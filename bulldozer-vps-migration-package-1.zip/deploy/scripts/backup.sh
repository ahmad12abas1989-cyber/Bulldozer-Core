#!/usr/bin/env bash
# deploy/scripts/backup.sh
# Create a timestamped, compressed backup of all Bulldozer Mother Core persistent storage.
# Storage layout backed up:
#   storage/snapshots/
#   storage/runtime-snapshots/
#   storage/runtime-state/
#   storage/tasks/
#   storage/store/
# Does NOT back up secrets, .env, or the container image.
# Does NOT mutate any Mother Core state. Read-only operation.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPLOY_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ENV_FILE="${DEPLOY_DIR}/.env"

# Load config from .env if present
if [[ -f "${ENV_FILE}" ]]; then
  set -o allexport
  # shellcheck disable=SC1090
  source <(grep -E '^[A-Z_]+=' "${ENV_FILE}" | sed 's/#.*//')
  set +o allexport
fi

STORAGE_PATH="${STORAGE_PATH:-/opt/bulldozer/storage}"
BACKUP_DIR="${BACKUP_DIR:-/opt/bulldozer/backups}"
BACKUP_RETENTION="${BACKUP_RETENTION:-14}"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
ARCHIVE_NAME="bulldozer-backup-${TIMESTAMP}.tar.gz"
ARCHIVE_PATH="${BACKUP_DIR}/${ARCHIVE_NAME}"

echo "[bulldozer] Backup starting — ${TIMESTAMP}"
echo "[bulldozer]   Source  : ${STORAGE_PATH}"
echo "[bulldozer]   Dest    : ${ARCHIVE_PATH}"

# Ensure backup directory exists
mkdir -p "${BACKUP_DIR}"

# Verify storage directory exists and is non-empty
if [[ ! -d "${STORAGE_PATH}" ]]; then
  echo "[bulldozer] ERROR: Storage directory not found: ${STORAGE_PATH}"
  exit 1
fi

# Create compressed archive
tar -czf "${ARCHIVE_PATH}" \
  --exclude='*.tmp' \
  -C "$(dirname "${STORAGE_PATH}")" \
  "$(basename "${STORAGE_PATH}")"

ARCHIVE_SIZE=$(du -sh "${ARCHIVE_PATH}" | cut -f1)
echo "[bulldozer] Archive created: ${ARCHIVE_PATH} (${ARCHIVE_SIZE})"

# Compute checksum
sha256sum "${ARCHIVE_PATH}" > "${ARCHIVE_PATH}.sha256"
echo "[bulldozer] Checksum:  ${ARCHIVE_PATH}.sha256"

# Prune old backups — keep only the N most recent archives
ARCHIVE_COUNT=$(find "${BACKUP_DIR}" -maxdepth 1 -name "bulldozer-backup-*.tar.gz" | wc -l)
if [[ "${ARCHIVE_COUNT}" -gt "${BACKUP_RETENTION}" ]]; then
  PRUNE_COUNT=$(( ARCHIVE_COUNT - BACKUP_RETENTION ))
  echo "[bulldozer] Pruning ${PRUNE_COUNT} old backup(s) (retention=${BACKUP_RETENTION})..."
  find "${BACKUP_DIR}" -maxdepth 1 -name "bulldozer-backup-*.tar.gz" \
    | sort | head -n "${PRUNE_COUNT}" \
    | xargs -I{} sh -c 'rm -f "{}" "{}.sha256" && echo "  removed: {}"'
fi

echo "[bulldozer] Backup complete."
