import {
  mkdirSync,
  writeFileSync,
  readFileSync,
  readdirSync,
  existsSync,
  statSync,
  renameSync,
  unlinkSync,
} from "node:fs";
import { join, basename } from "node:path";
import { logger } from "../lib/logger";
import { config } from "./config";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { emitRuntimeEvent } from "./runtimeEventBus";

export interface PersistentStoreStatus {
  operational: boolean;
  subsystemName: "persistent_store";
  storeDir: string;
  keyCount: number;
  keys: string[];
  bytesUsed: number;
  maxKeys: number;
  executionBlocked: true;
  recoveryBlocked: true;
  initializedAt: string | null;
}

const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;
const MAX_KEYS = 100;
const MAX_VALUE_SIZE = 512 * 1024;
const MAX_KEY_LENGTH = 64;
const KEY_PATTERN = /^[a-zA-Z0-9_-]+$/;

const STORE_DIR = join(config.storageDir, "store");

let operational = false;
let initializedAt: string | null = null;

function validateKey(key: string): void {
  if (!KEY_PATTERN.test(key)) {
    throw new Error(
      `Invalid store key "${key}" — must match [a-zA-Z0-9_-]+`,
    );
  }
  if (key.length > MAX_KEY_LENGTH) {
    throw new Error(
      `Store key too long: ${key.length} chars (max ${MAX_KEY_LENGTH})`,
    );
  }
}

function keyPath(key: string): string {
  return join(STORE_DIR, `${key}.json`);
}

function listKeyFiles(): string[] {
  if (!existsSync(STORE_DIR)) return [];
  return readdirSync(STORE_DIR)
    .filter((f) => f.endsWith(".json") && !f.endsWith(".tmp.json"))
    .sort();
}

function computeBytesUsed(): number {
  if (!existsSync(STORE_DIR)) return 0;
  return listKeyFiles().reduce((sum, f) => {
    try {
      return sum + statSync(join(STORE_DIR, f)).size;
    } catch {
      return sum;
    }
  }, 0);
}

export function initPersistentStore(): void {
  mkdirSync(STORE_DIR, { recursive: true });
  operational = true;
  initializedAt = new Date().toISOString();

  const keys = listKeyFiles().map((f) => basename(f, ".json"));

  emit("persistent_store:initialized", "persistent-store", { keyCount: keys.length });
  addTimelineEvent({
    level: "info",
    source: "persistent-store",
    message: `Persistent store initialized — ${keys.length} existing key(s)`,
    metadata: { keyCount: keys.length, storeDir: STORE_DIR },
  });
  emitRuntimeEvent({
    eventType: "persistent_store.initialized",
    source: "persistent-store",
    severity: "info",
    category: "persistence",
    payload: { keyCount: keys.length, executionBlocked: EXECUTION_BLOCKED },
  });

  logger.info(
    { subsystem: "persistent_store", keyCount: keys.length, storeDir: STORE_DIR },
    "Persistent store initialized",
  );
}

export function readStore<T = unknown>(key: string): T | null {
  validateKey(key);
  const path = keyPath(key);
  if (!existsSync(path)) return null;
  try {
    const content = readFileSync(path, "utf8");
    return JSON.parse(content) as T;
  } catch (err) {
    logger.warn({ key, err: String(err) }, "Failed to read store key");
    return null;
  }
}

export function writeStore<T = unknown>(key: string, value: T): void {
  validateKey(key);
  const payload = JSON.stringify(value, null, 2);
  if (payload.length > MAX_VALUE_SIZE) {
    throw new Error(
      `Value too large for key "${key}": ${payload.length} bytes (max ${MAX_VALUE_SIZE})`,
    );
  }
  mkdirSync(STORE_DIR, { recursive: true });
  const path = keyPath(key);
  const tmp = `${path}.tmp`;
  writeFileSync(tmp, payload, "utf8");
  renameSync(tmp, path);
  logger.info({ key, bytes: payload.length }, "Store key written");
}

export function deleteStore(key: string): void {
  validateKey(key);
  const path = keyPath(key);
  if (!existsSync(path)) return;
  unlinkSync(path);
  logger.info({ key }, "Store key deleted");
}

export function listStoreKeys(): string[] {
  return listKeyFiles().map((f) => basename(f, ".json"));
}

export function getPersistentStoreStatus(): PersistentStoreStatus {
  const keys = listStoreKeys();
  return {
    operational,
    subsystemName: "persistent_store",
    storeDir: STORE_DIR,
    keyCount: keys.length,
    keys,
    bytesUsed: computeBytesUsed(),
    maxKeys: MAX_KEYS,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    initializedAt,
  };
}
