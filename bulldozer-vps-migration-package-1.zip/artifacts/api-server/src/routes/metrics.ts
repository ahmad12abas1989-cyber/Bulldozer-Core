import type { IncomingMessage, ServerResponse } from "node:http";
import { getMetrics } from "../core/metrics";
import { sendJson } from "../lib/response";

export function handleMetrics(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getMetrics());
}
