import {
  mkdirSync,
  writeFileSync,
  readFileSync,
  readdirSync,
  renameSync,
  unlinkSync,
  existsSync,
} from "node:fs";
import { join } from "node:path";
import { logger } from "../lib/logger";
import { config } from "./config";
import type { Snapshot } from "./snapshots";

const STORAGE_DIR = join(config.storageDir, "snapshots");
const MAX_FILES = 20;

export function ensureStorageDir(): void {
  mkdirSync(STORAGE_DIR, { recursive: true });
}

function snapshotFileName(snapshot: Snapshot): string {
  const ts = snapshot.createdAt.replace(/[:.]/g, "-");
  return `${ts}-${snapshot.id}.json`;
}

function listSnapshotFiles(): string[] {
  if (!existsSync(STORAGE_DIR)) return [];
  return readdirSync(STORAGE_DIR)
    .filter((f) => f.endsWith(".json") && !f.endsWith(".tmp.json"))
    .sort();
}

function pruneOldFiles(files: string[]): void {
  if (files.length <= MAX_FILES) return;
  const toDelete = files.slice(0, files.length - MAX_FILES);
  for (const f of toDelete) {
    try {
      unlinkSync(join(STORAGE_DIR, f));
    } catch (err) {
      logger.warn({ file: f, err: String(err) }, "Failed to prune old snapshot file");
    }
  }
}

export function persistSnapshot(snapshot: Snapshot): void {
  ensureStorageDir();
  const filename = snapshotFileName(snapshot);
  const filePath = join(STORAGE_DIR, filename);
  const tmpPath = `${filePath}.tmp`;
  writeFileSync(tmpPath, JSON.stringify(snapshot, null, 2), "utf8");
  renameSync(tmpPath, filePath);
  const files = listSnapshotFiles();
  pruneOldFiles(files);
  logger.info({ file: filename, reason: snapshot.reason }, "Snapshot persisted");
}

export function loadLatestPersistedSnapshot(): Snapshot | null {
  const files = listSnapshotFiles();
  if (files.length === 0) return null;
  const latest = files[files.length - 1]!;
  try {
    const content = readFileSync(join(STORAGE_DIR, latest), "utf8");
    return JSON.parse(content) as Snapshot;
  } catch (err) {
    logger.warn({ file: latest, err: String(err) }, "Failed to read latest snapshot file");
    return null;
  }
}

export function listPersistedSnapshots(): {
  count: number;
  files: string[];
  storageDir: string;
  latest: Snapshot | null;
} {
  const files = listSnapshotFiles();
  return {
    count: files.length,
    files,
    storageDir: STORAGE_DIR,
    latest: loadLatestPersistedSnapshot(),
  };
}
