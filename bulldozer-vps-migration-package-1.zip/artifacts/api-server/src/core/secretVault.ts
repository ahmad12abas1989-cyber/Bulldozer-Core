import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";

export type VaultSecretCategory = "auth" | "payment" | "ai" | "webhook" | "internal";
export type VaultSecretSource = "env" | "vault_placeholder";

export interface VaultEntry {
  name: string;
  category: VaultSecretCategory;
  configured: boolean;
  source: VaultSecretSource;
  lastCheckedAt: string;
}

export interface VaultStatus {
  operational: boolean;
  totalSecrets: number;
  configuredCount: number;
  unconfiguredCount: number;
  placeholderCount: number;
  entries: VaultEntry[];
  lastCheckedAt: string;
  executionBlocked: true;
}

const EXECUTION_BLOCKED: true = true;

interface KnownSecretDef {
  name: string;
  category: VaultSecretCategory;
  source: VaultSecretSource;
}

const KNOWN_SECRETS: KnownSecretDef[] = [
  { name: "BULLDOZER_OWNER_API_KEY", category: "auth", source: "env" },
  { name: "BULLDOZER_SERVICE_API_KEY", category: "auth", source: "env" },
  { name: "BULLDOZER_STRIPE_SECRET_KEY", category: "payment", source: "vault_placeholder" },
  { name: "BULLDOZER_OPENAI_API_KEY", category: "ai", source: "vault_placeholder" },
  { name: "BULLDOZER_WEBHOOK_SECRET", category: "webhook", source: "vault_placeholder" },
];

let isOperational = false;

function isConfigured(def: KnownSecretDef): boolean {
  if (def.source === "vault_placeholder") return false;
  const val = process.env[def.name];
  return typeof val === "string" && val.length > 0;
}

function buildEntries(): VaultEntry[] {
  const now = new Date().toISOString();
  return KNOWN_SECRETS.map((def) => ({
    name: def.name,
    category: def.category,
    configured: isConfigured(def),
    source: def.source,
    lastCheckedAt: now,
  }));
}

export function initSecretVault(): void {
  if (isOperational) return;

  isOperational = true;

  const entries = buildEntries();
  const configuredCount = entries.filter((e) => e.configured).length;
  const placeholderCount = entries.filter((e) => e.source === "vault_placeholder").length;

  addTimelineEvent({
    level: "info",
    source: "secret-vault",
    message: "Secret vault initialized",
    metadata: {
      totalSecrets: entries.length,
      configuredCount,
      placeholderCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  emit("secret_vault:initialized", "secret-vault", {
    totalSecrets: entries.length,
    configuredCount,
    placeholderCount,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "secret_vault.initialized",
    source: "secret-vault",
    severity: "info",
    category: "runtime",
    payload: {
      totalSecrets: entries.length,
      configuredCount,
      placeholderCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    {
      totalSecrets: entries.length,
      configuredCount,
      placeholderCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
    "Secret vault initialized",
  );
}

export function getVaultStatus(): VaultStatus {
  const entries = buildEntries();
  const configuredCount = entries.filter((e) => e.configured).length;
  const unconfiguredCount = entries.filter((e) => !e.configured && e.source === "env").length;
  const placeholderCount = entries.filter((e) => e.source === "vault_placeholder").length;

  return {
    operational: isOperational,
    totalSecrets: entries.length,
    configuredCount,
    unconfiguredCount,
    placeholderCount,
    entries,
    lastCheckedAt: new Date().toISOString(),
    executionBlocked: EXECUTION_BLOCKED,
  };
}
