// firstActualSandboxMutationExecutorCore.ts
// Phase 329 — First Actual Sandbox Mutation Executor Descriptor Core Skeleton
// In-memory first actual sandbox mutation executor descriptor engine.
// Layer 29 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate stack.
// Prepares the first actual sandbox mutation executor descriptor.
// Preserves sandbox-approved-only target scope from layers 24–28 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. mutationExecutorEnabled=false — executor has not been activated.
// mutationExecutorPrepared=true — descriptor-readiness established for a future first actual sandbox write mutation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { ActualSandboxWriteCommitExecutionGateRecord } from "./actualSandboxWriteCommitExecutionGateCore.js";
import type { SandboxWriteCommitEnableRecord }              from "./sandboxWriteCommitEnableCore.js";
import type { FirstSandboxWriteCommitRecord }               from "./firstSandboxWriteCommitCore.js";
import type { RuntimeWriteExecutorRecord }                  from "./runtimeWriteExecutorCore.js";
import type { FirstActualSandboxWriteOperationRecord }      from "./firstActualSandboxWriteOperationCore.js";
import type { ControlledExecutionRecord }                   from "./controlledExecutionCore.js";
import { randomUUID }                                       from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type MutationExecutorState = "descriptor_mutation_executor_pending";

export type MutationExecutorCheckRule =
  | "commit_execution_gate_exists"
  | "commit_enable_record_exists"
  | "sandbox_write_commit_exists"
  | "runtime_write_executor_exists"
  | "actual_write_operation_exists"
  | "execution_record_exists"
  | "commit_execution_gate_bound_to_commit_enable"
  | "commit_enable_bound_to_commit"
  | "commit_bound_to_executor"
  | "executor_bound_to_write_operation"
  | "mutation_executor_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface MutationExecutorCheck {
  readonly rule: MutationExecutorCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface MutationExecutorBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface MutationExecutorPlanEntry {
  readonly entryId:               string;
  readonly operationType:         "descriptor_mutation_executor_planned";
  readonly targetScope:           "sandbox_approved_only";
  readonly mutationExecutorEnabled: false;
  readonly mutationBlocked:       true;
  readonly note:                  string;
}

export interface LinkedMutationExecutorReference {
  readonly commitExecutionGateId:         string;
  readonly sandboxWriteCommitEnableId:    string;
  readonly sandboxWriteCommitId:          string;
  readonly runtimeWriteExecutorId:        string;
  readonly rollbackSnapshotId:            string;
  readonly mutationExecutorPrepared:      true;
  readonly mutationExecutorEnabled:       false;
  readonly commitExecutionGateEnabled:    false;
  readonly sandboxWriteCommitEnabled:     false;
  readonly actualWritesEnabled:           false;
  readonly rollbackChainValid:            boolean;
  readonly referenceNote:                 string;
}

export interface MutationExecutorReadinessReport {
  readonly mutationExecutorPrepared:      true;
  readonly mutationExecutorEnabled:       false;
  readonly commitExecutionGateEnabled:    false;
  readonly sandboxWriteCommitEnabled:     false;
  readonly runtimeWriteExecutorEnabled:   false;
  readonly writeExecutionGateEnabled:     false;
  readonly scopedActivationEnabled:       false;
  readonly writePermissionEnabled:        false;
  readonly mutationSwitchEnabled:         false;
  readonly guardedWriteEnabled:           false;
  readonly actualWritesEnabled:           false;
  readonly realWritesEnabled:             false;
  readonly approvalRequired:              true;
  readonly allChecksPass:                 boolean;
  readonly blockedReasonCount:            number;
  readonly rollbackChainValid:            boolean;
  readonly targetScope:                   "sandbox_approved_only";
  readonly summary:                       string;
}

export interface FirstActualSandboxMutationExecutorRecord {
  readonly mutationExecutorId:            string;
  readonly mutationExecutorState:         MutationExecutorState;
  readonly approvalRequired:              true;
  readonly mutationExecutorPrepared:      true;
  readonly mutationExecutorEnabled:       false;
  readonly commitExecutionGateEnabled:    false;
  readonly sandboxWriteCommitEnabled:     false;
  readonly runtimeWriteExecutorEnabled:   false;
  readonly actualWritesEnabled:           false;
  readonly filesystemMutationBlocked:     true;
  readonly motherCoreMutationBlocked:     true;
  readonly vaultMutationBlocked:          true;
  readonly shellBlocked:                  true;
  readonly networkBlocked:                true;
  readonly targetScope:                   "sandbox_approved_only";
  readonly implementationPhase:           "descriptor_only";
  readonly commitExecutionGateId:         string;
  readonly sandboxWriteCommitEnableId:    string;
  readonly sandboxWriteCommitId:          string;
  readonly runtimeWriteExecutorId:        string;
  readonly actualWriteOperationId:        string;
  readonly controlledExecutionId:         string;
  readonly mutationExecutorPlan:          readonly MutationExecutorPlanEntry[];
  readonly mutationExecutorChecks:        readonly MutationExecutorCheck[];
  readonly mutationExecutorBlockedReasons: readonly MutationExecutorBlockedReason[];
  readonly mutationExecutorReadinessReport: MutationExecutorReadinessReport;
  readonly linkedMutationExecutorReference: LinkedMutationExecutorReference;
  readonly createdAt:                     string;
}

export interface CreateFirstActualSandboxMutationExecutorInput {
  readonly commitExecutionGateRecord: ActualSandboxWriteCommitExecutionGateRecord;
  readonly commitEnableRecord:        SandboxWriteCommitEnableRecord;
  readonly commitRecord:              FirstSandboxWriteCommitRecord;
  readonly executorRecord:            RuntimeWriteExecutorRecord;
  readonly writeOperationRecord:      FirstActualSandboxWriteOperationRecord;
  readonly executionRecord:           ControlledExecutionRecord;
}

export interface FirstActualSandboxMutationExecutorSummary {
  readonly total:                         number;
  readonly byState:                       Record<MutationExecutorState, number>;
  readonly mutationExecutorPrepared:      true;
  readonly mutationExecutorEnabled:       false;
  readonly commitExecutionGateEnabled:    false;
  readonly sandboxWriteCommitEnabled:     false;
  readonly runtimeWriteExecutorEnabled:   false;
  readonly actualWritesEnabled:           false;
  readonly approvalRequired:              true;
  readonly filesystemMutationBlocked:     true;
  readonly motherCoreMutationBlocked:     true;
  readonly targetScope:                   "sandbox_approved_only";
  readonly mutationExecutorState:         MutationExecutorState;
  readonly implementationPhase:           "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstActualSandboxMutationExecutorRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstActualSandboxMutationExecutorInput,
): readonly MutationExecutorCheck[] {
  const { commitExecutionGateRecord, commitEnableRecord, commitRecord, executorRecord, writeOperationRecord, executionRecord } = input;

  const gateExists    = commitExecutionGateRecord.commitExecutionGateId.length > 0;
  const enableExists  = commitEnableRecord.sandboxWriteCommitEnableId.length > 0;
  const commitExists  = commitRecord.sandboxWriteCommitId.length > 0;
  const execExists    = executorRecord.runtimeWriteExecutorId.length > 0;
  const opExists      = writeOperationRecord.actualWriteOperationId.length > 0;
  const ctrlExists    = executionRecord.controlledExecutionId.length > 0;

  const gateBound     = commitExecutionGateRecord.sandboxWriteCommitEnableId === commitEnableRecord.sandboxWriteCommitEnableId;
  const enableBound   = commitEnableRecord.sandboxWriteCommitId === commitRecord.sandboxWriteCommitId;
  const commitBound   = commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId;
  const execBound     = executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId;

  return [
    {
      rule: "commit_execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`
        : "commitExecutionGateRecord.commitExecutionGateId is empty",
    },
    {
      rule: "commit_enable_record_exists",
      pass: enableExists,
      note: enableExists
        ? `sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`
        : "commitEnableRecord.sandboxWriteCommitEnableId is empty",
    },
    {
      rule: "sandbox_write_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`
        : "commitRecord.sandboxWriteCommitId is empty",
    },
    {
      rule: "runtime_write_executor_exists",
      pass: execExists,
      note: execExists
        ? `runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`
        : "executorRecord.runtimeWriteExecutorId is empty",
    },
    {
      rule: "actual_write_operation_exists",
      pass: opExists,
      note: opExists
        ? `actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`
        : "writeOperationRecord.actualWriteOperationId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "commit_execution_gate_bound_to_commit_enable",
      pass: gateBound,
      note: gateBound
        ? `commitExecutionGateRecord.sandboxWriteCommitEnableId === commitEnableRecord.sandboxWriteCommitEnableId (${commitEnableRecord.sandboxWriteCommitEnableId})`
        : `gate/commit-enable mismatch: gate.sandboxWriteCommitEnableId=${commitExecutionGateRecord.sandboxWriteCommitEnableId} vs enable.sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`,
    },
    {
      rule: "commit_enable_bound_to_commit",
      pass: enableBound,
      note: enableBound
        ? `commitEnableRecord.sandboxWriteCommitId === commitRecord.sandboxWriteCommitId (${commitRecord.sandboxWriteCommitId})`
        : `commit-enable/commit mismatch: enable.sandboxWriteCommitId=${commitEnableRecord.sandboxWriteCommitId} vs commit.sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`,
    },
    {
      rule: "commit_bound_to_executor",
      pass: commitBound,
      note: commitBound
        ? `commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId (${executorRecord.runtimeWriteExecutorId})`
        : `commit/executor mismatch: commit.runtimeWriteExecutorId=${commitRecord.runtimeWriteExecutorId} vs executor.runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`,
    },
    {
      rule: "executor_bound_to_write_operation",
      pass: execBound,
      note: execBound
        ? `executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId (${writeOperationRecord.actualWriteOperationId})`
        : `executor/write-operation mismatch: executor.actualWriteOperationId=${executorRecord.actualWriteOperationId} vs op.actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`,
    },
    {
      rule: "mutation_executor_still_disabled",
      pass: true,
      note: "mutationExecutorEnabled=false — compile-time literal; no mutation executor activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "mutationExecutorState=descriptor_mutation_executor_pending — output is a descriptor only; mutation executor is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly MutationExecutorCheck[],
): readonly MutationExecutorBlockedReason[] {
  const staticReasons: MutationExecutorBlockedReason[] = [
    { code: "mutation_executor_disabled", reason: "mutationExecutorEnabled=false — compile-time literal; an explicit first actual sandbox write mutation phase must activate the executor before any sandbox target can be mutated",                                                                                                                                                                                                                                           static: true },
    { code: "approval_required",          reason: "approvalRequired=true — explicit operator approval is required before the mutation executor can be activated",                                                                                                                                                                                                                                                                                                              static: true },
    { code: "actual_writes_disabled",     reason: "actualWritesEnabled=false — compile-time literal across all 29 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, and commit-execution-gate layers", static: true },
  ];
  const dynamicReasons: MutationExecutorBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedMutationExecutorReference(
  input: CreateFirstActualSandboxMutationExecutorInput,
  rollbackChainValid: boolean,
): LinkedMutationExecutorReference {
  const { commitExecutionGateRecord, commitEnableRecord, commitRecord, executorRecord } = input;
  return {
    commitExecutionGateId:        commitExecutionGateRecord.commitExecutionGateId,
    sandboxWriteCommitEnableId:   commitEnableRecord.sandboxWriteCommitEnableId,
    sandboxWriteCommitId:         commitRecord.sandboxWriteCommitId,
    runtimeWriteExecutorId:       executorRecord.runtimeWriteExecutorId,
    rollbackSnapshotId:           commitExecutionGateRecord.linkedCommitExecutionReference.rollbackSnapshotId,
    mutationExecutorPrepared:     true,
    mutationExecutorEnabled:      false,
    commitExecutionGateEnabled:   false,
    sandboxWriteCommitEnabled:    false,
    actualWritesEnabled:          false,
    rollbackChainValid,
    referenceNote: "linked mutation executor reference sources rollbackSnapshotId from commitExecutionGateRecord.linkedCommitExecutionReference; mutation executor disabled; commit execution gate disabled; sandbox write commit enable disabled; sandbox write commit disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstActualSandboxMutationExecutorRecord(
  input: CreateFirstActualSandboxMutationExecutorInput,
): FirstActualSandboxMutationExecutorRecord {
  const { commitExecutionGateRecord, commitEnableRecord, commitRecord, executorRecord, writeOperationRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = commitExecutionGateRecord.commitExecutionReadinessReport.rollbackChainValid;

  const allChecksPass   = checks.every((c) => c.pass);
  const blockedReasons  = buildBlockedReasons(checks);
  const linkedRef       = buildLinkedMutationExecutorReference(input, rollbackChainValid);

  const mutationExecutorPlan: MutationExecutorPlanEntry[] = [
    {
      entryId:                randomUUID(),
      operationType:          "descriptor_mutation_executor_planned",
      targetScope:            "sandbox_approved_only",
      mutationExecutorEnabled: false,
      mutationBlocked:        true,
      note:                   "mutation executor planned in descriptor-only mode; targetScope=sandbox_approved_only; mutationExecutorEnabled=false; filesystemMutationBlocked=true; first actual sandbox write mutation phase required to activate",
    },
  ];

  const mutationExecutorReadinessReport: MutationExecutorReadinessReport = {
    mutationExecutorPrepared:     true,
    mutationExecutorEnabled:      false,
    commitExecutionGateEnabled:   false,
    sandboxWriteCommitEnabled:    false,
    runtimeWriteExecutorEnabled:  false,
    writeExecutionGateEnabled:    false,
    scopedActivationEnabled:      false,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    targetScope:                  "sandbox_approved_only",
    summary: `mutationExecutorState=descriptor_mutation_executor_pending; mutationExecutorEnabled=false; commitExecutionGateEnabled=false; sandboxWriteCommitEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstActualSandboxMutationExecutorRecord = {
    mutationExecutorId:               randomUUID(),
    mutationExecutorState:            "descriptor_mutation_executor_pending",
    approvalRequired:                 true,
    mutationExecutorPrepared:         true,
    mutationExecutorEnabled:          false,
    commitExecutionGateEnabled:       false,
    sandboxWriteCommitEnabled:        false,
    runtimeWriteExecutorEnabled:      false,
    actualWritesEnabled:              false,
    filesystemMutationBlocked:        true,
    motherCoreMutationBlocked:        true,
    vaultMutationBlocked:             true,
    shellBlocked:                     true,
    networkBlocked:                   true,
    targetScope:                      "sandbox_approved_only",
    implementationPhase:              "descriptor_only",
    commitExecutionGateId:            commitExecutionGateRecord.commitExecutionGateId,
    sandboxWriteCommitEnableId:       commitEnableRecord.sandboxWriteCommitEnableId,
    sandboxWriteCommitId:             commitRecord.sandboxWriteCommitId,
    runtimeWriteExecutorId:           executorRecord.runtimeWriteExecutorId,
    actualWriteOperationId:           writeOperationRecord.actualWriteOperationId,
    controlledExecutionId:            executionRecord.controlledExecutionId,
    mutationExecutorPlan,
    mutationExecutorChecks:           checks,
    mutationExecutorBlockedReasons:   blockedReasons,
    mutationExecutorReadinessReport,
    linkedMutationExecutorReference:  linkedRef,
    createdAt:                        new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstActualSandboxMutationExecutorRecords(): readonly FirstActualSandboxMutationExecutorRecord[] {
  return _store.slice();
}

export function getFirstActualSandboxMutationExecutorSummary(): FirstActualSandboxMutationExecutorSummary {
  return {
    total:                          _store.length,
    byState:                        { descriptor_mutation_executor_pending: _store.length },
    mutationExecutorPrepared:       true,
    mutationExecutorEnabled:        false,
    commitExecutionGateEnabled:     false,
    sandboxWriteCommitEnabled:      false,
    runtimeWriteExecutorEnabled:    false,
    actualWritesEnabled:            false,
    approvalRequired:               true,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    targetScope:                    "sandbox_approved_only",
    mutationExecutorState:          "descriptor_mutation_executor_pending",
    implementationPhase:            "descriptor_only",
  };
}
