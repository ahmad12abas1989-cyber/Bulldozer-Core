import { SandboxFilesystemRecord, SandboxWritablePath, SandboxProtectedPath } from "./sandboxFilesystemCore.js";
import { ControlledExecutionRecord }                                            from "./controlledExecutionCore.js";
import { randomBytes }                                                          from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type WriteGuardState = "descriptor_guard_ready";

export type WritePolicyCheckRule =
  | "filesystem_record_exists"
  | "execution_record_exists"
  | "rollback_ready"
  | "approval_reference_present"
  | "allowed_zones_are_sandbox_scoped"
  | "protected_zones_fully_blocked"
  | "output_remains_descriptor_only";

export interface AllowedWriteZone {
  readonly path:            SandboxWritablePath;
  readonly writeAllowed:    boolean;
  readonly realWritesEnabled: false;
  readonly reason:          string;
}

export interface BlockedWriteZone {
  readonly path:            SandboxProtectedPath;
  readonly writeBlocked:    true;
  readonly reason:          string;
}

export interface WritePolicyCheck {
  readonly rule:   WritePolicyCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface WriteGuardRollbackReadiness {
  readonly rollbackRequired:   true;
  readonly rollbackReady:      boolean;
  readonly filesystemPlanId:   string;
  readonly summary:            string;
}

export interface WriteGuardRecord {
  readonly writeGuardId:              string;
  readonly guardState:                WriteGuardState;
  readonly approvalRequired:          true;
  readonly realWritesEnabled:         false;
  readonly motherCoreWritesBlocked:   true;
  readonly protectedZoneWritesBlocked: true;
  readonly rollbackRequired:          true;
  readonly implementationPhase:       "descriptor_only";
  readonly filesystemRecordId:        string;
  readonly executionRecordId:         string;
  readonly approvalReference:         string;
  readonly allowedZones:              readonly AllowedWriteZone[];
  readonly blockedZones:              readonly BlockedWriteZone[];
  readonly writePolicyChecks:         readonly WritePolicyCheck[];
  readonly rollbackReadiness:         WriteGuardRollbackReadiness;
  readonly createdAt:                 string;
}

export interface CreateWriteGuardInput {
  readonly filesystemRecord:  SandboxFilesystemRecord;
  readonly executionRecord:   ControlledExecutionRecord;
}

export interface WriteGuardSummary {
  readonly total:                     number;
  readonly byState:                   Record<WriteGuardState, number>;
  readonly realWritesEnabled:         false;
  readonly motherCoreWritesBlocked:   true;
  readonly protectedZoneWritesBlocked: true;
  readonly rollbackRequired:          true;
  readonly approvalRequired:          true;
  readonly allowedZonePaths:          readonly SandboxWritablePath[];
  readonly blockedZonePaths:          readonly SandboxProtectedPath[];
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildAllowedZones(
  filesystemRecord: SandboxFilesystemRecord,
): readonly AllowedWriteZone[] {
  return filesystemRecord.writableZones.map(z => ({
    path:             z.path,
    writeAllowed:     false,
    realWritesEnabled: false,
    reason:           "Descriptor-only phase — no real write activation; approval + rollback required first",
  }));
}

function buildBlockedZones(
  filesystemRecord: SandboxFilesystemRecord,
): readonly BlockedWriteZone[] {
  return filesystemRecord.protectedZones.map(z => ({
    path:         z.path,
    writeBlocked: true,
    reason:       `Protected zone — writes permanently blocked at all phases (${z.reason})`,
  }));
}

function buildPolicyChecks(
  input: CreateWriteGuardInput,
): readonly WritePolicyCheck[] {
  const { filesystemRecord, executionRecord } = input;
  const rollbackReady = filesystemRecord.rollbackFilesystemPlan.rollbackReady;
  const allZonesSandboxScoped = filesystemRecord.writableZones.every(
    z => z.path.startsWith("/sandbox/"),
  );
  const allProtectedBlocked = filesystemRecord.protectedZones.every(
    z => z.sandboxAccess === false,
  );

  return [
    {
      rule:   "filesystem_record_exists",
      passed: filesystemRecord.sandboxFilesystemId.length > 0,
      detail: "Sandbox filesystem record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "rollback_ready",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback filesystem plan is complete and validated"
        : "Rollback filesystem plan is not yet valid — writes cannot proceed",
    },
    {
      rule:   "approval_reference_present",
      passed: filesystemRecord.approvalReference.length > 0,
      detail: "Operator approval reference is present in filesystem record",
    },
    {
      rule:   "allowed_zones_are_sandbox_scoped",
      passed: allZonesSandboxScoped,
      detail: "All allowed zones are scoped under /sandbox/ — no escape to host filesystem",
    },
    {
      rule:   "protected_zones_fully_blocked",
      passed: allProtectedBlocked,
      detail: `All ${filesystemRecord.protectedZones.length} protected zones have sandboxAccess=false`,
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: true,
      detail: "Write guard output is descriptor-only — no real filesystem mutation",
    },
  ] as const;
}

function buildRollbackReadiness(
  filesystemRecord: SandboxFilesystemRecord,
): WriteGuardRollbackReadiness {
  const rollbackReady = filesystemRecord.rollbackFilesystemPlan.rollbackReady;
  return {
    rollbackRequired: true,
    rollbackReady,
    filesystemPlanId: filesystemRecord.sandboxFilesystemId,
    summary: rollbackReady
      ? "Rollback plan validated — guard may proceed to approval gate"
      : "Rollback plan incomplete — guard is blocked until rollback is validated",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const guardStore = new Map<string, WriteGuardRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createWriteGuardRecord(
  input: CreateWriteGuardInput,
): { ok: true; record: WriteGuardRecord } {
  const writeGuardId    = randomBytes(16).toString("hex");
  const allowedZones    = buildAllowedZones(input.filesystemRecord);
  const blockedZones    = buildBlockedZones(input.filesystemRecord);
  const checks          = buildPolicyChecks(input);
  const rollbackReadiness = buildRollbackReadiness(input.filesystemRecord);

  const record: WriteGuardRecord = {
    writeGuardId,
    guardState:                "descriptor_guard_ready",
    approvalRequired:          true,
    realWritesEnabled:         false,
    motherCoreWritesBlocked:   true,
    protectedZoneWritesBlocked: true,
    rollbackRequired:          true,
    implementationPhase:       "descriptor_only",
    filesystemRecordId:        input.filesystemRecord.sandboxFilesystemId,
    executionRecordId:         input.executionRecord.controlledExecutionId,
    approvalReference:         input.filesystemRecord.approvalReference,
    allowedZones,
    blockedZones,
    writePolicyChecks:         checks,
    rollbackReadiness,
    createdAt:                 new Date().toISOString(),
  };

  guardStore.set(writeGuardId, record);
  return { ok: true, record };
}

export function listWriteGuardRecords(): readonly WriteGuardRecord[] {
  return [...guardStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getWriteGuardSummary(): WriteGuardSummary {
  const records = listWriteGuardRecords();
  const allowedPaths: SandboxWritablePath[] = [
    "/sandbox/workspace",
    "/sandbox/tmp",
    "/sandbox/build-cache",
  ];
  const blockedPaths: SandboxProtectedPath[] = [
    "/mother-core",
    "/vault",
    "/runtime-config",
    "/system",
    "/network-secrets",
  ];
  return {
    total:                     records.length,
    byState:                   { descriptor_guard_ready: records.length },
    realWritesEnabled:         false,
    motherCoreWritesBlocked:   true,
    protectedZoneWritesBlocked: true,
    rollbackRequired:          true,
    approvalRequired:          true,
    allowedZonePaths:          allowedPaths,
    blockedZonePaths:          blockedPaths,
  };
}
