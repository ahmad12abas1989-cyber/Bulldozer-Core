// firstControlledFilesystemMutationFinalApprovalCore.ts
// Phase 352 — First Controlled Filesystem Mutation Final Approval Descriptor Core Skeleton
// In-memory first controlled filesystem mutation final approval descriptor engine.
// Layer 39 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply + mutation-surface +
//   filesystem-mutation-enablement + filesystem-mutation-gate +
//   filesystem-mutation-permit + filesystem-mutation-authorization +
//   filesystem-mutation-approval + filesystem-mutation-grant stack.
// Defines the first controlled filesystem mutation final approval descriptor.
// Binds final approval to filesystem mutation grant and to approval/authorization/permit/gate chain.
// Preserves sandbox-approved-only target scope from layers 24–38 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem mutation. No shell execution. No network access.
// No vault access. No Mother Core mutation.
// filesystemMutationFinalApprovalGranted=false — final approval has not been granted.
// filesystemMutationFinalApprovalPrepared=true — descriptor-readiness established for a future
//   first controlled filesystem mutation final approval grant phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstControlledFilesystemMutationGrantRecord }         from "./firstControlledFilesystemMutationGrantCore.js";
import type { FirstControlledFilesystemMutationApprovalRecord }      from "./firstControlledFilesystemMutationApprovalCore.js";
import type { FirstControlledFilesystemMutationAuthorizationRecord } from "./firstControlledFilesystemMutationAuthorizationCore.js";
import type { FirstControlledFilesystemMutationPermitRecord }        from "./firstControlledFilesystemMutationPermitCore.js";
import type { FirstControlledFilesystemMutationGateRecord }          from "./firstControlledFilesystemMutationGateCore.js";
import type { ControlledExecutionRecord }                            from "./controlledExecutionCore.js";
import { randomUUID }                                                from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FilesystemMutationFinalApprovalState =
  "descriptor_filesystem_mutation_final_approval_pending";

export type FilesystemMutationFinalApprovalCheckRule =
  | "final_approval_still_not_granted"
  | "grant_bound_to_approval"
  | "approval_bound_to_authorization"
  | "authorization_bound_to_permit"
  | "permit_bound_to_gate"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface FilesystemMutationFinalApprovalCheck {
  readonly rule: FilesystemMutationFinalApprovalCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface FilesystemMutationFinalApprovalBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface FilesystemMutationFinalApprovalPlanEntry {
  readonly entryId:                              string;
  readonly operationType:                        "descriptor_filesystem_mutation_final_approval_planned";
  readonly targetScope:                          "sandbox_approved_only";
  readonly filesystemMutationFinalApprovalGranted: false;
  readonly mutationBlocked:                      true;
  readonly note:                                 string;
}

export interface LinkedFilesystemMutationFinalApprovalReference {
  readonly filesystemMutationGrantId:               string;
  readonly filesystemMutationApprovalId:            string;
  readonly filesystemMutationAuthorizationId:       string;
  readonly filesystemMutationPermitId:              string;
  readonly rollbackSnapshotId:                      string;
  readonly filesystemMutationFinalApprovalPrepared: true;
  readonly filesystemMutationFinalApprovalGranted:  false;
  readonly filesystemMutationGrantEnabled:          false;
  readonly filesystemMutationApprovalGranted:       false;
  readonly filesystemMutationAuthorizationEnabled:  false;
  readonly filesystemMutationPermitEnabled:         false;
  readonly filesystemMutationGateEnabled:           false;
  readonly actualWritesEnabled:                     false;
  readonly rollbackChainValid:                      boolean;
  readonly referenceNote:                           string;
}

export interface FilesystemMutationFinalApprovalReadinessReport {
  readonly filesystemMutationFinalApprovalPrepared:    true;
  readonly filesystemMutationFinalApprovalGranted:     false;
  readonly filesystemMutationGrantEnabled:             false;
  readonly filesystemMutationApprovalGranted:          false;
  readonly filesystemMutationAuthorizationEnabled:     false;
  readonly filesystemMutationPermitEnabled:            false;
  readonly filesystemMutationGateEnabled:              false;
  readonly filesystemMutationEnablementEnabled:        false;
  readonly mutationSurfaceEnabled:                     false;
  readonly mutationApplyEnabled:                       false;
  readonly mutationCommitEnabled:                      false;
  readonly mutationExecutorEnabled:                    false;
  readonly commitExecutionGateEnabled:                 false;
  readonly sandboxWriteCommitEnabled:                  false;
  readonly runtimeWriteExecutorEnabled:                false;
  readonly writeExecutionGateEnabled:                  false;
  readonly scopedActivationEnabled:                    false;
  readonly writePermissionEnabled:                     false;
  readonly mutationSwitchEnabled:                      false;
  readonly guardedWriteEnabled:                        false;
  readonly actualWritesEnabled:                        false;
  readonly realWritesEnabled:                          false;
  readonly approvalRequired:                           true;
  readonly allChecksPass:                              boolean;
  readonly blockedReasonCount:                         number;
  readonly rollbackChainValid:                         boolean;
  readonly targetScope:                                "sandbox_approved_only";
  readonly summary:                                    string;
}

export interface FirstControlledFilesystemMutationFinalApprovalRecord {
  readonly filesystemMutationFinalApprovalId:              string;
  readonly filesystemMutationFinalApprovalState:           FilesystemMutationFinalApprovalState;
  readonly approvalRequired:                               true;
  readonly filesystemMutationFinalApprovalPrepared:        true;
  readonly filesystemMutationFinalApprovalGranted:         false;
  readonly filesystemMutationGrantEnabled:                 false;
  readonly filesystemMutationApprovalGranted:              false;
  readonly filesystemMutationAuthorizationEnabled:         false;
  readonly filesystemMutationPermitEnabled:                false;
  readonly filesystemMutationGateEnabled:                  false;
  readonly actualWritesEnabled:                            false;
  readonly filesystemMutationBlocked:                      true;
  readonly motherCoreMutationBlocked:                      true;
  readonly vaultMutationBlocked:                           true;
  readonly shellBlocked:                                   true;
  readonly networkBlocked:                                 true;
  readonly targetScope:                                    "sandbox_approved_only";
  readonly implementationPhase:                            "descriptor_only";
  readonly filesystemMutationGrantId:                      string;
  readonly filesystemMutationApprovalId:                   string;
  readonly filesystemMutationAuthorizationId:              string;
  readonly filesystemMutationPermitId:                     string;
  readonly filesystemMutationGateId:                       string;
  readonly controlledExecutionId:                          string;
  readonly filesystemMutationFinalApprovalPlan:            readonly FilesystemMutationFinalApprovalPlanEntry[];
  readonly filesystemMutationFinalApprovalChecks:          readonly FilesystemMutationFinalApprovalCheck[];
  readonly filesystemMutationFinalApprovalBlockedReasons:  readonly FilesystemMutationFinalApprovalBlockedReason[];
  readonly filesystemMutationFinalApprovalReadinessReport: FilesystemMutationFinalApprovalReadinessReport;
  readonly linkedFilesystemMutationFinalApprovalReference: LinkedFilesystemMutationFinalApprovalReference;
  readonly createdAt:                                      string;
}

export interface CreateFirstControlledFilesystemMutationFinalApprovalInput {
  readonly grantRecord:         FirstControlledFilesystemMutationGrantRecord;
  readonly approvalRecord:      FirstControlledFilesystemMutationApprovalRecord;
  readonly authorizationRecord: FirstControlledFilesystemMutationAuthorizationRecord;
  readonly permitRecord:        FirstControlledFilesystemMutationPermitRecord;
  readonly gateRecord:          FirstControlledFilesystemMutationGateRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface FirstControlledFilesystemMutationFinalApprovalSummary {
  readonly total:                                      number;
  readonly byState:                                    Record<FilesystemMutationFinalApprovalState, number>;
  readonly filesystemMutationFinalApprovalPrepared:    true;
  readonly filesystemMutationFinalApprovalGranted:     false;
  readonly filesystemMutationGrantEnabled:             false;
  readonly filesystemMutationApprovalGranted:          false;
  readonly filesystemMutationAuthorizationEnabled:     false;
  readonly filesystemMutationPermitEnabled:            false;
  readonly filesystemMutationGateEnabled:              false;
  readonly actualWritesEnabled:                        false;
  readonly approvalRequired:                           true;
  readonly filesystemMutationBlocked:                  true;
  readonly motherCoreMutationBlocked:                  true;
  readonly targetScope:                                "sandbox_approved_only";
  readonly filesystemMutationFinalApprovalState:       FilesystemMutationFinalApprovalState;
  readonly implementationPhase:                        "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstControlledFilesystemMutationFinalApprovalRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstControlledFilesystemMutationFinalApprovalInput,
): readonly FilesystemMutationFinalApprovalCheck[] {
  const { grantRecord, approvalRecord, authorizationRecord, permitRecord, gateRecord } = input;

  const grantBound         = grantRecord.filesystemMutationApprovalId === approvalRecord.filesystemMutationApprovalId;
  const approvalBound      = approvalRecord.filesystemMutationAuthorizationId === authorizationRecord.filesystemMutationAuthorizationId;
  const authorizationBound = authorizationRecord.filesystemMutationPermitId === permitRecord.filesystemMutationPermitId;
  const permitBound        = permitRecord.filesystemMutationGateId === gateRecord.filesystemMutationGateId;

  return [
    {
      rule: "final_approval_still_not_granted",
      pass: true,
      note: "filesystemMutationFinalApprovalGranted=false — compile-time literal; no filesystem mutation final approval grant phase has been started; final approval remains pending",
    },
    {
      rule: "grant_bound_to_approval",
      pass: grantBound,
      note: grantBound
        ? `grantRecord.filesystemMutationApprovalId === approvalRecord.filesystemMutationApprovalId (${approvalRecord.filesystemMutationApprovalId})`
        : `grant/approval mismatch: grant.filesystemMutationApprovalId=${grantRecord.filesystemMutationApprovalId} vs approval.filesystemMutationApprovalId=${approvalRecord.filesystemMutationApprovalId}`,
    },
    {
      rule: "approval_bound_to_authorization",
      pass: approvalBound,
      note: approvalBound
        ? `approvalRecord.filesystemMutationAuthorizationId === authorizationRecord.filesystemMutationAuthorizationId (${authorizationRecord.filesystemMutationAuthorizationId})`
        : `approval/authorization mismatch: approval.filesystemMutationAuthorizationId=${approvalRecord.filesystemMutationAuthorizationId} vs authorization.filesystemMutationAuthorizationId=${authorizationRecord.filesystemMutationAuthorizationId}`,
    },
    {
      rule: "authorization_bound_to_permit",
      pass: authorizationBound,
      note: authorizationBound
        ? `authorizationRecord.filesystemMutationPermitId === permitRecord.filesystemMutationPermitId (${permitRecord.filesystemMutationPermitId})`
        : `authorization/permit mismatch: authorization.filesystemMutationPermitId=${authorizationRecord.filesystemMutationPermitId} vs permit.filesystemMutationPermitId=${permitRecord.filesystemMutationPermitId}`,
    },
    {
      rule: "permit_bound_to_gate",
      pass: permitBound,
      note: permitBound
        ? `permitRecord.filesystemMutationGateId === gateRecord.filesystemMutationGateId (${gateRecord.filesystemMutationGateId})`
        : `permit/gate mismatch: permit.filesystemMutationGateId=${permitRecord.filesystemMutationGateId} vs gate.filesystemMutationGateId=${gateRecord.filesystemMutationGateId}`,
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "filesystemMutationFinalApprovalState=descriptor_filesystem_mutation_final_approval_pending — output is a descriptor only; filesystem mutation final approval is not yet granted",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly FilesystemMutationFinalApprovalCheck[],
): readonly FilesystemMutationFinalApprovalBlockedReason[] {
  const staticReasons: FilesystemMutationFinalApprovalBlockedReason[] = [
    { code: "filesystem_mutation_final_approval_not_granted", reason: "filesystemMutationFinalApprovalGranted=false — compile-time literal; an explicit first controlled filesystem mutation final approval grant phase must grant final approval before any sandbox target can receive filesystem writes",                                                                                                                                                                                                                                                                                                                                                        static: true },
    { code: "approval_required",                              reason: "approvalRequired=true — explicit operator approval is required before the filesystem mutation final approval can be granted",                                                                                                                                                                                                                                                                                                                                                                                                                                                              static: true },
    { code: "actual_writes_disabled",                         reason: "actualWritesEnabled=false — compile-time literal across all 39 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, mutation-apply, mutation-surface, filesystem-mutation-enablement, filesystem-mutation-gate, filesystem-mutation-permit, filesystem-mutation-authorization, filesystem-mutation-approval, and filesystem-mutation-grant layers", static: true },
  ];
  const dynamicReasons: FilesystemMutationFinalApprovalBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedFinalApprovalReference(
  input: CreateFirstControlledFilesystemMutationFinalApprovalInput,
  rollbackChainValid: boolean,
): LinkedFilesystemMutationFinalApprovalReference {
  const { grantRecord, approvalRecord, authorizationRecord, permitRecord } = input;
  return {
    filesystemMutationGrantId:               grantRecord.filesystemMutationGrantId,
    filesystemMutationApprovalId:            approvalRecord.filesystemMutationApprovalId,
    filesystemMutationAuthorizationId:       authorizationRecord.filesystemMutationAuthorizationId,
    filesystemMutationPermitId:              permitRecord.filesystemMutationPermitId,
    rollbackSnapshotId:                      grantRecord.linkedFilesystemMutationGrantReference.rollbackSnapshotId,
    filesystemMutationFinalApprovalPrepared: true,
    filesystemMutationFinalApprovalGranted:  false,
    filesystemMutationGrantEnabled:          false,
    filesystemMutationApprovalGranted:       false,
    filesystemMutationAuthorizationEnabled:  false,
    filesystemMutationPermitEnabled:         false,
    filesystemMutationGateEnabled:           false,
    actualWritesEnabled:                     false,
    rollbackChainValid,
    referenceNote: "linked filesystem mutation final approval reference sources rollbackSnapshotId from grantRecord.linkedFilesystemMutationGrantReference; filesystem mutation final approval not granted; filesystem mutation grant disabled; filesystem mutation approval not granted; filesystem mutation authorization disabled; filesystem mutation permit disabled; filesystem mutation gate disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstControlledFilesystemMutationFinalApprovalRecord(
  input: CreateFirstControlledFilesystemMutationFinalApprovalInput,
): FirstControlledFilesystemMutationFinalApprovalRecord {
  const { grantRecord, approvalRecord, authorizationRecord, permitRecord, gateRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = grantRecord.filesystemMutationGrantReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedFinalApprovalReference(input, rollbackChainValid);

  const filesystemMutationFinalApprovalPlan: FilesystemMutationFinalApprovalPlanEntry[] = [
    {
      entryId:                                randomUUID(),
      operationType:                          "descriptor_filesystem_mutation_final_approval_planned",
      targetScope:                            "sandbox_approved_only",
      filesystemMutationFinalApprovalGranted: false,
      mutationBlocked:                        true,
      note:                                   "filesystem mutation final approval planned in descriptor-only mode; targetScope=sandbox_approved_only; filesystemMutationFinalApprovalGranted=false; filesystemMutationBlocked=true; first controlled filesystem mutation final approval grant phase required to grant",
    },
  ];

  const filesystemMutationFinalApprovalReadinessReport: FilesystemMutationFinalApprovalReadinessReport = {
    filesystemMutationFinalApprovalPrepared:  true,
    filesystemMutationFinalApprovalGranted:   false,
    filesystemMutationGrantEnabled:           false,
    filesystemMutationApprovalGranted:        false,
    filesystemMutationAuthorizationEnabled:   false,
    filesystemMutationPermitEnabled:          false,
    filesystemMutationGateEnabled:            false,
    filesystemMutationEnablementEnabled:      false,
    mutationSurfaceEnabled:                   false,
    mutationApplyEnabled:                     false,
    mutationCommitEnabled:                    false,
    mutationExecutorEnabled:                  false,
    commitExecutionGateEnabled:               false,
    sandboxWriteCommitEnabled:                false,
    runtimeWriteExecutorEnabled:              false,
    writeExecutionGateEnabled:                false,
    scopedActivationEnabled:                  false,
    writePermissionEnabled:                   false,
    mutationSwitchEnabled:                    false,
    guardedWriteEnabled:                      false,
    actualWritesEnabled:                      false,
    realWritesEnabled:                        false,
    approvalRequired:                         true,
    allChecksPass,
    blockedReasonCount:                       blockedReasons.length,
    rollbackChainValid,
    targetScope:                              "sandbox_approved_only",
    summary: `filesystemMutationFinalApprovalState=descriptor_filesystem_mutation_final_approval_pending; filesystemMutationFinalApprovalGranted=false; filesystemMutationGrantEnabled=false; filesystemMutationApprovalGranted=false; filesystemMutationAuthorizationEnabled=false; filesystemMutationPermitEnabled=false; filesystemMutationGateEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstControlledFilesystemMutationFinalApprovalRecord = {
    filesystemMutationFinalApprovalId:              randomUUID(),
    filesystemMutationFinalApprovalState:           "descriptor_filesystem_mutation_final_approval_pending",
    approvalRequired:                               true,
    filesystemMutationFinalApprovalPrepared:        true,
    filesystemMutationFinalApprovalGranted:         false,
    filesystemMutationGrantEnabled:                 false,
    filesystemMutationApprovalGranted:              false,
    filesystemMutationAuthorizationEnabled:         false,
    filesystemMutationPermitEnabled:                false,
    filesystemMutationGateEnabled:                  false,
    actualWritesEnabled:                            false,
    filesystemMutationBlocked:                      true,
    motherCoreMutationBlocked:                      true,
    vaultMutationBlocked:                           true,
    shellBlocked:                                   true,
    networkBlocked:                                 true,
    targetScope:                                    "sandbox_approved_only",
    implementationPhase:                            "descriptor_only",
    filesystemMutationGrantId:                      grantRecord.filesystemMutationGrantId,
    filesystemMutationApprovalId:                   approvalRecord.filesystemMutationApprovalId,
    filesystemMutationAuthorizationId:              authorizationRecord.filesystemMutationAuthorizationId,
    filesystemMutationPermitId:                     permitRecord.filesystemMutationPermitId,
    filesystemMutationGateId:                       gateRecord.filesystemMutationGateId,
    controlledExecutionId:                          executionRecord.controlledExecutionId,
    filesystemMutationFinalApprovalPlan,
    filesystemMutationFinalApprovalChecks:          checks,
    filesystemMutationFinalApprovalBlockedReasons:  blockedReasons,
    filesystemMutationFinalApprovalReadinessReport,
    linkedFilesystemMutationFinalApprovalReference: linkedRef,
    createdAt:                                      new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstControlledFilesystemMutationFinalApprovalRecords(): readonly FirstControlledFilesystemMutationFinalApprovalRecord[] {
  return _store.slice();
}

export function getFirstControlledFilesystemMutationFinalApprovalSummary(): FirstControlledFilesystemMutationFinalApprovalSummary {
  return {
    total:                                       _store.length,
    byState:                                     { descriptor_filesystem_mutation_final_approval_pending: _store.length },
    filesystemMutationFinalApprovalPrepared:     true,
    filesystemMutationFinalApprovalGranted:      false,
    filesystemMutationGrantEnabled:              false,
    filesystemMutationApprovalGranted:           false,
    filesystemMutationAuthorizationEnabled:      false,
    filesystemMutationPermitEnabled:             false,
    filesystemMutationGateEnabled:               false,
    actualWritesEnabled:                         false,
    approvalRequired:                            true,
    filesystemMutationBlocked:                   true,
    motherCoreMutationBlocked:                   true,
    targetScope:                                 "sandbox_approved_only",
    filesystemMutationFinalApprovalState:        "descriptor_filesystem_mutation_final_approval_pending",
    implementationPhase:                         "descriptor_only",
  };
}
