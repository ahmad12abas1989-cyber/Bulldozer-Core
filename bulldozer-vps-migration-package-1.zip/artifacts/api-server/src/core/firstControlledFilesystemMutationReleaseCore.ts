// firstControlledFilesystemMutationReleaseCore.ts
// Phase 354 — First Controlled Filesystem Mutation Release Descriptor Core Skeleton
// In-memory first controlled filesystem mutation release descriptor engine.
// Layer 40 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply + mutation-surface +
//   filesystem-mutation-enablement + filesystem-mutation-gate +
//   filesystem-mutation-permit + filesystem-mutation-authorization +
//   filesystem-mutation-approval + filesystem-mutation-grant +
//   filesystem-mutation-final-approval stack.
// Defines the first controlled filesystem mutation release descriptor.
// Binds release to filesystem mutation final approval and to grant/approval/authorization/permit chain.
// Preserves sandbox-approved-only target scope from layers 24–39 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem mutation. No shell execution. No network access.
// No vault access. No Mother Core mutation.
// filesystemMutationReleaseEnabled=false — release has not been enabled.
// filesystemMutationReleasePrepared=true — descriptor-readiness established for a future
//   first controlled filesystem mutation release activation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstControlledFilesystemMutationFinalApprovalRecord } from "./firstControlledFilesystemMutationFinalApprovalCore.js";
import type { FirstControlledFilesystemMutationGrantRecord }         from "./firstControlledFilesystemMutationGrantCore.js";
import type { FirstControlledFilesystemMutationApprovalRecord }      from "./firstControlledFilesystemMutationApprovalCore.js";
import type { FirstControlledFilesystemMutationAuthorizationRecord } from "./firstControlledFilesystemMutationAuthorizationCore.js";
import type { FirstControlledFilesystemMutationPermitRecord }        from "./firstControlledFilesystemMutationPermitCore.js";
import type { ControlledExecutionRecord }                            from "./controlledExecutionCore.js";
import { randomUUID }                                                from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FilesystemMutationReleaseState =
  "descriptor_filesystem_mutation_release_pending";

export type FilesystemMutationReleaseCheckRule =
  | "release_still_disabled"
  | "final_approval_bound_to_grant"
  | "grant_bound_to_approval"
  | "approval_bound_to_authorization"
  | "authorization_bound_to_permit"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface FilesystemMutationReleaseCheck {
  readonly rule: FilesystemMutationReleaseCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface FilesystemMutationReleaseBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface FilesystemMutationReleasePlanEntry {
  readonly entryId:                         string;
  readonly operationType:                   "descriptor_filesystem_mutation_release_planned";
  readonly targetScope:                     "sandbox_approved_only";
  readonly filesystemMutationReleaseEnabled: false;
  readonly mutationBlocked:                 true;
  readonly note:                            string;
}

export interface LinkedFilesystemMutationReleaseReference {
  readonly filesystemMutationFinalApprovalId:   string;
  readonly filesystemMutationGrantId:           string;
  readonly filesystemMutationApprovalId:        string;
  readonly filesystemMutationAuthorizationId:   string;
  readonly rollbackSnapshotId:                  string;
  readonly filesystemMutationReleasePrepared:   true;
  readonly filesystemMutationReleaseEnabled:    false;
  readonly filesystemMutationFinalApprovalGranted: false;
  readonly filesystemMutationGrantEnabled:      false;
  readonly filesystemMutationApprovalGranted:   false;
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly filesystemMutationPermitEnabled:     false;
  readonly actualWritesEnabled:                 false;
  readonly rollbackChainValid:                  boolean;
  readonly referenceNote:                       string;
}

export interface FilesystemMutationReleaseReadinessReport {
  readonly filesystemMutationReleasePrepared:      true;
  readonly filesystemMutationReleaseEnabled:       false;
  readonly filesystemMutationFinalApprovalGranted: false;
  readonly filesystemMutationGrantEnabled:         false;
  readonly filesystemMutationApprovalGranted:      false;
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly filesystemMutationPermitEnabled:        false;
  readonly filesystemMutationGateEnabled:          false;
  readonly filesystemMutationEnablementEnabled:    false;
  readonly mutationSurfaceEnabled:                 false;
  readonly mutationApplyEnabled:                   false;
  readonly mutationCommitEnabled:                  false;
  readonly mutationExecutorEnabled:                false;
  readonly commitExecutionGateEnabled:             false;
  readonly sandboxWriteCommitEnabled:              false;
  readonly runtimeWriteExecutorEnabled:            false;
  readonly writeExecutionGateEnabled:              false;
  readonly scopedActivationEnabled:                false;
  readonly writePermissionEnabled:                 false;
  readonly mutationSwitchEnabled:                  false;
  readonly guardedWriteEnabled:                    false;
  readonly actualWritesEnabled:                    false;
  readonly realWritesEnabled:                      false;
  readonly approvalRequired:                       true;
  readonly allChecksPass:                          boolean;
  readonly blockedReasonCount:                     number;
  readonly rollbackChainValid:                     boolean;
  readonly targetScope:                            "sandbox_approved_only";
  readonly summary:                                string;
}

export interface FirstControlledFilesystemMutationReleaseRecord {
  readonly filesystemMutationReleaseId:              string;
  readonly filesystemMutationReleaseState:           FilesystemMutationReleaseState;
  readonly approvalRequired:                         true;
  readonly filesystemMutationReleasePrepared:        true;
  readonly filesystemMutationReleaseEnabled:         false;
  readonly filesystemMutationFinalApprovalGranted:   false;
  readonly filesystemMutationGrantEnabled:           false;
  readonly filesystemMutationApprovalGranted:        false;
  readonly filesystemMutationAuthorizationEnabled:   false;
  readonly filesystemMutationPermitEnabled:          false;
  readonly actualWritesEnabled:                      false;
  readonly filesystemMutationBlocked:                true;
  readonly motherCoreMutationBlocked:                true;
  readonly vaultMutationBlocked:                     true;
  readonly shellBlocked:                             true;
  readonly networkBlocked:                           true;
  readonly targetScope:                              "sandbox_approved_only";
  readonly implementationPhase:                      "descriptor_only";
  readonly filesystemMutationFinalApprovalId:        string;
  readonly filesystemMutationGrantId:                string;
  readonly filesystemMutationApprovalId:             string;
  readonly filesystemMutationAuthorizationId:        string;
  readonly filesystemMutationPermitId:               string;
  readonly controlledExecutionId:                    string;
  readonly filesystemMutationReleasePlan:            readonly FilesystemMutationReleasePlanEntry[];
  readonly filesystemMutationReleaseChecks:          readonly FilesystemMutationReleaseCheck[];
  readonly filesystemMutationReleaseBlockedReasons:  readonly FilesystemMutationReleaseBlockedReason[];
  readonly filesystemMutationReleaseReadinessReport: FilesystemMutationReleaseReadinessReport;
  readonly linkedFilesystemMutationReleaseReference: LinkedFilesystemMutationReleaseReference;
  readonly createdAt:                                string;
}

export interface CreateFirstControlledFilesystemMutationReleaseInput {
  readonly finalApprovalRecord: FirstControlledFilesystemMutationFinalApprovalRecord;
  readonly grantRecord:         FirstControlledFilesystemMutationGrantRecord;
  readonly approvalRecord:      FirstControlledFilesystemMutationApprovalRecord;
  readonly authorizationRecord: FirstControlledFilesystemMutationAuthorizationRecord;
  readonly permitRecord:        FirstControlledFilesystemMutationPermitRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface FirstControlledFilesystemMutationReleaseSummary {
  readonly total:                                    number;
  readonly byState:                                  Record<FilesystemMutationReleaseState, number>;
  readonly filesystemMutationReleasePrepared:        true;
  readonly filesystemMutationReleaseEnabled:         false;
  readonly filesystemMutationFinalApprovalGranted:   false;
  readonly filesystemMutationGrantEnabled:           false;
  readonly filesystemMutationApprovalGranted:        false;
  readonly filesystemMutationAuthorizationEnabled:   false;
  readonly filesystemMutationPermitEnabled:          false;
  readonly actualWritesEnabled:                      false;
  readonly approvalRequired:                         true;
  readonly filesystemMutationBlocked:                true;
  readonly motherCoreMutationBlocked:                true;
  readonly targetScope:                              "sandbox_approved_only";
  readonly filesystemMutationReleaseState:           FilesystemMutationReleaseState;
  readonly implementationPhase:                      "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstControlledFilesystemMutationReleaseRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstControlledFilesystemMutationReleaseInput,
): readonly FilesystemMutationReleaseCheck[] {
  const { finalApprovalRecord, grantRecord, approvalRecord, authorizationRecord, permitRecord } = input;

  const finalApprovalBound  = finalApprovalRecord.filesystemMutationGrantId === grantRecord.filesystemMutationGrantId;
  const grantBound          = grantRecord.filesystemMutationApprovalId === approvalRecord.filesystemMutationApprovalId;
  const approvalBound       = approvalRecord.filesystemMutationAuthorizationId === authorizationRecord.filesystemMutationAuthorizationId;
  const authorizationBound  = authorizationRecord.filesystemMutationPermitId === permitRecord.filesystemMutationPermitId;

  return [
    {
      rule: "release_still_disabled",
      pass: true,
      note: "filesystemMutationReleaseEnabled=false — compile-time literal; no filesystem mutation release activation phase has been started",
    },
    {
      rule: "final_approval_bound_to_grant",
      pass: finalApprovalBound,
      note: finalApprovalBound
        ? `finalApprovalRecord.filesystemMutationGrantId === grantRecord.filesystemMutationGrantId (${grantRecord.filesystemMutationGrantId})`
        : `final-approval/grant mismatch: finalApproval.filesystemMutationGrantId=${finalApprovalRecord.filesystemMutationGrantId} vs grant.filesystemMutationGrantId=${grantRecord.filesystemMutationGrantId}`,
    },
    {
      rule: "grant_bound_to_approval",
      pass: grantBound,
      note: grantBound
        ? `grantRecord.filesystemMutationApprovalId === approvalRecord.filesystemMutationApprovalId (${approvalRecord.filesystemMutationApprovalId})`
        : `grant/approval mismatch: grant.filesystemMutationApprovalId=${grantRecord.filesystemMutationApprovalId} vs approval.filesystemMutationApprovalId=${approvalRecord.filesystemMutationApprovalId}`,
    },
    {
      rule: "approval_bound_to_authorization",
      pass: approvalBound,
      note: approvalBound
        ? `approvalRecord.filesystemMutationAuthorizationId === authorizationRecord.filesystemMutationAuthorizationId (${authorizationRecord.filesystemMutationAuthorizationId})`
        : `approval/authorization mismatch: approval.filesystemMutationAuthorizationId=${approvalRecord.filesystemMutationAuthorizationId} vs authorization.filesystemMutationAuthorizationId=${authorizationRecord.filesystemMutationAuthorizationId}`,
    },
    {
      rule: "authorization_bound_to_permit",
      pass: authorizationBound,
      note: authorizationBound
        ? `authorizationRecord.filesystemMutationPermitId === permitRecord.filesystemMutationPermitId (${permitRecord.filesystemMutationPermitId})`
        : `authorization/permit mismatch: authorization.filesystemMutationPermitId=${authorizationRecord.filesystemMutationPermitId} vs permit.filesystemMutationPermitId=${permitRecord.filesystemMutationPermitId}`,
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "filesystemMutationReleaseState=descriptor_filesystem_mutation_release_pending — output is a descriptor only; filesystem mutation release is not yet enabled",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly FilesystemMutationReleaseCheck[],
): readonly FilesystemMutationReleaseBlockedReason[] {
  const staticReasons: FilesystemMutationReleaseBlockedReason[] = [
    { code: "filesystem_mutation_release_disabled", reason: "filesystemMutationReleaseEnabled=false — compile-time literal; an explicit first controlled filesystem mutation release activation phase must enable the release before any sandbox target can receive filesystem writes",                                                                                                                                                                                                                                                                                                                                                                              static: true },
    { code: "approval_required",                    reason: "approvalRequired=true — explicit operator approval is required before the filesystem mutation release can be enabled",                                                                                                                                                                                                                                                                                                                                                                                                                                                                               static: true },
    { code: "actual_writes_disabled",               reason: "actualWritesEnabled=false — compile-time literal across all 40 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, mutation-apply, mutation-surface, filesystem-mutation-enablement, filesystem-mutation-gate, filesystem-mutation-permit, filesystem-mutation-authorization, filesystem-mutation-approval, filesystem-mutation-grant, and filesystem-mutation-final-approval layers", static: true },
  ];
  const dynamicReasons: FilesystemMutationReleaseBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedReleaseReference(
  input: CreateFirstControlledFilesystemMutationReleaseInput,
  rollbackChainValid: boolean,
): LinkedFilesystemMutationReleaseReference {
  const { finalApprovalRecord, grantRecord, approvalRecord, authorizationRecord } = input;
  return {
    filesystemMutationFinalApprovalId:    finalApprovalRecord.filesystemMutationFinalApprovalId,
    filesystemMutationGrantId:            grantRecord.filesystemMutationGrantId,
    filesystemMutationApprovalId:         approvalRecord.filesystemMutationApprovalId,
    filesystemMutationAuthorizationId:    authorizationRecord.filesystemMutationAuthorizationId,
    rollbackSnapshotId:                   finalApprovalRecord.linkedFilesystemMutationFinalApprovalReference.rollbackSnapshotId,
    filesystemMutationReleasePrepared:    true,
    filesystemMutationReleaseEnabled:     false,
    filesystemMutationFinalApprovalGranted: false,
    filesystemMutationGrantEnabled:       false,
    filesystemMutationApprovalGranted:    false,
    filesystemMutationAuthorizationEnabled: false,
    filesystemMutationPermitEnabled:      false,
    actualWritesEnabled:                  false,
    rollbackChainValid,
    referenceNote: "linked filesystem mutation release reference sources rollbackSnapshotId from finalApprovalRecord.linkedFilesystemMutationFinalApprovalReference; filesystem mutation release disabled; filesystem mutation final approval not granted; filesystem mutation grant disabled; filesystem mutation approval not granted; filesystem mutation authorization disabled; filesystem mutation permit disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstControlledFilesystemMutationReleaseRecord(
  input: CreateFirstControlledFilesystemMutationReleaseInput,
): FirstControlledFilesystemMutationReleaseRecord {
  const { finalApprovalRecord, grantRecord, approvalRecord, authorizationRecord, permitRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = finalApprovalRecord.filesystemMutationFinalApprovalReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedReleaseReference(input, rollbackChainValid);

  const filesystemMutationReleasePlan: FilesystemMutationReleasePlanEntry[] = [
    {
      entryId:                          randomUUID(),
      operationType:                    "descriptor_filesystem_mutation_release_planned",
      targetScope:                      "sandbox_approved_only",
      filesystemMutationReleaseEnabled: false,
      mutationBlocked:                  true,
      note:                             "filesystem mutation release planned in descriptor-only mode; targetScope=sandbox_approved_only; filesystemMutationReleaseEnabled=false; filesystemMutationBlocked=true; first controlled filesystem mutation release activation phase required to enable",
    },
  ];

  const filesystemMutationReleaseReadinessReport: FilesystemMutationReleaseReadinessReport = {
    filesystemMutationReleasePrepared:      true,
    filesystemMutationReleaseEnabled:       false,
    filesystemMutationFinalApprovalGranted: false,
    filesystemMutationGrantEnabled:         false,
    filesystemMutationApprovalGranted:      false,
    filesystemMutationAuthorizationEnabled: false,
    filesystemMutationPermitEnabled:        false,
    filesystemMutationGateEnabled:          false,
    filesystemMutationEnablementEnabled:    false,
    mutationSurfaceEnabled:                 false,
    mutationApplyEnabled:                   false,
    mutationCommitEnabled:                  false,
    mutationExecutorEnabled:                false,
    commitExecutionGateEnabled:             false,
    sandboxWriteCommitEnabled:              false,
    runtimeWriteExecutorEnabled:            false,
    writeExecutionGateEnabled:              false,
    scopedActivationEnabled:                false,
    writePermissionEnabled:                 false,
    mutationSwitchEnabled:                  false,
    guardedWriteEnabled:                    false,
    actualWritesEnabled:                    false,
    realWritesEnabled:                      false,
    approvalRequired:                       true,
    allChecksPass,
    blockedReasonCount:                     blockedReasons.length,
    rollbackChainValid,
    targetScope:                            "sandbox_approved_only",
    summary: `filesystemMutationReleaseState=descriptor_filesystem_mutation_release_pending; filesystemMutationReleaseEnabled=false; filesystemMutationFinalApprovalGranted=false; filesystemMutationGrantEnabled=false; filesystemMutationApprovalGranted=false; filesystemMutationAuthorizationEnabled=false; filesystemMutationPermitEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstControlledFilesystemMutationReleaseRecord = {
    filesystemMutationReleaseId:              randomUUID(),
    filesystemMutationReleaseState:           "descriptor_filesystem_mutation_release_pending",
    approvalRequired:                         true,
    filesystemMutationReleasePrepared:        true,
    filesystemMutationReleaseEnabled:         false,
    filesystemMutationFinalApprovalGranted:   false,
    filesystemMutationGrantEnabled:           false,
    filesystemMutationApprovalGranted:        false,
    filesystemMutationAuthorizationEnabled:   false,
    filesystemMutationPermitEnabled:          false,
    actualWritesEnabled:                      false,
    filesystemMutationBlocked:                true,
    motherCoreMutationBlocked:                true,
    vaultMutationBlocked:                     true,
    shellBlocked:                             true,
    networkBlocked:                           true,
    targetScope:                              "sandbox_approved_only",
    implementationPhase:                      "descriptor_only",
    filesystemMutationFinalApprovalId:        finalApprovalRecord.filesystemMutationFinalApprovalId,
    filesystemMutationGrantId:                grantRecord.filesystemMutationGrantId,
    filesystemMutationApprovalId:             approvalRecord.filesystemMutationApprovalId,
    filesystemMutationAuthorizationId:        authorizationRecord.filesystemMutationAuthorizationId,
    filesystemMutationPermitId:               permitRecord.filesystemMutationPermitId,
    controlledExecutionId:                    executionRecord.controlledExecutionId,
    filesystemMutationReleasePlan,
    filesystemMutationReleaseChecks:          checks,
    filesystemMutationReleaseBlockedReasons:  blockedReasons,
    filesystemMutationReleaseReadinessReport,
    linkedFilesystemMutationReleaseReference: linkedRef,
    createdAt:                                new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstControlledFilesystemMutationReleaseRecords(): readonly FirstControlledFilesystemMutationReleaseRecord[] {
  return _store.slice();
}

export function getFirstControlledFilesystemMutationReleaseSummary(): FirstControlledFilesystemMutationReleaseSummary {
  return {
    total:                                     _store.length,
    byState:                                   { descriptor_filesystem_mutation_release_pending: _store.length },
    filesystemMutationReleasePrepared:         true,
    filesystemMutationReleaseEnabled:          false,
    filesystemMutationFinalApprovalGranted:    false,
    filesystemMutationGrantEnabled:            false,
    filesystemMutationApprovalGranted:         false,
    filesystemMutationAuthorizationEnabled:    false,
    filesystemMutationPermitEnabled:           false,
    actualWritesEnabled:                       false,
    approvalRequired:                          true,
    filesystemMutationBlocked:                 true,
    motherCoreMutationBlocked:                 true,
    targetScope:                               "sandbox_approved_only",
    filesystemMutationReleaseState:            "descriptor_filesystem_mutation_release_pending",
    implementationPhase:                       "descriptor_only",
  };
}
