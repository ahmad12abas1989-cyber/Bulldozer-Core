import { ActualSandboxWriteApprovalTokenRecord } from "./actualSandboxWriteApprovalTokenCore.js";
import { ActualSandboxWriteDryRunRecord }         from "./actualSandboxWriteDryRunCore.js";
import { ActualSandboxWriteEnablementRecord }     from "./actualSandboxWriteEnablementCore.js";
import { SandboxWriteCommitGateRecord }           from "./sandboxWriteCommitGateCore.js";
import { ControlledExecutionRecord }              from "./controlledExecutionCore.js";
import { randomBytes }                            from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type PreflightState = "descriptor_preflight_ready";

export type PreflightCheckRule =
  | "approval_token_exists"
  | "dry_run_exists"
  | "enablement_record_exists"
  | "commit_gate_exists"
  | "execution_record_exists"
  | "approval_token_bound"
  | "dry_run_ready"
  | "enablement_ready"
  | "commit_gate_ready"
  | "approval_not_granted_yet"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface PreflightCheck {
  readonly rule:   PreflightCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface PreflightBlockedReason {
  readonly reason:    string;
  readonly permanent: boolean;
}

export interface LinkedApprovalReference {
  readonly approvalTokenId:        string;
  readonly rollbackSnapshotId:     string;
  readonly commitGateId:           string;
  readonly approvalGranted:        false;
  readonly approvalRequired:       true;
  readonly rollbackBound:          boolean;
  readonly rollbackReady:          boolean;
  readonly referenceNote:          string;
}

export interface PreflightReadinessReport {
  readonly preflightPassed:        false;
  readonly finalWriteAllowed:      false;
  readonly approvalRequired:       true;
  readonly actualWritesEnabled:    false;
  readonly allChecksPass:          boolean;
  readonly blockedReasonCount:     number;
  readonly rollbackReady:          boolean;
  readonly summary:                string;
}

export interface ActualSandboxWritePreflightRecord {
  readonly preflightId:                string;
  readonly preflightState:             PreflightState;
  readonly approvalRequired:           true;
  readonly preflightPassed:            false;
  readonly actualWritesEnabled:        false;
  readonly finalWriteAllowed:          false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly implementationPhase:        "descriptor_only";
  readonly approvalTokenId:            string;
  readonly dryRunId:                   string;
  readonly actualWriteEnablementId:    string;
  readonly commitGateId:               string;
  readonly executionRecordId:          string;
  readonly preflightChecks:            readonly PreflightCheck[];
  readonly preflightBlockedReasons:    readonly PreflightBlockedReason[];
  readonly preflightReadinessReport:   PreflightReadinessReport;
  readonly linkedApprovalReference:    LinkedApprovalReference;
  readonly createdAt:                  string;
}

export interface CreatePreflightInput {
  readonly approvalTokenRecord: ActualSandboxWriteApprovalTokenRecord;
  readonly dryRunRecord:        ActualSandboxWriteDryRunRecord;
  readonly enablementRecord:    ActualSandboxWriteEnablementRecord;
  readonly commitGateRecord:    SandboxWriteCommitGateRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface ActualSandboxWritePreflightSummary {
  readonly total:                      number;
  readonly byState:                    Record<PreflightState, number>;
  readonly preflightPassed:            false;
  readonly finalWriteAllowed:          false;
  readonly approvalRequired:           true;
  readonly actualWritesEnabled:        false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildPreflightChecks(
  input: CreatePreflightInput,
): readonly PreflightCheck[] {
  const { approvalTokenRecord, dryRunRecord, enablementRecord, commitGateRecord, executionRecord } = input;

  const approvalBound =
    approvalTokenRecord.approvalTokenId.length > 0 &&
    approvalTokenRecord.dryRunId === dryRunRecord.dryRunId;

  const dryRunReady       = dryRunRecord.dryRunReadinessReport.allChecksPass;
  const enablementReady   = enablementRecord.enablementReadinessReport.allChecksPass;
  const commitGateReady   = commitGateRecord.commitReadinessReport.allEligibilityChecksPassed;

  const rollbackReady =
    approvalTokenRecord.approvalReadinessReport.rollbackReady &&
    dryRunRecord.dryRunReadinessReport.rollbackReady &&
    enablementRecord.enablementReadinessReport.rollbackReady &&
    commitGateRecord.commitReadinessReport.rollbackReady;

  return [
    {
      rule:   "approval_token_exists",
      passed: approvalTokenRecord.approvalTokenId.length > 0,
      detail: "Approval token record is present and valid",
    },
    {
      rule:   "dry_run_exists",
      passed: dryRunRecord.dryRunId.length > 0,
      detail: "Dry-run record is present and valid",
    },
    {
      rule:   "enablement_record_exists",
      passed: enablementRecord.actualWriteEnablementId.length > 0,
      detail: "Actual write enablement record is present and valid",
    },
    {
      rule:   "commit_gate_exists",
      passed: commitGateRecord.commitGateId.length > 0,
      detail: "Commit gate record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "approval_token_bound",
      passed: approvalBound,
      detail: approvalBound
        ? `Approval token bound to dry-run — approvalTokenId=${approvalTokenRecord.approvalTokenId.slice(0, 8)}… dryRunId match confirmed`
        : "Approval token dryRunId does not match the provided dry-run record — preflight blocked",
    },
    {
      rule:   "dry_run_ready",
      passed: dryRunReady,
      detail: dryRunReady
        ? "Dry-run allChecksPass=true — dry-run layer is complete and ready for preflight"
        : "Dry-run checks have not all passed — preflight blocked until dry run is ready",
    },
    {
      rule:   "enablement_ready",
      passed: enablementReady,
      detail: enablementReady
        ? "Enablement allChecksPass=true — actual write enablement layer is ready for preflight"
        : "Enablement checks have not all passed — preflight blocked until enablement is ready",
    },
    {
      rule:   "commit_gate_ready",
      passed: commitGateReady,
      detail: commitGateReady
        ? "Commit gate allEligibilityChecksPassed=true — commit gate layer is ready for preflight"
        : "Commit gate eligibility checks have not all passed — preflight blocked",
    },
    {
      rule:   "approval_not_granted_yet",
      passed: true,
      detail: "approvalGranted=false confirmed — preflight is in descriptor-only state; actual approval requires explicit operator action in a future execution phase",
    },
    {
      rule:   "actual_writes_still_disabled",
      passed: true,
      detail: "actualWritesEnabled=false confirmed — no real filesystem writes occur during preflight",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback readiness confirmed across all 4 upstream records — preflight output is a valid descriptor"
        : "Rollback readiness not fully confirmed across upstream records — preflight descriptor blocked",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly PreflightCheck[],
): readonly PreflightBlockedReason[] {
  const static_: readonly PreflightBlockedReason[] = [
    {
      reason:    "preflightPassed=false — preflight descriptor confirms no actual write is permitted in this phase",
      permanent: false,
    },
    {
      reason:    "approvalRequired=true — explicit operator approval must be granted in a future execution phase before any actual write",
      permanent: false,
    },
    {
      reason:    "actualWritesEnabled=false — compile-time literal; no real filesystem mutation occurs at any preflight phase",
      permanent: false,
    },
  ];

  const dynamic = checks
    .filter(c => !c.passed)
    .map(c => ({
      reason:    `Check failed: ${c.rule} — ${c.detail}`,
      permanent: false,
    }));

  return [...static_, ...dynamic];
}

function buildLinkedApprovalReference(
  input: CreatePreflightInput,
  checks: readonly PreflightCheck[],
): LinkedApprovalReference {
  const rollbackReady = checks.every(c => c.passed);
  return {
    approvalTokenId:    input.approvalTokenRecord.approvalTokenId,
    rollbackSnapshotId: input.approvalTokenRecord.linkedRollbackReference.rollbackSnapshotId,
    commitGateId:       input.commitGateRecord.commitGateId,
    approvalGranted:    false,
    approvalRequired:   true,
    rollbackBound:      input.approvalTokenRecord.linkedRollbackReference.rollbackBound,
    rollbackReady,
    referenceNote: rollbackReady
      ? "Preflight is linked to a valid approval token, rollback snapshot, and commit gate — all upstream preflight references confirmed"
      : "Preflight approval reference incomplete — all checks must pass before the preflight is considered rollback-ready",
  };
}

function buildReadinessReport(
  checks: readonly PreflightCheck[],
  blocked: readonly PreflightBlockedReason[],
): PreflightReadinessReport {
  const allChecksPass = checks.every(c => c.passed);
  const rollbackCheck = checks.find(c => c.rule === "output_remains_descriptor_only");
  const rollbackReady = rollbackCheck?.passed ?? false;
  return {
    preflightPassed:      false,
    finalWriteAllowed:    false,
    approvalRequired:     true,
    actualWritesEnabled:  false,
    allChecksPass,
    blockedReasonCount:   blocked.length,
    rollbackReady,
    summary: allChecksPass
      ? `Final preflight descriptor ready — all 12 checks passed across 5 upstream layers, rollback binding confirmed; preflightPassed=false and finalWriteAllowed=false in this phase; actual writes require explicit operator approval in a future execution phase`
      : `Final preflight blocked — ${blocked.length - 3} dynamic check(s) failed in addition to the 3 permanent blocked reasons; no actual writes will occur`,
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const preflightStore = new Map<string, ActualSandboxWritePreflightRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createPreflightRecord(
  input: CreatePreflightInput,
): { ok: true; record: ActualSandboxWritePreflightRecord } {
  const preflightId = randomBytes(16).toString("hex");
  const checks      = buildPreflightChecks(input);
  const blocked     = buildBlockedReasons(checks);
  const linked      = buildLinkedApprovalReference(input, checks);
  const report      = buildReadinessReport(checks, blocked);

  const record: ActualSandboxWritePreflightRecord = {
    preflightId,
    preflightState:            "descriptor_preflight_ready",
    approvalRequired:          true,
    preflightPassed:           false,
    actualWritesEnabled:       false,
    finalWriteAllowed:         false,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
    implementationPhase:       "descriptor_only",
    approvalTokenId:           input.approvalTokenRecord.approvalTokenId,
    dryRunId:                  input.dryRunRecord.dryRunId,
    actualWriteEnablementId:   input.enablementRecord.actualWriteEnablementId,
    commitGateId:              input.commitGateRecord.commitGateId,
    executionRecordId:         input.executionRecord.controlledExecutionId,
    preflightChecks:           checks,
    preflightBlockedReasons:   blocked,
    preflightReadinessReport:  report,
    linkedApprovalReference:   linked,
    createdAt:                 new Date().toISOString(),
  };

  preflightStore.set(preflightId, record);
  return { ok: true, record };
}

export function listPreflightRecords(): readonly ActualSandboxWritePreflightRecord[] {
  return [...preflightStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getPreflightSummary(): ActualSandboxWritePreflightSummary {
  const records = listPreflightRecords();
  return {
    total:                     records.length,
    byState:                   { descriptor_preflight_ready: records.length },
    preflightPassed:           false,
    finalWriteAllowed:         false,
    approvalRequired:          true,
    actualWritesEnabled:       false,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
  };
}
