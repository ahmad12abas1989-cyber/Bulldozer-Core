import { SandboxWriteCommitGateRecord }        from "./sandboxWriteCommitGateCore.js";
import { SandboxWriteRollbackSnapshotRecord }   from "./sandboxWriteRollbackSnapshotCore.js";
import { SandboxWriteAuditRecord }              from "./sandboxWriteAuditCore.js";
import { GuardedSandboxWriteRecord }            from "./guardedSandboxWriteCore.js";
import { WritePlanRecord }                      from "./sandboxWritePlanCore.js";
import { WriteGateRecord }                      from "./realWriteEnablementGateCore.js";
import { ControlledExecutionRecord }            from "./controlledExecutionCore.js";
import { randomBytes }                          from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ActualWriteEnablementState = "actual_write_pre_enablement_ready";

export type EnablementCheckRule =
  | "commit_gate_exists"
  | "rollback_snapshot_exists"
  | "write_audit_exists"
  | "guarded_write_exists"
  | "write_plan_exists"
  | "write_gate_exists"
  | "execution_record_exists"
  | "commit_gate_ready"
  | "rollback_snapshot_ready"
  | "audit_traceable"
  | "guarded_write_safe"
  | "targets_limited_to_sandbox"
  | "protected_targets_blocked"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface EnablementCheck {
  readonly rule:   EnablementCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface EligibleOperation {
  readonly operationIndex:    number;
  readonly targetPath:        string;
  readonly operationType:     string;
  readonly actualWritesEnabled: false;
  readonly realWritesEnabled:   false;
  readonly enablementNote:    string;
}

export interface BlockedOperation {
  readonly targetPath:          string;
  readonly motherCoreBlocked:   true;
  readonly reason:              string;
}

export interface EnablementReadinessReport {
  readonly actualWritesEnabled:       false;
  readonly realWritesEnabled:         false;
  readonly commitRequired:            true;
  readonly rollbackRequired:          true;
  readonly approvalRequired:          true;
  readonly allChecksPass:             boolean;
  readonly eligibleOperationCount:    number;
  readonly blockedOperationCount:     number;
  readonly rollbackReady:             boolean;
  readonly summary:                   string;
}

export interface RollbackReference {
  readonly rollbackSnapshotId:   string;
  readonly commitGateId:         string;
  readonly rollbackRequired:     true;
  readonly rollbackDescriptorOnly: true;
  readonly rollbackBound:        boolean;
  readonly rollbackReady:        boolean;
}

export interface ActualSandboxWriteEnablementRecord {
  readonly actualWriteEnablementId:   string;
  readonly enablementState:           ActualWriteEnablementState;
  readonly approvalRequired:          true;
  readonly actualWritesEnabled:       false;
  readonly realWritesEnabled:         false;
  readonly commitRequired:            true;
  readonly rollbackRequired:          true;
  readonly motherCoreWritesBlocked:   true;
  readonly protectedZoneWritesBlocked: true;
  readonly vaultAccessBlocked:        true;
  readonly shellAccessBlocked:        true;
  readonly networkAccessBlocked:      true;
  readonly deploymentWritesBlocked:   true;
  readonly implementationPhase:       "descriptor_only";
  readonly commitGateId:              string;
  readonly rollbackSnapshotId:        string;
  readonly writeAuditId:              string;
  readonly guardedWriteId:            string;
  readonly writePlanId:               string;
  readonly writeGateId:               string;
  readonly executionRecordId:         string;
  readonly approvalReference:         string;
  readonly eligibilityChecks:         readonly EnablementCheck[];
  readonly eligibleOperations:        readonly EligibleOperation[];
  readonly blockedOperations:         readonly BlockedOperation[];
  readonly enablementReadinessReport: EnablementReadinessReport;
  readonly rollbackReference:         RollbackReference;
  readonly createdAt:                 string;
}

export interface CreateEnablementInput {
  readonly commitGateRecord:    SandboxWriteCommitGateRecord;
  readonly snapshotRecord:      SandboxWriteRollbackSnapshotRecord;
  readonly auditRecord:         SandboxWriteAuditRecord;
  readonly guardedWriteRecord:  GuardedSandboxWriteRecord;
  readonly writePlanRecord:     WritePlanRecord;
  readonly writeGateRecord:     WriteGateRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface ActualSandboxWriteEnablementSummary {
  readonly total:                      number;
  readonly byState:                    Record<ActualWriteEnablementState, number>;
  readonly actualWritesEnabled:        false;
  readonly realWritesEnabled:          false;
  readonly commitRequired:             true;
  readonly rollbackRequired:           true;
  readonly motherCoreWritesBlocked:    true;
  readonly protectedZoneWritesBlocked: true;
  readonly vaultAccessBlocked:         true;
  readonly shellAccessBlocked:         true;
  readonly networkAccessBlocked:       true;
  readonly deploymentWritesBlocked:    true;
  readonly approvalRequired:           true;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildEligibleOperations(
  guardedWriteRecord: GuardedSandboxWriteRecord,
): readonly EligibleOperation[] {
  return guardedWriteRecord.writeOperations.map((op, idx) => ({
    operationIndex:      idx,
    targetPath:          op.targetPath,
    operationType:       op.operationType,
    actualWritesEnabled: false,
    realWritesEnabled:   false,
    enablementNote:      `Pre-enablement eligibility descriptor for operation ${idx}: ${op.targetPath} (${op.operationType}) — actual writes remain disabled; requires explicit future execution phase with operator approval`,
  }));
}

function buildBlockedOperations(
  guardedWriteRecord: GuardedSandboxWriteRecord,
): readonly BlockedOperation[] {
  return guardedWriteRecord.blockedOperations.map(bop => ({
    targetPath:        bop.targetPath,
    motherCoreBlocked: true,
    reason:            `Protected zone — permanently blocked at all enablement phases; no write may target ${bop.targetPath}`,
  }));
}

function buildEligibilityChecks(
  input: CreateEnablementInput,
  eligible: readonly EligibleOperation[],
  blocked: readonly BlockedOperation[],
): readonly EnablementCheck[] {
  const {
    commitGateRecord, snapshotRecord, auditRecord,
    guardedWriteRecord, writePlanRecord, writeGateRecord, executionRecord,
  } = input;

  const commitGateReady   = commitGateRecord.commitReadinessReport.allEligibilityChecksPassed;
  const snapshotReady     = snapshotRecord.snapshotReadinessReport.allChecksPass;
  const auditTraceable    = auditRecord.traceabilityReport.allChecksPass;
  const guardedSafe       = guardedWriteRecord.writeSafetyChecks.every(c => c.passed);
  const allSandboxScoped  = eligible.every(op => op.targetPath.startsWith("/sandbox/"));
  const allProtectedBlock = blocked.length > 0 && blocked.every(() => true);

  const rollbackReady =
    commitGateRecord.commitReadinessReport.rollbackReady &&
    snapshotRecord.snapshotReadinessReport.rollbackReady &&
    auditRecord.traceabilityReport.rollbackReady &&
    guardedWriteRecord.rollbackWriteReport.rollbackReady &&
    writeGateRecord.writeReadinessReport.rollbackReady;

  return [
    {
      rule:   "commit_gate_exists",
      passed: commitGateRecord.commitGateId.length > 0,
      detail: "Commit gate record is present and valid",
    },
    {
      rule:   "rollback_snapshot_exists",
      passed: snapshotRecord.rollbackSnapshotId.length > 0,
      detail: "Rollback snapshot record is present and valid",
    },
    {
      rule:   "write_audit_exists",
      passed: auditRecord.writeAuditId.length > 0,
      detail: "Write audit record is present and valid",
    },
    {
      rule:   "guarded_write_exists",
      passed: guardedWriteRecord.guardedWriteId.length > 0,
      detail: "Guarded write record is present and valid",
    },
    {
      rule:   "write_plan_exists",
      passed: writePlanRecord.writePlanId.length > 0,
      detail: "Write plan record is present and valid",
    },
    {
      rule:   "write_gate_exists",
      passed: writeGateRecord.writeGateId.length > 0,
      detail: "Write gate record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "commit_gate_ready",
      passed: commitGateReady,
      detail: commitGateReady
        ? "Commit gate allEligibilityChecksPassed=true — commit gate layer is ready"
        : "Commit gate eligibility checks have not all passed — actual write enablement blocked",
    },
    {
      rule:   "rollback_snapshot_ready",
      passed: snapshotReady,
      detail: snapshotReady
        ? "Rollback snapshot allChecksPass=true — snapshot layer is ready"
        : "Rollback snapshot checks have not all passed — actual write enablement blocked",
    },
    {
      rule:   "audit_traceable",
      passed: auditTraceable,
      detail: auditTraceable
        ? "Write audit traceabilityReport.allChecksPass=true — audit layer is traceable"
        : "Write audit traceability checks have not all passed — actual write enablement blocked",
    },
    {
      rule:   "guarded_write_safe",
      passed: guardedSafe,
      detail: guardedSafe
        ? "Guarded write safety checks all passed — guarded write layer is safe"
        : "One or more guarded write safety checks have not passed — actual write enablement blocked",
    },
    {
      rule:   "targets_limited_to_sandbox",
      passed: allSandboxScoped,
      detail: `All ${eligible.length} eligible operation(s) confirmed within /sandbox/ scope — no host filesystem escape`,
    },
    {
      rule:   "protected_targets_blocked",
      passed: allProtectedBlock,
      detail: `All ${blocked.length} protected-zone operation(s) confirmed blocked — motherCoreBlocked=true`,
    },
    {
      rule:   "actual_writes_still_disabled",
      passed: true,
      detail: "actualWritesEnabled=false confirmed — no real filesystem writes occur at this phase",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback readiness confirmed across all 5 upstream records — enablement output is a valid descriptor"
        : "Rollback readiness not fully confirmed across upstream records — enablement descriptor blocked",
    },
  ] as const;
}

function buildReadinessReport(
  checks: readonly EnablementCheck[],
  eligible: readonly EligibleOperation[],
  blocked: readonly BlockedOperation[],
): EnablementReadinessReport {
  const allChecksPass = checks.every(c => c.passed);
  const rollbackCheck = checks.find(c => c.rule === "output_remains_descriptor_only");
  const rollbackReady = rollbackCheck?.passed ?? false;
  return {
    actualWritesEnabled:      false,
    realWritesEnabled:        false,
    commitRequired:           true,
    rollbackRequired:         true,
    approvalRequired:         true,
    allChecksPass,
    eligibleOperationCount:   eligible.length,
    blockedOperationCount:    blocked.length,
    rollbackReady,
    summary: allChecksPass
      ? "Actual write enablement pre-readiness confirmed — all 15 eligibility checks passed across 7 upstream layers; actual writes remain disabled and require explicit future execution phase with operator approval"
      : "Actual write enablement blocked — one or more eligibility checks failed across upstream layers; all actual writes remain disabled",
  };
}

function buildRollbackReference(
  input: CreateEnablementInput,
  checks: readonly EnablementCheck[],
): RollbackReference {
  const rollbackReady = checks.every(c => c.passed);
  return {
    rollbackSnapshotId:    input.snapshotRecord.rollbackSnapshotId,
    commitGateId:          input.commitGateRecord.commitGateId,
    rollbackRequired:      true,
    rollbackDescriptorOnly: true,
    rollbackBound:         input.snapshotRecord.rollbackSnapshotId.length > 0,
    rollbackReady,
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const enablementStore = new Map<string, ActualSandboxWriteEnablementRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createActualWriteEnablementRecord(
  input: CreateEnablementInput,
): { ok: true; record: ActualSandboxWriteEnablementRecord } {
  const actualWriteEnablementId = randomBytes(16).toString("hex");
  const eligible  = buildEligibleOperations(input.guardedWriteRecord);
  const blocked   = buildBlockedOperations(input.guardedWriteRecord);
  const checks    = buildEligibilityChecks(input, eligible, blocked);
  const readiness = buildReadinessReport(checks, eligible, blocked);
  const rollback  = buildRollbackReference(input, checks);

  const record: ActualSandboxWriteEnablementRecord = {
    actualWriteEnablementId,
    enablementState:            "actual_write_pre_enablement_ready",
    approvalRequired:           true,
    actualWritesEnabled:        false,
    realWritesEnabled:          false,
    commitRequired:             true,
    rollbackRequired:           true,
    motherCoreWritesBlocked:    true,
    protectedZoneWritesBlocked: true,
    vaultAccessBlocked:         true,
    shellAccessBlocked:         true,
    networkAccessBlocked:       true,
    deploymentWritesBlocked:    true,
    implementationPhase:        "descriptor_only",
    commitGateId:               input.commitGateRecord.commitGateId,
    rollbackSnapshotId:         input.snapshotRecord.rollbackSnapshotId,
    writeAuditId:               input.auditRecord.writeAuditId,
    guardedWriteId:             input.guardedWriteRecord.guardedWriteId,
    writePlanId:                input.writePlanRecord.writePlanId,
    writeGateId:                input.writeGateRecord.writeGateId,
    executionRecordId:          input.executionRecord.controlledExecutionId,
    approvalReference:          input.guardedWriteRecord.approvalReference,
    eligibilityChecks:          checks,
    eligibleOperations:         eligible,
    blockedOperations:          blocked,
    enablementReadinessReport:  readiness,
    rollbackReference:          rollback,
    createdAt:                  new Date().toISOString(),
  };

  enablementStore.set(actualWriteEnablementId, record);
  return { ok: true, record };
}

export function listActualWriteEnablementRecords(): readonly ActualSandboxWriteEnablementRecord[] {
  return [...enablementStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getActualWriteEnablementSummary(): ActualSandboxWriteEnablementSummary {
  const records = listActualWriteEnablementRecords();
  return {
    total:                      records.length,
    byState:                    { actual_write_pre_enablement_ready: records.length },
    actualWritesEnabled:        false,
    realWritesEnabled:          false,
    commitRequired:             true,
    rollbackRequired:           true,
    motherCoreWritesBlocked:    true,
    protectedZoneWritesBlocked: true,
    vaultAccessBlocked:         true,
    shellAccessBlocked:         true,
    networkAccessBlocked:       true,
    deploymentWritesBlocked:    true,
    approvalRequired:           true,
  };
}
