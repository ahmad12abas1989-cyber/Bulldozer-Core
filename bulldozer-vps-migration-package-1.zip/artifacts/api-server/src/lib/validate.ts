import type { IncomingMessage } from "node:http";

export type ValidRequest = { ok: true; method: string; path: string };
export type InvalidRequest = { ok: false; status: number; message: string };
export type ValidationResult = ValidRequest | InvalidRequest;

const ALLOWED_METHODS = new Set([
  "GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS",
]);

export function validateRequest(req: IncomingMessage): ValidationResult {
  const method = (req.method ?? "").toUpperCase();

  if (!method || !ALLOWED_METHODS.has(method)) {
    return { ok: false, status: 405, message: "Method Not Allowed" };
  }

  const rawUrl = req.url ?? "";

  if (!rawUrl.startsWith("/")) {
    return { ok: false, status: 400, message: "Bad Request" };
  }

  if (rawUrl.includes("\0")) {
    return { ok: false, status: 400, message: "Bad Request" };
  }

  let path: string;
  try {
    const parsed = new URL(rawUrl, "http://localhost");
    path = parsed.pathname;
    if (path.includes("\0")) {
      return { ok: false, status: 400, message: "Bad Request" };
    }
  } catch {
    return { ok: false, status: 400, message: "Bad Request" };
  }

  return { ok: true, method, path };
}
