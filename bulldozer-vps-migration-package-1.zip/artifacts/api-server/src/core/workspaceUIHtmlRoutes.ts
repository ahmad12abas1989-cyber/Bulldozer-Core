// workspaceUIHtmlRoutes.ts
// Phase 167 — UI HTML Routes API
// Pure derivation from getUIPageManifest() for sub-pages + static shell entry for /ui.
// No init. No persistence. No subsystem. No health check.
// No HTML/CSS/frontend framework code. executionBlocked always true.

import { getUIPageManifest } from "./workspaceUIPages";

// ── Types ──────────────────────────────────────────────────────────────────

export interface UIHtmlRouteEntry {
  readonly path: string;
  readonly pageId: string;
  readonly title: string;
  readonly type: "shell" | "page";
  readonly panelCount: number;
  readonly executionBlocked: true;
}

export interface UIHtmlRoutesIndex {
  readonly generatedAt: string;
  readonly totalRoutes: number;
  readonly routes: readonly UIHtmlRouteEntry[];
  readonly executionBlocked: true;
}

// ── Public API ─────────────────────────────────────────────────────────────

export function getUIHtmlRoutesIndex(): UIHtmlRoutesIndex {
  const manifest = getUIPageManifest();

  // Shell index entry — /ui is the navigation hub, not a dashboard page
  const shellEntry: UIHtmlRouteEntry = {
    path: "/ui",
    pageId: "shell",
    title: "UI Shell",
    type: "shell",
    panelCount: 0,
    executionBlocked: true,
  };

  // Sub-page entries derived from page manifest (already sorted by pageOrder)
  const pageEntries: UIHtmlRouteEntry[] = manifest.pages.map((p) => ({
    path: p.route,
    pageId: p.pageId,
    title: p.title,
    type: "page" as const,
    panelCount: p.panelCount,
    executionBlocked: true,
  }));

  const routes: UIHtmlRouteEntry[] = [shellEntry, ...pageEntries];

  return {
    generatedAt: new Date().toISOString(),
    totalRoutes: routes.length,
    routes,
    executionBlocked: true,
  };
}
