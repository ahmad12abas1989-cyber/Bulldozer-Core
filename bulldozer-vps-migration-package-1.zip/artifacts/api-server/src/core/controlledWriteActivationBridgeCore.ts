// controlledWriteActivationBridgeCore.ts
// Phase 294 — Controlled Write Activation Bridge Core Skeleton
// In-memory first controlled-write-activation-bridge descriptor engine.
// Layer 17 of the write-preparation + preflight + activation + switch + transition stack.
// Bridges execution-transition readiness toward future controlled write activation.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// bridgeEnabled=false — the write-activation bridge has not been opened.
// bridgePrepared=true — descriptor-readiness is established for a future bridge-open phase.

import type { FirstExecutionTransitionRecord }          from "./firstExecutionTransitionCore.js";
import type { FirstActivationSwitchRecord }             from "./firstActivationSwitchCore.js";
import type { FirstRealSandboxWriteActivationRecord }   from "./firstRealSandboxWriteActivationCore.js";
import type { ActualSandboxWritePreflightRecord }       from "./actualSandboxWritePreflightCore.js";
import type { ActualSandboxWriteApprovalTokenRecord }   from "./actualSandboxWriteApprovalTokenCore.js";
import type { ControlledExecutionRecord }               from "./controlledExecutionCore.js";
import { randomUUID }                                   from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type BridgeState = "descriptor_bridge_pending";

export type BridgeCheckRule =
  | "execution_transition_exists"
  | "activation_switch_exists"
  | "activation_record_exists"
  | "preflight_record_exists"
  | "approval_token_exists"
  | "execution_record_exists"
  | "transition_bound_to_switch"
  | "switch_bound_to_activation"
  | "activation_bound_to_preflight"
  | "preflight_bound_to_approval"
  | "bridge_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface BridgeCheck {
  readonly rule: BridgeCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface BridgeBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedBridgeReference {
  readonly executionTransitionId:     string;
  readonly activationSwitchId:        string;
  readonly activationId:              string;
  readonly preflightId:               string;
  readonly rollbackSnapshotId:        string;
  readonly bridgePrepared:            true;
  readonly bridgeEnabled:             false;
  readonly executionTransitionEnabled:false;
  readonly rollbackChainValid:        boolean;
  readonly referenceNote:             string;
}

export interface BridgeReadinessReport {
  readonly bridgePrepared:             true;
  readonly bridgeEnabled:              false;
  readonly executionTransitionEnabled: false;
  readonly activationSwitchEnabled:    false;
  readonly actualWritesEnabled:        false;
  readonly realWritesEnabled:          false;
  readonly approvalRequired:           true;
  readonly allChecksPass:              boolean;
  readonly blockedReasonCount:         number;
  readonly rollbackChainValid:         boolean;
  readonly summary:                    string;
}

export interface ControlledWriteActivationBridgeRecord {
  readonly writeActivationBridgeId:    string;
  readonly bridgeState:                BridgeState;
  readonly approvalRequired:           true;
  readonly bridgePrepared:             true;
  readonly bridgeEnabled:              false;
  readonly executionTransitionEnabled: false;
  readonly activationSwitchEnabled:    false;
  readonly actualWritesEnabled:        false;
  readonly realWritesEnabled:          false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly implementationPhase:        "descriptor_only";
  readonly executionTransitionId:      string;
  readonly activationSwitchId:         string;
  readonly activationId:               string;
  readonly preflightId:                string;
  readonly approvalTokenId:            string;
  readonly controlledExecutionId:      string;
  readonly bridgeChecks:               readonly BridgeCheck[];
  readonly bridgeBlockedReasons:       readonly BridgeBlockedReason[];
  readonly bridgeReadinessReport:      BridgeReadinessReport;
  readonly linkedBridgeReference:      LinkedBridgeReference;
  readonly createdAt:                  string;
}

export interface CreateBridgeInput {
  readonly transitionRecord:    FirstExecutionTransitionRecord;
  readonly switchRecord:        FirstActivationSwitchRecord;
  readonly activationRecord:    FirstRealSandboxWriteActivationRecord;
  readonly preflightRecord:     ActualSandboxWritePreflightRecord;
  readonly approvalTokenRecord: ActualSandboxWriteApprovalTokenRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface ControlledWriteActivationBridgeSummary {
  readonly total:                      number;
  readonly byState:                    Record<BridgeState, number>;
  readonly bridgePrepared:             true;
  readonly bridgeEnabled:              false;
  readonly executionTransitionEnabled: false;
  readonly activationSwitchEnabled:    false;
  readonly actualWritesEnabled:        false;
  readonly realWritesEnabled:          false;
  readonly approvalRequired:           true;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly bridgeState:                BridgeState;
  readonly implementationPhase:        "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: ControlledWriteActivationBridgeRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateBridgeInput): readonly BridgeCheck[] {
  const { transitionRecord, switchRecord, activationRecord, preflightRecord, approvalTokenRecord, executionRecord } = input;

  const transitionExists = transitionRecord.executionTransitionId.length > 0;
  const switchExists     = switchRecord.activationSwitchId.length > 0;
  const activationExists = activationRecord.activationId.length > 0;
  const preflightExists  = preflightRecord.preflightId.length > 0;
  const approvalExists   = approvalTokenRecord.approvalTokenId.length > 0;
  const executionExists  = executionRecord.controlledExecutionId.length > 0;

  const transitionBound  = transitionRecord.activationSwitchId === switchRecord.activationSwitchId;
  const switchBound      = switchRecord.activationId === activationRecord.activationId;
  const activationBound  = activationRecord.preflightId === preflightRecord.preflightId;
  const preflightBound   = preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId;

  return [
    {
      rule: "execution_transition_exists",
      pass: transitionExists,
      note: transitionExists
        ? `executionTransitionId=${transitionRecord.executionTransitionId}`
        : "transitionRecord.executionTransitionId is empty",
    },
    {
      rule: "activation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `activationSwitchId=${switchRecord.activationSwitchId}`
        : "switchRecord.activationSwitchId is empty",
    },
    {
      rule: "activation_record_exists",
      pass: activationExists,
      note: activationExists
        ? `activationId=${activationRecord.activationId}`
        : "activationRecord.activationId is empty",
    },
    {
      rule: "preflight_record_exists",
      pass: preflightExists,
      note: preflightExists
        ? `preflightId=${preflightRecord.preflightId}`
        : "preflightRecord.preflightId is empty",
    },
    {
      rule: "approval_token_exists",
      pass: approvalExists,
      note: approvalExists
        ? `approvalTokenId=${approvalTokenRecord.approvalTokenId}`
        : "approvalTokenRecord.approvalTokenId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "transition_bound_to_switch",
      pass: transitionBound,
      note: transitionBound
        ? `transitionRecord.activationSwitchId === switchRecord.activationSwitchId (${switchRecord.activationSwitchId})`
        : `transition-switch mismatch: transition.activationSwitchId=${transitionRecord.activationSwitchId} vs switch.activationSwitchId=${switchRecord.activationSwitchId}`,
    },
    {
      rule: "switch_bound_to_activation",
      pass: switchBound,
      note: switchBound
        ? `switchRecord.activationId === activationRecord.activationId (${activationRecord.activationId})`
        : `switch-activation mismatch: switch.activationId=${switchRecord.activationId} vs activation.activationId=${activationRecord.activationId}`,
    },
    {
      rule: "activation_bound_to_preflight",
      pass: activationBound,
      note: activationBound
        ? `activationRecord.preflightId === preflightRecord.preflightId (${preflightRecord.preflightId})`
        : `activation-preflight mismatch: activation.preflightId=${activationRecord.preflightId} vs preflight.preflightId=${preflightRecord.preflightId}`,
    },
    {
      rule: "preflight_bound_to_approval",
      pass: preflightBound,
      note: preflightBound
        ? `preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId (${approvalTokenRecord.approvalTokenId})`
        : `preflight-approval mismatch: preflight.approvalTokenId=${preflightRecord.approvalTokenId} vs token.approvalTokenId=${approvalTokenRecord.approvalTokenId}`,
    },
    {
      rule: "bridge_still_disabled",
      pass: true,
      note: "bridgeEnabled=false — compile-time literal; no bridge-open phase has enabled the write-activation bridge",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "bridgeState=descriptor_bridge_pending — output is a descriptor only; write-activation bridge is not yet live",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly BridgeCheck[]): readonly BridgeBlockedReason[] {
  const staticReasons: BridgeBlockedReason[] = [
    { code: "bridge_disabled",           reason: "bridgeEnabled=false — compile-time literal; an explicit bridge-open phase must set this to true",                                             static: true },
    { code: "approval_required",         reason: "approvalRequired=true — explicit operator approval is required before the write-activation bridge can be opened",                             static: true },
    { code: "actual_writes_disabled",    reason: "actualWritesEnabled=false — compile-time literal across all 17 sealed write-preparation, activation, switch, and transition layers",          static: true },
  ];
  const dynamicReasons: BridgeBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedBridgeReference(
  input: CreateBridgeInput,
  rollbackChainValid: boolean,
): LinkedBridgeReference {
  const { transitionRecord, switchRecord, activationRecord, preflightRecord } = input;
  return {
    executionTransitionId:      transitionRecord.executionTransitionId,
    activationSwitchId:         switchRecord.activationSwitchId,
    activationId:               activationRecord.activationId,
    preflightId:                preflightRecord.preflightId,
    rollbackSnapshotId:         transitionRecord.linkedTransitionReference.rollbackSnapshotId,
    bridgePrepared:             true,
    bridgeEnabled:              false,
    executionTransitionEnabled: false,
    rollbackChainValid,
    referenceNote:              "linked bridge reference sources rollbackSnapshotId from transitionRecord.linkedTransitionReference; bridge disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createBridgeRecord(input: CreateBridgeInput): ControlledWriteActivationBridgeRecord {
  const { transitionRecord, switchRecord, activationRecord, preflightRecord, approvalTokenRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid =
    transitionRecord.transitionReadinessReport.rollbackChainValid &&
    preflightRecord.preflightReadinessReport.rollbackReady &&
    approvalTokenRecord.approvalReadinessReport.rollbackReady;

  const allChecksPass    = checks.every((c) => c.pass);
  const blockedReasons   = buildBlockedReasons(checks);
  const linkedRef        = buildLinkedBridgeReference(input, rollbackChainValid);

  const bridgeReadinessReport: BridgeReadinessReport = {
    bridgePrepared:              true,
    bridgeEnabled:               false,
    executionTransitionEnabled:  false,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    approvalRequired:            true,
    allChecksPass,
    blockedReasonCount:          blockedReasons.length,
    rollbackChainValid,
    summary: `bridgeState=descriptor_bridge_pending; bridgeEnabled=false; executionTransitionEnabled=false; actualWritesEnabled=false; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: ControlledWriteActivationBridgeRecord = {
    writeActivationBridgeId:     randomUUID(),
    bridgeState:                 "descriptor_bridge_pending",
    approvalRequired:            true,
    bridgePrepared:              true,
    bridgeEnabled:               false,
    executionTransitionEnabled:  false,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    filesystemMutationBlocked:   true,
    motherCoreMutationBlocked:   true,
    vaultMutationBlocked:        true,
    shellBlocked:                true,
    networkBlocked:              true,
    implementationPhase:         "descriptor_only",
    executionTransitionId:       transitionRecord.executionTransitionId,
    activationSwitchId:          switchRecord.activationSwitchId,
    activationId:                activationRecord.activationId,
    preflightId:                 preflightRecord.preflightId,
    approvalTokenId:             approvalTokenRecord.approvalTokenId,
    controlledExecutionId:       executionRecord.controlledExecutionId,
    bridgeChecks:                checks,
    bridgeBlockedReasons:        blockedReasons,
    bridgeReadinessReport,
    linkedBridgeReference:       linkedRef,
    createdAt:                   new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listBridgeRecords(): readonly ControlledWriteActivationBridgeRecord[] {
  return _store.slice();
}

export function getBridgeSummary(): ControlledWriteActivationBridgeSummary {
  return {
    total:                       _store.length,
    byState:                     { descriptor_bridge_pending: _store.length },
    bridgePrepared:              true,
    bridgeEnabled:               false,
    executionTransitionEnabled:  false,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    approvalRequired:            true,
    filesystemMutationBlocked:   true,
    motherCoreMutationBlocked:   true,
    bridgeState:                 "descriptor_bridge_pending",
    implementationPhase:         "descriptor_only",
  };
}
