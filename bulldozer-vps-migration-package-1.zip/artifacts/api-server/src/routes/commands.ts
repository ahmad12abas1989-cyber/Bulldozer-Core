import type { IncomingMessage, ServerResponse } from "node:http";
import { readJsonBody } from "../lib/body";
import { sendJson, sendError } from "../lib/response";
import {
  submitCommand,
  getCommandGatewayStatus,
  evaluateCommand,
  getFilteredCommands,
  type CommandFilter,
} from "../core/commandGateway";

const MAX_LIMIT = 100;
const DEFAULT_LIMIT = 100;

function decodeParam(val: string | undefined): string | undefined {
  if (val === undefined) return undefined;
  try {
    return decodeURIComponent(val);
  } catch {
    return undefined;
  }
}

export function handleCommandsGet(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "";
  const queryStart = rawUrl.indexOf("?");
  const queryString = queryStart >= 0 ? rawUrl.slice(queryStart + 1) : "";

  const filter: CommandFilter = { limit: DEFAULT_LIMIT };

  if (queryString) {
    for (const part of queryString.split("&")) {
      const eqIdx = part.indexOf("=");
      if (eqIdx < 0) continue;
      const rawKey = part.slice(0, eqIdx);
      const rawVal = part.slice(eqIdx + 1);
      const key = decodeParam(rawKey);
      const val = decodeParam(rawVal);
      if (key === undefined || val === undefined || val === "") continue;

      switch (key) {
        case "limit": {
          const parsed = parseInt(val, 10);
          if (!isNaN(parsed) && parsed > 0) {
            filter.limit = Math.min(parsed, MAX_LIMIT);
          }
          break;
        }
        case "riskLevel":
          filter.riskLevel = val;
          break;
        case "commandType":
          filter.commandType = val;
          break;
        case "requestedBy":
          filter.requestedBy = val;
          break;
        case "status":
          filter.status = val;
          break;
        case "source":
          filter.source = val;
          break;
        default:
          break;
      }
    }
  }

  sendJson(res, 200, getFilteredCommands(filter));
}

export function handleCommandsStatus(_req: IncomingMessage, res: ServerResponse): void {
  const status = getCommandGatewayStatus();
  sendJson(res, 200, status);
}

export function handleCommandsPost(req: IncomingMessage, res: ServerResponse): void {
  readJsonBody(req)
    .then((body) => {
      if (!body || typeof body !== "object" || Array.isArray(body)) {
        sendError(res, 400, "Request body must be a JSON object");
        return;
      }

      const { commandType, source, requestedBy, payload, correlationId } =
        body as Record<string, unknown>;

      if (!commandType || typeof commandType !== "string" || !commandType.trim()) {
        sendError(res, 400, 'Field "commandType" is required and must be a non-empty string');
        return;
      }

      if (!source || typeof source !== "string" || !source.trim()) {
        sendError(res, 400, 'Field "source" is required and must be a non-empty string');
        return;
      }

      if (requestedBy !== undefined && typeof requestedBy !== "string") {
        sendError(res, 400, 'Field "requestedBy" must be a string if provided');
        return;
      }

      if (
        payload !== undefined &&
        (typeof payload !== "object" || Array.isArray(payload) || payload === null)
      ) {
        sendError(res, 400, 'Field "payload" must be a plain object if provided');
        return;
      }

      if (correlationId !== undefined && typeof correlationId !== "string") {
        sendError(res, 400, 'Field "correlationId" must be a string if provided');
        return;
      }

      const evaluation = evaluateCommand(commandType.trim());

      const command = submitCommand({
        commandType: commandType.trim(),
        source: source.trim(),
        requestedBy: typeof requestedBy === "string" ? requestedBy.trim() : undefined,
        payload: (payload as Record<string, unknown>) ?? {},
        correlationId: typeof correlationId === "string" ? correlationId : null,
      });

      sendJson(res, 201, {
        command,
        policyId: evaluation.policyId,
        policyReason: evaluation.policyReason,
        commandExecutionBlocked: true as const,
        executionBlocked: true as const,
        note: "Command recorded. No execution path exists — this gateway is intake-only.",
      });
    })
    .catch((err: Error) => {
      sendError(res, 400, err.message ?? "Bad Request");
    });
}
