import type { IncomingMessage, ServerResponse } from "node:http";
import { getRecoveryTrackingStatus } from "../core/recoveryTracker";
import { sendJson } from "../lib/response";

export function handleRecoveryTracker(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getRecoveryTrackingStatus());
}
