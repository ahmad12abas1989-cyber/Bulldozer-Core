import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson, sendError } from "../lib/response";
import {
  listDependencyNodes,
  getDependencyNode,
  getRuntimeDependencyGraphStatus,
} from "../core/runtimeDependencyGraph";

export function handleDependencyGraphList(_req: IncomingMessage, res: ServerResponse): void {
  const status = getRuntimeDependencyGraphStatus();
  const graphNodes = listDependencyNodes();

  sendJson(res, 200, {
    ...status,
    nodes: graphNodes,
  });
}

export function handleDependencyGraphStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getRuntimeDependencyGraphStatus());
}

export function handleDependencyGraphByName(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const subsystemName = segments[segments.length - 1] ?? "";

  if (!subsystemName) {
    sendError(res, 400, "Subsystem name is required");
    return;
  }

  const node = getDependencyNode(subsystemName);
  if (!node) {
    sendError(
      res,
      404,
      `Dependency node not found: "${subsystemName}". Use GET /api/runtime/graph to list all nodes.`,
    );
    return;
  }

  sendJson(res, 200, node);
}
