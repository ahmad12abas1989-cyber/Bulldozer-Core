import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson, sendError } from "../lib/response";
import { getPersistentStoreStatus } from "../core/persistentStore";

export function handleStorageStatus(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  try {
    const status = getPersistentStoreStatus();
    sendJson(res, 200, status);
  } catch (err) {
    sendError(res, 500, "Failed to retrieve storage status");
  }
}
