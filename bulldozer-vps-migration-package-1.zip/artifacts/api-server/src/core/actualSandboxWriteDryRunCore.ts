import { ActualSandboxWriteEnablementRecord } from "./actualSandboxWriteEnablementCore.js";
import { SandboxWriteCommitGateRecord }        from "./sandboxWriteCommitGateCore.js";
import { SandboxWriteRollbackSnapshotRecord }  from "./sandboxWriteRollbackSnapshotCore.js";
import { SandboxWriteAuditRecord }             from "./sandboxWriteAuditCore.js";
import { GuardedSandboxWriteRecord }           from "./guardedSandboxWriteCore.js";
import { ControlledExecutionRecord }           from "./controlledExecutionCore.js";
import { randomBytes }                         from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type DryRunState = "descriptor_dry_run_ready";

export type DryRunCheckRule =
  | "actual_enablement_exists"
  | "commit_gate_exists"
  | "rollback_snapshot_exists"
  | "write_audit_exists"
  | "guarded_write_exists"
  | "execution_record_exists"
  | "eligible_operations_present"
  | "operation_order_deterministic"
  | "rollback_binding_valid"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface DryRunOperation {
  readonly stepIndex:           number;
  readonly targetPath:          string;
  readonly operationType:       string;
  readonly simulatedOutcome:    "would_write_if_enabled";
  readonly actualWritesEnabled: false;
  readonly dryRunOnly:          true;
  readonly filesystemMutationBlocked: true;
  readonly dryRunNote:          string;
}

export interface DryRunValidationCheck {
  readonly rule:   DryRunCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface RollbackBindingReport {
  readonly rollbackSnapshotId:     string;
  readonly commitGateId:           string;
  readonly rollbackRequired:       true;
  readonly rollbackDescriptorOnly: true;
  readonly rollbackBound:          boolean;
  readonly rollbackReady:          boolean;
  readonly bindingNote:            string;
}

export interface DryRunReadinessReport {
  readonly actualWritesEnabled:    false;
  readonly dryRunOnly:             true;
  readonly allChecksPass:          boolean;
  readonly dryRunOperationCount:   number;
  readonly rollbackReady:          boolean;
  readonly approvalRequired:       true;
  readonly summary:                string;
}

export interface ActualSandboxWriteDryRunRecord {
  readonly dryRunId:                   string;
  readonly dryRunState:                DryRunState;
  readonly approvalRequired:           true;
  readonly actualWritesEnabled:        false;
  readonly dryRunOnly:                 true;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly implementationPhase:        "descriptor_only";
  readonly actualWriteEnablementId:    string;
  readonly commitGateId:               string;
  readonly rollbackSnapshotId:         string;
  readonly writeAuditId:               string;
  readonly guardedWriteId:             string;
  readonly executionRecordId:          string;
  readonly approvalReference:          string;
  readonly dryRunOperations:           readonly DryRunOperation[];
  readonly dryRunValidationChecks:     readonly DryRunValidationCheck[];
  readonly dryRunReadinessReport:      DryRunReadinessReport;
  readonly rollbackBindingReport:      RollbackBindingReport;
  readonly createdAt:                  string;
}

export interface CreateDryRunInput {
  readonly enablementRecord:    ActualSandboxWriteEnablementRecord;
  readonly commitGateRecord:    SandboxWriteCommitGateRecord;
  readonly snapshotRecord:      SandboxWriteRollbackSnapshotRecord;
  readonly auditRecord:         SandboxWriteAuditRecord;
  readonly guardedWriteRecord:  GuardedSandboxWriteRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface ActualSandboxWriteDryRunSummary {
  readonly total:                      number;
  readonly byState:                    Record<DryRunState, number>;
  readonly actualWritesEnabled:        false;
  readonly dryRunOnly:                 true;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly approvalRequired:           true;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildDryRunOperations(
  enablementRecord: ActualSandboxWriteEnablementRecord,
): readonly DryRunOperation[] {
  return enablementRecord.eligibleOperations
    .slice()
    .sort((a, b) => a.operationIndex - b.operationIndex)
    .map((op, stepIdx) => ({
      stepIndex:                stepIdx,
      targetPath:               op.targetPath,
      operationType:            op.operationType,
      simulatedOutcome:         "would_write_if_enabled" as const,
      actualWritesEnabled:      false,
      dryRunOnly:               true,
      filesystemMutationBlocked: true,
      dryRunNote:               `Dry-run step ${stepIdx}: would ${op.operationType} → ${op.targetPath} if actualWritesEnabled=true and operator-approved; no filesystem mutation occurs in this phase`,
    }));
}

function buildValidationChecks(
  input: CreateDryRunInput,
  ops: readonly DryRunOperation[],
): readonly DryRunValidationCheck[] {
  const { enablementRecord, commitGateRecord, snapshotRecord, auditRecord, guardedWriteRecord, executionRecord } = input;

  const orderDeterministic = ops.length > 0 &&
    ops.every((op, idx) => op.stepIndex === idx);

  const rollbackReady =
    enablementRecord.enablementReadinessReport.rollbackReady &&
    commitGateRecord.commitReadinessReport.rollbackReady &&
    snapshotRecord.snapshotReadinessReport.rollbackReady &&
    auditRecord.traceabilityReport.rollbackReady &&
    guardedWriteRecord.rollbackWriteReport.rollbackReady;

  const rollbackBound =
    snapshotRecord.rollbackSnapshotId.length > 0 &&
    commitGateRecord.commitGateId.length > 0;

  return [
    {
      rule:   "actual_enablement_exists",
      passed: enablementRecord.actualWriteEnablementId.length > 0,
      detail: "Actual write enablement record is present and valid",
    },
    {
      rule:   "commit_gate_exists",
      passed: commitGateRecord.commitGateId.length > 0,
      detail: "Commit gate record is present and valid",
    },
    {
      rule:   "rollback_snapshot_exists",
      passed: snapshotRecord.rollbackSnapshotId.length > 0,
      detail: "Rollback snapshot record is present and valid",
    },
    {
      rule:   "write_audit_exists",
      passed: auditRecord.writeAuditId.length > 0,
      detail: "Write audit record is present and valid",
    },
    {
      rule:   "guarded_write_exists",
      passed: guardedWriteRecord.guardedWriteId.length > 0,
      detail: "Guarded write record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "eligible_operations_present",
      passed: ops.length > 0 && enablementRecord.enablementReadinessReport.allChecksPass,
      detail: `${ops.length} eligible dry-run operation(s) present — enablementReadinessReport.allChecksPass=${enablementRecord.enablementReadinessReport.allChecksPass}`,
    },
    {
      rule:   "operation_order_deterministic",
      passed: orderDeterministic,
      detail: orderDeterministic
        ? `Dry-run operations are in deterministic stepIndex order (0–${ops.length - 1})`
        : "Dry-run operation ordering is not deterministic — dry run blocked",
    },
    {
      rule:   "rollback_binding_valid",
      passed: rollbackBound,
      detail: rollbackBound
        ? `Rollback binding valid — snapshotId=${snapshotRecord.rollbackSnapshotId.slice(0, 8)}… commitGateId=${commitGateRecord.commitGateId.slice(0, 8)}…`
        : "Rollback binding incomplete — rollbackSnapshotId or commitGateId missing",
    },
    {
      rule:   "actual_writes_still_disabled",
      passed: true,
      detail: "actualWritesEnabled=false confirmed — no real filesystem writes occur during dry run",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback readiness confirmed across all 5 upstream records — dry-run output is a valid descriptor"
        : "Rollback readiness not fully confirmed across upstream records — dry-run descriptor blocked",
    },
  ] as const;
}

function buildRollbackBindingReport(
  input: CreateDryRunInput,
  checks: readonly DryRunValidationCheck[],
): RollbackBindingReport {
  const rollbackReady = checks.every(c => c.passed);
  const rollbackBound =
    input.snapshotRecord.rollbackSnapshotId.length > 0 &&
    input.commitGateRecord.commitGateId.length > 0;
  return {
    rollbackSnapshotId:     input.snapshotRecord.rollbackSnapshotId,
    commitGateId:           input.commitGateRecord.commitGateId,
    rollbackRequired:       true,
    rollbackDescriptorOnly: true,
    rollbackBound,
    rollbackReady,
    bindingNote: rollbackReady
      ? "Rollback binding confirmed — dry-run is bound to a valid rollback snapshot and commit gate; any future real write can be rolled back to the pre-write state described in the snapshot"
      : "Rollback binding incomplete — all checks must pass before dry-run can be considered rollback-ready",
  };
}

function buildReadinessReport(
  checks: readonly DryRunValidationCheck[],
  ops: readonly DryRunOperation[],
): DryRunReadinessReport {
  const allChecksPass = checks.every(c => c.passed);
  const rollbackCheck = checks.find(c => c.rule === "output_remains_descriptor_only");
  const rollbackReady = rollbackCheck?.passed ?? false;
  return {
    actualWritesEnabled:   false,
    dryRunOnly:            true,
    allChecksPass,
    dryRunOperationCount:  ops.length,
    rollbackReady,
    approvalRequired:      true,
    summary: allChecksPass
      ? `Dry-run descriptor ready — ${ops.length} operation(s) simulated in deterministic order, rollback binding valid, all 11 checks passed; actual writes remain disabled and require explicit operator approval`
      : "Dry-run descriptor blocked — one or more validation checks failed; no actual writes will occur",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const dryRunStore = new Map<string, ActualSandboxWriteDryRunRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createActualSandboxWriteDryRunRecord(
  input: CreateDryRunInput,
): { ok: true; record: ActualSandboxWriteDryRunRecord } {
  const dryRunId   = randomBytes(16).toString("hex");
  const ops        = buildDryRunOperations(input.enablementRecord);
  const checks     = buildValidationChecks(input, ops);
  const rollback   = buildRollbackBindingReport(input, checks);
  const readiness  = buildReadinessReport(checks, ops);

  const record: ActualSandboxWriteDryRunRecord = {
    dryRunId,
    dryRunState:               "descriptor_dry_run_ready",
    approvalRequired:          true,
    actualWritesEnabled:       false,
    dryRunOnly:                true,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
    implementationPhase:       "descriptor_only",
    actualWriteEnablementId:   input.enablementRecord.actualWriteEnablementId,
    commitGateId:              input.commitGateRecord.commitGateId,
    rollbackSnapshotId:        input.snapshotRecord.rollbackSnapshotId,
    writeAuditId:              input.auditRecord.writeAuditId,
    guardedWriteId:            input.guardedWriteRecord.guardedWriteId,
    executionRecordId:         input.executionRecord.controlledExecutionId,
    approvalReference:         input.guardedWriteRecord.approvalReference,
    dryRunOperations:          ops,
    dryRunValidationChecks:    checks,
    dryRunReadinessReport:     readiness,
    rollbackBindingReport:     rollback,
    createdAt:                 new Date().toISOString(),
  };

  dryRunStore.set(dryRunId, record);
  return { ok: true, record };
}

export function listActualSandboxWriteDryRunRecords(): readonly ActualSandboxWriteDryRunRecord[] {
  return [...dryRunStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getActualSandboxWriteDryRunSummary(): ActualSandboxWriteDryRunSummary {
  const records = listActualSandboxWriteDryRunRecords();
  return {
    total:                     records.length,
    byState:                   { descriptor_dry_run_ready: records.length },
    actualWritesEnabled:       false,
    dryRunOnly:                true,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
    approvalRequired:          true,
  };
}
