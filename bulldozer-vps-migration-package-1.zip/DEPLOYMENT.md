# Bulldozer Mother Core — Deployment Guide

Cloud and VPS deployment reference. All deployment paths are read-only infrastructure operations — no execution, no autonomous behavior, no self-repair.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Environment Variables](#2-environment-variables)
3. [Quick Start — Docker Compose](#3-quick-start--docker-compose)
4. [Manual Docker Build and Run](#4-manual-docker-build-and-run)
5. [Direct Node.js Deployment (no Docker)](#5-direct-nodejs-deployment-no-docker)
6. [Storage Configuration](#6-storage-configuration)
7. [Health Verification](#7-health-verification)
8. [Nginx Reverse Proxy (recommended)](#8-nginx-reverse-proxy-recommended)
9. [Cloud Migration Checklist](#9-cloud-migration-checklist)
10. [Security Notes](#10-security-notes)

---

## 1. Prerequisites

| Requirement | Minimum Version | Notes |
|---|---|---|
| Node.js | 24 LTS | Required for direct deployment |
| pnpm | 9+ | Required for building from source |
| Docker | 24+ | Required for container deployment |
| Docker Compose | 2.20+ | Required for Compose deployment |

---

## 2. Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `PORT` | **Yes** | — | TCP port the HTTP server listens on |
| `SESSION_SECRET` | **Yes** | — | Random string ≥ 64 chars for session integrity |
| `STORAGE_DIR` | No | `<cwd>/storage` | Base directory for all persistent storage |
| `NODE_ENV` | No | `development` | Set to `production` outside of dev |
| `LOG_LEVEL` | No | `info` | One of: fatal, error, warn, info, debug, trace |
| `BULLDOZER_ALLOWED_HOSTS` | No | unset (all valid hosts allowed) | Comma-separated allowlist of permitted `Host` header values. Include port if non-standard (e.g. `api.example.com,api.example.com:443`). If unset, any syntactically valid `Host` is accepted. |
| `BULLDOZER_REQUIRE_HTTPS` | No | `false` | Set to `"true"` to require `X-Forwarded-Proto: https` on every request. Any request missing the header or arriving with a non-https value receives HTTP 400. **Only enable when the server is behind a TLS-terminating reverse proxy that injects `X-Forwarded-Proto`.** Do not set to `true` in local development. |
| `BULLDOZER_TRUSTED_PROXIES` | No | unset (disabled) | Comma-separated list of exact IP addresses (IPv4 or IPv6) that are trusted reverse proxies. When set, any request whose TCP socket `remoteAddress` is not in this list receives HTTP 400. Protects `X-Forwarded-For` and `X-Forwarded-Proto` from client spoofing. IPv4-mapped IPv6 addresses (`::ffff:x.x.x.x`) are automatically normalised to their IPv4 form for comparison. CIDR notation is **not** supported — list each exact proxy IP. Include both `127.0.0.1` and `::1` if your proxy may connect over either loopback form. |
| `BULLDOZER_OWNER_API_KEY` | No | unset | Static API key granting `owner/owner` identity. Minimum 16 characters. |
| `BULLDOZER_SERVICE_API_KEY` | No | unset | Static API key granting `service/operator` identity. Minimum 16 characters. |

Generate `SESSION_SECRET`:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

---

## 3. Quick Start — Docker Compose

```bash
# 1. Clone the repository
git clone <your-repo-url> bulldozer-core
cd bulldozer-core

# 2. Create the environment file
cp .env.example .env
# Edit .env — set PORT, SESSION_SECRET, and adjust STORAGE_DIR if needed

# 3. Build and start
docker compose up -d --build

# 4. Verify
curl http://localhost:3000/api/healthz
# Expected: {"status":"ok"}

# 5. View logs
docker compose logs -f api-server
```

To stop:
```bash
docker compose down
```

To upgrade (zero downtime storage — volume is preserved):
```bash
docker compose pull
docker compose up -d --build
```

---

## 4. Manual Docker Build and Run

```bash
# Build the image (run from workspace root)
docker build -t bulldozer-core:latest .

# Create a named volume for storage
docker volume create bulldozer-storage

# Run
docker run -d \
  --name bulldozer-api \
  --restart unless-stopped \
  -p 3000:3000 \
  -e PORT=3000 \
  -e NODE_ENV=production \
  -e SESSION_SECRET="$(openssl rand -hex 48)" \
  -e STORAGE_DIR=/app/storage \
  -v bulldozer-storage:/app/storage \
  bulldozer-core:latest

# Check health
curl http://localhost:3000/api/healthz
```

---

## 5. Direct Node.js Deployment (no Docker)

### One-time setup

```bash
# Install pnpm if not present
npm install -g pnpm@latest

# Clone repository
git clone <your-repo-url> /opt/bulldozer-core
cd /opt/bulldozer-core

# Install dependencies
pnpm install --frozen-lockfile

# Build the production bundle
pnpm --filter @workspace/api-server run build
# Output: artifacts/api-server/dist/index.mjs
```

### Environment

```bash
# Create the environment file
cp .env.example /etc/bulldozer-core.env
# Edit /etc/bulldozer-core.env — set all required variables
```

### Run with systemd (recommended)

Create `/etc/systemd/system/bulldozer-core.service`:

```ini
[Unit]
Description=Bulldozer Mother Core API Server
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=bulldozer
Group=bulldozer
WorkingDirectory=/opt/bulldozer-core/artifacts/api-server
EnvironmentFile=/etc/bulldozer-core.env
ExecStart=/usr/bin/node --enable-source-maps dist/index.mjs
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=bulldozer-core

# Security hardening
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ReadWritePaths=/app/storage

[Install]
WantedBy=multi-user.target
```

```bash
# Create the service user
useradd -r -s /bin/false bulldozer

# Create storage directory
mkdir -p /app/storage
chown bulldozer:bulldozer /app/storage

# Enable and start
systemctl daemon-reload
systemctl enable bulldozer-core
systemctl start bulldozer-core

# Check status
systemctl status bulldozer-core
journalctl -u bulldozer-core -f
```

---

## 6. Storage Configuration

All persistent storage lives under a single configurable base directory (`STORAGE_DIR`). Subdirectory layout:

```
$STORAGE_DIR/
├── snapshots/              # In-memory snapshot exports (max 20 files)
├── runtime-snapshots/      # Runtime snapshot archive
│   ├── active/             # Max 50 active snapshots
│   └── archived/           # Unlimited archived snapshots (read-only)
├── runtime-state/          # Single-file persistent runtime state
│   └── runtime-state.json
├── tasks/                  # Task queue persistence
│   └── task-state.json
└── store/                  # General key-value store (max 100 keys, 512 KB/value)
    └── <key>.json
```

All writes use atomic rename (`write to .tmp` → `rename`) — no partial writes on crash.

### Storage sizing

| Subdirectory | Max Size | Notes |
|---|---|---|
| `snapshots/` | ~20 MB | 20 files × ~1 MB each |
| `runtime-snapshots/` | ~50 MB | 50 active; archived unbounded |
| `runtime-state/` | < 1 MB | Single file, overwritten on change |
| `tasks/` | < 5 MB | Max 100 tasks |
| `store/` | < 52 MB | 100 keys × 512 KB |

**Minimum recommended storage allocation: 256 MB.** Leave headroom for logs and archived snapshots.

---

## 7. Health Verification

After deployment, run these checks:

```bash
BASE=http://localhost:3000

# 1. Basic health
curl -s $BASE/api/healthz
# Expected: {"status":"ok"}

# 2. Full health report (35 checks)
curl -s $BASE/api/health/full | jq '{status: .status, total: (.checks | length), fails: [.checks[] | select(.status=="fail") | .name]}'

# 3. Baseline integrity
curl -s $BASE/api/baseline/status | jq '{status: .baselineStatus, phase: .lockPhase}'
# Expected: {"status":"intact","phase":43}

# 4. Storage subsystem
curl -s $BASE/api/storage/status | jq '{operational: .operational, keys: .keyCount, maxKeys: .maxKeys}'

# 5. Diagnostics snapshot (all 26 subsystems)
curl -s $BASE/api/diagnostics/snapshot | jq '{baseline: .baseline.status, counts: .counts, safetyFlags: .safetyFlags}'
# Expected: baseline "intact", executionBlocked true
```

**Expected health state after clean boot:**
- `healthz`: `{"status":"ok"}`
- `health/full`: status `degraded` is normal — 5 structural warns are expected by design (`secure_config`, `task_queue`, `task_persistence`, `queue_orchestration`, `runtime_snapshot` all carry `executionBlocked: true`). Zero failures is the pass condition.
- `baseline/status`: `intact`

---

## 8. Nginx Reverse Proxy (recommended)

The `X-Forwarded-Proto` header is **required** when `BULLDOZER_REQUIRE_HTTPS=true`. Nginx injects it automatically via `proxy_set_header X-Forwarded-Proto $scheme;` — this is already included in the configuration below. Do not remove it.

```nginx
upstream bulldozer {
    server 127.0.0.1:3000;
    keepalive 32;
}

server {
    listen 80;
    server_name your-domain.com;
    # HTTP → HTTPS redirect. All requests land on HTTPS before reaching the app.
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate     /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    # TLS hardening — restrict to TLS 1.2+ and strong cipher suites
    ssl_protocols        TLSv1.2 TLSv1.3;
    ssl_ciphers          HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    location /api/ {
        proxy_pass         http://bulldozer;
        proxy_http_version 1.1;
        proxy_set_header   Connection "";
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;   # ← required for BULLDOZER_REQUIRE_HTTPS=true
        proxy_read_timeout 30s;
        proxy_send_timeout 30s;
    }

    location /api/healthz {
        proxy_pass         http://bulldozer;
        proxy_set_header   X-Forwarded-Proto $scheme;
        access_log         off;
    }
}
```

### Caddy equivalent

```caddy
your-domain.com {
    reverse_proxy /api/* localhost:3000 {
        header_up X-Forwarded-Proto {http.request.scheme}
        header_up Host              {host}
    }
}
```

### TLS termination notes

- The server speaks plain HTTP internally. TLS is terminated at Nginx/Caddy.
- When `BULLDOZER_REQUIRE_HTTPS=true` is set, the server trusts the `X-Forwarded-Proto` header injected by the proxy. **Ensure the proxy is the only ingress point** — do not expose port 3000 directly to the internet.
- The server always emits `Strict-Transport-Security: max-age=63072000; includeSubDomains` regardless of whether `BULLDOZER_REQUIRE_HTTPS` is set. The HSTS header is only meaningful over HTTPS; it is ignored by browsers over plain HTTP.
- Verify `X-Forwarded-Proto` injection is working after deployment: `curl -s https://your-domain.com/api/hardening | jq '{requireHttpsConfigured, hstsHeaderPresent}'`

### Trusted proxy and X-Forwarded-For notes

- **`BULLDOZER_TRUSTED_PROXIES`** locks down which IP addresses may act as reverse proxies. Any TCP connection that does not originate from a listed IP is rejected with HTTP 400 before any session, audit, or lifecycle record is created.
- `X-Forwarded-For` is **structurally validated** on every request regardless of `BULLDOZER_TRUSTED_PROXIES`. Control characters, values exceeding 512 characters, and empty comma-separated segments all return HTTP 400.
- `X-Real-IP` is surfaced in `GET /api/hardening` → `realIpHeader: "x-real-ip"` but the server does not currently parse its value for business logic — it is informational metadata in the hardening status only.
- `remoteAddress` in session context (`GET /api/session/recent`) is the raw TCP socket address — the proxy's IP, **not** the client IP. When `BULLDOZER_TRUSTED_PROXIES` is configured, `clientIp` is also set to the leftmost (original client) IP from `X-Forwarded-For`.
- **IPv4-mapped IPv6 addresses** (`::ffff:127.0.0.1`) are normalised to their IPv4 form (`127.0.0.1`) for comparison against `TRUSTED_PROXIES`. The raw form is stored unchanged in session context.
- **CIDR notation is not supported.** List each exact proxy IP address. For a same-host Nginx setup: `BULLDOZER_TRUSTED_PROXIES=127.0.0.1,::1`. For a LAN proxy: `BULLDOZER_TRUSTED_PROXIES=192.168.1.10`.
- Verify proxy trust configuration after deployment: `curl -s https://your-domain.com/api/hardening | jq '{trustedProxiesConfigured, forwardedForHeader, realIpHeader}'`

---

## 9. Cloud Migration Checklist

### Pre-migration

- [ ] `SESSION_SECRET` generated and stored securely (≥ 64 hex chars)
- [ ] `STORAGE_DIR` set to a persistent volume path (not ephemeral container storage)
- [ ] `NODE_ENV=production` confirmed in environment file
- [ ] `PORT` set and firewall rules allow traffic on that port
- [ ] Storage volume provisioned with ≥ 256 MB free space
- [ ] Storage directory writable by process user

### Build verification

- [ ] `pnpm --filter @workspace/api-server run typecheck` exits 0 (clean)
- [ ] `pnpm --filter @workspace/api-server run build` exits 0
- [ ] `dist/index.mjs` present after build
- [ ] No forbidden patterns in source: no `child_process`, no `eval`, no autonomous execution

### Runtime verification

- [ ] `GET /api/healthz` → `{"status":"ok"}`
- [ ] `GET /api/health/full` → 0 `fail` checks (5 structural `warn` checks are expected and normal)
- [ ] `GET /api/baseline/status` → `baselineStatus: "intact"`, `lockPhase: 43`
- [ ] `GET /api/storage/status` → `operational: true`
- [ ] `GET /api/diagnostics/snapshot` → `baseline.allFieldsMatch: true`, all `safetyFlags` true
- [ ] `GET /api/runtime/graph/status` → `cycleCount: 0`
- [ ] `GET /api/runtime/capabilities/status` → `invalidReferenceCount: 0`, `validationStatus: "valid"`

### Safety flags (must all be true in production)

- [ ] `executionBlocked: true` on every subsystem response
- [ ] `recoveryBlocked: true` on every subsystem response
- [ ] `commandExecutionBlocked: true` on `/api/commands/status`
- [ ] `executionStillBlocked: true` on `/api/task-evaluation`
- [ ] `enforcementMode: "observe"` on `/api/access/status`

### Post-migration monitoring

- [ ] Health endpoint polled every 30 s (e.g. via UptimeRobot, Datadog, or nginx healthcheck)
- [ ] Log output directed to persistent store or log aggregator
- [ ] Storage volume included in backup schedule
- [ ] Restart policy configured (`unless-stopped` in Docker, `Restart=on-failure` in systemd)

---

## 10. Security Notes

- **No execution path exists.** `executionBlocked: true` is a typed literal constant in every subsystem — it cannot be changed via API or environment variable.
- **No AI, no autonomous repair, no self-healing.** The nucleus is purely observational infrastructure.
- **Access enforcement is in `observe` mode by default.** All routes are accessible to anonymous `guest` role. To harden, switch enforcement mode and implement real authentication (not yet built).
- **SESSION_SECRET** is present in the env but not yet used for HTTP session signing — it is reserved for the authentication layer (Phase 45+).
- **Never expose port 3000 directly to the internet.** Put Nginx (or Caddy, Traefik) in front with TLS.
- **Storage files are plain JSON.** Do not write secrets to the persistent store.
- **Set `BULLDOZER_ALLOWED_HOSTS` in production** to the exact `Host` header value your reverse proxy forwards (e.g. `api.example.com` or `api.example.com:443`). If unset, any syntactically valid Host is accepted — this is appropriate for development but not for production deployments facing the internet.
- **`BULLDOZER_ALLOWED_HOSTS` includes the port** when the port is non-standard. For a standard HTTPS deployment behind Nginx on port 443, the Host header will be `api.example.com` (no port). For a non-standard port (e.g. a staging server on port 8443), the value must be `api.example.com:8443`.
- **Host header allowlist is parsed at startup.** Changes to `BULLDOZER_ALLOWED_HOSTS` require a server restart to take effect.
- **Set `BULLDOZER_REQUIRE_HTTPS=true` in production** to enforce HTTPS transport. The server rejects any request that does not carry `X-Forwarded-Proto: https` (or `HTTPS`, case-insensitive). Violations return HTTP 400 with `x-request-id` and all 10 security headers — no session, no audit, no lifecycle record is created.
- **`BULLDOZER_REQUIRE_HTTPS` requires a TLS-terminating reverse proxy** that injects `X-Forwarded-Proto`. Do not set it to `true` without verifying that Nginx/Caddy/Traefik is configured to forward this header. If the proxy does not inject the header, all requests will be rejected.
- **`BULLDOZER_REQUIRE_HTTPS` is parsed at startup.** Changes require a server restart. The current enforcement status is visible at `GET /api/hardening` → `requireHttpsConfigured`.
- **The `Strict-Transport-Security` header is always emitted** (regardless of `BULLDOZER_REQUIRE_HTTPS` state) with `max-age=63072000; includeSubDomains`. This is a 2-year HSTS policy. Once a browser has seen this header over HTTPS, it will refuse plain HTTP connections to the same domain for 2 years. Do not deploy behind plain HTTP to a public domain without understanding HSTS preloading implications.
- **Set `BULLDOZER_TRUSTED_PROXIES` in production** to the exact IP address(es) of your reverse proxy. This prevents clients from spoofing `X-Forwarded-For` and `X-Forwarded-Proto` by bypassing the proxy and connecting directly. Without this setting, any client can inject arbitrary `X-Forwarded-*` headers.
- **`BULLDOZER_TRUSTED_PROXIES` is parsed at startup.** Changes require a server restart. The current enforcement status is visible at `GET /api/hardening` → `trustedProxiesConfigured`.
- **Do not expose port 3000 directly to the internet** even with `BULLDOZER_TRUSTED_PROXIES` set — the setting enforces trust at the TCP socket level but is not a substitute for firewall rules. Use `ufw`, security groups, or iptables to restrict inbound traffic on port 3000 to loopback/VPC only.
- **`X-Forwarded-For` is always structurally validated** regardless of `BULLDOZER_TRUSTED_PROXIES`. Requests with control characters, values longer than 512 chars, or empty comma-separated segments are rejected with HTTP 400 before session creation. This protects the server from header injection attacks at the protocol level.
