import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";

const WINDOW_MS = 60_000;
const MAX_IDENTITY_KEYS = 500;
const MAX_ANOMALY_ENTRIES = 25;
const EXECUTION_BLOCKED: true = true;

interface Bucket {
  windowStart: number;
  count: number;
  blockedCount: number;
  lastBlockedAt: string | null;
}

export interface RateLimitAnomaly {
  timestamp: string;
  identityKey: string;
  route: string;
  method: string;
  retryAfterSeconds: number;
  blockedCount: number;
  executionBlocked: true;
}

export interface RateLimitResult {
  allowed: boolean;
  identityKey: string;
  requestCount: number;
  windowLimit: number;
  windowStart: number;
  windowMs: number;
  blockedCount: number;
}

export interface RateLimiterStatus {
  operational: boolean;
  windowMs: number;
  maxIdentityKeys: number;
  activeKeys: number;
  totalRequestsChecked: number;
  totalBlocked: number;
  lastBlockedAt: string | null;
  lastBlockedKey: string | null;
  anomalyCount: number;
  recentAnomalies: RateLimitAnomaly[];
  lastAnomalyAt: string | null;
  executionBlocked: true;
}

const buckets = new Map<string, Bucket>();
const keyInsertionOrder: string[] = [];
const anomalyBuffer: RateLimitAnomaly[] = [];

let isOperational = false;
let totalRequestsChecked = 0;
let totalBlocked = 0;
let lastBlockedAt: string | null = null;
let lastBlockedKey: string | null = null;
let anomalyCount = 0;
let lastAnomalyAt: string | null = null;

function resolveLimit(actorType: string, role: string): number {
  if (actorType === "owner" || actorType === "system") return 600;
  if (role === "admin") return 600;
  if (role === "operator") return 300;
  if (role === "viewer") return 120;
  return 60;
}

function makeIdentityKey(actorType: string, role: string, actorId: string | undefined): string {
  if (actorId !== undefined) return `id:${actorId}`;
  return `${actorType}:${role}`;
}

function evictOldest(): void {
  const oldest = keyInsertionOrder.shift();
  if (oldest !== undefined) {
    buckets.delete(oldest);
  }
}

export function initRateLimiter(): void {
  if (isOperational) return;
  isOperational = true;

  addTimelineEvent({
    level: "info",
    source: "rate-limiter",
    message: "Rate limiter initialized",
    metadata: {
      windowMs: WINDOW_MS,
      maxIdentityKeys: MAX_IDENTITY_KEYS,
      maxAnomalyEntries: MAX_ANOMALY_ENTRIES,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  emit("rate_limiter:initialized", "rate-limiter", {
    windowMs: WINDOW_MS,
    maxIdentityKeys: MAX_IDENTITY_KEYS,
  });

  emitRuntimeEvent({
    eventType: "rate_limiter.initialized",
    source: "rate-limiter",
    severity: "info",
    category: "runtime",
    payload: {
      windowMs: WINDOW_MS,
      maxIdentityKeys: MAX_IDENTITY_KEYS,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    { windowMs: WINDOW_MS, maxIdentityKeys: MAX_IDENTITY_KEYS, executionBlocked: EXECUTION_BLOCKED },
    "Rate limiter initialized",
  );
}

export function recordRateLimitAnomaly(anomaly: RateLimitAnomaly): void {
  if (anomalyBuffer.length >= MAX_ANOMALY_ENTRIES) {
    anomalyBuffer.shift();
  }
  anomalyBuffer.push(anomaly);
  anomalyCount++;
  lastAnomalyAt = anomaly.timestamp;
}

export function checkRateLimit(
  actorType: string,
  role: string,
  actorId: string | undefined,
): RateLimitResult {
  if (!isOperational) {
    return {
      allowed: true,
      identityKey: makeIdentityKey(actorType, role, actorId),
      requestCount: 0,
      windowLimit: resolveLimit(actorType, role),
      windowStart: Date.now(),
      windowMs: WINDOW_MS,
      blockedCount: 0,
    };
  }

  const identityKey = makeIdentityKey(actorType, role, actorId);
  const limit = resolveLimit(actorType, role);
  const now = Date.now();

  let bucket = buckets.get(identityKey);

  if (bucket === undefined) {
    if (buckets.size >= MAX_IDENTITY_KEYS) {
      evictOldest();
    }
    bucket = { windowStart: now, count: 0, blockedCount: 0, lastBlockedAt: null };
    buckets.set(identityKey, bucket);
    keyInsertionOrder.push(identityKey);
  } else if (now - bucket.windowStart >= WINDOW_MS) {
    bucket.windowStart = now;
    bucket.count = 0;
  }

  totalRequestsChecked++;
  bucket.count++;

  if (bucket.count > limit) {
    bucket.blockedCount++;
    bucket.lastBlockedAt = new Date().toISOString();
    totalBlocked++;
    lastBlockedAt = bucket.lastBlockedAt;
    lastBlockedKey = identityKey;

    return {
      allowed: false,
      identityKey,
      requestCount: bucket.count,
      windowLimit: limit,
      windowStart: bucket.windowStart,
      windowMs: WINDOW_MS,
      blockedCount: bucket.blockedCount,
    };
  }

  return {
    allowed: true,
    identityKey,
    requestCount: bucket.count,
    windowLimit: limit,
    windowStart: bucket.windowStart,
    windowMs: WINDOW_MS,
    blockedCount: bucket.blockedCount,
  };
}

export function getRateLimiterStatus(): RateLimiterStatus {
  return {
    operational: isOperational,
    windowMs: WINDOW_MS,
    maxIdentityKeys: MAX_IDENTITY_KEYS,
    activeKeys: buckets.size,
    totalRequestsChecked,
    totalBlocked,
    lastBlockedAt,
    lastBlockedKey,
    anomalyCount,
    recentAnomalies: anomalyBuffer.slice(),
    lastAnomalyAt,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
