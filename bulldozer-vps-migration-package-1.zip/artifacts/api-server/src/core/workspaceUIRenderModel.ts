// Workspace UI Render Model — Phase 129
// Derives a frontend-safe read-only render model from existing Widget Contracts
// and Visual Shell layers. No HTML generation, no React code, no runtime rendering,
// no mutation paths, no user action handlers, no secrets exposure.
// Pure static + light derivation — deterministic shape, bounded output.

import { getAllWidgetContracts } from "./workspaceWidgetContracts";
import { getWorkspaceVisualShell } from "./workspaceVisualShell";
import type { WidgetType, SectionId } from "./workspaceVisualShell";

const EXECUTION_BLOCKED: true = true;
const UI_VERSION = "1" as const;

// --- Render hint mapping (widgetType → CSS/layout hint token) ---
// No HTML emitted — these are opaque tokens for a future renderer.

const RENDER_HINT: Record<WidgetType, string> = {
  gauge:     "gauge_ring",
  badge:     "status_badge",
  table:     "data_table",
  list:      "item_list",
  metric:    "numeric_stat",
  chart:     "line_chart",
  timeline:  "event_feed",
  scorecard: "scorecard_card",
  heatmap:   "heatmap_grid",
  status:    "status_indicator",
};

// --- Types ---

export interface UILayout {
  appName: string;
  shellType: string;
  sidebarEnabled: boolean;
  topbarEnabled: boolean;
  contentGrid: string;
  executionBlocked: true;
}

export interface UIPage {
  pageId: string;
  title: string;
  route: string;
  sectionIds: SectionId[];
  description: string;
  pageOrder: number;
  executionBlocked: true;
}

export interface UINavigationItem {
  itemId: string;
  title: string;
  route: string;
  itemOrder: number;
  executionBlocked: true;
}

export interface UINavigationGroup {
  groupId: string;
  title: string;
  groupOrder: number;
  items: UINavigationItem[];
  executionBlocked: true;
}

export interface UINavigation {
  groups: UINavigationGroup[];
  totalGroups: number;
  executionBlocked: true;
}

export interface UIWidget {
  widgetId: string;
  title: string;
  widgetType: WidgetType;
  sourceEndpoint: string;
  compactDataType: string;
  renderHint: string;
  size: string;
  refreshMode: string;
  executionBlocked: true;
}

export interface UIPanelSummary {
  panelId: string;
  title: string;
  sectionId: SectionId;
  panelOrder: number;
  widgetIds: string[];
  executionBlocked: true;
}

export interface UIThemeTokens {
  colorMode: string;
  density: string;
  cardRadius: string;
  gridGap: string;
  typographyScale: string;
  executionBlocked: true;
}

export interface UIDataBinding {
  sourceEndpoint: string;
  readOnly: true;
  mutationAllowed: false;
  requiresApproval: false;
  executionBlocked: true;
}

export interface UIGovernanceBadge {
  badgeId: string;
  label: string;
  signalType: string;
  sourceEndpoint: string;
  refreshMode: string;
  executionBlocked: true;
}

export interface WorkspaceUIRenderModel {
  generatedAt: string;
  uiVersion: typeof UI_VERSION;
  layout: UILayout;
  navigation: UINavigation;
  pages: UIPage[];
  panels: UIPanelSummary[];
  widgets: UIWidget[];
  themeTokens: UIThemeTokens;
  dataBindings: UIDataBinding[];
  governanceBadges: UIGovernanceBadge[];
  executionBlocked: true;
}

// --- Static layout ---

const STATIC_LAYOUT: UILayout = {
  appName:        "Bulldozer",
  shellType:      "operator_dashboard",
  sidebarEnabled: true,
  topbarEnabled:  true,
  contentGrid:    "responsive",
  executionBlocked: EXECUTION_BLOCKED,
};

// --- Static pages (5 initial read-only dashboard pages) ---

const STATIC_PAGES: UIPage[] = [
  {
    pageId: "overview", title: "Overview", route: "/ui/overview",
    sectionIds: ["governance", "observation", "diagnostics"],
    description: "High-level system status across governance, observation, and diagnostics",
    pageOrder: 1, executionBlocked: EXECUTION_BLOCKED,
  },
  {
    pageId: "governance", title: "Governance", route: "/ui/governance",
    sectionIds: ["governance"],
    description: "Governance scorecard, drift history, and policy compliance",
    pageOrder: 2, executionBlocked: EXECUTION_BLOCKED,
  },
  {
    pageId: "observation", title: "Observation", route: "/ui/observation",
    sectionIds: ["observation"],
    description: "Observation ledger, coverage heatmap, exposure index, and probe results",
    pageOrder: 3, executionBlocked: EXECUTION_BLOCKED,
  },
  {
    pageId: "diagnostics", title: "Diagnostics", route: "/ui/diagnostics",
    sectionIds: ["diagnostics"],
    description: "Runtime health, metrics, freeze detector, and crash detector",
    pageOrder: 4, executionBlocked: EXECUTION_BLOCKED,
  },
  {
    pageId: "comparison", title: "Comparison", route: "/ui/comparison",
    sectionIds: ["governance", "observation"],
    description: "Point-in-time governance and observation diff views",
    pageOrder: 5, executionBlocked: EXECUTION_BLOCKED,
  },
];

// --- Static navigation (5 groups matching NavigationGroupId) ---

const STATIC_NAVIGATION: UINavigation = {
  groups: [
    {
      groupId: "overview", title: "Overview", groupOrder: 1,
      items: [
        { itemId: "nav-overview", title: "Overview", route: "/ui/overview", itemOrder: 1, executionBlocked: EXECUTION_BLOCKED },
      ],
      executionBlocked: EXECUTION_BLOCKED,
    },
    {
      groupId: "governance", title: "Governance", groupOrder: 2,
      items: [
        { itemId: "nav-governance-scorecard", title: "Scorecard",     route: "/ui/governance",          itemOrder: 1, executionBlocked: EXECUTION_BLOCKED },
        { itemId: "nav-governance-drift",     title: "Drift History", route: "/ui/governance/drift",    itemOrder: 2, executionBlocked: EXECUTION_BLOCKED },
        { itemId: "nav-governance-policy",    title: "Policy",        route: "/ui/governance/policy",   itemOrder: 3, executionBlocked: EXECUTION_BLOCKED },
      ],
      executionBlocked: EXECUTION_BLOCKED,
    },
    {
      groupId: "observation", title: "Observation", groupOrder: 3,
      items: [
        { itemId: "nav-observation-ledger",   title: "Ledger",   route: "/ui/observation",            itemOrder: 1, executionBlocked: EXECUTION_BLOCKED },
        { itemId: "nav-observation-coverage", title: "Coverage", route: "/ui/observation/coverage",   itemOrder: 2, executionBlocked: EXECUTION_BLOCKED },
        { itemId: "nav-observation-exposure", title: "Exposure", route: "/ui/observation/exposure",   itemOrder: 3, executionBlocked: EXECUTION_BLOCKED },
      ],
      executionBlocked: EXECUTION_BLOCKED,
    },
    {
      groupId: "diagnostics", title: "Diagnostics", groupOrder: 4,
      items: [
        { itemId: "nav-diagnostics-health",  title: "Health",  route: "/ui/diagnostics",         itemOrder: 1, executionBlocked: EXECUTION_BLOCKED },
        { itemId: "nav-diagnostics-metrics", title: "Metrics", route: "/ui/diagnostics/metrics", itemOrder: 2, executionBlocked: EXECUTION_BLOCKED },
      ],
      executionBlocked: EXECUTION_BLOCKED,
    },
    {
      groupId: "audit", title: "Audit", groupOrder: 5,
      items: [
        { itemId: "nav-audit-reports",    title: "Reports",    route: "/ui/audit",      itemOrder: 1, executionBlocked: EXECUTION_BLOCKED },
        { itemId: "nav-audit-comparison", title: "Comparison", route: "/ui/comparison", itemOrder: 2, executionBlocked: EXECUTION_BLOCKED },
      ],
      executionBlocked: EXECUTION_BLOCKED,
    },
  ],
  totalGroups: 5,
  executionBlocked: EXECUTION_BLOCKED,
};

// --- Static theme tokens ---

const STATIC_THEME_TOKENS: UIThemeTokens = {
  colorMode:       "dark",
  density:         "compact",
  cardRadius:      "4px",
  gridGap:         "16px",
  typographyScale: "sm",
  executionBlocked: EXECUTION_BLOCKED,
};

// --- Static governance badges ---
// Opaque signal descriptors — no live data, no rendering.

const STATIC_GOVERNANCE_BADGES: UIGovernanceBadge[] = [
  { badgeId: "badge-governance-score",   label: "Governance Score",   signalType: "score",        sourceEndpoint: "/api/workspace/governance/scorecard", refreshMode: "on-demand", executionBlocked: EXECUTION_BLOCKED },
  { badgeId: "badge-governance-grade",   label: "Governance Grade",   signalType: "grade",        sourceEndpoint: "/api/workspace/governance/scorecard", refreshMode: "on-demand", executionBlocked: EXECUTION_BLOCKED },
  { badgeId: "badge-drift-risk",         label: "Drift Risk Level",   signalType: "risk_level",   sourceEndpoint: "/api/workspace/governance/drift",     refreshMode: "on-demand", executionBlocked: EXECUTION_BLOCKED },
  { badgeId: "badge-observation-health", label: "Observation Health", signalType: "health",       sourceEndpoint: "/api/workspace/observation/ledger",   refreshMode: "on-demand", executionBlocked: EXECUTION_BLOCKED },
  { badgeId: "badge-system-health",      label: "System Health",      signalType: "health_status", sourceEndpoint: "/api/healthz",                       refreshMode: "realtime",  executionBlocked: EXECUTION_BLOCKED },
];

// --- Widget derivation ---
// O(37) scan of the full widget contract registry.
// getAllWidgetContracts() returns ReadonlyArray<WidgetContract> with all fields.
// widgetType cast is safe — registry only stores WidgetType literals.

function deriveWidgets(): UIWidget[] {
  return getAllWidgetContracts().map((c) => ({
    widgetId:        c.widgetId,
    title:           c.title,
    widgetType:      c.widgetType as WidgetType,
    sourceEndpoint:  c.sourceEndpoint,
    compactDataType: c.compactDataType,
    renderHint:      RENDER_HINT[c.widgetType as WidgetType] ?? "generic_card",
    size:            c.recommendedSize,
    refreshMode:     c.refreshCategory,
    executionBlocked: EXECUTION_BLOCKED,
  }));
}

// --- Panel derivation ---
// O(15) scan of static visual shell panels.
// Delegates to getWorkspaceVisualShell() which is purely static.

function derivePanels(): UIPanelSummary[] {
  const shell = getWorkspaceVisualShell();
  return shell.panels.map((p) => ({
    panelId:   p.panelId,
    title:     p.title,
    sectionId: p.sectionId,
    panelOrder: p.panelOrder,
    widgetIds: p.widgets.map((w) => w.widgetId),
    executionBlocked: EXECUTION_BLOCKED,
  }));
}

// --- Data binding derivation ---
// One binding per unique sourceEndpoint across all widgets.
// All bindings: readOnly=true, mutationAllowed=false, requiresApproval=false.
// Sorted by endpoint path for deterministic ordering.

function deriveDataBindings(widgets: UIWidget[]): UIDataBinding[] {
  const seen = new Set<string>();
  const bindings: UIDataBinding[] = [];
  for (const w of widgets) {
    if (!seen.has(w.sourceEndpoint)) {
      seen.add(w.sourceEndpoint);
      bindings.push({
        sourceEndpoint:   w.sourceEndpoint,
        readOnly:         true  as const,
        mutationAllowed:  false as const,
        requiresApproval: false as const,
        executionBlocked: EXECUTION_BLOCKED,
      });
    }
  }
  return bindings.sort((a, b) => a.sourceEndpoint.localeCompare(b.sourceEndpoint));
}

// --- Public API ---
// O(37) widget scan + O(15) panel scan. No I/O, no persistence mutation.
// No HTML, no React, no JSX, no runtime rendering. Read-only render model only.
// executionBlocked: true at every level throughout the response tree.

export function getUIRenderModel(): WorkspaceUIRenderModel {
  const widgets = deriveWidgets();
  const dataBindings = deriveDataBindings(widgets);
  const panels = derivePanels();

  return {
    generatedAt:      new Date().toISOString(),
    uiVersion:        UI_VERSION,
    layout:           STATIC_LAYOUT,
    navigation:       STATIC_NAVIGATION,
    pages:            STATIC_PAGES,
    panels,
    widgets,
    themeTokens:      STATIC_THEME_TOKENS,
    dataBindings,
    governanceBadges: STATIC_GOVERNANCE_BADGES,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
