// Sandbox Build Observe Route — Phase 233
// GET /api/sandbox/build/plans
// Read-only diagnostic view of the in-memory sandbox build plan registry.
// No build creation, no filesystem writes, no package installation,
// no runtime execution, no sandbox execution, no network access,
// no vault access, no deployment package.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  listSandboxBuildRecords,
  getSandboxBuildSummary,
} from "../core/sandboxBuildCore";

export function handleSandboxBuildObserve(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  const buildPlans = listSandboxBuildRecords();
  const summary    = getSandboxBuildSummary();

  sendJson(res, 200, {
    generatedAt:       new Date().toISOString(),
    buildEnabled:      false,
    executionEnabled:  false,
    deploymentEnabled: false,
    persistenceEnabled: false,
    executionBlocked:  true,
    deploymentBlocked: true,
    totalBuildPlans:   buildPlans.length,
    summary,
    buildPlans,
  });
}
