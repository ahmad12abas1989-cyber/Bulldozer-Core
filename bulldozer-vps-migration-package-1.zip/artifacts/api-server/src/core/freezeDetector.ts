import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";

export type FreezeStatus = "normal" | "warning" | "frozen";

export interface FreezeState {
  status: FreezeStatus;
  lastCheckAt: string | null;
  lastLagMs: number;
  maxLagMs: number;
  freezeCount: number;
  lastFreezeAt: string | null;
  timestamp: string;
}

const INTERVAL_MS = 1_000;
const WARN_THRESHOLD_MS = 100;
const FREEZE_THRESHOLD_MS = 500;

let timer: ReturnType<typeof setInterval> | null = null;
let lastTickAt = 0;

let currentStatus: FreezeStatus = "normal";
let lastCheckAt: string | null = null;
let lastLagMs = 0;
let maxLagMs = 0;
let freezeCount = 0;
let lastFreezeAt: string | null = null;

function tick(): void {
  const now = Date.now();

  if (lastTickAt === 0) {
    lastTickAt = now;
    return;
  }

  const elapsed = now - lastTickAt;
  const lag = Math.max(0, elapsed - INTERVAL_MS);
  lastTickAt = now;

  lastLagMs = lag;
  lastCheckAt = new Date(now).toISOString();

  if (lag > maxLagMs) maxLagMs = lag;

  if (lag >= FREEZE_THRESHOLD_MS) {
    if (currentStatus !== "frozen") {
      freezeCount++;
      lastFreezeAt = lastCheckAt;
      logger.warn({ lagMs: lag }, "Event loop freeze detected");
      addTimelineEvent({ level: "error", source: "freeze-detector", message: "Event loop freeze detected", metadata: { lagMs: lag } });
      emit("freeze:detected", "freeze-detector", { lagMs: lag });
    }
    currentStatus = "frozen";
  } else if (lag >= WARN_THRESHOLD_MS) {
    if (currentStatus !== "warning") {
      logger.warn({ lagMs: lag }, "Event loop lag warning");
      addTimelineEvent({ level: "warn", source: "freeze-detector", message: "Event loop lag warning", metadata: { lagMs: lag } });
      emit("freeze:warning", "freeze-detector", { lagMs: lag });
    }
    currentStatus = "warning";
  } else {
    currentStatus = "normal";
  }
}

export function getFreezeStatus(): FreezeState {
  return {
    status: currentStatus,
    lastCheckAt,
    lastLagMs,
    maxLagMs,
    freezeCount,
    lastFreezeAt,
    timestamp: new Date().toISOString(),
  };
}

export function startFreezeDetector(): void {
  if (timer !== null) return;
  lastTickAt = Date.now();
  timer = setInterval(tick, INTERVAL_MS);
  if (typeof timer.unref === "function") timer.unref();
  logger.info("Freeze detector started");
}

export function stopFreezeDetector(): void {
  if (timer === null) return;
  clearInterval(timer);
  timer = null;
  logger.info("Freeze detector stopped");
}
