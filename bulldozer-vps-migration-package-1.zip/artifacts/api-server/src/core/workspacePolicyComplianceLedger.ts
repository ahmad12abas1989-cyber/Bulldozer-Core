import { createHash } from "node:crypto";
import {
  getAccessEnforcementPolicies,
  type RouteAccessPolicy,
} from "./accessEnforcement";
import { getAuditLogEntries, type AuditEntry } from "./auditLog";

const EXECUTION_BLOCKED: true = true;
const MAX_AUDIT_SCAN = 1000;

// --- Types ---

export type ComplianceStatus = "observed" | "unobserved";

export interface ComplianceLedgerEntry {
  method: string;
  path: string;
  permission: string;
  minimumRole: string;
  status: ComplianceStatus;
  isWritePolicy: boolean;
  observationCount: number;
  allowedCount: number;
  deniedCount: number;
  lastObservedAt: string | null;
  firstObservedAt: string | null;
  executionBlocked: true;
}

export interface ComplianceSummary {
  totalPolicies: number;
  observedPolicies: number;
  unobservedPolicies: number;
  blockedPolicies: number;
  coveragePercent: number;
  latestObservedAt: string | null;
  executionBlocked: true;
}

export interface PolicyComplianceLedger {
  ledgerId: string;
  generatedAt: string;
  summary: ComplianceSummary;
  entries: ComplianceLedgerEntry[];
  auditEntriesScanned: number;
  executionBlocked: true;
}

// --- Internal helpers ---

function matchPath(pattern: string, actual: string): boolean {
  const pp = pattern.split("/");
  const ap = actual.split("/");
  if (pp.length !== ap.length) return false;
  return pp.every((seg, i) => seg.startsWith(":") || seg === ap[i]);
}

interface PolicyObservation {
  observationCount: number;
  allowedCount: number;
  deniedCount: number;
  firstObservedAt: string | null;
  lastObservedAt: string | null;
}

function buildObservationMap(
  policies: RouteAccessPolicy[],
  auditEntries: AuditEntry[],
): Map<string, PolicyObservation> {
  const policyKey = (method: string, path: string): string =>
    `${method.toUpperCase()}:${path}`;

  const obsMap = new Map<string, PolicyObservation>();

  for (const policy of policies) {
    obsMap.set(policyKey(policy.method, policy.path), {
      observationCount: 0,
      allowedCount: 0,
      deniedCount: 0,
      firstObservedAt: null,
      lastObservedAt: null,
    });
  }

  for (const entry of auditEntries) {
    const method = entry.method.toUpperCase();

    for (const policy of policies) {
      if (policy.method !== method) continue;
      if (!matchPath(policy.path, entry.route)) continue;

      const key = policyKey(policy.method, policy.path);
      const obs = obsMap.get(key);
      if (!obs) continue;

      obs.observationCount++;
      if (entry.decision === "allowed") obs.allowedCount++;
      else if (entry.decision === "denied") obs.deniedCount++;

      if (obs.firstObservedAt === null || entry.timestamp < obs.firstObservedAt) {
        obs.firstObservedAt = entry.timestamp;
      }
      if (obs.lastObservedAt === null || entry.timestamp > obs.lastObservedAt) {
        obs.lastObservedAt = entry.timestamp;
      }

      break;
    }
  }

  return obsMap;
}

function buildEntry(
  policy: RouteAccessPolicy,
  obs: PolicyObservation,
): ComplianceLedgerEntry {
  return {
    method: policy.method,
    path: policy.path,
    permission: policy.permission,
    minimumRole: policy.minimumRole,
    status: obs.observationCount > 0 ? "observed" : "unobserved",
    isWritePolicy: policy.permission === "write",
    observationCount: obs.observationCount,
    allowedCount: obs.allowedCount,
    deniedCount: obs.deniedCount,
    lastObservedAt: obs.lastObservedAt,
    firstObservedAt: obs.firstObservedAt,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function sortEntries(entries: ComplianceLedgerEntry[]): ComplianceLedgerEntry[] {
  const observed = entries
    .filter((e) => e.status === "observed")
    .sort((a, b) => {
      if (b.observationCount !== a.observationCount) {
        return b.observationCount - a.observationCount;
      }
      return `${a.method}:${a.path}`.localeCompare(`${b.method}:${b.path}`);
    });

  const unobserved = entries
    .filter((e) => e.status === "unobserved")
    .sort((a, b) =>
      `${a.method}:${a.path}`.localeCompare(`${b.method}:${b.path}`),
    );

  return [...observed, ...unobserved];
}

// --- Public API ---

export function getPolicyComplianceLedger(): PolicyComplianceLedger {
  const generatedAt = new Date().toISOString();
  const ledgerId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  const { policies } = getAccessEnforcementPolicies();
  const auditResult = getAuditLogEntries(MAX_AUDIT_SCAN);
  const auditEntries = auditResult.entries;

  const obsMap = buildObservationMap(policies, auditEntries);

  const policyKey = (method: string, path: string): string =>
    `${method.toUpperCase()}:${path}`;

  const entries = policies.map((policy) => {
    const obs = obsMap.get(policyKey(policy.method, policy.path)) ?? {
      observationCount: 0,
      allowedCount: 0,
      deniedCount: 0,
      firstObservedAt: null,
      lastObservedAt: null,
    };
    return buildEntry(policy, obs);
  });

  const sorted = sortEntries(entries);

  const totalPolicies = sorted.length;
  const observedPolicies = sorted.filter((e) => e.status === "observed").length;
  const unobservedPolicies = totalPolicies - observedPolicies;
  const blockedPolicies = sorted.filter((e) => e.isWritePolicy).length;
  const coveragePercent =
    totalPolicies > 0
      ? Math.min(100, Math.round((observedPolicies / totalPolicies) * 100))
      : 0;

  let latestObservedAt: string | null = null;
  for (const e of sorted) {
    if (e.lastObservedAt === null) continue;
    if (latestObservedAt === null || e.lastObservedAt > latestObservedAt) {
      latestObservedAt = e.lastObservedAt;
    }
  }

  const summary: ComplianceSummary = {
    totalPolicies,
    observedPolicies,
    unobservedPolicies,
    blockedPolicies,
    coveragePercent,
    latestObservedAt,
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    ledgerId,
    generatedAt,
    summary,
    entries: sorted,
    auditEntriesScanned: auditEntries.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
