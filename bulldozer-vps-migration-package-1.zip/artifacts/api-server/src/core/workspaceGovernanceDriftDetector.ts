// Governance Drift Detector — Phase 126
// Scans the Governance Scorecard history ring and Observation Ledger history ring
// for significant regressions across consecutive captures.
// Pure read-only derivation — no persistence mutation, no live recomputation,
// no rendering, no autonomous execution, no AI orchestration.

import { getRawScorecardHistoryEntries } from "./workspaceGovernanceScorecardHistory";
import { getRawHistoryEntries } from "./workspaceObservationLedgerHistory";
import type { GovernanceGrade } from "./workspaceGovernanceScorecard";
import type { ObservationHealth } from "./workspaceObservationLedger";

const EXECUTION_BLOCKED: true = true;

// --- Detection thresholds ---

const SCORECARD_DRIFT_THRESHOLD  = 5;   // governanceScore drop >= 5 → scorecard drift
const LEDGER_DRIFT_THRESHOLD     = 10;  // observationCoverage drop >= 10 → ledger drift
const SCORECARD_SEVERE_THRESHOLD = 10;  // score drop >= 10 → severe (medium risk alone)
const LEDGER_SEVERE_THRESHOLD    = 20;  // coverage drop >= 20 → severe (medium risk alone)

// --- Ordering tables (lower index = better) ---

const GRADE_ORDER: GovernanceGrade[]    = ["A", "B", "C", "D", "F"];
const HEALTH_ORDER: ObservationHealth[] = ["healthy", "degraded", "critical"];

// --- Types ---

export type RiskLevel  = "none" | "low" | "medium" | "high";
export type ChangeLabel = "improved" | "unchanged" | "degraded";

export interface ScorecardDriftResult {
  driftDetected: boolean;
  worstScoreDrop: number;
  fromCaptureSeq: number;
  toCaptureSeq: number;
  governanceGradeChange: ChangeLabel;
  executionBlocked: true;
}

export interface LedgerDriftResult {
  driftDetected: boolean;
  worstCoverageDrop: number;
  fromCaptureSeq: number;
  toCaptureSeq: number;
  observationHealthChange: ChangeLabel;
  executionBlocked: true;
}

export interface GovernanceDriftResult {
  generatedAt: string;
  driftDetected: boolean;
  riskLevel: RiskLevel;
  scorecardDrift: ScorecardDriftResult;
  ledgerDrift: LedgerDriftResult;
  executionBlocked: true;
}

// --- Internal helpers ---

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function gradeChangeLabel(from: GovernanceGrade, to: GovernanceGrade): ChangeLabel {
  // Lower grade index = better grade.
  // from→to with rising index = degradation.
  const diff = GRADE_ORDER.indexOf(to) - GRADE_ORDER.indexOf(from);
  if (diff > 0) return "degraded";
  if (diff < 0) return "improved";
  return "unchanged";
}

function healthChangeLabel(from: ObservationHealth, to: ObservationHealth): ChangeLabel {
  const diff = HEALTH_ORDER.indexOf(to) - HEALTH_ORDER.indexOf(from);
  if (diff > 0) return "degraded";
  if (diff < 0) return "improved";
  return "unchanged";
}

function deriveRiskLevel(sc: ScorecardDriftResult, ld: LedgerDriftResult): RiskLevel {
  if (!sc.driftDetected && !ld.driftDetected) return "none";
  if (sc.driftDetected && ld.driftDetected) return "high";
  // Exactly one drift present — classify by severity.
  if (sc.driftDetected && sc.worstScoreDrop >= SCORECARD_SEVERE_THRESHOLD) return "medium";
  if (ld.driftDetected && ld.worstCoverageDrop >= LEDGER_SEVERE_THRESHOLD) return "medium";
  return "low";
}

// --- Scorecard drift scan ---
// O(N-1) where N ≤ 10. Ring entries sorted ascending by captureSeq before scanning.
// Returns a zero-drift sentinel when the ring has fewer than 2 entries.

function scanScorecardDrift(): ScorecardDriftResult {
  const entries = getRawScorecardHistoryEntries();

  if (entries.length < 2) {
    return {
      driftDetected: false,
      worstScoreDrop: 0,
      fromCaptureSeq: 0,
      toCaptureSeq: 0,
      governanceGradeChange: "unchanged",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  // Sort ascending by captureSeq → chronological consecutive-pair scan.
  const sorted = [...entries].sort((a, b) => a.captureSeq - b.captureSeq);

  let worstDrop      = 0;
  let worstFrom      = sorted[0].captureSeq;
  let worstTo        = sorted[1].captureSeq;
  let worstGradeFrom: GovernanceGrade = sorted[0].snapshot.governanceGrade;
  let worstGradeTo:   GovernanceGrade = sorted[1].snapshot.governanceGrade;

  for (let i = 0; i < sorted.length - 1; i++) {
    const from = sorted[i];
    const to   = sorted[i + 1];
    const drop = round1(from.snapshot.governanceScore - to.snapshot.governanceScore);
    if (drop > worstDrop) {
      worstDrop      = drop;
      worstFrom      = from.captureSeq;
      worstTo        = to.captureSeq;
      worstGradeFrom = from.snapshot.governanceGrade;
      worstGradeTo   = to.snapshot.governanceGrade;
    }
  }

  const detected = worstDrop >= SCORECARD_DRIFT_THRESHOLD;
  return {
    driftDetected: detected,
    worstScoreDrop: worstDrop,
    fromCaptureSeq: detected ? worstFrom : 0,
    toCaptureSeq:   detected ? worstTo   : 0,
    governanceGradeChange: detected ? gradeChangeLabel(worstGradeFrom, worstGradeTo) : "unchanged",
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Ledger drift scan ---
// O(N-1) where N ≤ 20. Ring entries sorted ascending by captureSeq before scanning.
// Returns a zero-drift sentinel when the ring has fewer than 2 entries.

function scanLedgerDrift(): LedgerDriftResult {
  const entries = getRawHistoryEntries();

  if (entries.length < 2) {
    return {
      driftDetected: false,
      worstCoverageDrop: 0,
      fromCaptureSeq: 0,
      toCaptureSeq: 0,
      observationHealthChange: "unchanged",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const sorted = [...entries].sort((a, b) => a.captureSeq - b.captureSeq);

  let worstDrop        = 0;
  let worstFrom        = sorted[0].captureSeq;
  let worstTo          = sorted[1].captureSeq;
  let worstHealthFrom: ObservationHealth = sorted[0].snapshot.summary.overallObservationHealth;
  let worstHealthTo:   ObservationHealth = sorted[1].snapshot.summary.overallObservationHealth;

  for (let i = 0; i < sorted.length - 1; i++) {
    const from = sorted[i];
    const to   = sorted[i + 1];
    const drop = round1(from.snapshot.summary.observationCoverage - to.snapshot.summary.observationCoverage);
    if (drop > worstDrop) {
      worstDrop        = drop;
      worstFrom        = from.captureSeq;
      worstTo          = to.captureSeq;
      worstHealthFrom  = from.snapshot.summary.overallObservationHealth;
      worstHealthTo    = to.snapshot.summary.overallObservationHealth;
    }
  }

  const detected = worstDrop >= LEDGER_DRIFT_THRESHOLD;
  return {
    driftDetected: detected,
    worstCoverageDrop: worstDrop,
    fromCaptureSeq: detected ? worstFrom : 0,
    toCaptureSeq:   detected ? worstTo   : 0,
    observationHealthChange: detected ? healthChangeLabel(worstHealthFrom, worstHealthTo) : "unchanged",
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Public API ---

// O(9) + O(19) bounded consecutive-pair scans.
// No I/O, no persistence mutation, no live recomputation.
// Handles rings with < 2 entries gracefully — returns driftDetected=false, all zero/unchanged.
export function getGovernanceDrift(): GovernanceDriftResult {
  const sc = scanScorecardDrift();
  const ld = scanLedgerDrift();

  return {
    generatedAt:   new Date().toISOString(),
    driftDetected: sc.driftDetected || ld.driftDetected,
    riskLevel:     deriveRiskLevel(sc, ld),
    scorecardDrift: sc,
    ledgerDrift:    ld,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
