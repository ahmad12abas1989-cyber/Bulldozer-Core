import type { IncomingMessage } from "node:http";
import { generateRequestId } from "./requestId";

declare module "node:http" {
  interface IncomingMessage {
    requestId?: string;
  }
}

export function attachRequestId(req: IncomingMessage): string {
  const id = generateRequestId();
  req.requestId = id;
  return id;
}
