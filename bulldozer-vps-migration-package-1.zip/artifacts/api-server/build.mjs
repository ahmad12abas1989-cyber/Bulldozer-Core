import { build } from "esbuild";
import { rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const dir = path.dirname(fileURLToPath(import.meta.url));
const distDir = path.join(dir, "dist");

await rm(distDir, { recursive: true, force: true });

await build({
  entryPoints: [path.join(dir, "src/index.ts")],
  platform: "node",
  bundle: true,
  format: "esm",
  outdir: distDir,
  outExtension: { ".js": ".mjs" },
  sourcemap: "linked",
  logLevel: "info",
  external: ["*.node"],
  banner: {
    js: [
      "import { createRequire as __cr } from 'node:module';",
      "import __path from 'node:path';",
      "import __url from 'node:url';",
      "globalThis.require = __cr(import.meta.url);",
      "globalThis.__filename = __url.fileURLToPath(import.meta.url);",
      "globalThis.__dirname = __path.dirname(globalThis.__filename);",
    ].join("\n"),
  },
});
