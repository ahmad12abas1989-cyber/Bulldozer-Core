import type { IncomingMessage, ServerResponse } from "node:http";
import { getRuntimeStatePersistenceStatus } from "../core/runtimeState";
import { sendJson } from "../lib/response";

export function handleRuntimeState(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getRuntimeStatePersistenceStatus());
}
