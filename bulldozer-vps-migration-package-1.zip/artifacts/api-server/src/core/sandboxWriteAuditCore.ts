import { GuardedSandboxWriteRecord } from "./guardedSandboxWriteCore.js";
import { WritePlanRecord }           from "./sandboxWritePlanCore.js";
import { WriteGateRecord }           from "./realWriteEnablementGateCore.js";
import { ControlledExecutionRecord } from "./controlledExecutionCore.js";
import { randomBytes }               from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type AuditState = "descriptor_audit_ready";

export type AuditCheckRule =
  | "guarded_write_exists"
  | "write_plan_exists"
  | "write_gate_exists"
  | "execution_record_exists"
  | "attempted_operations_traced"
  | "blocked_operations_recorded"
  | "rollback_reference_present"
  | "mutation_still_blocked"
  | "output_remains_descriptor_only";

export interface AttemptedOperationTrace {
  readonly traceIndex:         number;
  readonly targetPath:         string;
  readonly operationType:      string;
  readonly contentDescriptor:  string;
  readonly actualWritesEnabled: false;
  readonly mutationBlocked:    true;
  readonly traceNote:          string;
}

export interface BlockedOperationRecord {
  readonly targetPath:          string;
  readonly mutationBlocked:     true;
  readonly reason:              string;
}

export interface AuditCheck {
  readonly rule:   AuditCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface TraceabilityReport {
  readonly rollbackRequired:         true;
  readonly rollbackDescriptorOnly:   true;
  readonly rollbackReferencePresent: boolean;
  readonly rollbackReady:            boolean;
  readonly attemptedOperationCount:  number;
  readonly blockedOperationCount:    number;
  readonly allChecksPass:            boolean;
  readonly summary:                  string;
}

export interface SandboxWriteAuditRecord {
  readonly writeAuditId:              string;
  readonly auditState:                AuditState;
  readonly approvalRequired:          true;
  readonly actualWritesEnabled:       false;
  readonly mutationBlocked:           true;
  readonly motherCoreMutationBlocked: true;
  readonly vaultMutationBlocked:      true;
  readonly networkBlocked:            true;
  readonly shellBlocked:              true;
  readonly rollbackRequired:          true;
  readonly implementationPhase:       "descriptor_only";
  readonly guardedWriteId:            string;
  readonly writePlanId:               string;
  readonly writeGateId:               string;
  readonly executionRecordId:         string;
  readonly approvalReference:         string;
  readonly attemptedOperations:       readonly AttemptedOperationTrace[];
  readonly blockedOperations:         readonly BlockedOperationRecord[];
  readonly auditChecks:               readonly AuditCheck[];
  readonly traceabilityReport:        TraceabilityReport;
  readonly createdAt:                 string;
}

export interface CreateSandboxWriteAuditInput {
  readonly guardedWriteRecord: GuardedSandboxWriteRecord;
  readonly writePlanRecord:    WritePlanRecord;
  readonly writeGateRecord:    WriteGateRecord;
  readonly executionRecord:    ControlledExecutionRecord;
}

export interface SandboxWriteAuditSummary {
  readonly total:                     number;
  readonly byState:                   Record<AuditState, number>;
  readonly actualWritesEnabled:       false;
  readonly mutationBlocked:           true;
  readonly motherCoreMutationBlocked: true;
  readonly vaultMutationBlocked:      true;
  readonly networkBlocked:            true;
  readonly shellBlocked:              true;
  readonly approvalRequired:          true;
  readonly rollbackRequired:          true;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildAttemptedOperations(
  guardedWriteRecord: GuardedSandboxWriteRecord,
): readonly AttemptedOperationTrace[] {
  return guardedWriteRecord.writeOperations.map((op, idx) => ({
    traceIndex:          idx,
    targetPath:          op.targetPath,
    operationType:       op.operationType,
    contentDescriptor:   op.contentDescriptor,
    actualWritesEnabled: false,
    mutationBlocked:     true,
    traceNote:           `Audit trace for guarded write operation ${idx} targeting ${op.targetPath} (${op.operationType}) — descriptor-only; no filesystem mutation occurred`,
  }));
}

function buildBlockedOperations(
  guardedWriteRecord: GuardedSandboxWriteRecord,
): readonly BlockedOperationRecord[] {
  return guardedWriteRecord.blockedOperations.map(bop => ({
    targetPath:      bop.targetPath,
    mutationBlocked: true,
    reason:          `Protected zone — permanently blocked; audit record confirms no write attempted to ${bop.targetPath}`,
  }));
}

function buildAuditChecks(
  input: CreateSandboxWriteAuditInput,
  attempted: readonly AttemptedOperationTrace[],
  blocked: readonly BlockedOperationRecord[],
): readonly AuditCheck[] {
  const { guardedWriteRecord, writePlanRecord, writeGateRecord, executionRecord } = input;
  const rollbackReady =
    guardedWriteRecord.rollbackWriteReport.rollbackReady &&
    writeGateRecord.writeReadinessReport.rollbackReady;

  return [
    {
      rule:   "guarded_write_exists",
      passed: guardedWriteRecord.guardedWriteId.length > 0,
      detail: "Guarded sandbox write record is present and valid",
    },
    {
      rule:   "write_plan_exists",
      passed: writePlanRecord.writePlanId.length > 0,
      detail: "Sandbox write plan record is present and valid",
    },
    {
      rule:   "write_gate_exists",
      passed: writeGateRecord.writeGateId.length > 0,
      detail: "Write enablement gate record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "attempted_operations_traced",
      passed: attempted.length > 0,
      detail: `${attempted.length} attempted write operation trace(s) recorded — all mutationBlocked=true`,
    },
    {
      rule:   "blocked_operations_recorded",
      passed: blocked.length > 0,
      detail: `${blocked.length} blocked protected-zone operation(s) recorded — all mutationBlocked=true`,
    },
    {
      rule:   "rollback_reference_present",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback reference confirmed across guarded write record and write gate"
        : "Rollback reference not fully confirmed across upstream records",
    },
    {
      rule:   "mutation_still_blocked",
      passed: true,
      detail: "mutationBlocked=true confirmed — no filesystem mutation occurred in this phase",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: true,
      detail: "Audit output is descriptor-only — no real filesystem writes",
    },
  ] as const;
}

function buildTraceabilityReport(
  checks: readonly AuditCheck[],
  attempted: readonly AttemptedOperationTrace[],
  blocked: readonly BlockedOperationRecord[],
): TraceabilityReport {
  const rollbackCheck   = checks.find(c => c.rule === "rollback_reference_present");
  const rollbackReady   = rollbackCheck?.passed ?? false;
  const allChecksPass   = checks.every(c => c.passed);
  return {
    rollbackRequired:         true,
    rollbackDescriptorOnly:   true,
    rollbackReferencePresent: rollbackReady,
    rollbackReady,
    attemptedOperationCount:  attempted.length,
    blockedOperationCount:    blocked.length,
    allChecksPass,
    summary: allChecksPass
      ? "Audit traceability confirmed — all write operations traced, all protected zones recorded as blocked, rollback reference present, no mutation occurred"
      : "Audit traceability incomplete — one or more checks failed; write operation tracing must be resolved before activation",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const auditStore = new Map<string, SandboxWriteAuditRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createSandboxWriteAuditRecord(
  input: CreateSandboxWriteAuditInput,
): { ok: true; record: SandboxWriteAuditRecord } {
  const writeAuditId    = randomBytes(16).toString("hex");
  const attempted       = buildAttemptedOperations(input.guardedWriteRecord);
  const blocked         = buildBlockedOperations(input.guardedWriteRecord);
  const checks          = buildAuditChecks(input, attempted, blocked);
  const traceability    = buildTraceabilityReport(checks, attempted, blocked);

  const record: SandboxWriteAuditRecord = {
    writeAuditId,
    auditState:                "descriptor_audit_ready",
    approvalRequired:          true,
    actualWritesEnabled:       false,
    mutationBlocked:           true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    networkBlocked:            true,
    shellBlocked:              true,
    rollbackRequired:          true,
    implementationPhase:       "descriptor_only",
    guardedWriteId:            input.guardedWriteRecord.guardedWriteId,
    writePlanId:               input.writePlanRecord.writePlanId,
    writeGateId:               input.writeGateRecord.writeGateId,
    executionRecordId:         input.executionRecord.controlledExecutionId,
    approvalReference:         input.guardedWriteRecord.approvalReference,
    attemptedOperations:       attempted,
    blockedOperations:         blocked,
    auditChecks:               checks,
    traceabilityReport:        traceability,
    createdAt:                 new Date().toISOString(),
  };

  auditStore.set(writeAuditId, record);
  return { ok: true, record };
}

export function listSandboxWriteAuditRecords(): readonly SandboxWriteAuditRecord[] {
  return [...auditStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getSandboxWriteAuditSummary(): SandboxWriteAuditSummary {
  const records = listSandboxWriteAuditRecords();
  return {
    total:                     records.length,
    byState:                   { descriptor_audit_ready: records.length },
    actualWritesEnabled:       false,
    mutationBlocked:           true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    networkBlocked:            true,
    shellBlocked:              true,
    approvalRequired:          true,
    rollbackRequired:          true,
  };
}
