import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  getRuntimeEventBusStatus,
  listRuntimeSubscribers,
  getFilteredRuntimeEvents,
  type RuntimeEventFilter,
} from "../core/runtimeEventBus";

const MAX_LIMIT = 100;
const DEFAULT_LIMIT = 50;

function decodeParam(val: string | undefined): string | undefined {
  if (val === undefined) return undefined;
  try {
    return decodeURIComponent(val);
  } catch {
    return undefined;
  }
}

export function handleRuntimeEvents(_req: IncomingMessage, res: ServerResponse): void {
  const status = getRuntimeEventBusStatus();
  sendJson(res, 200, status);
}

export function handleRuntimeEventsRecent(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "";
  const queryStart = rawUrl.indexOf("?");
  const queryString = queryStart >= 0 ? rawUrl.slice(queryStart + 1) : "";

  const filter: RuntimeEventFilter = { limit: DEFAULT_LIMIT };

  if (queryString) {
    for (const part of queryString.split("&")) {
      const eqIdx = part.indexOf("=");
      if (eqIdx < 0) continue;
      const rawKey = part.slice(0, eqIdx);
      const rawVal = part.slice(eqIdx + 1);
      const key = decodeParam(rawKey);
      const val = decodeParam(rawVal);
      if (key === undefined || val === undefined || val === "") continue;

      switch (key) {
        case "limit": {
          const parsed = parseInt(val, 10);
          if (!isNaN(parsed) && parsed > 0) {
            filter.limit = Math.min(parsed, MAX_LIMIT);
          }
          break;
        }
        case "eventType":
          filter.eventType = val;
          break;
        case "source":
          filter.source = val;
          break;
        case "severity":
          filter.severity = val;
          break;
        case "category":
          filter.category = val;
          break;
        case "correlationId":
          filter.correlationId = val;
          break;
        default:
          break;
      }
    }
  }

  sendJson(res, 200, getFilteredRuntimeEvents(filter));
}

export function handleRuntimeSubscribers(_req: IncomingMessage, res: ServerResponse): void {
  const subscribers = listRuntimeSubscribers();

  sendJson(res, 200, {
    subscribers,
    totalCount: subscribers.length,
    executionBlocked: true as const,
    timestamp: new Date().toISOString(),
  });
}
