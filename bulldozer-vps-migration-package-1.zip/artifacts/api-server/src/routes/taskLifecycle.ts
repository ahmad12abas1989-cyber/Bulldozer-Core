import type { IncomingMessage, ServerResponse } from "node:http";
import { readJsonBody } from "../lib/body";
import { sendJson, sendError } from "../lib/response";
import {
  getTaskLifecycleStatus,
  listLifecycleRules,
  listTaskLifecycles,
  transitionTaskState,
  type LifecycleState,
} from "../core/taskLifecycle";

const VALID_STATES = new Set<LifecycleState>([
  "queued",
  "ready",
  "waiting_approval",
  "blocked",
  "archived",
]);

export function handleTaskLifecycleGet(_req: IncomingMessage, res: ServerResponse): void {
  const status = getTaskLifecycleStatus();
  const rules = listLifecycleRules();
  const taskLifecycles = listTaskLifecycles();

  sendJson(res, 200, {
    ...status,
    lifecycleRules: rules,
    taskLifecycles,
  });
}

export function handleTaskLifecycleTransitionPost(req: IncomingMessage, res: ServerResponse): void {
  readJsonBody(req)
    .then((body) => {
      if (!body || typeof body !== "object" || Array.isArray(body)) {
        sendError(res, 400, "Request body must be a JSON object");
        return;
      }

      const { taskId, targetState, reason } = body as Record<string, unknown>;

      if (!taskId || typeof taskId !== "string" || !taskId.trim()) {
        sendError(res, 400, 'Field "taskId" is required and must be a non-empty string');
        return;
      }

      if (!targetState || typeof targetState !== "string") {
        sendError(res, 400, 'Field "targetState" is required and must be a string');
        return;
      }

      if (!VALID_STATES.has(targetState as LifecycleState)) {
        sendError(
          res,
          400,
          `Field "targetState" must be one of: ${[...VALID_STATES].join(", ")}`,
        );
        return;
      }

      if (reason !== undefined && typeof reason !== "string") {
        sendError(res, 400, 'Field "reason" must be a string if provided');
        return;
      }

      const result = transitionTaskState(
        taskId.trim(),
        targetState as LifecycleState,
        typeof reason === "string" ? reason.trim() : undefined,
      );

      const statusCode = result.success ? 200 : 422;
      sendJson(res, statusCode, result);
    })
    .catch((err: Error) => {
      sendError(res, 400, err.message ?? "Bad Request");
    });
}
