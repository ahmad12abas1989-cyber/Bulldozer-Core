import { ExperimentalProductionFlowRecord } from "./experimentalProductionFlowCore.js";
import { PreviewPipelineRecord }             from "./previewPipelineCore.js";
import { VirtualWorkspaceRecord }            from "./virtualWorkspaceCore.js";
import { InstallSimulationRecord }           from "./installSimulationCore.js";
import { randomBytes }                       from "node:crypto";

export type ControlledExecutionState =
  "awaiting_operator_execution_approval";

export type ControlledExecutionStage =
  | "validate_execution_context"
  | "allocate_sandbox_runtime"
  | "prepare_virtual_workspace_mount"
  | "validate_execution_policy"
  | "verify_install_simulation"
  | "prepare_runtime_guards"
  | "await_operator_execution_approval";

export type ExecutionValidationRule =
  | "experimental_flow_exists"
  | "preview_exists"
  | "workspace_exists"
  | "install_simulation_passed"
  | "execution_policy_present"
  | "rollback_preparation_valid"
  | "output_remains_descriptor_only";

export interface ExecutionValidationCheck {
  readonly rule:    ExecutionValidationRule;
  readonly passed:  boolean;
  readonly message: string;
}

export interface ExecutionBoundaryReport {
  readonly executionBlocked:   true;
  readonly filesystemBlocked:  true;
  readonly networkBlocked:     true;
  readonly deploymentBlocked:  true;
  readonly autonomousBlocked:  true;
  readonly motherCoreMutation: false;
  readonly vaultMutation:      false;
  readonly shellAccess:        false;
  readonly summary:            string;
}

export interface RollbackPreparationReport {
  readonly rollbackRequired:       true;
  readonly rollbackDescriptorOnly: true;
  readonly rollbackStagesCount:    number;
  readonly rollbackTargetStage:    ControlledExecutionStage;
  readonly rollbackReady:          boolean;
  readonly summary:                string;
}

export interface ExecutionPlanStep {
  readonly stepIndex: number;
  readonly stage:     ControlledExecutionStage;
  readonly blocked:   true;
  readonly reason:    string;
}

export interface ControlledExecutionRecord {
  readonly controlledExecutionId:   string;
  readonly createdAt:               string;
  readonly executionState:          ControlledExecutionState;
  readonly approvalRequired:        true;
  readonly executionBlocked:        true;
  readonly filesystemBlocked:       true;
  readonly networkBlocked:          true;
  readonly deploymentBlocked:       true;
  readonly autonomousBlocked:       true;
  readonly linkedFlowId:            string;
  readonly linkedPreviewId:         string;
  readonly linkedWorkspaceId:       string;
  readonly linkedInstallSimId:      string;
  readonly operatorApprovalRef:     string;
  readonly executionPolicyRef:      string;
  readonly executionPlan:           readonly ExecutionPlanStep[];
  readonly executionStages:         readonly ControlledExecutionStage[];
  readonly executionValidationChecks: readonly ExecutionValidationCheck[];
  readonly executionBoundaryReport: ExecutionBoundaryReport;
  readonly rollbackPreparationReport: RollbackPreparationReport;
}

export interface CreateControlledExecutionInput {
  readonly flowRecord:          ExperimentalProductionFlowRecord;
  readonly previewRecord:       PreviewPipelineRecord;
  readonly workspaceRecord:     VirtualWorkspaceRecord;
  readonly installRecord:       InstallSimulationRecord;
  readonly operatorApprovalRef: string;
  readonly executionPolicyRef:  string;
}

export interface ControlledExecutionSummary {
  readonly totalExecutions:    number;
  readonly byState:            Record<ControlledExecutionState, number>;
  readonly executionBlocked:   true;
  readonly filesystemBlocked:  true;
  readonly networkBlocked:     true;
  readonly deploymentBlocked:  true;
  readonly autonomousBlocked:  true;
  readonly implementationPhase: "descriptor_only";
}

const CANONICAL_STAGES: readonly ControlledExecutionStage[] = [
  "validate_execution_context",
  "allocate_sandbox_runtime",
  "prepare_virtual_workspace_mount",
  "validate_execution_policy",
  "verify_install_simulation",
  "prepare_runtime_guards",
  "await_operator_execution_approval",
] as const;

const VALIDATION_RULES: readonly ExecutionValidationRule[] = [
  "experimental_flow_exists",
  "preview_exists",
  "workspace_exists",
  "install_simulation_passed",
  "execution_policy_present",
  "rollback_preparation_valid",
  "output_remains_descriptor_only",
] as const;

const BOUNDARY_REPORT: ExecutionBoundaryReport = {
  executionBlocked:   true,
  filesystemBlocked:  true,
  networkBlocked:     true,
  deploymentBlocked:  true,
  autonomousBlocked:  true,
  motherCoreMutation: false,
  vaultMutation:      false,
  shellAccess:        false,
  summary:            "All execution boundaries active — descriptor-only phase; no real execution permitted",
} as const;

function buildExecutionPlan(): readonly ExecutionPlanStep[] {
  return CANONICAL_STAGES.map((stage, index): ExecutionPlanStep => ({
    stepIndex: index + 1,
    stage,
    blocked:   true,
    reason:    "executionBlocked=true — descriptor-only phase; no real execution permitted at any stage",
  }));
}

function buildValidationChecks(
  input: CreateControlledExecutionInput,
): readonly ExecutionValidationCheck[] {
  const installPassed =
    input.installRecord.simulationState === "descriptor_simulated";
  const hasPreviewScreens = input.previewRecord.previewScreens.length > 0;

  return VALIDATION_RULES.map((rule): ExecutionValidationCheck => {
    switch (rule) {
      case "experimental_flow_exists":
        return {
          rule,
          passed:  true,
          message: `Experimental production flow record resolved — flowId: ${input.flowRecord.flowId}`,
        };
      case "preview_exists":
        return {
          rule,
          passed:  hasPreviewScreens,
          message: hasPreviewScreens
            ? `Preview pipeline record resolved — ${input.previewRecord.previewScreens.length} screen descriptor(s)`
            : "Preview pipeline record has no screen descriptors",
        };
      case "workspace_exists":
        return {
          rule,
          passed:  true,
          message: `Virtual workspace record resolved — workspaceId: ${input.workspaceRecord.workspaceId}`,
        };
      case "install_simulation_passed":
        return {
          rule,
          passed:  installPassed,
          message: installPassed
            ? "Install simulation reached descriptor_simulated state"
            : "Install simulation did not reach descriptor_simulated state",
        };
      case "execution_policy_present":
        return {
          rule,
          passed:  input.executionPolicyRef.length > 0,
          message: input.executionPolicyRef.length > 0
            ? "Execution policy reference is present"
            : "Execution policy reference is missing",
        };
      case "rollback_preparation_valid":
        return {
          rule,
          passed:  true,
          message: "Rollback preparation descriptor is structurally complete",
        };
      case "output_remains_descriptor_only":
        return {
          rule,
          passed:  true,
          message: "All outputs remain descriptor-only — no real artifact produced",
        };
    }
  });
}

function buildRollbackReport(
  checks: readonly ExecutionValidationCheck[],
): RollbackPreparationReport {
  const allPassed = checks.every((c) => c.passed);
  return {
    rollbackRequired:       true,
    rollbackDescriptorOnly: true,
    rollbackStagesCount:    CANONICAL_STAGES.length,
    rollbackTargetStage:    "validate_execution_context",
    rollbackReady:          allPassed,
    summary:                allPassed
      ? "Rollback preparation complete — all validation checks passed"
      : "Rollback preparation incomplete — one or more validation checks failed",
  };
}

const executionStore = new Map<string, ControlledExecutionRecord>();

export function createControlledExecutionRecord(
  input: CreateControlledExecutionInput,
): { ok: true; record: ControlledExecutionRecord } {
  const controlledExecutionId = randomBytes(8).toString("hex");
  const createdAt             = new Date().toISOString();
  const executionPlan         = buildExecutionPlan();
  const executionValidationChecks = buildValidationChecks(input);
  const rollbackPreparationReport = buildRollbackReport(executionValidationChecks);

  const record: ControlledExecutionRecord = {
    controlledExecutionId,
    createdAt,
    executionState:           "awaiting_operator_execution_approval",
    approvalRequired:         true,
    executionBlocked:         true,
    filesystemBlocked:        true,
    networkBlocked:           true,
    deploymentBlocked:        true,
    autonomousBlocked:        true,
    linkedFlowId:             input.flowRecord.flowId,
    linkedPreviewId:          input.previewRecord.previewId,
    linkedWorkspaceId:        input.workspaceRecord.workspaceId,
    linkedInstallSimId:       input.installRecord.installSimulationId,
    operatorApprovalRef:      input.operatorApprovalRef,
    executionPolicyRef:       input.executionPolicyRef,
    executionPlan,
    executionStages:          CANONICAL_STAGES,
    executionValidationChecks,
    executionBoundaryReport:  BOUNDARY_REPORT,
    rollbackPreparationReport,
  };

  executionStore.set(controlledExecutionId, record);
  return { ok: true, record };
}

export function listControlledExecutionRecords(): ControlledExecutionRecord[] {
  return Array.from(executionStore.values()).sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getControlledExecutionSummary(): ControlledExecutionSummary {
  const records = listControlledExecutionRecords();
  return {
    totalExecutions:      records.length,
    byState:              { awaiting_operator_execution_approval: records.length },
    executionBlocked:     true,
    filesystemBlocked:    true,
    networkBlocked:       true,
    deploymentBlocked:    true,
    autonomousBlocked:    true,
    implementationPhase:  "descriptor_only",
  };
}
