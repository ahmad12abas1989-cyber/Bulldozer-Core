import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { randomBytes } from "node:crypto";
import type { Duplex } from "node:stream";
import { router } from "./core/router";
import { withErrorBoundary } from "./core/errorBoundary";
import { validateRequest } from "./lib/validate";
import { sendError } from "./lib/response";
import { attachRequestId } from "./lib/requestContext";
import { logger } from "./lib/logger";
import { handleUIShell, handleUIOverview, handleUIGovernance, handleUIObservation, handleUIDiagnostics, handleUIComparison } from "./routes/ui";
import { handleHealth } from "./routes/health";
import { handleStatus } from "./routes/status";
import { handleMetrics } from "./routes/metrics";
import { handleHealthFull } from "./routes/healthFull";
import { handleFreeze } from "./routes/freeze";
import { handleCrash } from "./routes/crash";
import { handleSnapshot } from "./routes/snapshot";
import { handleSnapshots } from "./routes/snapshots";
import { handleSnapshotLatest } from "./routes/snapshotLatest";
import { handleSnapshotHistory } from "./routes/snapshotHistory";
import { handleTimeline } from "./routes/timeline";
import { handleEvents } from "./routes/events";
import { handleWatchdog } from "./routes/watchdog";
import { handleRestartSupervisor } from "./routes/restartSupervisor";
import { handlePluginSandbox } from "./routes/pluginSandbox";
import { handleRuntimeState } from "./routes/runtimeState";
import { handleRecoveryTracker } from "./routes/recoveryTracker";
import { handleHardening } from "./routes/hardening";
import { handleConfigStatus } from "./routes/configStatus";
import { handleTasksGet, handleTasksPost } from "./routes/tasks";
import { handleTaskEvaluation } from "./routes/taskEvaluation";
import { handleTaskPolicy } from "./routes/taskPolicy";
import { handleTaskPersistence } from "./routes/taskPersistence";
import { handleQueueOrchestration } from "./routes/queueOrchestration";
import { handleTaskLifecycleGet, handleTaskLifecycleTransitionPost } from "./routes/taskLifecycle";
import {
  handleRuntimeSnapshotsList,
  handleRuntimeSnapshotById,
  handleRuntimeSnapshotsCreate,
  handleRuntimeRecoveryDryRun,
} from "./routes/runtimeSnapshots";
import {
  handleRuntimeEvents,
  handleRuntimeEventsRecent,
  handleRuntimeSubscribers,
} from "./routes/runtimeEvents";
import {
  handleCommandsGet,
  handleCommandsStatus,
  handleCommandsPost,
} from "./routes/commands";
import {
  handleRuntimeRegistryList,
  handleRuntimeRegistryStatus,
  handleRuntimeRegistryByName,
} from "./routes/runtimeRegistry";
import {
  handleDependencyGraphList,
  handleDependencyGraphStatus,
  handleDependencyGraphByName,
} from "./routes/runtimeDependencyGraph";
import {
  handleCapabilityMatrixList,
  handleCapabilityMatrixStatus,
  handleCapabilityMatrixByName,
} from "./routes/runtimeCapabilityMatrix";
import { handleBaselineStatus } from "./routes/baselineStatus";
import { handleAuthObserveStatus } from "./routes/authObserveStatus";
import { handleAuthAuditLog } from "./routes/authAuditLog";
import { handleSessionObserve } from "./routes/sessionObserve";
import { handleRateLimitObserve } from "./routes/rateLimitObserve";
import { handleVaultObserve } from "./routes/vaultObserve";
import { handleSandboxObserve } from "./routes/sandboxObserve";
import { handlePluginObserve } from "./routes/pluginObserve";
import { handleAppFactoryObserve } from "./routes/appFactoryObserve";
import { handleTemplateRegistryObserve } from "./routes/templateRegistryObserve";
import { handleExperimentalGenerationObserve } from "./routes/experimentalGenerationObserve";
import { handleTemplateArtifactObserve } from "./routes/templateArtifactObserve";
import { handleVirtualPackageObserve } from "./routes/virtualPackageObserve";
import { handleDependencyResolutionObserve } from "./routes/dependencyResolutionObserve";
import { handleSandboxBuildObserve } from "./routes/sandboxBuildObserve";
import { handleInstallSimulationObserve } from "./routes/installSimulationObserve";
import { handleVirtualWorkspaceObserve } from "./routes/virtualWorkspaceObserve";
import { handlePreviewPipelineObserve }              from "./routes/previewPipelineObserve";
import { handleExperimentalProductionFlowObserve }   from "./routes/experimentalProductionFlowObserve";
import { handleControlledExecutionObserve }          from "./routes/controlledExecutionObserve";
import { handleIdentityStatus, handleIdentityRoles } from "./routes/identityAccess";
import { handleAccessStatus, handleAccessPolicies } from "./routes/accessEnforcement";
import { handleAuditStatus, handleAuditLog } from "./routes/auditLog";
import { handleSessionStatus, handleSessionRecent } from "./routes/sessionContext";
import { handleLifecycleStatus, handleLifecycleRecent } from "./routes/requestLifecycleLedger";
import { handleDiagnosticsSnapshot } from "./routes/diagnostics";
import { handleStorageStatus } from "./routes/storage";
import {
  handleProjectsGet,
  handleProjectsPost,
  handleProjectById,
  handleProjectPatch,
  handleProjectMembersGet,
  handleProjectMembersPost,
  handleProjectMemberDelete,
  handleProjectActivityGet,
  handleProjectQuotaGet,
  handleProjectQuotaPost,
  handleProjectQuotaDelete,
} from "./routes/projects";
import {
  handleWorkspaceSummary,
  handleWorkspaceProjectsOverview,
  handleWorkspaceHealth,
  handleWorkspaceNavigation,
  handleWorkspacePanelList,
  handleWorkspacePanelById,
  handleWorkspaceSnapshotCreate,
  handleWorkspaceSnapshotList,
  handleWorkspaceSnapshotLatest,
  handleWorkspaceTimeline,
  handleWorkspaceActivityFeed,
  handleWorkspaceDiffList,
  handleWorkspaceDiffBySnapshotIds,
  handleAuditReportCreate,
  handleAuditReportList,
  handleAuditReportById,
  handleAuditDigest,
  handleGovernanceDrift,
  handleDriftHistoryCapture,
  handleDriftHistory,
  handleUIRenderModel,
  handleDashboardSkeleton,
  handleUICoherence,
  handleUILayerVersion,
  handleUILayerSummary,
  handleUIPreviewPayload,
  handleUIIndex,
  handleUINavigation,
  handleUIPages,
  handleUIPagesSummary,
  handleUIHtmlRoutes,
  handleUIPanels,
  handleUIWidgets,
  handleUIBindings,
  handleUIBadges,
  handleUITheme,
  handleUILayout,
  handleUILayerAudit,
  handleUIManifestCatalogue,
  handleGovernanceScorecard,
  handleScorecardHistoryCapture,
  handleScorecardHistoryList,
  handleScorecardHistoryCompare,
  handleScorecardHistoryDetail,
  handleScorecardAnalytics,
  handlePolicyCompliance,
  handleObservationHeatmap,
  handleCoverageTrend,
  handlePolicyExposureIndex,
  handleObservationProbe,
  handleObservationLedger,
  handleComparisonRegistry,
  handleDualComparison,
  handleLedgerHistoryCapture,
  handleLedgerHistoryList,
  handleLedgerHistoryCompare,
  handleLedgerHistoryDetail,
  handleLedgerAnalytics,
  handleVisualShell,
  handleVisualShellComposed,
  handleWidgetContractList,
  handleWidgetContractById,
  handleWidgetValidationProbe,
  handleWidgetValidationCapture,
  handleWidgetValidationHistory,
  handleWidgetValidationHistoryDetail,
  handleWidgetRegistryCoherence,
} from "./routes/workspace";
import {
  applySecurityHeaders,
  getSecurityHeaderLines,
  recordHardeningViolation,
  validateHttpsTransport,
  validateRequestHardening,
  validateForwardedFor,
  resolveClientIp,
} from "./core/hardening";
import { incrementRequests } from "./core/metrics";
import { validateRouteAccess } from "./core/accessEnforcement";
import { appendAuditEntry, type AuditDecision } from "./core/auditLog";
import { createSessionContext, completeSessionLifecycle, type SessionLifecycle } from "./core/sessionContext";
import { resolveRequestIdentity, type ResolvedIdentity } from "./core/identityAccess";
import { checkRateLimit, recordRateLimitAnomaly } from "./core/rateLimiter";
import { resolveApiKeyIdentity } from "./core/apiKeyAuth";
import { appendLifecycleRecord } from "./core/requestLifecycleLedger";
import { updateAuditEntryLifecycle, type AuditLifecycle } from "./core/auditLog";
import { MAX_BODY_BYTES } from "./lib/body";

router.get("/api/healthz", handleHealth);
router.get("/api/status", handleStatus);
router.get("/api/metrics", handleMetrics);
router.get("/api/health/full", handleHealthFull);
router.get("/api/freeze", handleFreeze);
router.get("/api/crash", handleCrash);
router.get("/api/snapshot", handleSnapshot);
router.get("/api/snapshots", handleSnapshots);
router.get("/api/snapshot/latest", handleSnapshotLatest);
router.get("/api/snapshot/history", handleSnapshotHistory);
router.get("/api/timeline", handleTimeline);
router.get("/api/events", handleEvents);
router.get("/api/watchdog", handleWatchdog);
router.get("/api/restart-supervisor", handleRestartSupervisor);
router.get("/api/plugin-sandbox", handlePluginSandbox);
router.get("/api/runtime-state", handleRuntimeState);
router.get("/api/recovery-tracker", handleRecoveryTracker);
router.get("/api/hardening", handleHardening);
router.get("/api/config/status", handleConfigStatus);
router.get("/api/tasks", handleTasksGet);
router.post("/api/tasks", handleTasksPost);
router.get("/api/task-evaluation", handleTaskEvaluation);
router.get("/api/task-policy", handleTaskPolicy);
router.get("/api/tasks/persistence", handleTaskPersistence);
router.get("/api/queue/orchestration", handleQueueOrchestration);
router.get("/api/tasks/lifecycle", handleTaskLifecycleGet);
router.post("/api/tasks/lifecycle/transition", handleTaskLifecycleTransitionPost);
router.get("/api/runtime/snapshots", handleRuntimeSnapshotsList);
router.get("/api/runtime/snapshots/:id", handleRuntimeSnapshotById);
router.post("/api/runtime/snapshots/create", handleRuntimeSnapshotsCreate);
router.post("/api/runtime/recovery/dry-run", handleRuntimeRecoveryDryRun);
router.get("/api/runtime/events", handleRuntimeEvents);
router.get("/api/runtime/events/recent", handleRuntimeEventsRecent);
router.get("/api/runtime/subscribers", handleRuntimeSubscribers);
router.get("/api/commands", handleCommandsGet);
router.get("/api/commands/status", handleCommandsStatus);
router.post("/api/commands", handleCommandsPost);
router.get("/api/runtime/registry", handleRuntimeRegistryList);
router.get("/api/runtime/registry/status", handleRuntimeRegistryStatus);
router.get("/api/runtime/registry/:subsystemName", handleRuntimeRegistryByName);
router.get("/api/runtime/graph", handleDependencyGraphList);
router.get("/api/runtime/graph/status", handleDependencyGraphStatus);
router.get("/api/runtime/graph/:subsystemName", handleDependencyGraphByName);
router.get("/api/runtime/capabilities", handleCapabilityMatrixList);
router.get("/api/runtime/capabilities/status", handleCapabilityMatrixStatus);
router.get("/api/runtime/capabilities/:subsystemName", handleCapabilityMatrixByName);
router.get("/api/baseline/status", handleBaselineStatus);
router.get("/api/identity/status", handleIdentityStatus);
router.get("/api/identity/roles", handleIdentityRoles);
router.get("/api/access/status", handleAccessStatus);
router.get("/api/access/policies", handleAccessPolicies);
router.get("/api/audit/status", handleAuditStatus);
router.get("/api/audit/log", handleAuditLog);
router.get("/api/session/status", handleSessionStatus);
router.get("/api/session/recent", handleSessionRecent);
router.get("/api/lifecycle/status", handleLifecycleStatus);
router.get("/api/lifecycle/recent", handleLifecycleRecent);
router.get("/api/diagnostics/snapshot", handleDiagnosticsSnapshot);
router.get("/api/storage/status", handleStorageStatus);
router.get("/api/projects", handleProjectsGet);
router.post("/api/projects", handleProjectsPost);
router.get("/api/projects/:id", handleProjectById);
router.patch("/api/projects/:id", handleProjectPatch);
router.get("/api/projects/:id/members", handleProjectMembersGet);
router.post("/api/projects/:id/members", handleProjectMembersPost);
router.delete("/api/projects/:id/members/:actorId", handleProjectMemberDelete);
router.get("/api/projects/:id/activity", handleProjectActivityGet);
router.get("/api/projects/:id/quotas", handleProjectQuotaGet);
router.post("/api/projects/:id/quotas", handleProjectQuotaPost);
router.delete("/api/projects/:id/quotas", handleProjectQuotaDelete);
router.get("/api/workspace/summary", handleWorkspaceSummary);
router.get("/api/workspace/projects/overview", handleWorkspaceProjectsOverview);
router.get("/api/workspace/health", handleWorkspaceHealth);
router.get("/api/workspace/navigation", handleWorkspaceNavigation);
router.get("/api/workspace/panels", handleWorkspacePanelList);
router.get("/api/workspace/panels/:panelId", handleWorkspacePanelById);
router.post("/api/workspace/snapshots/create", handleWorkspaceSnapshotCreate);
router.get("/api/workspace/snapshots", handleWorkspaceSnapshotList);
router.get("/api/workspace/snapshot/latest", handleWorkspaceSnapshotLatest);
router.get("/api/workspace/timeline", handleWorkspaceTimeline);
router.get("/api/workspace/activity-feed", handleWorkspaceActivityFeed);
router.get("/api/workspace/diff", handleWorkspaceDiffList);
router.get("/api/workspace/diff/:fromSnapshotId/:toSnapshotId", handleWorkspaceDiffBySnapshotIds);
router.post("/api/workspace/audit/report", handleAuditReportCreate);
router.get("/api/workspace/audit/reports", handleAuditReportList);
router.get("/api/workspace/audit/reports/:reportId", handleAuditReportById);
router.get("/api/workspace/audit/digest", handleAuditDigest);
router.get("/api/workspace/governance/drift", handleGovernanceDrift);
router.post("/api/workspace/governance/drift/capture", handleDriftHistoryCapture);
router.get("/api/workspace/governance/drift/history", handleDriftHistory);
router.get("/api/workspace/governance/scorecard", handleGovernanceScorecard);
router.post("/api/workspace/governance/scorecard/capture", handleScorecardHistoryCapture);
router.get("/api/workspace/governance/scorecard/history", handleScorecardHistoryList);
router.get("/api/workspace/governance/scorecard/history/compare", handleScorecardHistoryCompare);
router.get("/api/workspace/governance/scorecard/history/:captureSeq", handleScorecardHistoryDetail);
router.get("/api/workspace/governance/scorecard/analytics", handleScorecardAnalytics);
router.get("/api/workspace/policy/compliance", handlePolicyCompliance);
router.get("/api/workspace/observation/heatmap", handleObservationHeatmap);
router.get("/api/workspace/observation/trend", handleCoverageTrend);
router.get("/api/workspace/observation/exposure", handlePolicyExposureIndex);
router.get("/api/workspace/observation/probe", handleObservationProbe);
router.get("/api/workspace/observation/ledger", handleObservationLedger);
router.get("/api/workspace/comparison/dual", handleDualComparison);
router.get("/api/workspace/comparison/registry", handleComparisonRegistry);
router.post("/api/workspace/observation/ledger/capture", handleLedgerHistoryCapture);
router.get("/api/workspace/observation/ledger/history", handleLedgerHistoryList);
router.get("/api/workspace/observation/ledger/history/compare", handleLedgerHistoryCompare);
router.get("/api/workspace/observation/ledger/history/:captureSeq", handleLedgerHistoryDetail);
router.get("/api/workspace/observation/ledger/analytics", handleLedgerAnalytics);
router.get("/api/workspace/ui",            handleUIIndex);
router.get("/api/workspace/ui/navigation", handleUINavigation);
router.get("/api/workspace/ui/pages",         handleUIPages);
router.get("/api/workspace/ui/pages/summary", handleUIPagesSummary);
router.get("/api/workspace/ui/html-routes",   handleUIHtmlRoutes);
router.get("/api/workspace/ui/panels",        handleUIPanels);
router.get("/api/workspace/ui/widgets",    handleUIWidgets);
router.get("/api/workspace/ui/bindings",   handleUIBindings);
router.get("/api/workspace/ui/badges",     handleUIBadges);
router.get("/api/workspace/ui/theme",      handleUITheme);
router.get("/api/workspace/ui/layout",     handleUILayout);
router.get("/api/workspace/ui/audit",      handleUILayerAudit);
router.get("/api/workspace/ui/catalogue",  handleUIManifestCatalogue);
router.get("/api/workspace/ui/coherence", handleUICoherence);
router.get("/api/workspace/ui/version", handleUILayerVersion);
router.get("/api/workspace/ui/summary", handleUILayerSummary);
router.get("/api/workspace/ui/preview", handleUIPreviewPayload);
router.get("/api/workspace/ui/render-model", handleUIRenderModel);
router.get("/api/workspace/ui/dashboard-skeleton", handleDashboardSkeleton);
router.get("/api/workspace/visual-shell", handleVisualShell);
router.get("/api/workspace/visual-shell/composed", handleVisualShellComposed);
router.get("/api/workspace/visual-shell/widgets/registry/coherence", handleWidgetRegistryCoherence);
router.get("/api/workspace/visual-shell/widgets", handleWidgetContractList);
router.get("/api/workspace/visual-shell/widgets/validate", handleWidgetValidationProbe);
router.post("/api/workspace/visual-shell/widgets/validate/capture", handleWidgetValidationCapture);
router.get("/api/workspace/visual-shell/widgets/validate/history", handleWidgetValidationHistory);
router.get("/api/workspace/visual-shell/widgets/validate/history/:captureSeq", handleWidgetValidationHistoryDetail);
router.get("/api/workspace/visual-shell/widgets/:widgetId", handleWidgetContractById);
router.get("/api/auth/observe-status", handleAuthObserveStatus);
router.get("/api/auth/audit-log", handleAuthAuditLog);
router.get("/api/auth/sessions", handleSessionObserve);
router.get("/api/auth/rate-limit", handleRateLimitObserve);
router.get("/api/auth/vault", handleVaultObserve);
router.get("/api/sandbox/runs", handleSandboxObserve);
router.get("/api/plugins/registry", handlePluginObserve);
router.get("/api/factory/requests",   handleAppFactoryObserve);
router.get("/api/templates/registry",       handleTemplateRegistryObserve);
router.get("/api/generation/experimental",  handleExperimentalGenerationObserve);
router.get("/api/artifacts/virtual",        handleTemplateArtifactObserve);
router.get("/api/packages/virtual",         handleVirtualPackageObserve);
router.get("/api/resolution/dependencies",  handleDependencyResolutionObserve);
router.get("/api/sandbox/build/plans",      handleSandboxBuildObserve);
router.get("/api/install/simulations",      handleInstallSimulationObserve);
router.get("/api/workspaces/virtual",       handleVirtualWorkspaceObserve);
router.get("/api/preview/pipelines",                    handlePreviewPipelineObserve);
router.get("/api/production/experimental-flows",        handleExperimentalProductionFlowObserve);
router.get("/api/execution/controlled",                 handleControlledExecutionObserve);
router.get("/ui",             handleUIShell);
router.get("/ui/overview",   handleUIOverview);
router.get("/ui/governance",  handleUIGovernance);
router.get("/ui/observation", handleUIObservation);
router.get("/ui/diagnostics", handleUIDiagnostics);
router.get("/ui/comparison",  handleUIComparison);

function dispatch(req: IncomingMessage, res: ServerResponse): void {
  const requestId = attachRequestId(req);
  const log = logger.child({ requestId });
  const start = Date.now();
  const startedAt = new Date().toISOString();

  res.setHeader("x-request-id", requestId);
  applySecurityHeaders(res);
  incrementRequests();

  let resolvedCtx: ReturnType<typeof createSessionContext> | null = null;

  res.on("finish", () => {
    const method = req.method ?? "GET";
    const path = (req.url ?? "/").split("?")[0];
    const latencyMs = Date.now() - start;
    const finishedAt = new Date().toISOString();
    const statusCode = res.statusCode;

    log.info({ method, path, statusCode, durationMs: latencyMs }, "Request completed");

    if (resolvedCtx !== null) {
      const lifecycle: SessionLifecycle & AuditLifecycle = { statusCode, latencyMs, finishedAt };
      appendLifecycleRecord({
        requestId,
        correlationId: resolvedCtx.correlationId,
        method,
        route: path,
        startedAt,
        finishedAt,
        statusCode,
        latencyMs,
      });
      completeSessionLifecycle(requestId, lifecycle);
      updateAuditEntryLifecycle(requestId, lifecycle);
    }
  });

  const validation = validateRequest(req);

  if (!validation.ok) {
    const rawPath = (req.url ?? "/").split("?")[0];
    const violationType = validation.status === 405 ? "method_not_allowed" : "malformed_url";
    recordHardeningViolation(violationType, rawPath, validation.message, true);
    log.warn({ method: req.method, url: req.url, status: validation.status }, validation.message);
    sendError(res, validation.status, validation.message);
    return;
  }

  const { method, path } = validation;

  const hardeningResult = validateRequestHardening(req);
  if (hardeningResult.blocked) {
    recordHardeningViolation(hardeningResult.type, path, hardeningResult.reason, true);
    log.warn({ method, path, type: hardeningResult.type }, hardeningResult.reason);
    sendError(res, hardeningResult.httpStatus, "Bad Request");
    return;
  }
  if (hardeningResult.warned) {
    recordHardeningViolation(hardeningResult.type, path, hardeningResult.reason, false);
    log.warn({ method, path, type: hardeningResult.type }, hardeningResult.reason);
  }

  const httpsResult = validateHttpsTransport(req);
  if (httpsResult.blocked) {
    recordHardeningViolation(httpsResult.type, path, httpsResult.reason, true);
    log.warn({ method, path, type: httpsResult.type }, httpsResult.reason);
    sendError(res, httpsResult.httpStatus, "Bad Request");
    return;
  }

  const xffResult = validateForwardedFor(req);
  if (xffResult.blocked) {
    recordHardeningViolation(xffResult.type, path, xffResult.reason, true);
    log.warn({ method, path, type: xffResult.type }, xffResult.reason);
    sendError(res, xffResult.httpStatus, "Bad Request");
    return;
  }

  const rawContentLength = req.headers["content-length"];
  if (rawContentLength !== undefined) {
    const contentLength = Number(rawContentLength);
    if (!Number.isFinite(contentLength) || contentLength < 0) {
      log.warn({ method, path, contentLengthRaw: rawContentLength }, "Invalid Content-Length header rejected");
      sendError(res, 400, "Invalid Content-Length");
      return;
    }
    if (contentLength > MAX_BODY_BYTES) {
      log.warn({ method, path, contentLength, maxBytes: MAX_BODY_BYTES }, "Request body too large");
      sendError(res, 413, "Payload Too Large");
      return;
    }
  }

  log.info({ method, path }, "Request received");

  const rawCorrelationId = req.headers["x-correlation-id"];
  const correlationId = typeof rawCorrelationId === "string" ? rawCorrelationId : undefined;

  const rawApiKey = req.headers["x-api-key"];
  let identity: ResolvedIdentity;
  let authSource: string;

  if (typeof rawApiKey === "string" && rawApiKey.length > 0) {
    const apiKeyResult = resolveApiKeyIdentity(rawApiKey);
    if (apiKeyResult.valid && apiKeyResult.identity !== null) {
      identity = apiKeyResult.identity;
      authSource = "api_key";
    } else {
      identity = { actorType: "anonymous", role: "guest", actorId: undefined, source: "default" };
      authSource = "invalid_api_key";
    }
  } else {
    const rawActorId = req.headers["x-actor-id"];
    const rawActorType = req.headers["x-actor-type"];
    const rawRole = req.headers["x-role"];
    identity = resolveRequestIdentity(
      typeof rawActorId === "string" ? rawActorId : undefined,
      typeof rawActorType === "string" ? rawActorType : undefined,
      typeof rawRole === "string" ? rawRole : undefined,
    );
    authSource = identity.source;
  }

  if (path !== "/api/healthz") {
    const rl = checkRateLimit(identity.actorType, identity.role, identity.actorId);
    if (!rl.allowed) {
      const retryAfterSec = Math.max(1, Math.ceil((rl.windowStart + rl.windowMs - Date.now()) / 1000));
      log.warn(
        {
          method,
          path,
          identityKey: rl.identityKey,
          requestCount: rl.requestCount,
          windowLimit: rl.windowLimit,
          retryAfterSec,
        },
        "Rate limit exceeded",
      );
      recordRateLimitAnomaly({
        timestamp: new Date().toISOString(),
        identityKey: rl.identityKey,
        route: path,
        method,
        retryAfterSeconds: retryAfterSec,
        blockedCount: rl.blockedCount,
        executionBlocked: true,
      });
      res.setHeader("retry-after", String(retryAfterSec));
      sendError(res, 429, "Too Many Requests");
      return;
    }
  }

  const sessionCtx = createSessionContext({
    requestId,
    method,
    route: path,
    correlationId,
    actorType: identity.actorType,
    role: identity.role,
    actorId: identity.actorId,
    remoteAddress: req.socket?.remoteAddress,
    clientIp: resolveClientIp(req),
  });
  resolvedCtx = sessionCtx;

  res.setHeader("x-correlation-id", sessionCtx.correlationId);

  const accessResult = validateRouteAccess(method, path, sessionCtx.role);
  const decision: AuditDecision = accessResult.reason.startsWith("No access policy")
    ? "no_policy"
    : accessResult.allowed
      ? "allowed"
      : "denied";
  appendAuditEntry({
    requestId,
    correlationId: sessionCtx.correlationId,
    method,
    route: path,
    role: sessionCtx.role,
    actorType: sessionCtx.actorType,
    actorId: sessionCtx.actorId,
    authSource,
    permission: accessResult.permission,
    minimumRole: accessResult.minimumRole,
    decision,
    reason: accessResult.reason,
    enforcementMode: accessResult.enforcementMode,
  });

  const handler = router.resolve(method, path);

  if (!handler) {
    log.warn({ method, path }, "Route not found");
    sendError(res, 404, "Not Found");
    return;
  }

  withErrorBoundary(handler)(req, res);
}

export function createHttpServer() {
  const server = createServer(dispatch);

  server.on("clientError", (_err: Error, socket: Duplex) => {
    if (!socket.writable) return;
    const requestId = randomBytes(8).toString("hex");
    const body = JSON.stringify({ error: "Bad Request" });
    const headerLines = [
      "HTTP/1.1 400 Bad Request",
      `x-request-id: ${requestId}`,
      "content-type: application/json",
      `content-length: ${Buffer.byteLength(body)}`,
      "connection: close",
      ...getSecurityHeaderLines(),
    ];
    socket.write(headerLines.join("\r\n") + "\r\n\r\n" + body);
    socket.end();
  });

  return server;
}
