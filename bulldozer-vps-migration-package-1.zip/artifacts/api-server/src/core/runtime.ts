import { config } from "./config";
import { pluginManager } from "./plugins";
import { registerShutdown } from "./shutdown";
import { logger } from "../lib/logger";
import { createHttpServer } from "../server";
import { startFreezeDetector } from "./freezeDetector";
import { startCrashDetector } from "./crashDetector";
import { startWatchdog } from "./watchdog";
import { initRuntimeStatePersistence, saveRuntimeState } from "./runtimeState";
import { initRecoveryTracking } from "./recoveryTracker";
import { initTaskPolicy } from "./taskPolicy";
import { initTaskPersistence } from "./taskPersistence";
import { initTaskEvaluation } from "./taskEvaluation";
import { initQueueOrchestrator } from "./queueOrchestrator";
import { initTaskLifecycle } from "./taskLifecycle";
import { createSnapshot } from "./snapshots";
import { initRuntimeSnapshotSystem, createRuntimeSnapshot } from "./runtimeSnapshot";
import { initRuntimeEventBus, emitRuntimeEvent } from "./runtimeEventBus";
import { initCommandGateway } from "./commandGateway";
import { initRuntimeStateRegistry } from "./runtimeStateRegistry";
import { initRuntimeDependencyGraph } from "./runtimeDependencyGraph";
import { initCapabilityMatrix } from "./runtimeCapabilityMatrix";
import { initBaseline } from "./baseline";
import { initIdentityAccess } from "./identityAccess";
import { initAccessEnforcement } from "./accessEnforcement";
import { initAuditLog } from "./auditLog";
import { initSessionContext } from "./sessionContext";
import { initRequestLifecycleLedger } from "./requestLifecycleLedger";
import { initPersistentStore } from "./persistentStore";
import { initRateLimiter } from "./rateLimiter";
import { initApiKeyAuth } from "./apiKeyAuth";
import { initSecretVault } from "./secretVault";
import { initProjectRegistry, initProjectMembers, initProjectActivity, initProjectQuotas } from "./projectRegistry";
import { initWorkspaceSnapshots } from "./workspaceSnapshots";
import { initWorkspaceAuditReports } from "./workspaceAuditReport";
import { initWorkspaceObservationLedgerHistory } from "./workspaceObservationLedgerHistory";
import { initWorkspaceWidgetValidationHistory } from "./workspaceWidgetValidationHistory";
import { initWorkspaceGovernanceScorecardHistory } from "./workspaceGovernanceScorecardHistory";
import { initWorkspaceGovernanceDriftHistory } from "./workspaceGovernanceDriftHistory";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";

export type RuntimeStatus = "starting" | "ready" | "stopping" | "stopped" | "failed";

export interface RuntimeInfo {
  state: RuntimeStatus;
  uptimeMs: number;
  env: string;
  port: number;
  pluginCount: number;
  timestamp: string;
}

let status: RuntimeStatus = "starting";
let startTime: number = Date.now();

export function getRuntimeStatus(): RuntimeStatus {
  return status;
}

export function setRuntimeStatus(next: RuntimeStatus): void {
  status = next;
}

export function getRuntimeInfo(): RuntimeInfo {
  return {
    state: status,
    uptimeMs: Date.now() - startTime,
    env: config.nodeEnv,
    port: config.port,
    pluginCount: pluginManager.list().length,
    timestamp: new Date().toISOString(),
  };
}

export async function startRuntime(): Promise<void> {
  startTime = Date.now();
  status = "starting";
  startCrashDetector();
  addTimelineEvent({ level: "info", source: "runtime", message: "Runtime starting", metadata: { env: config.nodeEnv } });
  emit("runtime:starting", "runtime", { env: config.nodeEnv });

  logger.info({ env: config.nodeEnv }, "Bulldozer Core starting");

  try {
    await pluginManager.loadAll();

    const server = createHttpServer();
    registerShutdown(server);

    await new Promise<void>((resolve, reject) => {
      server.listen(config.port, () => {
        logger.info({ port: config.port }, "HTTP server listening");
        resolve();
      });

      server.on("error", (err: Error) => {
        logger.error({ err: String(err) }, "HTTP server error");
        reject(err);
      });
    });

    status = "ready";
    addTimelineEvent({ level: "info", source: "runtime", message: "Runtime ready", metadata: { port: config.port } });
    emit("runtime:ready", "runtime", { port: config.port });
    startFreezeDetector();
    startWatchdog();
    initPersistentStore();
    initRuntimeStatePersistence();
    initRecoveryTracking();
    initTaskPolicy();
    initTaskPersistence();
    initTaskEvaluation();
    initQueueOrchestrator();
    initTaskLifecycle();
    initRuntimeSnapshotSystem();
    initRuntimeEventBus();
    initCommandGateway();
    initRuntimeStateRegistry();
    initIdentityAccess();
    initAccessEnforcement();
    initAuditLog();
    initSessionContext();
    initRequestLifecycleLedger();
    initRateLimiter();
    initApiKeyAuth();
    initSecretVault();
    initProjectRegistry();
    initProjectMembers();
    initProjectActivity();
    initProjectQuotas();
    initWorkspaceSnapshots();
    initWorkspaceAuditReports();
    initWorkspaceObservationLedgerHistory();
    initWorkspaceWidgetValidationHistory();
    initWorkspaceGovernanceScorecardHistory();
    initWorkspaceGovernanceDriftHistory();
    initRuntimeDependencyGraph();
    initCapabilityMatrix();
    initBaseline();
    emitRuntimeEvent({
      eventType: "runtime.ready",
      source: "runtime",
      severity: "info",
      category: "runtime",
      payload: { port: config.port, env: config.nodeEnv },
    });
    createSnapshot("startup");
    createRuntimeSnapshot("startup");
    saveRuntimeState();
    logger.info({ plugins: pluginManager.list() }, "Bulldozer Core ready");
  } catch (err) {
    status = "failed";
    addTimelineEvent({ level: "error", source: "runtime", message: "Runtime failed to start", metadata: { err: String(err) } });
    emit("runtime:failed", "runtime", { err: String(err) });
    logger.error({ err: String(err) }, "Bulldozer Core failed to start");
    throw err;
  }
}
