import { randomBytes } from "node:crypto";
import {
  mkdirSync,
  writeFileSync,
  readFileSync,
  readdirSync,
  renameSync,
  existsSync,
} from "node:fs";
import { join } from "node:path";
import { logger } from "../lib/logger";
import { config } from "./config";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { getRuntimeInfo } from "./runtime";
import { getTaskQueueStatus } from "./taskQueue";
import { getTaskLifecycleStatus } from "./taskLifecycle";
import { getTaskPolicyStatus } from "./taskPolicy";
import { getQueueOrchestrationStatus } from "./queueOrchestrator";
import { getTaskPersistenceStatus } from "./taskPersistence";
import { router } from "./router";

const STORAGE_DIR = join(config.storageDir, "runtime-snapshots");
const ACTIVE_DIR = join(STORAGE_DIR, "active");
const ARCHIVED_DIR = join(STORAGE_DIR, "archived");
const MAX_ACTIVE_SNAPSHOTS = 50;
const RETENTION_WARN_THRESHOLD = Math.floor(MAX_ACTIVE_SNAPSHOTS * 0.8);
const HEALTH_CHECK_COUNT = 36;
const SNAPSHOT_VERSION = 1 as const;
const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;
const MAX_QUERY_LIMIT = 100;
const DEFAULT_QUERY_LIMIT = 50;

export type RuntimeSnapshotStatus = "active" | "archived";
export type OverallHealthStatus = "healthy" | "degraded" | "unknown";
export type ImpactLevel = "minimal" | "moderate" | "significant";

export interface RuntimeSnapshot {
  id: string;
  version: 1;
  status: RuntimeSnapshotStatus;
  reason: string;
  createdAt: string;
  endpointCount: number;
  healthCheckCount: number;
  executionBlocked: true;
  runtime: {
    state: string;
    uptimeMs: number;
    env: string;
    port: number;
    pluginCount: number;
  };
  healthSummary: {
    overallStatus: OverallHealthStatus;
    note: string;
  };
  queueStats: {
    totalTasks: number;
    queuedTasks: number;
    blockedTasks: number;
    executionBlocked: true;
  };
  lifecycleStats: {
    operational: boolean;
    trackedTaskCount: number;
    totalTransitions: number;
    allowedTransitions: number;
    rejectedTransitions: number;
  };
  policyStats: {
    totalPolicyEvaluations: number;
    allowedCount: number;
    warningCount: number;
    blockedCount: number;
    approvalRequiredCount: number;
    executionBlocked: true;
  };
  orchestratorStats: {
    orchestrationMode: string;
    totalQueued: number;
    readyCount: number;
    blockedCount: number;
    approvalRequiredCount: number;
    warningCount: number;
  };
  persistenceStats: {
    operational: boolean;
    persistedTaskCount: number;
    loadedTaskCount: number;
  };
}

export interface RuntimeSnapshotSummary {
  id: string;
  status: RuntimeSnapshotStatus;
  reason: string;
  createdAt: string;
  overallHealth: OverallHealthStatus;
  endpointCount: number;
  healthCheckCount: number;
}

export interface SnapshotListResult {
  active: RuntimeSnapshotSummary[];
  archived: RuntimeSnapshotSummary[];
  totalActive: number;
  totalArchived: number;
  total: number;
  maxActiveSnapshots: number;
  executionBlocked: true;
  timestamp: string;
}

export interface SnapshotFilter {
  status?: string;
  triggeredBy?: string;
  snapshotType?: string;
  subsystem?: string;
  limit?: number;
}

export interface SnapshotFilterResult {
  active: RuntimeSnapshotSummary[];
  archived: RuntimeSnapshotSummary[];
  totalActive: number;
  totalArchived: number;
  filteredCount: number;
  total: number;
  limit: number;
  filtersApplied: Record<string, string>;
  maxActiveSnapshots: number;
  executionBlocked: true;
  timestamp: string;
}

export interface SnapshotValidationResult {
  snapshotId: string;
  isValid: boolean;
  validationErrors: string[];
  fieldCount: number;
  recoveryBlocked: true;
  executionBlocked: true;
  timestamp: string;
}

export interface RecoveryImpactEstimate {
  snapshotId: string;
  snapshotAge: string;
  snapshotAgeMs: number;
  estimatedImpact: ImpactLevel;
  affectedSystems: string[];
  warnings: string[];
  recoveryBlocked: true;
  executionBlocked: true;
  note: string;
  timestamp: string;
}

export interface DryRunRecoveryResult {
  snapshotId: string;
  dryRun: true;
  wouldRestore: string[];
  blockedSteps: string[];
  phasesPlanned: number;
  recoveryBlocked: true;
  executionBlocked: true;
  plannedAt: string;
  note: string;
}

export interface SnapshotComparisonResult {
  snapshotIdA: string;
  snapshotIdB: string;
  createdAtA: string;
  createdAtB: string;
  timeDeltaMs: number;
  diffs: {
    runtime: {
      stateDelta: { a: string; b: string; changed: boolean };
      uptimeDeltaMs: number;
      pluginCountDelta: { a: number; b: number; changed: boolean };
    };
    queueStats: {
      totalTasksDelta: number;
      blockedTasksDelta: number;
    };
    lifecycleStats: {
      transitionsDelta: number;
      rejectedTransitionsDelta: number;
      trackedTaskCountDelta: number;
    };
    policyStats: {
      evaluationsDelta: number;
      blockedCountDelta: number;
      approvalRequiredDelta: number;
    };
    endpointCountDelta: { a: number; b: number; changed: boolean };
    healthCheckCountDelta: { a: number; b: number; changed: boolean };
  };
  executionBlocked: true;
  timestamp: string;
}

export interface RuntimeSnapshotSystemStatus {
  operational: boolean;
  activeSnapshotCount: number;
  archivedSnapshotCount: number;
  maxActiveSnapshots: number;
  retentionNearLimit: boolean;
  lastSnapshotAt: string | null;
  lastSnapshotReason: string | null;
  executionBlocked: true;
  timestamp: string;
}

let isOperational = false;
let lastSnapshotAt: string | null = null;
let lastSnapshotReason: string | null = null;
let totalSnapshotsCreated = 0;
let totalArchived = 0;
let lastStorageError: string | null = null;

function ensureStorageDirs(): void {
  mkdirSync(ACTIVE_DIR, { recursive: true });
  mkdirSync(ARCHIVED_DIR, { recursive: true });
}

function snapshotFileName(id: string, createdAt: string): string {
  const ts = createdAt.replace(/[:.]/g, "-");
  return `${ts}-${id}.json`;
}

function listDir(dir: string): string[] {
  if (!existsSync(dir)) return [];
  return readdirSync(dir)
    .filter((f) => f.endsWith(".json") && !f.endsWith(".tmp.json"))
    .sort();
}

function archiveOldest(): void {
  const activeFiles = listDir(ACTIVE_DIR);
  if (activeFiles.length <= MAX_ACTIVE_SNAPSHOTS) return;
  const toArchive = activeFiles.slice(0, activeFiles.length - MAX_ACTIVE_SNAPSHOTS);
  for (const f of toArchive) {
    try {
      renameSync(join(ACTIVE_DIR, f), join(ARCHIVED_DIR, f));
      totalArchived++;
      emit("runtime_snapshot:archived", "runtime-snapshot", { file: f });
      logger.info({ file: f }, "Runtime snapshot auto-archived (retention limit reached)");
    } catch (err) {
      lastStorageError = String(err);
      logger.warn({ file: f, err: String(err) }, "Failed to archive runtime snapshot");
    }
  }
}

function findSnapshotFile(
  snapshotId: string,
): { path: string; status: RuntimeSnapshotStatus } | null {
  const activeFiles = listDir(ACTIVE_DIR);
  const activeFile = activeFiles.find((f) => f.endsWith(`-${snapshotId}.json`));
  if (activeFile) return { path: join(ACTIVE_DIR, activeFile), status: "active" };

  const archivedFiles = listDir(ARCHIVED_DIR);
  const archivedFile = archivedFiles.find((f) => f.endsWith(`-${snapshotId}.json`));
  if (archivedFile) return { path: join(ARCHIVED_DIR, archivedFile), status: "archived" };

  return null;
}

function readSnapshotFile(filePath: string): RuntimeSnapshot | null {
  try {
    const raw = readFileSync(filePath, "utf8");
    return JSON.parse(raw) as RuntimeSnapshot;
  } catch (err) {
    lastStorageError = String(err);
    logger.warn({ filePath, err: String(err) }, "Failed to read runtime snapshot file");
    return null;
  }
}

function toSummary(
  file: string,
  dir: string,
  status: RuntimeSnapshotStatus,
): RuntimeSnapshotSummary | null {
  const snap = readSnapshotFile(join(dir, file));
  if (!snap) return null;
  return {
    id: snap.id,
    status,
    reason: snap.reason,
    createdAt: snap.createdAt,
    overallHealth: snap.healthSummary.overallStatus,
    endpointCount: snap.endpointCount,
    healthCheckCount: snap.healthCheckCount,
  };
}

function deriveHealthSummary(
  runtimeState: string,
  rejectedTransitions: number,
  blockedTasks: number,
  policyBlockedCount: number,
): { overallStatus: OverallHealthStatus; note: string } {
  if (runtimeState !== "ready") {
    return {
      overallStatus: "unknown",
      note: `Runtime state is "${runtimeState}" — system not fully ready`,
    };
  }
  if (rejectedTransitions > 0 || blockedTasks > 0 || policyBlockedCount > 0) {
    const parts: string[] = [];
    if (rejectedTransitions > 0) parts.push(`${rejectedTransitions} rejected lifecycle transition(s)`);
    if (blockedTasks > 0) parts.push(`${blockedTasks} blocked task(s)`);
    if (policyBlockedCount > 0) parts.push(`${policyBlockedCount} policy-blocked decision(s)`);
    return {
      overallStatus: "degraded",
      note: `Runtime ready with anomalies: ${parts.join(", ")}`,
    };
  }
  return {
    overallStatus: "healthy",
    note: "Runtime ready — no anomalies detected at snapshot time",
  };
}

export function createRuntimeSnapshot(reason = "manual"): RuntimeSnapshot {
  ensureStorageDirs();

  const id = randomBytes(8).toString("hex");
  const createdAt = new Date().toISOString();

  const runtimeInfo = getRuntimeInfo();
  const queueStatus = getTaskQueueStatus();
  const lifecycleStatus = getTaskLifecycleStatus();
  const policyStatus = getTaskPolicyStatus();
  const orchestratorStatus = getQueueOrchestrationStatus();
  const persistenceStatus = getTaskPersistenceStatus();
  const endpointCount = router.list().length;

  const { overallStatus, note } = deriveHealthSummary(
    runtimeInfo.state,
    lifecycleStatus.rejectedTransitions,
    queueStatus.blockedTasks,
    policyStatus.blockedCount,
  );

  const snapshot: RuntimeSnapshot = {
    id,
    version: SNAPSHOT_VERSION,
    status: "active",
    reason,
    createdAt,
    endpointCount,
    healthCheckCount: HEALTH_CHECK_COUNT,
    executionBlocked: EXECUTION_BLOCKED,
    runtime: {
      state: runtimeInfo.state,
      uptimeMs: runtimeInfo.uptimeMs,
      env: runtimeInfo.env,
      port: runtimeInfo.port,
      pluginCount: runtimeInfo.pluginCount,
    },
    healthSummary: { overallStatus, note },
    queueStats: {
      totalTasks: queueStatus.totalTasks,
      queuedTasks: queueStatus.queuedTasks,
      blockedTasks: queueStatus.blockedTasks,
      executionBlocked: EXECUTION_BLOCKED,
    },
    lifecycleStats: {
      operational: lifecycleStatus.operational,
      trackedTaskCount: lifecycleStatus.trackedTaskCount,
      totalTransitions: lifecycleStatus.totalTransitions,
      allowedTransitions: lifecycleStatus.allowedTransitions,
      rejectedTransitions: lifecycleStatus.rejectedTransitions,
    },
    policyStats: {
      totalPolicyEvaluations: policyStatus.totalPolicyEvaluations,
      allowedCount: policyStatus.allowedCount,
      warningCount: policyStatus.warningCount,
      blockedCount: policyStatus.blockedCount,
      approvalRequiredCount: policyStatus.approvalRequiredCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
    orchestratorStats: {
      orchestrationMode: orchestratorStatus.orchestrationMode,
      totalQueued: orchestratorStatus.totalQueued,
      readyCount: orchestratorStatus.readyCount,
      blockedCount: orchestratorStatus.blockedCount,
      approvalRequiredCount: orchestratorStatus.approvalRequiredCount,
      warningCount: orchestratorStatus.warningCount,
    },
    persistenceStats: {
      operational: persistenceStatus.operational,
      persistedTaskCount: persistenceStatus.persistedTaskCount,
      loadedTaskCount: persistenceStatus.loadedTaskCount,
    },
  };

  const filename = snapshotFileName(id, createdAt);
  const filePath = join(ACTIVE_DIR, filename);
  const tmpPath = filePath + ".tmp";

  try {
    writeFileSync(tmpPath, JSON.stringify(snapshot, null, 2), "utf8");
    renameSync(tmpPath, filePath);
    lastStorageError = null;
  } catch (err) {
    lastStorageError = String(err);
    logger.error({ id, reason, err: String(err) }, "Failed to persist runtime snapshot");
    throw err;
  }

  archiveOldest();

  totalSnapshotsCreated++;
  lastSnapshotAt = createdAt;
  lastSnapshotReason = reason;

  emit("runtime_snapshot:created", "runtime-snapshot", {
    id,
    reason,
    endpointCount,
    healthCheckCount: HEALTH_CHECK_COUNT,
    overallStatus,
  });

  addTimelineEvent({
    level: "info",
    source: "runtime-snapshot",
    message: `Runtime snapshot created: ${reason}`,
    metadata: { id, reason, endpointCount, overallStatus },
  });

  logger.info(
    { id, reason, endpointCount, healthCheckCount: HEALTH_CHECK_COUNT, overallStatus },
    "Runtime snapshot created",
  );

  return snapshot;
}

export function listRuntimeSnapshots(): SnapshotListResult {
  const activeFiles = listDir(ACTIVE_DIR);
  const archivedFiles = listDir(ARCHIVED_DIR);

  const active = activeFiles
    .map((f) => toSummary(f, ACTIVE_DIR, "active"))
    .filter((s): s is RuntimeSnapshotSummary => s !== null);

  const archived = archivedFiles
    .map((f) => toSummary(f, ARCHIVED_DIR, "archived"))
    .filter((s): s is RuntimeSnapshotSummary => s !== null);

  return {
    active,
    archived,
    totalActive: active.length,
    totalArchived: archived.length,
    total: active.length + archived.length,
    maxActiveSnapshots: MAX_ACTIVE_SNAPSHOTS,
    executionBlocked: EXECUTION_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function getFilteredSnapshots(filter: SnapshotFilter): SnapshotFilterResult {
  const raw = listRuntimeSnapshots();
  let candidates: RuntimeSnapshotSummary[] = [...raw.active, ...raw.archived];
  const filtersApplied: Record<string, string> = {};

  if (filter.status) {
    candidates = candidates.filter((s) => s.status === filter.status);
    filtersApplied["status"] = filter.status;
  }
  if (filter.triggeredBy) {
    candidates = candidates.filter((s) => s.reason === filter.triggeredBy);
    filtersApplied["triggeredBy"] = filter.triggeredBy;
  }
  if (filter.snapshotType) {
    candidates = candidates.filter((s) => s.reason === filter.snapshotType);
    filtersApplied["snapshotType"] = filter.snapshotType;
  }
  if (filter.subsystem) {
    candidates = candidates.filter((s) => s.reason === filter.subsystem);
    filtersApplied["subsystem"] = filter.subsystem;
  }

  const filteredCount = candidates.length;

  candidates.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );

  const limitRaw = filter.limit ?? DEFAULT_QUERY_LIMIT;
  const limit = Math.min(Math.max(1, limitRaw), MAX_QUERY_LIMIT);
  const limited = candidates.slice(0, limit);

  const active = limited.filter((s) => s.status === "active");
  const archived = limited.filter((s) => s.status === "archived");

  return {
    active,
    archived,
    totalActive: raw.totalActive,
    totalArchived: raw.totalArchived,
    filteredCount,
    total: raw.total,
    limit,
    filtersApplied,
    maxActiveSnapshots: MAX_ACTIVE_SNAPSHOTS,
    executionBlocked: EXECUTION_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function getRuntimeSnapshot(snapshotId: string): RuntimeSnapshot | null {
  const found = findSnapshotFile(snapshotId);
  if (!found) return null;
  const snap = readSnapshotFile(found.path);
  if (!snap) return null;
  return { ...snap, status: found.status };
}

export function validateRuntimeSnapshot(snapshotId: string): SnapshotValidationResult {
  const timestamp = new Date().toISOString();
  const snap = getRuntimeSnapshot(snapshotId);

  if (!snap) {
    return {
      snapshotId,
      isValid: false,
      validationErrors: [`Snapshot "${snapshotId}" not found in active or archived storage`],
      fieldCount: 0,
      recoveryBlocked: RECOVERY_BLOCKED,
      executionBlocked: EXECUTION_BLOCKED,
      timestamp,
    };
  }

  const errors: string[] = [];

  if (!snap.id) errors.push("Missing required field: id");
  if (snap.version !== 1) errors.push(`Unsupported snapshot version: ${snap.version}`);
  if (!snap.status) errors.push("Missing required field: status");
  if (!snap.reason) errors.push("Missing required field: reason");
  if (!snap.createdAt) errors.push("Missing required field: createdAt");
  if (!snap.runtime || typeof snap.runtime !== "object") errors.push("Missing required section: runtime");
  if (!snap.healthSummary || typeof snap.healthSummary !== "object") errors.push("Missing required section: healthSummary");
  if (!snap.queueStats || typeof snap.queueStats !== "object") errors.push("Missing required section: queueStats");
  if (!snap.lifecycleStats || typeof snap.lifecycleStats !== "object") errors.push("Missing required section: lifecycleStats");
  if (!snap.policyStats || typeof snap.policyStats !== "object") errors.push("Missing required section: policyStats");
  if (!snap.orchestratorStats || typeof snap.orchestratorStats !== "object") errors.push("Missing required section: orchestratorStats");
  if (!snap.persistenceStats || typeof snap.persistenceStats !== "object") errors.push("Missing required section: persistenceStats");
  if (snap.executionBlocked !== true) errors.push("Invalid invariant: executionBlocked must be true");

  const fieldCount = Object.keys(snap).length;

  logger.info(
    { snapshotId, isValid: errors.length === 0, fieldCount, errorCount: errors.length },
    "Runtime snapshot validated",
  );

  return {
    snapshotId,
    isValid: errors.length === 0,
    validationErrors: errors,
    fieldCount,
    recoveryBlocked: RECOVERY_BLOCKED,
    executionBlocked: EXECUTION_BLOCKED,
    timestamp,
  };
}

export function compareSnapshots(
  snapshotIdA: string,
  snapshotIdB: string,
): SnapshotComparisonResult | { error: string; executionBlocked: true } {
  const a = getRuntimeSnapshot(snapshotIdA);
  const b = getRuntimeSnapshot(snapshotIdB);

  if (!a) {
    return { error: `Snapshot not found: ${snapshotIdA}`, executionBlocked: EXECUTION_BLOCKED };
  }
  if (!b) {
    return { error: `Snapshot not found: ${snapshotIdB}`, executionBlocked: EXECUTION_BLOCKED };
  }

  return {
    snapshotIdA,
    snapshotIdB,
    createdAtA: a.createdAt,
    createdAtB: b.createdAt,
    timeDeltaMs: new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    diffs: {
      runtime: {
        stateDelta: {
          a: a.runtime.state,
          b: b.runtime.state,
          changed: a.runtime.state !== b.runtime.state,
        },
        uptimeDeltaMs: b.runtime.uptimeMs - a.runtime.uptimeMs,
        pluginCountDelta: {
          a: a.runtime.pluginCount,
          b: b.runtime.pluginCount,
          changed: a.runtime.pluginCount !== b.runtime.pluginCount,
        },
      },
      queueStats: {
        totalTasksDelta: b.queueStats.totalTasks - a.queueStats.totalTasks,
        blockedTasksDelta: b.queueStats.blockedTasks - a.queueStats.blockedTasks,
      },
      lifecycleStats: {
        transitionsDelta: b.lifecycleStats.totalTransitions - a.lifecycleStats.totalTransitions,
        rejectedTransitionsDelta:
          b.lifecycleStats.rejectedTransitions - a.lifecycleStats.rejectedTransitions,
        trackedTaskCountDelta:
          b.lifecycleStats.trackedTaskCount - a.lifecycleStats.trackedTaskCount,
      },
      policyStats: {
        evaluationsDelta:
          b.policyStats.totalPolicyEvaluations - a.policyStats.totalPolicyEvaluations,
        blockedCountDelta: b.policyStats.blockedCount - a.policyStats.blockedCount,
        approvalRequiredDelta:
          b.policyStats.approvalRequiredCount - a.policyStats.approvalRequiredCount,
      },
      endpointCountDelta: {
        a: a.endpointCount,
        b: b.endpointCount,
        changed: a.endpointCount !== b.endpointCount,
      },
      healthCheckCountDelta: {
        a: a.healthCheckCount,
        b: b.healthCheckCount,
        changed: a.healthCheckCount !== b.healthCheckCount,
      },
    },
    executionBlocked: EXECUTION_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function validateRecoveryCandidate(snapshotId: string): SnapshotValidationResult {
  return validateRuntimeSnapshot(snapshotId);
}

export function estimateRecoveryImpact(snapshotId: string): RecoveryImpactEstimate {
  const timestamp = new Date().toISOString();
  const snap = getRuntimeSnapshot(snapshotId);

  if (!snap) {
    return {
      snapshotId,
      snapshotAge: "unknown",
      snapshotAgeMs: -1,
      estimatedImpact: "significant",
      affectedSystems: [],
      warnings: [`Snapshot "${snapshotId}" not found — recovery impact cannot be estimated`],
      recoveryBlocked: RECOVERY_BLOCKED,
      executionBlocked: EXECUTION_BLOCKED,
      note: "Recovery is blocked. No execution path exists.",
      timestamp,
    };
  }

  const snapshotAgeMs = Date.now() - new Date(snap.createdAt).getTime();
  const ageSec = Math.round(snapshotAgeMs / 1000);
  const ageMin = Math.round(snapshotAgeMs / 60_000);

  const estimatedImpact: ImpactLevel =
    snapshotAgeMs > 3_600_000 ? "significant" : snapshotAgeMs > 300_000 ? "moderate" : "minimal";

  const affectedSystems = [
    "runtime",
    "task_queue",
    "task_lifecycle",
    "task_policy",
    "queue_orchestration",
    "task_persistence",
  ];

  const warnings: string[] = [];
  if (snap.status === "archived") {
    warnings.push("Snapshot is archived — it represents an older system state");
  }
  if (snapshotAgeMs > 3_600_000) {
    warnings.push(`Snapshot is ${ageMin} minutes old — significant state drift may have occurred`);
  }
  if (snap.queueStats.blockedTasks > 0) {
    warnings.push(`${snap.queueStats.blockedTasks} task(s) were blocked at snapshot time`);
  }
  if (snap.lifecycleStats.rejectedTransitions > 0) {
    warnings.push(
      `${snap.lifecycleStats.rejectedTransitions} lifecycle transition(s) had been rejected`,
    );
  }
  if (snap.healthSummary.overallStatus !== "healthy") {
    warnings.push(`System was "${snap.healthSummary.overallStatus}" at snapshot time: ${snap.healthSummary.note}`);
  }

  emit("runtime_snapshot:impact_estimated", "runtime-snapshot", {
    snapshotId,
    estimatedImpact,
    snapshotAgeMs,
  });

  logger.info(
    { snapshotId, estimatedImpact, snapshotAgeMs: `${ageSec}s`, recoveryBlocked: RECOVERY_BLOCKED },
    "Recovery impact estimated (no execution)",
  );

  return {
    snapshotId,
    snapshotAge: snapshotAgeMs < 60_000 ? `${ageSec}s` : `${ageMin}m`,
    snapshotAgeMs,
    estimatedImpact,
    affectedSystems,
    warnings,
    recoveryBlocked: RECOVERY_BLOCKED,
    executionBlocked: EXECUTION_BLOCKED,
    note: "Recovery is blocked. This is a planning-only impact estimate. No system state was modified. No execution path exists.",
    timestamp,
  };
}

export function dryRunRecovery(snapshotId: string): DryRunRecoveryResult {
  const plannedAt = new Date().toISOString();
  const snap = getRuntimeSnapshot(snapshotId);

  if (!snap) {
    logger.warn({ snapshotId }, "Dry-run recovery: snapshot not found");
    return {
      snapshotId,
      dryRun: true,
      wouldRestore: [],
      blockedSteps: ["all steps — snapshot not found, no recovery plan can be generated"],
      phasesPlanned: 0,
      recoveryBlocked: RECOVERY_BLOCKED,
      executionBlocked: EXECUTION_BLOCKED,
      plannedAt,
      note: "Snapshot not found. No recovery plan can be generated.",
    };
  }

  const wouldRestore = [
    `runtime.state → "${snap.runtime.state}" (captured at ${snap.createdAt})`,
    `task_queue → ${snap.queueStats.totalTasks} task(s) total, ${snap.queueStats.queuedTasks} queued, ${snap.queueStats.blockedTasks} blocked`,
    `task_lifecycle → ${snap.lifecycleStats.trackedTaskCount} record(s), ${snap.lifecycleStats.totalTransitions} transition(s) recorded`,
    `task_policy → ${snap.policyStats.totalPolicyEvaluations} evaluation(s): ${snap.policyStats.allowedCount} allowed, ${snap.policyStats.blockedCount} blocked`,
    `queue_orchestration → ${snap.orchestratorStats.totalQueued} queued, ${snap.orchestratorStats.readyCount} ready`,
    `task_persistence → ${snap.persistenceStats.persistedTaskCount} persisted task(s)`,
    `endpoint_count → ${snap.endpointCount} registered routes`,
    `health_checks → ${snap.healthCheckCount} active checks`,
  ];

  const blockedSteps = [
    "execution — executionBlocked is always true, no dispatch path exists",
    "task dispatch — no worker, no scheduler, no executor registered",
    "shell/network operations — blocked by task policy",
    "filesystem mutation — blocked by task policy",
    "autonomous recovery — blocked by design, requires explicit human action",
  ];

  emit("runtime_snapshot:dry_run_recovery", "runtime-snapshot", {
    snapshotId,
    phasesPlanned: wouldRestore.length,
    plannedAt,
    recoveryBlocked: RECOVERY_BLOCKED,
  });

  addTimelineEvent({
    level: "info",
    source: "runtime-snapshot",
    message: `Dry-run recovery planned for snapshot ${snapshotId}`,
    metadata: { snapshotId, phasesPlanned: wouldRestore.length, recoveryBlocked: RECOVERY_BLOCKED },
  });

  logger.info(
    {
      snapshotId,
      phasesPlanned: wouldRestore.length,
      plannedAt,
      recoveryBlocked: RECOVERY_BLOCKED,
      executionBlocked: EXECUTION_BLOCKED,
    },
    "Dry-run recovery planned (no execution, no state modified)",
  );

  return {
    snapshotId,
    dryRun: true,
    wouldRestore,
    blockedSteps,
    phasesPlanned: wouldRestore.length,
    recoveryBlocked: RECOVERY_BLOCKED,
    executionBlocked: EXECUTION_BLOCKED,
    plannedAt,
    note: "This is a planning-only dry run. Recovery is blocked. No system state was modified. No execution path exists.",
  };
}

export function getRuntimeSnapshotStatus(): RuntimeSnapshotSystemStatus {
  const activeFiles = existsSync(ACTIVE_DIR) ? listDir(ACTIVE_DIR) : [];
  const archivedFiles = existsSync(ARCHIVED_DIR) ? listDir(ARCHIVED_DIR) : [];

  return {
    operational: isOperational,
    activeSnapshotCount: activeFiles.length,
    archivedSnapshotCount: archivedFiles.length,
    maxActiveSnapshots: MAX_ACTIVE_SNAPSHOTS,
    retentionNearLimit: activeFiles.length >= RETENTION_WARN_THRESHOLD,
    lastSnapshotAt,
    lastSnapshotReason,
    executionBlocked: EXECUTION_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function initRuntimeSnapshotSystem(): void {
  ensureStorageDirs();

  isOperational = true;

  emit("runtime_snapshot:initialized", "runtime-snapshot", {
    maxActiveSnapshots: MAX_ACTIVE_SNAPSHOTS,
    storageDir: STORAGE_DIR,
    executionBlocked: EXECUTION_BLOCKED,
  });

  addTimelineEvent({
    level: "info",
    source: "runtime-snapshot",
    message: "Runtime snapshot system initialized",
    metadata: {
      maxActiveSnapshots: MAX_ACTIVE_SNAPSHOTS,
      storageDir: STORAGE_DIR,
      retentionWarnThreshold: RETENTION_WARN_THRESHOLD,
    },
  });

  logger.info(
    {
      maxActiveSnapshots: MAX_ACTIVE_SNAPSHOTS,
      storageDir: STORAGE_DIR,
      executionBlocked: EXECUTION_BLOCKED,
    },
    "Runtime snapshot system initialized",
  );
}
