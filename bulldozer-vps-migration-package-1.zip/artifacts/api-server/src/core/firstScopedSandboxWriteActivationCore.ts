// firstScopedSandboxWriteActivationCore.ts
// Phase 309 — First Scoped Sandbox Write Activation Core Skeleton
// In-memory first scoped sandbox write activation descriptor engine.
// Layer 22 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate stack.
// Prepares write permission for sandbox-only targets without enabling actual writes.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// scopedActivationEnabled=false — the scoped write activation has not been triggered.
// scopedActivationPrepared=true — descriptor-readiness established for a future controlled sandbox mutation phase.

import type { ActualSandboxWritePermissionGateRecord } from "./actualSandboxWritePermissionGateCore.js";
import type { FirstActualSandboxMutationSwitchRecord }  from "./firstActualSandboxMutationSwitchCore.js";
import type { FirstGuardedWriteEnableRecord }            from "./firstGuardedWriteEnableCore.js";
import type { FirstBridgeOpenRecord }                    from "./firstBridgeOpenCore.js";
import type { ControlledWriteActivationBridgeRecord }    from "./controlledWriteActivationBridgeCore.js";
import type { ControlledExecutionRecord }                 from "./controlledExecutionCore.js";
import { randomUUID }                                     from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ScopedActivationState = "descriptor_scoped_write_activation_pending";

export type ScopedActivationCheckRule =
  | "write_permission_gate_exists"
  | "mutation_switch_exists"
  | "guarded_write_enable_exists"
  | "bridge_open_exists"
  | "bridge_record_exists"
  | "execution_record_exists"
  | "permission_gate_bound_to_mutation_switch"
  | "mutation_switch_bound_to_guarded_enable"
  | "guarded_enable_bound_to_bridge_open"
  | "bridge_open_bound_to_bridge"
  | "scoped_activation_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface ScopedActivationCheck {
  readonly rule: ScopedActivationCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface ScopedActivationBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedScopedActivationReference {
  readonly writePermissionGateId:      string;
  readonly mutationSwitchId:           string;
  readonly guardedWriteEnableId:       string;
  readonly bridgeOpenId:               string;
  readonly rollbackSnapshotId:         string;
  readonly scopedActivationPrepared:   true;
  readonly scopedActivationEnabled:    false;
  readonly writePermissionEnabled:     false;
  readonly mutationSwitchEnabled:      false;
  readonly rollbackChainValid:         boolean;
  readonly referenceNote:              string;
}

export interface ScopedActivationReadinessReport {
  readonly scopedActivationPrepared:    true;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly summary:                     string;
}

export interface FirstScopedSandboxWriteActivationRecord {
  readonly scopedWriteActivationId:     string;
  readonly scopedActivationState:       ScopedActivationState;
  readonly approvalRequired:            true;
  readonly scopedActivationPrepared:    true;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly implementationPhase:         "descriptor_only";
  readonly writePermissionGateId:       string;
  readonly mutationSwitchId:            string;
  readonly guardedWriteEnableId:        string;
  readonly bridgeOpenId:                string;
  readonly writeActivationBridgeId:     string;
  readonly controlledExecutionId:       string;
  readonly scopedActivationChecks:      readonly ScopedActivationCheck[];
  readonly scopedActivationBlockedReasons: readonly ScopedActivationBlockedReason[];
  readonly scopedActivationReadinessReport: ScopedActivationReadinessReport;
  readonly linkedScopedActivationReference: LinkedScopedActivationReference;
  readonly createdAt:                   string;
}

export interface CreateScopedActivationInput {
  readonly writePermissionGateRecord: ActualSandboxWritePermissionGateRecord;
  readonly mutationSwitchRecord:      FirstActualSandboxMutationSwitchRecord;
  readonly guardedWriteEnableRecord:  FirstGuardedWriteEnableRecord;
  readonly bridgeOpenRecord:          FirstBridgeOpenRecord;
  readonly bridgeRecord:              ControlledWriteActivationBridgeRecord;
  readonly executionRecord:           ControlledExecutionRecord;
}

export interface FirstScopedSandboxWriteActivationSummary {
  readonly total:                       number;
  readonly byState:                     Record<ScopedActivationState, number>;
  readonly scopedActivationPrepared:    true;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly scopedActivationState:       ScopedActivationState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstScopedSandboxWriteActivationRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateScopedActivationInput): readonly ScopedActivationCheck[] {
  const { writePermissionGateRecord, mutationSwitchRecord, guardedWriteEnableRecord, bridgeOpenRecord, bridgeRecord, executionRecord } = input;

  const gateExists       = writePermissionGateRecord.writePermissionGateId.length > 0;
  const switchExists     = mutationSwitchRecord.mutationSwitchId.length > 0;
  const guardedExists    = guardedWriteEnableRecord.guardedWriteEnableId.length > 0;
  const bridgeOpenExists = bridgeOpenRecord.bridgeOpenId.length > 0;
  const bridgeExists     = bridgeRecord.writeActivationBridgeId.length > 0;
  const executionExists  = executionRecord.controlledExecutionId.length > 0;

  const gateBound        = writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId;
  const switchBound      = mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId;
  const guardedBound     = guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId;
  const bridgeOpenBound  = bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId;

  return [
    {
      rule: "write_permission_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`
        : "writePermissionGateRecord.writePermissionGateId is empty",
    },
    {
      rule: "mutation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`
        : "mutationSwitchRecord.mutationSwitchId is empty",
    },
    {
      rule: "guarded_write_enable_exists",
      pass: guardedExists,
      note: guardedExists
        ? `guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`
        : "guardedWriteEnableRecord.guardedWriteEnableId is empty",
    },
    {
      rule: "bridge_open_exists",
      pass: bridgeOpenExists,
      note: bridgeOpenExists
        ? `bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`
        : "bridgeOpenRecord.bridgeOpenId is empty",
    },
    {
      rule: "bridge_record_exists",
      pass: bridgeExists,
      note: bridgeExists
        ? `writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`
        : "bridgeRecord.writeActivationBridgeId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "permission_gate_bound_to_mutation_switch",
      pass: gateBound,
      note: gateBound
        ? `writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId (${mutationSwitchRecord.mutationSwitchId})`
        : `permission-gate/mutation-switch mismatch: gate.mutationSwitchId=${writePermissionGateRecord.mutationSwitchId} vs switch.mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`,
    },
    {
      rule: "mutation_switch_bound_to_guarded_enable",
      pass: switchBound,
      note: switchBound
        ? `mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId (${guardedWriteEnableRecord.guardedWriteEnableId})`
        : `mutation-switch/guarded-enable mismatch: switch.guardedWriteEnableId=${mutationSwitchRecord.guardedWriteEnableId} vs guarded.guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`,
    },
    {
      rule: "guarded_enable_bound_to_bridge_open",
      pass: guardedBound,
      note: guardedBound
        ? `guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId (${bridgeOpenRecord.bridgeOpenId})`
        : `guarded-enable/bridge-open mismatch: guarded.bridgeOpenId=${guardedWriteEnableRecord.bridgeOpenId} vs bridgeOpen.bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`,
    },
    {
      rule: "bridge_open_bound_to_bridge",
      pass: bridgeOpenBound,
      note: bridgeOpenBound
        ? `bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId (${bridgeRecord.writeActivationBridgeId})`
        : `bridge-open/bridge mismatch: bridgeOpen.writeActivationBridgeId=${bridgeOpenRecord.writeActivationBridgeId} vs bridge.writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`,
    },
    {
      rule: "scoped_activation_still_disabled",
      pass: true,
      note: "scopedActivationEnabled=false — compile-time literal; no scoped sandbox write activation phase has triggered this layer",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "scopedActivationState=descriptor_scoped_write_activation_pending — output is a descriptor only; scoped activation is not yet live",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly ScopedActivationCheck[]): readonly ScopedActivationBlockedReason[] {
  const staticReasons: ScopedActivationBlockedReason[] = [
    { code: "scoped_activation_disabled", reason: "scopedActivationEnabled=false — compile-time literal; an explicit controlled sandbox mutation phase must trigger the scoped write activation",                                                                              static: true },
    { code: "approval_required",          reason: "approvalRequired=true — explicit operator approval is required before the scoped write activation can be triggered",                                                                                                         static: true },
    { code: "actual_writes_disabled",     reason: "actualWritesEnabled=false — compile-time literal across all 22 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, and permission-gate layers",           static: true },
  ];
  const dynamicReasons: ScopedActivationBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedScopedActivationReference(
  input: CreateScopedActivationInput,
  rollbackChainValid: boolean,
): LinkedScopedActivationReference {
  const { writePermissionGateRecord, mutationSwitchRecord, guardedWriteEnableRecord, bridgeOpenRecord } = input;
  return {
    writePermissionGateId:   writePermissionGateRecord.writePermissionGateId,
    mutationSwitchId:        mutationSwitchRecord.mutationSwitchId,
    guardedWriteEnableId:    guardedWriteEnableRecord.guardedWriteEnableId,
    bridgeOpenId:            bridgeOpenRecord.bridgeOpenId,
    rollbackSnapshotId:      writePermissionGateRecord.linkedPermissionReference.rollbackSnapshotId,
    scopedActivationPrepared: true,
    scopedActivationEnabled: false,
    writePermissionEnabled:  false,
    mutationSwitchEnabled:   false,
    rollbackChainValid,
    referenceNote:           "linked scoped-activation reference sources rollbackSnapshotId from writePermissionGateRecord.linkedPermissionReference; scoped activation disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createScopedActivationRecord(
  input: CreateScopedActivationInput,
): FirstScopedSandboxWriteActivationRecord {
  const { writePermissionGateRecord, mutationSwitchRecord, guardedWriteEnableRecord, bridgeOpenRecord, bridgeRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = writePermissionGateRecord.permissionReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedScopedActivationReference(input, rollbackChainValid);

  const scopedActivationReadinessReport: ScopedActivationReadinessReport = {
    scopedActivationPrepared:     true,
    scopedActivationEnabled:      false,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    bridgeOpenEnabled:            false,
    bridgeEnabled:                false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    summary: `scopedActivationState=descriptor_scoped_write_activation_pending; scopedActivationEnabled=false; writePermissionEnabled=false; mutationSwitchEnabled=false; actualWritesEnabled=false; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstScopedSandboxWriteActivationRecord = {
    scopedWriteActivationId:          randomUUID(),
    scopedActivationState:            "descriptor_scoped_write_activation_pending",
    approvalRequired:                 true,
    scopedActivationPrepared:         true,
    scopedActivationEnabled:          false,
    writePermissionEnabled:           false,
    mutationSwitchEnabled:            false,
    guardedWriteEnabled:              false,
    bridgeOpenEnabled:                false,
    bridgeEnabled:                    false,
    actualWritesEnabled:              false,
    realWritesEnabled:                false,
    filesystemMutationBlocked:        true,
    motherCoreMutationBlocked:        true,
    vaultMutationBlocked:             true,
    shellBlocked:                     true,
    networkBlocked:                   true,
    implementationPhase:              "descriptor_only",
    writePermissionGateId:            writePermissionGateRecord.writePermissionGateId,
    mutationSwitchId:                 mutationSwitchRecord.mutationSwitchId,
    guardedWriteEnableId:             guardedWriteEnableRecord.guardedWriteEnableId,
    bridgeOpenId:                     bridgeOpenRecord.bridgeOpenId,
    writeActivationBridgeId:          bridgeRecord.writeActivationBridgeId,
    controlledExecutionId:            executionRecord.controlledExecutionId,
    scopedActivationChecks:           checks,
    scopedActivationBlockedReasons:   blockedReasons,
    scopedActivationReadinessReport,
    linkedScopedActivationReference:  linkedRef,
    createdAt:                        new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listScopedActivationRecords(): readonly FirstScopedSandboxWriteActivationRecord[] {
  return _store.slice();
}

export function getScopedActivationSummary(): FirstScopedSandboxWriteActivationSummary {
  return {
    total:                          _store.length,
    byState:                        { descriptor_scoped_write_activation_pending: _store.length },
    scopedActivationPrepared:       true,
    scopedActivationEnabled:        false,
    writePermissionEnabled:         false,
    mutationSwitchEnabled:          false,
    guardedWriteEnabled:            false,
    bridgeOpenEnabled:              false,
    bridgeEnabled:                  false,
    actualWritesEnabled:            false,
    realWritesEnabled:              false,
    approvalRequired:               true,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    scopedActivationState:          "descriptor_scoped_write_activation_pending",
    implementationPhase:            "descriptor_only",
  };
}
