import { createHash } from "node:crypto";
import {
  getWorkspaceSummary,
  getWorkspaceHealth,
} from "./workspaceShell";
import { listWorkspaceSnapshots } from "./workspaceSnapshots";
import { listAuditReports } from "./workspaceAuditReport";
import { runWidgetRegistryValidation } from "./widgetRegistryHealth";

const EXECUTION_BLOCKED: true = true;

// --- Scoring constants ---
// Phase 112: validation_integrity added as 6th dimension.
// Weight redistribution: audit 25→22, snapshot 25→22, ratio 15→13, quota 15→13.
// validation_integrity=10. Invariant: all weights sum to exactly 100.

const WEIGHT_CAPACITY   = 20;
const WEIGHT_AUDIT      = 22;
const WEIGHT_SNAPSHOT   = 22;
const WEIGHT_RATIO      = 13;
const WEIGHT_QUOTA      = 13;
const WEIGHT_VALIDATION = 10;
// Invariant: 20+22+22+13+13+10 = 100

const MAX_AUDIT_REPORTS  = 10;
const MAX_SNAPSHOTS      = 20;
const TARGET_MEMBERS_PER_PROJECT = 2; // full ratio score at >= 2 members/project

const MAX_RECOMMENDATIONS = 5;

// --- Types ---

export type GovernanceGrade = "A" | "B" | "C" | "D" | "F";

export interface ScorecardCategory {
  category: string;
  rawScore: number;
  weight: number;
  weightedScore: number;
  signal: string;
}

export interface ScorecardSignals {
  capacityUtilizationPercent: number;
  atCapacity: boolean;
  retainedReportCount: number;
  snapshotCount: number;
  totalProjects: number;
  memberRecords: number;
  projectsWithCustomQuotas: number;
  registryOperational: boolean;
  // Phase 112 — validation integrity signals
  validationIntegrityScore: number;
  validationIntegrityWeight: number;
  widgetContractViolations: number;
  widgetRegistryHealthy: boolean;
}

export interface WorkspaceGovernanceScorecard {
  scorecardId: string;
  generatedAt: string;
  governanceScore: number;
  governanceGrade: GovernanceGrade;
  breakdown: ScorecardCategory[];
  recommendations: string[];
  signals: ScorecardSignals;
  executionBlocked: true;
}

// --- Internal helpers ---

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function gradeFromScore(score: number): GovernanceGrade {
  if (score >= 90) return "A";
  if (score >= 75) return "B";
  if (score >= 60) return "C";
  if (score >= 45) return "D";
  return "F";
}

function scoreCapacity(utilizationPercent: number): number {
  return clamp(100 - Math.round(utilizationPercent), 0, 100);
}

function scoreAuditCoverage(retainedReportCount: number): number {
  return clamp(Math.round((retainedReportCount / MAX_AUDIT_REPORTS) * 100), 0, 100);
}

function scoreSnapshotAvailability(snapshotCount: number): number {
  return clamp(Math.round((snapshotCount / MAX_SNAPSHOTS) * 100), 0, 100);
}

function scoreMemberRatio(memberRecords: number, totalProjects: number): number {
  if (totalProjects === 0) return 100;
  const ratio = memberRecords / totalProjects;
  return clamp(Math.round((ratio / TARGET_MEMBERS_PER_PROJECT) * 100), 0, 100);
}

function scoreQuotaAdoption(projectsWithCustomQuotas: number, totalProjects: number): number {
  if (totalProjects === 0) return 100;
  return clamp(Math.round((projectsWithCustomQuotas / totalProjects) * 100), 0, 100);
}

// Phase 112 — validation integrity scoring.
// 100 when all 37 contracts pass registry validation.
// Scales proportionally to passing widget fraction when violations exist.
// O(37) bounded scan of contractValidations — effectively O(1).
function scoreValidationIntegrity(
  registryHealthy: boolean,
  violationCount: number,
  contractCount: number,
  passedContractCount: number,
): number {
  if (registryHealthy && violationCount === 0) return 100;
  if (contractCount === 0) return 0;
  return clamp(Math.round((passedContractCount / contractCount) * 100), 0, 100);
}

function buildRecommendations(
  rawCapacity: number,
  rawAudit: number,
  rawSnapshot: number,
  rawRatio: number,
  rawQuota: number,
  rawValidation: number,
  signals: ScorecardSignals,
): string[] {
  const recs: string[] = [];

  if (rawAudit < 50) {
    recs.push(
      "Audit report coverage is below target. Create additional audit reports via POST /api/workspace/audit/report with reportType governance_review or timeline_summary.",
    );
  }

  if (rawSnapshot < 50) {
    recs.push(
      "Workspace snapshot availability is low. Capture point-in-time snapshots via POST /api/workspace/snapshots/create to improve observability.",
    );
  }

  if (rawCapacity < 50) {
    recs.push(
      `Workspace capacity utilization is elevated at ${signals.capacityUtilizationPercent}%. Consider archiving completed or inactive projects to free registry capacity.`,
    );
  }

  if (rawRatio < 50 && signals.totalProjects > 0) {
    const current = signals.memberRecords / signals.totalProjects;
    recs.push(
      `Member-to-project ratio is ${current.toFixed(2)} (target: ${TARGET_MEMBERS_PER_PROJECT}). Assign members to projects via POST /api/projects/:id/members to improve governance coverage.`,
    );
  }

  if (rawQuota < 50 && signals.totalProjects > 0) {
    recs.push(
      `Quota adoption is ${signals.projectsWithCustomQuotas} of ${signals.totalProjects} projects. Set custom resource quotas via POST /api/projects/:id/quotas to enforce governance bounds.`,
    );
  }

  // Phase 112
  if (rawValidation < 100) {
    recs.push(
      `Widget contract validation integrity is at ${rawValidation}% (${signals.widgetContractViolations} violation${signals.widgetContractViolations === 1 ? "" : "s"}). Inspect GET /api/workspace/visual-shell/widgets/registry/coherence for details.`,
    );
  }

  return recs.slice(0, MAX_RECOMMENDATIONS);
}

// --- Public API ---

export function getWorkspaceGovernanceScorecard(): WorkspaceGovernanceScorecard {
  const generatedAt = new Date().toISOString();
  const scorecardId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  const summary = getWorkspaceSummary();
  const health = getWorkspaceHealth();
  const snapshotResult = listWorkspaceSnapshots();
  const reportsResult = listAuditReports({ limit: MAX_AUDIT_REPORTS });
  // Phase 112 — pure static registry read, no circular deps
  const validationResult = runWidgetRegistryValidation();
  const passedContractCount = validationResult.contractValidations.filter((c) => c.passed).length;

  const signals: ScorecardSignals = {
    capacityUtilizationPercent: summary.capacity.utilizationPercent,
    atCapacity: summary.capacity.atCapacity,
    retainedReportCount: reportsResult.reports.length,
    snapshotCount: snapshotResult.count,
    totalProjects: summary.projects.total,
    memberRecords: summary.members.totalRecords,
    projectsWithCustomQuotas: summary.quotas.projectsWithCustomQuotas,
    registryOperational: health.registryOperational,
    // Phase 112
    validationIntegrityScore: 0, // filled below after score computation
    validationIntegrityWeight: WEIGHT_VALIDATION,
    widgetContractViolations: validationResult.summary.violationCount,
    widgetRegistryHealthy: validationResult.registryHealthy,
  };

  const rawCapacity   = scoreCapacity(signals.capacityUtilizationPercent);
  const rawAudit      = scoreAuditCoverage(signals.retainedReportCount);
  const rawSnapshot   = scoreSnapshotAvailability(signals.snapshotCount);
  const rawRatio      = scoreMemberRatio(signals.memberRecords, signals.totalProjects);
  const rawQuota      = scoreQuotaAdoption(signals.projectsWithCustomQuotas, signals.totalProjects);
  const rawValidation = scoreValidationIntegrity(
    validationResult.registryHealthy,
    validationResult.summary.violationCount,
    validationResult.summary.contractCount,
    passedContractCount,
  );

  // Patch signals with computed validation score
  signals.validationIntegrityScore = rawValidation;

  const categories: ScorecardCategory[] = [
    {
      category: "capacity_utilization",
      rawScore: rawCapacity,
      weight: WEIGHT_CAPACITY,
      weightedScore: (rawCapacity * WEIGHT_CAPACITY) / 100,
      signal: `${signals.capacityUtilizationPercent}% of max projects used${signals.atCapacity ? " (at capacity)" : ""}`,
    },
    {
      category: "audit_report_coverage",
      rawScore: rawAudit,
      weight: WEIGHT_AUDIT,
      weightedScore: (rawAudit * WEIGHT_AUDIT) / 100,
      signal: `${signals.retainedReportCount} of ${MAX_AUDIT_REPORTS} max audit reports retained`,
    },
    {
      category: "snapshot_availability",
      rawScore: rawSnapshot,
      weight: WEIGHT_SNAPSHOT,
      weightedScore: (rawSnapshot * WEIGHT_SNAPSHOT) / 100,
      signal: `${signals.snapshotCount} of ${MAX_SNAPSHOTS} max snapshots retained`,
    },
    {
      category: "member_project_ratio",
      rawScore: rawRatio,
      weight: WEIGHT_RATIO,
      weightedScore: (rawRatio * WEIGHT_RATIO) / 100,
      signal: signals.totalProjects > 0
        ? `${signals.memberRecords} member records across ${signals.totalProjects} projects (ratio: ${(signals.memberRecords / signals.totalProjects).toFixed(2)}, target: ${TARGET_MEMBERS_PER_PROJECT})`
        : "No projects — vacuously compliant",
    },
    {
      category: "quota_adoption",
      rawScore: rawQuota,
      weight: WEIGHT_QUOTA,
      weightedScore: (rawQuota * WEIGHT_QUOTA) / 100,
      signal: signals.totalProjects > 0
        ? `${signals.projectsWithCustomQuotas} of ${signals.totalProjects} projects have custom quotas`
        : "No projects — vacuously compliant",
    },
    // Phase 112
    {
      category: "validation_integrity",
      rawScore: rawValidation,
      weight: WEIGHT_VALIDATION,
      weightedScore: (rawValidation * WEIGHT_VALIDATION) / 100,
      signal: validationResult.registryHealthy
        ? `All ${validationResult.summary.contractCount} widget contracts pass registry validation`
        : `${passedContractCount} of ${validationResult.summary.contractCount} widget contracts pass (${validationResult.summary.violationCount} violation${validationResult.summary.violationCount === 1 ? "" : "s"})`,
    },
  ];

  const rawTotal = categories.reduce((acc, c) => acc + c.weightedScore, 0);
  const governanceScore = clamp(Math.round(rawTotal), 0, 100);
  const governanceGrade = gradeFromScore(governanceScore);

  const recommendations = buildRecommendations(
    rawCapacity,
    rawAudit,
    rawSnapshot,
    rawRatio,
    rawQuota,
    rawValidation,
    signals,
  );

  return {
    scorecardId,
    generatedAt,
    governanceScore,
    governanceGrade,
    breakdown: categories,
    recommendations,
    signals,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
