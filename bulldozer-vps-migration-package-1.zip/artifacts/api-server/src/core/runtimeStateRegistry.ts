import { logger } from "../lib/logger";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { emitRuntimeEvent } from "./runtimeEventBus";

export type SubsystemStatus =
  | "initialized"
  | "ready"
  | "degraded"
  | "blocked"
  | "archived"
  | "unknown";

export type SubsystemHealth = "healthy" | "degraded" | "unhealthy" | "unknown";

export interface SubsystemState {
  subsystemName: string;
  category: string;
  status: SubsystemStatus;
  health: SubsystemHealth;
  version: number;
  lastUpdatedAt: string;
  dependencies: string[];
  warnings: string[];
  errors: string[];
  executionBlocked: true;
  recoveryBlocked: true;
  metadata: Record<string, unknown>;
}

export type SubsystemStatePatch = Partial<
  Pick<SubsystemState, "status" | "health" | "warnings" | "errors" | "metadata">
>;

export interface SubsystemRegistrationInput {
  subsystemName: string;
  category: string;
  status?: SubsystemStatus;
  health?: SubsystemHealth;
  dependencies?: string[];
  warnings?: string[];
  errors?: string[];
  metadata?: Record<string, unknown>;
}

export interface RuntimeStateRegistryStatus {
  operational: boolean;
  registeredSubsystemCount: number;
  initializedCount: number;
  readyCount: number;
  degradedCount: number;
  blockedCount: number;
  archivedCount: number;
  unknownCount: number;
  healthyCount: number;
  unhealthyCount: number;
  hasUnhealthySubsystems: boolean;
  hasDegradedOrBlockedSubsystems: boolean;
  coreSubsystemsPresent: boolean;
  executionBlocked: true;
  recoveryBlocked: true;
  timestamp: string;
}

const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;

const CORE_SUBSYSTEMS = [
  "runtime",
  "health_monitor",
  "task_queue",
  "task_policy",
  "command_gateway",
] as const;

const SEED_SUBSYSTEMS: SubsystemRegistrationInput[] = [
  {
    subsystemName: "runtime",
    category: "core",
    dependencies: [],
    metadata: { description: "Core runtime lifecycle — startup, status, shutdown" },
  },
  {
    subsystemName: "health_monitor",
    category: "core",
    dependencies: ["runtime"],
    metadata: { description: "Composite health monitor — 27 synchronous checks" },
  },
  {
    subsystemName: "task_queue",
    category: "queue",
    dependencies: ["runtime"],
    metadata: { description: "In-memory task queue — max 100 tasks, importTask load path" },
  },
  {
    subsystemName: "task_policy",
    category: "queue",
    dependencies: ["task_queue"],
    metadata: { description: "Task policy engine — 10 ordered policies, source of truth" },
  },
  {
    subsystemName: "task_evaluation",
    category: "queue",
    dependencies: ["task_queue", "task_policy"],
    metadata: { description: "Task evaluation — delegates to taskPolicy, executionBlocked always true" },
  },
  {
    subsystemName: "task_persistence",
    category: "queue",
    dependencies: ["task_queue"],
    metadata: { description: "Task persistence — atomic disk writes, load-on-boot" },
  },
  {
    subsystemName: "queue_orchestration",
    category: "queue",
    dependencies: ["task_queue", "task_policy"],
    metadata: { description: "Queue orchestrator — planning-only readiness scan" },
  },
  {
    subsystemName: "task_lifecycle",
    category: "queue",
    dependencies: ["task_queue", "task_policy"],
    metadata: { description: "Task lifecycle — 5-state machine, safe transitions only" },
  },
  {
    subsystemName: "runtime_snapshot",
    category: "snapshot",
    dependencies: ["runtime", "task_queue", "task_lifecycle"],
    metadata: { description: "Runtime snapshot — cross-system capture, max 50 active + archive" },
  },
  {
    subsystemName: "runtime_event_bus",
    category: "events",
    dependencies: ["runtime"],
    metadata: { description: "Runtime event bus — 9-category model, 1000-event ring buffer" },
  },
  {
    subsystemName: "command_gateway",
    category: "commands",
    dependencies: ["runtime_event_bus"],
    metadata: { description: "Command gateway — intake-only, 4-policy risk classification" },
  },
  {
    subsystemName: "hardening",
    category: "security",
    dependencies: ["runtime"],
    metadata: { description: "Production hardening — 5 block types, 2 warning types, security headers" },
  },
  {
    subsystemName: "secure_config",
    category: "security",
    dependencies: ["runtime"],
    metadata: { description: "Secure config — masking, validation, 3-status model" },
  },
  {
    subsystemName: "watchdog",
    category: "monitoring",
    dependencies: ["runtime"],
    metadata: { description: "Watchdog — 15 s passive monitor, reads raw state, 8 event types" },
  },
  {
    subsystemName: "restart_supervisor",
    category: "monitoring",
    dependencies: ["watchdog"],
    metadata: { description: "Restart supervisor — 5-threshold decision layer, blockedExecution always true" },
  },
  {
    subsystemName: "plugin_sandbox",
    category: "plugins",
    dependencies: ["runtime"],
    metadata: { description: "Plugin sandbox — all-denied permission model, in-memory registry" },
  },
  {
    subsystemName: "recovery_tracker",
    category: "recovery",
    dependencies: ["runtime_event_bus"],
    metadata: { description: "Recovery tracker — 10 event subscriptions, passive observation only" },
  },
  {
    subsystemName: "runtime_state_registry",
    category: "meta",
    dependencies: ["runtime", "runtime_event_bus"],
    metadata: { description: "Runtime state registry — subsystem state tracking, register/update/list/get, executionBlocked always true" },
  },
  {
    subsystemName: "runtime_dependency_graph",
    category: "meta",
    dependencies: ["runtime_state_registry"],
    metadata: { description: "Runtime dependency graph — upstream/downstream/transitive closures, cycle detection, read-only" },
  },
  {
    subsystemName: "runtime_capability_matrix",
    category: "meta",
    dependencies: ["runtime_state_registry"],
    metadata: { description: "Runtime capability matrix — read/write/emit/subscribe/access definitions per subsystem, validation" },
  },
  {
    subsystemName: "persistent_store",
    category: "infrastructure",
    dependencies: ["runtime"],
    metadata: { description: "Persistent store — atomic JSON key-value store, max 100 keys, 512 KB per value, storage/store directory" },
  },
];

const registry = new Map<string, SubsystemState>();
let isOperational = false;

export function registerSubsystemState(input: SubsystemRegistrationInput): SubsystemState {
  const now = new Date().toISOString();

  const existing = registry.get(input.subsystemName);
  if (existing) {
    return existing;
  }

  const state: SubsystemState = {
    subsystemName: input.subsystemName,
    category: input.category,
    status: input.status ?? "initialized",
    health: input.health ?? "unknown",
    version: 1,
    lastUpdatedAt: now,
    dependencies: input.dependencies ?? [],
    warnings: input.warnings ?? [],
    errors: input.errors ?? [],
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    metadata: input.metadata ?? {},
  };

  registry.set(input.subsystemName, state);
  return state;
}

export function updateSubsystemState(
  subsystemName: string,
  patch: SubsystemStatePatch,
): SubsystemState | null {
  const existing = registry.get(subsystemName);
  if (!existing) return null;

  const now = new Date().toISOString();

  const updated: SubsystemState = {
    ...existing,
    ...(patch.status !== undefined ? { status: patch.status } : {}),
    ...(patch.health !== undefined ? { health: patch.health } : {}),
    ...(patch.warnings !== undefined ? { warnings: patch.warnings } : {}),
    ...(patch.errors !== undefined ? { errors: patch.errors } : {}),
    ...(patch.metadata !== undefined
      ? { metadata: { ...existing.metadata, ...patch.metadata } }
      : {}),
    version: existing.version + 1,
    lastUpdatedAt: now,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
  };

  registry.set(subsystemName, updated);
  return updated;
}

export function getSubsystemState(subsystemName: string): SubsystemState | null {
  return registry.get(subsystemName) ?? null;
}

export function listSubsystemStates(): SubsystemState[] {
  return Array.from(registry.values()).sort((a, b) =>
    a.subsystemName.localeCompare(b.subsystemName),
  );
}

export function getRuntimeStateRegistryStatus(): RuntimeStateRegistryStatus {
  const states = Array.from(registry.values());
  const total = states.length;

  let initializedCount = 0;
  let readyCount = 0;
  let degradedCount = 0;
  let blockedCount = 0;
  let archivedCount = 0;
  let unknownCount = 0;
  let healthyCount = 0;
  let unhealthyCount = 0;

  for (const s of states) {
    if (s.status === "initialized") initializedCount++;
    else if (s.status === "ready") readyCount++;
    else if (s.status === "degraded") degradedCount++;
    else if (s.status === "blocked") blockedCount++;
    else if (s.status === "archived") archivedCount++;
    else unknownCount++;

    if (s.health === "healthy") healthyCount++;
    else if (s.health === "unhealthy") unhealthyCount++;
  }

  const coreSubsystemsPresent = CORE_SUBSYSTEMS.every((name) => registry.has(name));

  return {
    operational: isOperational,
    registeredSubsystemCount: total,
    initializedCount,
    readyCount,
    degradedCount,
    blockedCount,
    archivedCount,
    unknownCount,
    healthyCount,
    unhealthyCount,
    hasUnhealthySubsystems: unhealthyCount > 0,
    hasDegradedOrBlockedSubsystems: degradedCount > 0 || blockedCount > 0,
    coreSubsystemsPresent,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function initRuntimeStateRegistry(): void {
  for (const seed of SEED_SUBSYSTEMS) {
    registerSubsystemState(seed);
  }

  isOperational = true;

  emit("runtime_state_registry:initialized", "runtime-state-registry", {
    registeredSubsystemCount: registry.size,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "runtime_state_registry.initialized",
    source: "runtime-state-registry",
    severity: "info",
    category: "runtime",
    payload: {
      registeredSubsystemCount: registry.size,
      seededSubsystems: SEED_SUBSYSTEMS.map((s) => s.subsystemName),
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  addTimelineEvent({
    level: "info",
    source: "runtime-state-registry",
    message: `Runtime state registry initialized — ${registry.size} subsystems registered`,
    metadata: {
      registeredSubsystemCount: registry.size,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    {
      registeredSubsystemCount: registry.size,
      executionBlocked: EXECUTION_BLOCKED,
    },
    "Runtime state registry initialized",
  );
}
