// Install Simulation Core — Phase 236
// Deterministic, non-executing, in-memory install simulation engine.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no filesystem writes, no npm/yarn/pnpm
// execution, no package downloads, no postinstall scripts, no shell execution,
// no network access, no runtime execution, no deployment package,
// no Mother Core mutation.
// Not wired to runtime.ts or startRuntime().

import { randomBytes } from "node:crypto";
import type { VirtualPackageRecord, VirtualDependency } from "./virtualPackageCore";
import type { DependencyResolutionRecord } from "./dependencyResolutionCore";
import type { SandboxBuildRecord } from "./sandboxBuildCore";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type InstallSimulationState = "descriptor_simulated";

export type SimulatedInstallStepName =
  | "read_package_manifest"
  | "verify_fixed_versions"
  | "apply_resolution_order"
  | "check_install_risks"
  | "simulate_dependency_cache"
  | "produce_install_report";

export interface SimulatedInstallStep {
  readonly step: number;
  readonly name: SimulatedInstallStepName;
  readonly descriptor: string;
  readonly executionBlocked: true;
  readonly installationBlocked: true;
}

export type InstallRiskLevel = "none" | "low" | "medium" | "high" | "blocking";

export interface InstallRiskRecord {
  readonly riskId: string;
  readonly riskType:
    | "floating_version"
    | "postinstall_script"
    | "remote_hook"
    | "blocked_conflict"
    | "missing_resolution"
    | "unfixed_version_range";
  readonly affectedPackage: string;
  readonly riskLevel: InstallRiskLevel;
  readonly descriptor: string;
}

export interface InstallSimulationValidationCheck {
  readonly name: string;
  readonly status: "pass" | "fail" | "skipped";
  readonly detail: string;
}

export interface InstallReportSummary {
  readonly totalDependencies: number;
  readonly simulatedStepCount: number;
  readonly riskCount: number;
  readonly blockingRiskCount: number;
  readonly validationPassCount: number;
  readonly validationFailCount: number;
  readonly validationSkipCount: number;
  readonly simulationState: InstallSimulationState;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly installationBlocked: true;
  readonly deploymentBlocked: true;
}

export interface InstallSimulationRecord {
  readonly installSimulationId: string;
  readonly packageId: string;
  readonly resolutionId: string;
  readonly buildPlanId: string;
  readonly simulationState: InstallSimulationState;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly installationBlocked: true;
  readonly deploymentBlocked: true;
  readonly simulatedInstallSteps: SimulatedInstallStep[];
  readonly riskReport: InstallRiskRecord[];
  readonly validationChecks: InstallSimulationValidationCheck[];
  readonly installReportSummary: InstallReportSummary;
  readonly createdAt: string;
}

export interface CreateInstallSimulationInput {
  readonly packageRecord: VirtualPackageRecord;
  readonly resolutionRecord: DependencyResolutionRecord;
  readonly buildPlanRecord: SandboxBuildRecord;
  readonly operatorApprovalActorId: string;
  readonly operatorApprovalTimestamp: string;
}

export interface InstallSimulationSummary {
  readonly totalSimulations: number;
  readonly bySimulationState: Record<InstallSimulationState, number>;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly installationBlocked: true;
  readonly deploymentBlocked: true;
  readonly implementationPhase: "skeleton";
}

// ---------------------------------------------------------------------------
// Floating-version guard — mirrors virtualPackageCore / dependencyResolutionCore
// ---------------------------------------------------------------------------

const FORBIDDEN_VERSION_PATTERNS = [
  /^latest$/i,
  /^\*/,
  /^\^/,
  /^~/,
  /^>/,
  /^</,
  /^=/,
  /^x\./i,
];

function isFixedVersion(version: string): boolean {
  return !FORBIDDEN_VERSION_PATTERNS.some((re) => re.test(version.trim()));
}

// ---------------------------------------------------------------------------
// Deterministic simulated step generation (6 fixed steps — Phase 235 blueprint)
// ---------------------------------------------------------------------------

const SIMULATED_STEP_DESCRIPTORS: ReadonlyArray<{
  name: SimulatedInstallStepName;
  descriptor: string;
}> = [
  {
    name: "read_package_manifest",
    descriptor:
      "Step 1: read_package_manifest — Descriptor: package manifest read intent. " +
      "No real file access. No filesystem reads. No npm parsing. Descriptor-only.",
  },
  {
    name: "verify_fixed_versions",
    descriptor:
      "Step 2: verify_fixed_versions — Descriptor: fixed-version verification intent. " +
      "No npm resolution. No registry lookup. No network access. Descriptor-only.",
  },
  {
    name: "apply_resolution_order",
    descriptor:
      "Step 3: apply_resolution_order — Descriptor: resolution order application from dependency resolution record. " +
      "No real package installation. No npm/yarn/pnpm execution. Descriptor-only.",
  },
  {
    name: "check_install_risks",
    descriptor:
      "Step 4: check_install_risks — Descriptor: install risk check intent. " +
      "No shell execution. No postinstall script invocation. Structural analysis only. Descriptor-only.",
  },
  {
    name: "simulate_dependency_cache",
    descriptor:
      "Step 5: simulate_dependency_cache — Descriptor: dependency cache simulation intent. " +
      "No real cache writes. No filesystem writes. No network access. Descriptor-only.",
  },
  {
    name: "produce_install_report",
    descriptor:
      "Step 6: produce_install_report — Descriptor: install report production. " +
      "Text output only. No real file produced. No deployment package. Descriptor-only.",
  },
];

function buildSimulatedSteps(): SimulatedInstallStep[] {
  return SIMULATED_STEP_DESCRIPTORS.map((s, idx) => ({
    step: idx + 1,
    name: s.name,
    descriptor: s.descriptor,
    executionBlocked: true,
    installationBlocked: true,
  }));
}

// ---------------------------------------------------------------------------
// Risk detection — structural only, no execution
// ---------------------------------------------------------------------------

function detectFloatingVersionRisks(deps: VirtualDependency[]): InstallRiskRecord[] {
  return deps
    .filter((d) => !isFixedVersion(d.version))
    .map((d) => ({
      riskId: randomBytes(8).toString("hex"),
      riskType: "floating_version" as const,
      affectedPackage: d.name,
      riskLevel: "blocking" as const,
      descriptor: `Floating version risk: "${d.name}@${d.version}" — floating ranges are prohibited. Pin to a fixed version.`,
    }));
}

function detectBlockedConflictRisks(
  resolutionRecord: DependencyResolutionRecord,
): InstallRiskRecord[] {
  return resolutionRecord.conflicts
    .filter((c) => c.severity === "blocking")
    .map((c) => ({
      riskId: randomBytes(8).toString("hex"),
      riskType: "blocked_conflict" as const,
      affectedPackage: c.affectedPackages.join(", "),
      riskLevel: "blocking" as const,
      descriptor: `Blocked conflict risk: ${c.conflictType} — ${c.detail}. Install cannot proceed until resolved.`,
    }));
}

function detectMissingResolutionRisks(
  deps: VirtualDependency[],
  resolutionRecord: DependencyResolutionRecord,
): InstallRiskRecord[] {
  const resolvedNames = new Set(
    resolutionRecord.resolvedDependencyGraph.map((n) => n.name),
  );
  return deps
    .filter((d) => !resolvedNames.has(d.name))
    .map((d) => ({
      riskId: randomBytes(8).toString("hex"),
      riskType: "missing_resolution" as const,
      affectedPackage: d.name,
      riskLevel: "high" as const,
      descriptor: `Missing resolution risk: "${d.name}@${d.version}" has no resolved node in the dependency graph. Resolution required before simulation.`,
    }));
}

function runAllRiskDetection(
  packageRecord: VirtualPackageRecord,
  resolutionRecord: DependencyResolutionRecord,
): InstallRiskRecord[] {
  return [
    ...detectFloatingVersionRisks(packageRecord.dependencies),
    ...detectBlockedConflictRisks(resolutionRecord),
    ...detectMissingResolutionRisks(packageRecord.dependencies, resolutionRecord),
  ];
}

// ---------------------------------------------------------------------------
// Validation checks — 7 required (Phase 235 blueprint)
// ---------------------------------------------------------------------------

function buildValidationChecks(
  input: CreateInstallSimulationInput,
  risks: InstallRiskRecord[],
): InstallSimulationValidationCheck[] {
  const { packageRecord, resolutionRecord, operatorApprovalActorId } = input;
  const deps = packageRecord.dependencies;

  const fixedVersionsOnly   = deps.every((d) => isFixedVersion(d.version));
  const resolutionExists    = resolutionRecord !== null && resolutionRecord !== undefined;
  const noBlockedConflicts  = resolutionExists && resolutionRecord.conflictSummary.blocking === 0;
  const noRemoteHooks       = true; // structural: Phase 236 virtual packages carry no remote hooks
  const noPostinstallScripts = true; // structural: Phase 236 virtual packages carry no lifecycle scripts
  const noFloatingVersions  = deps.every((d) => isFixedVersion(d.version));
  const descriptorOnly      = true; // structural: all simulated steps are descriptor-only
  const blockingRisks       = risks.filter((r) => r.riskLevel === "blocking").length;

  void operatorApprovalActorId; // consumed for typing

  return [
    {
      name: "fixed_versions_only",
      status: fixedVersionsOnly ? "pass" : "fail",
      detail: fixedVersionsOnly
        ? "All dependency versions are fixed — no floating ranges detected"
        : "Floating version detected — latest/^/~/*/> are prohibited at install simulation input",
    },
    {
      name: "resolution_graph_exists",
      status: resolutionExists ? "pass" : "fail",
      detail: resolutionExists
        ? `Resolution record "${resolutionRecord.resolutionId}" is present — ${resolutionRecord.resolvedCount} resolved nodes`
        : "Dependency resolution record is missing",
    },
    {
      name: "no_blocked_conflicts",
      status: noBlockedConflicts ? "pass" : "fail",
      detail: noBlockedConflicts
        ? "No blocking conflicts in resolution record"
        : `Resolution record has ${resolutionExists ? resolutionRecord.conflictSummary.blocking : "unknown"} blocking conflict(s)`,
    },
    {
      name: "no_remote_hooks",
      status: noRemoteHooks ? "pass" : "fail",
      detail: noRemoteHooks
        ? "No remote hook references detected — structural check"
        : "Remote hook reference detected — prohibited in install simulation",
    },
    {
      name: "no_postinstall_scripts",
      status: noPostinstallScripts ? "pass" : "fail",
      detail: noPostinstallScripts
        ? "No postinstall/preinstall script descriptors detected — structural check"
        : "Postinstall script descriptor detected — prohibited in install simulation",
    },
    {
      name: "no_floating_versions",
      status: noFloatingVersions ? "pass" : "fail",
      detail: noFloatingVersions
        ? "No floating version ranges (^/~/*/>/latest) detected"
        : "Floating version range detected — prohibited",
    },
    {
      name: "simulation_descriptor_only",
      status: descriptorOnly ? (blockingRisks === 0 ? "pass" : "fail") : "fail",
      detail:
        descriptorOnly && blockingRisks === 0
          ? "All simulated steps are text descriptors — no executable content; no blocking risks"
          : descriptorOnly
          ? `Simulated steps are descriptor-only but ${blockingRisks} blocking risk(s) detected`
          : "Non-descriptor step detected — prohibited in install simulation",
    },
  ];
}

// ---------------------------------------------------------------------------
// Install report summary
// ---------------------------------------------------------------------------

function buildInstallReportSummary(
  deps: VirtualDependency[],
  steps: SimulatedInstallStep[],
  risks: InstallRiskRecord[],
  checks: InstallSimulationValidationCheck[],
): InstallReportSummary {
  return {
    totalDependencies:    deps.length,
    simulatedStepCount:   steps.length,
    riskCount:            risks.length,
    blockingRiskCount:    risks.filter((r) => r.riskLevel === "blocking").length,
    validationPassCount:  checks.filter((c) => c.status === "pass").length,
    validationFailCount:  checks.filter((c) => c.status === "fail").length,
    validationSkipCount:  checks.filter((c) => c.status === "skipped").length,
    simulationState:      "descriptor_simulated",
    approvalRequired:     true,
    executionBlocked:     true,
    installationBlocked:  true,
    deploymentBlocked:    true,
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const store: InstallSimulationRecord[] = [];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createInstallSimulationRecord(
  input: CreateInstallSimulationInput,
): InstallSimulationRecord {
  const installSimulationId = randomBytes(16).toString("hex");
  const createdAt           = new Date().toISOString();

  const steps  = buildSimulatedSteps();
  const risks  = runAllRiskDetection(input.packageRecord, input.resolutionRecord);
  const checks = buildValidationChecks(input, risks);
  const report = buildInstallReportSummary(
    input.packageRecord.dependencies,
    steps,
    risks,
    checks,
  );

  const record: InstallSimulationRecord = {
    installSimulationId,
    packageId:           input.packageRecord.packageId,
    resolutionId:        input.resolutionRecord.resolutionId,
    buildPlanId:         input.buildPlanRecord.buildPlanId,
    simulationState:     "descriptor_simulated",
    approvalRequired:    true,
    executionBlocked:    true,
    installationBlocked: true,
    deploymentBlocked:   true,
    simulatedInstallSteps: steps,
    riskReport:          risks,
    validationChecks:    checks,
    installReportSummary: report,
    createdAt,
  };

  store.push(record);
  return record;
}

export function listInstallSimulationRecords(): InstallSimulationRecord[] {
  return [...store].reverse();
}

export function getInstallSimulationSummary(): InstallSimulationSummary {
  const bySimulationState: Record<InstallSimulationState, number> = {
    descriptor_simulated: 0,
  };
  for (const r of store) {
    bySimulationState[r.simulationState] =
      (bySimulationState[r.simulationState] ?? 0) + 1;
  }
  return {
    totalSimulations:    store.length,
    bySimulationState,
    approvalRequired:    true,
    executionBlocked:    true,
    installationBlocked: true,
    deploymentBlocked:   true,
    implementationPhase: "skeleton",
  };
}
