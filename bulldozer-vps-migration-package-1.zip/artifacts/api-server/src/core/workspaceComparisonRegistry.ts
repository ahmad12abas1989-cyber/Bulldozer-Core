// Comparison Registry — Phase 124
// Purely static, deterministic catalog of all available comparison endpoints.
// No runtime endpoint scanning, no persistence reads, no mutation paths,
// no rendering, no autonomous execution, no AI orchestration.

const EXECUTION_BLOCKED: true = true;
const REGISTRY_VERSION = "1" as const;

// --- Types ---

export type ComparisonType =
  | "scorecard_comparison"
  | "ledger_comparison"
  | "dual_comparison";

export type RingType =
  | "governance_scorecard_history"
  | "observation_ledger_history"
  | "governance_scorecard_history+observation_ledger_history";

export interface ComparisonQueryParam {
  name: string;
  description: string;
  required: true;
  type: "positive_integer";
  executionBlocked: true;
}

export interface ComparisonRegistryEntry {
  route: string;
  method: "GET";
  comparisonType: ComparisonType;
  ringType: RingType;
  ringCapacity: number | string;
  responseType: string;
  supportedQueryParams: ComparisonQueryParam[];
  supportedChangeDomains: string[];
  executionBlocked: true;
}

export interface ComparisonRegistryResult {
  generatedAt: string;
  registryVersion: typeof REGISTRY_VERSION;
  comparisonEndpoints: ComparisonRegistryEntry[];
  executionBlocked: true;
}

// --- Static registry definition ---
// Canonical ordering: alphabetical by route.

const COMPARISON_ENDPOINTS: ComparisonRegistryEntry[] = [
  {
    route: "/api/workspace/comparison/dual",
    method: "GET",
    comparisonType: "dual_comparison",
    ringType: "governance_scorecard_history+observation_ledger_history",
    ringCapacity: "scorecard=10,ledger=20",
    responseType: "DualComparisonResult",
    supportedQueryParams: [
      { name: "scorecardFrom", description: "Scorecard ring captureSeq for the from-snapshot", required: true, type: "positive_integer", executionBlocked: EXECUTION_BLOCKED },
      { name: "scorecardTo",   description: "Scorecard ring captureSeq for the to-snapshot",   required: true, type: "positive_integer", executionBlocked: EXECUTION_BLOCKED },
      { name: "ledgerFrom",    description: "Ledger ring captureSeq for the from-snapshot",    required: true, type: "positive_integer", executionBlocked: EXECUTION_BLOCKED },
      { name: "ledgerTo",      description: "Ledger ring captureSeq for the to-snapshot",      required: true, type: "positive_integer", executionBlocked: EXECUTION_BLOCKED },
    ],
    supportedChangeDomains: [
      "governance_score_delta",
      "governance_grade_change",
      "validation_integrity_delta",
      "improvement_direction",
      "dimension_weighted_score_delta",
      "dimension_trend_direction",
      "observation_coverage_delta",
      "governance_readiness_change",
      "validation_health_change",
      "widget_coverage_percent_delta",
      "overall_observation_health_change",
      "exposure_risk_change",
      "trend_direction_change",
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    route: "/api/workspace/governance/scorecard/history/compare",
    method: "GET",
    comparisonType: "scorecard_comparison",
    ringType: "governance_scorecard_history",
    ringCapacity: 10,
    responseType: "ScorecardComparisonResult",
    supportedQueryParams: [
      { name: "from", description: "Scorecard ring captureSeq for the from-snapshot", required: true, type: "positive_integer", executionBlocked: EXECUTION_BLOCKED },
      { name: "to",   description: "Scorecard ring captureSeq for the to-snapshot",   required: true, type: "positive_integer", executionBlocked: EXECUTION_BLOCKED },
    ],
    supportedChangeDomains: [
      "governance_score_delta",
      "governance_grade_change",
      "validation_integrity_delta",
      "improvement_direction",
      "dimension_weighted_score_delta",
      "dimension_trend_direction",
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    route: "/api/workspace/observation/ledger/history/compare",
    method: "GET",
    comparisonType: "ledger_comparison",
    ringType: "observation_ledger_history",
    ringCapacity: 20,
    responseType: "LedgerComparisonResult",
    supportedQueryParams: [
      { name: "from", description: "Ledger ring captureSeq for the from-snapshot", required: true, type: "positive_integer", executionBlocked: EXECUTION_BLOCKED },
      { name: "to",   description: "Ledger ring captureSeq for the to-snapshot",   required: true, type: "positive_integer", executionBlocked: EXECUTION_BLOCKED },
    ],
    supportedChangeDomains: [
      "observation_coverage_delta",
      "governance_readiness_change",
      "validation_health_change",
      "widget_coverage_percent_delta",
      "overall_observation_health_change",
      "improvement_direction",
      "exposure_risk_change",
      "trend_direction_change",
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
];

// --- Public API ---

// Returns a static, deterministic ComparisonRegistryResult.
// No runtime scanning, no persistence reads, no I/O.
// The only non-deterministic field is generatedAt (ISO timestamp at call time).
export function getComparisonRegistry(): ComparisonRegistryResult {
  return {
    generatedAt: new Date().toISOString(),
    registryVersion: REGISTRY_VERSION,
    comparisonEndpoints: COMPARISON_ENDPOINTS.map((e) => ({ ...e, supportedQueryParams: e.supportedQueryParams.map((p) => ({ ...p })) })),
    executionBlocked: EXECUTION_BLOCKED,
  };
}
