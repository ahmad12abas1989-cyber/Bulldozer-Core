import type { IncomingMessage, ServerResponse } from "node:http";
import { getFreezeStatus } from "../core/freezeDetector";
import { sendJson } from "../lib/response";

export function handleFreeze(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getFreezeStatus());
}
