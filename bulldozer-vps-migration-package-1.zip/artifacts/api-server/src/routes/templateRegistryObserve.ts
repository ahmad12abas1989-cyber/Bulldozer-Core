// Template Registry Observe Route — Phase 213
// GET /api/templates/registry
// Read-only diagnostic view of the in-memory Template Registry metadata store.
// No template registration, no enable/deprecate/revoke, no generation, no file
// creation, no execution, no network access, no vault access.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { listTemplateMetadata, getTemplateSummary } from "../core/templateRegistryCore";

export function handleTemplateRegistryObserve(_req: IncomingMessage, res: ServerResponse): void {
  const templates = listTemplateMetadata();
  const summary   = getTemplateSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    generationEnabled:  false,
    executionEnabled:   false,
    persistenceEnabled: false,
    executionBlocked:   true,
    totalTemplates:     templates.length,
    summary,
    templates,
  });
}
