import type { IncomingMessage, ServerResponse } from "node:http";
import { getFullHealth } from "../core/healthMonitor";
import { sendJson } from "../lib/response";

export function handleHealthFull(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getFullHealth());
}
