// Auth Audit Log Route — Phase 188
// GET /api/auth/audit-log
// Read-only diagnostic view of the in-memory auth audit log.
// No mutation, no deletion, no persistence, no auto-appended events.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { listAuthAuditEvents, getAuthAuditSummary } from "../core/authAuditLog";

export function handleAuthAuditLog(_req: IncomingMessage, res: ServerResponse): void {
  const summary = getAuthAuditSummary();
  const events  = listAuthAuditEvents();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    appendOnly:         true,
    persistenceEnabled: false,
    executionBlocked:   true,
    totalEvents:        summary.totalEvents,
    summary,
    events,
  });
}
