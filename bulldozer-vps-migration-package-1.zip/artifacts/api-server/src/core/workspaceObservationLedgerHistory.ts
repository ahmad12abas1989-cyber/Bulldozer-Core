import { readStore, writeStore } from "./persistentStore";
import { logger } from "../lib/logger";
import {
  getWorkspaceObservationLedger,
  WorkspaceObservationLedger,
  ObservationHealth,
  ExposureRiskLevel,
  ValidationHealth,
} from "./workspaceObservationLedger";
import type { GovernanceGrade } from "./workspaceGovernanceScorecard";

const EXECUTION_BLOCKED: true = true;
const MAX_ENTRIES = 20;
const STORE_KEY = "workspace-observation-ledger-history";

// --- Types ---

export interface LedgerHistoryEntry {
  captureSeq: number;
  createdAt: string;
  ledgerId: string;
  snapshot: WorkspaceObservationLedger;
  executionBlocked: true;
}

export interface LedgerHistoryListItem {
  captureSeq: number;
  createdAt: string;
  ledgerId: string;
  overallObservationHealth: ObservationHealth;
  governanceReadiness: GovernanceGrade;
  observationCoverage: number;
  exposureRiskLevel: ExposureRiskLevel;
  validationHealth: ValidationHealth;
  widgetCoveragePercent: number;
  executionBlocked: true;
}

export interface LedgerHistoryCaptureResult {
  captureSeq: number;
  createdAt: string;
  ledgerId: string;
  ringSize: number;
  executionBlocked: true;
}

export interface LedgerHistoryListResult {
  entries: LedgerHistoryListItem[];
  total: number;
  maxRetained: number;
  storeKey: string;
  executionBlocked: true;
}

// Full detail projection — includes complete stored WorkspaceObservationLedger.
// Read-only, O(20) ring lookup. No persistence mutation, no live ledger call.
export interface LedgerHistoryDetailResult {
  captureSeq: number;
  createdAt: string;
  ledgerId: string;
  ledgerSnapshot: WorkspaceObservationLedger;
  executionBlocked: true;
}

// --- Module state ---

let historyRing: LedgerHistoryEntry[] = [];
let nextCaptureSeq = 1;
let loadedOnBoot = 0;
let isInitialized = false;

// --- Persistence helpers ---

function flush(): void {
  try {
    writeStore<LedgerHistoryEntry[]>(STORE_KEY, historyRing);
  } catch (err) {
    logger.error({ err, storeKey: STORE_KEY }, "Ledger history: flush failed — ring preserved in memory");
  }
}

function isValidEntry(obj: unknown): obj is LedgerHistoryEntry {
  if (obj === null || typeof obj !== "object") return false;
  const e = obj as Record<string, unknown>;
  return (
    typeof e["captureSeq"] === "number" &&
    typeof e["createdAt"] === "string" &&
    typeof e["ledgerId"] === "string" &&
    e["snapshot"] !== null &&
    typeof e["snapshot"] === "object" &&
    e["executionBlocked"] === true
  );
}

// --- Init ---

export function initWorkspaceObservationLedgerHistory(): void {
  if (isInitialized) return;

  const stored = readStore<unknown[]>(STORE_KEY);
  if (Array.isArray(stored)) {
    const valid = stored.filter(isValidEntry);
    historyRing = valid.slice(-MAX_ENTRIES);
    loadedOnBoot = historyRing.length;
    if (valid.length !== stored.length) {
      logger.warn(
        { total: stored.length, valid: valid.length, key: STORE_KEY },
        "Ledger history load: skipped invalid entries on boot",
      );
    }
    // Resume captureSeq from the highest persisted seq to avoid collisions
    if (historyRing.length > 0) {
      const maxSeq = Math.max(...historyRing.map((e) => e.captureSeq));
      nextCaptureSeq = maxSeq + 1;
    }
  }

  isInitialized = true;
  logger.info(
    {
      subsystem: "workspace_observation_ledger_history",
      loadedOnBoot,
      maxRetained: MAX_ENTRIES,
      storeKey: STORE_KEY,
      nextCaptureSeq,
    },
    "Workspace observation ledger history initialized",
  );
}

// --- Capture ---

export function captureWorkspaceObservationLedgerHistory(): LedgerHistoryCaptureResult {
  const snapshot = getWorkspaceObservationLedger();
  const captureSeq = nextCaptureSeq++;
  const createdAt = snapshot.generatedAt;
  const ledgerId = snapshot.ledgerId;

  const entry: LedgerHistoryEntry = {
    captureSeq,
    createdAt,
    ledgerId,
    snapshot,
    executionBlocked: EXECUTION_BLOCKED,
  };

  historyRing.push(entry);

  // Prune to ring cap — oldest (lowest captureSeq) removed first
  while (historyRing.length > MAX_ENTRIES) {
    historyRing.shift();
  }

  flush();

  return {
    captureSeq,
    createdAt,
    ledgerId,
    ringSize: historyRing.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- List ---

export function listWorkspaceObservationLedgerHistory(): LedgerHistoryListResult {
  // Newest-first (highest captureSeq first)
  const sorted = [...historyRing].sort((a, b) => b.captureSeq - a.captureSeq);

  const entries: LedgerHistoryListItem[] = sorted.map((e) => {
    // Safe projection of validation signals — older snapshots (pre-Phase 109)
    // may not have validationProbe; degrade safely rather than crash.
    const vp = e.snapshot.validationProbe as
      | { validationHealth: ValidationHealth; widgetCoveragePercent: number }
      | undefined
      | null;
    const validationHealth: ValidationHealth =
      vp != null && typeof vp.validationHealth === "string"
        ? (vp.validationHealth as ValidationHealth)
        : "failed";
    const widgetCoveragePercent: number =
      vp != null && typeof vp.widgetCoveragePercent === "number"
        ? vp.widgetCoveragePercent
        : 0;
    return {
      captureSeq: e.captureSeq,
      createdAt: e.createdAt,
      ledgerId: e.ledgerId,
      overallObservationHealth: e.snapshot.summary.overallObservationHealth,
      governanceReadiness: e.snapshot.summary.governanceReadiness,
      observationCoverage: e.snapshot.summary.observationCoverage,
      exposureRiskLevel: e.snapshot.summary.exposureRiskLevel,
      validationHealth,
      widgetCoveragePercent,
      executionBlocked: EXECUTION_BLOCKED,
    };
  });

  return {
    entries,
    total: entries.length,
    maxRetained: MAX_ENTRIES,
    storeKey: STORE_KEY,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getRawHistoryEntries(): LedgerHistoryEntry[] {
  return [...historyRing];
}

// --- Detail lookup ---

// O(20) bounded scan — ring max is 20.
// Returns null if captureSeq is not in the current ring (pruned or never existed).
// No persistence mutation, no live ledger recomputation.
export function getObservationLedgerHistoryDetail(
  captureSeq: number,
): LedgerHistoryDetailResult | null {
  const entry = historyRing.find((e) => e.captureSeq === captureSeq) ?? null;
  if (entry === null) return null;
  return {
    captureSeq: entry.captureSeq,
    createdAt: entry.createdAt,
    ledgerId: entry.ledgerId,
    ledgerSnapshot: entry.snapshot,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getLedgerHistoryStatus(): {
  storeKey: string;
  maxRetained: number;
  ringSize: number;
  loadedOnBoot: number;
  nextCaptureSeq: number;
  lastCapturedAt: string | null;
  executionBlocked: true;
} {
  const last = historyRing.length > 0 ? historyRing[historyRing.length - 1].createdAt : null;
  return {
    storeKey: STORE_KEY,
    maxRetained: MAX_ENTRIES,
    ringSize: historyRing.length,
    loadedOnBoot,
    nextCaptureSeq,
    lastCapturedAt: last,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
