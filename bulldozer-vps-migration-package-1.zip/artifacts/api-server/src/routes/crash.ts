import type { IncomingMessage, ServerResponse } from "node:http";
import { getCrashStatus } from "../core/crashDetector";
import { sendJson } from "../lib/response";

export function handleCrash(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getCrashStatus());
}
