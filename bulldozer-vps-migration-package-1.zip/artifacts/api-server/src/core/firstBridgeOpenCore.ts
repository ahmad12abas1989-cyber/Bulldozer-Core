// firstBridgeOpenCore.ts
// Phase 297 — First Bridge-Open Core Skeleton
// In-memory first bridge-open descriptor engine.
// Layer 18 of the write-preparation + preflight + activation + switch + transition + bridge stack.
// Prepares the bridge to move from closed toward future controlled write activation.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// bridgeOpenEnabled=false — the bridge-open gate has not been opened.
// bridgeOpenPrepared=true — descriptor-readiness established for a future bridge-open execution phase.

import type { ControlledWriteActivationBridgeRecord }  from "./controlledWriteActivationBridgeCore.js";
import type { FirstExecutionTransitionRecord }          from "./firstExecutionTransitionCore.js";
import type { FirstActivationSwitchRecord }             from "./firstActivationSwitchCore.js";
import type { FirstRealSandboxWriteActivationRecord }   from "./firstRealSandboxWriteActivationCore.js";
import type { ActualSandboxWritePreflightRecord }       from "./actualSandboxWritePreflightCore.js";
import type { ControlledExecutionRecord }               from "./controlledExecutionCore.js";
import { randomUUID }                                   from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type BridgeOpenState = "descriptor_bridge_open_pending";

export type BridgeOpenCheckRule =
  | "bridge_record_exists"
  | "execution_transition_exists"
  | "activation_switch_exists"
  | "activation_record_exists"
  | "preflight_record_exists"
  | "execution_record_exists"
  | "bridge_bound_to_transition"
  | "transition_bound_to_switch"
  | "switch_bound_to_activation"
  | "activation_bound_to_preflight"
  | "bridge_open_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface BridgeOpenCheck {
  readonly rule: BridgeOpenCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface BridgeOpenBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedBridgeOpenReference {
  readonly writeActivationBridgeId:    string;
  readonly executionTransitionId:      string;
  readonly activationSwitchId:         string;
  readonly activationId:               string;
  readonly rollbackSnapshotId:         string;
  readonly bridgeOpenPrepared:         true;
  readonly bridgeOpenEnabled:          false;
  readonly bridgeEnabled:              false;
  readonly rollbackChainValid:         boolean;
  readonly referenceNote:              string;
}

export interface BridgeOpenReadinessReport {
  readonly bridgeOpenPrepared:          true;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly summary:                     string;
}

export interface FirstBridgeOpenRecord {
  readonly bridgeOpenId:                string;
  readonly bridgeOpenState:             BridgeOpenState;
  readonly approvalRequired:            true;
  readonly bridgeOpenPrepared:          true;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly implementationPhase:         "descriptor_only";
  readonly writeActivationBridgeId:     string;
  readonly executionTransitionId:       string;
  readonly activationSwitchId:          string;
  readonly activationId:                string;
  readonly preflightId:                 string;
  readonly controlledExecutionId:       string;
  readonly bridgeOpenChecks:            readonly BridgeOpenCheck[];
  readonly bridgeOpenBlockedReasons:    readonly BridgeOpenBlockedReason[];
  readonly bridgeOpenReadinessReport:   BridgeOpenReadinessReport;
  readonly linkedBridgeOpenReference:   LinkedBridgeOpenReference;
  readonly createdAt:                   string;
}

export interface CreateBridgeOpenInput {
  readonly bridgeRecord:     ControlledWriteActivationBridgeRecord;
  readonly transitionRecord: FirstExecutionTransitionRecord;
  readonly switchRecord:     FirstActivationSwitchRecord;
  readonly activationRecord: FirstRealSandboxWriteActivationRecord;
  readonly preflightRecord:  ActualSandboxWritePreflightRecord;
  readonly executionRecord:  ControlledExecutionRecord;
}

export interface FirstBridgeOpenSummary {
  readonly total:                       number;
  readonly byState:                     Record<BridgeOpenState, number>;
  readonly bridgeOpenPrepared:          true;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly bridgeOpenState:             BridgeOpenState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstBridgeOpenRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateBridgeOpenInput): readonly BridgeOpenCheck[] {
  const { bridgeRecord, transitionRecord, switchRecord, activationRecord, preflightRecord, executionRecord } = input;

  const bridgeExists     = bridgeRecord.writeActivationBridgeId.length > 0;
  const transitionExists = transitionRecord.executionTransitionId.length > 0;
  const switchExists     = switchRecord.activationSwitchId.length > 0;
  const activationExists = activationRecord.activationId.length > 0;
  const preflightExists  = preflightRecord.preflightId.length > 0;
  const executionExists  = executionRecord.controlledExecutionId.length > 0;

  const bridgeBound      = bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId;
  const transitionBound  = transitionRecord.activationSwitchId === switchRecord.activationSwitchId;
  const switchBound      = switchRecord.activationId === activationRecord.activationId;
  const activationBound  = activationRecord.preflightId === preflightRecord.preflightId;

  return [
    {
      rule: "bridge_record_exists",
      pass: bridgeExists,
      note: bridgeExists
        ? `writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`
        : "bridgeRecord.writeActivationBridgeId is empty",
    },
    {
      rule: "execution_transition_exists",
      pass: transitionExists,
      note: transitionExists
        ? `executionTransitionId=${transitionRecord.executionTransitionId}`
        : "transitionRecord.executionTransitionId is empty",
    },
    {
      rule: "activation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `activationSwitchId=${switchRecord.activationSwitchId}`
        : "switchRecord.activationSwitchId is empty",
    },
    {
      rule: "activation_record_exists",
      pass: activationExists,
      note: activationExists
        ? `activationId=${activationRecord.activationId}`
        : "activationRecord.activationId is empty",
    },
    {
      rule: "preflight_record_exists",
      pass: preflightExists,
      note: preflightExists
        ? `preflightId=${preflightRecord.preflightId}`
        : "preflightRecord.preflightId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "bridge_bound_to_transition",
      pass: bridgeBound,
      note: bridgeBound
        ? `bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId (${transitionRecord.executionTransitionId})`
        : `bridge-transition mismatch: bridge.executionTransitionId=${bridgeRecord.executionTransitionId} vs transition.executionTransitionId=${transitionRecord.executionTransitionId}`,
    },
    {
      rule: "transition_bound_to_switch",
      pass: transitionBound,
      note: transitionBound
        ? `transitionRecord.activationSwitchId === switchRecord.activationSwitchId (${switchRecord.activationSwitchId})`
        : `transition-switch mismatch: transition.activationSwitchId=${transitionRecord.activationSwitchId} vs switch.activationSwitchId=${switchRecord.activationSwitchId}`,
    },
    {
      rule: "switch_bound_to_activation",
      pass: switchBound,
      note: switchBound
        ? `switchRecord.activationId === activationRecord.activationId (${activationRecord.activationId})`
        : `switch-activation mismatch: switch.activationId=${switchRecord.activationId} vs activation.activationId=${activationRecord.activationId}`,
    },
    {
      rule: "activation_bound_to_preflight",
      pass: activationBound,
      note: activationBound
        ? `activationRecord.preflightId === preflightRecord.preflightId (${preflightRecord.preflightId})`
        : `activation-preflight mismatch: activation.preflightId=${activationRecord.preflightId} vs preflight.preflightId=${preflightRecord.preflightId}`,
    },
    {
      rule: "bridge_open_still_disabled",
      pass: true,
      note: "bridgeOpenEnabled=false — compile-time literal; no bridge-open execution phase has opened the bridge",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "bridgeOpenState=descriptor_bridge_open_pending — output is a descriptor only; bridge-open gate is not yet live",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly BridgeOpenCheck[]): readonly BridgeOpenBlockedReason[] {
  const staticReasons: BridgeOpenBlockedReason[] = [
    { code: "bridge_open_disabled",   reason: "bridgeOpenEnabled=false — compile-time literal; an explicit bridge-open execution phase must set this to true",                                        static: true },
    { code: "approval_required",      reason: "approvalRequired=true — explicit operator approval is required before the bridge-open gate can be opened",                                              static: true },
    { code: "actual_writes_disabled", reason: "actualWritesEnabled=false — compile-time literal across all 18 sealed write-preparation, activation, switch, transition, and bridge layers",           static: true },
  ];
  const dynamicReasons: BridgeOpenBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedBridgeOpenReference(
  input: CreateBridgeOpenInput,
  rollbackChainValid: boolean,
): LinkedBridgeOpenReference {
  const { bridgeRecord, transitionRecord, switchRecord, activationRecord } = input;
  return {
    writeActivationBridgeId: bridgeRecord.writeActivationBridgeId,
    executionTransitionId:   transitionRecord.executionTransitionId,
    activationSwitchId:      switchRecord.activationSwitchId,
    activationId:            activationRecord.activationId,
    rollbackSnapshotId:      bridgeRecord.linkedBridgeReference.rollbackSnapshotId,
    bridgeOpenPrepared:      true,
    bridgeOpenEnabled:       false,
    bridgeEnabled:           false,
    rollbackChainValid,
    referenceNote:           "linked bridge-open reference sources rollbackSnapshotId from bridgeRecord.linkedBridgeReference; bridge-open disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createBridgeOpenRecord(input: CreateBridgeOpenInput): FirstBridgeOpenRecord {
  const { bridgeRecord, transitionRecord, switchRecord, activationRecord, preflightRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid =
    bridgeRecord.bridgeReadinessReport.rollbackChainValid &&
    preflightRecord.preflightReadinessReport.rollbackReady;

  const allChecksPass    = checks.every((c) => c.pass);
  const blockedReasons   = buildBlockedReasons(checks);
  const linkedRef        = buildLinkedBridgeOpenReference(input, rollbackChainValid);

  const bridgeOpenReadinessReport: BridgeOpenReadinessReport = {
    bridgeOpenPrepared:          true,
    bridgeOpenEnabled:           false,
    bridgeEnabled:               false,
    executionTransitionEnabled:  false,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    approvalRequired:            true,
    allChecksPass,
    blockedReasonCount:          blockedReasons.length,
    rollbackChainValid,
    summary: `bridgeOpenState=descriptor_bridge_open_pending; bridgeOpenEnabled=false; bridgeEnabled=false; actualWritesEnabled=false; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstBridgeOpenRecord = {
    bridgeOpenId:                randomUUID(),
    bridgeOpenState:             "descriptor_bridge_open_pending",
    approvalRequired:            true,
    bridgeOpenPrepared:          true,
    bridgeOpenEnabled:           false,
    bridgeEnabled:               false,
    executionTransitionEnabled:  false,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    filesystemMutationBlocked:   true,
    motherCoreMutationBlocked:   true,
    vaultMutationBlocked:        true,
    shellBlocked:                true,
    networkBlocked:              true,
    implementationPhase:         "descriptor_only",
    writeActivationBridgeId:     bridgeRecord.writeActivationBridgeId,
    executionTransitionId:       transitionRecord.executionTransitionId,
    activationSwitchId:          switchRecord.activationSwitchId,
    activationId:                activationRecord.activationId,
    preflightId:                 preflightRecord.preflightId,
    controlledExecutionId:       executionRecord.controlledExecutionId,
    bridgeOpenChecks:            checks,
    bridgeOpenBlockedReasons:    blockedReasons,
    bridgeOpenReadinessReport,
    linkedBridgeOpenReference:   linkedRef,
    createdAt:                   new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listBridgeOpenRecords(): readonly FirstBridgeOpenRecord[] {
  return _store.slice();
}

export function getBridgeOpenSummary(): FirstBridgeOpenSummary {
  return {
    total:                        _store.length,
    byState:                      { descriptor_bridge_open_pending: _store.length },
    bridgeOpenPrepared:           true,
    bridgeOpenEnabled:            false,
    bridgeEnabled:                false,
    executionTransitionEnabled:   false,
    activationSwitchEnabled:      false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    filesystemMutationBlocked:    true,
    motherCoreMutationBlocked:    true,
    bridgeOpenState:              "descriptor_bridge_open_pending",
    implementationPhase:          "descriptor_only",
  };
}
