import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { getAuditLogStatus, getFilteredAuditEntries, type AuditFilter } from "../core/auditLog";

const MAX_LIMIT = 200;
const DEFAULT_LIMIT = 100;

function decodeParam(val: string | undefined): string | undefined {
  if (val === undefined) return undefined;
  try {
    return decodeURIComponent(val);
  } catch {
    return undefined;
  }
}

export function handleAuditStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getAuditLogStatus());
}

export function handleAuditLog(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "";
  const queryStart = rawUrl.indexOf("?");
  const queryString = queryStart >= 0 ? rawUrl.slice(queryStart + 1) : "";

  const filter: AuditFilter = { limit: DEFAULT_LIMIT };

  if (queryString) {
    for (const part of queryString.split("&")) {
      const eqIdx = part.indexOf("=");
      if (eqIdx < 0) continue;
      const rawKey = part.slice(0, eqIdx);
      const rawVal = part.slice(eqIdx + 1);
      const key = decodeParam(rawKey);
      const val = decodeParam(rawVal);
      if (key === undefined || val === undefined || val === "") continue;

      switch (key) {
        case "limit": {
          const parsed = parseInt(val, 10);
          if (!isNaN(parsed) && parsed > 0) {
            filter.limit = Math.min(parsed, MAX_LIMIT);
          }
          break;
        }
        case "role":
          filter.role = val;
          break;
        case "actorType":
          filter.actorType = val;
          break;
        case "decision":
          filter.decision = val;
          break;
        case "route":
          filter.route = val;
          break;
        case "authSource":
          filter.authSource = val;
          break;
        default:
          break;
      }
    }
  }

  sendJson(res, 200, getFilteredAuditEntries(filter));
}
