import { listProjects, getProjectActivity } from "./projectRegistry";
import { listWorkspaceSnapshots } from "./workspaceSnapshots";

const EXECUTION_BLOCKED: true = true;
const MAX_TIMELINE_EVENTS = 500;
const ACTIVITY_PER_PROJECT_LIMIT = 100;
const ACTIVITY_FEED_RECENT_EVENTS = 5;

// --- Types ---

export type WorkspaceEventType =
  | "project_created"
  | "status_transition"
  | "member_added"
  | "member_removed"
  | "quota_updated"
  | "quota_reset"
  | "workspace_snapshot_created";

export type WorkspaceEventSource =
  | "project_registry"
  | "membership"
  | "quota"
  | "workspace_snapshots";

export interface WorkspaceTimelineEvent {
  eventId: string;
  eventType: WorkspaceEventType;
  source: WorkspaceEventSource;
  projectId: string | null;
  projectName: string | null;
  occurredAt: string;
  summary: string;
  metadata: Record<string, string | number | boolean | null>;
  executionBlocked: true;
}

export interface WorkspaceTimelineFilters {
  projectId?: string;
  eventType?: string;
  limit?: number;
}

export interface WorkspaceTimelineResult {
  queriedAt: string;
  events: WorkspaceTimelineEvent[];
  totalBeforeFilter: number;
  totalReturned: number;
  filters: {
    projectId: string | null;
    eventType: string | null;
    limit: number;
  };
  maxEvents: number;
  executionBlocked: true;
}

export interface WorkspaceActivityFeedItem {
  projectId: string;
  projectName: string;
  projectStatus: string;
  eventCount: number;
  lastActivityAt: string | null;
  recentEvents: WorkspaceTimelineEvent[];
  executionBlocked: true;
}

export interface WorkspaceActivityFeedResult {
  queriedAt: string;
  projects: WorkspaceActivityFeedItem[];
  totalProjects: number;
  totalEvents: number;
  workspaceSnapshotEvents: number;
  executionBlocked: true;
}

// --- Constants ---

const VALID_EVENT_TYPES = new Set<string>([
  "project_created",
  "status_transition",
  "member_added",
  "member_removed",
  "quota_updated",
  "quota_reset",
  "workspace_snapshot_created",
]);

// --- Internal helpers ---

function resolveSource(type: WorkspaceEventType): WorkspaceEventSource {
  switch (type) {
    case "member_added":
    case "member_removed":
      return "membership";
    case "quota_updated":
    case "quota_reset":
      return "quota";
    case "workspace_snapshot_created":
      return "workspace_snapshots";
    default:
      return "project_registry";
  }
}

function buildSummary(
  type: WorkspaceEventType,
  projectName: string | null,
  metadata: Record<string, string | number | boolean | null>,
): string {
  const name = projectName ?? "unknown";
  switch (type) {
    case "project_created":
      return `Project '${name}' created`;
    case "status_transition": {
      const prev = metadata["previousStatus"] ?? "unknown";
      const curr = metadata["currentStatus"] ?? "unknown";
      return `Project '${name}' transitioned ${String(prev)} → ${String(curr)}`;
    }
    case "member_added": {
      const actor = metadata["actorId"] ?? "unknown";
      const role = metadata["role"] ?? "unknown";
      return `Member '${String(actor)}' added to '${name}' as ${String(role)}`;
    }
    case "member_removed": {
      const actor = metadata["actorId"] ?? "unknown";
      return `Member '${String(actor)}' removed from '${name}'`;
    }
    case "quota_updated":
      return `Quota updated for project '${name}'`;
    case "quota_reset":
      return `Quota reset to defaults for project '${name}'`;
    case "workspace_snapshot_created": {
      const id = metadata["snapshotId"] ?? "unknown";
      return `Workspace snapshot captured (id: ${String(id)})`;
    }
  }
}

function buildAllEvents(): WorkspaceTimelineEvent[] {
  const events: WorkspaceTimelineEvent[] = [];
  const projects = listProjects();

  for (const project of projects) {
    const result = getProjectActivity(project.projectId, {
      limit: ACTIVITY_PER_PROJECT_LIMIT,
    });
    if (!result.success) continue;

    for (const activity of result.activities) {
      const type = activity.type as WorkspaceEventType;

      // Sanitize metadata — only safe scalar values, no nested objects or secrets
      const meta: Record<string, string | number | boolean | null> = {
        actorId: activity.actorId,
        projectId: project.projectId,
      };
      for (const [k, v] of Object.entries(activity.metadata)) {
        if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") {
          meta[k] = v;
        }
      }

      events.push({
        eventId: activity.activityId,
        eventType: type,
        source: resolveSource(type),
        projectId: project.projectId,
        projectName: project.projectName,
        occurredAt: activity.createdAt,
        summary: buildSummary(type, project.projectName, meta),
        metadata: meta,
        executionBlocked: EXECUTION_BLOCKED,
      });
    }
  }

  // Workspace-level snapshot events
  const snapshots = listWorkspaceSnapshots();
  for (const s of snapshots.snapshots) {
    const meta: Record<string, string | number | boolean | null> = {
      snapshotId: s.snapshotId,
      schemaVersion: s.schemaVersion,
      projectCount: s.projectCount,
      memberCount: s.memberCount,
      activityCount: s.activityCount,
    };
    events.push({
      eventId: s.snapshotId,
      eventType: "workspace_snapshot_created",
      source: "workspace_snapshots",
      projectId: null,
      projectName: null,
      occurredAt: s.createdAt,
      summary: buildSummary("workspace_snapshot_created", null, meta),
      metadata: meta,
      executionBlocked: EXECUTION_BLOCKED,
    });
  }

  // Sort newest-first, then cap
  events.sort(
    (a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime(),
  );
  return events.slice(0, MAX_TIMELINE_EVENTS);
}

// --- Public API ---

export function getWorkspaceTimeline(
  filters: WorkspaceTimelineFilters = {},
): WorkspaceTimelineResult {
  const allEvents = buildAllEvents();
  const totalBeforeFilter = allEvents.length;

  const normalizedLimit =
    typeof filters.limit === "number" && filters.limit > 0 && filters.limit <= 500
      ? Math.floor(filters.limit)
      : 100;

  const normalizedProjectId =
    typeof filters.projectId === "string" && filters.projectId.length > 0
      ? filters.projectId
      : null;

  const normalizedEventType =
    typeof filters.eventType === "string" && VALID_EVENT_TYPES.has(filters.eventType)
      ? filters.eventType
      : null;

  let filtered = allEvents;

  if (normalizedProjectId !== null) {
    filtered = filtered.filter((e) => e.projectId === normalizedProjectId);
  }

  if (normalizedEventType !== null) {
    filtered = filtered.filter((e) => e.eventType === normalizedEventType);
  }

  const events = filtered.slice(0, normalizedLimit);

  return {
    queriedAt: new Date().toISOString(),
    events,
    totalBeforeFilter,
    totalReturned: events.length,
    filters: {
      projectId: normalizedProjectId,
      eventType: normalizedEventType,
      limit: normalizedLimit,
    },
    maxEvents: MAX_TIMELINE_EVENTS,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getWorkspaceActivityFeed(): WorkspaceActivityFeedResult {
  const allEvents = buildAllEvents();
  const projects = listProjects();

  const snapshotEvents = allEvents.filter((e) => e.source === "workspace_snapshots");

  const feedItems: WorkspaceActivityFeedItem[] = [];
  for (const project of projects) {
    const projectEvents = allEvents.filter((e) => e.projectId === project.projectId);
    if (projectEvents.length === 0) continue;

    // allEvents is already newest-first; projectEvents preserves that order
    const lastActivityAt = projectEvents[0]?.occurredAt ?? null;
    const recentEvents = projectEvents.slice(0, ACTIVITY_FEED_RECENT_EVENTS);

    feedItems.push({
      projectId: project.projectId,
      projectName: project.projectName,
      projectStatus: project.status,
      eventCount: projectEvents.length,
      lastActivityAt,
      recentEvents,
      executionBlocked: EXECUTION_BLOCKED,
    });
  }

  // Sort by most recently active first
  feedItems.sort((a, b) => {
    if (a.lastActivityAt === null) return 1;
    if (b.lastActivityAt === null) return -1;
    return (
      new Date(b.lastActivityAt).getTime() - new Date(a.lastActivityAt).getTime()
    );
  });

  return {
    queriedAt: new Date().toISOString(),
    projects: feedItems,
    totalProjects: feedItems.length,
    totalEvents: allEvents.length,
    workspaceSnapshotEvents: snapshotEvents.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
