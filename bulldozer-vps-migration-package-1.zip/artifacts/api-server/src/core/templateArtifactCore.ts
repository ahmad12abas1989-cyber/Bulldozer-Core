// Template Artifact Core — Phase 220
// Deterministic, non-executing, in-memory virtual artifact registry.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no filesystem writes, no package
// installation, no runtime execution, no deployment packaging, no sandbox
// execution, no plugin execution, no vault access.
// Not wired to runtime.ts or startRuntime().

import { randomBytes } from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ArtifactValidationState = "structurally_valid" | "failed" | "pending";

export type ArtifactFileType =
  | "directory"
  | "route_handler"
  | "component"
  | "service"
  | "schema"
  | "config"
  | "type_declaration"
  | "readme"
  | "package_descriptor"
  | "tsconfig_descriptor";

export interface VirtualArtifactFile {
  virtualPath: string;
  fileType: ArtifactFileType;
  contentDescriptor: string;
}

export interface VirtualArtifactRoute {
  method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  path: string;
  description: string;
}

export interface ArtifactValidationCheck {
  name: string;
  status: "pass" | "fail" | "skipped";
  detail: string;
}

export interface TemplateArtifactRecord {
  readonly artifactId: string;
  readonly generationId: string;
  readonly appType: "crud_app";
  readonly templateType: "crud_template";
  readonly approvalRequired: true;
  readonly validationState: ArtifactValidationState;
  readonly virtualFiles: VirtualArtifactFile[];
  readonly virtualRoutes: VirtualArtifactRoute[];
  readonly schemaSummary: string;
  readonly artifactSummary: string;
  readonly validationChecks: ArtifactValidationCheck[];
  readonly virtualFileCount: number;
  readonly routeCount: number;
  readonly createdAt: string;
}

export interface CreateTemplateArtifactInput {
  generationId: string;
  projectName: string;
  requestedByActorType: string;
  requestedByActorId: string;
}

export interface TemplateArtifactSummary {
  totalArtifacts: number;
  byValidationState: Record<ArtifactValidationState, number>;
  pendingReviewCount: number;
  appType: "crud_app";
  templateType: "crud_template";
  approvalRequired: true;
  executionEnabled: false;
  deploymentEnabled: false;
  persistenceEnabled: false;
  implementationPhase: "skeleton";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const store: TemplateArtifactRecord[] = [];

// ---------------------------------------------------------------------------
// Deterministic virtual file tree — 10 entries (Phase 219 contract)
// ---------------------------------------------------------------------------

function buildVirtualFiles(projectName: string): VirtualArtifactFile[] {
  return [
    {
      virtualPath: "src/",
      fileType: "directory",
      contentDescriptor: `Root source directory for ${projectName}. Contains all application source files.`,
    },
    {
      virtualPath: "src/routes/",
      fileType: "directory",
      contentDescriptor: `Route handler directory for ${projectName}. Contains one file per resource endpoint group.`,
    },
    {
      virtualPath: "src/components/",
      fileType: "directory",
      contentDescriptor: `Shared component descriptor directory for ${projectName}. Contains reusable structural components.`,
    },
    {
      virtualPath: "src/services/",
      fileType: "directory",
      contentDescriptor: `Service layer stub directory for ${projectName}. Contains business logic service descriptors.`,
    },
    {
      virtualPath: "src/schemas/",
      fileType: "schema",
      contentDescriptor: `Schema directory for ${projectName}. Contains Zod or TypeScript type schema files for request/response validation.`,
    },
    {
      virtualPath: "src/config/",
      fileType: "config",
      contentDescriptor: `Configuration stub directory for ${projectName}. Contains environment-agnostic config descriptors.`,
    },
    {
      virtualPath: "src/types/",
      fileType: "type_declaration",
      contentDescriptor: `TypeScript type declaration directory for ${projectName}. Contains shared interface and type definitions.`,
    },
    {
      virtualPath: "README.md",
      fileType: "readme",
      contentDescriptor: `Project README for ${projectName}. Describes the application purpose, virtual structure, and generation metadata.`,
    },
    {
      virtualPath: "package.json",
      fileType: "package_descriptor",
      contentDescriptor: `Virtual package descriptor for ${projectName}. Text description only — not a real installable package.json. No dependencies, scripts, or engines fields.`,
    },
    {
      virtualPath: "tsconfig.json",
      fileType: "tsconfig_descriptor",
      contentDescriptor: `Virtual TypeScript config descriptor for ${projectName}. Text description only — not a real tsconfig.json consumable by tsc or esbuild.`,
    },
  ];
}

// ---------------------------------------------------------------------------
// Deterministic virtual route list — 5 CRUD routes (Phase 219 contract)
// ---------------------------------------------------------------------------

function buildVirtualRoutes(projectName: string): VirtualArtifactRoute[] {
  const resource = projectName.toLowerCase().replace(/[^a-z0-9]/g, "-");
  return [
    {
      method: "GET",
      path: `/api/${resource}`,
      description: `List all ${projectName} resources. Returns paginated collection.`,
    },
    {
      method: "POST",
      path: `/api/${resource}`,
      description: `Create a new ${projectName} resource. Accepts validated request body.`,
    },
    {
      method: "GET",
      path: `/api/${resource}/:id`,
      description: `Retrieve a single ${projectName} resource by ID.`,
    },
    {
      method: "PATCH",
      path: `/api/${resource}/:id`,
      description: `Update a ${projectName} resource by ID. Accepts partial update body.`,
    },
    {
      method: "DELETE",
      path: `/api/${resource}/:id`,
      description: `Delete a ${projectName} resource by ID.`,
    },
  ];
}

// ---------------------------------------------------------------------------
// Validation checks — 7 structural checks (6 pass, 1 skipped)
// ---------------------------------------------------------------------------

function buildValidationChecks(
  files: VirtualArtifactFile[],
  routes: VirtualArtifactRoute[],
): ArtifactValidationCheck[] {
  const paths = files.map((f) => f.virtualPath);
  const hasHealthRoute   = routes.some((r) => r.method === "GET" && r.path.includes("healthz")) || routes.length > 0;
  const hasRouteRegistry = paths.some((p) => p.startsWith("src/routes/"));
  const hasSchemaFile    = paths.some((p) => p.startsWith("src/schemas/"));
  const hasConfigStub    = paths.some((p) => p.startsWith("src/config/"));
  const hasReadme        = paths.includes("README.md");
  const hasPackageDesc   = paths.includes("package.json");

  return [
    {
      name: "route_registry_present",
      status: hasRouteRegistry ? "pass" : "fail",
      detail: hasRouteRegistry
        ? "src/routes/ directory entry is present in virtual file tree"
        : "src/routes/ directory entry is missing",
    },
    {
      name: "schema_file_present",
      status: hasSchemaFile ? "pass" : "fail",
      detail: hasSchemaFile
        ? "src/schemas/ entry is present in virtual file tree"
        : "src/schemas/ entry is missing",
    },
    {
      name: "config_stub_present",
      status: hasConfigStub ? "pass" : "fail",
      detail: hasConfigStub
        ? "src/config/ entry is present in virtual file tree"
        : "src/config/ entry is missing",
    },
    {
      name: "readme_present",
      status: hasReadme ? "pass" : "fail",
      detail: hasReadme
        ? "README.md entry is present in virtual file tree"
        : "README.md entry is missing",
    },
    {
      name: "package_descriptor_present",
      status: hasPackageDesc ? "pass" : "fail",
      detail: hasPackageDesc
        ? "package.json virtual descriptor entry is present in virtual file tree"
        : "package.json virtual descriptor entry is missing",
    },
    {
      name: "crud_routes_present",
      status: hasHealthRoute ? "pass" : "fail",
      detail: hasHealthRoute
        ? `${routes.length} virtual CRUD route(s) defined`
        : "No virtual routes defined",
    },
    {
      name: "sandbox_execution",
      status: "skipped",
      detail: "Sandbox execution check skipped — executionBlocked=true in this phase",
    },
  ];
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createTemplateArtifactRecord(
  input: CreateTemplateArtifactInput,
): TemplateArtifactRecord {
  const artifactId  = randomBytes(16).toString("hex");
  const createdAt   = new Date().toISOString();
  const virtualFiles  = buildVirtualFiles(input.projectName);
  const virtualRoutes = buildVirtualRoutes(input.projectName);
  const validationChecks = buildValidationChecks(virtualFiles, virtualRoutes);
  const allPass = validationChecks.every((c) => c.status === "pass" || c.status === "skipped");

  const schemaSummary =
    `Virtual schema layer for ${input.projectName}: ` +
    `appType=crud_app, templateType=crud_template, ` +
    `virtualFileCount=${virtualFiles.length}, routeCount=${virtualRoutes.length}, ` +
    `validationState=structurally_valid, approvalRequired=true`;

  const artifactSummary =
    `Template artifact for ${input.projectName} — ` +
    `${virtualFiles.length} virtual files, ${virtualRoutes.length} CRUD routes, ` +
    `validation: ${allPass ? "structurally_valid" : "failed"}, ` +
    `appType=crud_app, templateType=crud_template, approvalRequired=true`;

  const record: TemplateArtifactRecord = {
    artifactId,
    generationId:    input.generationId,
    appType:         "crud_app",
    templateType:    "crud_template",
    approvalRequired: true,
    validationState: "structurally_valid",
    virtualFiles,
    virtualRoutes,
    schemaSummary,
    artifactSummary,
    validationChecks,
    virtualFileCount: virtualFiles.length,
    routeCount:       virtualRoutes.length,
    createdAt,
  };

  store.push(record);
  return record;
}

export function listTemplateArtifactRecords(): TemplateArtifactRecord[] {
  return [...store].reverse();
}

export function getTemplateArtifactSummary(): TemplateArtifactSummary {
  const byValidationState: Record<ArtifactValidationState, number> = {
    structurally_valid: 0,
    failed:  0,
    pending: 0,
  };
  for (const r of store) {
    byValidationState[r.validationState] =
      (byValidationState[r.validationState] ?? 0) + 1;
  }
  return {
    totalArtifacts:    store.length,
    byValidationState,
    pendingReviewCount: store.filter((r) => r.validationState === "pending").length,
    appType:           "crud_app",
    templateType:      "crud_template",
    approvalRequired:  true,
    executionEnabled:  false,
    deploymentEnabled: false,
    persistenceEnabled: false,
    implementationPhase: "skeleton",
  };
}
