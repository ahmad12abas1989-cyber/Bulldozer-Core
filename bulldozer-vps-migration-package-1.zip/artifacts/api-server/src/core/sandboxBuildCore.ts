// Sandbox Build Core — Phase 232
// Deterministic, non-executing, in-memory sandbox build planning engine.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no filesystem writes, no package
// installation, no runtime execution, no shell execution, no network access,
// no vault access, no Docker build, no deployment package, no generated app launch,
// no secrets, no Mother Core mutation.
// Not wired to runtime.ts or startRuntime().

import { randomBytes } from "node:crypto";
import type { TemplateArtifactRecord } from "./templateArtifactCore";
import type { VirtualPackageRecord } from "./virtualPackageCore";
import type { DependencyResolutionRecord } from "./dependencyResolutionCore";
import type { SandboxRunRecord } from "./sandboxCore";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type SandboxBuildState = "virtually_prepared";

export type SandboxBuildStepName =
  | "prepare_workspace"
  | "map_virtual_files"
  | "validate_package_manifest"
  | "apply_resolution_order"
  | "simulate_typecheck"
  | "simulate_bundle"
  | "produce_build_report";

export interface SandboxBuildStep {
  readonly step: number;
  readonly name: SandboxBuildStepName;
  readonly descriptor: string;
  readonly executionBlocked: true;
}

export interface SandboxBuildValidationCheck {
  readonly name: string;
  readonly status: "pass" | "fail" | "skipped";
  readonly detail: string;
}

export interface SandboxBuildOutputDescriptor {
  readonly outputName: string;
  readonly outputType: "build_report" | "virtual_bundle" | "virtual_typecheck_result" | "virtual_workspace_map";
  readonly descriptor: string;
  readonly isVirtual: true;
  readonly realFileProduced: false;
}

export interface SandboxBuildCompatibilitySummary {
  readonly artifactCompatible: boolean;
  readonly packageCompatible: boolean;
  readonly resolutionCompatible: boolean;
  readonly sandboxCompatible: boolean;
  readonly overallCompatible: boolean;
  readonly runtimeVersion: string;
  readonly buildTool: string;
}

export interface SandboxBuildReportSummary {
  readonly totalBuildSteps: number;
  readonly completedSteps: number;
  readonly blockedSteps: number;
  readonly validationPassCount: number;
  readonly validationFailCount: number;
  readonly validationSkipCount: number;
  readonly buildState: SandboxBuildState;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
}

export interface SandboxBuildRecord {
  readonly buildPlanId: string;
  readonly artifactId: string;
  readonly packageId: string;
  readonly resolutionId: string;
  readonly sandboxRunId: string;
  readonly buildState: SandboxBuildState;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
  readonly buildSteps: SandboxBuildStep[];
  readonly expectedOutputs: SandboxBuildOutputDescriptor[];
  readonly validationChecks: SandboxBuildValidationCheck[];
  readonly compatibilitySummary: SandboxBuildCompatibilitySummary;
  readonly buildReportSummary: SandboxBuildReportSummary;
  readonly createdAt: string;
}

export interface CreateSandboxBuildInput {
  readonly artifactRecord: TemplateArtifactRecord;
  readonly packageRecord: VirtualPackageRecord;
  readonly resolutionRecord: DependencyResolutionRecord;
  readonly sandboxRunRecord: SandboxRunRecord;
  readonly operatorApprovalActorId: string;
  readonly operatorApprovalTimestamp: string;
}

export interface SandboxBuildSummary {
  readonly totalBuildPlans: number;
  readonly byBuildState: Record<SandboxBuildState, number>;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
  readonly implementationPhase: "skeleton";
}

// ---------------------------------------------------------------------------
// Deterministic build step generation (7 fixed steps — Phase 231 blueprint)
// ---------------------------------------------------------------------------

const BUILD_STEP_DESCRIPTORS: ReadonlyArray<{
  name: SandboxBuildStepName;
  descriptor: string;
}> = [
  {
    name: "prepare_workspace",
    descriptor:
      "Step 1: prepare_workspace — Descriptor: workspace preparation intent. " +
      "No real directory creation. No filesystem writes. No shell execution. Descriptor-only.",
  },
  {
    name: "map_virtual_files",
    descriptor:
      "Step 2: map_virtual_files — Descriptor: virtual file mapping from artifact file descriptors. " +
      "No real file writes. No filesystem access. Descriptor-only.",
  },
  {
    name: "validate_package_manifest",
    descriptor:
      "Step 3: validate_package_manifest — Descriptor: package manifest validation intent. " +
      "No real manifest parsing. No npm/yarn/pnpm invocation. Descriptor-only.",
  },
  {
    name: "apply_resolution_order",
    descriptor:
      "Step 4: apply_resolution_order — Descriptor: resolution order application from dependency resolution record. " +
      "No real package installation. No install execution. Descriptor-only.",
  },
  {
    name: "simulate_typecheck",
    descriptor:
      "Step 5: simulate_typecheck — Descriptor: typecheck simulation intent. " +
      "No real tsc invocation. No shell execution. No source file access. Descriptor-only.",
  },
  {
    name: "simulate_bundle",
    descriptor:
      "Step 6: simulate_bundle — Descriptor: bundle simulation intent. " +
      "No real esbuild invocation. No file output. No shell execution. Descriptor-only.",
  },
  {
    name: "produce_build_report",
    descriptor:
      "Step 7: produce_build_report — Descriptor: build report production. " +
      "Text output only. No real file produced. No deployment package. Descriptor-only.",
  },
];

function buildSteps(): SandboxBuildStep[] {
  return BUILD_STEP_DESCRIPTORS.map((s, idx) => ({
    step: idx + 1,
    name: s.name,
    descriptor: s.descriptor,
    executionBlocked: true,
  }));
}

// ---------------------------------------------------------------------------
// Deterministic expected output generation
// ---------------------------------------------------------------------------

function buildExpectedOutputs(artifactId: string): SandboxBuildOutputDescriptor[] {
  return [
    {
      outputName: `virtual-workspace-map-${artifactId}`,
      outputType: "virtual_workspace_map",
      descriptor:
        "Virtual workspace map — text descriptor of the planned workspace structure. No real directory created.",
      isVirtual: true,
      realFileProduced: false,
    },
    {
      outputName: `virtual-typecheck-result-${artifactId}`,
      outputType: "virtual_typecheck_result",
      descriptor:
        "Virtual typecheck result — text descriptor of simulated typecheck outcome. No real tsc output file.",
      isVirtual: true,
      realFileProduced: false,
    },
    {
      outputName: `virtual-bundle-${artifactId}`,
      outputType: "virtual_bundle",
      descriptor:
        "Virtual bundle — text descriptor of simulated bundle intent. No real bundle file produced.",
      isVirtual: true,
      realFileProduced: false,
    },
    {
      outputName: `build-report-${artifactId}`,
      outputType: "build_report",
      descriptor:
        "Build report — text summary of build plan execution intent. No real file written. Descriptor-only.",
      isVirtual: true,
      realFileProduced: false,
    },
  ];
}

// ---------------------------------------------------------------------------
// Validation checks — 7 required (Phase 231 blueprint)
// ---------------------------------------------------------------------------

function buildValidationChecks(
  input: CreateSandboxBuildInput,
): SandboxBuildValidationCheck[] {
  const { artifactRecord, packageRecord, resolutionRecord, sandboxRunRecord, operatorApprovalActorId } = input;

  const artifactExists = artifactRecord !== null && artifactRecord !== undefined;
  const packageExists  = packageRecord  !== null && packageRecord  !== undefined;
  const resolutionExists = resolutionRecord !== null && resolutionRecord !== undefined;
  const sandboxApprovalExists =
    typeof operatorApprovalActorId === "string" && operatorApprovalActorId.length > 0;
  const noBlockingConflicts =
    resolutionExists && resolutionRecord.conflictSummary.blocking === 0;
  const stepsDescriptorOnly = true; // structural: all steps in this phase are descriptor-only
  const outputVirtual = true;       // structural: no real files produced in this phase

  void sandboxRunRecord; // consumed for typing; no field access needed for these checks

  return [
    {
      name: "artifact_structure_exists",
      status: artifactExists ? "pass" : "fail",
      detail: artifactExists
        ? `Artifact record "${artifactRecord.artifactId}" is present`
        : "Virtual artifact record is missing",
    },
    {
      name: "package_descriptor_exists",
      status: packageExists ? "pass" : "fail",
      detail: packageExists
        ? `Package record "${packageRecord.packageId}" is present`
        : "Virtual package record is missing",
    },
    {
      name: "resolution_graph_exists",
      status: resolutionExists ? "pass" : "fail",
      detail: resolutionExists
        ? `Resolution record "${resolutionRecord.resolutionId}" is present`
        : "Dependency resolution record is missing",
    },
    {
      name: "no_blocked_dependency_conflicts",
      status: noBlockingConflicts ? "pass" : "fail",
      detail: noBlockingConflicts
        ? "No blocking dependency conflicts detected in resolution record"
        : `Resolution record has ${resolutionExists ? resolutionRecord.conflictSummary.blocking : "unknown"} blocking conflict(s)`,
    },
    {
      name: "sandbox_approval_present",
      status: sandboxApprovalExists ? "pass" : "fail",
      detail: sandboxApprovalExists
        ? `Operator approval present — actorId: "${operatorApprovalActorId}"`
        : "Operator approval actorId is missing or empty",
    },
    {
      name: "build_steps_descriptor_only",
      status: stepsDescriptorOnly ? "pass" : "fail",
      detail: stepsDescriptorOnly
        ? "All 7 build steps are text descriptors — no executable content present"
        : "One or more build steps contain executable content — prohibited",
    },
    {
      name: "output_remains_virtual",
      status: outputVirtual ? "pass" : "fail",
      detail: outputVirtual
        ? "All expected outputs are virtual text descriptors — no real files produced"
        : "Real file output detected — prohibited in this phase",
    },
  ];
}

// ---------------------------------------------------------------------------
// Compatibility summary
// ---------------------------------------------------------------------------

function buildCompatibilitySummary(
  input: CreateSandboxBuildInput,
): SandboxBuildCompatibilitySummary {
  const { artifactRecord, packageRecord, resolutionRecord, sandboxRunRecord } = input;

  const artifactCompatible   = artifactRecord.validationState === "structurally_valid";
  const packageCompatible    = packageRecord.dependencies.length >= 0; // always pass — structural
  const resolutionCompatible = resolutionRecord.conflictSummary.blocking === 0;
  const sandboxCompatible    = sandboxRunRecord.status === "pending_approval" || sandboxRunRecord.status === "approved" || sandboxRunRecord.status === "completed";
  const overallCompatible    = artifactCompatible && packageCompatible && resolutionCompatible && sandboxCompatible;

  return {
    artifactCompatible,
    packageCompatible,
    resolutionCompatible,
    sandboxCompatible,
    overallCompatible,
    runtimeVersion: packageRecord.runtimeManifest.nodeVersion,
    buildTool:      packageRecord.buildManifest.tool,
  };
}

// ---------------------------------------------------------------------------
// Build report summary
// ---------------------------------------------------------------------------

function buildReportSummary(
  steps: SandboxBuildStep[],
  checks: SandboxBuildValidationCheck[],
): SandboxBuildReportSummary {
  const passCount = checks.filter((c) => c.status === "pass").length;
  const failCount = checks.filter((c) => c.status === "fail").length;
  const skipCount = checks.filter((c) => c.status === "skipped").length;

  return {
    totalBuildSteps:       steps.length,
    completedSteps:        0,          // no execution in this phase
    blockedSteps:          steps.length,
    validationPassCount:   passCount,
    validationFailCount:   failCount,
    validationSkipCount:   skipCount,
    buildState:            "virtually_prepared",
    approvalRequired:      true,
    executionBlocked:      true,
    deploymentBlocked:     true,
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const store: SandboxBuildRecord[] = [];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createSandboxBuildRecord(
  input: CreateSandboxBuildInput,
): SandboxBuildRecord {
  const buildPlanId = randomBytes(16).toString("hex");
  const createdAt   = new Date().toISOString();

  const steps   = buildSteps();
  const outputs = buildExpectedOutputs(input.artifactRecord.artifactId);
  const checks  = buildValidationChecks(input);
  const compat  = buildCompatibilitySummary(input);
  const report  = buildReportSummary(steps, checks);

  const record: SandboxBuildRecord = {
    buildPlanId,
    artifactId:           input.artifactRecord.artifactId,
    packageId:            input.packageRecord.packageId,
    resolutionId:         input.resolutionRecord.resolutionId,
    sandboxRunId:         input.sandboxRunRecord.sandboxRunId,
    buildState:           "virtually_prepared",
    approvalRequired:     true,
    executionBlocked:     true,
    deploymentBlocked:    true,
    buildSteps:           steps,
    expectedOutputs:      outputs,
    validationChecks:     checks,
    compatibilitySummary: compat,
    buildReportSummary:   report,
    createdAt,
  };

  store.push(record);
  return record;
}

export function listSandboxBuildRecords(): SandboxBuildRecord[] {
  return [...store].reverse();
}

export function getSandboxBuildSummary(): SandboxBuildSummary {
  const byBuildState: Record<SandboxBuildState, number> = {
    virtually_prepared: 0,
  };
  for (const r of store) {
    byBuildState[r.buildState] = (byBuildState[r.buildState] ?? 0) + 1;
  }
  return {
    totalBuildPlans:  store.length,
    byBuildState,
    approvalRequired: true,
    executionBlocked: true,
    deploymentBlocked: true,
    implementationPhase: "skeleton",
  };
}
