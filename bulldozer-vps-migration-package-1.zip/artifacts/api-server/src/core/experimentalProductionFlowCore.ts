import { AppFactoryRequestRecord }     from "./appFactoryCore.js";
import { TemplateMetadataRecord }       from "./templateRegistryCore.js";
import { ExperimentalGenerationRecord } from "./experimentalGenerationCore.js";
import { TemplateArtifactRecord }       from "./templateArtifactCore.js";
import { VirtualPackageRecord }         from "./virtualPackageCore.js";
import { DependencyResolutionRecord }   from "./dependencyResolutionCore.js";
import { SandboxBuildRecord }           from "./sandboxBuildCore.js";
import { InstallSimulationRecord }      from "./installSimulationCore.js";
import { VirtualWorkspaceRecord }       from "./virtualWorkspaceCore.js";
import { PreviewPipelineRecord }        from "./previewPipelineCore.js";
import { randomBytes }                  from "node:crypto";

export type ExperimentalProductionFlowState = "descriptor_ready";

export type ExperimentalFlowStage =
  | "receive_request"
  | "select_template"
  | "generate_virtual_artifact"
  | "create_virtual_package"
  | "resolve_dependencies"
  | "prepare_sandbox_build"
  | "simulate_install"
  | "map_virtual_workspace"
  | "generate_preview"
  | "operator_review";

export type ExperimentalValidationRule =
  | "all_linked_records_exist"
  | "stage_order_deterministic"
  | "no_blocked_dependency_conflicts"
  | "install_simulation_passed_structurally"
  | "preview_descriptors_exist"
  | "approval_gate_present"
  | "output_remains_virtual";

export interface ExperimentalReadinessCheck {
  readonly rule:    ExperimentalValidationRule;
  readonly passed:  boolean;
  readonly message: string;
}

export interface ExperimentalBlockingCheck {
  readonly stage:   ExperimentalFlowStage;
  readonly blocked: true;
  readonly reason:  string;
}

export interface ExperimentalLinkedRecordIds {
  readonly receive_request:         string;
  readonly select_template:         string;
  readonly generate_virtual_artifact: string;
  readonly create_virtual_package:  string;
  readonly resolve_dependencies:    string;
  readonly prepare_sandbox_build:   string;
  readonly simulate_install:        string;
  readonly map_virtual_workspace:   string;
  readonly generate_preview:        string;
  readonly operator_review:         string;
}

export interface ExperimentalProductionFlowRecord {
  readonly flowId:             string;
  readonly createdAt:          string;
  readonly flowState:          ExperimentalProductionFlowState;
  readonly approvalRequired:   true;
  readonly executionBlocked:   true;
  readonly filesystemBlocked:  true;
  readonly deploymentBlocked:  true;
  readonly linkedRecordIds:    ExperimentalLinkedRecordIds;
  readonly stageSequence:      readonly ExperimentalFlowStage[];
  readonly readinessReport:    readonly ExperimentalReadinessCheck[];
  readonly blockingReport:     readonly ExperimentalBlockingCheck[];
  readonly flowSummary:        ExperimentalFlowSummaryInline;
}

export interface ExperimentalFlowSummaryInline {
  readonly totalStages:            number;
  readonly totalReadinessChecks:   number;
  readonly totalBlockingChecks:    number;
  readonly allReadinessChecksPassed: boolean;
  readonly allStagesBlocked:       boolean;
  readonly executionBlocked:       true;
  readonly filesystemBlocked:      true;
  readonly deploymentBlocked:      true;
  readonly implementationPhase:    "blueprint_descriptor";
}

export interface CreateExperimentalProductionFlowInput {
  readonly factoryRequest:      AppFactoryRequestRecord;
  readonly templateMetadata:    TemplateMetadataRecord;
  readonly generationRecord:    ExperimentalGenerationRecord;
  readonly artifactRecord:      TemplateArtifactRecord;
  readonly packageRecord:       VirtualPackageRecord;
  readonly resolutionRecord:    DependencyResolutionRecord;
  readonly buildRecord:         SandboxBuildRecord;
  readonly installRecord:       InstallSimulationRecord;
  readonly workspaceRecord:     VirtualWorkspaceRecord;
  readonly previewRecord:       PreviewPipelineRecord;
  readonly operatorApprovalRef: string;
}

export interface ExperimentalProductionFlowSummary {
  readonly totalFlows:          number;
  readonly byFlowState:         Record<ExperimentalProductionFlowState, number>;
  readonly executionBlocked:    true;
  readonly filesystemBlocked:   true;
  readonly deploymentBlocked:   true;
  readonly implementationPhase: "blueprint_descriptor";
}

const CANONICAL_STAGE_SEQUENCE: readonly ExperimentalFlowStage[] = [
  "receive_request",
  "select_template",
  "generate_virtual_artifact",
  "create_virtual_package",
  "resolve_dependencies",
  "prepare_sandbox_build",
  "simulate_install",
  "map_virtual_workspace",
  "generate_preview",
  "operator_review",
] as const;

const VALIDATION_RULES: readonly ExperimentalValidationRule[] = [
  "all_linked_records_exist",
  "stage_order_deterministic",
  "no_blocked_dependency_conflicts",
  "install_simulation_passed_structurally",
  "preview_descriptors_exist",
  "approval_gate_present",
  "output_remains_virtual",
] as const;

function buildLinkedRecordIds(
  input: CreateExperimentalProductionFlowInput,
): ExperimentalLinkedRecordIds {
  return {
    receive_request:           input.factoryRequest.factoryRequestId,
    select_template:           input.templateMetadata.templateId,
    generate_virtual_artifact: input.generationRecord.generationId,
    create_virtual_package:    input.packageRecord.packageId,
    resolve_dependencies:      input.resolutionRecord.resolutionId,
    prepare_sandbox_build:     input.buildRecord.buildPlanId,
    simulate_install:          input.installRecord.installSimulationId,
    map_virtual_workspace:     input.workspaceRecord.workspaceId,
    generate_preview:          input.previewRecord.previewId,
    operator_review:           input.operatorApprovalRef,
  };
}

function buildReadinessReport(
  input: CreateExperimentalProductionFlowInput,
): readonly ExperimentalReadinessCheck[] {
  const hasConflicts = input.resolutionRecord.conflictSummary.totalConflicts > 0;
  const hasPreviewScreens = input.previewRecord.previewScreens.length > 0;
  const installPassed = input.installRecord.simulationState === "descriptor_simulated";

  return VALIDATION_RULES.map((rule): ExperimentalReadinessCheck => {
    switch (rule) {
      case "all_linked_records_exist":
        return { rule, passed: true, message: "All 10 input records resolved to non-null entries" };
      case "stage_order_deterministic":
        return { rule, passed: true, message: "Stage sequence matches canonical 10-stage order" };
      case "no_blocked_dependency_conflicts":
        return {
          rule,
          passed:  !hasConflicts,
          message: hasConflicts
            ? `${input.resolutionRecord.conflictSummary.totalConflicts} dependency conflict(s) detected`
            : "No dependency conflicts detected",
        };
      case "install_simulation_passed_structurally":
        return {
          rule,
          passed:  installPassed,
          message: installPassed
            ? "Install simulation completed with state descriptor_simulated"
            : "Install simulation did not reach descriptor_simulated state",
        };
      case "preview_descriptors_exist":
        return {
          rule,
          passed:  hasPreviewScreens,
          message: hasPreviewScreens
            ? `${input.previewRecord.previewScreens.length} preview screen descriptor(s) present`
            : "No preview screen descriptors found",
        };
      case "approval_gate_present":
        return {
          rule,
          passed:  input.operatorApprovalRef.length > 0,
          message: input.operatorApprovalRef.length > 0
            ? "Operator approval reference is present"
            : "Operator approval reference is missing",
        };
      case "output_remains_virtual":
        return { rule, passed: true, message: "All outputs carry virtual=true — no real artifact produced" };
    }
  });
}

function buildBlockingReport(): readonly ExperimentalBlockingCheck[] {
  return CANONICAL_STAGE_SEQUENCE.map((stage): ExperimentalBlockingCheck => ({
    stage,
    blocked: true,
    reason:  "executionBlocked=true — descriptor-only phase; no real execution permitted at any stage",
  }));
}

const flowStore = new Map<string, ExperimentalProductionFlowRecord>();

export function createExperimentalProductionFlowRecord(
  input: CreateExperimentalProductionFlowInput,
): { ok: true; record: ExperimentalProductionFlowRecord } {
  const flowId        = randomBytes(8).toString("hex");
  const createdAt     = new Date().toISOString();
  const linkedRecordIds = buildLinkedRecordIds(input);
  const readinessReport = buildReadinessReport(input);
  const blockingReport  = buildBlockingReport();
  const allPassed       = readinessReport.every((c) => c.passed);

  const flowSummary: ExperimentalFlowSummaryInline = {
    totalStages:              CANONICAL_STAGE_SEQUENCE.length,
    totalReadinessChecks:     readinessReport.length,
    totalBlockingChecks:      blockingReport.length,
    allReadinessChecksPassed: allPassed,
    allStagesBlocked:         true,
    executionBlocked:         true,
    filesystemBlocked:        true,
    deploymentBlocked:        true,
    implementationPhase:      "blueprint_descriptor",
  };

  const record: ExperimentalProductionFlowRecord = {
    flowId,
    createdAt,
    flowState:         "descriptor_ready",
    approvalRequired:  true,
    executionBlocked:  true,
    filesystemBlocked: true,
    deploymentBlocked: true,
    linkedRecordIds,
    stageSequence:     CANONICAL_STAGE_SEQUENCE,
    readinessReport,
    blockingReport,
    flowSummary,
  };

  flowStore.set(flowId, record);
  return { ok: true, record };
}

export function listExperimentalProductionFlowRecords(): ExperimentalProductionFlowRecord[] {
  return Array.from(flowStore.values()).sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getExperimentalProductionFlowSummary(): ExperimentalProductionFlowSummary {
  const records = listExperimentalProductionFlowRecords();
  return {
    totalFlows:          records.length,
    byFlowState:         { descriptor_ready: records.length },
    executionBlocked:    true,
    filesystemBlocked:   true,
    deploymentBlocked:   true,
    implementationPhase: "blueprint_descriptor",
  };
}
