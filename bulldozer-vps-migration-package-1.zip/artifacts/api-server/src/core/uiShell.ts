import { getUIThemeManifest }     from "./workspaceUITheme";
import { getUILayoutManifest }    from "./workspaceUILayout";
import { getUINavigationManifest } from "./workspaceUINavigation";
import { getUIPageManifest }      from "./workspaceUIPages";
import { getUIPanelManifest }     from "./workspaceUIPanels";
import { getUIWidgetManifest }    from "./workspaceUIWidgets";
import { getUIBadgeManifest }     from "./workspaceUIBadges";
import { getUILayerAudit }        from "./workspaceUILayerAudit";

function esc(s: string): string {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Phase 175 — Light theme palette (sealed Phase 174)
const ACCENT = "#6366f1"; // indigo — UI Shell / Overview

const PAGE_ACCENTS: Record<string, string> = {
  overview:    "#6366f1", // indigo
  governance:  "#3b82f6", // blue
  observation: "#d946ef", // pink/magenta
  diagnostics: "#f97316", // orange
  comparison:  "#14b8a6", // teal
};

const PAGE_ROUTES: Record<string, string> = {
  overview:    "/ui/overview",
  governance:  "/ui/governance",
  observation: "/ui/observation",
  diagnostics: "/ui/diagnostics",
  comparison:  "/ui/comparison",
};

function buildCss(accent: string): string {
  return `
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden}
body{background:#f8f9fa;color:#212529;font-family:ui-monospace,SFMono-Regular,'Cascadia Code','Fira Code',monospace;font-size:13px;line-height:1.5;display:flex;flex-direction:column}
.op-root{display:flex;flex-direction:column;flex:1;overflow:hidden}
.op-topbar{display:flex;align-items:center;gap:10px;padding:0 16px;height:48px;background:#ffffff;border-bottom:1px solid #dee2e6;flex-shrink:0;z-index:10}
.op-brand{display:flex;align-items:center;gap:9px;flex-shrink:0}
.op-mark{font-size:17px;color:${accent};line-height:1}
.op-name{font-size:13px;font-weight:900;letter-spacing:3px;color:#212529}
.op-sub{font-size:9px;color:#6c757d;letter-spacing:1.5px;text-transform:uppercase}
.op-vdiv{width:1px;height:22px;background:#dee2e6;flex-shrink:0}
.op-search{flex:1;display:flex;align-items:center;gap:8px;padding:5px 12px;background:#f8f9fa;border:1px solid #dee2e6;border-radius:4px;max-width:440px;min-width:0}
.op-search-ic{color:#6c757d;font-size:14px;flex-shrink:0;line-height:1}
.op-search-txt{font-size:10px;color:#6c757d;letter-spacing:0.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}
.op-topbar-right{display:flex;align-items:center;gap:7px;margin-left:auto;flex-shrink:0}
.badge{padding:3px 9px;border-radius:3px;font-size:9px;font-weight:700;letter-spacing:1px;white-space:nowrap}
.ro{background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0}
.eb{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
.op-body{display:flex;flex:1;overflow:hidden}
.op-sidebar{width:208px;flex-shrink:0;background:#f1f3f5;border-right:1px solid #dee2e6;display:flex;flex-direction:column;overflow-y:auto;scrollbar-width:thin;scrollbar-color:#ced4da #f1f3f5}
.sb-sec{padding:14px 12px 10px}
.sb-lbl{font-size:8px;font-weight:700;letter-spacing:2px;color:#6c757d;text-transform:uppercase;margin-bottom:6px;padding-left:2px}
.sb-link{display:flex;align-items:center;gap:7px;text-decoration:none;font-size:11px;font-weight:600;letter-spacing:0.5px;color:#495057;padding:6px 8px;border-radius:4px;margin-bottom:1px;border:1px solid transparent;overflow:hidden}
.sb-link.on{color:${accent};background:${accent}14;border-color:${accent}30}
.sb-dot{width:5px;height:5px;border-radius:50%;background:currentColor;flex-shrink:0;opacity:0.85}
.sb-dot.gov{background:#3b82f6}
.sb-dot.obs{background:#d946ef}
.sb-dot.diag{background:#f97316}
.sb-dot.cmp{background:#14b8a6}
.sb-sep{height:1px;background:#dee2e6;margin:4px 12px 6px}
.sb-stat{display:flex;justify-content:space-between;align-items:baseline;padding:3px 12px;font-size:10px}
.sb-stat-k{color:#6c757d}
.sb-stat-v{color:${accent};font-weight:700}
.sb-status{margin:4px 12px 12px;padding:8px 10px;background:#ffffff;border:1px solid #dee2e6;border-radius:4px}
.sb-status-row{display:flex;justify-content:space-between;align-items:center;font-size:10px;padding:2px 0}
.sb-ok{color:#16a34a;font-weight:700}
.sb-blk{color:#dc2626;font-weight:700}
.op-main{flex:1;overflow-y:auto;padding:24px 28px;min-width:0;scrollbar-width:thin;scrollbar-color:#ced4da #f8f9fa}
.op-title-area{margin-bottom:20px;padding-bottom:14px;border-bottom:1px solid #dee2e6}
.op-page-tag{font-size:9px;font-weight:700;letter-spacing:2px;color:${accent};text-transform:uppercase;margin-bottom:6px;display:flex;align-items:center;gap:6px}
.op-page-tag::before{content:'';display:inline-block;width:5px;height:5px;background:${accent};border-radius:50%}
.op-title{font-size:20px;font-weight:900;letter-spacing:2px;color:#212529;line-height:1.1;margin-bottom:5px}
.op-subtitle{font-size:10px;color:#6c757d;letter-spacing:1px}
.op-section{margin-bottom:26px}
.op-sh{display:flex;align-items:baseline;gap:9px;font-size:9px;font-weight:700;letter-spacing:2px;color:#6c757d;text-transform:uppercase;padding:14px 0 8px;border-bottom:1px solid #dee2e6;margin-bottom:12px}
.op-sh .op-ct{color:#adb5bd;font-weight:400;letter-spacing:0;font-size:9px;text-transform:none}
.m-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(118px,1fr));gap:10px}
.mc{background:#ffffff;border:1px solid #dee2e6;border-top:2px solid ${accent};border-radius:5px;padding:14px 15px}
.mc-n{font-size:28px;font-weight:800;color:${accent};line-height:1;margin-bottom:6px}
.mc-n.sm{font-size:13px;color:#495057;font-weight:600}
.mc-l{font-size:8px;color:#6c757d;text-transform:uppercase;letter-spacing:1.5px}
.kv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(152px,1fr));gap:8px}
.kv{background:#ffffff;border:1px solid #dee2e6;border-radius:4px;padding:10px 13px}
.kv-k{font-size:8px;color:#6c757d;text-transform:uppercase;letter-spacing:1.2px;margin-bottom:4px}
.kv-v{font-size:12px;color:${accent};font-weight:600}
.pg-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(178px,1fr));gap:8px}
.pgc{display:block;text-decoration:none;background:#ffffff;border:1px solid #dee2e6;border-radius:5px;overflow:hidden;color:inherit}
.pgc-bar{height:3px}
.pgc-body{padding:12px 14px}
.pgc-id{font-size:8px;color:#6c757d;letter-spacing:1px;margin-bottom:3px}
.pgc-title{font-size:12px;font-weight:700;color:#212529;margin-bottom:6px}
.pgc-meta{font-size:9px;color:#6c757d;line-height:1.6}
.nav-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:8px}
.nc{background:#ffffff;border:1px solid #dee2e6;border-radius:4px;padding:10px 12px}
.nc-hd{font-size:10px;font-weight:700;color:#212529;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center}
.nc-ct{font-size:9px;color:#6c757d}
.ni{font-size:10px;color:#495057;padding:3px 0;border-bottom:1px solid #dee2e6}
.ni:last-child{border-bottom:none}
.ni-r{font-size:9px;color:#6c757d;margin-top:1px}
.table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
table{width:100%;border-collapse:collapse;min-width:360px}
thead tr{background:#f1f3f5}
th{text-align:left;font-size:8px;color:#6c757d;text-transform:uppercase;letter-spacing:1.2px;padding:7px 11px;border-bottom:1px solid #dee2e6}
td{padding:7px 11px;border-bottom:1px solid #e9ecef;font-size:11px;color:#495057;vertical-align:middle}
tbody tr:last-child td{border-bottom:none}
.td-id{color:#6c757d;font-size:10px}
.td-r{color:#6c757d;font-size:11px}
.ok{color:#16a34a;font-weight:700}
.fail{color:#dc2626;font-weight:700}
.audit-bar{display:flex;align-items:center;gap:12px;padding:8px 13px;background:#ffffff;border:1px solid #dee2e6;border-radius:4px;margin-bottom:10px;flex-wrap:wrap}
.a-lbl{font-size:9px;color:#6c757d}
.eb-chip{padding:2px 9px;background:#fef2f2;color:#dc2626;border:1px solid #fecaca;border-radius:3px;font-size:9px;font-weight:700}
.op-footer{margin-top:22px;padding:10px 0;border-top:1px solid #dee2e6;color:#6c757d;font-size:9px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;letter-spacing:0.5px}
@media(max-width:820px){
  html,body{overflow:auto;height:auto}
  .op-root{overflow:visible}
  .op-body{flex-direction:column;overflow:visible}
  .op-sidebar{width:100%;height:auto;overflow:visible;border-right:none;border-bottom:1px solid #dee2e6;flex-direction:row;flex-wrap:wrap;padding:6px 4px}
  .op-main{overflow:visible;padding:14px 12px}
  .op-section{margin-bottom:18px}
  .sb-sec{flex:1;min-width:130px;padding:6px 8px 4px}
  .sb-sep{display:none}
  .m-grid{grid-template-columns:repeat(3,1fr)}
  .pg-grid,.nav-grid,.kv-grid{grid-template-columns:repeat(2,1fr)}
  .op-topbar{flex-wrap:wrap;height:auto;padding:8px 12px;gap:8px}
  .op-vdiv{display:none}
  .op-search{max-width:100%}
  .op-topbar-right{margin-left:0}
  .op-title-area{margin-bottom:14px;padding-bottom:10px}
  .op-sh{padding:10px 0 6px}
}
@media(max-width:480px){
  .m-grid{grid-template-columns:repeat(2,1fr)}
  .pg-grid,.nav-grid,.kv-grid{grid-template-columns:1fr}
}`.trim();
}

export function buildUIShellHtml(): string {
  const theme    = getUIThemeManifest().themeTokens;
  const layout   = getUILayoutManifest().layout;
  const nav      = getUINavigationManifest();
  const pages    = getUIPageManifest();
  const panels   = getUIPanelManifest();
  const widgets  = getUIWidgetManifest();
  const badges   = getUIBadgeManifest();
  const audit    = getUILayerAudit();
  const generatedAt = new Date().toISOString();

  const navGroupsHtml = nav.groups.map((g) => `
    <div class="nc">
      <div class="nc-hd">${esc(g.title)}<span class="nc-ct">${g.itemCount}</span></div>
      ${g.items.map((item) => `<div class="ni">${esc(item.title)}<div class="ni-r">${esc(item.endpoint)}</div></div>`).join("")}
    </div>`).join("");

  const pagesHtml = pages.pages.map((p) => {
    const accent = PAGE_ACCENTS[p.pageId] ?? ACCENT;
    const route  = PAGE_ROUTES[p.pageId];
    const inner = `
      <div class="pgc-bar" style="background:${accent}"></div>
      <div class="pgc-body">
        <div class="pgc-id">${esc(p.pageId)}</div>
        <div class="pgc-title">${esc(p.title)}</div>
        <div class="pgc-meta">${p.panelCount} panel${p.panelCount !== 1 ? "s" : ""} &middot; ${esc(p.route)}</div>
      </div>`;
    return route
      ? `<a class="pgc" href="${esc(route)}">${inner}</a>`
      : `<div class="pgc">${inner}</div>`;
  }).join("");

  const badgesHtml = badges.badges.map((b) =>
    `<tr><td class="td-id">${esc(b.badgeId)}</td><td>${esc(b.label)}</td><td>${esc(b.signalType)}</td><td>${esc(b.refreshMode)}</td></tr>`
  ).join("");

  const auditHtml = audit.checks.map((c) =>
    `<tr><td class="td-id">${esc(c.layerId)}</td><td class="${c.healthy ? "ok" : "fail"}">${c.healthy ? "&#10003;" : "&#10007;"}</td><td class="${c.totalInvariantValid ? "ok" : "fail"}">${c.totalInvariantValid ? "&#10003;" : "&#10007;"}</td><td class="ok">true</td></tr>`
  ).join("");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(layout.appName)} &mdash; UI Shell</title>
<style>${buildCss(ACCENT)}
</style>
</head>
<body>
<div class="op-root">

<header class="op-topbar">
  <div class="op-brand">
    <span class="op-mark">&#9672;</span>
    <div>
      <div class="op-name">${esc(layout.appName)}</div>
      <div class="op-sub">Mother Core</div>
    </div>
  </div>
  <div class="op-vdiv"></div>
  <div class="op-search">
    <span class="op-search-ic">&#128269;</span>
    <span class="op-search-txt">Read-only control surface &middot; no execution &middot; no mutation</span>
  </div>
  <div class="op-topbar-right">
    <span class="badge ro">READ ONLY</span>
    <span class="badge eb">EXECUTION BLOCKED</span>
  </div>
</header>

<div class="op-body">

<aside class="op-sidebar">
  <div class="sb-sec">
    <div class="sb-lbl">Pages</div>
    <a class="sb-link on" href="/ui"><span class="sb-dot"></span>UI Shell</a>
    <a class="sb-link" href="/ui/overview"><span class="sb-dot"></span>Overview</a>
    <a class="sb-link" href="/ui/governance"><span class="sb-dot gov"></span>Governance</a>
    <a class="sb-link" href="/ui/observation"><span class="sb-dot obs"></span>Observation</a>
    <a class="sb-link" href="/ui/diagnostics"><span class="sb-dot diag"></span>Diagnostics</a>
    <a class="sb-link" href="/ui/comparison"><span class="sb-dot cmp"></span>Comparison</a>
  </div>
  <div class="sb-sep"></div>
  <div class="sb-sec">
    <div class="sb-lbl">Runtime</div>
    <div class="sb-status">
      <div class="sb-status-row"><span>Read Only</span><span class="sb-ok">true</span></div>
      <div class="sb-status-row"><span>Exec Blocked</span><span class="sb-blk">true</span></div>
      <div class="sb-status-row"><span>No Mutation</span><span class="sb-ok">true</span></div>
      <div class="sb-status-row"><span>No Client JS</span><span class="sb-ok">true</span></div>
    </div>
    <div class="sb-stat"><span class="sb-stat-k">Shell</span><span class="sb-stat-v">${esc(layout.shellType)}</span></div>
    <div class="sb-stat"><span class="sb-stat-k">Mode</span><span class="sb-stat-v">${esc(theme.colorMode)}</span></div>
    <div class="sb-stat"><span class="sb-stat-k">Density</span><span class="sb-stat-v">${esc(theme.density)}</span></div>
    <div class="sb-stat"><span class="sb-stat-k">Audit</span><span class="sb-stat-v ${audit.allHealthy ? "sb-ok" : "sb-blk"}">${audit.allHealthy ? "&#10003;" : "&#10007;"}</span></div>
  </div>
</aside>

<main class="op-main">

  <div class="op-title-area">
    <div class="op-page-tag">UI Shell</div>
    <div class="op-title">Operator Dashboard</div>
    <div class="op-subtitle">Mother Core &middot; Read-only control surface &middot; ${esc(layout.shellType)} shell</div>
  </div>

  <div class="op-section">
    <div class="op-sh">System counters <span class="op-ct">${pages.totalPages} pages &middot; ${panels.totalPanels} panels &middot; ${widgets.totalWidgets} widgets</span></div>
    <div class="m-grid">
      <div class="mc"><div class="mc-n">${pages.totalPages}</div><div class="mc-l">Pages</div></div>
      <div class="mc"><div class="mc-n">${panels.totalPanels}</div><div class="mc-l">Panels</div></div>
      <div class="mc"><div class="mc-n">${widgets.totalWidgets}</div><div class="mc-l">Widgets</div></div>
      <div class="mc"><div class="mc-n">${badges.totalBadges}</div><div class="mc-l">Badges</div></div>
      <div class="mc"><div class="mc-n sm">${esc(theme.colorMode)}</div><div class="mc-l">Theme Mode</div></div>
      <div class="mc"><div class="mc-n sm">${esc(layout.shellType)}</div><div class="mc-l">Shell Type</div></div>
    </div>
  </div>

  <div class="op-section">
    <div class="op-sh">Shell configuration <span class="op-ct">${esc(layout.contentGrid)} grid</span></div>
    <div class="kv-grid">
      <div class="kv"><div class="kv-k">Content Grid</div><div class="kv-v">${esc(layout.contentGrid)}</div></div>
      <div class="kv"><div class="kv-k">Sidebar</div><div class="kv-v">${layout.sidebarEnabled ? "enabled" : "disabled"}</div></div>
      <div class="kv"><div class="kv-k">Topbar</div><div class="kv-v">${layout.topbarEnabled ? "enabled" : "disabled"}</div></div>
      <div class="kv"><div class="kv-k">Card Radius</div><div class="kv-v">${esc(theme.cardRadius)}</div></div>
      <div class="kv"><div class="kv-k">Grid Gap</div><div class="kv-v">${esc(theme.gridGap)}</div></div>
      <div class="kv"><div class="kv-k">Typography Scale</div><div class="kv-v">${esc(theme.typographyScale)}</div></div>
    </div>
  </div>

  <div class="op-section">
    <div class="op-sh">Pages &mdash; ${pages.totalPages} total <span class="op-ct">click to navigate</span></div>
    <div class="pg-grid">${pagesHtml}</div>
  </div>

  <div class="op-section">
    <div class="op-sh">Navigation &mdash; ${nav.totalGroups} groups <span class="op-ct">default: ${esc(nav.defaultPage)}</span></div>
    <div class="nav-grid">${navGroupsHtml}</div>
  </div>

  <div class="op-section">
    <div class="op-sh">Governance badges <span class="op-ct">${badges.totalBadges} total</span></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Badge ID</th><th>Label</th><th>Signal Type</th><th>Refresh Mode</th></tr></thead>
      <tbody>${badgesHtml}</tbody>
    </table></div>
  </div>

  <div class="op-section">
    <div class="op-sh">UI layer audit <span class="op-ct">v${esc(audit.auditVersion)} &middot; ${audit.layersChecked} layers</span></div>
    <div class="audit-bar">
      <span class="a-lbl">All Healthy:</span>
      <span class="${audit.allHealthy ? "ok" : "fail"}">${audit.allHealthy ? "&#10003; true" : "&#10007; false"}</span>
      <span class="a-lbl">executionBlocked:</span>
      <span class="eb-chip">true</span>
    </div>
    <div class="table-wrap"><table>
      <thead><tr><th>Layer</th><th>Healthy</th><th>Invariant Valid</th><th>Execution Blocked</th></tr></thead>
      <tbody>${auditHtml}</tbody>
    </table></div>
  </div>

  <footer class="op-footer">
    <span>generatedAt: ${esc(generatedAt)}</span>
    <span>executionBlocked: true &middot; readOnly: true &middot; noMutation: true &middot; noClientJS: true</span>
  </footer>

</main>
</div>
</div>
</body>
</html>`;
}
