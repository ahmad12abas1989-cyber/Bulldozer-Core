// firstGuardedWriteEnableCore.ts
// Phase 300 — First Guarded Write Enable Core Skeleton
// In-memory first guarded write enable descriptor engine.
// Layer 19 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open stack.
// Prepares the final safe enablement path before actual sandbox mutation.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// guardedWriteEnabled=false — the guarded write gate has not been opened.
// guardedWriteEnablePrepared=true — descriptor-readiness established for a future sandbox mutation phase.

import type { FirstBridgeOpenRecord }                  from "./firstBridgeOpenCore.js";
import type { ControlledWriteActivationBridgeRecord }  from "./controlledWriteActivationBridgeCore.js";
import type { FirstExecutionTransitionRecord }          from "./firstExecutionTransitionCore.js";
import type { FirstActivationSwitchRecord }             from "./firstActivationSwitchCore.js";
import type { FirstRealSandboxWriteActivationRecord }   from "./firstRealSandboxWriteActivationCore.js";
import type { ControlledExecutionRecord }               from "./controlledExecutionCore.js";
import { randomUUID }                                   from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type GuardedWriteEnableState = "descriptor_guarded_write_enable_pending";

export type GuardedEnableCheckRule =
  | "bridge_open_record_exists"
  | "bridge_record_exists"
  | "execution_transition_exists"
  | "activation_switch_exists"
  | "activation_record_exists"
  | "execution_record_exists"
  | "bridge_open_bound_to_bridge"
  | "bridge_bound_to_transition"
  | "transition_bound_to_switch"
  | "switch_bound_to_activation"
  | "guarded_write_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface GuardedEnableCheck {
  readonly rule: GuardedEnableCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface GuardedEnableBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedGuardedEnableReference {
  readonly bridgeOpenId:               string;
  readonly writeActivationBridgeId:    string;
  readonly executionTransitionId:      string;
  readonly activationSwitchId:         string;
  readonly rollbackSnapshotId:         string;
  readonly guardedWriteEnablePrepared: true;
  readonly guardedWriteEnabled:        false;
  readonly bridgeOpenEnabled:          false;
  readonly bridgeEnabled:              false;
  readonly rollbackChainValid:         boolean;
  readonly referenceNote:              string;
}

export interface GuardedEnableReadinessReport {
  readonly guardedWriteEnablePrepared:  true;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly summary:                     string;
}

export interface FirstGuardedWriteEnableRecord {
  readonly guardedWriteEnableId:        string;
  readonly enableState:                 GuardedWriteEnableState;
  readonly approvalRequired:            true;
  readonly guardedWriteEnablePrepared:  true;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly implementationPhase:         "descriptor_only";
  readonly bridgeOpenId:                string;
  readonly writeActivationBridgeId:     string;
  readonly executionTransitionId:       string;
  readonly activationSwitchId:          string;
  readonly activationId:                string;
  readonly controlledExecutionId:       string;
  readonly guardedEnableChecks:         readonly GuardedEnableCheck[];
  readonly guardedEnableBlockedReasons: readonly GuardedEnableBlockedReason[];
  readonly guardedEnableReadinessReport: GuardedEnableReadinessReport;
  readonly linkedGuardedEnableReference: LinkedGuardedEnableReference;
  readonly createdAt:                   string;
}

export interface CreateGuardedWriteEnableInput {
  readonly bridgeOpenRecord:   FirstBridgeOpenRecord;
  readonly bridgeRecord:       ControlledWriteActivationBridgeRecord;
  readonly transitionRecord:   FirstExecutionTransitionRecord;
  readonly switchRecord:       FirstActivationSwitchRecord;
  readonly activationRecord:   FirstRealSandboxWriteActivationRecord;
  readonly executionRecord:    ControlledExecutionRecord;
}

export interface FirstGuardedWriteEnableSummary {
  readonly total:                       number;
  readonly byState:                     Record<GuardedWriteEnableState, number>;
  readonly guardedWriteEnablePrepared:  true;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly enableState:                 GuardedWriteEnableState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstGuardedWriteEnableRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateGuardedWriteEnableInput): readonly GuardedEnableCheck[] {
  const { bridgeOpenRecord, bridgeRecord, transitionRecord, switchRecord, activationRecord, executionRecord } = input;

  const bridgeOpenExists  = bridgeOpenRecord.bridgeOpenId.length > 0;
  const bridgeExists      = bridgeRecord.writeActivationBridgeId.length > 0;
  const transitionExists  = transitionRecord.executionTransitionId.length > 0;
  const switchExists      = switchRecord.activationSwitchId.length > 0;
  const activationExists  = activationRecord.activationId.length > 0;
  const executionExists   = executionRecord.controlledExecutionId.length > 0;

  const bridgeOpenBound   = bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId;
  const bridgeBound       = bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId;
  const transitionBound   = transitionRecord.activationSwitchId === switchRecord.activationSwitchId;
  const switchBound       = switchRecord.activationId === activationRecord.activationId;

  return [
    {
      rule: "bridge_open_record_exists",
      pass: bridgeOpenExists,
      note: bridgeOpenExists
        ? `bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`
        : "bridgeOpenRecord.bridgeOpenId is empty",
    },
    {
      rule: "bridge_record_exists",
      pass: bridgeExists,
      note: bridgeExists
        ? `writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`
        : "bridgeRecord.writeActivationBridgeId is empty",
    },
    {
      rule: "execution_transition_exists",
      pass: transitionExists,
      note: transitionExists
        ? `executionTransitionId=${transitionRecord.executionTransitionId}`
        : "transitionRecord.executionTransitionId is empty",
    },
    {
      rule: "activation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `activationSwitchId=${switchRecord.activationSwitchId}`
        : "switchRecord.activationSwitchId is empty",
    },
    {
      rule: "activation_record_exists",
      pass: activationExists,
      note: activationExists
        ? `activationId=${activationRecord.activationId}`
        : "activationRecord.activationId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "bridge_open_bound_to_bridge",
      pass: bridgeOpenBound,
      note: bridgeOpenBound
        ? `bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId (${bridgeRecord.writeActivationBridgeId})`
        : `bridge-open/bridge mismatch: bridgeOpen.writeActivationBridgeId=${bridgeOpenRecord.writeActivationBridgeId} vs bridge.writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`,
    },
    {
      rule: "bridge_bound_to_transition",
      pass: bridgeBound,
      note: bridgeBound
        ? `bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId (${transitionRecord.executionTransitionId})`
        : `bridge-transition mismatch: bridge.executionTransitionId=${bridgeRecord.executionTransitionId} vs transition.executionTransitionId=${transitionRecord.executionTransitionId}`,
    },
    {
      rule: "transition_bound_to_switch",
      pass: transitionBound,
      note: transitionBound
        ? `transitionRecord.activationSwitchId === switchRecord.activationSwitchId (${switchRecord.activationSwitchId})`
        : `transition-switch mismatch: transition.activationSwitchId=${transitionRecord.activationSwitchId} vs switch.activationSwitchId=${switchRecord.activationSwitchId}`,
    },
    {
      rule: "switch_bound_to_activation",
      pass: switchBound,
      note: switchBound
        ? `switchRecord.activationId === activationRecord.activationId (${activationRecord.activationId})`
        : `switch-activation mismatch: switch.activationId=${switchRecord.activationId} vs activation.activationId=${activationRecord.activationId}`,
    },
    {
      rule: "guarded_write_still_disabled",
      pass: true,
      note: "guardedWriteEnabled=false — compile-time literal; no guarded write execution phase has opened the enable gate",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "enableState=descriptor_guarded_write_enable_pending — output is a descriptor only; guarded write gate is not yet live",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly GuardedEnableCheck[]): readonly GuardedEnableBlockedReason[] {
  const staticReasons: GuardedEnableBlockedReason[] = [
    { code: "guarded_write_disabled",  reason: "guardedWriteEnabled=false — compile-time literal; an explicit guarded write execution phase must set this to true",                                       static: true },
    { code: "approval_required",       reason: "approvalRequired=true — explicit operator approval is required before the guarded write enable gate can be opened",                                        static: true },
    { code: "actual_writes_disabled",  reason: "actualWritesEnabled=false — compile-time literal across all 19 sealed write-preparation, activation, switch, transition, bridge, and bridge-open layers", static: true },
  ];
  const dynamicReasons: GuardedEnableBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedGuardedEnableReference(
  input: CreateGuardedWriteEnableInput,
  rollbackChainValid: boolean,
): LinkedGuardedEnableReference {
  const { bridgeOpenRecord, bridgeRecord, transitionRecord, switchRecord } = input;
  return {
    bridgeOpenId:               bridgeOpenRecord.bridgeOpenId,
    writeActivationBridgeId:    bridgeRecord.writeActivationBridgeId,
    executionTransitionId:      transitionRecord.executionTransitionId,
    activationSwitchId:         switchRecord.activationSwitchId,
    rollbackSnapshotId:         bridgeOpenRecord.linkedBridgeOpenReference.rollbackSnapshotId,
    guardedWriteEnablePrepared: true,
    guardedWriteEnabled:        false,
    bridgeOpenEnabled:          false,
    bridgeEnabled:              false,
    rollbackChainValid,
    referenceNote:              "linked guarded enable reference sources rollbackSnapshotId from bridgeOpenRecord.linkedBridgeOpenReference; guarded write disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createGuardedWriteEnableRecord(
  input: CreateGuardedWriteEnableInput,
): FirstGuardedWriteEnableRecord {
  const { bridgeOpenRecord, bridgeRecord, transitionRecord, switchRecord, activationRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = bridgeOpenRecord.bridgeOpenReadinessReport.rollbackChainValid;

  const allChecksPass    = checks.every((c) => c.pass);
  const blockedReasons   = buildBlockedReasons(checks);
  const linkedRef        = buildLinkedGuardedEnableReference(input, rollbackChainValid);

  const guardedEnableReadinessReport: GuardedEnableReadinessReport = {
    guardedWriteEnablePrepared:  true,
    guardedWriteEnabled:         false,
    bridgeOpenEnabled:           false,
    bridgeEnabled:               false,
    executionTransitionEnabled:  false,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    approvalRequired:            true,
    allChecksPass,
    blockedReasonCount:          blockedReasons.length,
    rollbackChainValid,
    summary: `enableState=descriptor_guarded_write_enable_pending; guardedWriteEnabled=false; bridgeOpenEnabled=false; bridgeEnabled=false; actualWritesEnabled=false; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstGuardedWriteEnableRecord = {
    guardedWriteEnableId:         randomUUID(),
    enableState:                  "descriptor_guarded_write_enable_pending",
    approvalRequired:             true,
    guardedWriteEnablePrepared:   true,
    guardedWriteEnabled:          false,
    bridgeOpenEnabled:            false,
    bridgeEnabled:                false,
    executionTransitionEnabled:   false,
    activationSwitchEnabled:      false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    filesystemMutationBlocked:    true,
    motherCoreMutationBlocked:    true,
    vaultMutationBlocked:         true,
    shellBlocked:                 true,
    networkBlocked:               true,
    implementationPhase:          "descriptor_only",
    bridgeOpenId:                 bridgeOpenRecord.bridgeOpenId,
    writeActivationBridgeId:      bridgeRecord.writeActivationBridgeId,
    executionTransitionId:        transitionRecord.executionTransitionId,
    activationSwitchId:           switchRecord.activationSwitchId,
    activationId:                 activationRecord.activationId,
    controlledExecutionId:        executionRecord.controlledExecutionId,
    guardedEnableChecks:          checks,
    guardedEnableBlockedReasons:  blockedReasons,
    guardedEnableReadinessReport,
    linkedGuardedEnableReference: linkedRef,
    createdAt:                    new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listGuardedWriteEnableRecords(): readonly FirstGuardedWriteEnableRecord[] {
  return _store.slice();
}

export function getGuardedWriteEnableSummary(): FirstGuardedWriteEnableSummary {
  return {
    total:                        _store.length,
    byState:                      { descriptor_guarded_write_enable_pending: _store.length },
    guardedWriteEnablePrepared:   true,
    guardedWriteEnabled:          false,
    bridgeOpenEnabled:            false,
    bridgeEnabled:                false,
    executionTransitionEnabled:   false,
    activationSwitchEnabled:      false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    filesystemMutationBlocked:    true,
    motherCoreMutationBlocked:    true,
    enableState:                  "descriptor_guarded_write_enable_pending",
    implementationPhase:          "descriptor_only",
  };
}
