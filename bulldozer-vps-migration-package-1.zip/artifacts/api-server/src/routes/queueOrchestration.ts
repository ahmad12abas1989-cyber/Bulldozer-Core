import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  getQueueOrchestrationStatus,
  listOrchestrationPlan,
} from "../core/queueOrchestrator";

export function handleQueueOrchestration(_req: IncomingMessage, res: ServerResponse): void {
  const status = getQueueOrchestrationStatus();
  const orchestrationPlan = listOrchestrationPlan();

  sendJson(res, 200, {
    orchestrationMode: status.orchestrationMode,
    executionBlocked: status.executionBlocked,
    status: {
      totalQueued: status.totalQueued,
      readyCount: status.readyCount,
      blockedCount: status.blockedCount,
      approvalRequiredCount: status.approvalRequiredCount,
      warningCount: status.warningCount,
      lastEvaluationAt: status.lastEvaluationAt,
    },
    orchestrationPlan,
    timestamp: new Date().toISOString(),
  });
}
