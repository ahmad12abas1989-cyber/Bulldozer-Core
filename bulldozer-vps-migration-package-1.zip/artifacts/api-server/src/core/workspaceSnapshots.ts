import { randomBytes } from "node:crypto";
import { readStore, writeStore } from "./persistentStore";
import { logger } from "../lib/logger";
import {
  getWorkspaceSummary,
  getWorkspaceNavigation,
  getWorkspaceHealth,
  getPanel,
  type WorkspaceSummary,
  type WorkspaceNavigationResult,
  type WorkspaceHealthSummary,
  type DiagnosticsPanel,
  type ProjectsPanel,
  type QuotasPanel,
  type ActivityPanel,
  type MembershipPanel,
} from "./workspaceShell";

const EXECUTION_BLOCKED: true = true;
const MAX_SNAPSHOTS = 20;
const STORE_KEY = "workspace-snapshots";
const SCHEMA_VERSION = "1" as const;

// --- Interfaces ---

export interface WorkspaceSnapshotPanels {
  diagnostics: DiagnosticsPanel;
  projects: ProjectsPanel;
  quotas: QuotasPanel;
  activity: ActivityPanel;
  membership: MembershipPanel;
}

export interface WorkspaceSnapshot {
  snapshotId: string;
  schemaVersion: "1";
  createdAt: string;
  summary: WorkspaceSummary;
  navigation: WorkspaceNavigationResult;
  panels: WorkspaceSnapshotPanels;
  diagnosticsExcerpt: WorkspaceHealthSummary;
  executionBlocked: true;
}

export interface WorkspaceSnapshotListItem {
  snapshotId: string;
  schemaVersion: string;
  createdAt: string;
  projectCount: number;
  memberCount: number;
  activityCount: number;
  executionBlocked: true;
}

export interface WorkspaceSnapshotListResult {
  checkedAt: string;
  snapshots: WorkspaceSnapshotListItem[];
  count: number;
  maxRetained: number;
  loadedOnBoot: number;
  executionBlocked: true;
}

export interface WorkspaceSnapshotStatus {
  operational: boolean;
  storeKey: string;
  maxRetained: number;
  snapshotCount: number;
  loadedOnBoot: number;
  flushCount: number;
  lastFlushedAt: string | null;
  executionBlocked: true;
}

// --- In-memory state ---

let snapshotRing: WorkspaceSnapshot[] = [];
let loadedOnBoot = 0;
let flushCount = 0;
let lastFlushedAt: string | null = null;
let isInitialized = false;

// --- Internal helpers ---

function persist(): void {
  writeStore<WorkspaceSnapshot[]>(STORE_KEY, snapshotRing);
  flushCount++;
  lastFlushedAt = new Date().toISOString();
}

function isValidStoredSnapshot(obj: unknown): obj is WorkspaceSnapshot {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  const s = obj as Record<string, unknown>;
  return (
    typeof s["snapshotId"] === "string" &&
    s["snapshotId"].length > 0 &&
    typeof s["createdAt"] === "string" &&
    s["createdAt"].length > 0 &&
    typeof s["schemaVersion"] === "string" &&
    s["executionBlocked"] === true &&
    s["summary"] !== null &&
    typeof s["summary"] === "object" &&
    s["panels"] !== null &&
    typeof s["panels"] === "object"
  );
}

function buildPanels(): WorkspaceSnapshotPanels {
  return {
    diagnostics: getPanel("diagnostics") as DiagnosticsPanel,
    projects: getPanel("projects") as ProjectsPanel,
    quotas: getPanel("quotas") as QuotasPanel,
    activity: getPanel("activity") as ActivityPanel,
    membership: getPanel("membership") as MembershipPanel,
  };
}

// --- Public API ---

export function initWorkspaceSnapshots(): void {
  if (isInitialized) return;

  const stored = readStore<unknown[]>(STORE_KEY);
  if (Array.isArray(stored)) {
    const valid = stored.filter(isValidStoredSnapshot);
    snapshotRing = valid.slice(-MAX_SNAPSHOTS);
    loadedOnBoot = snapshotRing.length;
    if (valid.length !== stored.length) {
      logger.warn(
        { total: stored.length, valid: valid.length, key: STORE_KEY },
        "Workspace snapshot load: skipped invalid entries on boot",
      );
    }
  }

  isInitialized = true;
  logger.info(
    { subsystem: "workspace_snapshots", loadedOnBoot, maxRetained: MAX_SNAPSHOTS, storeKey: STORE_KEY },
    "Workspace snapshot store initialized",
  );
}

export function captureWorkspaceSnapshot(): WorkspaceSnapshot {
  const snapshotId = randomBytes(8).toString("hex");
  const createdAt = new Date().toISOString();

  const snapshot: WorkspaceSnapshot = {
    snapshotId,
    schemaVersion: SCHEMA_VERSION,
    createdAt,
    summary: getWorkspaceSummary(),
    navigation: getWorkspaceNavigation(),
    panels: buildPanels(),
    diagnosticsExcerpt: getWorkspaceHealth(),
    executionBlocked: EXECUTION_BLOCKED,
  };

  snapshotRing.push(snapshot);
  while (snapshotRing.length > MAX_SNAPSHOTS) {
    snapshotRing.shift();
  }
  persist();

  logger.info(
    { snapshotId, createdAt, ringSize: snapshotRing.length, executionBlocked: EXECUTION_BLOCKED },
    "Workspace snapshot captured",
  );

  return snapshot;
}

export function listWorkspaceSnapshots(): WorkspaceSnapshotListResult {
  const items: WorkspaceSnapshotListItem[] = snapshotRing
    .slice()
    .reverse()
    .map((s) => ({
      snapshotId: s.snapshotId,
      schemaVersion: s.schemaVersion,
      createdAt: s.createdAt,
      projectCount: s.summary.projects.total,
      memberCount: s.summary.members.totalRecords,
      activityCount: s.summary.activity.totalRecords,
      executionBlocked: EXECUTION_BLOCKED,
    }));

  return {
    checkedAt: new Date().toISOString(),
    snapshots: items,
    count: items.length,
    maxRetained: MAX_SNAPSHOTS,
    loadedOnBoot,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getLatestWorkspaceSnapshot(): WorkspaceSnapshot | null {
  if (snapshotRing.length === 0) return null;
  return snapshotRing[snapshotRing.length - 1] ?? null;
}

export function getWorkspaceSnapshotById(snapshotId: string): WorkspaceSnapshot | null {
  return snapshotRing.find((s) => s.snapshotId === snapshotId) ?? null;
}

export function getWorkspaceSnapshotStatus(): WorkspaceSnapshotStatus {
  return {
    operational: isInitialized,
    storeKey: STORE_KEY,
    maxRetained: MAX_SNAPSHOTS,
    snapshotCount: snapshotRing.length,
    loadedOnBoot,
    flushCount,
    lastFlushedAt,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
