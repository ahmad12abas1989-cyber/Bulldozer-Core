import type { IncomingMessage, ServerResponse } from "node:http";
import {
  createProject,
  getProject,
  listProjects,
  getProjectRegistryStatus,
  transitionProjectStatus,
  addProjectMember,
  listProjectMembers,
  removeProjectMember,
  getProjectActivity,
  getProjectQuota,
  setProjectQuota,
  resetProjectQuota,
} from "../core/projectRegistry";
import { readJsonBody } from "../lib/body";
import { sendJson, sendError } from "../lib/response";

export function handleProjectsGet(_req: IncomingMessage, res: ServerResponse): void {
  const status = getProjectRegistryStatus();
  const projects = listProjects();
  sendJson(res, 200, {
    status,
    projects,
    count: projects.length,
    executionBlocked: true,
    timestamp: new Date().toISOString(),
  });
}

export function handleProjectsPost(req: IncomingMessage, res: ServerResponse): void {
  readJsonBody(req)
    .then((body) => {
      if (!body || typeof body !== "object" || Array.isArray(body)) {
        sendError(res, 400, "Request body must be a JSON object");
        return;
      }

      const b = body as Record<string, unknown>;

      const result = createProject({
        projectName: b["projectName"],
        owner: b["owner"],
        status: b["status"],
      });

      if (!result.success) {
        const httpStatus =
          result.errorType === "conflict"
            ? 409
            : result.errorType === "capacity"
              ? 507
              : 400;
        sendError(res, httpStatus, result.error ?? "Project creation failed");
        return;
      }

      sendJson(res, 201, {
        project: result.project,
        executionBlocked: true,
        note: "Project registered. Execution is blocked — no workers exist.",
      });
    })
    .catch((err: Error) => {
      sendError(res, 400, err.message ?? "Bad Request");
    });
}

export function handleProjectPatch(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const projectId = decodeURIComponent(segments[segments.length - 1] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }

  readJsonBody(req)
    .then((body) => {
      if (!body || typeof body !== "object" || Array.isArray(body)) {
        sendError(res, 400, "Request body must be a JSON object");
        return;
      }

      const b = body as Record<string, unknown>;
      const result = transitionProjectStatus(projectId, b["status"]);

      if (!result.success) {
        const httpStatus =
          result.errorType === "not_found"
            ? 404
            : result.errorType === "invalid_transition"
              ? 409
              : 400;
        sendError(res, httpStatus, result.error ?? "Transition failed");
        return;
      }

      sendJson(res, 200, {
        project: result.project,
        previousStatus: result.previousStatus,
        executionBlocked: true,
        timestamp: new Date().toISOString(),
      });
    })
    .catch((err: Error) => {
      sendError(res, 400, err.message ?? "Bad Request");
    });
}

export function handleProjectMembersGet(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // ["", "api", "projects", "<projectId>", "members"]
  const projectId = decodeURIComponent(segments[3] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }

  const result = listProjectMembers(projectId);
  if (!result.success) {
    sendError(res, 404, result.error ?? "Project not found");
    return;
  }

  sendJson(res, 200, {
    projectId: result.projectId,
    members: result.members,
    count: result.count,
    executionBlocked: true,
    timestamp: new Date().toISOString(),
  });
}

export function handleProjectMembersPost(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const projectId = decodeURIComponent(segments[3] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }

  readJsonBody(req)
    .then((body) => {
      if (!body || typeof body !== "object" || Array.isArray(body)) {
        sendError(res, 400, "Request body must be a JSON object");
        return;
      }

      const b = body as Record<string, unknown>;
      const result = addProjectMember(projectId, b["actorId"], b["role"]);

      if (!result.success) {
        const httpStatus =
          result.errorType === "not_found"
            ? 404
            : result.errorType === "conflict" || result.errorType === "capacity"
              ? 409
              : 400;
        sendError(res, httpStatus, result.error ?? "Failed to add member");
        return;
      }

      sendJson(res, 201, {
        member: result.member,
        executionBlocked: true,
        note: "Member added. Execution is blocked — no workers exist.",
      });
    })
    .catch((err: Error) => {
      sendError(res, 400, err.message ?? "Bad Request");
    });
}

export function handleProjectMemberDelete(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // ["", "api", "projects", "<projectId>", "members", "<actorId>"]
  const projectId = decodeURIComponent(segments[3] ?? "");
  const actorId = decodeURIComponent(segments[5] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }
  if (!actorId) {
    sendError(res, 400, "Actor ID is required");
    return;
  }

  const result = removeProjectMember(projectId, actorId);

  if (!result.success) {
    const httpStatus =
      result.errorType === "not_found" || result.errorType === "not_member" ? 404 : 400;
    sendError(res, httpStatus, result.error ?? "Failed to remove member");
    return;
  }

  sendJson(res, 200, {
    removedActorId: result.removedActorId,
    projectId,
    executionBlocked: true,
    timestamp: new Date().toISOString(),
  });
}

export function handleProjectActivityGet(req: IncomingMessage, res: ServerResponse): void {
  const full = req.url ?? "";
  const rawPath = full.split("?")[0];
  const rawQuery = full.includes("?") ? full.split("?")[1] : "";
  const segments = rawPath.split("/");
  // ["", "api", "projects", "<projectId>", "activity"]
  const projectId = decodeURIComponent(segments[3] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }

  const params = new URLSearchParams(rawQuery);

  const typeRaw = params.get("type");
  const typeParam = typeRaw !== null ? decodeURIComponent(typeRaw) : undefined;

  const actorIdRaw = params.get("actorId");
  const actorIdParam = actorIdRaw !== null ? decodeURIComponent(actorIdRaw) : undefined;

  const limitRaw = params.get("limit");
  const limitParsed = limitRaw !== null ? parseInt(limitRaw, 10) : NaN;
  const limitParam =
    !isNaN(limitParsed) && limitParsed > 0 ? Math.min(limitParsed, 100) : 50;

  const result = getProjectActivity(projectId, {
    type: typeParam,
    actorId: actorIdParam,
    limit: limitParam,
  });

  if (!result.success) {
    sendError(res, 404, result.error ?? "Project not found");
    return;
  }

  sendJson(res, 200, {
    projectId: result.projectId,
    activities: result.activities,
    count: result.count,
    total: result.total,
    filtersApplied: result.filtersApplied,
    executionBlocked: true,
    timestamp: new Date().toISOString(),
  });
}

export function handleProjectQuotaGet(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // ["", "api", "projects", "<projectId>", "quotas"]
  const projectId = decodeURIComponent(segments[3] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }

  const result = getProjectQuota(projectId);
  if (!result.success) {
    sendError(res, 404, result.error ?? "Project not found");
    return;
  }

  sendJson(res, 200, {
    projectId: result.projectId,
    quota: result.quota,
    isDefault: result.isDefault,
    executionBlocked: true,
    timestamp: new Date().toISOString(),
  });
}

export function handleProjectQuotaPost(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const projectId = decodeURIComponent(segments[3] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }

  readJsonBody(req)
    .then((body) => {
      const input =
        body && typeof body === "object" && !Array.isArray(body)
          ? (body as Record<string, unknown>)
          : {};

      const result = setProjectQuota(projectId, {
        maxMembers: input["maxMembers"],
        maxActivityEntries: input["maxActivityEntries"],
        maxTags: input["maxTags"],
      });

      if (!result.success) {
        const statusCode =
          result.errorType === "not_found" ? 404
          : result.errorType === "validation" ? 400
          : 500;
        sendError(res, statusCode, result.error ?? "Quota update failed");
        return;
      }

      sendJson(res, 200, {
        projectId: result.projectId,
        quota: result.quota,
        isDefault: result.isDefault,
        executionBlocked: true,
        timestamp: new Date().toISOString(),
      });
    })
    .catch(() => {
      sendError(res, 400, "Invalid JSON body");
    });
}

export function handleProjectQuotaDelete(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const projectId = decodeURIComponent(segments[3] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }

  const result = resetProjectQuota(projectId);
  if (!result.success) {
    sendError(res, 404, result.error ?? "Project not found");
    return;
  }

  sendJson(res, 200, {
    projectId: result.projectId,
    quota: result.quota,
    reset: true,
    executionBlocked: true,
    timestamp: new Date().toISOString(),
  });
}

export function handleProjectById(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const projectId = decodeURIComponent(segments[segments.length - 1] ?? "");

  if (!projectId) {
    sendError(res, 400, "Project ID is required");
    return;
  }

  const project = getProject(projectId);
  if (!project) {
    sendError(res, 404, `Project not found: "${projectId}"`);
    return;
  }

  sendJson(res, 200, {
    project,
    executionBlocked: true,
    timestamp: new Date().toISOString(),
  });
}
