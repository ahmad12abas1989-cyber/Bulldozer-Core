import { logger } from "../lib/logger";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";

export type PolicyDecision = "allow" | "warn" | "block" | "approval_required";

export interface PolicyEvaluationResult {
  decision: PolicyDecision;
  policyId: string;
  reason: string;
}

export interface Policy {
  id: string;
  description: string;
  decision: PolicyDecision;
  matchDescription: string;
}

const EXECUTION_BLOCKED: true = true;

const TYPE_FORMAT = /^[a-zA-Z][a-zA-Z0-9_-]*:[a-zA-Z][a-zA-Z0-9_:.-]*$/;
const MAX_PAYLOAD_BYTES = 10_240;

const BLOCK_SHELL = /\bshell\b|\bexec\b|\bspawn\b|\bcmd\b|\bbash\b|\b\.sh\b|^sh:|^process:|^system:/i;
const BLOCK_FS = /^fs:write|^file:write|^file:delete|^disk:|^dir:delete|^dir:remove|^rm:|^format:|^fs:delete/i;
const BLOCK_NETWORK = /^network:exec|^http:post|^http:put|^http:delete|^http:patch|^fetch:run|^request:send|^socket:open/i;

const SAFE_NAMESPACES = new Set([
  "metadata", "info", "status", "monitor", "log", "audit",
  "report", "queue", "task", "config", "health", "snapshot",
  "timeline", "internal", "watchdog", "recovery",
]);

const WARN_NAMESPACES = new Set(["external", "provision", "cloud", "orchestrate"]);

const POLICIES: Policy[] = [
  {
    id: "block_invalid_type_format",
    description: "Block tasks whose type does not follow the required namespace:action format",
    decision: "block",
    matchDescription: "type does not match /^[a-zA-Z][a-zA-Z0-9_-]*:[a-zA-Z][a-zA-Z0-9_:.-]*$/",
  },
  {
    id: "block_shell_tasks",
    description: "Block shell, exec, spawn, cmd, bash, and process control tasks",
    decision: "block",
    matchDescription: "type contains: shell, exec, spawn, cmd, bash, .sh, or starts with sh:, process:, system:",
  },
  {
    id: "block_filesystem_mutation_tasks",
    description: "Block filesystem write, delete, format, and removal tasks",
    decision: "block",
    matchDescription: "type starts with: fs:write, file:write, file:delete, disk:, dir:delete, dir:remove, rm:, format:, fs:delete",
  },
  {
    id: "block_network_execution_tasks",
    description: "Block network execution, HTTP mutation, and socket-opening tasks",
    decision: "block",
    matchDescription: "type starts with: network:exec, http:post, http:put, http:delete, http:patch, fetch:run, request:send, socket:open",
  },
  {
    id: "block_invalid_payload",
    description: "Block tasks whose payload cannot be serialized to JSON",
    decision: "block",
    matchDescription: "JSON.stringify(payload) throws",
  },
  {
    id: "warn_oversized_payload",
    description: "Flag tasks whose serialized payload exceeds the 10 KB limit",
    decision: "warn",
    matchDescription: "JSON.stringify(payload).length > 10240",
  },
  {
    id: "approval_required_deploy_tasks",
    description: "Require explicit approval for all deployment-related tasks",
    decision: "approval_required",
    matchDescription: "namespace is deploy",
  },
  {
    id: "warn_external_tasks",
    description: "Flag external, provisioning, cloud, and orchestration tasks for review",
    decision: "warn",
    matchDescription: "namespace is one of: external, provision, cloud, orchestrate",
  },
  {
    id: "allow_safe_namespace_tasks",
    description: "Allow tasks whose namespace is in the approved safe namespace list",
    decision: "allow",
    matchDescription: "namespace is one of: metadata, info, status, monitor, log, audit, report, queue, task, config, health, snapshot, timeline, internal, watchdog, recovery",
  },
  {
    id: "warn_unknown_namespace",
    description: "Flag tasks in unrecognized namespaces for review",
    decision: "warn",
    matchDescription: "namespace not in any recognized list",
  },
];

let totalPolicyEvaluations = 0;
let allowedCount = 0;
let warnCount = 0;
let blockedCount = 0;
let approvalRequiredCount = 0;
let lastPolicyDecisionAt: string | null = null;
let lastDecision: PolicyDecision | null = null;

export function evaluateTaskPolicy(task: { type: string; payload: unknown }): PolicyEvaluationResult {
  const { type, payload } = task;

  if (!TYPE_FORMAT.test(type)) {
    return record("block", "block_invalid_type_format", "invalid_type_format: task type must follow the namespace:action format");
  }

  if (BLOCK_SHELL.test(type)) {
    return record("block", "block_shell_tasks", "shell_or_process_task: shell, exec, spawn, and process tasks are not permitted");
  }

  if (BLOCK_FS.test(type)) {
    return record("block", "block_filesystem_mutation_tasks", "filesystem_mutation_task: filesystem write, delete, and format tasks are not permitted");
  }

  if (BLOCK_NETWORK.test(type)) {
    return record("block", "block_network_execution_tasks", "network_execution_task: network execution, HTTP mutation, and socket tasks are not permitted");
  }

  let serializedLength = 0;
  try {
    serializedLength = JSON.stringify(payload ?? {}).length;
  } catch {
    return record("block", "block_invalid_payload", "invalid_payload: payload cannot be serialized to JSON");
  }

  if (serializedLength > MAX_PAYLOAD_BYTES) {
    return record(
      "warn",
      "warn_oversized_payload",
      `oversized_payload: payload is ${serializedLength} bytes, exceeds ${MAX_PAYLOAD_BYTES} byte limit`,
    );
  }

  const namespace = type.split(":")[0].toLowerCase();

  if (namespace === "deploy") {
    return record("approval_required", "approval_required_deploy_tasks", "approval_required: deployment tasks require explicit approval before processing");
  }

  if (WARN_NAMESPACES.has(namespace)) {
    return record("warn", "warn_external_tasks", `${namespace}_task_flagged: ${namespace} tasks require review before processing`);
  }

  if (SAFE_NAMESPACES.has(namespace)) {
    return record("allow", "allow_safe_namespace_tasks", "allowed: task type is in the approved namespace list");
  }

  return record("warn", "warn_unknown_namespace", "unknown_namespace: task namespace is not in any recognized list");
}

function record(decision: PolicyDecision, policyId: string, reason: string): PolicyEvaluationResult {
  totalPolicyEvaluations++;
  lastPolicyDecisionAt = new Date().toISOString();
  lastDecision = decision;

  if (decision === "allow") allowedCount++;
  else if (decision === "warn") warnCount++;
  else if (decision === "block") blockedCount++;
  else if (decision === "approval_required") approvalRequiredCount++;

  emit(`task_policy:${decision}`, "task-policy", { policyId, reason });
  logger.info({ decision, policyId, reason }, "Task policy decision");

  return { decision, policyId, reason };
}

export function getTaskPolicyStatus(): {
  totalPolicyEvaluations: number;
  allowedCount: number;
  warningCount: number;
  blockedCount: number;
  approvalRequiredCount: number;
  lastPolicyDecisionAt: string | null;
  lastDecision: PolicyDecision | null;
  executionBlocked: true;
  timestamp: string;
} {
  return {
    totalPolicyEvaluations,
    allowedCount,
    warningCount: warnCount,
    blockedCount,
    approvalRequiredCount,
    lastPolicyDecisionAt,
    lastDecision,
    executionBlocked: EXECUTION_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function listTaskPolicies(): Policy[] {
  return [...POLICIES];
}

export function peekTaskPolicy(task: { type: string; payload: unknown }): PolicyEvaluationResult {
  const { type, payload } = task;

  if (!TYPE_FORMAT.test(type)) {
    return { decision: "block", policyId: "block_invalid_type_format", reason: "invalid_type_format: task type must follow the namespace:action format" };
  }

  if (BLOCK_SHELL.test(type)) {
    return { decision: "block", policyId: "block_shell_tasks", reason: "shell_or_process_task: shell, exec, spawn, and process tasks are not permitted" };
  }

  if (BLOCK_FS.test(type)) {
    return { decision: "block", policyId: "block_filesystem_mutation_tasks", reason: "filesystem_mutation_task: filesystem write, delete, and format tasks are not permitted" };
  }

  if (BLOCK_NETWORK.test(type)) {
    return { decision: "block", policyId: "block_network_execution_tasks", reason: "network_execution_task: network execution, HTTP mutation, and socket tasks are not permitted" };
  }

  let serializedLength = 0;
  try {
    serializedLength = JSON.stringify(payload ?? {}).length;
  } catch {
    return { decision: "block", policyId: "block_invalid_payload", reason: "invalid_payload: payload cannot be serialized to JSON" };
  }

  if (serializedLength > MAX_PAYLOAD_BYTES) {
    return {
      decision: "warn",
      policyId: "warn_oversized_payload",
      reason: `oversized_payload: payload is ${serializedLength} bytes, exceeds ${MAX_PAYLOAD_BYTES} byte limit`,
    };
  }

  const namespace = type.split(":")[0].toLowerCase();

  if (namespace === "deploy") {
    return { decision: "approval_required", policyId: "approval_required_deploy_tasks", reason: "approval_required: deployment tasks require explicit approval before processing" };
  }

  if (WARN_NAMESPACES.has(namespace)) {
    return { decision: "warn", policyId: "warn_external_tasks", reason: `${namespace}_task_flagged: ${namespace} tasks require review before processing` };
  }

  if (SAFE_NAMESPACES.has(namespace)) {
    return { decision: "allow", policyId: "allow_safe_namespace_tasks", reason: "allowed: task type is in the approved namespace list" };
  }

  return { decision: "warn", policyId: "warn_unknown_namespace", reason: "unknown_namespace: task namespace is not in any recognized list" };
}

export function initTaskPolicy(): void {
  emit("task_policy:initialized", "task-policy", { policyCount: POLICIES.length });
  addTimelineEvent({
    level: "info",
    source: "task-policy",
    message: `Task policy engine initialized — ${POLICIES.length} policies loaded`,
  });
  logger.info({ policyCount: POLICIES.length, executionBlocked: EXECUTION_BLOCKED }, "Task policy engine initialized");
}
