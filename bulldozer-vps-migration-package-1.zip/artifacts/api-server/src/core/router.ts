import type { IncomingMessage, ServerResponse } from "node:http";

export type Handler = (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;

interface Route {
  method: string;
  path: string;
  handler: Handler;
}

class Router {
  private readonly routes: Route[] = [];

  register(method: string, path: string, handler: Handler): void {
    this.routes.push({ method: method.toUpperCase(), path, handler });
  }

  get(path: string, handler: Handler): void {
    this.register("GET", path, handler);
  }

  post(path: string, handler: Handler): void {
    this.register("POST", path, handler);
  }

  patch(path: string, handler: Handler): void {
    this.register("PATCH", path, handler);
  }

  delete(path: string, handler: Handler): void {
    this.register("DELETE", path, handler);
  }

  resolve(method: string, path: string): Handler | null {
    const upper = method.toUpperCase();
    for (const r of this.routes) {
      if (r.method === upper && r.path === path) return r.handler;
    }
    for (const r of this.routes) {
      if (r.method !== upper) continue;
      if (!r.path.includes("/:")) continue;
      const rParts = r.path.split("/");
      const pParts = path.split("/");
      if (rParts.length !== pParts.length) continue;
      const matched = rParts.every((rp, i) => rp.startsWith(":") || rp === pParts[i]);
      if (matched) return r.handler;
    }
    return null;
  }

  list(): Array<{ method: string; path: string }> {
    return this.routes.map(({ method, path }) => ({ method, path }));
  }
}

export const router = new Router();
