import { timingSafeEqual } from "node:crypto";
import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";
import type { ResolvedIdentity } from "./identityAccess";

export interface ApiKeyAuthStatus {
  operational: boolean;
  ownerKeyConfigured: boolean;
  serviceKeyConfigured: boolean;
  totalApiKeyRequests: number;
  totalValidApiKeyRequests: number;
  totalInvalidApiKeyRequests: number;
  lastInvalidAt: string | null;
  timingSafeComparison: true;
  executionBlocked: true;
}

export interface ApiKeyCheckResult {
  valid: boolean;
  identity: ResolvedIdentity | null;
}

const EXECUTION_BLOCKED: true = true;
const TIMING_SAFE_COMPARISON: true = true;
const API_KEY_MIN_LENGTH = 16;
const API_KEY_MAX_LENGTH = 256;

let ownerKey: string | null = null;
let serviceKey: string | null = null;
let ownerKeyConfigured = false;
let serviceKeyConfigured = false;

let isOperational = false;
let totalApiKeyRequests = 0;
let totalValidApiKeyRequests = 0;
let totalInvalidApiKeyRequests = 0;
let lastInvalidAt: string | null = null;

function timingSafeCompare(submitted: string, configured: string): boolean {
  if (submitted.length !== configured.length) return false;
  return timingSafeEqual(Buffer.from(submitted), Buffer.from(configured));
}

export function initApiKeyAuth(): void {
  if (isOperational) return;

  const rawOwnerKey = process.env["BULLDOZER_OWNER_API_KEY"];
  const rawServiceKey = process.env["BULLDOZER_SERVICE_API_KEY"];

  if (
    typeof rawOwnerKey === "string" &&
    rawOwnerKey.length >= API_KEY_MIN_LENGTH &&
    rawOwnerKey.length <= API_KEY_MAX_LENGTH
  ) {
    ownerKey = rawOwnerKey;
    ownerKeyConfigured = true;
  }

  if (
    typeof rawServiceKey === "string" &&
    rawServiceKey.length >= API_KEY_MIN_LENGTH &&
    rawServiceKey.length <= API_KEY_MAX_LENGTH
  ) {
    serviceKey = rawServiceKey;
    serviceKeyConfigured = true;
  }

  isOperational = true;

  addTimelineEvent({
    level: "info",
    source: "api-key-auth",
    message: "API key auth initialized",
    metadata: {
      ownerKeyConfigured,
      serviceKeyConfigured,
      timingSafeComparison: TIMING_SAFE_COMPARISON,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  emit("api_key_auth:initialized", "api-key-auth", {
    ownerKeyConfigured,
    serviceKeyConfigured,
    timingSafeComparison: TIMING_SAFE_COMPARISON,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "api_key_auth.initialized",
    source: "api-key-auth",
    severity: "info",
    category: "runtime",
    payload: {
      ownerKeyConfigured,
      serviceKeyConfigured,
      timingSafeComparison: TIMING_SAFE_COMPARISON,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    {
      ownerKeyConfigured,
      serviceKeyConfigured,
      timingSafeComparison: TIMING_SAFE_COMPARISON,
      executionBlocked: EXECUTION_BLOCKED,
    },
    "API key auth initialized",
  );
}

export function resolveApiKeyIdentity(rawKey: string | undefined): ApiKeyCheckResult {
  if (rawKey === undefined || rawKey.length === 0) {
    return { valid: false, identity: null };
  }

  totalApiKeyRequests++;

  if (ownerKeyConfigured && ownerKey !== null && timingSafeCompare(rawKey, ownerKey)) {
    totalValidApiKeyRequests++;
    return {
      valid: true,
      identity: { actorType: "owner", role: "owner", actorId: "owner", source: "api_key" },
    };
  }

  if (serviceKeyConfigured && serviceKey !== null && timingSafeCompare(rawKey, serviceKey)) {
    totalValidApiKeyRequests++;
    return {
      valid: true,
      identity: { actorType: "service", role: "operator", actorId: "service", source: "api_key" },
    };
  }

  totalInvalidApiKeyRequests++;
  lastInvalidAt = new Date().toISOString();

  logger.warn(
    { executionBlocked: EXECUTION_BLOCKED },
    "Invalid API key attempt — key rejected, falling back to anonymous/guest",
  );

  return { valid: false, identity: null };
}

export function getApiKeyAuthStatus(): ApiKeyAuthStatus {
  return {
    operational: isOperational,
    ownerKeyConfigured,
    serviceKeyConfigured,
    totalApiKeyRequests,
    totalValidApiKeyRequests,
    totalInvalidApiKeyRequests,
    lastInvalidAt,
    timingSafeComparison: TIMING_SAFE_COMPARISON,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
