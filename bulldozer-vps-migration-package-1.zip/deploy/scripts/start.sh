#!/usr/bin/env bash
# deploy/scripts/start.sh
# Start Bulldozer Mother Core via docker compose.
# Reads configuration from deploy/.env (must exist).
# No autonomous execution. No self-healing. No AI.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPLOY_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ENV_FILE="${DEPLOY_DIR}/.env"
COMPOSE_FILE="${DEPLOY_DIR}/docker-compose.yml"

echo "[bulldozer] Starting Bulldozer Mother Core..."

# Require .env
if [[ ! -f "${ENV_FILE}" ]]; then
  echo "[bulldozer] ERROR: ${ENV_FILE} not found."
  echo "[bulldozer]   Copy deploy/.env.example to deploy/.env and fill in all values."
  exit 1
fi

# Require SESSION_SECRET to be set and non-default
SESSION_SECRET_VAL=$(grep -E '^SESSION_SECRET=' "${ENV_FILE}" | cut -d'=' -f2- | tr -d '"' || true)
if [[ -z "${SESSION_SECRET_VAL}" || "${SESSION_SECRET_VAL}" == "REPLACE_WITH_64_CHAR_RANDOM_HEX" ]]; then
  echo "[bulldozer] ERROR: SESSION_SECRET is not set or is still the placeholder value."
  echo "[bulldozer]   Generate one with: openssl rand -hex 64"
  exit 1
fi

# Ensure storage directory exists and is writable
STORAGE_PATH_VAL=$(grep -E '^STORAGE_PATH=' "${ENV_FILE}" | cut -d'=' -f2- | tr -d '"' || echo "/opt/bulldozer/storage")
if [[ ! -d "${STORAGE_PATH_VAL}" ]]; then
  echo "[bulldozer] Creating storage directory: ${STORAGE_PATH_VAL}"
  sudo mkdir -p "${STORAGE_PATH_VAL}"
  sudo chown 1000:1000 "${STORAGE_PATH_VAL}"
fi

docker compose \
  --env-file "${ENV_FILE}" \
  --file "${COMPOSE_FILE}" \
  up --detach --remove-orphans

echo "[bulldozer] Container started. Waiting for health check..."
sleep 5

HOST_PORT_VAL=$(grep -E '^HOST_PORT=' "${ENV_FILE}" | cut -d'=' -f2- | tr -d '"' || echo "8080")
if curl -sf "http://localhost:${HOST_PORT_VAL}/api/healthz" > /dev/null; then
  echo "[bulldozer] Health check passed — server is ready."
else
  echo "[bulldozer] WARNING: Health check did not pass yet. Check logs:"
  echo "[bulldozer]   docker compose --file ${COMPOSE_FILE} logs --tail=50"
fi
