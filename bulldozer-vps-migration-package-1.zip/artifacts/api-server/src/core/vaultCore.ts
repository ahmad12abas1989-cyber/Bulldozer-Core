// Vault Core Skeleton — Phase 196
// Metadata-only in-memory registry for secret descriptors.
// Never accepts, stores, or returns secret values.
// No init, no subsystem registration, no health checks, no event emission,
// no persistence, no encryption, not wired to request flow.

import { randomBytes } from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type VaultSecretType =
  | "api_key"
  | "session_token"
  | "service_credential"
  | "signing_key"
  | "encryption_key"
  | "webhook_secret"
  | "oauth_token";

export type VaultSecretScope =
  | "global"
  | "project"
  | "operator"
  | "service"
  | "user";

export interface VaultSecretMetadata {
  readonly secretId:        string;       // server-generated, 16-byte hex
  readonly type:            VaultSecretType;
  readonly scope:           VaultSecretScope;
  readonly ownerActorType:  string;       // caller-supplied actor type label
  readonly ownerActorId:    string;       // caller-supplied actor ID
  readonly expiresAt:       string | null; // ISO 8601 or null = no expiry
  readonly rotationRequired: boolean;
  readonly createdAt:       string;       // ISO 8601, server-generated
}

export interface RegisterVaultSecretInput {
  readonly type:            VaultSecretType;
  readonly scope:           VaultSecretScope;
  readonly ownerActorType:  string;
  readonly ownerActorId:    string;
  readonly expiresAt?:      string | null;
  readonly rotationRequired?: boolean;
  // Prohibited fields — never accepted:
  //   value, secret, token, password, credential, apiKey
}

export interface RegisterVaultSecretResult {
  readonly ok:      true;
  readonly metadata: VaultSecretMetadata;
}

export interface VaultSummary {
  readonly totalSecrets:       number;
  readonly byType:             Record<VaultSecretType, number>;
  readonly byScope:            Record<VaultSecretScope, number>;
  readonly rotationRequired:   number;
  readonly expiredCount:       number;
  readonly persistenceEnabled: false;
  readonly encryptionEnabled:  false;
  readonly implementationPhase: "skeleton";
}

// ---------------------------------------------------------------------------
// Store — in-memory only, never persisted
// ---------------------------------------------------------------------------

const store = new Map<string, VaultSecretMetadata>();

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

/**
 * Register a secret descriptor (metadata only).
 * Never accepts secret values — any field named value, secret, token,
 * password, credential, or apiKey is structurally excluded from input.
 * Returns the generated metadata record.
 */
export function registerVaultSecretMetadata(
  input: RegisterVaultSecretInput,
): RegisterVaultSecretResult {
  const secretId  = randomBytes(16).toString("hex");
  const createdAt = new Date().toISOString();

  const metadata: VaultSecretMetadata = {
    secretId,
    type:             input.type,
    scope:            input.scope,
    ownerActorType:   input.ownerActorType,
    ownerActorId:     input.ownerActorId,
    expiresAt:        input.expiresAt ?? null,
    rotationRequired: input.rotationRequired ?? false,
    createdAt,
  };

  store.set(secretId, metadata);

  return { ok: true, metadata };
}

/**
 * Return all registered secret metadata records, newest-first.
 * Never returns secret values — none are stored.
 */
export function listVaultSecretMetadata(): readonly VaultSecretMetadata[] {
  const records = Array.from(store.values());
  records.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return records;
}

/**
 * Return a summary of the vault state.
 */
export function getVaultSummary(): VaultSummary {
  const now     = new Date().toISOString();
  const records = Array.from(store.values());

  const byType  = {} as Record<VaultSecretType, number>;
  const byScope = {} as Record<VaultSecretScope, number>;
  let rotationRequired = 0;
  let expiredCount     = 0;

  for (const r of records) {
    byType[r.type]   = (byType[r.type]   ?? 0) + 1;
    byScope[r.scope] = (byScope[r.scope] ?? 0) + 1;
    if (r.rotationRequired)                            rotationRequired++;
    if (r.expiresAt !== null && r.expiresAt < now)    expiredCount++;
  }

  return {
    totalSecrets:        store.size,
    byType,
    byScope,
    rotationRequired,
    expiredCount,
    persistenceEnabled:  false,
    encryptionEnabled:   false,
    implementationPhase: "skeleton",
  };
}
