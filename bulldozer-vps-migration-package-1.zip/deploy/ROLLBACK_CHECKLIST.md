# Bulldozer Mother Core — Rollback Checklist

> Use this checklist if a VPS migration or server update goes wrong.
> Every step must be completed in order. Do not skip steps.
> Mother Core sealed architecture is never modified during rollback.

---

## When to roll back

Roll back if any of the following occur after a migration or update:

- [ ] `/api/healthz` does not return HTTP 200 within 60 seconds of start
- [ ] `allHealthy` is `false` in `/api/health/full`
- [ ] `cycleCount` is non-zero in `/api/runtime/graph/status`
- [ ] `routePolicyCount` is not 162 in `/api/access/status`
- [ ] Any UI route (`/ui`, `/ui/observation`, `/ui/governance`, `/ui/diagnostics`) returns non-200
- [ ] Container exits repeatedly (check `docker logs bulldozer-core`)
- [ ] Data corruption detected in storage (malformed JSON, missing files)
- [ ] `SESSION_SECRET` was accidentally logged or exposed

---

## Phase 1 — Immediate containment

- [ ] **Stop the container** — `./deploy/scripts/stop.sh`
- [ ] **Capture logs** before they are lost:
  ```bash
  docker logs bulldozer-core > /tmp/bulldozer-failure-$(date +%s).log 2>&1
  ```
- [ ] Note the exact timestamp of the failure (UTC)
- [ ] Note the last known good commit SHA: `git log --oneline -5`

---

## Phase 2 — Assess storage integrity

- [ ] Inspect the storage directory:
  ```bash
  ls -lah /opt/bulldozer/storage/
  ls -lah /opt/bulldozer/storage/store/
  ```
- [ ] Check for `.tmp` files (incomplete atomic writes):
  ```bash
  find /opt/bulldozer/storage -name "*.tmp"
  ```
  If any `.tmp` files are found, they are safe to delete — they are incomplete writes that did not atomically replace the target.
- [ ] Verify key store files are valid JSON:
  ```bash
  for f in /opt/bulldozer/storage/store/*.json; do
    python3 -m json.tool "$f" > /dev/null && echo "OK: $f" || echo "CORRUPT: $f"
  done
  ```

---

## Phase 3 — Roll back storage (if corrupted)

- [ ] Identify the most recent good backup:
  ```bash
  ls -lt /opt/bulldozer/backups/bulldozer-backup-*.tar.gz | head -5
  ```
- [ ] Verify backup checksum:
  ```bash
  sha256sum --check /opt/bulldozer/backups/<archive>.tar.gz.sha256
  ```
- [ ] Run restore:
  ```bash
  ./deploy/scripts/restore.sh /opt/bulldozer/backups/<archive>.tar.gz
  ```
  The restore script preserves the corrupted storage directory at `storage.pre-restore-<timestamp>` before overwriting.

---

## Phase 4 — Roll back the application image

- [ ] Identify the last known good Docker image:
  ```bash
  docker images bulldozer-core --format "{{.Tag}}\t{{.CreatedAt}}\t{{.ID}}"
  ```
- [ ] Tag the previous image as latest:
  ```bash
  docker tag bulldozer-core:<previous-tag> bulldozer-core:latest
  ```
- [ ] Or roll back via git and rebuild:
  ```bash
  git checkout <last-known-good-commit>
  docker build --file deploy/Dockerfile --tag bulldozer-core:latest .
  ```

---

## Phase 5 — Restart and verify

- [ ] Start the container: `./deploy/scripts/start.sh`
- [ ] Run the full health check suite: `./deploy/scripts/health-check.sh`
- [ ] Confirm all invariants:
  - [ ] `allHealthy=true`
  - [ ] `cycleCount=0`
  - [ ] `routePolicyCount=162`
  - [ ] `/ui/observation` returns 200
  - [ ] `actualWritesEnabled=false` (Mother Core write-blocked)
- [ ] Check the observation UI at `/ui/observation` — Architecture Era Banner should read **Production Extraction** with INFRA LOCKED badge

---

## Phase 6 — Post-rollback documentation

- [ ] Record the incident: what failed, when, what was rolled back
- [ ] Preserve the failure logs captured in Phase 1
- [ ] Preserve the `storage.pre-restore-<timestamp>` directory until root cause is confirmed
- [ ] Do not delete corrupted storage until a post-mortem is complete
- [ ] Update the deployment log with rollback timestamp and cause

---

## Sealed architecture invariants (never change during rollback)

| File | Action |
|---|---|
| `artifacts/api-server/src/core/*.ts` (sealed) | **Never edit** — these are compile-time descriptor-only cores |
| `artifacts/api-server/BASELINE_LOCK.json` | **Never edit** — frozen at Phase 43 |
| `artifacts/api-server/src/server.ts` | Edit only if explicitly approved by a new phase |
| Compile-time literal `actualWritesEnabled=false` | **Never flip** without a full multi-layer approval chain |

Rolling back never requires modifying sealed cores. If a proposed rollback would require editing a sealed core, stop and re-evaluate.
