// Experimental Generation Observe Route — Phase 217
// GET /api/generation/experimental
// Read-only diagnostic view of the in-memory experimental generation registry.
// No generation trigger, no filesystem writes, no execution, no deployment,
// no sandbox execution, no plugin execution, no vault access.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  listExperimentalGenerationRecords,
  getExperimentalGenerationSummary,
} from "../core/experimentalGenerationCore";

export function handleExperimentalGenerationObserve(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  const generations = listExperimentalGenerationRecords();
  const summary     = getExperimentalGenerationSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    generationEnabled:  false,
    executionEnabled:   false,
    deploymentEnabled:  false,
    persistenceEnabled: false,
    executionBlocked:   true,
    deploymentBlocked:  true,
    totalGenerations:   generations.length,
    summary,
    generations,
  });
}
