import { getFullHealth, type HealthStatus } from "./healthMonitor";
import { getBaselineStatus } from "./baseline";
import { getLifecycleLedgerStatus } from "./requestLifecycleLedger";
import { getAuditLogStatus } from "./auditLog";
import { getAccessEnforcementStatus } from "./accessEnforcement";
import { getSessionContextStatus } from "./sessionContext";
import { getRuntimeDependencyGraphStatus } from "./runtimeDependencyGraph";
import { getCapabilityMatrixStatus } from "./runtimeCapabilityMatrix";
import { router } from "./router";
import { getRateLimiterStatus, type RateLimitAnomaly } from "./rateLimiter";
import { getApiKeyAuthStatus } from "./apiKeyAuth";
import { getVaultStatus, type VaultEntry } from "./secretVault";
import { listRuntimeSnapshots } from "./runtimeSnapshot";
import { getProductLayerHealth, type ProductLayerHealth } from "./projectRegistry";

const HEALTH_CHECKS_TOTAL = 38;
const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;

export interface DiagnosticsHealth {
  status: HealthStatus;
  checkCount: number;
  passCount: number;
  warnCount: number;
  failCount: number;
}

export interface DiagnosticsBaselineField {
  baseline: number;
  live: number;
  match: boolean;
}

export interface DiagnosticsBaseline {
  status: string;
  phase: number;
  allFieldsMatch: boolean;
  endpointCount: DiagnosticsBaselineField;
  healthCheckCount: DiagnosticsBaselineField;
  subsystemCount: DiagnosticsBaselineField;
  graphNodeCount: DiagnosticsBaselineField;
  cycleCount: DiagnosticsBaselineField;
  invalidReferenceCount: DiagnosticsBaselineField;
}

export interface DiagnosticsLifecycle {
  recordCount: number;
  capacity: number;
  percentiles: { p50: number | null; p95: number | null; p99: number | null } | null;
  statusDistribution: { "2xx": number; "4xx": number; "5xx": number; other: number };
  slowRequestCount: number;
  slowThresholdMs: number;
}

export interface DiagnosticsAudit {
  entryCount: number;
  capacity: number;
  oldestEntryAt: string | null;
  newestEntryAt: string | null;
}

export interface DiagnosticsAccess {
  routePolicyCount: number;
  enforcementMode: string;
  authEnabled: boolean;
  executionBlocked: true;
  recoveryBlocked: true;
}

export interface DiagnosticsSession {
  sessionCount: number;
  capacity: number;
  authEnabled: boolean;
  defaultRole: string;
  defaultActorType: string;
  executionBlocked: true;
  recoveryBlocked: true;
}

export interface DiagnosticsGraph {
  nodeCount: number;
  cycleCount: number;
  maxDepth: number;
  hasCycles: boolean;
}

export interface DiagnosticsCapabilities {
  subsystemCount: number;
  invalidReferenceCount: number;
  validationStatus: string;
}

export type { ProductLayerHealth };
export { RateLimitAnomaly };

export interface DiagnosticsRateLimit {
  operational: boolean;
  windowMs: number;
  maxIdentityKeys: number;
  activeKeys: number;
  totalRequestsChecked: number;
  totalBlocked: number;
  lastBlockedAt: string | null;
  lastBlockedKey: string | null;
  anomalyCount: number;
  recentAnomalies: RateLimitAnomaly[];
  lastAnomalyAt: string | null;
}

export interface DiagnosticsAuth {
  operational: boolean;
  ownerKeyConfigured: boolean;
  serviceKeyConfigured: boolean;
  totalApiKeyRequests: number;
  totalValidApiKeyRequests: number;
  totalInvalidApiKeyRequests: number;
  lastInvalidAt: string | null;
  timingSafeComparison: boolean;
}

export type { VaultEntry };

export interface DiagnosticsVault {
  operational: boolean;
  totalSecrets: number;
  configuredCount: number;
  unconfiguredCount: number;
  placeholderCount: number;
  entries: VaultEntry[];
  lastCheckedAt: string;
}

export interface DiagnosticsSafetyFlags {
  executionBlocked: true;
  recoveryBlocked: true;
  executePermissionBlocked: true;
  enforcementMode: "observe";
  commandExecutionBlocked: true;
  executionStillBlocked: true;
}

export interface DiagnosticsCounts {
  endpoints: number;
  healthChecks: number;
  subsystems: number;
  graphNodes: number;
}

export interface DriftField {
  name: string;
  expected: number;
  actual: number;
  drifted: boolean;
  firstDetectedAt: string | null;
}

export interface DriftReport {
  driftDetected: boolean;
  checkedAt: string;
  fields: DriftField[];
}

export interface SnapshotConsistencyMismatch {
  field: string;
  liveValue: number;
  snapshotValue: number;
}

export interface SnapshotConsistency {
  consistencyCheckedAt: string;
  snapshotCountCompared: number;
  consistent: boolean;
  mismatchFields: SnapshotConsistencyMismatch[];
  comparedFields: string[];
  untrackedFields: string[];
  latestSnapshotId: string | null;
  latestSnapshotCreatedAt: string | null;
}

export type OverallDiagnosticsStatus = "ok" | "warning" | "degraded";

export interface StatusTransition {
  fromStatus: OverallDiagnosticsStatus;
  toStatus: OverallDiagnosticsStatus;
  detectedAt: string;
  durationMs: number;
  reasons: string[];
}

export interface StatusTransitionHistory {
  capacity: number;
  totalTransitions: number;
  transitions: StatusTransition[];
}

export interface PollingCadence {
  totalPollCount: number;
  lastPolledAt: string;
  previousPolledAt: string | null;
  recentIntervalsMs: number[];
  avgIntervalMs: number | null;
  minIntervalMs: number | null;
  maxIntervalMs: number | null;
}

export interface DiagnosticsHealthSummary {
  overallDiagnosticsStatus: OverallDiagnosticsStatus;
  checkedAt: string;
  currentStatusSince: string;
  reasons: string[];
  baselineOk: boolean;
  driftOk: boolean;
  snapshotConsistencyOk: boolean;
  statusHistory: StatusTransitionHistory;
  pollingCadence: PollingCadence;
}

export interface DiagnosticsSnapshot {
  timestamp: string;
  executionBlocked: true;
  recoveryBlocked: true;
  health: DiagnosticsHealth;
  baseline: DiagnosticsBaseline;
  lifecycle: DiagnosticsLifecycle;
  audit: DiagnosticsAudit;
  access: DiagnosticsAccess;
  session: DiagnosticsSession;
  graph: DiagnosticsGraph;
  capabilities: DiagnosticsCapabilities;
  rateLimit: DiagnosticsRateLimit;
  auth: DiagnosticsAuth;
  vault: DiagnosticsVault;
  safetyFlags: DiagnosticsSafetyFlags;
  counts: DiagnosticsCounts;
  driftReport: DriftReport;
  snapshotConsistency: SnapshotConsistency;
  diagnosticsHealth: DiagnosticsHealthSummary;
  productLayerHealth: ProductLayerHealth;
}

const driftFirstDetected = new Map<string, string>();

const POLLING_INTERVAL_CAPACITY = 50;
let totalPollCount = 0;
let lastPolledAt: string | null = null;
let previousPolledAt: string | null = null;
const pollingIntervalBuffer: number[] = [];

function recordAndGetPollingCadence(): PollingCadence {
  const now = new Date().toISOString();
  totalPollCount++;

  if (lastPolledAt !== null) {
    const intervalMs = Date.now() - new Date(lastPolledAt).getTime();
    previousPolledAt = lastPolledAt;
    pollingIntervalBuffer.push(intervalMs);
    if (pollingIntervalBuffer.length > POLLING_INTERVAL_CAPACITY) {
      pollingIntervalBuffer.shift();
    }
  }

  lastPolledAt = now;

  const avg =
    pollingIntervalBuffer.length > 0
      ? Math.round(pollingIntervalBuffer.reduce((a, b) => a + b, 0) / pollingIntervalBuffer.length)
      : null;
  const min = pollingIntervalBuffer.length > 0 ? Math.min(...pollingIntervalBuffer) : null;
  const max = pollingIntervalBuffer.length > 0 ? Math.max(...pollingIntervalBuffer) : null;

  return {
    totalPollCount,
    lastPolledAt: now,
    previousPolledAt,
    recentIntervalsMs: [...pollingIntervalBuffer],
    avgIntervalMs: avg,
    minIntervalMs: min,
    maxIntervalMs: max,
  };
}

const STATUS_HISTORY_CAPACITY = 50;
let lastKnownStatus: OverallDiagnosticsStatus | null = null;
let currentStatusSince: string | null = null;
let totalStatusTransitions = 0;
const statusTransitionBuffer: StatusTransition[] = [];

function recordAndGetStatusHistory(
  newStatus: OverallDiagnosticsStatus,
  reasons: string[],
): StatusTransitionHistory {
  const now = new Date().toISOString();

  if (lastKnownStatus === null) {
    currentStatusSince = now;
  } else if (lastKnownStatus !== newStatus) {
    const durationMs = Date.now() - new Date(currentStatusSince!).getTime();
    const transition: StatusTransition = {
      fromStatus: lastKnownStatus,
      toStatus: newStatus,
      detectedAt: now,
      durationMs,
      reasons: [...reasons],
    };
    statusTransitionBuffer.push(transition);
    if (statusTransitionBuffer.length > STATUS_HISTORY_CAPACITY) {
      statusTransitionBuffer.shift();
    }
    totalStatusTransitions++;
    currentStatusSince = now;
  }

  lastKnownStatus = newStatus;
  return {
    capacity: STATUS_HISTORY_CAPACITY,
    totalTransitions: totalStatusTransitions,
    transitions: [...statusTransitionBuffer].reverse(),
  };
}

const DRIFT_FIELD_NAMES = [
  "endpointCount",
  "healthCheckCount",
  "subsystemCount",
  "graphNodeCount",
  "cycleCount",
  "invalidReferenceCount",
] as const;

type DriftFieldName = (typeof DRIFT_FIELD_NAMES)[number];

function buildDriftReport(baseline: DiagnosticsBaseline): DriftReport {
  const checkedAt = new Date().toISOString();
  const fields: DriftField[] = [];

  for (const name of DRIFT_FIELD_NAMES) {
    const field = baseline[name as DriftFieldName];
    const drifted = !field.match;

    if (drifted) {
      if (!driftFirstDetected.has(name)) {
        driftFirstDetected.set(name, checkedAt);
      }
    } else {
      driftFirstDetected.delete(name);
    }

    fields.push({
      name,
      expected: field.baseline,
      actual: field.live,
      drifted,
      firstDetectedAt: driftFirstDetected.get(name) ?? null,
    });
  }

  return {
    driftDetected: fields.some((f) => f.drifted),
    checkedAt,
    fields,
  };
}

function buildDiagnosticsHealth(
  diagBaseline: DiagnosticsBaseline,
  driftReport: DriftReport,
  snapshotConsistency: SnapshotConsistency,
): Omit<DiagnosticsHealthSummary, "statusHistory" | "currentStatusSince" | "pollingCadence"> {
  const checkedAt = new Date().toISOString();
  const baselineOk = diagBaseline.allFieldsMatch;
  const driftOk = !driftReport.driftDetected;
  const snapshotConsistencyOk = snapshotConsistency.consistent;

  const reasons: string[] = [];
  if (!baselineOk) reasons.push("Baseline field mismatch detected");
  if (!driftOk) reasons.push("Baseline drift detected in one or more fields");
  if (!snapshotConsistencyOk) reasons.push("Live state inconsistent with latest runtime snapshot");

  let overallDiagnosticsStatus: OverallDiagnosticsStatus;
  if (!baselineOk || !driftOk) {
    overallDiagnosticsStatus = "degraded";
  } else if (!snapshotConsistencyOk) {
    overallDiagnosticsStatus = "warning";
  } else {
    overallDiagnosticsStatus = "ok";
  }

  return {
    overallDiagnosticsStatus,
    checkedAt,
    reasons,
    baselineOk,
    driftOk,
    snapshotConsistencyOk,
  };
}

const SNAPSHOT_COMPARED_FIELDS = ["endpointCount", "healthCheckCount"] as const;
const SNAPSHOT_UNTRACKED_FIELDS = ["subsystemCount", "graphNodeCount"] as const;

function buildSnapshotConsistency(
  liveEndpoints: number,
  liveHealthChecks: number,
): SnapshotConsistency {
  const consistencyCheckedAt = new Date().toISOString();
  const snapshotList = listRuntimeSnapshots();
  const all = [...snapshotList.active, ...snapshotList.archived];

  if (all.length === 0) {
    return {
      consistencyCheckedAt,
      snapshotCountCompared: 0,
      consistent: true,
      mismatchFields: [],
      comparedFields: [],
      untrackedFields: [...SNAPSHOT_UNTRACKED_FIELDS],
      latestSnapshotId: null,
      latestSnapshotCreatedAt: null,
    };
  }

  const sorted = [...all].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
  const latest = sorted[0];

  const mismatchFields: SnapshotConsistencyMismatch[] = [];

  if (latest.endpointCount !== liveEndpoints) {
    mismatchFields.push({
      field: "endpointCount",
      liveValue: liveEndpoints,
      snapshotValue: latest.endpointCount,
    });
  }

  if (latest.healthCheckCount !== liveHealthChecks) {
    mismatchFields.push({
      field: "healthCheckCount",
      liveValue: liveHealthChecks,
      snapshotValue: latest.healthCheckCount,
    });
  }

  return {
    consistencyCheckedAt,
    snapshotCountCompared: 1,
    consistent: mismatchFields.length === 0,
    mismatchFields,
    comparedFields: [...SNAPSHOT_COMPARED_FIELDS],
    untrackedFields: [...SNAPSHOT_UNTRACKED_FIELDS],
    latestSnapshotId: latest.id,
    latestSnapshotCreatedAt: latest.createdAt,
  };
}

export function getDiagnosticsSnapshot(): DiagnosticsSnapshot {
  const health = getFullHealth();
  const baseline = getBaselineStatus();
  const lifecycle = getLifecycleLedgerStatus();
  const audit = getAuditLogStatus();
  const access = getAccessEnforcementStatus();
  const session = getSessionContextStatus();
  const graph = getRuntimeDependencyGraphStatus();
  const caps = getCapabilityMatrixStatus();
  const rl = getRateLimiterStatus();
  const auth = getApiKeyAuthStatus();
  const vault = getVaultStatus();

  const passCount = health.checks.filter((c) => c.status === "pass").length;
  const warnCount = health.checks.filter((c) => c.status === "warn").length;
  const failCount = health.checks.filter((c) => c.status === "fail").length;

  const allFieldsMatch =
    baseline.endpointCount.match &&
    baseline.healthCheckCount.match &&
    baseline.subsystemCount.match &&
    baseline.graphNodeCount.match &&
    baseline.cycleCount.match &&
    baseline.invalidReferenceCount.match;

  const diagBaseline: DiagnosticsBaseline = {
    status: baseline.baselineStatus,
    phase: baseline.lockPhase,
    allFieldsMatch,
    endpointCount: baseline.endpointCount,
    healthCheckCount: baseline.healthCheckCount,
    subsystemCount: baseline.subsystemCount,
    graphNodeCount: baseline.graphNodeCount,
    cycleCount: baseline.cycleCount,
    invalidReferenceCount: baseline.invalidReferenceCount,
  };

  const driftReport = buildDriftReport(diagBaseline);
  const snapshotConsistency = buildSnapshotConsistency(
    router.list().length,
    HEALTH_CHECKS_TOTAL,
  );
  const diagnosticsHealthBase = buildDiagnosticsHealth(diagBaseline, driftReport, snapshotConsistency);
  const statusHistory = recordAndGetStatusHistory(
    diagnosticsHealthBase.overallDiagnosticsStatus,
    diagnosticsHealthBase.reasons,
  );
  const pollingCadence = recordAndGetPollingCadence();
  const diagnosticsHealth: DiagnosticsHealthSummary = {
    ...diagnosticsHealthBase,
    currentStatusSince: currentStatusSince!,
    statusHistory,
    pollingCadence,
  };

  return {
    timestamp: new Date().toISOString(),
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    health: {
      status: health.status,
      checkCount: health.checks.length,
      passCount,
      warnCount,
      failCount,
    },
    baseline: diagBaseline,
    lifecycle: {
      recordCount: lifecycle.recordCount,
      capacity: lifecycle.capacity,
      percentiles: lifecycle.percentiles,
      statusDistribution: lifecycle.statusDistribution,
      slowRequestCount: lifecycle.slowRequestCount,
      slowThresholdMs: lifecycle.slowThresholdMs,
    },
    audit: {
      entryCount: audit.entryCount,
      capacity: audit.capacity,
      oldestEntryAt: audit.oldestEntryAt,
      newestEntryAt: audit.newestEntryAt,
    },
    access: {
      routePolicyCount: access.routePolicyCount,
      enforcementMode: access.enforcementMode,
      authEnabled: access.authEnabled,
      executionBlocked: EXECUTION_BLOCKED,
      recoveryBlocked: RECOVERY_BLOCKED,
    },
    session: {
      sessionCount: session.sessionCount,
      capacity: session.capacity,
      authEnabled: session.authEnabled,
      defaultRole: session.defaultRole,
      defaultActorType: session.defaultActorType,
      executionBlocked: EXECUTION_BLOCKED,
      recoveryBlocked: RECOVERY_BLOCKED,
    },
    graph: {
      nodeCount: graph.totalNodes,
      cycleCount: graph.cycleCount,
      maxDepth: graph.maxDepth,
      hasCycles: graph.cycleCount > 0,
    },
    capabilities: {
      subsystemCount: caps.totalSubsystems,
      invalidReferenceCount: caps.invalidReferenceCount,
      validationStatus: caps.validationStatus,
    },
    rateLimit: {
      operational: rl.operational,
      windowMs: rl.windowMs,
      maxIdentityKeys: rl.maxIdentityKeys,
      activeKeys: rl.activeKeys,
      totalRequestsChecked: rl.totalRequestsChecked,
      totalBlocked: rl.totalBlocked,
      lastBlockedAt: rl.lastBlockedAt,
      lastBlockedKey: rl.lastBlockedKey,
      anomalyCount: rl.anomalyCount,
      recentAnomalies: rl.recentAnomalies,
      lastAnomalyAt: rl.lastAnomalyAt,
    },
    auth: {
      operational: auth.operational,
      ownerKeyConfigured: auth.ownerKeyConfigured,
      serviceKeyConfigured: auth.serviceKeyConfigured,
      totalApiKeyRequests: auth.totalApiKeyRequests,
      totalValidApiKeyRequests: auth.totalValidApiKeyRequests,
      totalInvalidApiKeyRequests: auth.totalInvalidApiKeyRequests,
      lastInvalidAt: auth.lastInvalidAt,
      timingSafeComparison: auth.timingSafeComparison,
    },
    vault: {
      operational: vault.operational,
      totalSecrets: vault.totalSecrets,
      configuredCount: vault.configuredCount,
      unconfiguredCount: vault.unconfiguredCount,
      placeholderCount: vault.placeholderCount,
      entries: vault.entries,
      lastCheckedAt: vault.lastCheckedAt,
    },
    safetyFlags: {
      executionBlocked: EXECUTION_BLOCKED,
      recoveryBlocked: RECOVERY_BLOCKED,
      executePermissionBlocked: true,
      enforcementMode: "observe",
      commandExecutionBlocked: true,
      executionStillBlocked: true,
    },
    counts: {
      endpoints: router.list().length,
      healthChecks: HEALTH_CHECKS_TOTAL,
      subsystems: caps.totalSubsystems,
      graphNodes: graph.totalNodes,
    },
    driftReport,
    snapshotConsistency,
    diagnosticsHealth,
    productLayerHealth: getProductLayerHealth(),
  };
}
