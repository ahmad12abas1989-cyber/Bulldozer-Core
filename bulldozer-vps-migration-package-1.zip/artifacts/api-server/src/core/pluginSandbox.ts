import { logger } from "../lib/logger";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";

export type PermissionName =
  | "filesystem"
  | "network"
  | "processControl"
  | "shellExecution"
  | "externalApi";

export interface PluginPermissions {
  filesystem: "denied";
  network: "denied";
  processControl: "denied";
  shellExecution: "denied";
  externalApi: "denied";
}

export interface SandboxedPlugin {
  pluginId: string;
  registeredAt: string;
  metadata: Record<string, unknown>;
  permissions: PluginPermissions;
  isolated: true;
}

export interface PermissionEvaluation {
  pluginId: string;
  permissions: PluginPermissions;
  deniedPermissions: PermissionName[];
  allDenied: true;
  timestamp: string;
}

export interface PluginSandboxState {
  status: "operational";
  registeredPluginCount: number;
  deniedPermissions: PermissionName[];
  isolatedPlugins: SandboxedPlugin[];
  lastSandboxEventAt: string | null;
  timestamp: string;
}

const DENIED_PERMISSIONS: PluginPermissions = {
  filesystem: "denied",
  network: "denied",
  processControl: "denied",
  shellExecution: "denied",
  externalApi: "denied",
};

const ALL_DENIED: PermissionName[] = [
  "filesystem",
  "network",
  "processControl",
  "shellExecution",
  "externalApi",
];

const plugins = new Map<string, SandboxedPlugin>();
let lastSandboxEventAt: string | null = null;

function touchEvent(timestamp: string): void {
  lastSandboxEventAt = timestamp;
}

export function registerSandboxedPlugin(
  pluginId: string,
  metadata: Record<string, unknown> = {},
): SandboxedPlugin {
  const now = new Date().toISOString();

  const plugin: SandboxedPlugin = {
    pluginId,
    registeredAt: now,
    metadata,
    permissions: { ...DENIED_PERMISSIONS },
    isolated: true,
  };

  plugins.set(pluginId, plugin);
  touchEvent(now);

  emit("plugin_sandbox:registered", "plugin-sandbox", { pluginId, isolated: true });
  addTimelineEvent({
    level: "info",
    source: "plugin-sandbox",
    message: `Plugin registered in sandbox: ${pluginId}`,
    metadata: { pluginId, isolated: true, permissionsAllDenied: true },
  });
  logger.info({ pluginId }, "Plugin registered in sandbox (all permissions denied)");

  return plugin;
}

export function unregisterSandboxedPlugin(pluginId: string): boolean {
  const existed = plugins.has(pluginId);
  if (!existed) return false;

  const now = new Date().toISOString();
  plugins.delete(pluginId);
  touchEvent(now);

  emit("plugin_sandbox:unregistered", "plugin-sandbox", { pluginId });
  addTimelineEvent({
    level: "info",
    source: "plugin-sandbox",
    message: `Plugin unregistered from sandbox: ${pluginId}`,
    metadata: { pluginId },
  });
  logger.info({ pluginId }, "Plugin unregistered from sandbox");

  return true;
}

export function evaluatePluginPermissions(pluginId: string): PermissionEvaluation {
  const now = new Date().toISOString();

  if (!plugins.has(pluginId)) {
    emit("plugin_sandbox:permission_check_unknown", "plugin-sandbox", { pluginId });
    logger.warn({ pluginId }, "Permission evaluation requested for unknown plugin");
  }

  return {
    pluginId,
    permissions: { ...DENIED_PERMISSIONS },
    deniedPermissions: [...ALL_DENIED],
    allDenied: true,
    timestamp: now,
  };
}

export function getPluginSandboxStatus(): PluginSandboxState {
  return {
    status: "operational",
    registeredPluginCount: plugins.size,
    deniedPermissions: [...ALL_DENIED],
    isolatedPlugins: Array.from(plugins.values()),
    lastSandboxEventAt,
    timestamp: new Date().toISOString(),
  };
}
