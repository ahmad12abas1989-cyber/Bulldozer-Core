import type { IncomingMessage, ServerResponse } from "node:http";
import { getSnapshotHistory } from "../core/snapshots";
import { sendJson } from "../lib/response";

export function handleSnapshots(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getSnapshotHistory());
}
