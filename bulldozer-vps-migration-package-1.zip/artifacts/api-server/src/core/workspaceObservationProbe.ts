import { createHash } from "node:crypto";
import { getPolicyComplianceLedger } from "./workspacePolicyComplianceLedger";
import { getWorkspaceObservationHeatmap } from "./workspaceObservationHeatmap";
import { getWorkspaceCoverageTrend } from "./workspaceCoverageTrend";
import { getWorkspacePolicyExposureIndex } from "./workspacePolicyExposureIndex";
import { getWorkspaceGovernanceScorecard } from "./workspaceGovernanceScorecard";

const EXECUTION_BLOCKED: true = true;
const TOTAL_PROBES = 5;

// --- Types ---

export interface SubProbeResult {
  probeIndex: number;
  moduleName: string;
  endpoint: string;
  responseTimeMs: number;
  schemaValid: boolean;
  executionBlockedValid: boolean;
  missingFields: string[];
  passed: boolean;
  executionBlocked: true;
}

export interface ObservationProbeSummary {
  allProbesPassed: boolean;
  passedProbeCount: number;
  failedProbeCount: number;
  totalProbes: number;
  fastestProbeMs: number | null;
  slowestProbeMs: number | null;
  totalProbeTimeMs: number;
  executionBlocked: true;
}

export interface WorkspaceObservationProbeResult {
  probeId: string;
  generatedAt: string;
  summary: ObservationProbeSummary;
  probes: SubProbeResult[];
  executionBlocked: true;
}

// --- Schema validators ---
// Each returns an array of missing top-level field names.
// An empty array means schemaValid = true.

function validateObject(obj: unknown, required: string[]): string[] {
  if (obj === null || typeof obj !== "object") {
    return ["(not an object)"];
  }
  const rec = obj as Record<string, unknown>;
  return required.filter((k) => !(k in rec));
}

const COMPLIANCE_REQUIRED = [
  "ledgerId",
  "generatedAt",
  "summary",
  "entries",
  "auditEntriesScanned",
  "executionBlocked",
];

const HEATMAP_REQUIRED = [
  "heatmapId",
  "generatedAt",
  "summary",
  "permissionMatrix",
  "roleTierMatrix",
  "policies",
  "auditEntriesScanned",
  "executionBlocked",
];

const TREND_REQUIRED = [
  "trendId",
  "generatedAt",
  "summary",
  "snapshotHistory",
  "auditEntriesScanned",
  "executionBlocked",
];

const EXPOSURE_REQUIRED = [
  "exposureId",
  "generatedAt",
  "summary",
  "entries",
  "totalPoliciesScanned",
  "auditEntriesScanned",
  "executionBlocked",
];

const SCORECARD_REQUIRED = [
  "scorecardId",
  "generatedAt",
  "governanceScore",
  "governanceGrade",
  "breakdown",
  "recommendations",
  "signals",
  "executionBlocked",
];

// --- Probe runners ---

function runSubProbe(
  probeIndex: number,
  moduleName: string,
  endpoint: string,
  required: string[],
  runner: () => unknown,
): SubProbeResult {
  const start = Date.now();
  let result: unknown;
  try {
    result = runner();
  } catch {
    const responseTimeMs = Date.now() - start;
    return {
      probeIndex,
      moduleName,
      endpoint,
      responseTimeMs,
      schemaValid: false,
      executionBlockedValid: false,
      missingFields: ["(module threw an exception)"],
      passed: false,
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  const responseTimeMs = Date.now() - start;

  const missingFields = validateObject(result, required);
  const schemaValid = missingFields.length === 0;

  const asRecord = result !== null && typeof result === "object"
    ? (result as Record<string, unknown>)
    : null;
  const executionBlockedValid = asRecord !== null && asRecord["executionBlocked"] === true;

  return {
    probeIndex,
    moduleName,
    endpoint,
    responseTimeMs,
    schemaValid,
    executionBlockedValid,
    missingFields,
    passed: schemaValid && executionBlockedValid,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Public API ---

export function getWorkspaceObservationProbe(): WorkspaceObservationProbeResult {
  const generatedAt = new Date().toISOString();
  const probeId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  // All 5 probes run sequentially — deterministic order, no parallelism
  const probes: SubProbeResult[] = [
    runSubProbe(
      1,
      "workspacePolicyComplianceLedger",
      "/api/workspace/policy/compliance",
      COMPLIANCE_REQUIRED,
      getPolicyComplianceLedger,
    ),
    runSubProbe(
      2,
      "workspaceObservationHeatmap",
      "/api/workspace/observation/heatmap",
      HEATMAP_REQUIRED,
      getWorkspaceObservationHeatmap,
    ),
    runSubProbe(
      3,
      "workspaceCoverageTrend",
      "/api/workspace/observation/trend",
      TREND_REQUIRED,
      getWorkspaceCoverageTrend,
    ),
    runSubProbe(
      4,
      "workspacePolicyExposureIndex",
      "/api/workspace/observation/exposure",
      EXPOSURE_REQUIRED,
      getWorkspacePolicyExposureIndex,
    ),
    runSubProbe(
      5,
      "workspaceGovernanceScorecard",
      "/api/workspace/governance/scorecard",
      SCORECARD_REQUIRED,
      getWorkspaceGovernanceScorecard,
    ),
  ];

  const passedProbeCount = probes.filter((p) => p.passed).length;
  const failedProbeCount = TOTAL_PROBES - passedProbeCount;
  const allProbesPassed = failedProbeCount === 0;
  const totalProbeTimeMs = probes.reduce((acc, p) => acc + p.responseTimeMs, 0);

  const times = probes.map((p) => p.responseTimeMs);
  const fastestProbeMs = times.length > 0 ? Math.min(...times) : null;
  const slowestProbeMs = times.length > 0 ? Math.max(...times) : null;

  const summary: ObservationProbeSummary = {
    allProbesPassed,
    passedProbeCount,
    failedProbeCount,
    totalProbes: TOTAL_PROBES,
    fastestProbeMs,
    slowestProbeMs,
    totalProbeTimeMs,
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    probeId,
    generatedAt,
    summary,
    probes,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
