import { randomBytes } from "node:crypto";
import { registerSubsystemState } from "./runtimeStateRegistry";
import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";
import { readStore, writeStore } from "./persistentStore";

export interface LifecycleRecord {
  id: string;
  requestId: string;
  correlationId: string;
  method: string;
  route: string;
  startedAt: string;
  finishedAt: string;
  statusCode: number;
  latencyMs: number;
  executionBlocked: true;
}

export interface LifecycleRecordInput {
  requestId: string;
  correlationId: string;
  method: string;
  route: string;
  startedAt: string;
  finishedAt: string;
  statusCode: number;
  latencyMs: number;
}

export interface LatencyPercentiles {
  p50: number | null;
  p95: number | null;
  p99: number | null;
}

export interface StatusDistribution {
  "2xx": number;
  "4xx": number;
  "5xx": number;
  other: number;
}

export interface LifecycleFilter {
  statusCode?: number;
  route?: string;
  method?: string;
  minLatencyMs?: number;
  maxLatencyMs?: number;
  limit?: number;
}

export interface LifecycleLedgerStatus {
  operational: boolean;
  subsystemName: "request_lifecycle_ledger";
  recordCount: number;
  capacity: number;
  oldestRecordAt: string | null;
  newestRecordAt: string | null;
  percentiles: LatencyPercentiles | null;
  statusDistribution: StatusDistribution;
  slowRequestCount: number;
  slowThresholdMs: number;
  executionBlocked: true;
  recoveryBlocked: true;
  initializedAt: string | null;
}

export interface LifecycleLedgerResult {
  executionBlocked: true;
  recoveryBlocked: true;
  recordCount: number;
  capacity: number;
  limit: number;
  filteredCount: number;
  filtersApplied: Record<string, string>;
  records: LifecycleRecord[];
  timestamp: string;
}

const MAX_RECORDS = 500;
const MAX_QUERY_LIMIT = 100;
const SLOW_REQUEST_THRESHOLD_MS = 500;
const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;
const PERSIST_LIMIT = 500;
const STORE_KEY = "lifecycle-ledger";

const ledger: LifecycleRecord[] = [];
let isOperational = false;
let initializedAt: string | null = null;
let slowRequestCount = 0;

function isValidLifecycleRecord(obj: unknown): obj is LifecycleRecord {
  if (obj === null || typeof obj !== "object") return false;
  const r = obj as Record<string, unknown>;
  return (
    typeof r["id"] === "string" &&
    typeof r["requestId"] === "string" &&
    typeof r["correlationId"] === "string" &&
    typeof r["method"] === "string" &&
    typeof r["route"] === "string" &&
    typeof r["startedAt"] === "string" &&
    typeof r["finishedAt"] === "string" &&
    typeof r["statusCode"] === "number" &&
    Number.isFinite(r["statusCode"]) &&
    typeof r["latencyMs"] === "number" &&
    Number.isFinite(r["latencyMs"]) &&
    (r["latencyMs"] as number) >= 0 &&
    r["executionBlocked"] === true
  );
}

function flushLifecycleLedger(): void {
  try {
    writeStore(STORE_KEY, ledger.slice(-PERSIST_LIMIT));
  } catch (err) {
    logger.warn({ err }, "lifecycle-ledger: flush to persistent store failed");
  }
}

function computePercentile(sorted: number[], pct: number): number | null {
  if (sorted.length === 0) return null;
  const idx = Math.min(Math.floor(sorted.length * pct), sorted.length - 1);
  return sorted[idx];
}

function computeLatencyPercentiles(): LatencyPercentiles | null {
  if (ledger.length === 0) return null;
  const sorted = ledger.map((r) => r.latencyMs).sort((a, b) => a - b);
  return {
    p50: computePercentile(sorted, 0.50),
    p95: computePercentile(sorted, 0.95),
    p99: computePercentile(sorted, 0.99),
  };
}

function computeStatusDistribution(): StatusDistribution {
  const dist: StatusDistribution = { "2xx": 0, "4xx": 0, "5xx": 0, other: 0 };
  for (const r of ledger) {
    if (r.statusCode >= 200 && r.statusCode < 300) dist["2xx"]++;
    else if (r.statusCode >= 400 && r.statusCode < 500) dist["4xx"]++;
    else if (r.statusCode >= 500 && r.statusCode < 600) dist["5xx"]++;
    else dist.other++;
  }
  return dist;
}

export function initRequestLifecycleLedger(): void {
  if (isOperational) return;

  registerSubsystemState({
    subsystemName: "request_lifecycle_ledger",
    category: "observability",
    dependencies: ["session_context", "audit_log", "runtime_state_registry"],
    metadata: {
      description:
        "Request lifecycle ledger — 500-entry ring buffer, statusCode + latencyMs + finishedAt on res.on(\"finish\"), p50/p95/p99 percentiles, slow request alerting at 500ms, executionBlocked always true",
    },
  });

  let restoredCount = 0;
  try {
    const stored = readStore<unknown>(STORE_KEY);
    if (Array.isArray(stored)) {
      for (const item of stored) {
        if (ledger.length >= MAX_RECORDS) break;
        if (isValidLifecycleRecord(item)) {
          ledger.push(item);
          restoredCount++;
          if (item.latencyMs >= SLOW_REQUEST_THRESHOLD_MS) {
            slowRequestCount++;
          }
        }
      }
    }
  } catch (err) {
    logger.warn({ err }, "lifecycle-ledger: restore from persistent store failed");
  }

  isOperational = true;
  initializedAt = new Date().toISOString();

  addTimelineEvent({
    level: "info",
    source: "request-lifecycle-ledger",
    message: "Request lifecycle ledger initialized",
    metadata: { capacity: MAX_RECORDS, slowThresholdMs: SLOW_REQUEST_THRESHOLD_MS, executionBlocked: EXECUTION_BLOCKED, restoredCount, persistLimit: PERSIST_LIMIT },
  });

  emit("request_lifecycle_ledger:initialized", "request-lifecycle-ledger", {
    capacity: MAX_RECORDS,
    slowThresholdMs: SLOW_REQUEST_THRESHOLD_MS,
    executionBlocked: EXECUTION_BLOCKED,
    restoredCount,
  });

  emitRuntimeEvent({
    eventType: "request_lifecycle_ledger.initialized",
    source: "request-lifecycle-ledger",
    severity: "info",
    category: "runtime",
    payload: { capacity: MAX_RECORDS, slowThresholdMs: SLOW_REQUEST_THRESHOLD_MS, executionBlocked: EXECUTION_BLOCKED, restoredCount },
  });

  logger.info(
    { capacity: MAX_RECORDS, slowThresholdMs: SLOW_REQUEST_THRESHOLD_MS, executionBlocked: EXECUTION_BLOCKED, restoredCount, persistLimit: PERSIST_LIMIT },
    "Request lifecycle ledger initialized",
  );
}

export function appendLifecycleRecord(input: LifecycleRecordInput): void {
  if (!isOperational) return;

  const record: LifecycleRecord = {
    id: randomBytes(8).toString("hex"),
    requestId: input.requestId,
    correlationId: input.correlationId,
    method: input.method,
    route: input.route,
    startedAt: input.startedAt,
    finishedAt: input.finishedAt,
    statusCode: input.statusCode,
    latencyMs: input.latencyMs,
    executionBlocked: EXECUTION_BLOCKED,
  };

  if (ledger.length >= MAX_RECORDS) {
    const evicted = ledger.shift();
    if (evicted !== undefined && evicted.latencyMs >= SLOW_REQUEST_THRESHOLD_MS) {
      slowRequestCount = Math.max(0, slowRequestCount - 1);
    }
  }

  ledger.push(record);

  if (record.latencyMs >= SLOW_REQUEST_THRESHOLD_MS) {
    slowRequestCount++;
  }

  flushLifecycleLedger();
}

export function getLifecycleLedgerStatus(): LifecycleLedgerStatus {
  return {
    operational: isOperational,
    subsystemName: "request_lifecycle_ledger",
    recordCount: ledger.length,
    capacity: MAX_RECORDS,
    oldestRecordAt: ledger.length > 0 ? ledger[0].finishedAt : null,
    newestRecordAt: ledger.length > 0 ? ledger[ledger.length - 1].finishedAt : null,
    percentiles: computeLatencyPercentiles(),
    statusDistribution: computeStatusDistribution(),
    slowRequestCount,
    slowThresholdMs: SLOW_REQUEST_THRESHOLD_MS,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    initializedAt,
  };
}

export function getRecentLifecycleRecords(limit: number = 50): LifecycleLedgerResult {
  const clamped = Math.max(1, Math.min(limit, MAX_RECORDS));
  const records = ledger.slice(-clamped);
  return {
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    recordCount: ledger.length,
    capacity: MAX_RECORDS,
    limit: clamped,
    filteredCount: records.length,
    filtersApplied: {},
    records,
    timestamp: new Date().toISOString(),
  };
}

export function getFilteredLifecycleRecords(filter: LifecycleFilter): LifecycleLedgerResult {
  const limit = Math.max(1, Math.min(filter.limit ?? 50, MAX_QUERY_LIMIT));
  const filtersApplied: Record<string, string> = {};

  let records = ledger.slice();

  if (filter.statusCode !== undefined) {
    records = records.filter((r) => r.statusCode === filter.statusCode);
    filtersApplied["statusCode"] = String(filter.statusCode);
  }

  if (filter.route !== undefined) {
    records = records.filter((r) => r.route === filter.route);
    filtersApplied["route"] = filter.route;
  }

  if (filter.method !== undefined) {
    records = records.filter((r) => r.method === filter.method);
    filtersApplied["method"] = filter.method;
  }

  if (filter.minLatencyMs !== undefined) {
    records = records.filter((r) => r.latencyMs >= (filter.minLatencyMs as number));
    filtersApplied["minLatencyMs"] = String(filter.minLatencyMs);
  }

  if (filter.maxLatencyMs !== undefined) {
    records = records.filter((r) => r.latencyMs <= (filter.maxLatencyMs as number));
    filtersApplied["maxLatencyMs"] = String(filter.maxLatencyMs);
  }

  const filteredCount = records.length;
  const sliced = records.slice(-limit);

  return {
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    recordCount: ledger.length,
    capacity: MAX_RECORDS,
    limit,
    filteredCount,
    filtersApplied,
    records: sliced,
    timestamp: new Date().toISOString(),
  };
}
