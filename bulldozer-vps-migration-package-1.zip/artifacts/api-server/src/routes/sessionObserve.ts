// Session Observe Route — Phase 191
// GET /api/auth/sessions
// Read-only diagnostic view of the in-memory session store.
// No session creation, no logout, no cookies, no credentials, no auth enforcement.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { listSessionRecords, getSessionSummary } from "../core/sessionCore";

export function handleSessionObserve(_req: IncomingMessage, res: ServerResponse): void {
  const summary = getSessionSummary();
  const sessions = listSessionRecords();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    persistenceEnabled: false,
    enforcing:          false,
    executionBlocked:   true,
    totalSessions:      summary.totalSessions,
    summary,
    sessions,
  });
}
