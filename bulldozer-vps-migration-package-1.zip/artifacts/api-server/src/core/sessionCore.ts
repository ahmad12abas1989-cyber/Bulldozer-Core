// Session Core — Phase 190
// In-memory, non-enforcing session skeleton. No cookies. No credentials. No JWT.
// No persistence. No auth enforcement. Not wired to request flow.
// Pure module — no init, no subsystem registration, no health checks, no event emission.

import { randomBytes } from "node:crypto";
import type { AuthActorType } from "./authModel";

// ─── Session actor types ────────────────────────────────────────────────────
// Only actor types that may hold Mother Core sessions.
// anonymous and customer sessions are outside Mother Core (Phase 185 blueprint).

export type SessionActorType = Extract<
  AuthActorType,
  "root_operator" | "internal_operator" | "employee" | "service_token"
>;

// ─── TTL map (milliseconds) ─────────────────────────────────────────────────
// Phase 185 blueprint values:
//   root_operator     30 min
//   internal_operator  2 h
//   employee           2 h
//   service_token     24 h (sliding — future enforcement layer extends on activity)

const TTL_MS: Record<SessionActorType, number> = {
  root_operator:     30 * 60 * 1000,
  internal_operator:  2 * 60 * 60 * 1000,
  employee:           2 * 60 * 60 * 1000,
  service_token:     24 * 60 * 60 * 1000,
};

// ─── Constraints ────────────────────────────────────────────────────────────
const MAX_SESSIONS = 500;
const ROOT_OPERATOR_MAX_ACTIVE = 1;

// ─── Types ──────────────────────────────────────────────────────────────────

export type SessionStatus = "active" | "expired";

export interface SessionRecord {
  readonly sessionId:  string;           // server-generated, 16-byte hex
  readonly actorType:  SessionActorType;
  readonly actorId:    string;           // caller-supplied opaque identifier
  readonly auditId:    string;           // required link to auth audit event
  readonly issuedAt:   string;           // ISO 8601, server-generated
  readonly expiresAt:  string;           // ISO 8601, server-generated from TTL
  status:              SessionStatus;    // mutable only via expireSessionRecord()
  readonly metadata:   Readonly<Record<string, string>>;  // no credentials allowed
}

export interface CreateSessionInput {
  readonly actorType: SessionActorType;
  readonly actorId:   string;
  readonly auditId:   string;
  readonly metadata?: Readonly<Record<string, string>>;
}

export type CreateSessionResult =
  | { readonly ok: true;  readonly record: SessionRecord }
  | { readonly ok: false; readonly reason: string };

export interface SessionSummary {
  readonly totalSessions:           number;
  readonly activeSessions:          number;
  readonly expiredSessions:         number;
  readonly byActorType:             Readonly<Record<SessionActorType, number>>;  // active only
  readonly rootOperatorActiveCount: number;
  readonly persistenceEnabled:      false;
  readonly implementationPhase:     "skeleton";
}

// ─── In-memory store ─────────────────────────────────────────────────────────
// Mutable only through the exported functions below.
// Ring buffer: when full, oldest entry is dropped before appending.

const SESSION_STORE: SessionRecord[] = [];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function activeRecords(): SessionRecord[] {
  return SESSION_STORE.filter((r) => r.status === "active");
}

function countActiveByType(actorType: SessionActorType): number {
  return SESSION_STORE.filter((r) => r.status === "active" && r.actorType === actorType).length;
}

// ─── Exports ─────────────────────────────────────────────────────────────────

/**
 * Create a new in-memory session record.
 *
 * - sessionId is always server-generated (randomBytes 16 hex).
 * - issuedAt and expiresAt are always server-generated.
 * - root_operator sessions are capped at ROOT_OPERATOR_MAX_ACTIVE (1).
 *   Returns { ok: false } instead of throwing when the cap is already reached.
 * - No credentials, no secrets, no JWT written to the record.
 * - If the store is at MAX_SESSIONS (500), the oldest entry is dropped first.
 */
export function createSessionRecord(input: CreateSessionInput): CreateSessionResult {
  // root_operator: enforce max-1 active session
  if (
    input.actorType === "root_operator" &&
    countActiveByType("root_operator") >= ROOT_OPERATOR_MAX_ACTIVE
  ) {
    return {
      ok: false,
      reason: "root_operator already has an active session; expire it before creating a new one",
    };
  }

  const now      = new Date();
  const ttlMs    = TTL_MS[input.actorType];
  const issuedAt = now.toISOString();
  const expiresAt = new Date(now.getTime() + ttlMs).toISOString();

  const record: SessionRecord = {
    sessionId:  randomBytes(16).toString("hex"),
    actorType:  input.actorType,
    actorId:    input.actorId,
    auditId:    input.auditId,
    issuedAt,
    expiresAt,
    status:     "active",
    metadata:   input.metadata ?? {},
  };

  // Ring buffer: drop oldest when full
  if (SESSION_STORE.length >= MAX_SESSIONS) {
    SESSION_STORE.shift();
  }

  SESSION_STORE.push(record);
  return { ok: true, record };
}

/**
 * List all session records (active + expired), newest-first.
 * No visibility scoping — caller is responsible for actor-level filtering.
 */
export function listSessionRecords(): SessionRecord[] {
  return SESSION_STORE.slice().reverse();
}

/**
 * Expire an active session by sessionId.
 * Returns the updated record, or null if sessionId is not found or already expired.
 * No-op on unknown or already-expired sessions.
 */
export function expireSessionRecord(sessionId: string): SessionRecord | null {
  const record = SESSION_STORE.find(
    (r) => r.sessionId === sessionId && r.status === "active"
  );
  if (!record) return null;
  record.status = "expired";
  return record;
}

/**
 * Return a summary of the current session store state.
 */
export function getSessionSummary(): SessionSummary {
  const active  = activeRecords();
  const expired = SESSION_STORE.length - active.length;

  const byActorType: Record<SessionActorType, number> = {
    root_operator:     0,
    internal_operator: 0,
    employee:          0,
    service_token:     0,
  };

  for (const r of active) {
    byActorType[r.actorType]++;
  }

  return {
    totalSessions:           SESSION_STORE.length,
    activeSessions:          active.length,
    expiredSessions:         expired,
    byActorType,
    rootOperatorActiveCount: byActorType.root_operator,
    persistenceEnabled:      false,
    implementationPhase:     "skeleton",
  };
}
