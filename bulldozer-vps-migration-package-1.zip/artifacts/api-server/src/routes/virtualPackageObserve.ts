// Virtual Package Observe Route — Phase 225
// GET /api/packages/virtual
// Read-only diagnostic view of the in-memory virtual package registry.
// No package creation, no filesystem writes, no package installation,
// no runtime execution, no deployment packaging, no sandbox execution,
// no external registry access, no plugin install execution.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  listVirtualPackageRecords,
  getVirtualPackageSummary,
} from "../core/virtualPackageCore";

export function handleVirtualPackageObserve(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  const packages = listVirtualPackageRecords();
  const summary  = getVirtualPackageSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    generationEnabled:  false,
    executionEnabled:   false,
    deploymentEnabled:  false,
    persistenceEnabled: false,
    executionBlocked:   true,
    deploymentBlocked:  true,
    totalPackages:      packages.length,
    summary,
    packages,
  });
}
