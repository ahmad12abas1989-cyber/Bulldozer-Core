import { getRuntimeStatus } from "./runtime";
import {
  getMetrics,
  type MemoryMetrics,
  type CpuMetrics,
  type RequestMetrics,
  type ErrorMetrics,
} from "./metrics";
import { getFreezeStatus, type FreezeStatus } from "./freezeDetector";
import { getCrashStatus } from "./crashDetector";
import { getLatestSnapshot } from "./snapshots";
import { getTimelineSize } from "./timeline";
import { getEventStats } from "./eventBus";
import { getWatchdogStatus } from "./watchdog";
import { getRestartSupervisorStatus } from "./restartSupervisor";
import { getPluginSandboxStatus } from "./pluginSandbox";
import { getRuntimeStatePersistenceStatus, isRuntimeStateStale } from "./runtimeState";
import { getRecoveryTrackingStatus } from "./recoveryTracker";
import { getHardeningStatus } from "./hardening";
import { getSecureConfigStatus } from "./secureConfig";
import { getTaskQueueStatus } from "./taskQueue";
import { getTaskEvaluationStatus } from "./taskEvaluation";
import { getTaskPolicyStatus } from "./taskPolicy";
import { getTaskPersistenceStatus } from "./taskPersistence";
import { getQueueOrchestrationStatus, isQueueOrchestratorOperational } from "./queueOrchestrator";
import { getTaskLifecycleStatus } from "./taskLifecycle";
import { getRuntimeSnapshotStatus } from "./runtimeSnapshot";
import { getRuntimeEventBusStatus } from "./runtimeEventBus";
import { getCommandGatewayStatus } from "./commandGateway";
import { getRuntimeStateRegistryStatus } from "./runtimeStateRegistry";
import { getPersistentStoreStatus } from "./persistentStore";
import { getRuntimeDependencyGraphStatus } from "./runtimeDependencyGraph";
import { getCapabilityMatrixStatus } from "./runtimeCapabilityMatrix";
import { getBaselineStatus } from "./baseline";
import { getIdentityAccessStatus } from "./identityAccess";
import { getAccessEnforcementStatus } from "./accessEnforcement";
import { getAuditLogStatus } from "./auditLog";
import { getSessionContextStatus } from "./sessionContext";
import { getLifecycleLedgerStatus } from "./requestLifecycleLedger";
import { getProjectRegistryStatus } from "./projectRegistry";
import { getWidgetRegistryHealthStatus } from "./widgetRegistryHealth";

export type HealthStatus = "healthy" | "degraded" | "unhealthy";
export type CheckStatus = "pass" | "warn" | "fail";

export interface Check {
  name: string;
  status: CheckStatus;
  detail: string;
}

export interface FullHealthReport {
  status: HealthStatus;
  state: string;
  uptimeMs: number;
  memory: MemoryMetrics;
  cpu: CpuMetrics;
  requests: RequestMetrics;
  errors: ErrorMetrics;
  checks: Check[];
  timestamp: string;
}

function runChecks(
  state: string,
  memory: MemoryMetrics,
  cpu: CpuMetrics,
  requests: RequestMetrics,
  errors: ErrorMetrics,
): Check[] {
  const checks: Check[] = [];

  checks.push({
    name: "runtime_state",
    status: state === "ready" ? "pass" : "fail",
    detail: `Runtime state is "${state}"`,
  });

  const memOk = typeof memory.rss === "number" && memory.rss > 0;
  checks.push({
    name: "memory",
    status: memOk ? "pass" : "fail",
    detail: memOk
      ? `RSS ${Math.round(memory.rss / 1024 / 1024)} MB, heap ${Math.round(memory.heapUsed / 1024 / 1024)} MB`
      : "Memory data unavailable",
  });

  const cpuOk = typeof cpu.userMs === "number" && typeof cpu.systemMs === "number";
  checks.push({
    name: "cpu",
    status: cpuOk ? "pass" : "fail",
    detail: cpuOk
      ? `User ${cpu.userMs}ms, system ${cpu.systemMs}ms`
      : "CPU data unavailable",
  });

  const countersOk = typeof requests.total === "number" && typeof errors.total === "number";
  checks.push({
    name: "metrics_counters",
    status: countersOk ? "pass" : "fail",
    detail: countersOk
      ? `${requests.total} requests, ${errors.total} errors tracked`
      : "Metrics counters unavailable",
  });

  const errorTotal = errors.total;
  checks.push({
    name: "error_count",
    status: errorTotal === 0 ? "pass" : errorTotal < 10 ? "warn" : "fail",
    detail: `${errorTotal} handler error${errorTotal === 1 ? "" : "s"} recorded`,
  });

  const freeze = getFreezeStatus();
  const freezeCheckStatus: CheckStatus =
    freeze.status === "normal" ? "pass" : freeze.status === "warning" ? "warn" : "fail";
  checks.push({
    name: "event_loop",
    status: freezeCheckStatus,
    detail:
      freeze.lastCheckAt === null
        ? "Detector not yet started"
        : `Lag ${freeze.lastLagMs}ms, max ${freeze.maxLagMs}ms, freezes ${freeze.freezeCount}`,
  });

  const crash = getCrashStatus();
  const crashCheckStatus: CheckStatus =
    crash.status === "stable" ? "pass" : crash.status === "warning" ? "warn" : "fail";
  checks.push({
    name: "crash_detection",
    status: crashCheckStatus,
    detail:
      crash.status === "stable"
        ? "No crashes or warnings detected"
        : crash.status === "warning"
          ? `${crash.warningCount} process warning${crash.warningCount === 1 ? "" : "s"} recorded`
          : `${crash.crashCount} crash${crash.crashCount === 1 ? "" : "es"} — last: ${crash.lastCrashType}`,
  });

  const latestSnap = getLatestSnapshot();
  checks.push({
    name: "snapshot_system",
    status: latestSnap !== null ? "pass" : "warn",
    detail:
      latestSnap !== null
        ? `Latest snapshot at ${latestSnap.createdAt} (reason: ${latestSnap.reason})`
        : "No snapshot exists yet",
  });

  let timelineCheck: Check;
  try {
    const timelineSize = getTimelineSize();
    timelineCheck = {
      name: "timeline",
      status: timelineSize > 150 ? "warn" : "pass",
      detail:
        timelineSize > 150
          ? `Timeline at ${timelineSize}/200 events (near limit)`
          : `Timeline operational, ${timelineSize} events recorded`,
    };
  } catch {
    timelineCheck = { name: "timeline", status: "fail", detail: "Timeline internal error" };
  }
  checks.push(timelineCheck);

  let eventBusCheck: Check;
  try {
    const stats = getEventStats();
    eventBusCheck = {
      name: "event_bus",
      status: stats.activeSubscriptions > 50 ? "warn" : "pass",
      detail:
        stats.activeSubscriptions > 50
          ? `Event bus overloaded: ${stats.activeSubscriptions} active subscriptions`
          : `Event bus operational, ${stats.totalEmitted} events emitted`,
    };
  } catch {
    eventBusCheck = { name: "event_bus", status: "fail", detail: "Event bus internal error" };
  }
  checks.push(eventBusCheck);

  let watchdogCheck: Check;
  try {
    const wd = getWatchdogStatus();
    watchdogCheck = {
      name: "watchdog",
      status: wd.status === "healthy" ? "pass" : wd.status === "degraded" ? "warn" : "fail",
      detail:
        wd.status === "healthy"
          ? `Watchdog operational, ${wd.degradedCount} degraded observations`
          : `Watchdog degraded: ${wd.degradedCount} observations, ${wd.missedHealthChecks} missed checks`,
    };
  } catch {
    watchdogCheck = { name: "watchdog", status: "fail", detail: "Watchdog internal error" };
  }
  checks.push(watchdogCheck);

  let restartSupervisorCheck: Check;
  try {
    const rs = getRestartSupervisorStatus();
    restartSupervisorCheck = {
      name: "restart_supervisor",
      status: rs.restartRecommended ? "warn" : "pass",
      detail: rs.restartRecommended
        ? `Restart recommended (blocked): ${rs.recommendationReason}`
        : `No restart needed, ${rs.recommendationCount} total recommendations`,
    };
  } catch {
    restartSupervisorCheck = { name: "restart_supervisor", status: "fail", detail: "Restart supervisor internal error" };
  }
  checks.push(restartSupervisorCheck);

  let pluginSandboxCheck: Check;
  try {
    const ps = getPluginSandboxStatus();
    pluginSandboxCheck = {
      name: "plugin_sandbox",
      status: "pass",
      detail: `Sandbox operational, ${ps.registeredPluginCount} plugin(s) registered, all permissions denied`,
    };
  } catch {
    pluginSandboxCheck = { name: "plugin_sandbox", status: "fail", detail: "Plugin sandbox internal error" };
  }
  checks.push(pluginSandboxCheck);

  let runtimeStateCheck: Check;
  try {
    const rs = getRuntimeStatePersistenceStatus();
    const stale = isRuntimeStateStale();
    runtimeStateCheck = {
      name: "runtime_state_persistence",
      status: stale ? "warn" : "pass",
      detail: stale
        ? `Runtime state persistence stale — last saved: ${rs.lastSavedAt ?? "never"}`
        : `Runtime state persisted ${rs.saveCount} time(s), last at ${rs.lastSavedAt}`,
    };
  } catch {
    runtimeStateCheck = { name: "runtime_state_persistence", status: "fail", detail: "Runtime state persistence internal error" };
  }
  checks.push(runtimeStateCheck);

  let recoveryTrackerCheck: Check;
  try {
    const rt = getRecoveryTrackingStatus();
    recoveryTrackerCheck = {
      name: "recovery_tracker",
      status: rt.activeObservationCount > 0 ? "warn" : "pass",
      detail:
        rt.activeObservationCount > 0
          ? `${rt.activeObservationCount} active recovery condition(s): ${Object.entries(rt.severitySummary).filter(([, v]) => v > 0).map(([k, v]) => `${v} ${k}`).join(", ")}`
          : `No active recovery conditions, ${rt.totalTrackedConditions} total tracked`,
    };
  } catch {
    recoveryTrackerCheck = { name: "recovery_tracker", status: "fail", detail: "Recovery tracker internal error" };
  }
  checks.push(recoveryTrackerCheck);

  let hardeningCheck: Check;
  try {
    const h = getHardeningStatus();
    hardeningCheck = {
      name: "hardening",
      status: h.status === "warning" ? "warn" : "pass",
      detail:
        h.status === "clean"
          ? "No violations recorded"
          : h.status === "hardened"
            ? `Hardened — ${h.blockedCount} blocked, ${h.warningCount} warning(s), last: ${h.lastViolationType}`
            : `${h.warningCount} warning(s) recorded, last: ${h.lastViolationType}`,
    };
  } catch {
    hardeningCheck = { name: "hardening", status: "fail", detail: "Hardening internal error" };
  }
  checks.push(hardeningCheck);

  let secureConfigCheck: Check;
  try {
    const sc = getSecureConfigStatus();
    secureConfigCheck = {
      name: "secure_config",
      status: sc.status === "unsafe" ? "fail" : sc.status === "degraded" ? "warn" : "pass",
      detail:
        sc.status === "safe"
          ? `Config safe — env: ${sc.env}, ${Object.keys(sc.safeConfigSummary).length} key(s) present`
          : sc.status === "degraded"
            ? `Config degraded — ${sc.warnings.length} warning(s): ${sc.warnings[0]}`
            : `Config unsafe — ${sc.missingCount} required key(s) missing`,
    };
  } catch {
    secureConfigCheck = { name: "secure_config", status: "fail", detail: "Secure config internal error" };
  }
  checks.push(secureConfigCheck);

  let taskQueueCheck: Check;
  try {
    const tq = getTaskQueueStatus();
    taskQueueCheck = {
      name: "task_queue",
      status: tq.blockedTasks > 0 ? "warn" : "pass",
      detail:
        tq.totalTasks === 0
          ? `Task queue operational — no tasks, execution blocked: ${tq.executionBlocked}`
          : tq.blockedTasks > 0
            ? `${tq.blockedTasks} blocked task(s), ${tq.queuedTasks} queued, execution blocked: ${tq.executionBlocked}`
            : `${tq.queuedTasks} queued task(s), execution blocked: ${tq.executionBlocked}`,
    };
  } catch {
    taskQueueCheck = { name: "task_queue", status: "fail", detail: "Task queue internal error" };
  }
  checks.push(taskQueueCheck);

  let taskEvalCheck: Check;
  try {
    const te = getTaskEvaluationStatus();
    taskEvalCheck = {
      name: "task_evaluation",
      status: te.warningTasks > 0 ? "warn" : "pass",
      detail:
        te.totalEvaluations === 0
          ? `Task evaluation operational — no evaluations yet, execution blocked: ${te.executionStillBlocked}`
          : te.warningTasks > 0
            ? `${te.warningTasks} warning task(s), ${te.approvedTasks} approved, ${te.blockedTasks} blocked, execution blocked: ${te.executionStillBlocked}`
            : `${te.totalEvaluations} evaluated — ${te.approvedTasks} approved, ${te.blockedTasks} blocked, execution blocked: ${te.executionStillBlocked}`,
    };
  } catch {
    taskEvalCheck = { name: "task_evaluation", status: "fail", detail: "Task evaluation internal error" };
  }
  checks.push(taskEvalCheck);

  let taskPolicyCheck: Check;
  try {
    const tp = getTaskPolicyStatus();
    const hasDecisions = tp.blockedCount > 0 || tp.approvalRequiredCount > 0;
    taskPolicyCheck = {
      name: "task_policy",
      status: hasDecisions ? "warn" : "pass",
      detail:
        tp.totalPolicyEvaluations === 0
          ? `Task policy engine operational — ${tp.totalPolicyEvaluations === 0 ? "no evaluations yet" : `${tp.totalPolicyEvaluations} evaluated`}, execution blocked: ${tp.executionBlocked}`
          : hasDecisions
            ? `${tp.blockedCount} blocked, ${tp.approvalRequiredCount} approval-required, ${tp.allowedCount} allowed, execution blocked: ${tp.executionBlocked}`
            : `${tp.totalPolicyEvaluations} evaluated — ${tp.allowedCount} allowed, ${tp.warningCount} warned, execution blocked: ${tp.executionBlocked}`,
    };
  } catch {
    taskPolicyCheck = { name: "task_policy", status: "fail", detail: "Task policy engine internal error" };
  }
  checks.push(taskPolicyCheck);

  let taskPersistenceCheck: Check;
  try {
    const tp = getTaskPersistenceStatus();
    const isStale = tp.lastSavedAt === null && tp.persistedTaskCount === 0;
    taskPersistenceCheck = {
      name: "task_persistence",
      status: !tp.operational ? "fail" : isStale ? "warn" : "pass",
      detail: !tp.operational
        ? `Task persistence not yet operational`
        : isStale
          ? `Task persistence operational — no tasks saved yet, execution blocked: ${tp.executionBlocked}`
          : `${tp.persistedTaskCount} task(s) persisted, last saved: ${tp.lastSavedAt}, execution blocked: ${tp.executionBlocked}`,
    };
  } catch {
    taskPersistenceCheck = { name: "task_persistence", status: "fail", detail: "Task persistence internal error" };
  }
  checks.push(taskPersistenceCheck);

  let queueOrchestratorCheck: Check;
  try {
    const operational = isQueueOrchestratorOperational();
    const qo = getQueueOrchestrationStatus();
    const needsAttention = qo.blockedCount > 0 || qo.approvalRequiredCount > 0;
    queueOrchestratorCheck = {
      name: "queue_orchestration",
      status: !operational ? "fail" : needsAttention ? "warn" : "pass",
      detail: !operational
        ? "Queue orchestrator not yet initialized"
        : needsAttention
          ? `${qo.blockedCount} blocked, ${qo.approvalRequiredCount} approval-required, ${qo.readyCount} ready, execution blocked: ${qo.executionBlocked}`
          : `${qo.totalQueued} task(s) in plan, ${qo.readyCount} ready, orchestration mode: ${qo.orchestrationMode}`,
    };
  } catch {
    queueOrchestratorCheck = { name: "queue_orchestration", status: "fail", detail: "Queue orchestrator internal error" };
  }
  checks.push(queueOrchestratorCheck);

  let taskLifecycleCheck: Check;
  try {
    const tl = getTaskLifecycleStatus();
    taskLifecycleCheck = {
      name: "task_lifecycle",
      status: !tl.operational ? "fail" : tl.rejectedTransitions > 0 ? "warn" : "pass",
      detail: !tl.operational
        ? "Task lifecycle state machine not yet initialized"
        : tl.rejectedTransitions > 0
          ? `${tl.rejectedTransitions} rejected transition(s), ${tl.allowedTransitions} allowed, ${tl.trackedTaskCount} task(s) tracked, execution blocked: ${tl.executionBlocked}`
          : `${tl.trackedTaskCount} task(s) tracked, ${tl.allowedTransitions} transition(s) recorded, execution blocked: ${tl.executionBlocked}`,
    };
  } catch {
    taskLifecycleCheck = { name: "task_lifecycle", status: "fail", detail: "Task lifecycle internal error" };
  }
  checks.push(taskLifecycleCheck);

  let runtimeSnapshotCheck: Check;
  try {
    const rs = getRuntimeSnapshotStatus();
    runtimeSnapshotCheck = {
      name: "runtime_snapshot",
      status: !rs.operational
        ? "fail"
        : rs.retentionNearLimit
          ? "warn"
          : "pass",
      detail: !rs.operational
        ? "Runtime snapshot system not yet initialized"
        : rs.retentionNearLimit
          ? `Retention near limit: ${rs.activeSnapshotCount}/${rs.maxActiveSnapshots} active snapshots, ${rs.archivedSnapshotCount} archived`
          : `${rs.activeSnapshotCount} active snapshot(s), ${rs.archivedSnapshotCount} archived, last: ${rs.lastSnapshotReason ?? "none"}`,
    };
  } catch {
    runtimeSnapshotCheck = {
      name: "runtime_snapshot",
      status: "fail",
      detail: "Runtime snapshot system internal error",
    };
  }
  checks.push(runtimeSnapshotCheck);

  let runtimeEventBusCheck: Check;
  try {
    const reb = getRuntimeEventBusStatus();
    runtimeEventBusCheck = {
      name: "runtime_event_bus",
      status: !reb.operational
        ? "fail"
        : reb.dispatchFailures > 0
          ? "warn"
          : reb.retentionNearLimit
            ? "warn"
            : "pass",
      detail: !reb.operational
        ? "Runtime event bus not yet initialized"
        : reb.dispatchFailures > 0
          ? `Dispatch failure(s) detected: ${reb.dispatchFailures}, ${reb.totalEmitted} events emitted`
          : reb.retentionNearLimit
            ? `Event retention near limit: ${reb.retainedEventCount}/${reb.maxRetainedEvents} events retained`
            : `Runtime event bus operational, ${reb.totalEmitted} events emitted, ${reb.activeSubscriberCount} subscriber(s)`,
    };
  } catch {
    runtimeEventBusCheck = {
      name: "runtime_event_bus",
      status: "fail",
      detail: "Runtime event bus internal error",
    };
  }
  checks.push(runtimeEventBusCheck);

  let commandGatewayCheck: Check;
  try {
    const cg = getCommandGatewayStatus();
    commandGatewayCheck = {
      name: "command_gateway",
      status: !cg.operational
        ? "fail"
        : cg.hasBlockedOrPendingApproval
          ? "warn"
          : "pass",
      detail: !cg.operational
        ? "Command gateway not yet initialized"
        : cg.hasBlockedOrPendingApproval
          ? `Command gateway active — ${cg.totalBlocked} blocked, ${cg.totalApprovalRequired} pending approval, ${cg.totalEvaluated} evaluated`
          : `Command gateway operational — ${cg.totalReceived} received, ${cg.totalEvaluated} evaluated, no blocked commands`,
    };
  } catch {
    commandGatewayCheck = {
      name: "command_gateway",
      status: "fail",
      detail: "Command gateway internal error",
    };
  }
  checks.push(commandGatewayCheck);

  let runtimeStateRegistryCheck: Check;
  try {
    const rsr = getRuntimeStateRegistryStatus();
    const missingCore = !rsr.coreSubsystemsPresent;
    runtimeStateRegistryCheck = {
      name: "runtime_state_registry",
      status: !rsr.operational
        ? "fail"
        : missingCore
          ? "fail"
          : rsr.hasUnhealthySubsystems || rsr.hasDegradedOrBlockedSubsystems
            ? "warn"
            : "pass",
      detail: !rsr.operational
        ? "Runtime state registry not yet initialized"
        : missingCore
          ? "One or more core subsystems missing from registry"
          : rsr.hasUnhealthySubsystems || rsr.hasDegradedOrBlockedSubsystems
            ? `Registry active — ${rsr.registeredSubsystemCount} subsystems registered; ${rsr.degradedCount} degraded, ${rsr.blockedCount} blocked, ${rsr.unhealthyCount} unhealthy`
            : `Registry operational — ${rsr.registeredSubsystemCount} subsystems registered, core subsystems present`,
    };
  } catch {
    runtimeStateRegistryCheck = {
      name: "runtime_state_registry",
      status: "fail",
      detail: "Runtime state registry internal error",
    };
  }
  checks.push(runtimeStateRegistryCheck);

  let dependencyGraphCheck: Check;
  try {
    const dg = getRuntimeDependencyGraphStatus();
    dependencyGraphCheck = {
      name: "runtime_dependency_graph",
      status: !dg.operational
        ? "fail"
        : dg.hasCycles
          ? "warn"
          : "pass",
      detail: !dg.operational
        ? "Runtime dependency graph not yet initialized"
        : dg.hasCycles
          ? `Dependency graph active — ${dg.totalNodes} nodes, ${dg.cycleCount} cycle(s) detected`
          : `Dependency graph operational — ${dg.totalNodes} nodes, max depth ${dg.maxDepth}, no cycles`,
    };
  } catch {
    dependencyGraphCheck = {
      name: "runtime_dependency_graph",
      status: "fail",
      detail: "Runtime dependency graph internal error",
    };
  }
  checks.push(dependencyGraphCheck);

  let capabilityMatrixCheck: Check;
  try {
    const cm = getCapabilityMatrixStatus();
    capabilityMatrixCheck = {
      name: "runtime_capability_matrix",
      status: !cm.operational
        ? "fail"
        : cm.invalidReferenceCount > 0
          ? "warn"
          : "pass",
      detail: !cm.operational
        ? "Runtime capability matrix not yet initialized"
        : cm.invalidReferenceCount > 0
          ? `Capability matrix active — ${cm.totalSubsystems} subsystems, ${cm.invalidReferenceCount} invalid reference(s) detected`
          : `Capability matrix operational — ${cm.totalSubsystems} subsystems, ${cm.totalReadCapabilities} read, ${cm.totalWriteCapabilities} write, ${cm.totalEmitCapabilities} emit capabilities, all valid`,
    };
  } catch {
    capabilityMatrixCheck = {
      name: "runtime_capability_matrix",
      status: "fail",
      detail: "Runtime capability matrix internal error",
    };
  }
  checks.push(capabilityMatrixCheck);

  let baselineLockCheck: Check;
  try {
    const bl = getBaselineStatus();
    baselineLockCheck = {
      name: "baseline_lock",
      status: !bl.operational
        ? "warn"
        : bl.baselineStatus === "intact"
          ? "pass"
          : "warn",
      detail: !bl.operational
        ? "Baseline lock file not loaded — BASELINE_LOCK.json missing or unreadable"
        : bl.baselineStatus === "intact"
          ? `Baseline intact — ${bl.endpointCount.live} endpoints, ${bl.subsystemCount.live} subsystems, ${bl.graphNodeCount.live} nodes, ${bl.cycleCount.live} cycles, ${bl.invalidReferenceCount.live} invalid refs`
          : `Baseline drift detected — endpoints: ${bl.endpointCount.live}/${bl.endpointCount.baseline}, subsystems: ${bl.subsystemCount.live}/${bl.subsystemCount.baseline}, nodes: ${bl.graphNodeCount.live}/${bl.graphNodeCount.baseline}`,
    };
  } catch {
    baselineLockCheck = {
      name: "baseline_lock",
      status: "fail",
      detail: "Baseline lock internal error",
    };
  }
  checks.push(baselineLockCheck);

  let identityAccessCheck: Check;
  try {
    const ia = getIdentityAccessStatus();
    identityAccessCheck = {
      name: "identity_access",
      status: ia.operational ? "pass" : "warn",
      detail: ia.operational
        ? `Identity access operational — ${ia.actorTypes.length} actor types, ${ia.roleCount} roles, execute always blocked`
        : "Identity access foundation not yet initialized",
    };
  } catch {
    identityAccessCheck = {
      name: "identity_access",
      status: "fail",
      detail: "Identity access internal error",
    };
  }
  checks.push(identityAccessCheck);

  let accessEnforcementCheck: Check;
  try {
    const ae = getAccessEnforcementStatus();
    accessEnforcementCheck = {
      name: "access_enforcement",
      status: ae.operational ? "pass" : "warn",
      detail: ae.operational
        ? `Access enforcement operational — ${ae.routePolicyCount} route policies, mode: ${ae.enforcementMode}, execution blocked`
        : "Access enforcement layer not yet initialized",
    };
  } catch {
    accessEnforcementCheck = {
      name: "access_enforcement",
      status: "fail",
      detail: "Access enforcement internal error",
    };
  }
  checks.push(accessEnforcementCheck);

  let auditLogCheck: Check;
  try {
    const al = getAuditLogStatus();
    auditLogCheck = {
      name: "audit_log",
      status: al.operational ? "pass" : "warn",
      detail: al.operational
        ? `Audit log operational — ${al.entryCount}/${al.capacity} entries, newest: ${al.newestEntryAt ?? "none"}`
        : "Audit log not yet initialized",
    };
  } catch {
    auditLogCheck = {
      name: "audit_log",
      status: "fail",
      detail: "Audit log internal error",
    };
  }
  checks.push(auditLogCheck);

  let sessionContextCheck: Check;
  try {
    const sc = getSessionContextStatus();
    sessionContextCheck = {
      name: "session_context",
      status: sc.operational ? "pass" : "warn",
      detail: sc.operational
        ? `Session context operational — ${sc.sessionCount}/${sc.capacity} sessions, role: ${sc.defaultRole}, actorType: ${sc.defaultActorType}`
        : "Session context not yet initialized",
    };
  } catch {
    sessionContextCheck = {
      name: "session_context",
      status: "fail",
      detail: "Session context internal error",
    };
  }
  checks.push(sessionContextCheck);

  let lifecycleLedgerCheck: Check;
  try {
    const ll = getLifecycleLedgerStatus();
    if (!ll.operational) {
      lifecycleLedgerCheck = {
        name: "request_lifecycle_ledger",
        status: "warn",
        detail: "Request lifecycle ledger not yet initialized",
      };
    } else if (ll.slowRequestCount > 0) {
      const p95 = ll.percentiles?.p95 ?? null;
      lifecycleLedgerCheck = {
        name: "request_lifecycle_ledger",
        status: "warn",
        detail: `Slow requests detected — ${ll.slowRequestCount} record(s) exceed ${ll.slowThresholdMs}ms threshold, p95: ${p95 !== null ? p95 + "ms" : "N/A"}, records: ${ll.recordCount}/${ll.capacity}`,
      };
    } else {
      const p50 = ll.percentiles?.p50 ?? null;
      lifecycleLedgerCheck = {
        name: "request_lifecycle_ledger",
        status: "pass",
        detail: `Lifecycle ledger operational — ${ll.recordCount}/${ll.capacity} records, p50: ${p50 !== null ? p50 + "ms" : "N/A"}, slow: 0/${ll.slowThresholdMs}ms`,
      };
    }
  } catch {
    lifecycleLedgerCheck = {
      name: "request_lifecycle_ledger",
      status: "fail",
      detail: "Request lifecycle ledger internal error",
    };
  }
  checks.push(lifecycleLedgerCheck);

  let persistentStoreCheck: Check;
  try {
    const ps = getPersistentStoreStatus();
    if (!ps.operational) {
      persistentStoreCheck = {
        name: "persistent_store",
        status: "fail",
        detail: "Persistent store not initialized",
      };
    } else if (ps.keyCount >= Math.floor(ps.maxKeys * 0.8)) {
      persistentStoreCheck = {
        name: "persistent_store",
        status: "warn",
        detail: `Persistent store nearing capacity — ${ps.keyCount}/${ps.maxKeys} keys`,
      };
    } else {
      persistentStoreCheck = {
        name: "persistent_store",
        status: "pass",
        detail: `Persistent store operational — ${ps.keyCount}/${ps.maxKeys} keys, ${ps.bytesUsed} bytes`,
      };
    }
  } catch {
    persistentStoreCheck = {
      name: "persistent_store",
      status: "fail",
      detail: "Persistent store internal error",
    };
  }
  checks.push(persistentStoreCheck);

  let projectRegistryCheck: Check;
  try {
    const pr = getProjectRegistryStatus();
    projectRegistryCheck = {
      name: "project_registry",
      status: pr.operational ? (pr.atCapacity ? "warn" : "pass") : "warn",
      detail: pr.operational
        ? pr.atCapacity
          ? `Project registry at capacity — ${pr.projectCount}/${pr.maxProjects} projects`
          : `Project registry operational — ${pr.projectCount}/${pr.maxProjects} projects`
        : "Project registry not yet initialized",
    };
  } catch {
    projectRegistryCheck = {
      name: "project_registry",
      status: "fail",
      detail: "Project registry internal error",
    };
  }
  checks.push(projectRegistryCheck);

  let widgetContractRegistryCheck: Check;
  try {
    const wch = getWidgetRegistryHealthStatus();
    widgetContractRegistryCheck = {
      name: "widget_contract_registry",
      status: wch.registryHealthy ? "pass" : "fail",
      detail: wch.detail,
    };
  } catch {
    widgetContractRegistryCheck = {
      name: "widget_contract_registry",
      status: "fail",
      detail: "Widget contract registry health check internal error",
    };
  }
  checks.push(widgetContractRegistryCheck);

  return checks;
}

function computeStatus(checks: Check[]): HealthStatus {
  if (checks.some((c) => c.status === "fail")) return "unhealthy";
  if (checks.some((c) => c.status === "warn")) return "degraded";
  return "healthy";
}

export function getFullHealth(): FullHealthReport {
  const metrics = getMetrics();
  const state = getRuntimeStatus();
  const checks = runChecks(state, metrics.memory, metrics.cpu, metrics.requests, metrics.errors);
  const status = computeStatus(checks);

  return {
    status,
    state,
    uptimeMs: metrics.uptimeMs,
    memory: metrics.memory,
    cpu: metrics.cpu,
    requests: metrics.requests,
    errors: metrics.errors,
    checks,
    timestamp: metrics.timestamp,
  };
}
