// firstRealSandboxWriteActivationCore.ts
// Phase 285 — First Real Sandbox Write Activation Core Skeleton
// In-memory first real-write activation descriptor engine.
// Layer 14 of the write-preparation + preflight stack.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No real writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// activationSwitchEnabled=false compile-time literal — no actual write enabled here.

import type { ActualSandboxWritePreflightRecord }      from "./actualSandboxWritePreflightCore.js";
import type { ActualSandboxWriteApprovalTokenRecord }  from "./actualSandboxWriteApprovalTokenCore.js";
import type { ActualSandboxWriteDryRunRecord }         from "./actualSandboxWriteDryRunCore.js";
import type { ActualSandboxWriteEnablementRecord }     from "./actualSandboxWriteEnablementCore.js";
import type { SandboxWriteCommitGateRecord }           from "./sandboxWriteCommitGateCore.js";
import type { ControlledExecutionRecord }              from "./controlledExecutionCore.js";
import { randomUUID }                                  from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ActivationState = "descriptor_activation_ready";

export type ActivationCheckRule =
  | "preflight_exists"
  | "approval_token_exists"
  | "dry_run_exists"
  | "enablement_record_exists"
  | "commit_gate_exists"
  | "execution_record_exists"
  | "preflight_bound_to_approval"
  | "approval_bound_to_dry_run"
  | "dry_run_bound_to_commit_gate"
  | "rollback_reference_bound"
  | "activation_switch_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface ActivationCheck {
  readonly rule:    ActivationCheckRule;
  readonly pass:    boolean;
  readonly note:    string;
}

export interface ActivationScopeEntry {
  readonly operationIndex:          number;
  readonly targetPath:              string;
  readonly operationType:           string;
  readonly activationPrepared:      true;
  readonly activationSwitchEnabled: false;
  readonly approvalRequired:        true;
  readonly actualWritesEnabled:     false;
  readonly activationNote:          string;
}

export interface ActivationBlockedReason {
  readonly code:    string;
  readonly reason:  string;
  readonly static:  boolean;
}

export interface RollbackActivationReference {
  readonly preflightId:            string;
  readonly approvalTokenId:        string;
  readonly rollbackSnapshotId:     string;
  readonly commitGateId:           string;
  readonly rollbackRequired:       true;
  readonly rollbackDescriptorOnly: true;
  readonly rollbackBound:          boolean;
  readonly rollbackReady:          boolean;
  readonly referenceNote:          string;
}

export interface ActivationReadinessReport {
  readonly activationPrepared:        true;
  readonly activationSwitchEnabled:   false;
  readonly actualWritesEnabled:       false;
  readonly finalWriteAllowed:         false;
  readonly approvalRequired:          true;
  readonly allChecksPass:             boolean;
  readonly blockedReasonCount:        number;
  readonly rollbackReady:             boolean;
  readonly summary:                   string;
}

export interface FirstRealSandboxWriteActivationRecord {
  readonly activationId:                string;
  readonly activationState:             ActivationState;
  readonly approvalRequired:            true;
  readonly activationPrepared:          true;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly finalWriteAllowed:           false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly implementationPhase:         "descriptor_only";
  readonly preflightId:                 string;
  readonly approvalTokenId:             string;
  readonly dryRunId:                    string;
  readonly actualWriteEnablementId:     string;
  readonly commitGateId:                string;
  readonly controlledExecutionId:       string;
  readonly activationChecks:            readonly ActivationCheck[];
  readonly activationScope:             readonly ActivationScopeEntry[];
  readonly activationBlockedReasons:    readonly ActivationBlockedReason[];
  readonly rollbackActivationReference: RollbackActivationReference;
  readonly activationReadinessReport:   ActivationReadinessReport;
  readonly createdAt:                   string;
}

export interface CreateActivationInput {
  readonly preflightRecord:     ActualSandboxWritePreflightRecord;
  readonly approvalTokenRecord: ActualSandboxWriteApprovalTokenRecord;
  readonly dryRunRecord:        ActualSandboxWriteDryRunRecord;
  readonly enablementRecord:    ActualSandboxWriteEnablementRecord;
  readonly commitGateRecord:    SandboxWriteCommitGateRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface FirstRealSandboxWriteActivationSummary {
  readonly total:                    number;
  readonly byState:                  Record<ActivationState, number>;
  readonly activationPrepared:       true;
  readonly activationSwitchEnabled:  false;
  readonly actualWritesEnabled:      false;
  readonly finalWriteAllowed:        false;
  readonly approvalRequired:         true;
  readonly filesystemMutationBlocked: true;
  readonly motherCoreMutationBlocked: true;
  readonly activationState:          ActivationState;
  readonly implementationPhase:      "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstRealSandboxWriteActivationRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateActivationInput): readonly ActivationCheck[] {
  const { preflightRecord, approvalTokenRecord, dryRunRecord, enablementRecord, commitGateRecord, executionRecord } = input;

  const preflightExists      = preflightRecord.preflightId.length > 0;
  const approvalExists       = approvalTokenRecord.approvalTokenId.length > 0;
  const dryRunExists         = dryRunRecord.dryRunId.length > 0;
  const enablementExists     = enablementRecord.actualWriteEnablementId.length > 0;
  const commitGateExists     = commitGateRecord.commitGateId.length > 0;
  const executionExists      = executionRecord.controlledExecutionId.length > 0;
  const preflightBound       = preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId;
  const approvalBound        = approvalTokenRecord.dryRunId === dryRunRecord.dryRunId;
  const dryRunBound          = dryRunRecord.rollbackBindingReport.commitGateId === commitGateRecord.commitGateId;
  const rollbackBound        = approvalTokenRecord.linkedRollbackReference.rollbackBound &&
                               approvalTokenRecord.linkedRollbackReference.rollbackSnapshotId.length > 0;
  const rollbackReady        =
    preflightRecord.preflightReadinessReport.rollbackReady &&
    approvalTokenRecord.approvalReadinessReport.rollbackReady &&
    dryRunRecord.dryRunReadinessReport.rollbackReady &&
    commitGateRecord.commitReadinessReport.rollbackReady;

  return [
    { rule: "preflight_exists",              pass: preflightExists,  note: preflightExists  ? `preflightId=${preflightRecord.preflightId}`            : "preflightRecord.preflightId is empty"                         },
    { rule: "approval_token_exists",         pass: approvalExists,   note: approvalExists   ? `approvalTokenId=${approvalTokenRecord.approvalTokenId}` : "approvalTokenRecord.approvalTokenId is empty"                 },
    { rule: "dry_run_exists",                pass: dryRunExists,     note: dryRunExists     ? `dryRunId=${dryRunRecord.dryRunId}`                      : "dryRunRecord.dryRunId is empty"                               },
    { rule: "enablement_record_exists",      pass: enablementExists, note: enablementExists ? `actualWriteEnablementId=${enablementRecord.actualWriteEnablementId}` : "enablementRecord.actualWriteEnablementId is empty" },
    { rule: "commit_gate_exists",            pass: commitGateExists, note: commitGateExists ? `commitGateId=${commitGateRecord.commitGateId}`           : "commitGateRecord.commitGateId is empty"                       },
    { rule: "execution_record_exists",       pass: executionExists,  note: executionExists  ? `controlledExecutionId=${executionRecord.controlledExecutionId}` : "executionRecord.controlledExecutionId is empty"         },
    {
      rule: "preflight_bound_to_approval",
      pass: preflightBound,
      note: preflightBound
        ? `preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId (${approvalTokenRecord.approvalTokenId})`
        : `preflight-approval mismatch: preflight.approvalTokenId=${preflightRecord.approvalTokenId} vs token.approvalTokenId=${approvalTokenRecord.approvalTokenId}`,
    },
    {
      rule: "approval_bound_to_dry_run",
      pass: approvalBound,
      note: approvalBound
        ? `approvalTokenRecord.dryRunId === dryRunRecord.dryRunId (${dryRunRecord.dryRunId})`
        : `approval-dryRun mismatch: token.dryRunId=${approvalTokenRecord.dryRunId} vs dryRun.dryRunId=${dryRunRecord.dryRunId}`,
    },
    {
      rule: "dry_run_bound_to_commit_gate",
      pass: dryRunBound,
      note: dryRunBound
        ? `dryRunRecord.rollbackBindingReport.commitGateId === commitGateRecord.commitGateId (${commitGateRecord.commitGateId})`
        : `dryRun-commitGate mismatch: dryRun.bindingReport.commitGateId=${dryRunRecord.rollbackBindingReport.commitGateId} vs commitGate.commitGateId=${commitGateRecord.commitGateId}`,
    },
    {
      rule: "rollback_reference_bound",
      pass: rollbackBound,
      note: rollbackBound
        ? `linkedRollbackReference.rollbackBound=true, rollbackSnapshotId=${approvalTokenRecord.linkedRollbackReference.rollbackSnapshotId}`
        : "linkedRollbackReference.rollbackBound=false or rollbackSnapshotId is empty",
    },
    {
      rule: "activation_switch_still_disabled",
      pass: true,
      note: "activationSwitchEnabled=false — compile-time literal; no execution phase has enabled the activation switch",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: rollbackReady,
      note: rollbackReady
        ? "combined rollbackReady=true across preflight + approvalToken + dryRun + commitGate records"
        : "combined rollbackReady=false — one or more upstream records report rollbackReady=false",
    },
  ] as const;
}

function buildScope(input: CreateActivationInput): readonly ActivationScopeEntry[] {
  return input.approvalTokenRecord.approvalScope.map((entry, idx) => ({
    operationIndex:          idx,
    targetPath:              entry.targetPath,
    operationType:           entry.operationType,
    activationPrepared:      true   as const,
    activationSwitchEnabled: false  as const,
    approvalRequired:        true   as const,
    actualWritesEnabled:     false  as const,
    activationNote:          `operation_${idx}: activation descriptor prepared; switch disabled; approval still required`,
  }));
}

function buildBlockedReasons(checks: readonly ActivationCheck[]): readonly ActivationBlockedReason[] {
  const staticReasons: ActivationBlockedReason[] = [
    { code: "activation_switch_disabled", reason: "activationSwitchEnabled=false — compile-time literal; an explicit activation phase must set this to true", static: true },
    { code: "approval_required",          reason: "approvalRequired=true — explicit operator approval is required before any write can proceed",               static: true },
    { code: "actual_writes_disabled",     reason: "actualWritesEnabled=false — compile-time literal across all 14 sealed write-preparation layers",            static: true },
  ];
  const dynamicReasons: ActivationBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildRollbackActivationReference(input: CreateActivationInput, rollbackReady: boolean): RollbackActivationReference {
  const { preflightRecord, approvalTokenRecord, commitGateRecord } = input;
  return {
    preflightId:            preflightRecord.preflightId,
    approvalTokenId:        approvalTokenRecord.approvalTokenId,
    rollbackSnapshotId:     approvalTokenRecord.linkedRollbackReference.rollbackSnapshotId,
    commitGateId:           commitGateRecord.commitGateId,
    rollbackRequired:       true,
    rollbackDescriptorOnly: true,
    rollbackBound:          approvalTokenRecord.linkedRollbackReference.rollbackBound,
    rollbackReady,
    referenceNote:          "rollback anchored to approval token's linked rollback reference and commit gate; descriptor-only; no filesystem mutation enabled",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createActivationRecord(input: CreateActivationInput): FirstRealSandboxWriteActivationRecord {
  const { preflightRecord, approvalTokenRecord, dryRunRecord, enablementRecord, commitGateRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackReady =
    preflightRecord.preflightReadinessReport.rollbackReady &&
    approvalTokenRecord.approvalReadinessReport.rollbackReady &&
    dryRunRecord.dryRunReadinessReport.rollbackReady &&
    commitGateRecord.commitReadinessReport.rollbackReady;

  const allChecksPass        = checks.every((c) => c.pass);
  const scope                = buildScope(input);
  const blockedReasons       = buildBlockedReasons(checks);
  const rollbackRef          = buildRollbackActivationReference(input, rollbackReady);

  const activationReadinessReport: ActivationReadinessReport = {
    activationPrepared:      true,
    activationSwitchEnabled: false,
    actualWritesEnabled:     false,
    finalWriteAllowed:       false,
    approvalRequired:        true,
    allChecksPass,
    blockedReasonCount:      blockedReasons.length,
    rollbackReady,
    summary: `activationState=descriptor_activation_ready; activationSwitchEnabled=false; actualWritesEnabled=false; finalWriteAllowed=false; allChecksPass=${allChecksPass}; rollbackReady=${rollbackReady}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstRealSandboxWriteActivationRecord = {
    activationId:                randomUUID(),
    activationState:             "descriptor_activation_ready",
    approvalRequired:            true,
    activationPrepared:          true,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    finalWriteAllowed:           false,
    filesystemMutationBlocked:   true,
    motherCoreMutationBlocked:   true,
    vaultMutationBlocked:        true,
    shellBlocked:                true,
    networkBlocked:              true,
    implementationPhase:         "descriptor_only",
    preflightId:                 preflightRecord.preflightId,
    approvalTokenId:             approvalTokenRecord.approvalTokenId,
    dryRunId:                    dryRunRecord.dryRunId,
    actualWriteEnablementId:     enablementRecord.actualWriteEnablementId,
    commitGateId:                commitGateRecord.commitGateId,
    controlledExecutionId:       executionRecord.controlledExecutionId,
    activationChecks:            checks,
    activationScope:             scope,
    activationBlockedReasons:    blockedReasons,
    rollbackActivationReference: rollbackRef,
    activationReadinessReport,
    createdAt:                   new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listActivationRecords(): readonly FirstRealSandboxWriteActivationRecord[] {
  return _store.slice();
}

export function getActivationSummary(): FirstRealSandboxWriteActivationSummary {
  return {
    total:                     _store.length,
    byState:                   { descriptor_activation_ready: _store.length },
    activationPrepared:        true,
    activationSwitchEnabled:   false,
    actualWritesEnabled:       false,
    finalWriteAllowed:         false,
    approvalRequired:          true,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    activationState:           "descriptor_activation_ready",
    implementationPhase:       "descriptor_only",
  };
}
