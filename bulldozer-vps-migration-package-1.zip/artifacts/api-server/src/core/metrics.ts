import { getRuntimeStatus } from "./runtime";

export interface MemoryMetrics {
  rss: number;
  heapUsed: number;
  heapTotal: number;
  external: number;
}

export interface CpuMetrics {
  userMs: number;
  systemMs: number;
}

export interface RequestMetrics {
  total: number;
  lastAt: string | null;
}

export interface ErrorMetrics {
  total: number;
  lastAt: string | null;
}

export interface MetricsSnapshot {
  state: string;
  uptimeMs: number;
  memory: MemoryMetrics;
  cpu: CpuMetrics;
  requests: RequestMetrics;
  errors: ErrorMetrics;
  timestamp: string;
}

let requestCount = 0;
let errorCount = 0;
let lastRequestAt: string | null = null;
let lastErrorAt: string | null = null;

export function incrementRequests(): void {
  requestCount++;
  lastRequestAt = new Date().toISOString();
}

export function incrementErrors(): void {
  errorCount++;
  lastErrorAt = new Date().toISOString();
}

export function getMetrics(): MetricsSnapshot {
  const mem = process.memoryUsage();
  const cpu = process.cpuUsage();

  return {
    state: getRuntimeStatus(),
    uptimeMs: Math.round(process.uptime() * 1000),
    memory: {
      rss: mem.rss,
      heapUsed: mem.heapUsed,
      heapTotal: mem.heapTotal,
      external: mem.external,
    },
    cpu: {
      userMs: Math.round(cpu.user / 1000),
      systemMs: Math.round(cpu.system / 1000),
    },
    requests: {
      total: requestCount,
      lastAt: lastRequestAt,
    },
    errors: {
      total: errorCount,
      lastAt: lastErrorAt,
    },
    timestamp: new Date().toISOString(),
  };
}
