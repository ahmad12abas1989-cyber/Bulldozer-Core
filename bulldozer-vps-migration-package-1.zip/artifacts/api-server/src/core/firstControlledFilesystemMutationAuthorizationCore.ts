// firstControlledFilesystemMutationAuthorizationCore.ts
// Phase 344 — First Controlled Filesystem Mutation Authorization Descriptor Core Skeleton
// In-memory first controlled filesystem mutation authorization descriptor engine.
// Layer 36 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply + mutation-surface +
//   filesystem-mutation-enablement + filesystem-mutation-gate +
//   filesystem-mutation-permit stack.
// Defines the first controlled filesystem mutation authorization descriptor.
// Binds authorization to filesystem mutation permit and to gate/enablement/surface/apply chain.
// Preserves sandbox-approved-only target scope from layers 24–35 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem mutation. No shell execution. No network access.
// No vault access. No Mother Core mutation.
// filesystemMutationAuthorizationEnabled=false — authorization has not been activated.
// filesystemMutationAuthorizationPrepared=true — descriptor-readiness established for a future
//   first controlled filesystem mutation authorization activation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstControlledFilesystemMutationPermitRecord }       from "./firstControlledFilesystemMutationPermitCore.js";
import type { FirstControlledFilesystemMutationGateRecord }         from "./firstControlledFilesystemMutationGateCore.js";
import type { ControlledFilesystemMutationEnablementRecord }        from "./controlledFilesystemMutationEnablementCore.js";
import type { FirstActualSandboxMutationSurfaceRecord }             from "./firstActualSandboxMutationSurfaceCore.js";
import type { FirstActualSandboxMutationApplyRecord }               from "./firstActualSandboxMutationApplyCore.js";
import type { ControlledExecutionRecord }                           from "./controlledExecutionCore.js";
import { randomUUID }                                               from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FilesystemMutationAuthorizationState =
  "descriptor_filesystem_mutation_authorization_pending";

export type FilesystemMutationAuthorizationCheckRule =
  | "filesystem_mutation_permit_exists"
  | "filesystem_mutation_gate_exists"
  | "filesystem_mutation_enablement_exists"
  | "mutation_surface_exists"
  | "mutation_apply_exists"
  | "execution_record_exists"
  | "filesystem_mutation_permit_bound_to_gate"
  | "filesystem_mutation_gate_bound_to_enablement"
  | "filesystem_mutation_enablement_bound_to_surface"
  | "mutation_surface_bound_to_apply"
  | "filesystem_mutation_authorization_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface FilesystemMutationAuthorizationCheck {
  readonly rule: FilesystemMutationAuthorizationCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface FilesystemMutationAuthorizationBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface FilesystemMutationAuthorizationPlanEntry {
  readonly entryId:                               string;
  readonly operationType:                         "descriptor_filesystem_mutation_authorization_planned";
  readonly targetScope:                           "sandbox_approved_only";
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly mutationBlocked:                       true;
  readonly note:                                  string;
}

export interface LinkedFilesystemMutationAuthorizationReference {
  readonly filesystemMutationPermitId:             string;
  readonly filesystemMutationGateId:               string;
  readonly filesystemMutationEnablementId:         string;
  readonly mutationSurfaceId:                      string;
  readonly rollbackSnapshotId:                     string;
  readonly filesystemMutationAuthorizationPrepared: true;
  readonly filesystemMutationAuthorizationEnabled:  false;
  readonly filesystemMutationPermitEnabled:         false;
  readonly filesystemMutationGateEnabled:           false;
  readonly filesystemMutationEnablementEnabled:     false;
  readonly mutationSurfaceEnabled:                  false;
  readonly actualWritesEnabled:                     false;
  readonly rollbackChainValid:                      boolean;
  readonly referenceNote:                           string;
}

export interface FilesystemMutationAuthorizationReadinessReport {
  readonly filesystemMutationAuthorizationPrepared: true;
  readonly filesystemMutationAuthorizationEnabled:  false;
  readonly filesystemMutationPermitEnabled:         false;
  readonly filesystemMutationGateEnabled:           false;
  readonly filesystemMutationEnablementEnabled:     false;
  readonly mutationSurfaceEnabled:                  false;
  readonly mutationApplyEnabled:                    false;
  readonly mutationCommitEnabled:                   false;
  readonly mutationExecutorEnabled:                 false;
  readonly commitExecutionGateEnabled:              false;
  readonly sandboxWriteCommitEnabled:               false;
  readonly runtimeWriteExecutorEnabled:             false;
  readonly writeExecutionGateEnabled:               false;
  readonly scopedActivationEnabled:                 false;
  readonly writePermissionEnabled:                  false;
  readonly mutationSwitchEnabled:                   false;
  readonly guardedWriteEnabled:                     false;
  readonly actualWritesEnabled:                     false;
  readonly realWritesEnabled:                       false;
  readonly approvalRequired:                        true;
  readonly allChecksPass:                           boolean;
  readonly blockedReasonCount:                      number;
  readonly rollbackChainValid:                      boolean;
  readonly targetScope:                             "sandbox_approved_only";
  readonly summary:                                 string;
}

export interface FirstControlledFilesystemMutationAuthorizationRecord {
  readonly filesystemMutationAuthorizationId:             string;
  readonly filesystemMutationAuthorizationState:          FilesystemMutationAuthorizationState;
  readonly approvalRequired:                              true;
  readonly filesystemMutationAuthorizationPrepared:       true;
  readonly filesystemMutationAuthorizationEnabled:        false;
  readonly filesystemMutationPermitEnabled:               false;
  readonly filesystemMutationGateEnabled:                 false;
  readonly filesystemMutationEnablementEnabled:           false;
  readonly mutationSurfaceEnabled:                        false;
  readonly mutationApplyEnabled:                          false;
  readonly actualWritesEnabled:                           false;
  readonly filesystemMutationBlocked:                     true;
  readonly motherCoreMutationBlocked:                     true;
  readonly vaultMutationBlocked:                          true;
  readonly shellBlocked:                                  true;
  readonly networkBlocked:                                true;
  readonly targetScope:                                   "sandbox_approved_only";
  readonly implementationPhase:                           "descriptor_only";
  readonly filesystemMutationPermitId:                    string;
  readonly filesystemMutationGateId:                      string;
  readonly filesystemMutationEnablementId:                string;
  readonly mutationSurfaceId:                             string;
  readonly mutationApplyId:                               string;
  readonly controlledExecutionId:                         string;
  readonly filesystemMutationAuthorizationPlan:           readonly FilesystemMutationAuthorizationPlanEntry[];
  readonly filesystemMutationAuthorizationChecks:         readonly FilesystemMutationAuthorizationCheck[];
  readonly filesystemMutationAuthorizationBlockedReasons: readonly FilesystemMutationAuthorizationBlockedReason[];
  readonly filesystemMutationAuthorizationReadinessReport: FilesystemMutationAuthorizationReadinessReport;
  readonly linkedFilesystemMutationAuthorizationReference: LinkedFilesystemMutationAuthorizationReference;
  readonly createdAt:                                     string;
}

export interface CreateFirstControlledFilesystemMutationAuthorizationInput {
  readonly permitRecord:          FirstControlledFilesystemMutationPermitRecord;
  readonly gateRecord:            FirstControlledFilesystemMutationGateRecord;
  readonly enablementRecord:      ControlledFilesystemMutationEnablementRecord;
  readonly mutationSurfaceRecord: FirstActualSandboxMutationSurfaceRecord;
  readonly mutationApplyRecord:   FirstActualSandboxMutationApplyRecord;
  readonly executionRecord:       ControlledExecutionRecord;
}

export interface FirstControlledFilesystemMutationAuthorizationSummary {
  readonly total:                                       number;
  readonly byState:                                     Record<FilesystemMutationAuthorizationState, number>;
  readonly filesystemMutationAuthorizationPrepared:     true;
  readonly filesystemMutationAuthorizationEnabled:      false;
  readonly filesystemMutationPermitEnabled:             false;
  readonly filesystemMutationGateEnabled:               false;
  readonly filesystemMutationEnablementEnabled:         false;
  readonly mutationSurfaceEnabled:                      false;
  readonly mutationApplyEnabled:                        false;
  readonly actualWritesEnabled:                         false;
  readonly approvalRequired:                            true;
  readonly filesystemMutationBlocked:                   true;
  readonly motherCoreMutationBlocked:                   true;
  readonly targetScope:                                 "sandbox_approved_only";
  readonly filesystemMutationAuthorizationState:        FilesystemMutationAuthorizationState;
  readonly implementationPhase:                         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstControlledFilesystemMutationAuthorizationRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstControlledFilesystemMutationAuthorizationInput,
): readonly FilesystemMutationAuthorizationCheck[] {
  const { permitRecord, gateRecord, enablementRecord, mutationSurfaceRecord, mutationApplyRecord, executionRecord } = input;

  const permitExists      = permitRecord.filesystemMutationPermitId.length > 0;
  const gateExists        = gateRecord.filesystemMutationGateId.length > 0;
  const enablementExists  = enablementRecord.filesystemMutationEnablementId.length > 0;
  const surfaceExists     = mutationSurfaceRecord.mutationSurfaceId.length > 0;
  const applyExists       = mutationApplyRecord.mutationApplyId.length > 0;
  const ctrlExists        = executionRecord.controlledExecutionId.length > 0;

  const permitBound       = permitRecord.filesystemMutationGateId === gateRecord.filesystemMutationGateId;
  const gateBound         = gateRecord.filesystemMutationEnablementId === enablementRecord.filesystemMutationEnablementId;
  const enablementBound   = enablementRecord.mutationSurfaceId === mutationSurfaceRecord.mutationSurfaceId;
  const surfaceBound      = mutationSurfaceRecord.mutationApplyId === mutationApplyRecord.mutationApplyId;

  return [
    {
      rule: "filesystem_mutation_permit_exists",
      pass: permitExists,
      note: permitExists
        ? `filesystemMutationPermitId=${permitRecord.filesystemMutationPermitId}`
        : "permitRecord.filesystemMutationPermitId is empty",
    },
    {
      rule: "filesystem_mutation_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `filesystemMutationGateId=${gateRecord.filesystemMutationGateId}`
        : "gateRecord.filesystemMutationGateId is empty",
    },
    {
      rule: "filesystem_mutation_enablement_exists",
      pass: enablementExists,
      note: enablementExists
        ? `filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`
        : "enablementRecord.filesystemMutationEnablementId is empty",
    },
    {
      rule: "mutation_surface_exists",
      pass: surfaceExists,
      note: surfaceExists
        ? `mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`
        : "mutationSurfaceRecord.mutationSurfaceId is empty",
    },
    {
      rule: "mutation_apply_exists",
      pass: applyExists,
      note: applyExists
        ? `mutationApplyId=${mutationApplyRecord.mutationApplyId}`
        : "mutationApplyRecord.mutationApplyId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "filesystem_mutation_permit_bound_to_gate",
      pass: permitBound,
      note: permitBound
        ? `permitRecord.filesystemMutationGateId === gateRecord.filesystemMutationGateId (${gateRecord.filesystemMutationGateId})`
        : `permit/gate mismatch: permit.filesystemMutationGateId=${permitRecord.filesystemMutationGateId} vs gate.filesystemMutationGateId=${gateRecord.filesystemMutationGateId}`,
    },
    {
      rule: "filesystem_mutation_gate_bound_to_enablement",
      pass: gateBound,
      note: gateBound
        ? `gateRecord.filesystemMutationEnablementId === enablementRecord.filesystemMutationEnablementId (${enablementRecord.filesystemMutationEnablementId})`
        : `gate/enablement mismatch: gate.filesystemMutationEnablementId=${gateRecord.filesystemMutationEnablementId} vs enablement.filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`,
    },
    {
      rule: "filesystem_mutation_enablement_bound_to_surface",
      pass: enablementBound,
      note: enablementBound
        ? `enablementRecord.mutationSurfaceId === mutationSurfaceRecord.mutationSurfaceId (${mutationSurfaceRecord.mutationSurfaceId})`
        : `enablement/surface mismatch: enablement.mutationSurfaceId=${enablementRecord.mutationSurfaceId} vs surface.mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`,
    },
    {
      rule: "mutation_surface_bound_to_apply",
      pass: surfaceBound,
      note: surfaceBound
        ? `mutationSurfaceRecord.mutationApplyId === mutationApplyRecord.mutationApplyId (${mutationApplyRecord.mutationApplyId})`
        : `surface/apply mismatch: surface.mutationApplyId=${mutationSurfaceRecord.mutationApplyId} vs apply.mutationApplyId=${mutationApplyRecord.mutationApplyId}`,
    },
    {
      rule: "filesystem_mutation_authorization_still_disabled",
      pass: true,
      note: "filesystemMutationAuthorizationEnabled=false — compile-time literal; no filesystem mutation authorization activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "filesystemMutationAuthorizationState=descriptor_filesystem_mutation_authorization_pending — output is a descriptor only; filesystem mutation authorization is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly FilesystemMutationAuthorizationCheck[],
): readonly FilesystemMutationAuthorizationBlockedReason[] {
  const staticReasons: FilesystemMutationAuthorizationBlockedReason[] = [
    { code: "filesystem_mutation_authorization_disabled", reason: "filesystemMutationAuthorizationEnabled=false — compile-time literal; an explicit first controlled filesystem mutation authorization activation phase must activate the authorization before any sandbox target can receive filesystem writes",                                                                                                                                                                                                                                                                                                                                                   static: true },
    { code: "approval_required",                          reason: "approvalRequired=true — explicit operator approval is required before the filesystem mutation authorization can be activated",                                                                                                                                                                                                                                                                                                                                                                                                                                                                  static: true },
    { code: "actual_writes_disabled",                     reason: "actualWritesEnabled=false — compile-time literal across all 36 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, mutation-apply, mutation-surface, filesystem-mutation-enablement, filesystem-mutation-gate, and filesystem-mutation-permit layers", static: true },
  ];
  const dynamicReasons: FilesystemMutationAuthorizationBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedAuthorizationReference(
  input: CreateFirstControlledFilesystemMutationAuthorizationInput,
  rollbackChainValid: boolean,
): LinkedFilesystemMutationAuthorizationReference {
  const { permitRecord, gateRecord, enablementRecord, mutationSurfaceRecord } = input;
  return {
    filesystemMutationPermitId:              permitRecord.filesystemMutationPermitId,
    filesystemMutationGateId:                gateRecord.filesystemMutationGateId,
    filesystemMutationEnablementId:          enablementRecord.filesystemMutationEnablementId,
    mutationSurfaceId:                       mutationSurfaceRecord.mutationSurfaceId,
    rollbackSnapshotId:                      permitRecord.linkedFilesystemMutationPermitReference.rollbackSnapshotId,
    filesystemMutationAuthorizationPrepared: true,
    filesystemMutationAuthorizationEnabled:  false,
    filesystemMutationPermitEnabled:         false,
    filesystemMutationGateEnabled:           false,
    filesystemMutationEnablementEnabled:     false,
    mutationSurfaceEnabled:                  false,
    actualWritesEnabled:                     false,
    rollbackChainValid,
    referenceNote: "linked filesystem mutation authorization reference sources rollbackSnapshotId from permitRecord.linkedFilesystemMutationPermitReference; filesystem mutation authorization disabled; filesystem mutation permit disabled; filesystem mutation gate disabled; filesystem mutation enablement disabled; mutation surface disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstControlledFilesystemMutationAuthorizationRecord(
  input: CreateFirstControlledFilesystemMutationAuthorizationInput,
): FirstControlledFilesystemMutationAuthorizationRecord {
  const { permitRecord, gateRecord, enablementRecord, mutationSurfaceRecord, mutationApplyRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = permitRecord.filesystemMutationPermitReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedAuthorizationReference(input, rollbackChainValid);

  const filesystemMutationAuthorizationPlan: FilesystemMutationAuthorizationPlanEntry[] = [
    {
      entryId:                                randomUUID(),
      operationType:                          "descriptor_filesystem_mutation_authorization_planned",
      targetScope:                            "sandbox_approved_only",
      filesystemMutationAuthorizationEnabled: false,
      mutationBlocked:                        true,
      note:                                   "filesystem mutation authorization planned in descriptor-only mode; targetScope=sandbox_approved_only; filesystemMutationAuthorizationEnabled=false; filesystemMutationBlocked=true; first controlled filesystem mutation authorization activation phase required to activate",
    },
  ];

  const filesystemMutationAuthorizationReadinessReport: FilesystemMutationAuthorizationReadinessReport = {
    filesystemMutationAuthorizationPrepared:  true,
    filesystemMutationAuthorizationEnabled:   false,
    filesystemMutationPermitEnabled:          false,
    filesystemMutationGateEnabled:            false,
    filesystemMutationEnablementEnabled:      false,
    mutationSurfaceEnabled:                   false,
    mutationApplyEnabled:                     false,
    mutationCommitEnabled:                    false,
    mutationExecutorEnabled:                  false,
    commitExecutionGateEnabled:               false,
    sandboxWriteCommitEnabled:                false,
    runtimeWriteExecutorEnabled:              false,
    writeExecutionGateEnabled:                false,
    scopedActivationEnabled:                  false,
    writePermissionEnabled:                   false,
    mutationSwitchEnabled:                    false,
    guardedWriteEnabled:                      false,
    actualWritesEnabled:                      false,
    realWritesEnabled:                        false,
    approvalRequired:                         true,
    allChecksPass,
    blockedReasonCount:                       blockedReasons.length,
    rollbackChainValid,
    targetScope:                              "sandbox_approved_only",
    summary: `filesystemMutationAuthorizationState=descriptor_filesystem_mutation_authorization_pending; filesystemMutationAuthorizationEnabled=false; filesystemMutationPermitEnabled=false; filesystemMutationGateEnabled=false; filesystemMutationEnablementEnabled=false; mutationSurfaceEnabled=false; mutationApplyEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstControlledFilesystemMutationAuthorizationRecord = {
    filesystemMutationAuthorizationId:              randomUUID(),
    filesystemMutationAuthorizationState:           "descriptor_filesystem_mutation_authorization_pending",
    approvalRequired:                               true,
    filesystemMutationAuthorizationPrepared:        true,
    filesystemMutationAuthorizationEnabled:         false,
    filesystemMutationPermitEnabled:                false,
    filesystemMutationGateEnabled:                  false,
    filesystemMutationEnablementEnabled:            false,
    mutationSurfaceEnabled:                         false,
    mutationApplyEnabled:                           false,
    actualWritesEnabled:                            false,
    filesystemMutationBlocked:                      true,
    motherCoreMutationBlocked:                      true,
    vaultMutationBlocked:                           true,
    shellBlocked:                                   true,
    networkBlocked:                                 true,
    targetScope:                                    "sandbox_approved_only",
    implementationPhase:                            "descriptor_only",
    filesystemMutationPermitId:                     permitRecord.filesystemMutationPermitId,
    filesystemMutationGateId:                       gateRecord.filesystemMutationGateId,
    filesystemMutationEnablementId:                 enablementRecord.filesystemMutationEnablementId,
    mutationSurfaceId:                              mutationSurfaceRecord.mutationSurfaceId,
    mutationApplyId:                                mutationApplyRecord.mutationApplyId,
    controlledExecutionId:                          executionRecord.controlledExecutionId,
    filesystemMutationAuthorizationPlan,
    filesystemMutationAuthorizationChecks:          checks,
    filesystemMutationAuthorizationBlockedReasons:  blockedReasons,
    filesystemMutationAuthorizationReadinessReport,
    linkedFilesystemMutationAuthorizationReference: linkedRef,
    createdAt:                                      new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstControlledFilesystemMutationAuthorizationRecords(): readonly FirstControlledFilesystemMutationAuthorizationRecord[] {
  return _store.slice();
}

export function getFirstControlledFilesystemMutationAuthorizationSummary(): FirstControlledFilesystemMutationAuthorizationSummary {
  return {
    total:                                        _store.length,
    byState:                                      { descriptor_filesystem_mutation_authorization_pending: _store.length },
    filesystemMutationAuthorizationPrepared:       true,
    filesystemMutationAuthorizationEnabled:        false,
    filesystemMutationPermitEnabled:               false,
    filesystemMutationGateEnabled:                 false,
    filesystemMutationEnablementEnabled:           false,
    mutationSurfaceEnabled:                        false,
    mutationApplyEnabled:                          false,
    actualWritesEnabled:                           false,
    approvalRequired:                              true,
    filesystemMutationBlocked:                     true,
    motherCoreMutationBlocked:                     true,
    targetScope:                                   "sandbox_approved_only",
    filesystemMutationAuthorizationState:          "descriptor_filesystem_mutation_authorization_pending",
    implementationPhase:                           "descriptor_only",
  };
}
