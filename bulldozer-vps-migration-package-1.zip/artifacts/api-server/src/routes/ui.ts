import type { IncomingMessage, ServerResponse } from "node:http";
import { buildUIShellHtml }       from "../core/uiShell";
import { buildUIOverviewHtml }    from "../core/uiOverviewPage";
import { buildDashboardPageHtml } from "../core/uiDashboardPages";

function sendHtml(res: ServerResponse, html: string): void {
  const buf = Buffer.from(html, "utf8");
  res.writeHead(200, {
    "Content-Type": "text/html; charset=utf-8",
    "Content-Length": String(buf.byteLength),
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'",
    "X-Execution-Blocked": "true",
    "X-Read-Only": "true",
  });
  res.end(buf);
}

export function handleUIShell(_req: IncomingMessage, res: ServerResponse): void {
  sendHtml(res, buildUIShellHtml());
}

export function handleUIOverview(_req: IncomingMessage, res: ServerResponse): void {
  sendHtml(res, buildUIOverviewHtml());
}

export function handleUIGovernance(_req: IncomingMessage, res: ServerResponse): void {
  sendHtml(res, buildDashboardPageHtml("governance"));
}

export function handleUIObservation(_req: IncomingMessage, res: ServerResponse): void {
  sendHtml(res, buildDashboardPageHtml("observation"));
}

export function handleUIDiagnostics(_req: IncomingMessage, res: ServerResponse): void {
  sendHtml(res, buildDashboardPageHtml("diagnostics"));
}

export function handleUIComparison(_req: IncomingMessage, res: ServerResponse): void {
  sendHtml(res, buildDashboardPageHtml("comparison"));
}
