// Auth Observe Status — Phase 183
// GET /api/auth/observe-status
// Read-only diagnostic view of the observe-only auth stack.
// No enforcement, no blocking, no sessions, no mutation.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { getAuthModelStatus } from "../core/authModel";
import { getAuthRouteMapSummary } from "../core/authRouteMap";
import { composeAuthDecision, getAuthComposerStatus } from "../core/authDecisionComposer";

interface AuthModuleStatus {
  name: string;
  observeOnly: true;
  enforcing: false;
  implementationPhase: string;
  note: string;
}

interface AuthObserveStatusResponse {
  generatedAt: string;
  observeOnly: true;
  authStackReady: true;
  executionBlocked: true;
  modules: {
    authModel: AuthModuleStatus;
    authRouteMap: AuthModuleStatus;
    authDecisionComposer: AuthModuleStatus;
  };
  sampleDecisions: ReturnType<typeof composeAuthDecision>[];
}

const SAMPLE_DECISIONS: Array<{ actor: string | undefined; path: string }> = [
  { actor: "anonymous",         path: "/ui" },
  { actor: "employee",          path: "/ui" },
  { actor: "customer",          path: "/api/workspace/ui/audit" },
  { actor: "internal_operator", path: "/ui" },
  { actor: "root_operator",     path: "/api/workspace/ui/audit" },
];

export function handleAuthObserveStatus(_req: IncomingMessage, res: ServerResponse): void {
  const modelStatus = getAuthModelStatus();
  const routeMapSummary = getAuthRouteMapSummary();
  const composerStatus = getAuthComposerStatus();

  const modules: AuthObserveStatusResponse["modules"] = {
    authModel: {
      name: modelStatus.subsystemName,
      observeOnly: true,
      enforcing: false,
      implementationPhase: modelStatus.implementationPhase,
      note: modelStatus.note,
    },
    authRouteMap: {
      name: "auth_route_map",
      observeOnly: true,
      enforcing: false,
      implementationPhase: "skeleton",
      note: `Phase 181 skeleton — ${routeMapSummary.totalCategories} route categories, first-match-wins prefix matching, unrecognised paths default to operator-grade`,
    },
    authDecisionComposer: {
      name: composerStatus.subsystemName,
      observeOnly: true,
      enforcing: false,
      implementationPhase: composerStatus.implementationPhase,
      note: composerStatus.note,
    },
  };

  const sampleDecisions = SAMPLE_DECISIONS.map(({ actor, path }) =>
    composeAuthDecision(actor, path, "GET"),
  );

  const response: AuthObserveStatusResponse = {
    generatedAt: new Date().toISOString(),
    observeOnly: true,
    authStackReady: true,
    executionBlocked: true,
    modules,
    sampleDecisions,
  };

  sendJson(res, 200, response);
}
