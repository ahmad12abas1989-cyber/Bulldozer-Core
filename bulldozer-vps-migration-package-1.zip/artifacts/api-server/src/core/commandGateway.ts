import { randomBytes } from "node:crypto";
import { logger } from "../lib/logger";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { emitRuntimeEvent } from "./runtimeEventBus";

export type CommandStatus =
  | "received"
  | "evaluated"
  | "blocked"
  | "approval_required"
  | "archived";

export type RiskLevel = "low" | "medium" | "high" | "critical";

export interface Command {
  commandId: string;
  commandType: string;
  source: string;
  requestedBy: string;
  payload: Record<string, unknown>;
  status: CommandStatus;
  riskLevel: RiskLevel;
  approvalRequired: boolean;
  blockedReason: string | null;
  createdAt: string;
  updatedAt: string;
  correlationId: string | null;
}

export interface CommandEvaluationResult {
  status: CommandStatus;
  riskLevel: RiskLevel;
  approvalRequired: boolean;
  blockedReason: string | null;
  policyId: string;
  policyReason: string;
}

export interface CommandGatewayStatus {
  operational: boolean;
  totalReceived: number;
  totalEvaluated: number;
  totalBlocked: number;
  totalApprovalRequired: number;
  totalArchived: number;
  retainedCommandCount: number;
  maxRetainedCommands: number;
  hasBlockedOrPendingApproval: boolean;
  commandExecutionBlocked: true;
  executionBlocked: true;
  recoveryBlocked: true;
  timestamp: string;
}

export interface CommandFilter {
  riskLevel?: string;
  commandType?: string;
  requestedBy?: string;
  status?: string;
  source?: string;
  limit?: number;
}

export interface CommandListResult {
  operational: boolean;
  totalReceived: number;
  totalEvaluated: number;
  totalBlocked: number;
  totalApprovalRequired: number;
  totalArchived: number;
  retainedCommandCount: number;
  maxRetainedCommands: number;
  hasBlockedOrPendingApproval: boolean;
  commandExecutionBlocked: true;
  executionBlocked: true;
  recoveryBlocked: true;
  filteredCount: number;
  filtersApplied: Record<string, string>;
  limit: number;
  commands: Command[];
  commandCount: number;
  timestamp: string;
}

const MAX_COMMANDS = 500;
const MAX_QUERY_LIMIT = 100;
const EXECUTION_BLOCKED: true = true;
const COMMAND_EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;

const TYPE_FORMAT = /^[a-zA-Z][a-zA-Z0-9_-]*:[a-zA-Z][a-zA-Z0-9_:.-]*$/;

const BLOCKED_NAMESPACES = new Set([
  "shell", "exec", "spawn", "cmd", "bash", "sh",
  "process", "system", "deploy", "deployment",
  "recovery", "run", "execute", "start", "stop",
  "restart", "kill", "self", "ai", "auto", "repair",
  "fix", "update", "delete", "remove", "mutate",
  "write", "fs", "file", "disk", "network", "external",
  "rm", "format", "socket", "fetch", "http", "request",
  "worker", "thread", "cluster", "fork", "child",
]);

const LOW_RISK_NAMESPACES = new Set([
  "status", "read", "query", "metrics", "health",
  "check", "report", "view", "info", "ping",
]);

const MEDIUM_RISK_NAMESPACES = new Set([
  "monitor", "inspect", "list", "config", "audit",
  "log", "timeline", "snapshot", "watchdog", "trace",
  "describe", "show", "get",
]);

const commands: Command[] = [];
let isOperational = false;
let totalReceived = 0;
let totalEvaluated = 0;
let totalBlocked = 0;
let totalApprovalRequired = 0;
let totalArchived = 0;

function storeCommand(command: Command): void {
  if (commands.length >= MAX_COMMANDS) {
    commands.shift();
  }
  commands.push(command);
}

function getNamespace(commandType: string): string {
  const colonIdx = commandType.indexOf(":");
  return colonIdx >= 0 ? commandType.slice(0, colonIdx).toLowerCase() : commandType.toLowerCase();
}

export function evaluateCommand(commandType: string): CommandEvaluationResult {
  if (!TYPE_FORMAT.test(commandType)) {
    return {
      status: "blocked",
      riskLevel: "critical",
      approvalRequired: false,
      blockedReason: `Invalid command type format. Expected namespace:action, got: "${commandType}"`,
      policyId: "block_invalid_format",
      policyReason: "Command type must match pattern: namespace:action",
    };
  }

  const namespace = getNamespace(commandType);

  if (BLOCKED_NAMESPACES.has(namespace)) {
    return {
      status: "blocked",
      riskLevel: "critical",
      approvalRequired: false,
      blockedReason: `Blocked namespace: "${namespace}" commands are not permitted in this gateway`,
      policyId: "block_dangerous_namespace",
      policyReason: `Namespace "${namespace}" is in the blocked list — execution, mutation, and system-level commands are never allowed`,
    };
  }

  if (LOW_RISK_NAMESPACES.has(namespace)) {
    return {
      status: "evaluated",
      riskLevel: "low",
      approvalRequired: false,
      blockedReason: null,
      policyId: "allow_low_risk",
      policyReason: `Namespace "${namespace}" is read-only/status — low risk, no approval required`,
    };
  }

  if (MEDIUM_RISK_NAMESPACES.has(namespace)) {
    return {
      status: "evaluated",
      riskLevel: "medium",
      approvalRequired: false,
      blockedReason: null,
      policyId: "allow_medium_risk",
      policyReason: `Namespace "${namespace}" is observational — medium risk, no approval required`,
    };
  }

  return {
    status: "approval_required",
    riskLevel: "high",
    approvalRequired: true,
    blockedReason: null,
    policyId: "require_approval_unknown_namespace",
    policyReason: `Namespace "${namespace}" is not in any known-safe list — high risk, approval required before any further action`,
  };
}

export function submitCommand(input: {
  commandType: string;
  source: string;
  requestedBy?: string;
  payload?: Record<string, unknown>;
  correlationId?: string | null;
}): Command {
  const now = new Date().toISOString();
  const commandId = randomBytes(8).toString("hex");

  const command: Command = {
    commandId,
    commandType: input.commandType,
    source: input.source,
    requestedBy: input.requestedBy ?? "system",
    payload: input.payload ?? {},
    status: "received",
    riskLevel: "low",
    approvalRequired: false,
    blockedReason: null,
    createdAt: now,
    updatedAt: now,
    correlationId: input.correlationId ?? null,
  };

  totalReceived++;

  const evaluation = evaluateCommand(input.commandType);

  command.status = evaluation.status;
  command.riskLevel = evaluation.riskLevel;
  command.approvalRequired = evaluation.approvalRequired;
  command.blockedReason = evaluation.blockedReason;
  command.updatedAt = new Date().toISOString();

  if (evaluation.status === "blocked") {
    totalBlocked++;
  } else if (evaluation.status === "approval_required") {
    totalApprovalRequired++;
  } else {
    totalEvaluated++;
  }

  storeCommand(command);

  const eventSeverity =
    evaluation.status === "blocked"
      ? ("warning" as const)
      : evaluation.status === "approval_required"
        ? ("warning" as const)
        : ("info" as const);

  emit(`command_gateway:${evaluation.status}`, "command-gateway", {
    commandId,
    commandType: input.commandType,
    riskLevel: evaluation.riskLevel,
    policyId: evaluation.policyId,
  });

  emitRuntimeEvent({
    eventType: `command.${evaluation.status}`,
    source: "command-gateway",
    severity: eventSeverity,
    category: "runtime",
    payload: {
      commandId,
      commandType: input.commandType,
      riskLevel: evaluation.riskLevel,
      approvalRequired: evaluation.approvalRequired,
      blockedReason: evaluation.blockedReason,
      policyId: evaluation.policyId,
    },
    correlationId: input.correlationId ?? null,
  });

  addTimelineEvent({
    level: evaluation.status === "blocked" ? "warn" : "info",
    source: "command-gateway",
    message: `Command ${evaluation.status}: ${input.commandType} (risk: ${evaluation.riskLevel})`,
    metadata: {
      commandId,
      commandType: input.commandType,
      riskLevel: evaluation.riskLevel,
      policyId: evaluation.policyId,
      approvalRequired: evaluation.approvalRequired,
    },
  });

  logger.info(
    {
      commandId,
      commandType: input.commandType,
      status: evaluation.status,
      riskLevel: evaluation.riskLevel,
      policyId: evaluation.policyId,
      commandExecutionBlocked: COMMAND_EXECUTION_BLOCKED,
    },
    "Command gateway: command received and evaluated",
  );

  return command;
}

export function listCommands(): Command[] {
  return [...commands].reverse();
}

export function getCommandGatewayStatus(): CommandGatewayStatus {
  return {
    operational: isOperational,
    totalReceived,
    totalEvaluated,
    totalBlocked,
    totalApprovalRequired,
    totalArchived,
    retainedCommandCount: commands.length,
    maxRetainedCommands: MAX_COMMANDS,
    hasBlockedOrPendingApproval: totalBlocked > 0 || totalApprovalRequired > 0,
    commandExecutionBlocked: COMMAND_EXECUTION_BLOCKED,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function getFilteredCommands(filter: CommandFilter): CommandListResult {
  const limit = Math.max(1, Math.min(filter.limit ?? MAX_QUERY_LIMIT, MAX_QUERY_LIMIT));
  const filtersApplied: Record<string, string> = {};

  let records = commands.slice();

  if (filter.riskLevel !== undefined) {
    records = records.filter((c) => c.riskLevel === filter.riskLevel);
    filtersApplied["riskLevel"] = filter.riskLevel;
  }

  if (filter.commandType !== undefined) {
    records = records.filter((c) => c.commandType === filter.commandType);
    filtersApplied["commandType"] = filter.commandType;
  }

  if (filter.requestedBy !== undefined) {
    records = records.filter((c) => c.requestedBy === filter.requestedBy);
    filtersApplied["requestedBy"] = filter.requestedBy;
  }

  if (filter.status !== undefined) {
    records = records.filter((c) => c.status === filter.status);
    filtersApplied["status"] = filter.status;
  }

  if (filter.source !== undefined) {
    records = records.filter((c) => c.source === filter.source);
    filtersApplied["source"] = filter.source;
  }

  const filteredCount = records.length;
  const sliced = records.slice(-limit).reverse();

  return {
    operational: isOperational,
    totalReceived,
    totalEvaluated,
    totalBlocked,
    totalApprovalRequired,
    totalArchived,
    retainedCommandCount: commands.length,
    maxRetainedCommands: MAX_COMMANDS,
    hasBlockedOrPendingApproval: totalBlocked > 0 || totalApprovalRequired > 0,
    commandExecutionBlocked: COMMAND_EXECUTION_BLOCKED,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    filteredCount,
    filtersApplied,
    limit,
    commands: sliced,
    commandCount: sliced.length,
    timestamp: new Date().toISOString(),
  };
}

export function initCommandGateway(): void {
  isOperational = true;

  emit("command_gateway:initialized", "command-gateway", {
    maxRetainedCommands: MAX_COMMANDS,
    commandExecutionBlocked: COMMAND_EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "command_gateway.initialized",
    source: "command-gateway",
    severity: "info",
    category: "runtime",
    payload: {
      maxRetainedCommands: MAX_COMMANDS,
      commandExecutionBlocked: COMMAND_EXECUTION_BLOCKED,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  addTimelineEvent({
    level: "info",
    source: "command-gateway",
    message: "Command gateway initialized — intake only, no execution path",
    metadata: {
      maxRetainedCommands: MAX_COMMANDS,
      commandExecutionBlocked: COMMAND_EXECUTION_BLOCKED,
    },
  });

  logger.info(
    { maxRetainedCommands: MAX_COMMANDS, commandExecutionBlocked: COMMAND_EXECUTION_BLOCKED },
    "Command gateway initialized",
  );
}
