// firstActualSandboxMutationApplyCore.ts
// Phase 333 — First Actual Sandbox Mutation Apply Descriptor Core Skeleton
// In-memory first actual sandbox mutation apply descriptor engine.
// Layer 31 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit stack.
// Prepares the first actual sandbox mutation apply descriptor.
// Preserves sandbox-approved-only target scope from layers 24–30 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. mutationApplyEnabled=false — apply layer has not been activated.
// mutationApplyPrepared=true — descriptor-readiness established for a future first actual sandbox write mutation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstActualSandboxMutationCommitRecord }        from "./firstActualSandboxMutationCommitCore.js";
import type { FirstActualSandboxMutationExecutorRecord }      from "./firstActualSandboxMutationExecutorCore.js";
import type { ActualSandboxWriteCommitExecutionGateRecord }   from "./actualSandboxWriteCommitExecutionGateCore.js";
import type { SandboxWriteCommitEnableRecord }                from "./sandboxWriteCommitEnableCore.js";
import type { FirstSandboxWriteCommitRecord }                 from "./firstSandboxWriteCommitCore.js";
import type { ControlledExecutionRecord }                     from "./controlledExecutionCore.js";
import { randomUUID }                                         from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type MutationApplyState = "descriptor_mutation_apply_pending";

export type MutationApplyCheckRule =
  | "mutation_commit_exists"
  | "mutation_executor_exists"
  | "commit_execution_gate_exists"
  | "commit_enable_record_exists"
  | "sandbox_write_commit_exists"
  | "execution_record_exists"
  | "mutation_commit_bound_to_executor"
  | "mutation_executor_bound_to_commit_execution_gate"
  | "commit_execution_gate_bound_to_commit_enable"
  | "commit_enable_bound_to_commit"
  | "mutation_apply_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface MutationApplyCheck {
  readonly rule: MutationApplyCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface MutationApplyBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface MutationApplyPlanEntry {
  readonly entryId:               string;
  readonly operationType:         "descriptor_mutation_apply_planned";
  readonly targetScope:           "sandbox_approved_only";
  readonly mutationApplyEnabled:  false;
  readonly mutationBlocked:       true;
  readonly note:                  string;
}

export interface LinkedMutationApplyReference {
  readonly mutationCommitId:            string;
  readonly mutationExecutorId:          string;
  readonly commitExecutionGateId:       string;
  readonly sandboxWriteCommitEnableId:  string;
  readonly rollbackSnapshotId:          string;
  readonly mutationApplyPrepared:       true;
  readonly mutationApplyEnabled:        false;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly rollbackChainValid:          boolean;
  readonly referenceNote:               string;
}

export interface MutationApplyReadinessReport {
  readonly mutationApplyPrepared:       true;
  readonly mutationApplyEnabled:        false;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly commitExecutionGateEnabled:  false;
  readonly sandboxWriteCommitEnabled:   false;
  readonly runtimeWriteExecutorEnabled: false;
  readonly writeExecutionGateEnabled:   false;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly targetScope:                 "sandbox_approved_only";
  readonly summary:                     string;
}

export interface FirstActualSandboxMutationApplyRecord {
  readonly mutationApplyId:             string;
  readonly mutationApplyState:          MutationApplyState;
  readonly approvalRequired:            true;
  readonly mutationApplyPrepared:       true;
  readonly mutationApplyEnabled:        false;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly commitExecutionGateEnabled:  false;
  readonly sandboxWriteCommitEnabled:   false;
  readonly actualWritesEnabled:         false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly targetScope:                 "sandbox_approved_only";
  readonly implementationPhase:         "descriptor_only";
  readonly mutationCommitId:            string;
  readonly mutationExecutorId:          string;
  readonly commitExecutionGateId:       string;
  readonly sandboxWriteCommitEnableId:  string;
  readonly sandboxWriteCommitId:        string;
  readonly controlledExecutionId:       string;
  readonly mutationApplyPlan:           readonly MutationApplyPlanEntry[];
  readonly mutationApplyChecks:         readonly MutationApplyCheck[];
  readonly mutationApplyBlockedReasons: readonly MutationApplyBlockedReason[];
  readonly mutationApplyReadinessReport: MutationApplyReadinessReport;
  readonly linkedMutationApplyReference: LinkedMutationApplyReference;
  readonly createdAt:                   string;
}

export interface CreateFirstActualSandboxMutationApplyInput {
  readonly mutationCommitRecord:        FirstActualSandboxMutationCommitRecord;
  readonly mutationExecutorRecord:      FirstActualSandboxMutationExecutorRecord;
  readonly commitExecutionGateRecord:   ActualSandboxWriteCommitExecutionGateRecord;
  readonly commitEnableRecord:          SandboxWriteCommitEnableRecord;
  readonly commitRecord:                FirstSandboxWriteCommitRecord;
  readonly executionRecord:             ControlledExecutionRecord;
}

export interface FirstActualSandboxMutationApplySummary {
  readonly total:                       number;
  readonly byState:                     Record<MutationApplyState, number>;
  readonly mutationApplyPrepared:       true;
  readonly mutationApplyEnabled:        false;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly commitExecutionGateEnabled:  false;
  readonly sandboxWriteCommitEnabled:   false;
  readonly actualWritesEnabled:         false;
  readonly approvalRequired:            true;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly targetScope:                 "sandbox_approved_only";
  readonly mutationApplyState:          MutationApplyState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstActualSandboxMutationApplyRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstActualSandboxMutationApplyInput,
): readonly MutationApplyCheck[] {
  const { mutationCommitRecord, mutationExecutorRecord, commitExecutionGateRecord, commitEnableRecord, commitRecord, executionRecord } = input;

  const commitExists  = mutationCommitRecord.mutationCommitId.length > 0;
  const execExists    = mutationExecutorRecord.mutationExecutorId.length > 0;
  const gateExists    = commitExecutionGateRecord.commitExecutionGateId.length > 0;
  const enableExists  = commitEnableRecord.sandboxWriteCommitEnableId.length > 0;
  const swcExists     = commitRecord.sandboxWriteCommitId.length > 0;
  const ctrlExists    = executionRecord.controlledExecutionId.length > 0;

  const commitBound   = mutationCommitRecord.mutationExecutorId === mutationExecutorRecord.mutationExecutorId;
  const execBound     = mutationExecutorRecord.commitExecutionGateId === commitExecutionGateRecord.commitExecutionGateId;
  const gateBound     = commitExecutionGateRecord.sandboxWriteCommitEnableId === commitEnableRecord.sandboxWriteCommitEnableId;
  const enableBound   = commitEnableRecord.sandboxWriteCommitId === commitRecord.sandboxWriteCommitId;

  return [
    {
      rule: "mutation_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `mutationCommitId=${mutationCommitRecord.mutationCommitId}`
        : "mutationCommitRecord.mutationCommitId is empty",
    },
    {
      rule: "mutation_executor_exists",
      pass: execExists,
      note: execExists
        ? `mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`
        : "mutationExecutorRecord.mutationExecutorId is empty",
    },
    {
      rule: "commit_execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`
        : "commitExecutionGateRecord.commitExecutionGateId is empty",
    },
    {
      rule: "commit_enable_record_exists",
      pass: enableExists,
      note: enableExists
        ? `sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`
        : "commitEnableRecord.sandboxWriteCommitEnableId is empty",
    },
    {
      rule: "sandbox_write_commit_exists",
      pass: swcExists,
      note: swcExists
        ? `sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`
        : "commitRecord.sandboxWriteCommitId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "mutation_commit_bound_to_executor",
      pass: commitBound,
      note: commitBound
        ? `mutationCommitRecord.mutationExecutorId === mutationExecutorRecord.mutationExecutorId (${mutationExecutorRecord.mutationExecutorId})`
        : `commit/executor mismatch: commit.mutationExecutorId=${mutationCommitRecord.mutationExecutorId} vs executor.mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`,
    },
    {
      rule: "mutation_executor_bound_to_commit_execution_gate",
      pass: execBound,
      note: execBound
        ? `mutationExecutorRecord.commitExecutionGateId === commitExecutionGateRecord.commitExecutionGateId (${commitExecutionGateRecord.commitExecutionGateId})`
        : `executor/gate mismatch: executor.commitExecutionGateId=${mutationExecutorRecord.commitExecutionGateId} vs gate.commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`,
    },
    {
      rule: "commit_execution_gate_bound_to_commit_enable",
      pass: gateBound,
      note: gateBound
        ? `commitExecutionGateRecord.sandboxWriteCommitEnableId === commitEnableRecord.sandboxWriteCommitEnableId (${commitEnableRecord.sandboxWriteCommitEnableId})`
        : `gate/commit-enable mismatch: gate.sandboxWriteCommitEnableId=${commitExecutionGateRecord.sandboxWriteCommitEnableId} vs enable.sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`,
    },
    {
      rule: "commit_enable_bound_to_commit",
      pass: enableBound,
      note: enableBound
        ? `commitEnableRecord.sandboxWriteCommitId === commitRecord.sandboxWriteCommitId (${commitRecord.sandboxWriteCommitId})`
        : `commit-enable/commit mismatch: enable.sandboxWriteCommitId=${commitEnableRecord.sandboxWriteCommitId} vs commit.sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`,
    },
    {
      rule: "mutation_apply_still_disabled",
      pass: true,
      note: "mutationApplyEnabled=false — compile-time literal; no mutation apply activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "mutationApplyState=descriptor_mutation_apply_pending — output is a descriptor only; mutation apply is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly MutationApplyCheck[],
): readonly MutationApplyBlockedReason[] {
  const staticReasons: MutationApplyBlockedReason[] = [
    { code: "mutation_apply_disabled", reason: "mutationApplyEnabled=false — compile-time literal; an explicit first actual sandbox write mutation phase must activate the apply layer before any sandbox target can be mutated",                                                                                                                                                                                                                                                                              static: true },
    { code: "approval_required",       reason: "approvalRequired=true — explicit operator approval is required before the mutation apply layer can be activated",                                                                                                                                                                                                                                                                                                                                           static: true },
    { code: "actual_writes_disabled",  reason: "actualWritesEnabled=false — compile-time literal across all 31 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, and mutation-commit layers", static: true },
  ];
  const dynamicReasons: MutationApplyBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedMutationApplyReference(
  input: CreateFirstActualSandboxMutationApplyInput,
  rollbackChainValid: boolean,
): LinkedMutationApplyReference {
  const { mutationCommitRecord, mutationExecutorRecord, commitExecutionGateRecord, commitEnableRecord } = input;
  return {
    mutationCommitId:           mutationCommitRecord.mutationCommitId,
    mutationExecutorId:         mutationExecutorRecord.mutationExecutorId,
    commitExecutionGateId:      commitExecutionGateRecord.commitExecutionGateId,
    sandboxWriteCommitEnableId: commitEnableRecord.sandboxWriteCommitEnableId,
    rollbackSnapshotId:         mutationCommitRecord.linkedMutationCommitReference.rollbackSnapshotId,
    mutationApplyPrepared:      true,
    mutationApplyEnabled:       false,
    mutationCommitEnabled:      false,
    mutationExecutorEnabled:    false,
    actualWritesEnabled:        false,
    rollbackChainValid,
    referenceNote: "linked mutation apply reference sources rollbackSnapshotId from mutationCommitRecord.linkedMutationCommitReference; mutation apply disabled; mutation commit disabled; mutation executor disabled; commit execution gate disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstActualSandboxMutationApplyRecord(
  input: CreateFirstActualSandboxMutationApplyInput,
): FirstActualSandboxMutationApplyRecord {
  const { mutationCommitRecord, mutationExecutorRecord, commitExecutionGateRecord, commitEnableRecord, commitRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = mutationCommitRecord.mutationCommitReadinessReport.rollbackChainValid;

  const allChecksPass   = checks.every((c) => c.pass);
  const blockedReasons  = buildBlockedReasons(checks);
  const linkedRef       = buildLinkedMutationApplyReference(input, rollbackChainValid);

  const mutationApplyPlan: MutationApplyPlanEntry[] = [
    {
      entryId:             randomUUID(),
      operationType:       "descriptor_mutation_apply_planned",
      targetScope:         "sandbox_approved_only",
      mutationApplyEnabled: false,
      mutationBlocked:     true,
      note:                "mutation apply planned in descriptor-only mode; targetScope=sandbox_approved_only; mutationApplyEnabled=false; filesystemMutationBlocked=true; first actual sandbox write mutation phase required to activate",
    },
  ];

  const mutationApplyReadinessReport: MutationApplyReadinessReport = {
    mutationApplyPrepared:        true,
    mutationApplyEnabled:         false,
    mutationCommitEnabled:        false,
    mutationExecutorEnabled:      false,
    commitExecutionGateEnabled:   false,
    sandboxWriteCommitEnabled:    false,
    runtimeWriteExecutorEnabled:  false,
    writeExecutionGateEnabled:    false,
    scopedActivationEnabled:      false,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    targetScope:                  "sandbox_approved_only",
    summary: `mutationApplyState=descriptor_mutation_apply_pending; mutationApplyEnabled=false; mutationCommitEnabled=false; mutationExecutorEnabled=false; commitExecutionGateEnabled=false; sandboxWriteCommitEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstActualSandboxMutationApplyRecord = {
    mutationApplyId:              randomUUID(),
    mutationApplyState:           "descriptor_mutation_apply_pending",
    approvalRequired:             true,
    mutationApplyPrepared:        true,
    mutationApplyEnabled:         false,
    mutationCommitEnabled:        false,
    mutationExecutorEnabled:      false,
    commitExecutionGateEnabled:   false,
    sandboxWriteCommitEnabled:    false,
    actualWritesEnabled:          false,
    filesystemMutationBlocked:    true,
    motherCoreMutationBlocked:    true,
    vaultMutationBlocked:         true,
    shellBlocked:                 true,
    networkBlocked:               true,
    targetScope:                  "sandbox_approved_only",
    implementationPhase:          "descriptor_only",
    mutationCommitId:             mutationCommitRecord.mutationCommitId,
    mutationExecutorId:           mutationExecutorRecord.mutationExecutorId,
    commitExecutionGateId:        commitExecutionGateRecord.commitExecutionGateId,
    sandboxWriteCommitEnableId:   commitEnableRecord.sandboxWriteCommitEnableId,
    sandboxWriteCommitId:         commitRecord.sandboxWriteCommitId,
    controlledExecutionId:        executionRecord.controlledExecutionId,
    mutationApplyPlan,
    mutationApplyChecks:          checks,
    mutationApplyBlockedReasons:  blockedReasons,
    mutationApplyReadinessReport,
    linkedMutationApplyReference: linkedRef,
    createdAt:                    new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstActualSandboxMutationApplyRecords(): readonly FirstActualSandboxMutationApplyRecord[] {
  return _store.slice();
}

export function getFirstActualSandboxMutationApplySummary(): FirstActualSandboxMutationApplySummary {
  return {
    total:                          _store.length,
    byState:                        { descriptor_mutation_apply_pending: _store.length },
    mutationApplyPrepared:          true,
    mutationApplyEnabled:           false,
    mutationCommitEnabled:          false,
    mutationExecutorEnabled:        false,
    commitExecutionGateEnabled:     false,
    sandboxWriteCommitEnabled:      false,
    actualWritesEnabled:            false,
    approvalRequired:               true,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    targetScope:                    "sandbox_approved_only",
    mutationApplyState:             "descriptor_mutation_apply_pending",
    implementationPhase:            "descriptor_only",
  };
}
