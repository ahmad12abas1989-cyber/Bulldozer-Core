import type { IncomingMessage, ServerResponse } from "node:http";
import { URL } from "node:url";
import {
  getWorkspaceSummary,
  getProjectsOverview,
  getWorkspaceHealth,
  getWorkspaceNavigation,
  listWorkspacePanels,
  getPanel,
  KNOWN_PANEL_IDS,
} from "../core/workspaceShell";
import {
  captureWorkspaceSnapshot,
  listWorkspaceSnapshots,
  getLatestWorkspaceSnapshot,
} from "../core/workspaceSnapshots";
import {
  getWorkspaceTimeline,
  getWorkspaceActivityFeed,
} from "../core/workspaceTimeline";
import {
  getWorkspaceDiff,
  listWorkspaceDiffPairs,
} from "../core/workspaceDiff";
import {
  createAuditReport,
  listAuditReports,
  getAuditReportById,
  VALID_REPORT_TYPES,
  type AuditReportType,
  type AuditReportFilter,
} from "../core/workspaceAuditReport";
import { getWorkspaceAuditDigest } from "../core/workspaceAuditDigest";
import { getWorkspaceGovernanceScorecard } from "../core/workspaceGovernanceScorecard";
import { getPolicyComplianceLedger } from "../core/workspacePolicyComplianceLedger";
import { getWorkspaceObservationHeatmap } from "../core/workspaceObservationHeatmap";
import { getWorkspaceCoverageTrend } from "../core/workspaceCoverageTrend";
import { getWorkspacePolicyExposureIndex } from "../core/workspacePolicyExposureIndex";
import { getWorkspaceObservationProbe } from "../core/workspaceObservationProbe";
import { getWorkspaceObservationLedger } from "../core/workspaceObservationLedger";
import {
  captureWorkspaceObservationLedgerHistory,
  listWorkspaceObservationLedgerHistory,
  getObservationLedgerHistoryDetail,
} from "../core/workspaceObservationLedgerHistory";
import { compareObservationLedgerSnapshots } from "../core/workspaceObservationLedgerComparison";
import { getDualComparison } from "../core/workspaceDualComparisonGateway";
import { getComparisonRegistry } from "../core/workspaceComparisonRegistry";
import { getGovernanceDrift } from "../core/workspaceGovernanceDriftDetector";
import { getUIRenderModel } from "../core/workspaceUIRenderModel";
import { getDashboardSkeleton } from "../core/workspaceDashboardSkeleton";
import { getUICoherence } from "../core/workspaceUICoherence";
import { getUILayerVersionManifest } from "../core/workspaceUILayerVersionManifest";
import { getUILayerSummary }        from "../core/workspaceUILayerSummary";
import { getUIPreviewPayload }      from "../core/workspaceUIPreviewPayload";
import { getUIIndex }              from "../core/workspaceUIIndex";
import { getUINavigationManifest } from "../core/workspaceUINavigation";
import { getUIPageManifest }       from "../core/workspaceUIPages";
import { getUIPagesSummary }       from "../core/workspaceUIPagesSummary";
import { getUIHtmlRoutesIndex }    from "../core/workspaceUIHtmlRoutes";
import { getUIPanelManifest }      from "../core/workspaceUIPanels";
import { getUIWidgetManifest }     from "../core/workspaceUIWidgets";
import { getUIBindingManifest }    from "../core/workspaceUIBindings";
import { getUIBadgeManifest }      from "../core/workspaceUIBadges";
import { getUIThemeManifest }      from "../core/workspaceUITheme";
import { getUILayoutManifest }     from "../core/workspaceUILayout";
import { getUILayerAudit }         from "../core/workspaceUILayerAudit";
import { getUIManifestCatalogue }  from "../core/workspaceUIManifestCatalogue";
import {
  captureDriftSnapshot,
  listDriftHistory,
} from "../core/workspaceGovernanceDriftHistory";
import {
  captureGovernanceScorecardSnapshot,
  listGovernanceScorecardHistory,
  getGovernanceScorecardHistoryDetail,
} from "../core/workspaceGovernanceScorecardHistory";
import {
  compareGovernanceScorecards,
} from "../core/workspaceGovernanceScorecardComparison";
import { getWorkspaceGovernanceScorecardAnalytics } from "../core/workspaceGovernanceScorecardAnalytics";
import { getWorkspaceObservationLedgerAnalytics } from "../core/workspaceObservationLedgerAnalytics";
import { getWorkspaceVisualShell } from "../core/workspaceVisualShell";
import { getWorkspaceVisualShellComposed } from "../core/workspaceVisualShellComposition";
import {
  listWidgetContracts,
  getWidgetContract,
} from "../core/workspaceWidgetContracts";
import { runWidgetValidationProbe } from "../core/workspaceWidgetValidationProbe";
import { runWidgetRegistryValidation } from "../core/widgetRegistryHealth";
import {
  captureWidgetValidationSnapshot,
  listWidgetValidationHistory,
  getWidgetValidationHistoryDetail,
} from "../core/workspaceWidgetValidationHistory";
import { readJsonBody } from "../lib/body";
import { sendJson, sendError } from "../lib/response";

// --- Phase 83: workspace summary, overview, health ---

export function handleWorkspaceSummary(_req: IncomingMessage, res: ServerResponse): void {
  const summary = getWorkspaceSummary();
  sendJson(res, 200, summary);
}

export function handleWorkspaceProjectsOverview(req: IncomingMessage, res: ServerResponse): void {
  const raw = req.url ?? "/";
  const url = new URL(raw, "http://localhost");

  const statusParam = url.searchParams.get("status");
  const limitParam = url.searchParams.get("limit");

  const status =
    statusParam !== null &&
    ["active", "archived", "suspended"].includes(statusParam)
      ? statusParam
      : undefined;

  const limitRaw = limitParam !== null ? Number(limitParam) : NaN;
  const limit = !isNaN(limitRaw) && limitRaw > 0 ? Math.floor(limitRaw) : undefined;

  const result = getProjectsOverview({ status, limit });
  sendJson(res, 200, result);
}

export function handleWorkspaceHealth(_req: IncomingMessage, res: ServerResponse): void {
  const health = getWorkspaceHealth();
  sendJson(res, 200, health);
}

// --- Phase 84: navigation and panels ---

export function handleWorkspaceNavigation(_req: IncomingMessage, res: ServerResponse): void {
  const nav = getWorkspaceNavigation();
  sendJson(res, 200, nav);
}

export function handleWorkspacePanelList(_req: IncomingMessage, res: ServerResponse): void {
  const panels = listWorkspacePanels();
  sendJson(res, 200, panels);
}

export function handleWorkspacePanelById(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const panelId = decodeURIComponent(segments[segments.length - 1] ?? "");

  if (!panelId) {
    sendError(res, 400, "Panel ID is required");
    return;
  }

  const panel = getPanel(panelId);

  if (panel === null) {
    sendError(res, 404, `Unknown panel: "${panelId}". Known panels: ${KNOWN_PANEL_IDS.join(", ")}`);
    return;
  }

  sendJson(res, 200, panel);
}

// --- Phase 85: workspace snapshots ---

export function handleWorkspaceSnapshotCreate(_req: IncomingMessage, res: ServerResponse): void {
  const snapshot = captureWorkspaceSnapshot();
  sendJson(res, 201, {
    snapshotId: snapshot.snapshotId,
    schemaVersion: snapshot.schemaVersion,
    createdAt: snapshot.createdAt,
    note: "Workspace snapshot captured. This is an immutable read-only record. Execution is blocked.",
    executionBlocked: true as const,
  });
}

export function handleWorkspaceSnapshotList(_req: IncomingMessage, res: ServerResponse): void {
  const result = listWorkspaceSnapshots();
  sendJson(res, 200, result);
}

export function handleWorkspaceSnapshotLatest(_req: IncomingMessage, res: ServerResponse): void {
  const snapshot = getLatestWorkspaceSnapshot();
  if (snapshot === null) {
    sendError(
      res,
      404,
      "No workspace snapshots exist. POST /api/workspace/snapshots/create to capture the first snapshot.",
    );
    return;
  }
  sendJson(res, 200, snapshot);
}

// --- Phase 86: workspace timeline and activity feed ---

export function handleWorkspaceTimeline(req: IncomingMessage, res: ServerResponse): void {
  const raw = req.url ?? "/";
  const url = new URL(raw, "http://localhost");

  const projectId = url.searchParams.get("projectId") ?? undefined;
  const eventType = url.searchParams.get("eventType") ?? undefined;
  const limitRaw = url.searchParams.get("limit");
  const limitNum = limitRaw !== null ? Number(limitRaw) : undefined;
  const limit =
    limitNum !== undefined && !isNaN(limitNum) && limitNum > 0 ? Math.floor(limitNum) : undefined;

  const result = getWorkspaceTimeline({ projectId, eventType, limit });
  sendJson(res, 200, result);
}

export function handleWorkspaceActivityFeed(_req: IncomingMessage, res: ServerResponse): void {
  const result = getWorkspaceActivityFeed();
  sendJson(res, 200, result);
}

// --- Phase 87: workspace diff & change-detection ---

export function handleWorkspaceDiffList(_req: IncomingMessage, res: ServerResponse): void {
  const result = listWorkspaceDiffPairs();
  sendJson(res, 200, result);
}

export function handleWorkspaceDiffBySnapshotIds(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // /api/workspace/diff/:fromSnapshotId/:toSnapshotId → segments length 6
  const fromSnapshotId = decodeURIComponent(segments[segments.length - 2] ?? "");
  const toSnapshotId = decodeURIComponent(segments[segments.length - 1] ?? "");

  const outcome = getWorkspaceDiff(fromSnapshotId, toSnapshotId);

  if ("error" in outcome) {
    sendError(res, outcome.status, outcome.error);
    return;
  }

  sendJson(res, 200, outcome.result);
}

// --- Phase 88: workspace audit reports ---

export function handleAuditReportCreate(req: IncomingMessage, res: ServerResponse): void {
  readJsonBody(req)
    .then((body) => {
      if (!body || typeof body !== "object" || Array.isArray(body)) {
        sendError(res, 400, "Request body must be a JSON object");
        return;
      }

      const { reportType, fromSnapshotId, toSnapshotId } = body as Record<string, unknown>;

      if (!reportType || typeof reportType !== "string") {
        sendError(
          res,
          400,
          `Field "reportType" is required. Valid values: ${Array.from(VALID_REPORT_TYPES).join(", ")}`,
        );
        return;
      }

      if (!VALID_REPORT_TYPES.has(reportType)) {
        sendError(
          res,
          400,
          `Invalid reportType "${reportType}". Valid values: ${Array.from(VALID_REPORT_TYPES).join(", ")}`,
        );
        return;
      }

      const fromId = typeof fromSnapshotId === "string" ? fromSnapshotId : undefined;
      const toId = typeof toSnapshotId === "string" ? toSnapshotId : undefined;

      const outcome = createAuditReport({
        reportType: reportType as AuditReportType,
        fromSnapshotId: fromId,
        toSnapshotId: toId,
      });

      if ("error" in outcome) {
        sendError(res, outcome.status, outcome.error);
        return;
      }

      sendJson(res, 201, outcome.report);
    })
    .catch((err: unknown) => {
      sendError(res, 400, err instanceof Error ? err.message : "Failed to parse request body");
    });
}

const AUDIT_DEFAULT_LIMIT = 10;
const AUDIT_MAX_LIMIT = 10;

function decodeAuditParam(val: string | undefined): string | undefined {
  if (val === undefined) return undefined;
  try {
    return decodeURIComponent(val);
  } catch {
    return undefined;
  }
}

export function handleAuditReportList(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "";
  const queryStart = rawUrl.indexOf("?");
  const queryString = queryStart >= 0 ? rawUrl.slice(queryStart + 1) : "";

  const filter: AuditReportFilter = { limit: AUDIT_DEFAULT_LIMIT };

  if (queryString) {
    for (const part of queryString.split("&")) {
      const eqIdx = part.indexOf("=");
      if (eqIdx < 0) continue;
      const rawKey = part.slice(0, eqIdx);
      const rawVal = part.slice(eqIdx + 1);
      const key = decodeAuditParam(rawKey);
      const val = decodeAuditParam(rawVal);
      if (key === undefined || val === undefined || val === "") continue;

      switch (key) {
        case "reportType": {
          // VALID_REPORT_TYPES check is deferred to listAuditReports — invalid silently ignored
          filter.reportType = val as AuditReportType;
          break;
        }
        case "hasChanges": {
          if (val === "true") filter.hasChanges = true;
          else if (val === "false") filter.hasChanges = false;
          // any other value silently ignored
          break;
        }
        case "since": {
          // validated inside listAuditReports via Date.parse — pass raw value
          filter.since = val;
          break;
        }
        case "limit": {
          const parsed = parseInt(val, 10);
          if (!isNaN(parsed) && parsed > 0) {
            filter.limit = Math.min(parsed, AUDIT_MAX_LIMIT);
          }
          break;
        }
        default:
          break;
      }
    }
  }

  const result = listAuditReports(filter);
  sendJson(res, 200, result);
}

export function handleAuditDigest(_req: IncomingMessage, res: ServerResponse): void {
  const digest = getWorkspaceAuditDigest();
  sendJson(res, 200, digest);
}

export function handleGovernanceScorecard(_req: IncomingMessage, res: ServerResponse): void {
  const scorecard = getWorkspaceGovernanceScorecard();
  sendJson(res, 200, scorecard);
}

export function handlePolicyCompliance(_req: IncomingMessage, res: ServerResponse): void {
  const ledger = getPolicyComplianceLedger();
  sendJson(res, 200, ledger);
}

export function handleObservationHeatmap(_req: IncomingMessage, res: ServerResponse): void {
  const heatmap = getWorkspaceObservationHeatmap();
  sendJson(res, 200, heatmap);
}

export function handleCoverageTrend(_req: IncomingMessage, res: ServerResponse): void {
  const trend = getWorkspaceCoverageTrend();
  sendJson(res, 200, trend);
}

export function handlePolicyExposureIndex(_req: IncomingMessage, res: ServerResponse): void {
  const index = getWorkspacePolicyExposureIndex();
  sendJson(res, 200, index);
}

export function handleObservationProbe(_req: IncomingMessage, res: ServerResponse): void {
  const probe = getWorkspaceObservationProbe();
  sendJson(res, 200, probe);
}

export function handleObservationLedger(_req: IncomingMessage, res: ServerResponse): void {
  const ledger = getWorkspaceObservationLedger();
  sendJson(res, 200, ledger);
}

export function handleLedgerHistoryCapture(_req: IncomingMessage, res: ServerResponse): void {
  const result = captureWorkspaceObservationLedgerHistory();
  sendJson(res, 201, result);
}

export function handleLedgerHistoryList(_req: IncomingMessage, res: ServerResponse): void {
  const result = listWorkspaceObservationLedgerHistory();
  sendJson(res, 200, result);
}

export function handleComparisonRegistry(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getComparisonRegistry());
}

export function handleGovernanceDrift(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getGovernanceDrift());
}

export function handleDriftHistoryCapture(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, captureDriftSnapshot());
}

export function handleDriftHistory(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, listDriftHistory());
}

export function handleUIRenderModel(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIRenderModel());
}

export function handleDashboardSkeleton(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getDashboardSkeleton());
}

export function handleUICoherence(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUICoherence());
}

export function handleUILayerVersion(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUILayerVersionManifest());
}

export function handleUILayerSummary(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUILayerSummary());
}

export function handleUIPreviewPayload(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIPreviewPayload());
}

export function handleUIIndex(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIIndex());
}

export function handleUINavigation(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUINavigationManifest());
}

export function handleUIPages(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIPageManifest());
}

export function handleUIPagesSummary(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIPagesSummary());
}

export function handleUIHtmlRoutes(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIHtmlRoutesIndex());
}

export function handleUIPanels(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIPanelManifest());
}

export function handleUIWidgets(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIWidgetManifest());
}

export function handleUIBindings(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIBindingManifest());
}

export function handleUIBadges(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIBadgeManifest());
}

export function handleUITheme(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIThemeManifest());
}

export function handleUILayout(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUILayoutManifest());
}

export function handleUILayerAudit(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUILayerAudit());
}

export function handleUIManifestCatalogue(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getUIManifestCatalogue());
}

export function handleDualComparison(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "";
  const qIdx = rawUrl.indexOf("?");
  const qs = qIdx >= 0 ? rawUrl.slice(qIdx + 1) : "";
  const params = new URLSearchParams(qs);

  const rawSF = params.get("scorecardFrom") ?? "";
  const rawST = params.get("scorecardTo")   ?? "";
  const rawLF = params.get("ledgerFrom")    ?? "";
  const rawLT = params.get("ledgerTo")      ?? "";

  const sfSeq = parseInt(rawSF, 10);
  const stSeq = parseInt(rawST, 10);
  const lfSeq = parseInt(rawLF, 10);
  const ltSeq = parseInt(rawLT, 10);

  const sfInvalid = !rawSF || isNaN(sfSeq) || sfSeq <= 0 || String(sfSeq) !== rawSF;
  const stInvalid = !rawST || isNaN(stSeq) || stSeq <= 0 || String(stSeq) !== rawST;
  const lfInvalid = !rawLF || isNaN(lfSeq) || lfSeq <= 0 || String(lfSeq) !== rawLF;
  const ltInvalid = !rawLT || isNaN(ltSeq) || ltSeq <= 0 || String(ltSeq) !== rawLT;

  if (sfInvalid || stInvalid || lfInvalid || ltInvalid) {
    const bad: string[] = [];
    if (sfInvalid) bad.push(`"scorecardFrom" (got: "${rawSF}")`);
    if (stInvalid) bad.push(`"scorecardTo" (got: "${rawST}")`);
    if (lfInvalid) bad.push(`"ledgerFrom" (got: "${rawLF}")`);
    if (ltInvalid) bad.push(`"ledgerTo" (got: "${rawLT}")`);
    sendError(res, 400, `Dual comparison requires valid positive integer query params: ${bad.join(", ")}`);
    return;
  }

  const result = getDualComparison(sfSeq, stSeq, lfSeq, ltSeq);

  if ("error" in result) {
    if (result.error === "both_not_found") {
      sendError(res, 404,
        `Dual comparison: scorecardFrom=${result.scorecardFrom}/scorecardTo=${result.scorecardTo} not in scorecard ring (max 10) and ledgerFrom=${result.ledgerFrom}/ledgerTo=${result.ledgerTo} not in ledger ring (max 20)`);
    } else if (result.error === "scorecard_not_found") {
      const which = result.detail.which;
      sendError(res, 404,
        `Dual comparison: scorecard captureSeq ${which === "both" ? `${result.scorecardFrom} and ${result.scorecardTo} are` : which === "from" ? `${result.scorecardFrom} (scorecardFrom) is` : `${result.scorecardTo} (scorecardTo) is`} not in the scorecard ring (max 10)`);
    } else {
      const which = result.detail.which;
      sendError(res, 404,
        `Dual comparison: ledger captureSeq ${which === "both" ? `${result.ledgerFrom} and ${result.ledgerTo} are` : which === "from" ? `${result.ledgerFrom} (ledgerFrom) is` : `${result.ledgerTo} (ledgerTo) is`} not in the ledger ring (max 20)`);
    }
    return;
  }

  sendJson(res, 200, result);
}

export function handleLedgerHistoryCompare(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "";
  const qIdx = rawUrl.indexOf("?");
  const qs = qIdx >= 0 ? rawUrl.slice(qIdx + 1) : "";
  const params = new URLSearchParams(qs);

  const rawFrom = params.get("from") ?? "";
  const rawTo   = params.get("to")   ?? "";

  const fromSeq = parseInt(rawFrom, 10);
  const toSeq   = parseInt(rawTo,   10);

  const fromInvalid = !rawFrom || isNaN(fromSeq) || fromSeq <= 0 || String(fromSeq) !== rawFrom;
  const toInvalid   = !rawTo   || isNaN(toSeq)   || toSeq   <= 0 || String(toSeq)   !== rawTo;

  if (fromInvalid || toInvalid) {
    const missing: string[] = [];
    if (fromInvalid) missing.push(`"from" (got: "${rawFrom}")`);
    if (toInvalid)   missing.push(`"to" (got: "${rawTo}")`);
    sendError(res, 400, `Ledger comparison requires valid positive integer query params: ${missing.join(", ")}`);
    return;
  }

  const result = compareObservationLedgerSnapshots(fromSeq, toSeq);

  if ("error" in result) {
    const whichLabel =
      result.which === "both"
        ? `captureSeq ${fromSeq} (from) and ${toSeq} (to) are`
        : result.which === "from"
          ? `captureSeq ${fromSeq} (from) is`
          : `captureSeq ${toSeq} (to) is`;
    sendError(res, 404, `Ledger comparison: ${whichLabel} not in the retained ring (max 20)`);
    return;
  }

  sendJson(res, 200, result);
}

export function handleLedgerHistoryDetail(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // /api/workspace/observation/ledger/history/:captureSeq → last segment
  const rawSeq = segments[segments.length - 1] ?? "";
  const captureSeq = parseInt(rawSeq, 10);
  if (!rawSeq || isNaN(captureSeq) || captureSeq <= 0 || String(captureSeq) !== rawSeq) {
    sendError(res, 404, `Ledger history entry not found: "${rawSeq}" is not a valid captureSeq`);
    return;
  }
  const detail = getObservationLedgerHistoryDetail(captureSeq);
  if (detail === null) {
    sendError(res, 404, `Ledger history entry not found: captureSeq ${captureSeq} is not in the retained ring (max 20)`);
    return;
  }
  sendJson(res, 200, detail);
}

export function handleScorecardHistoryCapture(_req: IncomingMessage, res: ServerResponse): void {
  const result = captureGovernanceScorecardSnapshot();
  sendJson(res, 201, result);
}

export function handleScorecardHistoryList(_req: IncomingMessage, res: ServerResponse): void {
  const result = listGovernanceScorecardHistory();
  sendJson(res, 200, result);
}

export function handleScorecardHistoryCompare(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "";
  const qIdx = rawUrl.indexOf("?");
  const queryString = qIdx === -1 ? "" : rawUrl.slice(qIdx + 1);
  const params = new URLSearchParams(queryString);

  const rawFrom = params.get("from") ?? "";
  const rawTo   = params.get("to")   ?? "";

  // Validate "from" — must be a positive integer with no leading zeros or decimal
  const fromSeq = parseInt(rawFrom, 10);
  if (!rawFrom || isNaN(fromSeq) || fromSeq <= 0 || String(fromSeq) !== rawFrom) {
    sendError(res, 400, `Invalid query param "from": "${rawFrom}" is not a valid captureSeq (must be a positive integer)`);
    return;
  }

  // Validate "to"
  const toSeq = parseInt(rawTo, 10);
  if (!rawTo || isNaN(toSeq) || toSeq <= 0 || String(toSeq) !== rawTo) {
    sendError(res, 400, `Invalid query param "to": "${rawTo}" is not a valid captureSeq (must be a positive integer)`);
    return;
  }

  const result = compareGovernanceScorecards(fromSeq, toSeq);

  if ("error" in result) {
    sendError(
      res,
      404,
      `Scorecard comparison failed: captureSeq not found in ring (which="${result.which}") — max 10 entries retained`,
    );
    return;
  }

  sendJson(res, 200, result);
}

export function handleScorecardHistoryDetail(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // /api/workspace/governance/scorecard/history/:captureSeq → last segment
  const rawSeq = segments[segments.length - 1] ?? "";
  const captureSeq = parseInt(rawSeq, 10);
  if (!rawSeq || isNaN(captureSeq) || captureSeq <= 0 || String(captureSeq) !== rawSeq) {
    sendError(res, 404, `Scorecard history entry not found: "${rawSeq}" is not a valid captureSeq`);
    return;
  }
  const detail = getGovernanceScorecardHistoryDetail(captureSeq);
  if (detail === null) {
    sendError(res, 404, `Scorecard history entry not found: captureSeq ${captureSeq} is not in the retained ring (max 10)`);
    return;
  }
  sendJson(res, 200, detail);
}

export function handleScorecardAnalytics(_req: IncomingMessage, res: ServerResponse): void {
  const result = getWorkspaceGovernanceScorecardAnalytics();
  sendJson(res, 200, result);
}

export function handleLedgerAnalytics(_req: IncomingMessage, res: ServerResponse): void {
  const result = getWorkspaceObservationLedgerAnalytics();
  sendJson(res, 200, result);
}

export function handleVisualShell(_req: IncomingMessage, res: ServerResponse): void {
  const result = getWorkspaceVisualShell();
  sendJson(res, 200, result);
}

export function handleVisualShellComposed(_req: IncomingMessage, res: ServerResponse): void {
  const result = getWorkspaceVisualShellComposed();
  sendJson(res, 200, result);
}

export function handleWidgetValidationProbe(_req: IncomingMessage, res: ServerResponse): void {
  const result = runWidgetValidationProbe();
  sendJson(res, 200, result);
}

export function handleWidgetValidationCapture(_req: IncomingMessage, res: ServerResponse): void {
  const result = captureWidgetValidationSnapshot();
  sendJson(res, 201, result);
}

export function handleWidgetValidationHistory(_req: IncomingMessage, res: ServerResponse): void {
  const result = listWidgetValidationHistory();
  sendJson(res, 200, result);
}

export function handleWidgetValidationHistoryDetail(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // /api/workspace/visual-shell/widgets/validate/history/:captureSeq → last segment
  const rawSeq = segments[segments.length - 1] ?? "";
  const captureSeq = parseInt(rawSeq, 10);
  if (!rawSeq || isNaN(captureSeq) || captureSeq <= 0 || String(captureSeq) !== rawSeq) {
    sendError(res, 404, `Validation history entry not found: "${rawSeq}" is not a valid captureSeq`);
    return;
  }
  const detail = getWidgetValidationHistoryDetail(captureSeq);
  if (detail === null) {
    sendError(res, 404, `Validation history entry not found: captureSeq ${captureSeq} is not in the retained ring (max 10)`);
    return;
  }
  sendJson(res, 200, detail);
}

export function handleWidgetRegistryCoherence(_req: IncomingMessage, res: ServerResponse): void {
  const result = runWidgetRegistryValidation();
  sendJson(res, 200, result);
}

export function handleWidgetContractList(_req: IncomingMessage, res: ServerResponse): void {
  const result = listWidgetContracts();
  sendJson(res, 200, result);
}

export function handleWidgetContractById(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // /api/workspace/visual-shell/widgets/:widgetId → last segment
  const widgetId = decodeURIComponent(segments[segments.length - 1] ?? "");

  if (!widgetId) {
    sendError(res, 400, "Widget ID is required");
    return;
  }

  const contract = getWidgetContract(widgetId);
  if (contract === null) {
    sendError(
      res,
      404,
      `Widget contract not found: "${widgetId}". Check GET /api/workspace/visual-shell/widgets for available widget IDs.`,
    );
    return;
  }

  sendJson(res, 200, contract);
}

export function handleAuditReportById(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  // /api/workspace/audit/reports/:reportId → last segment
  const reportId = decodeURIComponent(segments[segments.length - 1] ?? "");

  if (!reportId) {
    sendError(res, 400, "Report ID is required");
    return;
  }

  const report = getAuditReportById(reportId);
  if (report === null) {
    sendError(
      res,
      404,
      `Audit report not found: "${reportId}". Check GET /api/workspace/audit/reports for available IDs.`,
    );
    return;
  }

  sendJson(res, 200, report);
}
