// Workspace Dashboard Skeleton — Phase 130
// Derives a structured dashboard composition blueprint from the existing Visual Shell
// (15 panels, 37 widgets, 5 navigation groups).
// No HTML generation, no CSS generation, no JSX, no rendering engines, no mutation paths,
// no interactive actions, no user action handlers, no secrets exposure.
// Pure static + light derivation — deterministic shape, bounded output.

import { getWorkspaceVisualShell } from "./workspaceVisualShell";
import type { SectionId, VisualPanel, WidgetType, WidgetSize } from "./workspaceVisualShell";

const EXECUTION_BLOCKED: true = true;
const DASHBOARD_VERSION = "1" as const;

// ---------------------------------------------------------------------------
// Panel → primary page mapping
// Each panel has one primary page assignment.
// pageLayouts may reference a panel across multiple pages — these assignments
// determine where the panelLayout "lives" for skeleton hierarchy purposes.
// ---------------------------------------------------------------------------

const PANEL_PRIMARY_PAGE: Readonly<Record<string, string>> = {
  "governance-overview":  "governance",
  "policy-compliance":    "governance",
  "exposure-risk":        "governance",
  "observation-heatmap":  "observation",
  "coverage-trend":       "observation",
  "observation-probe":    "observation",
  "ledger-analytics":     "observation",
  "system-health":        "diagnostics",
  "runtime-metrics":      "diagnostics",
  "event-detection":      "diagnostics",
  "project-registry":     "overview",
  "workspace-membership": "overview",
  "workspace-timeline":   "overview",
  "change-detection":     "comparison",
  "audit-trail":          "comparison",
};

// Width token derived from widget recommendedSize
const SIZE_WIDTH: Readonly<Record<WidgetSize, string>> = {
  small:  "col-1",
  medium: "col-2",
  large:  "col-3",
  full:   "col-4",
};

// Height token derived from widget recommendedSize
const SIZE_HEIGHT: Readonly<Record<WidgetSize, string>> = {
  small:  "row-1",
  medium: "row-1",
  large:  "row-2",
  full:   "row-2",
};

// Priority within a panel (1 = highest visual priority)
const WIDGET_TYPE_PRIORITY: Readonly<Record<WidgetType, number>> = {
  badge:     1,
  status:    1,
  metric:    2,
  gauge:     3,
  scorecard: 4,
  table:     5,
  list:      6,
  chart:     7,
  heatmap:   8,
  timeline:  9,
};

// Render density derived from widget size
const SIZE_DENSITY: Readonly<Record<WidgetSize, string>> = {
  small:  "compact",
  medium: "standard",
  large:  "standard",
  full:   "expanded",
};

// Card style per section
const SECTION_CARD_STYLE: Readonly<Record<SectionId, string>> = {
  governance:  "elevated",
  observation: "elevated",
  diagnostics: "outlined",
  projects:    "flat",
  activity:    "flat",
};

// Layout direction per section
const SECTION_LAYOUT_DIRECTION: Readonly<Record<SectionId, string>> = {
  governance:  "column",
  observation: "column",
  diagnostics: "row",
  projects:    "row",
  activity:    "column",
};

// ---------------------------------------------------------------------------
// Type definitions
// ---------------------------------------------------------------------------

export interface DashboardShell {
  shellType: string;
  shellMode: string;
  sidebarCollapsedDefault: boolean;
  topbarVisible: boolean;
  contentPadding: string;
  executionBlocked: true;
}

export interface DashboardTopbar {
  appTitle: string;
  breadcrumbEnabled: boolean;
  searchEnabled: boolean;
  actionsEnabled: boolean;
  executionBlocked: true;
}

export interface SidebarNavigationItem {
  itemId: string;
  title: string;
  endpoint: string;
  itemOrder: number;
  executionBlocked: true;
}

export interface SidebarNavigationGroup {
  groupId: string;
  title: string;
  groupOrder: number;
  items: SidebarNavigationItem[];
  executionBlocked: true;
}

export interface DashboardSidebar {
  navigationGroups: SidebarNavigationGroup[];
  defaultPage: string;
  iconMode: string;
  collapseAllowed: boolean;
  executionBlocked: true;
}

export interface LayoutRegion {
  regionId: string;
  role: string;
  order: number;
  executionBlocked: true;
}

export interface LayoutRegions {
  regions: LayoutRegion[];
  totalRegions: number;
  executionBlocked: true;
}

export interface PageLayout {
  pageId: string;
  pageTitle: string;
  regionOrder: string[];
  panelIds: string[];
  layoutStyle: string;
  executionBlocked: true;
}

export interface PanelLayout {
  panelId: string;
  pageId: string;
  region: string;
  widgetIds: string[];
  cardStyle: string;
  layoutDirection: string;
  executionBlocked: true;
}

export interface WidgetLayoutEntry {
  widgetId: string;
  pageId: string;
  panelId: string;
  width: string;
  height: string;
  priority: number;
  renderDensity: string;
  executionBlocked: true;
}

export interface ResponsiveBreakpoint {
  minWidth: string;
  columns: number;
  sidebarVisible: boolean;
  executionBlocked: true;
}

export interface ResponsiveRules {
  desktop: ResponsiveBreakpoint;
  tablet: ResponsiveBreakpoint;
  mobile: ResponsiveBreakpoint;
  collapseBehavior: string;
  maxColumns: number;
  executionBlocked: true;
}

export interface WorkspaceDashboardSkeleton {
  generatedAt: string;
  dashboardVersion: typeof DASHBOARD_VERSION;
  shell: DashboardShell;
  sidebar: DashboardSidebar;
  topbar: DashboardTopbar;
  layoutRegions: LayoutRegions;
  pageLayouts: PageLayout[];
  panelLayouts: PanelLayout[];
  widgetLayouts: WidgetLayoutEntry[];
  responsiveRules: ResponsiveRules;
  executionBlocked: true;
}

// ---------------------------------------------------------------------------
// Static constants
// ---------------------------------------------------------------------------

const STATIC_SHELL: DashboardShell = {
  shellType:              "operator_dashboard",
  shellMode:              "full",
  sidebarCollapsedDefault: false,
  topbarVisible:          true,
  contentPadding:         "24px",
  executionBlocked:       EXECUTION_BLOCKED,
};

const STATIC_TOPBAR: DashboardTopbar = {
  appTitle:          "Bulldozer",
  breadcrumbEnabled: true,
  searchEnabled:     false,
  actionsEnabled:    false,
  executionBlocked:  EXECUTION_BLOCKED,
};

const STATIC_LAYOUT_REGIONS: LayoutRegions = {
  regions: [
    { regionId: "header",    role: "topbar",      order: 1, executionBlocked: EXECUTION_BLOCKED },
    { regionId: "sidebar",   role: "navigation",  order: 2, executionBlocked: EXECUTION_BLOCKED },
    { regionId: "main",      role: "content",     order: 3, executionBlocked: EXECUTION_BLOCKED },
    { regionId: "statusbar", role: "statusbar",   order: 4, executionBlocked: EXECUTION_BLOCKED },
  ],
  totalRegions: 4,
  executionBlocked: EXECUTION_BLOCKED,
};

const STATIC_RESPONSIVE_RULES: ResponsiveRules = {
  desktop:          { minWidth: "1280px", columns: 4, sidebarVisible: true,  executionBlocked: EXECUTION_BLOCKED },
  tablet:           { minWidth: "768px",  columns: 2, sidebarVisible: false, executionBlocked: EXECUTION_BLOCKED },
  mobile:           { minWidth: "320px",  columns: 1, sidebarVisible: false, executionBlocked: EXECUTION_BLOCKED },
  collapseBehavior: "stack",
  maxColumns:       4,
  executionBlocked: EXECUTION_BLOCKED,
};

// Static page layout definitions — panel assignment per page.
// Panels may be referenced by multiple pages; each panel has one primary pageId
// in panelLayouts. regionOrder lists the region sequence for each page view.
const PAGE_LAYOUT_DEFS: ReadonlyArray<{
  pageId: string; pageTitle: string;
  regionOrder: string[]; panelIds: string[]; layoutStyle: string;
}> = [
  {
    pageId:      "overview",
    pageTitle:   "Overview",
    regionOrder: ["header", "sidebar", "main"],
    panelIds:    ["governance-overview", "observation-heatmap", "system-health", "project-registry", "workspace-timeline"],
    layoutStyle: "grid_3col",
  },
  {
    pageId:      "governance",
    pageTitle:   "Governance",
    regionOrder: ["header", "sidebar", "main"],
    panelIds:    ["governance-overview", "policy-compliance", "exposure-risk"],
    layoutStyle: "grid_2col",
  },
  {
    pageId:      "observation",
    pageTitle:   "Observation",
    regionOrder: ["header", "sidebar", "main"],
    panelIds:    ["observation-heatmap", "coverage-trend", "observation-probe", "ledger-analytics"],
    layoutStyle: "grid_2col",
  },
  {
    pageId:      "diagnostics",
    pageTitle:   "Diagnostics",
    regionOrder: ["header", "sidebar", "main"],
    panelIds:    ["system-health", "runtime-metrics", "event-detection"],
    layoutStyle: "grid_3col",
  },
  {
    pageId:      "comparison",
    pageTitle:   "Comparison",
    regionOrder: ["header", "sidebar", "main"],
    panelIds:    ["governance-overview", "observation-heatmap", "change-detection", "audit-trail"],
    layoutStyle: "grid_2col",
  },
];

// ---------------------------------------------------------------------------
// Derivation functions
// ---------------------------------------------------------------------------

function deriveSidebar(panels: readonly VisualPanel[]): DashboardSidebar {
  const shell = getWorkspaceVisualShell();
  const groups: SidebarNavigationGroup[] = shell.navigationGroups.map((g) => ({
    groupId:   g.groupId,
    title:     g.title,
    groupOrder: g.groupOrder,
    items: g.items.map((item) => ({
      itemId:    item.itemId,
      title:     item.title,
      endpoint:  item.endpoint,
      itemOrder: item.itemOrder,
      executionBlocked: EXECUTION_BLOCKED,
    })),
    executionBlocked: EXECUTION_BLOCKED,
  }));
  // suppress unused variable warning — panels param kept for future use
  void panels;
  return {
    navigationGroups: groups,
    defaultPage:      "overview",
    iconMode:         "icon_and_label",
    collapseAllowed:  true,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function derivePageLayouts(): PageLayout[] {
  return PAGE_LAYOUT_DEFS.map((def) => ({
    pageId:      def.pageId,
    pageTitle:   def.pageTitle,
    regionOrder: def.regionOrder,
    panelIds:    def.panelIds,
    layoutStyle: def.layoutStyle,
    executionBlocked: EXECUTION_BLOCKED,
  }));
}

function derivePanelLayouts(panels: readonly VisualPanel[]): PanelLayout[] {
  return panels.map((p) => ({
    panelId:         p.panelId,
    pageId:          PANEL_PRIMARY_PAGE[p.panelId] ?? "overview",
    region:          "main",
    widgetIds:       p.widgets.map((w) => w.widgetId),
    cardStyle:       SECTION_CARD_STYLE[p.sectionId] ?? "elevated",
    layoutDirection: SECTION_LAYOUT_DIRECTION[p.sectionId] ?? "column",
    executionBlocked: EXECUTION_BLOCKED,
  }));
}

function deriveWidgetLayouts(panels: readonly VisualPanel[]): WidgetLayoutEntry[] {
  const entries: WidgetLayoutEntry[] = [];
  for (const panel of panels) {
    const pageId = PANEL_PRIMARY_PAGE[panel.panelId] ?? "overview";
    for (const widget of panel.widgets) {
      const size = widget.recommendedSize;
      entries.push({
        widgetId:      widget.widgetId,
        pageId,
        panelId:       panel.panelId,
        width:         SIZE_WIDTH[size]  ?? "col-2",
        height:        SIZE_HEIGHT[size] ?? "row-1",
        priority:      WIDGET_TYPE_PRIORITY[widget.widgetType as WidgetType] ?? 5,
        renderDensity: SIZE_DENSITY[size] ?? "standard",
        executionBlocked: EXECUTION_BLOCKED,
      });
    }
  }
  return entries;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
// Pure read-only derivation. No HTML, no CSS, no JSX, no rendering engines.
// O(15) panel scan + O(37) widget scan. Deterministic ordering throughout.
// No persistence mutation. No mutation handlers. No interactive actions.
// executionBlocked: true at every level.

export function getDashboardSkeleton(): WorkspaceDashboardSkeleton {
  const shell = getWorkspaceVisualShell();
  const panels = shell.panels;

  const sidebar     = deriveSidebar(panels);
  const pageLayouts = derivePageLayouts();
  const panelLayouts = derivePanelLayouts(panels);
  const widgetLayouts = deriveWidgetLayouts(panels);

  return {
    generatedAt:      new Date().toISOString(),
    dashboardVersion: DASHBOARD_VERSION,
    shell:            STATIC_SHELL,
    sidebar,
    topbar:           STATIC_TOPBAR,
    layoutRegions:    STATIC_LAYOUT_REGIONS,
    pageLayouts,
    panelLayouts,
    widgetLayouts,
    responsiveRules:  STATIC_RESPONSIVE_RULES,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
