// Plugin Observe Route — Phase 205
// GET /api/plugins/registry
// Read-only diagnostic view of the in-memory plugin metadata registry.
// No plugin execution, no registration route, no enable/disable route,
// no code/script/command/path exposure, no filesystem access,
// no network access, no vault access.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { listPluginMetadata, getPluginSummary } from "../core/pluginCore";

export function handlePluginObserve(_req: IncomingMessage, res: ServerResponse): void {
  const plugins = listPluginMetadata();
  const summary = getPluginSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    executionEnabled:   false,
    persistenceEnabled: false,
    executionBlocked:   true,
    totalPlugins:       plugins.length,
    summary,
    plugins,
  });
}
