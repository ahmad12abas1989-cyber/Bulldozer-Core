import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";

export type CrashDetectorStatus = "stable" | "warning" | "crashed";

export interface CrashState {
  status: CrashDetectorStatus;
  crashCount: number;
  warningCount: number;
  lastCrashAt: string | null;
  lastWarningAt: string | null;
  lastCrashType: string | null;
  lastCrashMessage: string | null;
  timestamp: string;
}

let currentStatus: CrashDetectorStatus = "stable";
let crashCount = 0;
let warningCount = 0;
let lastCrashAt: string | null = null;
let lastWarningAt: string | null = null;
let lastCrashType: string | null = null;
let lastCrashMessage: string | null = null;

let active = false;

function onUncaughtException(err: Error): void {
  const now = new Date().toISOString();
  crashCount++;
  lastCrashAt = now;
  lastCrashType = "uncaughtException";
  lastCrashMessage = err?.message ?? String(err);
  currentStatus = "crashed";
  addTimelineEvent({ level: "error", source: "crash-detector", message: "Uncaught exception detected", metadata: { type: "uncaughtException", err: String(err) } });
  emit("crash:exception", "crash-detector", { type: "uncaughtException", err: String(err) });
  logger.error(
    { type: "uncaughtException", err: String(err) },
    "Uncaught exception detected",
  );
}

function onUnhandledRejection(reason: unknown): void {
  const now = new Date().toISOString();
  crashCount++;
  lastCrashAt = now;
  lastCrashType = "unhandledRejection";
  lastCrashMessage = reason instanceof Error ? reason.message : String(reason);
  currentStatus = "crashed";
  addTimelineEvent({ level: "error", source: "crash-detector", message: "Unhandled rejection detected", metadata: { type: "unhandledRejection", reason: String(reason) } });
  emit("crash:rejection", "crash-detector", { type: "unhandledRejection", reason: String(reason) });
  logger.error(
    { type: "unhandledRejection", reason: String(reason) },
    "Unhandled rejection detected",
  );
}

function onWarning(warning: Error): void {
  const now = new Date().toISOString();
  warningCount++;
  lastWarningAt = now;
  if (currentStatus === "stable") currentStatus = "warning";
  addTimelineEvent({ level: "warn", source: "crash-detector", message: "Process warning detected", metadata: { name: warning.name, detail: warning.message } });
  emit("crash:warning", "crash-detector", { name: warning.name, message: warning.message });
  logger.warn(
    { type: "warning", name: warning.name, message: warning.message },
    "Process warning detected",
  );
}

export function startCrashDetector(): void {
  if (active) return;
  active = true;
  process.on("uncaughtException", onUncaughtException);
  process.on("unhandledRejection", onUnhandledRejection);
  process.on("warning", onWarning);
  logger.info("Crash detector started");
}

export function stopCrashDetector(): void {
  if (!active) return;
  active = false;
  process.removeListener("uncaughtException", onUncaughtException);
  process.removeListener("unhandledRejection", onUnhandledRejection);
  process.removeListener("warning", onWarning);
  logger.info("Crash detector stopped");
}

export function getCrashStatus(): CrashState {
  return {
    status: currentStatus,
    crashCount,
    warningCount,
    lastCrashAt,
    lastWarningAt,
    lastCrashType,
    lastCrashMessage,
    timestamp: new Date().toISOString(),
  };
}
