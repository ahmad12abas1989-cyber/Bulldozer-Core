#!/usr/bin/env bash
# deploy/scripts/restore.sh
# Restore Bulldozer Mother Core persistent storage from a backup archive.
# Usage:
#   ./restore.sh /opt/bulldozer/backups/bulldozer-backup-20260515T120000Z.tar.gz
#
# SAFETY:
#   - The container MUST be stopped before running this script.
#   - The existing storage directory is renamed (not deleted) before restore.
#   - If restore fails the renamed directory can be moved back manually.
#   - Verifies SHA-256 checksum if a .sha256 sidecar file is present.
#   - Does NOT mutate any Mother Core sealed cores.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPLOY_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ENV_FILE="${DEPLOY_DIR}/.env"

# Load config
if [[ -f "${ENV_FILE}" ]]; then
  set -o allexport
  # shellcheck disable=SC1090
  source <(grep -E '^[A-Z_]+=' "${ENV_FILE}" | sed 's/#.*//')
  set +o allexport
fi

STORAGE_PATH="${STORAGE_PATH:-/opt/bulldozer/storage}"
ARCHIVE="${1:-}"

if [[ -z "${ARCHIVE}" ]]; then
  echo "Usage: $0 <path-to-backup-archive.tar.gz>"
  exit 1
fi

if [[ ! -f "${ARCHIVE}" ]]; then
  echo "[bulldozer] ERROR: Archive not found: ${ARCHIVE}"
  exit 1
fi

echo "[bulldozer] Restore starting"
echo "[bulldozer]   Archive : ${ARCHIVE}"
echo "[bulldozer]   Target  : ${STORAGE_PATH}"

# Verify checksum if sidecar exists
CHECKSUM_FILE="${ARCHIVE}.sha256"
if [[ -f "${CHECKSUM_FILE}" ]]; then
  echo "[bulldozer] Verifying checksum..."
  sha256sum --check "${CHECKSUM_FILE}"
  echo "[bulldozer] Checksum OK."
else
  echo "[bulldozer] WARNING: No .sha256 sidecar found — skipping checksum verification."
fi

# Confirm container is not running
if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "bulldozer-core"; then
  echo "[bulldozer] ERROR: Container 'bulldozer-core' is still running."
  echo "[bulldozer]   Stop it first:  ./stop.sh"
  exit 1
fi

# Rename existing storage as a safety net
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_EXISTING="${STORAGE_PATH}.pre-restore-${TIMESTAMP}"
if [[ -d "${STORAGE_PATH}" ]]; then
  echo "[bulldozer] Renaming existing storage to: ${BACKUP_EXISTING}"
  mv "${STORAGE_PATH}" "${BACKUP_EXISTING}"
fi

# Extract archive
echo "[bulldozer] Extracting archive..."
mkdir -p "$(dirname "${STORAGE_PATH}")"
tar -xzf "${ARCHIVE}" -C "$(dirname "${STORAGE_PATH}")"

# Fix ownership — bulldozer user inside container is UID 1000
chown -R 1000:1000 "${STORAGE_PATH}" 2>/dev/null || \
  echo "[bulldozer] WARNING: Could not chown storage — run 'sudo chown -R 1000:1000 ${STORAGE_PATH}' if needed."

echo ""
echo "[bulldozer] Restore complete."
echo "[bulldozer]   Previous storage preserved at: ${BACKUP_EXISTING}"
echo "[bulldozer]   Start the server with: ./start.sh"
echo "[bulldozer]   Run health checks with: ./health-check.sh"
