import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson, sendError } from "../lib/response";
import { readJsonBody } from "../lib/body";
import {
  getFilteredSnapshots,
  type SnapshotFilter,
  getRuntimeSnapshot,
  createRuntimeSnapshot,
  validateRuntimeSnapshot,
  compareSnapshots,
  dryRunRecovery,
  estimateRecoveryImpact,
} from "../core/runtimeSnapshot";

const MAX_LIMIT = 100;
const DEFAULT_LIMIT = 50;

function decodeParam(raw: string): string | null {
  try {
    const decoded = decodeURIComponent(raw).trim();
    return decoded.length > 0 ? decoded : null;
  } catch {
    return null;
  }
}

export function handleRuntimeSnapshotsList(
  req: IncomingMessage,
  res: ServerResponse,
): void {
  const rawUrl = req.url ?? "";
  const qIdx = rawUrl.indexOf("?");
  const queryString = qIdx >= 0 ? rawUrl.slice(qIdx + 1) : "";
  const params = new URLSearchParams(queryString);

  const filter: SnapshotFilter = {};

  for (const [key, raw] of params.entries()) {
    const decoded = decodeParam(raw);
    if (decoded === null) continue;
    switch (key) {
      case "status":
        filter.status = decoded;
        break;
      case "triggeredBy":
        filter.triggeredBy = decoded;
        break;
      case "snapshotType":
        filter.snapshotType = decoded;
        break;
      case "subsystem":
        filter.subsystem = decoded;
        break;
      case "limit": {
        const n = parseInt(decoded, 10);
        if (!isNaN(n) && n > 0) filter.limit = Math.min(n, MAX_LIMIT);
        break;
      }
      default:
        break;
    }
  }

  if (filter.limit === undefined) filter.limit = DEFAULT_LIMIT;

  const result = getFilteredSnapshots(filter);
  sendJson(res, 200, result);
}

export function handleRuntimeSnapshotById(
  req: IncomingMessage,
  res: ServerResponse,
): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const snapshotId = segments[segments.length - 1] ?? "";

  if (!snapshotId || !/^[0-9a-f]{16}$/.test(snapshotId)) {
    sendError(res, 400, 'Invalid snapshot ID — must be a 16-character hex string');
    return;
  }

  const snapshot = getRuntimeSnapshot(snapshotId);
  if (!snapshot) {
    sendError(res, 404, `Snapshot not found: ${snapshotId}`);
    return;
  }

  sendJson(res, 200, snapshot);
}

export async function handleRuntimeSnapshotsCreate(
  req: IncomingMessage,
  res: ServerResponse,
): Promise<void> {
  let body: Record<string, unknown> = {};

  try {
    body = (await readJsonBody(req)) as Record<string, unknown>;
  } catch {
    sendError(res, 400, "Invalid JSON body");
    return;
  }

  const reason =
    typeof body["reason"] === "string" && body["reason"].trim().length > 0
      ? body["reason"].trim()
      : "manual";

  if (reason.length > 200) {
    sendError(res, 400, 'Field "reason" must not exceed 200 characters');
    return;
  }

  try {
    const snapshot = createRuntimeSnapshot(reason);
    sendJson(res, 201, {
      id: snapshot.id,
      status: snapshot.status,
      reason: snapshot.reason,
      createdAt: snapshot.createdAt,
      endpointCount: snapshot.endpointCount,
      healthCheckCount: snapshot.healthCheckCount,
      overallHealth: snapshot.healthSummary.overallStatus,
      executionBlocked: snapshot.executionBlocked,
    });
  } catch (err) {
    sendError(res, 500, `Snapshot creation failed: ${String(err)}`);
  }
}

export async function handleRuntimeRecoveryDryRun(
  req: IncomingMessage,
  res: ServerResponse,
): Promise<void> {
  let body: Record<string, unknown> = {};

  try {
    body = (await readJsonBody(req)) as Record<string, unknown>;
  } catch {
    sendError(res, 400, "Invalid JSON body");
    return;
  }

  const snapshotId = body["snapshotId"];

  if (typeof snapshotId !== "string" || snapshotId.trim().length === 0) {
    sendError(res, 400, 'Field "snapshotId" is required and must be a non-empty string');
    return;
  }

  const trimmedId = snapshotId.trim();

  if (!/^[0-9a-f]{16}$/.test(trimmedId)) {
    sendError(res, 400, 'Field "snapshotId" must be a 16-character hex string');
    return;
  }

  const action = typeof body["action"] === "string" ? body["action"].trim() : "dry-run";

  if (action === "validate") {
    const validation = validateRuntimeSnapshot(trimmedId);
    sendJson(res, 200, validation);
    return;
  }

  if (action === "impact") {
    const impact = estimateRecoveryImpact(trimmedId);
    sendJson(res, 200, impact);
    return;
  }

  if (action === "compare") {
    const snapshotIdB = body["snapshotIdB"];
    if (typeof snapshotIdB !== "string" || !/^[0-9a-f]{16}$/.test(snapshotIdB.trim())) {
      sendError(
        res,
        400,
        'Field "snapshotIdB" is required for compare action and must be a 16-character hex string',
      );
      return;
    }
    const comparison = compareSnapshots(trimmedId, snapshotIdB.trim());
    sendJson(res, 200, comparison);
    return;
  }

  const result = dryRunRecovery(trimmedId);
  sendJson(res, 200, result);
}
