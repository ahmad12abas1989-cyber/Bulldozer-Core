// runtimeWriteExecutorCore.ts
// Phase 318 — Runtime Write Executor Core Skeleton
// In-memory runtime write executor descriptor engine.
// Layer 25 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation stack.
// Defines the first runtime write executor model.
// Preserves sandbox-approved-only target scope from layer 24.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executorEnabled=false — executor has not been enabled.
// runtimeWriteExecutorPrepared=true — descriptor-readiness established for a future first sandbox write commit phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstActualSandboxWriteOperationRecord } from "./firstActualSandboxWriteOperationCore.js";
import type { ActualSandboxWriteExecutionGateRecord }   from "./actualSandboxWriteExecutionGateCore.js";
import type { FirstScopedSandboxWriteActivationRecord } from "./firstScopedSandboxWriteActivationCore.js";
import type { ActualSandboxWritePermissionGateRecord }  from "./actualSandboxWritePermissionGateCore.js";
import type { FirstActualSandboxMutationSwitchRecord }  from "./firstActualSandboxMutationSwitchCore.js";
import type { ControlledExecutionRecord }               from "./controlledExecutionCore.js";
import { randomUUID }                                   from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type RuntimeWriteExecutorState = "descriptor_runtime_write_executor_pending";

export type ExecutorSafetyCheckRule =
  | "actual_write_operation_exists"
  | "execution_gate_exists"
  | "scoped_activation_exists"
  | "permission_gate_exists"
  | "mutation_switch_exists"
  | "execution_record_exists"
  | "write_operation_bound_to_execution_gate"
  | "execution_gate_bound_to_scoped_activation"
  | "scoped_activation_bound_to_permission_gate"
  | "permission_gate_bound_to_mutation_switch"
  | "executor_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface ExecutorSafetyCheck {
  readonly rule: ExecutorSafetyCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface ExecutorPlanEntry {
  readonly planEntryId:       string;
  readonly targetScope:       "sandbox_approved_only";
  readonly operationType:     "descriptor_executor_planned";
  readonly executorEnabled:   false;
  readonly mutationBlocked:   true;
  readonly planNote:          string;
}

export interface ExecutorBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedExecutorReference {
  readonly actualWriteOperationId:       string;
  readonly writeExecutionGateId:         string;
  readonly scopedWriteActivationId:      string;
  readonly writePermissionGateId:        string;
  readonly rollbackSnapshotId:           string;
  readonly runtimeWriteExecutorPrepared: true;
  readonly runtimeWriteExecutorEnabled:  false;
  readonly actualWritesEnabled:          false;
  readonly rollbackChainValid:           boolean;
  readonly referenceNote:                string;
}

export interface ExecutorReadinessReport {
  readonly runtimeWriteExecutorPrepared:  true;
  readonly runtimeWriteExecutorEnabled:   false;
  readonly writeExecutionGateEnabled:     false;
  readonly scopedActivationEnabled:       false;
  readonly writePermissionEnabled:        false;
  readonly mutationSwitchEnabled:         false;
  readonly guardedWriteEnabled:           false;
  readonly actualWritesEnabled:           false;
  readonly realWritesEnabled:             false;
  readonly approvalRequired:              true;
  readonly allChecksPass:                 boolean;
  readonly blockedReasonCount:            number;
  readonly rollbackChainValid:            boolean;
  readonly summary:                       string;
}

export interface RuntimeWriteExecutorRecord {
  readonly runtimeWriteExecutorId:       string;
  readonly executorState:                RuntimeWriteExecutorState;
  readonly approvalRequired:             true;
  readonly runtimeWriteExecutorPrepared: true;
  readonly runtimeWriteExecutorEnabled:  false;
  readonly actualWritesEnabled:          false;
  readonly filesystemMutationBlocked:    true;
  readonly motherCoreMutationBlocked:    true;
  readonly vaultMutationBlocked:         true;
  readonly shellBlocked:                 true;
  readonly networkBlocked:               true;
  readonly implementationPhase:          "descriptor_only";
  readonly actualWriteOperationId:       string;
  readonly writeExecutionGateId:         string;
  readonly scopedWriteActivationId:      string;
  readonly writePermissionGateId:        string;
  readonly mutationSwitchId:             string;
  readonly controlledExecutionId:        string;
  readonly executorPlan:                 readonly ExecutorPlanEntry[];
  readonly executorSafetyChecks:         readonly ExecutorSafetyCheck[];
  readonly executorBlockedReasons:       readonly ExecutorBlockedReason[];
  readonly linkedExecutorReference:      LinkedExecutorReference;
  readonly executorReadinessReport:      ExecutorReadinessReport;
  readonly createdAt:                    string;
}

export interface CreateRuntimeWriteExecutorInput {
  readonly writeOperationRecord:      FirstActualSandboxWriteOperationRecord;
  readonly writeExecutionGateRecord:  ActualSandboxWriteExecutionGateRecord;
  readonly scopedActivationRecord:    FirstScopedSandboxWriteActivationRecord;
  readonly writePermissionGateRecord: ActualSandboxWritePermissionGateRecord;
  readonly mutationSwitchRecord:      FirstActualSandboxMutationSwitchRecord;
  readonly executionRecord:           ControlledExecutionRecord;
}

export interface RuntimeWriteExecutorSummary {
  readonly total:                        number;
  readonly byState:                      Record<RuntimeWriteExecutorState, number>;
  readonly runtimeWriteExecutorPrepared: true;
  readonly runtimeWriteExecutorEnabled:  false;
  readonly actualWritesEnabled:          false;
  readonly approvalRequired:             true;
  readonly filesystemMutationBlocked:    true;
  readonly motherCoreMutationBlocked:    true;
  readonly executorState:                RuntimeWriteExecutorState;
  readonly implementationPhase:          "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: RuntimeWriteExecutorRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildSafetyChecks(input: CreateRuntimeWriteExecutorInput): readonly ExecutorSafetyCheck[] {
  const { writeOperationRecord, writeExecutionGateRecord, scopedActivationRecord, writePermissionGateRecord, mutationSwitchRecord, executionRecord } = input;

  const opExists      = writeOperationRecord.actualWriteOperationId.length > 0;
  const gateExists    = writeExecutionGateRecord.writeExecutionGateId.length > 0;
  const scopedExists  = scopedActivationRecord.scopedWriteActivationId.length > 0;
  const permExists    = writePermissionGateRecord.writePermissionGateId.length > 0;
  const switchExists  = mutationSwitchRecord.mutationSwitchId.length > 0;
  const execExists    = executionRecord.controlledExecutionId.length > 0;

  const opBound      = writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId;
  const gateBound    = writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId;
  const scopedBound  = scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId;
  const permBound    = writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId;

  return [
    {
      rule: "actual_write_operation_exists",
      pass: opExists,
      note: opExists
        ? `actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`
        : "writeOperationRecord.actualWriteOperationId is empty",
    },
    {
      rule: "execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`
        : "writeExecutionGateRecord.writeExecutionGateId is empty",
    },
    {
      rule: "scoped_activation_exists",
      pass: scopedExists,
      note: scopedExists
        ? `scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`
        : "scopedActivationRecord.scopedWriteActivationId is empty",
    },
    {
      rule: "permission_gate_exists",
      pass: permExists,
      note: permExists
        ? `writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`
        : "writePermissionGateRecord.writePermissionGateId is empty",
    },
    {
      rule: "mutation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`
        : "mutationSwitchRecord.mutationSwitchId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: execExists,
      note: execExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "write_operation_bound_to_execution_gate",
      pass: opBound,
      note: opBound
        ? `writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId (${writeExecutionGateRecord.writeExecutionGateId})`
        : `write-operation/execution-gate mismatch: op.writeExecutionGateId=${writeOperationRecord.writeExecutionGateId} vs gate.writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`,
    },
    {
      rule: "execution_gate_bound_to_scoped_activation",
      pass: gateBound,
      note: gateBound
        ? `writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId (${scopedActivationRecord.scopedWriteActivationId})`
        : `execution-gate/scoped-activation mismatch: gate.scopedWriteActivationId=${writeExecutionGateRecord.scopedWriteActivationId} vs scoped.scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`,
    },
    {
      rule: "scoped_activation_bound_to_permission_gate",
      pass: scopedBound,
      note: scopedBound
        ? `scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId (${writePermissionGateRecord.writePermissionGateId})`
        : `scoped-activation/permission-gate mismatch: scoped.writePermissionGateId=${scopedActivationRecord.writePermissionGateId} vs gate.writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`,
    },
    {
      rule: "permission_gate_bound_to_mutation_switch",
      pass: permBound,
      note: permBound
        ? `writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId (${mutationSwitchRecord.mutationSwitchId})`
        : `permission-gate/mutation-switch mismatch: gate.mutationSwitchId=${writePermissionGateRecord.mutationSwitchId} vs switch.mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`,
    },
    {
      rule: "executor_still_disabled",
      pass: true,
      note: "runtimeWriteExecutorEnabled=false — compile-time literal; no executor enable phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "executorState=descriptor_runtime_write_executor_pending — output is a descriptor only; runtime write executor is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly ExecutorSafetyCheck[]): readonly ExecutorBlockedReason[] {
  const staticReasons: ExecutorBlockedReason[] = [
    { code: "executor_disabled",      reason: "runtimeWriteExecutorEnabled=false — compile-time literal; an explicit sandbox write commit phase must enable the executor before any sandbox write target can be touched",                                                                                                                           static: true },
    { code: "approval_required",      reason: "approvalRequired=true — explicit operator approval is required before the runtime write executor can be enabled",                                                                                                                                                                                    static: true },
    { code: "actual_writes_disabled", reason: "actualWritesEnabled=false — compile-time literal across all 25 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, and write-operation layers", static: true },
  ];
  const dynamicReasons: ExecutorBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedExecutorReference(
  input: CreateRuntimeWriteExecutorInput,
  rollbackChainValid: boolean,
): LinkedExecutorReference {
  const { writeOperationRecord, writeExecutionGateRecord, scopedActivationRecord, writePermissionGateRecord } = input;
  return {
    actualWriteOperationId:        writeOperationRecord.actualWriteOperationId,
    writeExecutionGateId:          writeExecutionGateRecord.writeExecutionGateId,
    scopedWriteActivationId:       scopedActivationRecord.scopedWriteActivationId,
    writePermissionGateId:         writePermissionGateRecord.writePermissionGateId,
    rollbackSnapshotId:            writeOperationRecord.rollbackOperationReference.rollbackSnapshotId,
    runtimeWriteExecutorPrepared:  true,
    runtimeWriteExecutorEnabled:   false,
    actualWritesEnabled:           false,
    rollbackChainValid,
    referenceNote: "linked executor reference sources rollbackSnapshotId from writeOperationRecord.rollbackOperationReference; runtime write executor disabled; filesystem mutation blocked; descriptor-only",
  };
}

function buildExecutorPlan(): readonly ExecutorPlanEntry[] {
  return [
    {
      planEntryId:     randomUUID(),
      targetScope:     "sandbox_approved_only",
      operationType:   "descriptor_executor_planned",
      executorEnabled: false,
      mutationBlocked: true,
      planNote:        "Executor plan inherits sandbox_approved_only target scope from layer 24 write operation plan. Executor disabled. No filesystem mutation until an explicit sandbox write commit phase enables the executor. descriptor_runtime_write_executor_pending state — plan captured as descriptor only.",
    },
  ];
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createRuntimeWriteExecutorRecord(
  input: CreateRuntimeWriteExecutorInput,
): RuntimeWriteExecutorRecord {
  const { writeOperationRecord, writeExecutionGateRecord, scopedActivationRecord, writePermissionGateRecord, mutationSwitchRecord, executionRecord } = input;

  const checks = buildSafetyChecks(input);

  const rollbackChainValid = writeOperationRecord.writeOperationReadinessReport.rollbackChainValid;

  const allChecksPass   = checks.every((c) => c.pass);
  const blockedReasons  = buildBlockedReasons(checks);
  const linkedRef       = buildLinkedExecutorReference(input, rollbackChainValid);
  const plan            = buildExecutorPlan();

  const executorReadinessReport: ExecutorReadinessReport = {
    runtimeWriteExecutorPrepared:  true,
    runtimeWriteExecutorEnabled:   false,
    writeExecutionGateEnabled:     false,
    scopedActivationEnabled:       false,
    writePermissionEnabled:        false,
    mutationSwitchEnabled:         false,
    guardedWriteEnabled:           false,
    actualWritesEnabled:           false,
    realWritesEnabled:             false,
    approvalRequired:              true,
    allChecksPass,
    blockedReasonCount:            blockedReasons.length,
    rollbackChainValid,
    summary: `executorState=descriptor_runtime_write_executor_pending; runtimeWriteExecutorEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: RuntimeWriteExecutorRecord = {
    runtimeWriteExecutorId:        randomUUID(),
    executorState:                 "descriptor_runtime_write_executor_pending",
    approvalRequired:              true,
    runtimeWriteExecutorPrepared:  true,
    runtimeWriteExecutorEnabled:   false,
    actualWritesEnabled:           false,
    filesystemMutationBlocked:     true,
    motherCoreMutationBlocked:     true,
    vaultMutationBlocked:          true,
    shellBlocked:                  true,
    networkBlocked:                true,
    implementationPhase:           "descriptor_only",
    actualWriteOperationId:        writeOperationRecord.actualWriteOperationId,
    writeExecutionGateId:          writeExecutionGateRecord.writeExecutionGateId,
    scopedWriteActivationId:       scopedActivationRecord.scopedWriteActivationId,
    writePermissionGateId:         writePermissionGateRecord.writePermissionGateId,
    mutationSwitchId:              mutationSwitchRecord.mutationSwitchId,
    controlledExecutionId:         executionRecord.controlledExecutionId,
    executorPlan:                  plan,
    executorSafetyChecks:          checks,
    executorBlockedReasons:        blockedReasons,
    linkedExecutorReference:       linkedRef,
    executorReadinessReport,
    createdAt:                     new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listRuntimeWriteExecutorRecords(): readonly RuntimeWriteExecutorRecord[] {
  return _store.slice();
}

export function getRuntimeWriteExecutorSummary(): RuntimeWriteExecutorSummary {
  return {
    total:                          _store.length,
    byState:                        { descriptor_runtime_write_executor_pending: _store.length },
    runtimeWriteExecutorPrepared:   true,
    runtimeWriteExecutorEnabled:    false,
    actualWritesEnabled:            false,
    approvalRequired:               true,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    executorState:                  "descriptor_runtime_write_executor_pending",
    implementationPhase:            "descriptor_only",
  };
}
