import { randomBytes } from "node:crypto";
import { readStore, writeStore } from "./persistentStore";
import { logger } from "../lib/logger";
import {
  getWorkspaceSnapshotById,
  listWorkspaceSnapshots,
} from "./workspaceSnapshots";
import { getWorkspaceDiff } from "./workspaceDiff";
import { getWorkspaceTimeline } from "./workspaceTimeline";
import { getWorkspaceHealth, getWorkspaceSummary } from "./workspaceShell";

const EXECUTION_BLOCKED: true = true;
const MAX_REPORTS = 10;
const STORE_KEY = "workspace-audit-reports";
const TIMELINE_EXCERPT_SIZE = 20;

// --- Types ---

export type AuditReportType =
  | "snapshot_comparison"
  | "timeline_summary"
  | "governance_review";

export const VALID_REPORT_TYPES = new Set<string>([
  "snapshot_comparison",
  "timeline_summary",
  "governance_review",
]);

export interface AuditSnapshotRef {
  snapshotId: string;
  createdAt: string;
  projectCount: number;
  memberCount: number;
  activityCount: number;
}

export interface AuditDiffSummary {
  diffId: string;
  fromSnapshotId: string;
  toSnapshotId: string;
  timeDeltaMs: number;
  timeDeltaSeconds: number;
  hasChanges: boolean;
  changeCount: number;
  totalProjectsDelta: number;
  memberRecordsDelta: number;
  activityRecordsDelta: number;
  customQuotaProjectsDelta: number;
  newlyObservedProjectCount: number;
}

export interface AuditTimelineEventItem {
  eventId: string;
  eventType: string;
  source: string;
  projectId: string | null;
  projectName: string | null;
  occurredAt: string;
  summary: string;
}

export interface AuditTimelineExcerpt {
  totalEvents: number;
  excerptSize: number;
  recentEvents: AuditTimelineEventItem[];
  eventTypeCounts: Record<string, number>;
}

export interface AuditDiagnosticsHealth {
  status: string;
  registryOperational: boolean;
  totalProjects: number;
  totalMembers: number;
  totalActivityRecords: number;
  customQuotaProjects: number;
  storeKeyCount: number;
}

export interface AuditGovernanceSummary {
  totalProjects: number;
  activeProjects: number;
  archivedProjects: number;
  suspendedProjects: number;
  memberRecords: number;
  activityRecords: number;
  projectsWithCustomQuotas: number;
  projectsUsingDefaults: number;
  capacityUtilizationPercent: number;
  atCapacity: boolean;
}

export interface WorkspaceAuditReport {
  reportId: string;
  createdAt: string;
  reportType: AuditReportType;
  snapshotRefs: AuditSnapshotRef[];
  diffSummary: AuditDiffSummary | null;
  timelineExcerpt: AuditTimelineExcerpt;
  diagnosticsHealth: AuditDiagnosticsHealth;
  governanceSummary: AuditGovernanceSummary;
  note: string;
  executionBlocked: true;
}

export interface WorkspaceAuditReportListItem {
  reportId: string;
  createdAt: string;
  reportType: AuditReportType;
  hasChanges: boolean | null;
  changeCount: number | null;
  snapshotRefCount: number;
  timelineEventCount: number;
  executionBlocked: true;
}

export interface AuditReportFilter {
  reportType?: AuditReportType;
  hasChanges?: boolean;
  since?: string;
  limit: number;
}

export interface WorkspaceAuditReportListResult {
  checkedAt: string;
  reports: WorkspaceAuditReportListItem[];
  count: number;
  totalBeforeFilter: number;
  maxRetained: number;
  loadedOnBoot: number;
  filtersApplied: string[];
  executionBlocked: true;
}

export interface AuditReportCreateParams {
  reportType: AuditReportType;
  fromSnapshotId?: string;
  toSnapshotId?: string;
}

// --- In-memory state ---

let reportRing: WorkspaceAuditReport[] = [];
let loadedOnBoot = 0;
let isInitialized = false;

// --- Internal helpers ---

function persist(): void {
  writeStore<WorkspaceAuditReport[]>(STORE_KEY, reportRing);
}

function isValidStoredReport(obj: unknown): obj is WorkspaceAuditReport {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  const r = obj as Record<string, unknown>;
  return (
    typeof r["reportId"] === "string" &&
    r["reportId"].length > 0 &&
    typeof r["createdAt"] === "string" &&
    r["createdAt"].length > 0 &&
    typeof r["reportType"] === "string" &&
    r["executionBlocked"] === true &&
    r["timelineExcerpt"] !== null &&
    typeof r["timelineExcerpt"] === "object" &&
    r["governanceSummary"] !== null &&
    typeof r["governanceSummary"] === "object"
  );
}

function buildSnapshotRef(snapshotId: string): AuditSnapshotRef | null {
  const snap = getWorkspaceSnapshotById(snapshotId);
  if (!snap) return null;
  return {
    snapshotId: snap.snapshotId,
    createdAt: snap.createdAt,
    projectCount: snap.summary.projects.total,
    memberCount: snap.summary.members.totalRecords,
    activityCount: snap.summary.activity.totalRecords,
  };
}

function buildTimelineExcerpt(): AuditTimelineExcerpt {
  const result = getWorkspaceTimeline({ limit: TIMELINE_EXCERPT_SIZE });
  const eventTypeCounts: Record<string, number> = {};
  for (const e of result.events) {
    eventTypeCounts[e.eventType] = (eventTypeCounts[e.eventType] ?? 0) + 1;
  }
  const recentEvents: AuditTimelineEventItem[] = result.events.map((e) => ({
    eventId: e.eventId,
    eventType: e.eventType,
    source: e.source,
    projectId: e.projectId,
    projectName: e.projectName,
    occurredAt: e.occurredAt,
    summary: e.summary,
  }));
  return {
    totalEvents: result.totalBeforeFilter,
    excerptSize: recentEvents.length,
    recentEvents,
    eventTypeCounts,
  };
}

function buildDiagnosticsHealth(): AuditDiagnosticsHealth {
  const health = getWorkspaceHealth();
  return {
    status: health.status,
    registryOperational: health.registryOperational,
    totalProjects: health.totalProjects,
    totalMembers: health.totalMembers,
    totalActivityRecords: health.totalActivityRecords,
    customQuotaProjects: health.customQuotaProjects,
    storeKeyCount: health.storeKeyCount,
  };
}

function buildGovernanceSummary(): AuditGovernanceSummary {
  const summary = getWorkspaceSummary();
  return {
    totalProjects: summary.projects.total,
    activeProjects: summary.projects.active,
    archivedProjects: summary.projects.archived,
    suspendedProjects: summary.projects.suspended,
    memberRecords: summary.members.totalRecords,
    activityRecords: summary.activity.totalRecords,
    projectsWithCustomQuotas: summary.quotas.projectsWithCustomQuotas,
    projectsUsingDefaults: summary.quotas.projectsUsingDefaults,
    capacityUtilizationPercent: summary.capacity.utilizationPercent,
    atCapacity: summary.capacity.atCapacity,
  };
}

// --- Public API ---

export function initWorkspaceAuditReports(): void {
  if (isInitialized) return;

  const stored = readStore<unknown[]>(STORE_KEY);
  if (Array.isArray(stored)) {
    const valid = stored.filter(isValidStoredReport);
    reportRing = valid.slice(-MAX_REPORTS);
    loadedOnBoot = reportRing.length;
    if (valid.length !== stored.length) {
      logger.warn(
        { total: stored.length, valid: valid.length, key: STORE_KEY },
        "Audit report load: skipped invalid entries on boot",
      );
    }
  }

  isInitialized = true;
  logger.info(
    {
      subsystem: "workspace_audit_reports",
      loadedOnBoot,
      maxRetained: MAX_REPORTS,
      storeKey: STORE_KEY,
    },
    "Workspace audit report store initialized",
  );
}

export function createAuditReport(
  params: AuditReportCreateParams,
): { report: WorkspaceAuditReport } | { error: string; status: 400 | 404 } {
  const { reportType, fromSnapshotId, toSnapshotId } = params;

  const snapshotRefs: AuditSnapshotRef[] = [];
  let diffSummary: AuditDiffSummary | null = null;
  let note: string;

  if (reportType === "snapshot_comparison") {
    if (!fromSnapshotId || !toSnapshotId) {
      return {
        error:
          'reportType "snapshot_comparison" requires both fromSnapshotId and toSnapshotId in the request body',
        status: 400,
      };
    }

    const fromRef = buildSnapshotRef(fromSnapshotId);
    if (!fromRef) {
      return {
        error: `Snapshot not found: "${fromSnapshotId}". Check GET /api/workspace/snapshots for available IDs.`,
        status: 404,
      };
    }
    const toRef = buildSnapshotRef(toSnapshotId);
    if (!toRef) {
      return {
        error: `Snapshot not found: "${toSnapshotId}". Check GET /api/workspace/snapshots for available IDs.`,
        status: 404,
      };
    }

    snapshotRefs.push(fromRef, toRef);

    const diffOutcome = getWorkspaceDiff(fromSnapshotId, toSnapshotId);
    if ("error" in diffOutcome) {
      return { error: diffOutcome.error, status: diffOutcome.status };
    }

    const d = diffOutcome.result;
    diffSummary = {
      diffId: d.diffId,
      fromSnapshotId: d.from.snapshotId,
      toSnapshotId: d.to.snapshotId,
      timeDeltaMs: d.timeDeltaMs,
      timeDeltaSeconds: d.timeDeltaSeconds,
      hasChanges: d.hasChanges,
      changeCount: d.changeCount,
      totalProjectsDelta: d.summaryDelta.totalProjects.delta,
      memberRecordsDelta: d.summaryDelta.memberRecords.delta,
      activityRecordsDelta: d.summaryDelta.activityRecords.delta,
      customQuotaProjectsDelta: d.summaryDelta.customQuotaProjects.delta,
      newlyObservedProjectCount: d.projectChanges.newlyObservedCount,
    };

    note = `Snapshot comparison audit report. Comparing snapshot ${fromSnapshotId} (from) → ${toSnapshotId} (to). Execution is blocked — this is an immutable read-only governance record.`;
  } else if (reportType === "timeline_summary") {
    note =
      "Timeline summary audit report. Aggregates the most recent workspace events across all projects and workspace-level operations. Execution is blocked — this is an immutable read-only governance record.";
  } else {
    // governance_review
    const listing = listWorkspaceSnapshots();
    if (listing.snapshots.length > 0) {
      const latest = listing.snapshots[0]!;
      snapshotRefs.push({
        snapshotId: latest.snapshotId,
        createdAt: latest.createdAt,
        projectCount: latest.projectCount,
        memberCount: latest.memberCount,
        activityCount: latest.activityCount,
      });
    }
    note =
      "Governance review audit report. Aggregates current workspace governance state — project counts, quota adoption, membership totals, activity totals. Execution is blocked — this is an immutable read-only governance record.";
  }

  const reportId = randomBytes(8).toString("hex");
  const createdAt = new Date().toISOString();

  const report: WorkspaceAuditReport = {
    reportId,
    createdAt,
    reportType,
    snapshotRefs,
    diffSummary,
    timelineExcerpt: buildTimelineExcerpt(),
    diagnosticsHealth: buildDiagnosticsHealth(),
    governanceSummary: buildGovernanceSummary(),
    note,
    executionBlocked: EXECUTION_BLOCKED,
  };

  reportRing.push(report);
  while (reportRing.length > MAX_REPORTS) {
    reportRing.shift();
  }
  persist();

  logger.info(
    {
      reportId,
      reportType,
      createdAt,
      ringSize: reportRing.length,
      executionBlocked: EXECUTION_BLOCKED,
    },
    "Workspace audit report created",
  );

  return { report };
}

const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 10;

export function listAuditReports(
  filter: AuditReportFilter = { limit: DEFAULT_LIMIT },
): WorkspaceAuditReportListResult {
  const filtersApplied: string[] = [];

  // Newest-first ordering — reverse of ring insertion order
  let pool: WorkspaceAuditReport[] = reportRing.slice().reverse();
  const totalBeforeFilter = pool.length;

  // ?reportType — invalid value silently ignored (not in VALID_REPORT_TYPES)
  if (filter.reportType !== undefined && VALID_REPORT_TYPES.has(filter.reportType)) {
    pool = pool.filter((r) => r.reportType === filter.reportType);
    filtersApplied.push(`reportType=${filter.reportType}`);
  }

  // ?hasChanges — only meaningful for snapshot_comparison; null reports excluded by either value
  if (filter.hasChanges !== undefined) {
    pool = pool.filter((r) => r.diffSummary?.hasChanges === filter.hasChanges);
    filtersApplied.push(`hasChanges=${String(filter.hasChanges)}`);
  }

  // ?since — ISO date floor; invalid dates silently ignored
  if (filter.since !== undefined) {
    const sinceMs = Date.parse(filter.since);
    if (!isNaN(sinceMs)) {
      pool = pool.filter((r) => Date.parse(r.createdAt) >= sinceMs);
      filtersApplied.push(`since=${filter.since}`);
    }
  }

  // ?limit — default 10, max 10; out-of-range silently clamped to default
  const effectiveLimit = filter.limit > 0 && filter.limit <= MAX_LIMIT
    ? filter.limit
    : DEFAULT_LIMIT;

  const limited = pool.slice(0, effectiveLimit);

  const items: WorkspaceAuditReportListItem[] = limited.map((r) => ({
    reportId: r.reportId,
    createdAt: r.createdAt,
    reportType: r.reportType,
    hasChanges: r.diffSummary?.hasChanges ?? null,
    changeCount: r.diffSummary?.changeCount ?? null,
    snapshotRefCount: r.snapshotRefs.length,
    timelineEventCount: r.timelineExcerpt.totalEvents,
    executionBlocked: EXECUTION_BLOCKED,
  }));

  return {
    checkedAt: new Date().toISOString(),
    reports: items,
    count: items.length,
    totalBeforeFilter,
    maxRetained: MAX_REPORTS,
    loadedOnBoot,
    filtersApplied,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getAuditReportById(
  reportId: string,
): WorkspaceAuditReport | null {
  return reportRing.find((r) => r.reportId === reportId) ?? null;
}
