import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { getDiagnosticsSnapshot } from "../core/diagnostics";

export function handleDiagnosticsSnapshot(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getDiagnosticsSnapshot());
}
