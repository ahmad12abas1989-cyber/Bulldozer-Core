import { randomBytes } from "node:crypto";

export interface BusEvent {
  id: string;
  timestamp: string;
  eventName: string;
  source: string;
  payload: Record<string, unknown>;
  requestId?: string;
}

export type EventHandler = (event: BusEvent) => void;

export interface EventBusStats {
  totalEmitted: number;
  activeSubscriptions: number;
  lastEvent: BusEvent | null;
  eventCounts: Record<string, number>;
  timestamp: string;
}

const subscriptions = new Map<string, Set<EventHandler>>();
let totalEmitted = 0;
const eventCounts: Record<string, number> = {};
let lastEvent: BusEvent | null = null;

export function emit(
  eventName: string,
  source: string,
  payload: Record<string, unknown> = {},
  requestId?: string,
): BusEvent {
  const event: BusEvent = {
    id: randomBytes(4).toString("hex"),
    timestamp: new Date().toISOString(),
    eventName,
    source,
    payload,
  };

  if (requestId != null) event.requestId = requestId;

  totalEmitted++;
  eventCounts[eventName] = (eventCounts[eventName] ?? 0) + 1;
  lastEvent = event;

  const handlers = subscriptions.get(eventName);
  if (handlers) {
    for (const handler of handlers) {
      try {
        handler(event);
      } catch {
        // handler errors are swallowed — the bus never throws
      }
    }
  }

  return event;
}

export function subscribe(eventName: string, handler: EventHandler): void {
  let handlers = subscriptions.get(eventName);
  if (!handlers) {
    handlers = new Set();
    subscriptions.set(eventName, handlers);
  }
  handlers.add(handler);
}

export function unsubscribe(eventName: string, handler: EventHandler): void {
  const handlers = subscriptions.get(eventName);
  if (!handlers) return;
  handlers.delete(handler);
  if (handlers.size === 0) subscriptions.delete(eventName);
}

export function getEventStats(): EventBusStats {
  let activeSubscriptions = 0;
  for (const handlers of subscriptions.values()) {
    activeSubscriptions += handlers.size;
  }
  return {
    totalEmitted,
    activeSubscriptions,
    lastEvent,
    eventCounts: { ...eventCounts },
    timestamp: new Date().toISOString(),
  };
}
