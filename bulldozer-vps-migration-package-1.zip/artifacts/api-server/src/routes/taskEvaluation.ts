import type { IncomingMessage, ServerResponse } from "node:http";
import { getTaskEvaluationStatus } from "../core/taskEvaluation";
import { sendJson } from "../lib/response";

export function handleTaskEvaluation(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getTaskEvaluationStatus());
}
