import { listSubsystemStates } from "./runtimeStateRegistry";
import { logger } from "../lib/logger";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { emitRuntimeEvent } from "./runtimeEventBus";

export interface SubsystemCapabilities {
  read: string[];
  write: string[];
  emit: string[];
  subscribe: string[];
  access: string[];
}

export interface CapabilityRecord {
  subsystemName: string;
  category: string;
  capabilities: SubsystemCapabilities;
  executionBlocked: true;
  recoveryBlocked: true;
  version: 1;
}

export interface CapabilityValidationDetail {
  subsystemName: string;
  invalidReadRefs: string[];
  invalidWriteRefs: string[];
}

export interface CapabilityMatrixStatus {
  operational: boolean;
  totalSubsystems: number;
  totalReadCapabilities: number;
  totalWriteCapabilities: number;
  totalEmitCapabilities: number;
  totalSubscribeCapabilities: number;
  totalAccessCapabilities: number;
  validationStatus: "valid" | "invalid" | "unchecked";
  invalidReferenceCount: number;
  invalidReferences: string[];
  validationDetails: CapabilityValidationDetail[];
  executionBlocked: true;
  recoveryBlocked: true;
  timestamp: string;
}

const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;
const RECORD_VERSION = 1 as const;

const VALID_INFRASTRUCTURE_REFS = new Set([
  "event_bus",
  "timeline",
  "runtime_event_bus",
  "storage:snapshots",
  "storage:tasks",
  "storage:runtime-state",
  "storage:store",
  "node:fs",
  "node:http",
  "node:env",
  "node:process",
  "node:crypto",
]);

const SEED_CAPABILITIES: Array<{
  subsystemName: string;
  category: string;
  capabilities: SubsystemCapabilities;
}> = [
  {
    subsystemName: "runtime",
    category: "core",
    capabilities: {
      read: ["node:env", "node:process"],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: [
        "runtime:started",
        "runtime:ready",
        "runtime:stopping",
        "runtime:stopped",
        "runtime:failed",
      ],
      subscribe: [],
      access: ["node:process"],
    },
  },
  {
    subsystemName: "health_monitor",
    category: "core",
    capabilities: {
      read: [
        "runtime",
        "task_queue",
        "task_policy",
        "task_evaluation",
        "task_persistence",
        "queue_orchestration",
        "task_lifecycle",
        "runtime_snapshot",
        "runtime_event_bus",
        "command_gateway",
        "runtime_state_registry",
        "runtime_dependency_graph",
        "runtime_capability_matrix",
        "hardening",
        "secure_config",
        "watchdog",
        "restart_supervisor",
        "plugin_sandbox",
        "recovery_tracker",
        "project_registry",
      ],
      write: [],
      emit: [],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "task_queue",
    category: "queue",
    capabilities: {
      read: ["runtime"],
      write: ["event_bus", "timeline"],
      emit: [
        "task_queue:created",
        "task_queue:updated",
        "task_queue:loaded",
        "task_queue:pruned",
      ],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "task_policy",
    category: "queue",
    capabilities: {
      read: ["task_queue"],
      write: ["event_bus", "timeline"],
      emit: [
        "task_policy:evaluated",
        "task_policy:blocked",
        "task_policy:allowed",
        "task_policy:approval_required",
      ],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "task_evaluation",
    category: "queue",
    capabilities: {
      read: ["task_queue", "task_policy"],
      write: ["event_bus", "timeline"],
      emit: ["task_evaluation:evaluated", "task_evaluation:blocked"],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "task_persistence",
    category: "queue",
    capabilities: {
      read: ["task_queue"],
      write: ["event_bus", "timeline", "storage:tasks"],
      emit: [
        "task_persistence:saved",
        "task_persistence:loaded",
        "task_persistence:pruned",
      ],
      subscribe: [],
      access: ["node:fs"],
    },
  },
  {
    subsystemName: "queue_orchestration",
    category: "queue",
    capabilities: {
      read: ["task_queue", "task_policy"],
      write: ["event_bus", "timeline"],
      emit: ["queue_orchestration:scanned", "queue_orchestration:planned"],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "task_lifecycle",
    category: "queue",
    capabilities: {
      read: ["task_queue", "task_policy"],
      write: ["event_bus", "timeline"],
      emit: [
        "task_lifecycle:transition_requested",
        "task_lifecycle:transition_accepted",
        "task_lifecycle:transition_rejected",
      ],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "runtime_snapshot",
    category: "snapshot",
    capabilities: {
      read: [
        "runtime",
        "task_queue",
        "task_lifecycle",
        "task_policy",
        "queue_orchestration",
        "task_persistence",
      ],
      write: ["event_bus", "timeline", "storage:snapshots"],
      emit: [
        "runtime_snapshot:created",
        "runtime_snapshot:archived",
        "runtime_snapshot:recovery_dry_run",
      ],
      subscribe: [],
      access: ["node:fs"],
    },
  },
  {
    subsystemName: "runtime_event_bus",
    category: "events",
    capabilities: {
      read: ["event_bus"],
      write: ["timeline"],
      emit: [
        "runtime_event_bus:initialized",
        "runtime_event_bus:dispatch_failure",
      ],
      subscribe: [
        "runtime:*",
        "task_queue:*",
        "task_policy:*",
        "task_evaluation:*",
        "task_persistence:*",
        "task_lifecycle:*",
        "watchdog:*",
        "command_gateway:*",
        "runtime_snapshot:*",
      ],
      access: [],
    },
  },
  {
    subsystemName: "command_gateway",
    category: "commands",
    capabilities: {
      read: [],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: [
        "command_gateway:initialized",
        "command_gateway:received",
        "command_gateway:evaluated",
        "command_gateway:blocked",
        "command_gateway:approval_required",
      ],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "hardening",
    category: "security",
    capabilities: {
      read: ["node:http"],
      write: ["event_bus", "timeline"],
      emit: ["hardening:violation_blocked", "hardening:violation_warned"],
      subscribe: [],
      access: ["node:http"],
    },
  },
  {
    subsystemName: "secure_config",
    category: "security",
    capabilities: {
      read: ["node:env"],
      write: ["event_bus", "timeline"],
      emit: ["secure_config:validated", "secure_config:warning"],
      subscribe: [],
      access: ["node:env"],
    },
  },
  {
    subsystemName: "watchdog",
    category: "monitoring",
    capabilities: {
      read: ["runtime"],
      write: ["event_bus", "timeline"],
      emit: [
        "watchdog:heartbeat",
        "watchdog:degraded",
        "watchdog:recovered",
        "watchdog:event",
      ],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "restart_supervisor",
    category: "monitoring",
    capabilities: {
      read: ["watchdog"],
      write: ["event_bus", "timeline"],
      emit: ["restart_supervisor:recommendation_updated"],
      subscribe: ["watchdog:*"],
      access: [],
    },
  },
  {
    subsystemName: "plugin_sandbox",
    category: "plugins",
    capabilities: {
      read: ["runtime"],
      write: ["event_bus", "timeline"],
      emit: ["plugin_sandbox:registered", "plugin_sandbox:denied"],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "recovery_tracker",
    category: "recovery",
    capabilities: {
      read: [],
      write: ["timeline"],
      emit: [],
      subscribe: [
        "runtime_event_bus:*",
        "crash_detector:*",
        "freeze_detector:*",
      ],
      access: [],
    },
  },
  {
    subsystemName: "runtime_state_registry",
    category: "meta",
    capabilities: {
      read: [],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["runtime_state_registry:initialized"],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "runtime_dependency_graph",
    category: "meta",
    capabilities: {
      read: ["runtime_state_registry"],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["runtime_dependency_graph:initialized"],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "runtime_capability_matrix",
    category: "meta",
    capabilities: {
      read: ["runtime_state_registry"],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["runtime_capability_matrix:initialized"],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "identity_access",
    category: "identity",
    capabilities: {
      read: ["runtime_state_registry"],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["identity_access:initialized"],
      subscribe: [],
      access: ["node:env"],
    },
  },
  {
    subsystemName: "access_enforcement",
    category: "enforcement",
    capabilities: {
      read: ["identity_access", "runtime_state_registry"],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["access_enforcement:initialized"],
      subscribe: [],
      access: ["node:env"],
    },
  },
  {
    subsystemName: "audit_log",
    category: "observability",
    capabilities: {
      read: ["access_enforcement", "runtime_state_registry"],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["audit_log:initialized", "audit_log:entry_appended"],
      subscribe: [],
      access: ["node:crypto"],
    },
  },
  {
    subsystemName: "session_context",
    category: "observability",
    capabilities: {
      read: ["identity_access", "runtime_state_registry"],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["session_context:initialized", "session_context:created"],
      subscribe: [],
      access: ["node:crypto"],
    },
  },
  {
    subsystemName: "request_lifecycle_ledger",
    category: "observability",
    capabilities: {
      read: ["session_context", "audit_log", "runtime_state_registry"],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["request_lifecycle_ledger:initialized", "request_lifecycle_ledger:record_appended"],
      subscribe: [],
      access: ["node:crypto"],
    },
  },
  {
    subsystemName: "persistent_store",
    category: "infrastructure",
    capabilities: {
      read: ["node:fs"],
      write: ["node:fs", "storage:store", "event_bus", "timeline", "runtime_event_bus"],
      emit: ["persistent_store:initialized", "persistent_store:written", "persistent_store:deleted"],
      subscribe: [],
      access: [],
    },
  },
  {
    subsystemName: "project_registry",
    category: "workspace",
    capabilities: {
      read: [],
      write: ["event_bus", "timeline", "runtime_event_bus"],
      emit: ["project_registry:initialized", "project_registry:created"],
      subscribe: [],
      access: ["node:crypto"],
    },
  },
];

const records = new Map<string, CapabilityRecord>();
let validationDetails: CapabilityValidationDetail[] = [];
let invalidReferenceCount = 0;
let isOperational = false;

function validateRecords(knownSubsystems: Set<string>): void {
  const validRefs = new Set([...knownSubsystems, ...VALID_INFRASTRUCTURE_REFS]);
  const details: CapabilityValidationDetail[] = [];
  let totalInvalid = 0;

  for (const record of records.values()) {
    const invalidReadRefs = record.capabilities.read.filter(
      (r) => !validRefs.has(r),
    );
    const invalidWriteRefs = record.capabilities.write.filter(
      (w) => !validRefs.has(w),
    );

    if (invalidReadRefs.length > 0 || invalidWriteRefs.length > 0) {
      details.push({
        subsystemName: record.subsystemName,
        invalidReadRefs,
        invalidWriteRefs,
      });
      totalInvalid += invalidReadRefs.length + invalidWriteRefs.length;
    }
  }

  validationDetails = details;
  invalidReferenceCount = totalInvalid;
}

export function initCapabilityMatrix(): void {
  const states = listSubsystemStates();
  const knownSubsystems = new Set(states.map((s) => s.subsystemName));

  for (const seed of SEED_CAPABILITIES) {
    const record: CapabilityRecord = {
      subsystemName: seed.subsystemName,
      category: seed.category,
      capabilities: {
        read: [...seed.capabilities.read],
        write: [...seed.capabilities.write],
        emit: [...seed.capabilities.emit],
        subscribe: [...seed.capabilities.subscribe],
        access: [...seed.capabilities.access],
      },
      executionBlocked: EXECUTION_BLOCKED,
      recoveryBlocked: RECOVERY_BLOCKED,
      version: RECORD_VERSION,
    };
    records.set(seed.subsystemName, record);
  }

  validateRecords(knownSubsystems);

  isOperational = true;

  const hasCycles = invalidReferenceCount > 0;

  emit("runtime_capability_matrix:initialized", "runtime-capability-matrix", {
    totalSubsystems: records.size,
    invalidReferenceCount,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "runtime_capability_matrix.initialized",
    source: "runtime-capability-matrix",
    severity: hasCycles ? "warning" : "info",
    category: "runtime",
    payload: {
      totalSubsystems: records.size,
      invalidReferenceCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  addTimelineEvent({
    level: hasCycles ? "warn" : "info",
    source: "runtime-capability-matrix",
    message: `Runtime capability matrix initialized — ${records.size} subsystems${invalidReferenceCount > 0 ? `, ${invalidReferenceCount} invalid reference(s)` : ", all references valid"}`,
    metadata: {
      totalSubsystems: records.size,
      invalidReferenceCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    {
      totalSubsystems: records.size,
      invalidReferenceCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
    "Runtime capability matrix initialized",
  );
}

export function getCapabilityRecord(subsystemName: string): CapabilityRecord | null {
  return records.get(subsystemName) ?? null;
}

export function listCapabilityRecords(): CapabilityRecord[] {
  return Array.from(records.values()).sort((a, b) =>
    a.subsystemName.localeCompare(b.subsystemName),
  );
}

export function getCapabilityMatrixStatus(): CapabilityMatrixStatus {
  const all = Array.from(records.values());

  let totalRead = 0;
  let totalWrite = 0;
  let totalEmit = 0;
  let totalSubscribe = 0;
  let totalAccess = 0;

  for (const r of all) {
    totalRead += r.capabilities.read.length;
    totalWrite += r.capabilities.write.length;
    totalEmit += r.capabilities.emit.length;
    totalSubscribe += r.capabilities.subscribe.length;
    totalAccess += r.capabilities.access.length;
  }

  const allInvalidRefs: string[] = validationDetails.flatMap((d) => [
    ...d.invalidReadRefs.map((r) => `${d.subsystemName}:read:${r}`),
    ...d.invalidWriteRefs.map((w) => `${d.subsystemName}:write:${w}`),
  ]);

  const validationStatus: "valid" | "invalid" | "unchecked" = !isOperational
    ? "unchecked"
    : invalidReferenceCount > 0
      ? "invalid"
      : "valid";

  return {
    operational: isOperational,
    totalSubsystems: records.size,
    totalReadCapabilities: totalRead,
    totalWriteCapabilities: totalWrite,
    totalEmitCapabilities: totalEmit,
    totalSubscribeCapabilities: totalSubscribe,
    totalAccessCapabilities: totalAccess,
    validationStatus,
    invalidReferenceCount,
    invalidReferences: allInvalidRefs,
    validationDetails,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}
