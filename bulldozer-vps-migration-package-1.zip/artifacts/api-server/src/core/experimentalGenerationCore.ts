// Experimental Generation Core — Phase 216
// In-memory, virtual-output-only generation registry.
// Pure module — no init, not wired to runtime.ts, not wired to any request flow.
// No filesystem writes, no package installation, no runtime execution, no deployment,
// no sandbox execution, no plugin execution, no vault access. Virtual outputs only.

import { randomBytes } from "node:crypto";

// ─── Types ────────────────────────────────────────────────────────────────────

// Scope is intentionally locked to crud_app + crud_template only (Phase 215).
export type ExperimentalGenerationAppType     = "crud_app";
export type ExperimentalGenerationTemplateType = "crud_template";

export type ExperimentalGenerationStatus =
  | "receive_project_spec"
  | "select_template"
  | "generate_virtual_structure"
  | "validate_structure"
  | "produce_artifact_summary"
  | "operator_review"
  | "approved"
  | "rejected";

// A single entry in the virtual file map — path descriptor + content descriptor.
// No real file content, no executable code, no install commands, no shell commands.
export interface VirtualFileRecord {
  readonly virtualPath: string;          // e.g. "src/routes/items.ts"
  readonly fileType: string;             // e.g. "route", "model", "config"
  readonly contentDescriptor: string;    // human-readable description of what the file declares
}

// A single declared HTTP route for the generated app.
export interface VirtualRouteRecord {
  readonly method: string;               // e.g. "GET"
  readonly path: string;                 // e.g. "/api/items"
  readonly description: string;
}

// Top-level artifact summary — structural metadata, no code.
export interface ArtifactSummary {
  readonly packageName: string;
  readonly appType: ExperimentalGenerationAppType;
  readonly templateType: ExperimentalGenerationTemplateType;
  readonly version: string;
  readonly fileCount: number;
  readonly routeCount: number;
}

// Stage-by-stage structural validation results — no execution output.
export interface ValidationReport {
  readonly passed: boolean;
  readonly checks: ReadonlyArray<{ readonly check: string; readonly result: "pass" | "fail" | "skipped"; readonly note?: string }>;
}

// A single generation run record — all outputs are virtual/in-memory descriptors.
export interface ExperimentalGenerationRecord {
  readonly generationId: string;                         // server-generated 16-byte hex
  readonly appType: ExperimentalGenerationAppType;       // always "crud_app"
  readonly templateType: ExperimentalGenerationTemplateType; // always "crud_template"
  readonly projectName: string;
  readonly requestedByActorType: string;
  readonly requestedByActorId: string;
  readonly status: "generate_virtual_structure";         // always at creation; transitions are future-phase
  readonly virtualFileTree: readonly VirtualFileRecord[];
  readonly routeList: readonly VirtualRouteRecord[];
  readonly schemaSummary: string;                        // text descriptor — no schema execution
  readonly artifactSummary: ArtifactSummary;
  readonly validationReport: ValidationReport;
  readonly executionBlocked: true;                       // literal
  readonly deploymentBlocked: true;                      // literal
  readonly createdAt: string;                            // server-generated ISO 8601
}

// Input accepted from callers — structurally excludes:
// code, files, command, script, shellCommand, installCommand, deployFlag, secretValue
export interface CreateExperimentalGenerationInput {
  readonly projectName: string;
  readonly requestedByActorType: string;
  readonly requestedByActorId: string;
}

export interface ExperimentalGenerationSummary {
  readonly totalRuns: number;
  readonly byStatus: Record<ExperimentalGenerationStatus, number>;
  readonly pendingReviewCount: number;    // status === "operator_review" (always 0 until future phase)
  readonly appType: ExperimentalGenerationAppType;
  readonly templateType: ExperimentalGenerationTemplateType;
  readonly executionEnabled: false;       // literal
  readonly deploymentEnabled: false;      // literal
  readonly persistenceEnabled: false;     // literal
  readonly implementationPhase: "skeleton"; // literal
}

// ─── In-memory store ──────────────────────────────────────────────────────────

const store: ExperimentalGenerationRecord[] = [];

// ─── Helpers — virtual structure generators ───────────────────────────────────

function buildVirtualFileTree(projectName: string): readonly VirtualFileRecord[] {
  const slug = projectName.toLowerCase().replace(/\s+/g, "-");
  return [
    { virtualPath: `src/index.ts`,                  fileType: "entry",   contentDescriptor: "Server entry point — boots HTTP server" },
    { virtualPath: `src/server.ts`,                 fileType: "server",  contentDescriptor: "node:http server with request router" },
    { virtualPath: `src/routes/${slug}.ts`,         fileType: "route",   contentDescriptor: `CRUD routes for ${projectName} resource (GET list, GET by id, POST, PATCH, DELETE)` },
    { virtualPath: `src/core/${slug}Store.ts`,       fileType: "store",   contentDescriptor: `In-memory store for ${projectName} records` },
    { virtualPath: `src/lib/response.ts`,           fileType: "lib",     contentDescriptor: "sendJson / sendError helpers" },
    { virtualPath: `src/lib/validate.ts`,           fileType: "lib",     contentDescriptor: "Request validation helpers" },
    { virtualPath: `package.json`,                  fileType: "config",  contentDescriptor: "Package manifest — name, version, scripts, dependencies" },
    { virtualPath: `tsconfig.json`,                 fileType: "config",  contentDescriptor: "TypeScript config — strict mode, ESM" },
  ];
}

function buildRouteList(projectName: string): readonly VirtualRouteRecord[] {
  const base = `/api/${projectName.toLowerCase().replace(/\s+/g, "-")}`;
  return [
    { method: "GET",    path: base,        description: `List all ${projectName} records` },
    { method: "GET",    path: `${base}/:id`, description: `Get ${projectName} record by id` },
    { method: "POST",   path: base,        description: `Create a new ${projectName} record` },
    { method: "PATCH",  path: `${base}/:id`, description: `Update ${projectName} record by id` },
    { method: "DELETE", path: `${base}/:id`, description: `Delete ${projectName} record by id` },
  ];
}

function buildValidationReport(): ValidationReport {
  return {
    passed: true,
    checks: [
      { check: "route_coverage",       result: "pass",    note: "All CRUD operations declared" },
      { check: "schema_completeness",  result: "pass",    note: "Resource fields declared" },
      { check: "naming_conventions",   result: "pass",    note: "Files and routes follow project conventions" },
      { check: "no_executable_code",   result: "pass",    note: "Virtual descriptors only — no executable content" },
      { check: "no_filesystem_writes", result: "pass",    note: "All outputs are in-memory records" },
      { check: "no_secret_values",     result: "pass",    note: "No secret or credential fields present" },
      { check: "sandbox_execution",    result: "skipped", note: "Sandbox execution is a future-phase concern" },
    ],
  };
}

// ─── Public API ───────────────────────────────────────────────────────────────

export function createExperimentalGenerationRecord(
  input: CreateExperimentalGenerationInput,
): { ok: true; record: ExperimentalGenerationRecord } {
  const fileTree = buildVirtualFileTree(input.projectName);
  const routeList = buildRouteList(input.projectName);
  const validationReport = buildValidationReport();

  const record: ExperimentalGenerationRecord = {
    generationId:          randomBytes(16).toString("hex"),
    appType:               "crud_app",
    templateType:          "crud_template",
    projectName:           input.projectName,
    requestedByActorType:  input.requestedByActorType,
    requestedByActorId:    input.requestedByActorId,
    status:                "generate_virtual_structure",
    virtualFileTree:       fileTree,
    routeList,
    schemaSummary:         `${input.projectName} resource: id (string), name (string), description (string), createdAt (ISO 8601), updatedAt (ISO 8601)`,
    artifactSummary: {
      packageName:  `@generated/${input.projectName.toLowerCase().replace(/\s+/g, "-")}`,
      appType:      "crud_app",
      templateType: "crud_template",
      version:      "0.1.0",
      fileCount:    fileTree.length,
      routeCount:   routeList.length,
    },
    validationReport,
    executionBlocked:  true,
    deploymentBlocked: true,
    createdAt:         new Date().toISOString(),
  };

  store.push(record);
  return { ok: true, record };
}

export function listExperimentalGenerationRecords(): ExperimentalGenerationRecord[] {
  return store.slice().reverse(); // newest-first
}

export function getExperimentalGenerationSummary(): ExperimentalGenerationSummary {
  const byStatus: Record<ExperimentalGenerationStatus, number> = {
    receive_project_spec:      0,
    select_template:           0,
    generate_virtual_structure: 0,
    validate_structure:        0,
    produce_artifact_summary:  0,
    operator_review:           0,
    approved:                  0,
    rejected:                  0,
  };

  for (const r of store) {
    byStatus[r.status]++;
  }

  return {
    totalRuns:          store.length,
    byStatus,
    pendingReviewCount: byStatus.operator_review,
    appType:            "crud_app",
    templateType:       "crud_template",
    executionEnabled:   false,
    deploymentEnabled:  false,
    persistenceEnabled: false,
    implementationPhase: "skeleton",
  };
}
