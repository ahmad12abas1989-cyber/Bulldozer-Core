import { logger } from "../lib/logger";
import { emit, subscribe } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { listTasks } from "./taskQueue";
import { peekTaskPolicy, type PolicyDecision } from "./taskPolicy";

export type OrchestrationReadiness = "ready" | "blocked" | "approval_required" | "warning";
export type OrchestrationPriority = "low" | "normal" | "high";

export interface OrchestrationPlanEntry {
  taskId: string;
  taskType: string;
  currentStatus: string;
  policyDecision: PolicyDecision;
  evaluationCategory: string;
  readiness: OrchestrationReadiness;
  reason: string;
  priority: OrchestrationPriority;
}

export interface QueueOrchestrationStatus {
  orchestrationMode: "planning_only";
  executionBlocked: true;
  totalQueued: number;
  readyCount: number;
  blockedCount: number;
  approvalRequiredCount: number;
  warningCount: number;
  lastEvaluationAt: string | null;
  timestamp: string;
}

const ORCHESTRATION_MODE = "planning_only" as const;
const EXECUTION_BLOCKED: true = true;

let totalQueued = 0;
let readyCount = 0;
let blockedCount = 0;
let approvalRequiredCount = 0;
let warningCount = 0;
let lastEvaluationAt: string | null = null;
let isOperational = false;

function policyToReadiness(decision: PolicyDecision): OrchestrationReadiness {
  switch (decision) {
    case "allow": return "ready";
    case "warn": return "warning";
    case "approval_required": return "approval_required";
    case "block": return "blocked";
  }
}

function policyToPriority(decision: PolicyDecision): OrchestrationPriority {
  switch (decision) {
    case "block": return "low";
    case "allow": return "normal";
    case "warn": return "normal";
    case "approval_required": return "high";
  }
}

function policyToCategory(decision: PolicyDecision): string {
  switch (decision) {
    case "allow": return "safe";
    case "warn": return "warning";
    case "approval_required": return "warning";
    case "block": return "blocked";
  }
}

export function evaluateQueueReadiness(): OrchestrationPlanEntry[] {
  const now = new Date().toISOString();
  const tasks = listTasks();

  let ready = 0;
  let blocked = 0;
  let approvalRequired = 0;
  let warning = 0;

  const plan: OrchestrationPlanEntry[] = tasks.map((task) => {
    const peek = peekTaskPolicy(task);
    const readiness = policyToReadiness(peek.decision);
    const priority = policyToPriority(peek.decision);
    const evaluationCategory = policyToCategory(peek.decision);

    switch (readiness) {
      case "ready": ready++; break;
      case "blocked": blocked++; break;
      case "approval_required": approvalRequired++; break;
      case "warning": warning++; break;
    }

    return {
      taskId: task.id,
      taskType: task.type,
      currentStatus: task.status,
      policyDecision: peek.decision,
      evaluationCategory,
      readiness,
      reason: peek.reason,
      priority,
    };
  });

  totalQueued = tasks.length;
  readyCount = ready;
  blockedCount = blocked;
  approvalRequiredCount = approvalRequired;
  warningCount = warning;
  lastEvaluationAt = now;

  emit("queue_orchestrator:evaluated", "queue-orchestrator", {
    totalQueued,
    readyCount,
    blockedCount,
    approvalRequiredCount,
    warningCount,
  });

  return plan;
}

export function getQueueOrchestrationStatus(): QueueOrchestrationStatus {
  return {
    orchestrationMode: ORCHESTRATION_MODE,
    executionBlocked: EXECUTION_BLOCKED,
    totalQueued,
    readyCount,
    blockedCount,
    approvalRequiredCount,
    warningCount,
    lastEvaluationAt,
    timestamp: new Date().toISOString(),
  };
}

export function listOrchestrationPlan(): OrchestrationPlanEntry[] {
  return evaluateQueueReadiness();
}

export function isQueueOrchestratorOperational(): boolean {
  return isOperational;
}

export function initQueueOrchestrator(): void {
  subscribe("task_queue:task_created", () => {
    evaluateQueueReadiness();
  });

  subscribe("task_queue:task_blocked", () => {
    evaluateQueueReadiness();
  });

  subscribe("task_queue:task_queued", () => {
    evaluateQueueReadiness();
  });

  evaluateQueueReadiness();

  isOperational = true;

  emit("queue_orchestrator:initialized", "queue-orchestrator", {
    orchestrationMode: ORCHESTRATION_MODE,
    executionBlocked: EXECUTION_BLOCKED,
  });

  addTimelineEvent({
    level: "info",
    source: "queue-orchestrator",
    message: "Queue orchestration foundation initialized",
    metadata: { orchestrationMode: ORCHESTRATION_MODE },
  });

  logger.info(
    { orchestrationMode: ORCHESTRATION_MODE, executionBlocked: EXECUTION_BLOCKED },
    "Queue orchestration foundation initialized",
  );
}
