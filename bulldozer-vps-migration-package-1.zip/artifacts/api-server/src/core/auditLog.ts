import { randomBytes } from "node:crypto";
import { registerSubsystemState } from "./runtimeStateRegistry";
import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";
import { readStore, writeStore } from "./persistentStore";

export type AuditDecision = "allowed" | "denied" | "no_policy";

export interface AuditLifecycle {
  statusCode: number;
  latencyMs: number;
  finishedAt: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  requestId: string;
  correlationId: string;
  method: string;
  route: string;
  role: string;
  actorType?: string;
  actorId?: string;
  authSource?: string;
  permission: string;
  minimumRole: string;
  decision: AuditDecision;
  reason: string;
  enforcementMode: string;
  lifecycle?: AuditLifecycle;
  executionBlocked: true;
}

export interface AuditEntryInput {
  requestId: string;
  correlationId: string;
  method: string;
  route: string;
  role: string;
  actorType?: string;
  actorId?: string;
  authSource?: string;
  permission: string;
  minimumRole: string;
  decision: AuditDecision;
  reason: string;
  enforcementMode: string;
}

export interface AuditFilter {
  role?: string;
  actorType?: string;
  decision?: string;
  route?: string;
  authSource?: string;
  limit?: number;
}

export interface AuditLogStatus {
  operational: boolean;
  subsystemName: "audit_log";
  entryCount: number;
  capacity: number;
  oldestEntryAt: string | null;
  newestEntryAt: string | null;
  executionBlocked: true;
  recoveryBlocked: true;
  initializedAt: string | null;
}

export interface AuditLogResult {
  executionBlocked: true;
  recoveryBlocked: true;
  entryCount: number;
  capacity: number;
  limit: number;
  filteredCount: number;
  filtersApplied: Record<string, string>;
  entries: AuditEntry[];
  timestamp: string;
}

const MAX_ENTRIES = 1000;
const MAX_QUERY_LIMIT = 200;
const PERSIST_LIMIT = 500;
const STORE_KEY = "audit-log";
const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;
const VALID_DECISIONS: readonly AuditDecision[] = ["allowed", "denied", "no_policy"];

const buffer: AuditEntry[] = [];
let isOperational = false;
let initializedAt: string | null = null;

function isValidAuditEntry(obj: unknown): obj is AuditEntry {
  if (typeof obj !== "object" || obj === null) return false;
  const e = obj as Record<string, unknown>;
  return (
    typeof e["id"] === "string" &&
    typeof e["timestamp"] === "string" &&
    typeof e["requestId"] === "string" &&
    typeof e["correlationId"] === "string" &&
    typeof e["method"] === "string" &&
    typeof e["route"] === "string" &&
    typeof e["role"] === "string" &&
    typeof e["permission"] === "string" &&
    typeof e["minimumRole"] === "string" &&
    (e["decision"] === "allowed" || e["decision"] === "denied" || e["decision"] === "no_policy") &&
    typeof e["reason"] === "string" &&
    typeof e["enforcementMode"] === "string" &&
    e["executionBlocked"] === true
  );
}

function flushAuditLog(): void {
  try {
    writeStore(STORE_KEY, buffer.slice(-PERSIST_LIMIT));
  } catch (err) {
    logger.warn({ err: String(err) }, "Audit log: failed to flush to persistent store");
  }
}

export function initAuditLog(): void {
  if (isOperational) return;

  registerSubsystemState({
    subsystemName: "audit_log",
    category: "observability",
    dependencies: ["access_enforcement", "runtime_state_registry"],
    metadata: {
      description:
        "Append-only audit log — 1000-entry ring buffer, records access checks with timestamp, method, route, role, permission, decision, and requestId. Persists last 500 entries across restarts.",
    },
  });

  const stored = readStore<unknown>(STORE_KEY);
  let restoredCount = 0;
  if (Array.isArray(stored)) {
    for (const item of stored) {
      if (isValidAuditEntry(item) && buffer.length < MAX_ENTRIES) {
        buffer.push(item);
        restoredCount++;
      }
    }
  }

  isOperational = true;
  initializedAt = new Date().toISOString();

  addTimelineEvent({
    level: "info",
    source: "audit-log",
    message: `Audit log initialized — ${restoredCount} entr${restoredCount === 1 ? "y" : "ies"} restored from persistent store`,
    metadata: {
      capacity: MAX_ENTRIES,
      restoredCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  emit("audit_log:initialized", "audit-log", {
    capacity: MAX_ENTRIES,
    restoredCount,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "audit_log.initialized",
    source: "audit-log",
    severity: "info",
    category: "runtime",
    payload: {
      capacity: MAX_ENTRIES,
      restoredCount,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    { capacity: MAX_ENTRIES, restoredCount, persistLimit: PERSIST_LIMIT, executionBlocked: EXECUTION_BLOCKED },
    "Audit log initialized",
  );
}

export function appendAuditEntry(input: AuditEntryInput): void {
  if (!isOperational) return;

  const entry: AuditEntry = {
    id: randomBytes(8).toString("hex"),
    timestamp: new Date().toISOString(),
    requestId: input.requestId,
    correlationId: input.correlationId,
    method: input.method,
    route: input.route,
    role: input.role,
    ...(input.actorType !== undefined ? { actorType: input.actorType } : {}),
    ...(input.actorId !== undefined ? { actorId: input.actorId } : {}),
    ...(input.authSource !== undefined ? { authSource: input.authSource } : {}),
    permission: input.permission,
    minimumRole: input.minimumRole,
    decision: input.decision,
    reason: input.reason,
    enforcementMode: input.enforcementMode,
    executionBlocked: EXECUTION_BLOCKED,
  };

  if (buffer.length >= MAX_ENTRIES) {
    buffer.shift();
  }
  buffer.push(entry);
  flushAuditLog();
}

export function updateAuditEntryLifecycle(requestId: string, lifecycle: AuditLifecycle): void {
  for (let i = buffer.length - 1; i >= 0; i--) {
    if (buffer[i].requestId === requestId) {
      buffer[i] = { ...buffer[i], lifecycle };
      return;
    }
  }
}

export function getAuditLogStatus(): AuditLogStatus {
  return {
    operational: isOperational,
    subsystemName: "audit_log",
    entryCount: buffer.length,
    capacity: MAX_ENTRIES,
    oldestEntryAt: buffer.length > 0 ? buffer[0].timestamp : null,
    newestEntryAt: buffer.length > 0 ? buffer[buffer.length - 1].timestamp : null,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    initializedAt,
  };
}

export function getAuditLogEntries(limit: number = 100): AuditLogResult {
  const clamped = Math.max(1, Math.min(limit, MAX_ENTRIES));
  const entries = buffer.slice(-clamped);
  return {
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    entryCount: buffer.length,
    capacity: MAX_ENTRIES,
    limit: clamped,
    filteredCount: entries.length,
    filtersApplied: {},
    entries,
    timestamp: new Date().toISOString(),
  };
}

export function getFilteredAuditEntries(filter: AuditFilter): AuditLogResult {
  const limit = Math.max(1, Math.min(filter.limit ?? 100, MAX_QUERY_LIMIT));
  const filtersApplied: Record<string, string> = {};

  let entries = buffer.slice();

  if (filter.role !== undefined) {
    entries = entries.filter((e) => e.role === filter.role);
    filtersApplied["role"] = filter.role;
  }

  if (filter.actorType !== undefined) {
    entries = entries.filter((e) => e.actorType === filter.actorType);
    filtersApplied["actorType"] = filter.actorType;
  }

  if (filter.decision !== undefined) {
    if ((VALID_DECISIONS as readonly string[]).includes(filter.decision)) {
      const dec = filter.decision as AuditDecision;
      entries = entries.filter((e) => e.decision === dec);
      filtersApplied["decision"] = filter.decision;
    }
  }

  if (filter.route !== undefined) {
    entries = entries.filter((e) => e.route === filter.route);
    filtersApplied["route"] = filter.route;
  }

  if (filter.authSource !== undefined) {
    entries = entries.filter((e) => e.authSource === filter.authSource);
    filtersApplied["authSource"] = filter.authSource;
  }

  const filteredCount = entries.length;
  const sliced = entries.slice(-limit);

  return {
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    entryCount: buffer.length,
    capacity: MAX_ENTRIES,
    limit,
    filteredCount,
    filtersApplied,
    entries: sliced,
    timestamp: new Date().toISOString(),
  };
}
