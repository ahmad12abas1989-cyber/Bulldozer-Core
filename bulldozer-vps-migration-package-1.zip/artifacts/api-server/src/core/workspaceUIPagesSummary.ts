// workspaceUIPagesSummary.ts
// Phase 166 — UI Page Summary API
// Pure derivation from getUIPageManifest() + getDashboardSkeleton().pageLayouts.
// No init. No persistence. No subsystem. No health check.
// No HTML/CSS/frontend framework code. executionBlocked always true.

import { getUIPageManifest } from "./workspaceUIPages";
import { getDashboardSkeleton } from "./workspaceDashboardSkeleton";

// ── Types ──────────────────────────────────────────────────────────────────

export interface UIPageSummaryEntry {
  readonly pageId: string;
  readonly title: string;
  readonly apiRoute: string;
  readonly htmlRoute: string;
  readonly panelCount: number;
  readonly panelIds: readonly string[];
  readonly executionBlocked: true;
}

export interface UIPagesSummary {
  readonly generatedAt: string;
  readonly totalPages: number;
  readonly pages: readonly UIPageSummaryEntry[];
  readonly executionBlocked: true;
}

// ── Public API ─────────────────────────────────────────────────────────────

export function getUIPagesSummary(): UIPagesSummary {
  const manifest = getUIPageManifest();
  const skeleton = getDashboardSkeleton();

  // Build panelIds lookup from skeleton pageLayouts — O(5)
  const panelIdsMap = new Map<string, readonly string[]>();
  for (const pl of skeleton.pageLayouts) {
    panelIdsMap.set(pl.pageId, pl.panelIds);
  }

  // Pages are already sorted by pageOrder ascending from getUIPageManifest()
  const pages: UIPageSummaryEntry[] = manifest.pages.map((p) => ({
    pageId: p.pageId,
    title: p.title,
    apiRoute: "/api/workspace/ui/pages",
    htmlRoute: p.route,
    panelCount: p.panelCount,
    panelIds: panelIdsMap.get(p.pageId) ?? [],
    executionBlocked: true as const,
  }));

  return {
    generatedAt: new Date().toISOString(),
    totalPages: pages.length,
    pages,
    executionBlocked: true,
  };
}
