import type { IncomingMessage, ServerResponse } from "node:http";
import { loadLatestPersistedSnapshot } from "../core/snapshotStorage";
import { sendJson, sendError } from "../lib/response";

export function handleSnapshotLatest(_req: IncomingMessage, res: ServerResponse): void {
  const snapshot = loadLatestPersistedSnapshot();
  if (snapshot === null) {
    sendError(res, 404, "No persisted snapshot found");
    return;
  }
  sendJson(res, 200, snapshot);
}
