import * as fs from "node:fs";
import * as path from "node:path";
import { logger } from "../lib/logger";
import { config } from "./config";
import { emit, subscribe } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { listTasks, importTask, type Task } from "./taskQueue";

const STORAGE_DIR = path.join(config.storageDir, "tasks");
const TASK_FILE = path.join(STORAGE_DIR, "task-state.json");
const TASK_FILE_TMP = TASK_FILE + ".tmp";

const MAX_PERSISTED_TASKS = 100;
const EXECUTION_BLOCKED: true = true;

interface PersistedTask extends Task {
  policyDecision?: string;
  evaluationCategory?: string;
}

interface TaskPersistenceFile {
  version: 1;
  savedAt: string;
  taskCount: number;
  tasks: PersistedTask[];
}

let isOperational = false;
let lastSavedAt: string | null = null;
let lastLoadedAt: string | null = null;
let persistedCount = 0;
let loadedCount = 0;
let lastError: string | null = null;

export function persistTasks(): void {
  try {
    const all = listTasks();
    const toSave = all.slice(0, MAX_PERSISTED_TASKS);

    const file: TaskPersistenceFile = {
      version: 1,
      savedAt: new Date().toISOString(),
      taskCount: toSave.length,
      tasks: toSave as PersistedTask[],
    };

    fs.mkdirSync(STORAGE_DIR, { recursive: true });
    fs.writeFileSync(TASK_FILE_TMP, JSON.stringify(file, null, 2), "utf8");
    fs.renameSync(TASK_FILE_TMP, TASK_FILE);

    lastSavedAt = file.savedAt;
    persistedCount = toSave.length;
    lastError = null;

    emit("task_persistence:saved", "task-persistence", { count: persistedCount, savedAt: lastSavedAt });
    logger.info({ count: persistedCount, savedAt: lastSavedAt }, "Tasks persisted to disk");
  } catch (err) {
    lastError = String(err);
    logger.error({ err: lastError }, "Task persistence write failed");
  }
}

export function loadPersistedTasks(): void {
  const now = new Date().toISOString();
  lastLoadedAt = now;

  if (!fs.existsSync(TASK_FILE)) {
    logger.info({ path: TASK_FILE }, "No persisted task file found — starting fresh");
    loadedCount = 0;
    emit("task_persistence:loaded", "task-persistence", { count: 0, fresh: true });
    return;
  }

  try {
    const raw = fs.readFileSync(TASK_FILE, "utf8");
    const file = JSON.parse(raw) as TaskPersistenceFile;

    if (file.version !== 1 || !Array.isArray(file.tasks)) {
      logger.warn({ path: TASK_FILE }, "Persisted task file has unexpected format — skipping load");
      loadedCount = 0;
      return;
    }

    let imported = 0;
    for (const task of file.tasks) {
      if (task.id && task.type && task.status) {
        importTask(task);
        imported++;
      }
    }

    loadedCount = imported;
    emit("task_persistence:loaded", "task-persistence", { count: imported, savedAt: file.savedAt });
    addTimelineEvent({
      level: "info",
      source: "task-persistence",
      message: `Loaded ${imported} persisted task(s) from disk`,
      metadata: { savedAt: file.savedAt },
    });
    logger.info({ count: imported, savedAt: file.savedAt }, "Persisted tasks loaded (execution blocked)");
  } catch (err) {
    lastError = String(err);
    logger.error({ err: lastError }, "Task persistence load failed");
    loadedCount = 0;
  }
}

export function clearPersistedTasks(): void {
  try {
    const empty: TaskPersistenceFile = {
      version: 1,
      savedAt: new Date().toISOString(),
      taskCount: 0,
      tasks: [],
    };

    fs.mkdirSync(STORAGE_DIR, { recursive: true });
    fs.writeFileSync(TASK_FILE_TMP, JSON.stringify(empty, null, 2), "utf8");
    fs.renameSync(TASK_FILE_TMP, TASK_FILE);

    persistedCount = 0;
    lastSavedAt = empty.savedAt;
    lastError = null;

    emit("task_persistence:cleared", "task-persistence", {});
    logger.info("Task persistence cleared");
  } catch (err) {
    lastError = String(err);
    logger.error({ err: lastError }, "Task persistence clear failed");
  }
}

export function getTaskPersistenceStatus(): {
  operational: boolean;
  persistedTaskCount: number;
  loadedTaskCount: number;
  lastSavedAt: string | null;
  lastLoadedAt: string | null;
  lastError: string | null;
  executionBlocked: true;
  timestamp: string;
} {
  return {
    operational: isOperational,
    persistedTaskCount: persistedCount,
    loadedTaskCount: loadedCount,
    lastSavedAt,
    lastLoadedAt,
    lastError,
    executionBlocked: EXECUTION_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function initTaskPersistence(): void {
  try {
    fs.mkdirSync(STORAGE_DIR, { recursive: true });
  } catch (err) {
    logger.error({ err: String(err) }, "Task persistence: failed to create storage directory");
  }

  loadPersistedTasks();

  subscribe("task_queue:task_created", () => {
    persistTasks();
  });

  subscribe("task_queue:task_blocked", () => {
    persistTasks();
  });

  subscribe("task_queue:task_queued", () => {
    persistTasks();
  });

  isOperational = true;

  emit("task_persistence:initialized", "task-persistence", {
    storagePath: TASK_FILE,
    maxPersistedTasks: MAX_PERSISTED_TASKS,
    executionBlocked: EXECUTION_BLOCKED,
  });
  addTimelineEvent({
    level: "info",
    source: "task-persistence",
    message: "Task persistence layer initialized",
    metadata: { storagePath: TASK_FILE, maxPersistedTasks: MAX_PERSISTED_TASKS },
  });
  logger.info(
    { storagePath: TASK_FILE, maxPersistedTasks: MAX_PERSISTED_TASKS, executionBlocked: EXECUTION_BLOCKED },
    "Task persistence layer initialized",
  );
}
