import { SandboxWriteAuditRecord }  from "./sandboxWriteAuditCore.js";
import { GuardedSandboxWriteRecord } from "./guardedSandboxWriteCore.js";
import { SandboxFilesystemRecord }   from "./sandboxFilesystemCore.js";
import { ControlledExecutionRecord } from "./controlledExecutionCore.js";
import { randomBytes }               from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type SnapshotState = "descriptor_snapshot_ready";

export type SnapshotCheckRule =
  | "write_audit_exists"
  | "guarded_write_exists"
  | "filesystem_record_exists"
  | "execution_record_exists"
  | "audited_operations_traceable"
  | "snapshot_targets_within_writable_zones"
  | "protected_zones_excluded"
  | "recovery_plan_descriptor_only"
  | "mutation_still_blocked"
  | "output_remains_descriptor_only";

export interface SnapshotTarget {
  readonly targetIndex:             number;
  readonly targetPath:              string;
  readonly operationType:           string;
  readonly preWriteStateDescriptor: string;
  readonly filesystemMutationBlocked: true;
  readonly snapshotDescriptorOnly:  true;
  readonly snapshotNote:            string;
}

export interface SnapshotValidationCheck {
  readonly rule:   SnapshotCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface RecoveryStep {
  readonly stepIndex:        number;
  readonly targetPath:       string;
  readonly recoveryAction:   "restore_pre_write_state";
  readonly descriptorOnly:   true;
  readonly mutationBlocked:  true;
  readonly recoveryNote:     string;
}

export interface SnapshotReadinessReport {
  readonly rollbackRequired:         true;
  readonly rollbackDescriptorOnly:   true;
  readonly snapshotTargetCount:      number;
  readonly recoveryStepCount:        number;
  readonly rollbackReady:            boolean;
  readonly allChecksPass:            boolean;
  readonly summary:                  string;
}

export interface SandboxWriteRollbackSnapshotRecord {
  readonly rollbackSnapshotId:         string;
  readonly snapshotState:              SnapshotState;
  readonly approvalRequired:           true;
  readonly actualWritesEnabled:        false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly rollbackRequired:           true;
  readonly implementationPhase:        "descriptor_only";
  readonly writeAuditId:               string;
  readonly guardedWriteId:             string;
  readonly filesystemRecordId:         string;
  readonly executionRecordId:          string;
  readonly approvalReference:          string;
  readonly snapshotTargets:            readonly SnapshotTarget[];
  readonly snapshotValidationChecks:   readonly SnapshotValidationCheck[];
  readonly recoveryPlan:               readonly RecoveryStep[];
  readonly snapshotReadinessReport:    SnapshotReadinessReport;
  readonly createdAt:                  string;
}

export interface CreateRollbackSnapshotInput {
  readonly auditRecord:            SandboxWriteAuditRecord;
  readonly guardedWriteRecord:     GuardedSandboxWriteRecord;
  readonly filesystemRecord:       SandboxFilesystemRecord;
  readonly executionRecord:        ControlledExecutionRecord;
}

export interface SandboxWriteRollbackSnapshotSummary {
  readonly total:                      number;
  readonly byState:                    Record<SnapshotState, number>;
  readonly actualWritesEnabled:        false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly approvalRequired:           true;
  readonly rollbackRequired:           true;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildSnapshotTargets(
  auditRecord: SandboxWriteAuditRecord,
): readonly SnapshotTarget[] {
  return auditRecord.attemptedOperations.map((op, idx) => ({
    targetIndex:              idx,
    targetPath:               op.targetPath,
    operationType:            op.operationType,
    preWriteStateDescriptor:  `Pre-write state snapshot for ${op.targetPath} (${op.operationType}) — descriptor-only; records zone state before any future write attempt`,
    filesystemMutationBlocked: true,
    snapshotDescriptorOnly:   true,
    snapshotNote:             `Rollback snapshot target ${idx}: path=${op.targetPath}, operation=${op.operationType}. Captures expected pre-write state as a descriptor. No filesystem read or write occurs at this phase.`,
  }));
}

function buildRecoveryPlan(
  targets: readonly SnapshotTarget[],
): readonly RecoveryStep[] {
  return targets.map((t, idx) => ({
    stepIndex:       idx,
    targetPath:      t.targetPath,
    recoveryAction:  "restore_pre_write_state",
    descriptorOnly:  true,
    mutationBlocked: true,
    recoveryNote:    `Recovery step ${idx}: restore ${t.targetPath} to pre-write state snapshot — descriptor-only; no filesystem mutation occurs until real writes are enabled and operator-approved`,
  }));
}

function buildValidationChecks(
  input: CreateRollbackSnapshotInput,
  targets: readonly SnapshotTarget[],
): readonly SnapshotValidationCheck[] {
  const { auditRecord, guardedWriteRecord, filesystemRecord, executionRecord } = input;

  const writablePaths = new Set(
    filesystemRecord.writableZones.map(z => z.path as string),
  );
  const protectedPaths = new Set(
    filesystemRecord.protectedZones.map(z => z.path as string),
  );

  const allWithinWritable = targets.every(t => writablePaths.has(t.targetPath));
  const noneInProtected   = targets.every(t => !protectedPaths.has(t.targetPath));

  const rollbackReady =
    auditRecord.traceabilityReport.rollbackReady &&
    guardedWriteRecord.rollbackWriteReport.rollbackReady &&
    filesystemRecord.rollbackFilesystemPlan.rollbackReady;

  return [
    {
      rule:   "write_audit_exists",
      passed: auditRecord.writeAuditId.length > 0,
      detail: "Sandbox write audit record is present and valid",
    },
    {
      rule:   "guarded_write_exists",
      passed: guardedWriteRecord.guardedWriteId.length > 0,
      detail: "Guarded sandbox write record is present and valid",
    },
    {
      rule:   "filesystem_record_exists",
      passed: filesystemRecord.sandboxFilesystemId.length > 0,
      detail: "Sandbox filesystem record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "audited_operations_traceable",
      passed: auditRecord.attemptedOperations.length > 0 && auditRecord.traceabilityReport.allChecksPass,
      detail: `${auditRecord.attemptedOperations.length} audited operation(s) traceable — traceabilityReport.allChecksPass=${auditRecord.traceabilityReport.allChecksPass}`,
    },
    {
      rule:   "snapshot_targets_within_writable_zones",
      passed: allWithinWritable,
      detail: allWithinWritable
        ? `All ${targets.length} snapshot target(s) confirmed within writable sandbox zones`
        : "One or more snapshot targets fall outside declared writable zones — rollback snapshot blocked",
    },
    {
      rule:   "protected_zones_excluded",
      passed: noneInProtected,
      detail: noneInProtected
        ? "No snapshot targets overlap with protected zones"
        : "One or more snapshot targets overlap with protected zones — rollback snapshot blocked",
    },
    {
      rule:   "recovery_plan_descriptor_only",
      passed: true,
      detail: "Recovery plan is descriptor-only — no filesystem reads or writes occur at this phase",
    },
    {
      rule:   "mutation_still_blocked",
      passed: true,
      detail: "filesystemMutationBlocked=true confirmed — no filesystem mutation occurs in this phase",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback readiness confirmed across audit, guarded write, and filesystem records — snapshot output is valid descriptor"
        : "Rollback readiness not fully confirmed across upstream records — snapshot output blocked",
    },
  ] as const;
}

function buildReadinessReport(
  checks: readonly SnapshotValidationCheck[],
  targets: readonly SnapshotTarget[],
  recovery: readonly RecoveryStep[],
): SnapshotReadinessReport {
  const allChecksPass = checks.every(c => c.passed);
  const rollbackCheck = checks.find(c => c.rule === "output_remains_descriptor_only");
  const rollbackReady = rollbackCheck?.passed ?? false;
  return {
    rollbackRequired:       true,
    rollbackDescriptorOnly: true,
    snapshotTargetCount:    targets.length,
    recoveryStepCount:      recovery.length,
    rollbackReady,
    allChecksPass,
    summary: allChecksPass
      ? "Rollback snapshot readiness confirmed — all targets within writable zones, protected zones excluded, rollback readiness validated across three upstream records, recovery plan is descriptor-only"
      : "Rollback snapshot readiness incomplete — one or more validation checks failed; snapshot must not proceed to activation",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const snapshotStore = new Map<string, SandboxWriteRollbackSnapshotRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createRollbackSnapshotRecord(
  input: CreateRollbackSnapshotInput,
): { ok: true; record: SandboxWriteRollbackSnapshotRecord } {
  const rollbackSnapshotId = randomBytes(16).toString("hex");
  const snapshotTargets    = buildSnapshotTargets(input.auditRecord);
  const recoveryPlan       = buildRecoveryPlan(snapshotTargets);
  const checks             = buildValidationChecks(input, snapshotTargets);
  const readinessReport    = buildReadinessReport(checks, snapshotTargets, recoveryPlan);

  const record: SandboxWriteRollbackSnapshotRecord = {
    rollbackSnapshotId,
    snapshotState:             "descriptor_snapshot_ready",
    approvalRequired:          true,
    actualWritesEnabled:       false,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
    rollbackRequired:          true,
    implementationPhase:       "descriptor_only",
    writeAuditId:              input.auditRecord.writeAuditId,
    guardedWriteId:            input.guardedWriteRecord.guardedWriteId,
    filesystemRecordId:        input.filesystemRecord.sandboxFilesystemId,
    executionRecordId:         input.executionRecord.controlledExecutionId,
    approvalReference:         input.auditRecord.approvalReference,
    snapshotTargets,
    snapshotValidationChecks:  checks,
    recoveryPlan,
    snapshotReadinessReport:   readinessReport,
    createdAt:                 new Date().toISOString(),
  };

  snapshotStore.set(rollbackSnapshotId, record);
  return { ok: true, record };
}

export function listRollbackSnapshotRecords(): readonly SandboxWriteRollbackSnapshotRecord[] {
  return [...snapshotStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getRollbackSnapshotSummary(): SandboxWriteRollbackSnapshotSummary {
  const records = listRollbackSnapshotRecords();
  return {
    total:                     records.length,
    byState:                   { descriptor_snapshot_ready: records.length },
    actualWritesEnabled:       false,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
    approvalRequired:          true,
    rollbackRequired:          true,
  };
}
