// Rate Limit Observe Route — Phase 194
// GET /api/auth/rate-limit
// Read-only diagnostic view of the in-memory rate limit observation store.
// No blocking, no persistence, no automatic request wiring, no reset route.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { getRateLimitSummary } from "../core/rateLimitCore";

export function handleRateLimitObserve(_req: IncomingMessage, res: ServerResponse): void {
  const summary = getRateLimitSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    observeOnly:        true,
    enforcing:          false,
    persistenceEnabled: false,
    executionBlocked:   true,
    summary,
  });
}
