#!/usr/bin/env bash
# deploy/scripts/health-check.sh
# Run the full Bulldozer Mother Core health verification suite against a live instance.
# Exits 0 only if every check passes.
# Safe to run from CI, cron, or manual operator inspection.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPLOY_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ENV_FILE="${DEPLOY_DIR}/.env"

HOST_PORT_VAL=$(grep -E '^HOST_PORT=' "${ENV_FILE}" 2>/dev/null | cut -d'=' -f2- | tr -d '"' || echo "8080")
BASE="http://localhost:${HOST_PORT_VAL}"

PASS=0
FAIL=0

check() {
  local label="$1"
  local url="$2"
  local expected_status="${3:-200}"
  local http_status
  http_status=$(curl -s -o /dev/null -w "%{http_code}" "${url}")
  if [[ "${http_status}" == "${expected_status}" ]]; then
    echo "  PASS  ${label} (${http_status})"
    PASS=$((PASS + 1))
  else
    echo "  FAIL  ${label} — expected ${expected_status}, got ${http_status}"
    FAIL=$((FAIL + 1))
  fi
}

check_json() {
  local label="$1"
  local url="$2"
  local pattern="$3"
  local body
  body=$(curl -sf "${url}" 2>/dev/null || echo "")
  if echo "${body}" | grep -q "${pattern}"; then
    echo "  PASS  ${label}"
    PASS=$((PASS + 1))
  else
    echo "  FAIL  ${label} — pattern '${pattern}' not found in response"
    FAIL=$((FAIL + 1))
  fi
}

echo "[bulldozer] Health check suite — ${BASE}"
echo ""

echo "--- Core endpoints ---"
check "GET /api/healthz"             "${BASE}/api/healthz"
check "GET /api/status"              "${BASE}/api/status"
check "GET /api/metrics"             "${BASE}/api/metrics"
check "GET /api/health/full"         "${BASE}/api/health/full"
check "GET /api/diagnostics/snapshot" "${BASE}/api/diagnostics/snapshot"

echo ""
echo "--- Runtime subsystems ---"
check "GET /api/runtime/graph/status"  "${BASE}/api/runtime/graph/status"
check "GET /api/runtime/capabilities"  "${BASE}/api/runtime/capabilities"
check "GET /api/runtime/registry"      "${BASE}/api/runtime/registry"
check "GET /api/access/status"         "${BASE}/api/access/status"
check "GET /api/audit/status"          "${BASE}/api/audit/status"

echo ""
echo "--- UI routes ---"
check "GET /ui"             "${BASE}/ui"
check "GET /ui/observation" "${BASE}/ui/observation"
check "GET /ui/governance"  "${BASE}/ui/governance"
check "GET /ui/diagnostics" "${BASE}/ui/diagnostics"
check "GET /ui/overview"    "${BASE}/ui/overview"

echo ""
echo "--- JSON invariants ---"
check_json "allHealthy=true"    "${BASE}/api/workspace/ui/audit"          '"allHealthy":true'
check_json "cycleCount=0"       "${BASE}/api/runtime/graph/status"        '"cycleCount":0'
check_json "routePolicyCount"   "${BASE}/api/access/status"               '"routePolicyCount":'
check_json "actualWritesEnabled=false" "${BASE}/api/execution/controlled" '"executionBlocked"'

echo ""
echo "--- Summary ---"
echo "  Passed: ${PASS}"
echo "  Failed: ${FAIL}"

if [[ "${FAIL}" -gt 0 ]]; then
  echo ""
  echo "[bulldozer] HEALTH CHECK FAILED — ${FAIL} check(s) did not pass."
  exit 1
fi

echo ""
echo "[bulldozer] All health checks passed."
