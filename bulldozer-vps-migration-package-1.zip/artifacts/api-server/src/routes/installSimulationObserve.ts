// Install Simulation Observe Route — Phase 237
// GET /api/install/simulations
// Read-only diagnostic view of the in-memory install simulation registry.
// No simulation creation, no npm/yarn/pnpm execution, no package downloads,
// no filesystem writes, no postinstall scripts, no shell execution,
// no network access, no runtime execution, no deployment package.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  listInstallSimulationRecords,
  getInstallSimulationSummary,
} from "../core/installSimulationCore";

export function handleInstallSimulationObserve(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  const simulations = listInstallSimulationRecords();
  const summary     = getInstallSimulationSummary();

  sendJson(res, 200, {
    generatedAt:         new Date().toISOString(),
    simulationEnabled:   false,
    executionEnabled:    false,
    installationEnabled: false,
    deploymentEnabled:   false,
    persistenceEnabled:  false,
    executionBlocked:    true,
    installationBlocked: true,
    deploymentBlocked:   true,
    totalSimulations:    simulations.length,
    summary,
    simulations,
  });
}
