// Virtual Workspace Core — Phase 240
// Deterministic, non-writing, in-memory virtual workspace descriptor engine.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no real directory creation,
// no filesystem writes, no package installation, no shell execution,
// no network access, no vault access, no deployment package,
// no generated app launch, no Mother Core mutation.
// Not wired to runtime.ts or startRuntime().

import { randomBytes } from "node:crypto";
import type { TemplateMetadataRecord } from "./templateRegistryCore";
import type { VirtualPackageRecord } from "./virtualPackageCore";
import type { DependencyResolutionRecord } from "./dependencyResolutionCore";
import type { SandboxBuildRecord } from "./sandboxBuildCore";
import type { InstallSimulationRecord } from "./installSimulationCore";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type VirtualWorkspaceState = "virtually_mapped";

export interface VirtualWorkspacePath {
  readonly path: string;
  readonly descriptor: string;
  readonly isVirtual: true;
  readonly filesystemBlocked: true;
}

export interface VirtualWorkspaceValidationCheck {
  readonly name: string;
  readonly status: "pass" | "fail" | "skipped";
  readonly detail: string;
}

export interface VirtualWorkspaceRecord {
  readonly workspaceId: string;
  readonly templateId: string;
  readonly packageId: string;
  readonly resolutionId: string;
  readonly buildPlanId: string;
  readonly installSimulationId: string;
  readonly workspaceState: VirtualWorkspaceState;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
  readonly filesystemBlocked: true;
  readonly virtualWorkspaceTree: VirtualWorkspacePath[];
  readonly workspaceValidationChecks: VirtualWorkspaceValidationCheck[];
  readonly workspaceSummary: VirtualWorkspaceSummaryRecord;
  readonly createdAt: string;
}

export interface CreateVirtualWorkspaceInput {
  readonly templateRecord: TemplateMetadataRecord;
  readonly packageRecord: VirtualPackageRecord;
  readonly resolutionRecord: DependencyResolutionRecord;
  readonly buildPlanRecord: SandboxBuildRecord;
  readonly installSimulationRecord: InstallSimulationRecord;
  readonly operatorApprovalActorId: string;
  readonly operatorApprovalTimestamp: string;
}

export interface VirtualWorkspaceSummaryRecord {
  readonly totalPaths: number;
  readonly validationPassCount: number;
  readonly validationFailCount: number;
  readonly validationSkipCount: number;
  readonly workspaceState: VirtualWorkspaceState;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
  readonly filesystemBlocked: true;
}

export interface VirtualWorkspaceSummary {
  readonly totalWorkspaces: number;
  readonly byWorkspaceState: Record<VirtualWorkspaceState, number>;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
  readonly filesystemBlocked: true;
  readonly implementationPhase: "skeleton";
}

// ---------------------------------------------------------------------------
// Deterministic virtual workspace tree (8 fixed paths — Phase 239 blueprint)
// ---------------------------------------------------------------------------

const VIRTUAL_PATH_DESCRIPTORS: ReadonlyArray<{
  path: string;
  descriptor: string;
}> = [
  {
    path: "/workspace",
    descriptor:
      "/workspace — Virtual root container. No real directory created. " +
      "No filesystem write. Descriptor-only. filesystemBlocked=true.",
  },
  {
    path: "/workspace/src",
    descriptor:
      "/workspace/src — Virtual source files root. No real directory created. " +
      "No filesystem write. No shell execution. Descriptor-only.",
  },
  {
    path: "/workspace/src/routes",
    descriptor:
      "/workspace/src/routes — Virtual generated route descriptors. No real files written. " +
      "No code generation. No execution. Descriptor-only.",
  },
  {
    path: "/workspace/src/services",
    descriptor:
      "/workspace/src/services — Virtual generated service descriptors. No real files written. " +
      "No code generation. No execution. Descriptor-only.",
  },
  {
    path: "/workspace/src/schemas",
    descriptor:
      "/workspace/src/schemas — Virtual generated schema descriptors. No real files written. " +
      "No code generation. No execution. Descriptor-only.",
  },
  {
    path: "/workspace/config",
    descriptor:
      "/workspace/config — Virtual workspace configuration descriptors. No real files written. " +
      "No config parsing. No filesystem access. Descriptor-only.",
  },
  {
    path: "/workspace/reports",
    descriptor:
      "/workspace/reports — Virtual build and validation report output. No real files written. " +
      "No filesystem writes. No deployment package. Descriptor-only.",
  },
  {
    path: "/workspace/manifests",
    descriptor:
      "/workspace/manifests — Virtual package manifest descriptors. No real files written. " +
      "No npm/yarn/pnpm execution. No package downloads. Descriptor-only.",
  },
];

function buildVirtualWorkspaceTree(): VirtualWorkspacePath[] {
  return VIRTUAL_PATH_DESCRIPTORS.map((p) => ({
    path:              p.path,
    descriptor:        p.descriptor,
    isVirtual:         true,
    filesystemBlocked: true,
  }));
}

// ---------------------------------------------------------------------------
// Validation checks — 8 required (Phase 239 blueprint)
// ---------------------------------------------------------------------------

function buildValidationChecks(
  input: CreateVirtualWorkspaceInput,
): VirtualWorkspaceValidationCheck[] {
  const {
    templateRecord,
    packageRecord,
    resolutionRecord,
    buildPlanRecord,
    installSimulationRecord,
  } = input;

  const artifactExists           = templateRecord !== null && templateRecord !== undefined;
  const packageExists            = packageRecord !== null && packageRecord !== undefined;
  const resolutionExists         = resolutionRecord !== null && resolutionRecord !== undefined;
  const buildPlanExists          = buildPlanRecord !== null && buildPlanRecord !== undefined;
  const installSimulationExists  = installSimulationRecord !== null && installSimulationRecord !== undefined;
  const workspaceTreeDescriptor  = true; // structural: all paths are virtual descriptors
  const noRealPathsOutsideRoot   = true; // structural: no real filesystem paths constructed
  const outputRemainsVirtual     = true; // structural: record is in-memory, no filesystem ops

  return [
    {
      name:   "artifact_exists",
      status: artifactExists ? "pass" : "fail",
      detail: artifactExists
        ? `Template record "${templateRecord.templateId}" is present`
        : "Template record is missing — workspace cannot be mapped without a template",
    },
    {
      name:   "package_exists",
      status: packageExists ? "pass" : "fail",
      detail: packageExists
        ? `Virtual package record "${packageRecord.packageId}" is present`
        : "Virtual package record is missing — workspace cannot be mapped without a package",
    },
    {
      name:   "resolution_exists",
      status: resolutionExists ? "pass" : "fail",
      detail: resolutionExists
        ? `Dependency resolution record "${resolutionRecord.resolutionId}" is present`
        : "Dependency resolution record is missing — workspace cannot be mapped without resolution",
    },
    {
      name:   "build_plan_exists",
      status: buildPlanExists ? "pass" : "fail",
      detail: buildPlanExists
        ? `Sandbox build plan "${buildPlanRecord.buildPlanId}" is present`
        : "Sandbox build plan is missing — workspace cannot be mapped without a build plan",
    },
    {
      name:   "install_simulation_exists",
      status: installSimulationExists ? "pass" : "fail",
      detail: installSimulationExists
        ? `Install simulation record "${installSimulationRecord.installSimulationId}" is present`
        : "Install simulation record is missing — workspace cannot be mapped without install simulation",
    },
    {
      name:   "workspace_tree_descriptor_only",
      status: workspaceTreeDescriptor ? "pass" : "fail",
      detail: workspaceTreeDescriptor
        ? "All workspace tree paths are virtual descriptors — no real filesystem paths"
        : "Non-descriptor path detected — prohibited in virtual workspace",
    },
    {
      name:   "no_real_paths_outside_virtual_root",
      status: noRealPathsOutsideRoot ? "pass" : "fail",
      detail: noRealPathsOutsideRoot
        ? "No real filesystem paths outside virtual root — structural check"
        : "Real filesystem path detected outside virtual root — prohibited",
    },
    {
      name:   "output_remains_virtual",
      status: outputRemainsVirtual ? "pass" : "fail",
      detail: outputRemainsVirtual
        ? "Workspace record is in-memory only — no filesystem operations triggered"
        : "Output triggered a real filesystem operation — prohibited in virtual workspace",
    },
  ];
}

// ---------------------------------------------------------------------------
// Workspace summary record (per-workspace)
// ---------------------------------------------------------------------------

function buildWorkspaceSummaryRecord(
  tree: VirtualWorkspacePath[],
  checks: VirtualWorkspaceValidationCheck[],
): VirtualWorkspaceSummaryRecord {
  return {
    totalPaths:           tree.length,
    validationPassCount:  checks.filter((c) => c.status === "pass").length,
    validationFailCount:  checks.filter((c) => c.status === "fail").length,
    validationSkipCount:  checks.filter((c) => c.status === "skipped").length,
    workspaceState:       "virtually_mapped",
    approvalRequired:     true,
    executionBlocked:     true,
    deploymentBlocked:    true,
    filesystemBlocked:    true,
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const store: VirtualWorkspaceRecord[] = [];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createVirtualWorkspaceRecord(
  input: CreateVirtualWorkspaceInput,
): VirtualWorkspaceRecord {
  const workspaceId = randomBytes(16).toString("hex");
  const createdAt   = new Date().toISOString();

  const tree    = buildVirtualWorkspaceTree();
  const checks  = buildValidationChecks(input);
  const summary = buildWorkspaceSummaryRecord(tree, checks);

  const record: VirtualWorkspaceRecord = {
    workspaceId,
    templateId:            input.templateRecord.templateId,
    packageId:             input.packageRecord.packageId,
    resolutionId:          input.resolutionRecord.resolutionId,
    buildPlanId:           input.buildPlanRecord.buildPlanId,
    installSimulationId:   input.installSimulationRecord.installSimulationId,
    workspaceState:        "virtually_mapped",
    approvalRequired:      true,
    executionBlocked:      true,
    deploymentBlocked:     true,
    filesystemBlocked:     true,
    virtualWorkspaceTree:  tree,
    workspaceValidationChecks: checks,
    workspaceSummary:      summary,
    createdAt,
  };

  store.push(record);
  return record;
}

export function listVirtualWorkspaceRecords(): VirtualWorkspaceRecord[] {
  return [...store].reverse();
}

export function getVirtualWorkspaceSummary(): VirtualWorkspaceSummary {
  const byWorkspaceState: Record<VirtualWorkspaceState, number> = {
    virtually_mapped: 0,
  };
  for (const r of store) {
    byWorkspaceState[r.workspaceState] =
      (byWorkspaceState[r.workspaceState] ?? 0) + 1;
  }
  return {
    totalWorkspaces:   store.length,
    byWorkspaceState,
    approvalRequired:  true,
    executionBlocked:  true,
    deploymentBlocked: true,
    filesystemBlocked: true,
    implementationPhase: "skeleton",
  };
}
