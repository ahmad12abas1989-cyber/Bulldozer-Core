// Preview Pipeline Core — Phase 244
// Deterministic, non-rendering, in-memory preview descriptor engine.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no real rendering, no browser launch,
// no runtime execution, no generated app launch, no filesystem writes,
// no network access, no vault access, no deployment package,
// no Mother Core mutation.
// Not wired to runtime.ts or startRuntime().

import { randomBytes } from "node:crypto";
import type { VirtualWorkspaceRecord } from "./virtualWorkspaceCore";
import type { SandboxBuildRecord } from "./sandboxBuildCore";
import type { InstallSimulationRecord } from "./installSimulationCore";
import type { TemplateMetadataRecord } from "./templateRegistryCore";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type PreviewPipelineState = "descriptor_preview";

export type PreviewScreenName =
  | "app_home"
  | "list_view"
  | "create_view"
  | "detail_view"
  | "edit_view"
  | "health_view";

export interface PreviewScreenDescriptor {
  readonly screen: number;
  readonly name: PreviewScreenName;
  readonly descriptor: string;
  readonly renderingBlocked: true;
  readonly browserLaunchBlocked: true;
}

export interface PreviewRouteDescriptor {
  readonly routeIndex: number;
  readonly path: string;
  readonly screen: PreviewScreenName;
  readonly descriptor: string;
  readonly executionBlocked: true;
}

export interface PreviewValidationCheck {
  readonly name: string;
  readonly status: "pass" | "fail" | "skipped";
  readonly detail: string;
}

export interface PreviewPipelineSummaryRecord {
  readonly totalScreens: number;
  readonly totalRoutes: number;
  readonly validationPassCount: number;
  readonly validationFailCount: number;
  readonly validationSkipCount: number;
  readonly previewState: PreviewPipelineState;
  readonly approvalRequired: true;
  readonly renderingBlocked: true;
  readonly browserLaunchBlocked: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
}

export interface PreviewPipelineRecord {
  readonly previewId: string;
  readonly workspaceId: string;
  readonly buildPlanId: string;
  readonly installSimulationId: string;
  readonly artifactId: string;
  readonly previewState: PreviewPipelineState;
  readonly approvalRequired: true;
  readonly renderingBlocked: true;
  readonly browserLaunchBlocked: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
  readonly previewScreens: PreviewScreenDescriptor[];
  readonly previewRoutes: PreviewRouteDescriptor[];
  readonly previewValidationChecks: PreviewValidationCheck[];
  readonly previewSummary: PreviewPipelineSummaryRecord;
  readonly createdAt: string;
}

export interface CreatePreviewPipelineInput {
  readonly workspaceRecord: VirtualWorkspaceRecord;
  readonly buildPlanRecord: SandboxBuildRecord;
  readonly installSimulationRecord: InstallSimulationRecord;
  readonly templateRecord: TemplateMetadataRecord;
  readonly operatorApprovalActorId: string;
  readonly operatorApprovalTimestamp: string;
}

export interface PreviewPipelineSummary {
  readonly totalPreviews: number;
  readonly byPreviewState: Record<PreviewPipelineState, number>;
  readonly approvalRequired: true;
  readonly renderingBlocked: true;
  readonly browserLaunchBlocked: true;
  readonly executionBlocked: true;
  readonly deploymentBlocked: true;
  readonly implementationPhase: "skeleton";
}

// ---------------------------------------------------------------------------
// Deterministic preview screen generation (6 fixed screens — Phase 243 blueprint)
// ---------------------------------------------------------------------------

const PREVIEW_SCREEN_DESCRIPTORS: ReadonlyArray<{
  name: PreviewScreenName;
  descriptor: string;
}> = [
  {
    name: "app_home",
    descriptor:
      "Screen 1: app_home — Descriptor: application home view. " +
      "No real rendering. No browser launch. No HTTP request. No DOM. Descriptor-only.",
  },
  {
    name: "list_view",
    descriptor:
      "Screen 2: list_view — Descriptor: resource list view. " +
      "No real rendering. No data fetch. No runtime execution. Descriptor-only.",
  },
  {
    name: "create_view",
    descriptor:
      "Screen 3: create_view — Descriptor: resource creation view. " +
      "No real rendering. No form submission. No write operation. Descriptor-only.",
  },
  {
    name: "detail_view",
    descriptor:
      "Screen 4: detail_view — Descriptor: resource detail view. " +
      "No real rendering. No data fetch. No runtime execution. Descriptor-only.",
  },
  {
    name: "edit_view",
    descriptor:
      "Screen 5: edit_view — Descriptor: resource edit view. " +
      "No real rendering. No form submission. No write operation. Descriptor-only.",
  },
  {
    name: "health_view",
    descriptor:
      "Screen 6: health_view — Descriptor: application health view. " +
      "No real rendering. No health check execution. No runtime probe. Descriptor-only.",
  },
];

function buildPreviewScreens(): PreviewScreenDescriptor[] {
  return PREVIEW_SCREEN_DESCRIPTORS.map((s, idx) => ({
    screen:               idx + 1,
    name:                 s.name,
    descriptor:           s.descriptor,
    renderingBlocked:     true,
    browserLaunchBlocked: true,
  }));
}

// ---------------------------------------------------------------------------
// Deterministic preview route generation — one route per screen
// ---------------------------------------------------------------------------

const PREVIEW_ROUTE_MAP: ReadonlyArray<{ path: string; screen: PreviewScreenName }> = [
  { path: "/",             screen: "app_home"    },
  { path: "/list",         screen: "list_view"   },
  { path: "/create",       screen: "create_view" },
  { path: "/detail/:id",   screen: "detail_view" },
  { path: "/edit/:id",     screen: "edit_view"   },
  { path: "/health",       screen: "health_view" },
];

function buildPreviewRoutes(): PreviewRouteDescriptor[] {
  return PREVIEW_ROUTE_MAP.map((r, idx) => ({
    routeIndex:       idx + 1,
    path:             r.path,
    screen:           r.screen,
    descriptor:
      `Route ${idx + 1}: ${r.path} → ${r.screen} — Descriptor: virtual route mapping. ` +
      "No real routing. No HTTP server. No runtime execution. Descriptor-only.",
    executionBlocked: true,
  }));
}

// ---------------------------------------------------------------------------
// Validation checks — 7 required (Phase 243 blueprint)
// ---------------------------------------------------------------------------

function buildValidationChecks(
  input: CreatePreviewPipelineInput,
  screens: PreviewScreenDescriptor[],
  routes: PreviewRouteDescriptor[],
): PreviewValidationCheck[] {
  const {
    workspaceRecord,
    buildPlanRecord,
    installSimulationRecord,
    templateRecord,
  } = input;

  const workspaceExists         = workspaceRecord !== null && workspaceRecord !== undefined;
  const buildPlanExists         = buildPlanRecord !== null && buildPlanRecord !== undefined;
  const installSimulationExists = installSimulationRecord !== null && installSimulationRecord !== undefined;
  const artifactExists          = templateRecord !== null && templateRecord !== undefined;
  const screensDescriptorOnly   = screens.every((s) => s.renderingBlocked && s.browserLaunchBlocked);
  const routesMapped            = routes.length === screens.length;
  const outputRemainsVirtual    = true; // structural: record is in-memory, no rendering triggered

  return [
    {
      name:   "workspace_exists",
      status: workspaceExists ? "pass" : "fail",
      detail: workspaceExists
        ? `Virtual workspace record "${workspaceRecord.workspaceId}" is present`
        : "Virtual workspace record is missing — preview cannot be generated without a workspace",
    },
    {
      name:   "build_plan_exists",
      status: buildPlanExists ? "pass" : "fail",
      detail: buildPlanExists
        ? `Sandbox build plan "${buildPlanRecord.buildPlanId}" is present`
        : "Sandbox build plan is missing — preview cannot be generated without a build plan",
    },
    {
      name:   "install_simulation_exists",
      status: installSimulationExists ? "pass" : "fail",
      detail: installSimulationExists
        ? `Install simulation record "${installSimulationRecord.installSimulationId}" is present`
        : "Install simulation record is missing — preview cannot be generated without install simulation",
    },
    {
      name:   "artifact_exists",
      status: artifactExists ? "pass" : "fail",
      detail: artifactExists
        ? `Template record "${templateRecord.templateId}" is present`
        : "Template record is missing — preview cannot be generated without a template artifact",
    },
    {
      name:   "preview_screens_descriptor_only",
      status: screensDescriptorOnly ? "pass" : "fail",
      detail: screensDescriptorOnly
        ? `All ${screens.length} preview screens are virtual descriptors — renderingBlocked=true on all`
        : "Non-descriptor screen detected — real rendering is prohibited in preview pipeline",
    },
    {
      name:   "preview_routes_mapped",
      status: routesMapped ? "pass" : "fail",
      detail: routesMapped
        ? `All ${routes.length} preview routes are mapped to screen descriptors`
        : `Route count (${routes.length}) does not match screen count (${screens.length})`,
    },
    {
      name:   "output_remains_virtual",
      status: outputRemainsVirtual ? "pass" : "fail",
      detail: outputRemainsVirtual
        ? "Preview record is in-memory only — no rendering or execution triggered"
        : "Output triggered a real rendering or execution operation — prohibited in preview pipeline",
    },
  ];
}

// ---------------------------------------------------------------------------
// Preview summary record (per-record)
// ---------------------------------------------------------------------------

function buildPreviewSummaryRecord(
  screens: PreviewScreenDescriptor[],
  routes: PreviewRouteDescriptor[],
  checks: PreviewValidationCheck[],
): PreviewPipelineSummaryRecord {
  void routes;
  return {
    totalScreens:         screens.length,
    totalRoutes:          routes.length,
    validationPassCount:  checks.filter((c) => c.status === "pass").length,
    validationFailCount:  checks.filter((c) => c.status === "fail").length,
    validationSkipCount:  checks.filter((c) => c.status === "skipped").length,
    previewState:         "descriptor_preview",
    approvalRequired:     true,
    renderingBlocked:     true,
    browserLaunchBlocked: true,
    executionBlocked:     true,
    deploymentBlocked:    true,
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const store: PreviewPipelineRecord[] = [];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createPreviewPipelineRecord(
  input: CreatePreviewPipelineInput,
): PreviewPipelineRecord {
  const previewId = randomBytes(16).toString("hex");
  const createdAt = new Date().toISOString();

  const screens = buildPreviewScreens();
  const routes  = buildPreviewRoutes();
  const checks  = buildValidationChecks(input, screens, routes);
  const summary = buildPreviewSummaryRecord(screens, routes, checks);

  const record: PreviewPipelineRecord = {
    previewId,
    workspaceId:           input.workspaceRecord.workspaceId,
    buildPlanId:           input.buildPlanRecord.buildPlanId,
    installSimulationId:   input.installSimulationRecord.installSimulationId,
    artifactId:            input.templateRecord.templateId,
    previewState:          "descriptor_preview",
    approvalRequired:      true,
    renderingBlocked:      true,
    browserLaunchBlocked:  true,
    executionBlocked:      true,
    deploymentBlocked:     true,
    previewScreens:        screens,
    previewRoutes:         routes,
    previewValidationChecks: checks,
    previewSummary:        summary,
    createdAt,
  };

  store.push(record);
  return record;
}

export function listPreviewPipelineRecords(): PreviewPipelineRecord[] {
  return [...store].reverse();
}

export function getPreviewPipelineSummary(): PreviewPipelineSummary {
  const byPreviewState: Record<PreviewPipelineState, number> = {
    descriptor_preview: 0,
  };
  for (const r of store) {
    byPreviewState[r.previewState] =
      (byPreviewState[r.previewState] ?? 0) + 1;
  }
  return {
    totalPreviews:        store.length,
    byPreviewState,
    approvalRequired:     true,
    renderingBlocked:     true,
    browserLaunchBlocked: true,
    executionBlocked:     true,
    deploymentBlocked:    true,
    implementationPhase:  "skeleton",
  };
}
