import { createHash } from "node:crypto";
import {
  getWorkspaceVisualShell,
  type VisualWidget,
  type VisualSection,
  type WidgetLayout,
  type DashboardNavigationGroup,
  type WidgetType,
  type WidgetSize,
  type RefreshCategory,
  type SectionId,
} from "./workspaceVisualShell";
import { getWorkspaceObservationLedger } from "./workspaceObservationLedger";
import { getWorkspaceGovernanceScorecard } from "./workspaceGovernanceScorecard";
import { getWorkspaceSummary } from "./workspaceShell";
import { getFullHealth } from "./healthMonitor";
import { getMetrics } from "./metrics";
import { getFreezeStatus } from "./freezeDetector";
import { getCrashStatus } from "./crashDetector";
import { listAuditReports } from "./workspaceAuditReport";

const EXECUTION_BLOCKED: true = true;

// --- Compact data payload types (discriminated on dataType) ---

export interface CompactGovernanceData {
  dataType: "governance";
  governanceScore: number;
  governanceGrade: string;
  dimensionCount: number;
  recommendationCount: number;
  executionBlocked: true;
}

export interface CompactObservationCoverageData {
  dataType: "observation_coverage";
  coveragePercent: number;
  observedPolicies: number;
  unobservedPolicies: number;
  totalPolicies: number;
  executionBlocked: true;
}

export interface CompactExposureData {
  dataType: "exposure";
  exposureScore: number;
  exposureGrade: string;
  totalWritePolicies: number;
  unobservedWritePolicies: number;
  rarelyObservedWritePolicies: number;
  wellObservedWritePolicies: number;
  executionBlocked: true;
}

export interface CompactProbeData {
  dataType: "probe";
  allProbesPassed: boolean;
  passedProbeCount: number;
  failedProbeCount: number;
  totalProbes: number;
  totalProbeTimeMs: number;
  executionBlocked: true;
}

export interface CompactHeatmapData {
  dataType: "heatmap";
  coldCount: number;
  warmCount: number;
  hotCount: number;
  coveragePercent: number;
  executionBlocked: true;
}

export interface CompactTrendData {
  dataType: "trend";
  trendDirection: string | null;
  coverageDelta: number | null;
  currentCoveragePercent: number;
  comparedSnapshotCount: number;
  executionBlocked: true;
}

export interface CompactLedgerData {
  dataType: "ledger";
  overallObservationHealth: string;
  governanceReadiness: string;
  observationCoverage: number;
  exposureRiskLevel: string;
  probeHealth: string;
  executionBlocked: true;
}

export interface CompactHealthData {
  dataType: "health";
  status: string;
  totalChecks: number;
  passingChecks: number;
  failingChecks: number;
  executionBlocked: true;
}

export interface CompactMetricsData {
  dataType: "metrics";
  totalRequests: number;
  totalErrors: number;
  memoryUsedMb: number;
  executionBlocked: true;
}

export interface CompactFreezeData {
  dataType: "freeze";
  status: string;
  freezeCount: number;
  lastLagMs: number;
  executionBlocked: true;
}

export interface CompactCrashData {
  dataType: "crash";
  status: string;
  crashCount: number;
  warningCount: number;
  executionBlocked: true;
}

export interface CompactProjectData {
  dataType: "projects";
  total: number;
  active: number;
  archived: number;
  suspended: number;
  utilizationPercent: number;
  executionBlocked: true;
}

export interface CompactMemberData {
  dataType: "members";
  totalMemberRecords: number;
  projectsWithCustomQuotas: number;
  projectsUsingDefaults: number;
  executionBlocked: true;
}

export interface CompactAuditData {
  dataType: "audit";
  retainedReportCount: number;
  executionBlocked: true;
}

export interface CompactStaticReference {
  dataType: "static_reference";
  sourceEndpoint: string;
  note: string;
  executionBlocked: true;
}

export type CompactDataPayload =
  | CompactGovernanceData
  | CompactObservationCoverageData
  | CompactExposureData
  | CompactProbeData
  | CompactHeatmapData
  | CompactTrendData
  | CompactLedgerData
  | CompactHealthData
  | CompactMetricsData
  | CompactFreezeData
  | CompactCrashData
  | CompactProjectData
  | CompactMemberData
  | CompactAuditData
  | CompactStaticReference;

// --- Composed types ---

export interface ComposedWidget {
  widgetId: string;
  widgetType: WidgetType;
  title: string;
  sourceEndpoint: string;
  recommendedSize: WidgetSize;
  refreshCategory: RefreshCategory;
  compactData: CompactDataPayload;
  executionBlocked: true;
}

export interface ComposedPanel {
  panelId: string;
  title: string;
  description: string;
  sectionId: SectionId;
  panelOrder: number;
  widgets: ComposedWidget[];
  executionBlocked: true;
}

export interface CompositionSummary {
  totalComposedWidgets: number;
  widgetsWithLiveData: number;
  widgetsWithStaticReference: number;
  compactDataTypes: string[];
  governanceScore: number;
  governanceGrade: string;
  observationHealth: string;
  observationCoverage: number;
  executionBlocked: true;
}

export interface WorkspaceVisualShellComposed {
  composedId: string;
  generatedAt: string;
  shellId: string;
  sections: VisualSection[];
  composedPanels: ComposedPanel[];
  navigationGroups: DashboardNavigationGroup[];
  layout: WidgetLayout;
  compositionSummary: CompositionSummary;
  executionBlocked: true;
}

// --- Live data bundle (fetched once per composition call) ---

interface LiveBundle {
  ledger: ReturnType<typeof getWorkspaceObservationLedger>;
  scorecard: ReturnType<typeof getWorkspaceGovernanceScorecard>;
  summary: ReturnType<typeof getWorkspaceSummary>;
  health: ReturnType<typeof getFullHealth>;
  metrics: ReturnType<typeof getMetrics>;
  freeze: ReturnType<typeof getFreezeStatus>;
  crash: ReturnType<typeof getCrashStatus>;
  auditReportCount: number;
}

function fetchLiveBundle(): LiveBundle {
  const ledger = getWorkspaceObservationLedger();
  const scorecard = getWorkspaceGovernanceScorecard();
  const summary = getWorkspaceSummary();
  const health = getFullHealth();
  const metrics = getMetrics();
  const freeze = getFreezeStatus();
  const crash = getCrashStatus();
  const auditResult = listAuditReports({ limit: 10 });
  return {
    ledger,
    scorecard,
    summary,
    health,
    metrics,
    freeze,
    crash,
    auditReportCount: auditResult.reports.length,
  };
}

// --- Compact data extractors (keyed by widgetId) ---

type CompactExtractor = (b: LiveBundle) => CompactDataPayload;

function governancePayload(b: LiveBundle): CompactGovernanceData {
  return {
    dataType: "governance",
    governanceScore: b.ledger.governance.governanceScore,
    governanceGrade: b.ledger.governance.governanceGrade,
    dimensionCount: b.scorecard.breakdown.length,
    recommendationCount: b.scorecard.recommendations.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function observationCoveragePayload(b: LiveBundle): CompactObservationCoverageData {
  return {
    dataType: "observation_coverage",
    coveragePercent: b.ledger.compliance.coveragePercent,
    observedPolicies: b.ledger.compliance.observedPolicies,
    unobservedPolicies: b.ledger.compliance.unobservedPolicies,
    totalPolicies: b.ledger.compliance.totalPolicies,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function exposurePayload(b: LiveBundle): CompactExposureData {
  return {
    dataType: "exposure",
    exposureScore: b.ledger.exposure.exposureScore,
    exposureGrade: b.ledger.exposure.exposureGrade,
    totalWritePolicies: b.ledger.exposure.totalWritePolicies,
    unobservedWritePolicies: b.ledger.exposure.unobservedWritePolicies,
    rarelyObservedWritePolicies: b.ledger.exposure.rarelyObservedWritePolicies,
    wellObservedWritePolicies: b.ledger.exposure.wellObservedWritePolicies,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function probePayload(b: LiveBundle): CompactProbeData {
  return {
    dataType: "probe",
    allProbesPassed: b.ledger.probe.allProbesPassed,
    passedProbeCount: b.ledger.probe.passedProbeCount,
    failedProbeCount: b.ledger.probe.failedProbeCount,
    totalProbes: b.ledger.probe.totalProbes,
    totalProbeTimeMs: b.ledger.probe.totalProbeTimeMs,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function heatmapPayload(b: LiveBundle): CompactHeatmapData {
  return {
    dataType: "heatmap",
    coldCount: b.ledger.heatmap.coldCount,
    warmCount: b.ledger.heatmap.warmCount,
    hotCount: b.ledger.heatmap.hotCount,
    coveragePercent: b.ledger.heatmap.coveragePercent,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function trendPayload(b: LiveBundle): CompactTrendData {
  return {
    dataType: "trend",
    trendDirection: b.ledger.trend.trendDirection,
    coverageDelta: b.ledger.trend.coverageDelta,
    currentCoveragePercent: b.ledger.trend.currentCoveragePercent,
    comparedSnapshotCount: b.ledger.trend.comparedSnapshotCount,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function ledgerPayload(b: LiveBundle): CompactLedgerData {
  return {
    dataType: "ledger",
    overallObservationHealth: b.ledger.summary.overallObservationHealth,
    governanceReadiness: b.ledger.summary.governanceReadiness,
    observationCoverage: b.ledger.summary.observationCoverage,
    exposureRiskLevel: b.ledger.summary.exposureRiskLevel,
    probeHealth: b.ledger.summary.probeHealth,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function healthPayload(b: LiveBundle): CompactHealthData {
  const passing = b.health.checks.filter((c) => c.status === "pass").length;
  const failing = b.health.checks.filter((c) => c.status === "fail").length;
  return {
    dataType: "health",
    status: b.health.status,
    totalChecks: b.health.checks.length,
    passingChecks: passing,
    failingChecks: failing,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function metricsPayload(b: LiveBundle): CompactMetricsData {
  const memMb = Math.round(b.metrics.memory.heapUsed / 1_048_576);
  return {
    dataType: "metrics",
    totalRequests: b.metrics.requests.total,
    totalErrors: b.metrics.errors.total,
    memoryUsedMb: memMb,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function freezePayload(b: LiveBundle): CompactFreezeData {
  return {
    dataType: "freeze",
    status: b.freeze.status,
    freezeCount: b.freeze.freezeCount,
    lastLagMs: b.freeze.lastLagMs,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function crashPayload(b: LiveBundle): CompactCrashData {
  return {
    dataType: "crash",
    status: b.crash.status,
    crashCount: b.crash.crashCount,
    warningCount: b.crash.warningCount,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function projectPayload(b: LiveBundle): CompactProjectData {
  return {
    dataType: "projects",
    total: b.summary.projects.total,
    active: b.summary.projects.active,
    archived: b.summary.projects.archived,
    suspended: b.summary.projects.suspended,
    utilizationPercent: b.summary.capacity.utilizationPercent,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function memberPayload(b: LiveBundle): CompactMemberData {
  return {
    dataType: "members",
    totalMemberRecords: b.summary.members.totalRecords,
    projectsWithCustomQuotas: b.summary.quotas.projectsWithCustomQuotas,
    projectsUsingDefaults: b.summary.quotas.projectsUsingDefaults,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function auditPayload(b: LiveBundle): CompactAuditData {
  return {
    dataType: "audit",
    retainedReportCount: b.auditReportCount,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function staticRef(sourceEndpoint: string, note: string): CompactExtractor {
  return (_b: LiveBundle): CompactStaticReference => ({
    dataType: "static_reference",
    sourceEndpoint,
    note,
    executionBlocked: EXECUTION_BLOCKED,
  });
}

// --- Widget ID → extractor map ---

const WIDGET_EXTRACTORS: Record<string, CompactExtractor> = {
  // Governance section
  "governance-score-gauge":      governancePayload,
  "governance-grade-badge":      governancePayload,
  "governance-breakdown-table":  governancePayload,
  "governance-recommendations":  governancePayload,
  "compliance-coverage-gauge":   observationCoveragePayload,
  "compliance-policy-table":     observationCoveragePayload,
  "exposure-score-metric":       exposurePayload,
  "exposure-grade-badge":        exposurePayload,
  "exposure-risk-table":         exposurePayload,
  // Observation section
  "heatmap-matrix":              heatmapPayload,
  "heatmap-coverage-pct":        heatmapPayload,
  "heatmap-band-counts":         heatmapPayload,
  "coverage-trend-chart":        trendPayload,
  "coverage-delta-badge":        trendPayload,
  "coverage-delta-value":        trendPayload,
  "probe-status-badge":          probePayload,
  "probe-timing-table":          probePayload,
  "probe-pass-count":            probePayload,
  "ledger-analytics-scorecard":  ledgerPayload,
  "ledger-history-chart":        ledgerPayload,
  "ledger-transitions-metric":   ledgerPayload,
  // Diagnostics section
  "health-status-badge":         healthPayload,
  "health-checks-table":         healthPayload,
  "memory-usage-gauge":          metricsPayload,
  "request-count-metric":        metricsPayload,
  "error-count-metric":          metricsPayload,
  "freeze-status-badge":         freezePayload,
  "crash-status-badge":          crashPayload,
  // Projects section
  "project-count-metric":        projectPayload,
  "capacity-gauge":              projectPayload,
  "projects-status-table":       projectPayload,
  "member-count-metric":         memberPayload,
  "quota-coverage-metric":       memberPayload,
  // Activity section
  "timeline-feed":               staticRef("/api/workspace/timeline",         "Live timeline data — fetch from sourceEndpoint for full event list"),
  "diff-pairs-table":            staticRef("/api/workspace/diff",              "Diff pair data — fetch from sourceEndpoint for full snapshot comparison list"),
  "audit-reports-list":          auditPayload,
  "audit-digest-scorecard":      auditPayload,
};

// --- Composition logic ---

function composeWidget(widget: VisualWidget, bundle: LiveBundle): ComposedWidget {
  const extractor = WIDGET_EXTRACTORS[widget.widgetId];
  const compactData: CompactDataPayload = extractor
    ? extractor(bundle)
    : { dataType: "static_reference", sourceEndpoint: widget.sourceEndpoint, note: "No compact extractor registered for this widget", executionBlocked: EXECUTION_BLOCKED };

  return {
    widgetId: widget.widgetId,
    widgetType: widget.widgetType,
    title: widget.title,
    sourceEndpoint: widget.sourceEndpoint,
    recommendedSize: widget.recommendedSize,
    refreshCategory: widget.refreshCategory,
    compactData,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function buildCompositionSummary(
  composedPanels: ComposedPanel[],
  bundle: LiveBundle,
): CompositionSummary {
  const allWidgets = composedPanels.flatMap((p) => p.widgets);
  const totalComposedWidgets = allWidgets.length;
  const widgetsWithStaticReference = allWidgets.filter(
    (w) => w.compactData.dataType === "static_reference",
  ).length;
  const widgetsWithLiveData = totalComposedWidgets - widgetsWithStaticReference;
  const dataTypeSet = new Set(allWidgets.map((w) => w.compactData.dataType));
  const compactDataTypes = Array.from(dataTypeSet).sort();

  return {
    totalComposedWidgets,
    widgetsWithLiveData,
    widgetsWithStaticReference,
    compactDataTypes,
    governanceScore: bundle.ledger.governance.governanceScore,
    governanceGrade: bundle.ledger.governance.governanceGrade,
    observationHealth: bundle.ledger.summary.overallObservationHealth,
    observationCoverage: bundle.ledger.summary.observationCoverage,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Public API ---

export function getWorkspaceVisualShellComposed(): WorkspaceVisualShellComposed {
  const generatedAt = new Date().toISOString();
  const composedId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  const shell = getWorkspaceVisualShell();
  const bundle = fetchLiveBundle();

  const composedPanels: ComposedPanel[] = shell.panels.map((panel) => ({
    panelId: panel.panelId,
    title: panel.title,
    description: panel.description,
    sectionId: panel.sectionId,
    panelOrder: panel.panelOrder,
    widgets: panel.widgets.map((w) => composeWidget(w, bundle)),
    executionBlocked: EXECUTION_BLOCKED,
  }));

  const compositionSummary = buildCompositionSummary(composedPanels, bundle);

  return {
    composedId,
    generatedAt,
    shellId: shell.shellId,
    sections: shell.sections,
    composedPanels,
    navigationGroups: shell.navigationGroups,
    layout: shell.layout,
    compositionSummary,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
