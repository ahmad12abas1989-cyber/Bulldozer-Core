// Preview Pipeline Observe Route — Phase 245
// GET /api/preview/pipelines
// Read-only diagnostic view of the in-memory preview pipeline registry.
// No preview creation, no real rendering, no browser launch,
// no runtime execution, no generated app launch, no filesystem writes,
// no network access, no vault access, no deployment package.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  listPreviewPipelineRecords,
  getPreviewPipelineSummary,
} from "../core/previewPipelineCore";

export function handlePreviewPipelineObserve(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  const previews = listPreviewPipelineRecords();
  const summary  = getPreviewPipelineSummary();

  sendJson(res, 200, {
    generatedAt:          new Date().toISOString(),
    previewEnabled:       false,
    renderingEnabled:     false,
    browserLaunchEnabled: false,
    executionEnabled:     false,
    deploymentEnabled:    false,
    persistenceEnabled:   false,
    renderingBlocked:     true,
    browserLaunchBlocked: true,
    executionBlocked:     true,
    deploymentBlocked:    true,
    totalPreviews:        previews.length,
    summary,
    previews,
  });
}
