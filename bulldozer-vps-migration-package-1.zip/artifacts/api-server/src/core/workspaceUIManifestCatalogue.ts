export interface UIManifestEntry {
  path: string;
  layerId: string;
  description: string;
  dataShape: string;
  executionBlocked: true;
}

export interface UIManifestCatalogue {
  generatedAt: string;
  totalEntries: number;
  entries: UIManifestEntry[];
  executionBlocked: true;
}

const CATALOGUE_ENTRIES: ReadonlyArray<Omit<UIManifestEntry, "executionBlocked">> = [
  {
    path: "/api/workspace/ui/audit",
    layerId: "audit",
    description: "UI Layer Audit — read-only cross-check of all 8 UI manifest layers; calls each manifest getter directly; UILayerAudit: generatedAt, auditVersion, layersChecked, allHealthy, checks[] (layerId, endpoint, healthy, totalInvariantValid, executionBlocked)",
    dataShape: "UILayerAudit { generatedAt: string; auditVersion: string; layersChecked: number; allHealthy: boolean; checks: UIAuditCheck[]; executionBlocked: true }",
  },
  {
    path: "/api/workspace/ui/badges",
    layerId: "badges",
    description: "UI Governance Badges Manifest — flat list of governance signal badges derived from the render model; UIBadgeManifest: generatedAt, totalBadges=5, badges[] sorted alphabetically by badgeId (badgeId, label, signalType, sourceEndpoint, refreshMode, executionBlocked)",
    dataShape: "UIBadgeManifest { generatedAt: string; totalBadges: number; badges: UIBadgeEntry[]; executionBlocked: true }",
  },
  {
    path: "/api/workspace/ui/bindings",
    layerId: "bindings",
    description: "UI Data Bindings Manifest — flat list of data bindings derived from the render model; UIBindingManifest: generatedAt, totalBindings=18, bindings[] sorted alphabetically by sourceEndpoint (sourceEndpoint, readOnly=true, mutationAllowed=false, requiresApproval=false, executionBlocked)",
    dataShape: "UIBindingManifest { generatedAt: string; totalBindings: number; bindings: UIBindingEntry[]; executionBlocked: true }",
  },
  {
    path: "/api/workspace/ui/layout",
    layerId: "layout",
    description: "UI Layout Manifest — scalar layout configuration derived from the render model; UILayoutManifest: generatedAt, layout (appName, shellType, sidebarEnabled, topbarEnabled, contentGrid, executionBlocked)",
    dataShape: "UILayoutManifest { generatedAt: string; layout: UILayoutConfig; executionBlocked: true }",
  },
  {
    path: "/api/workspace/ui/navigation",
    layerId: "navigation",
    description: "UI Navigation Manifest — grouped navigation structure derived from the render model; UINavigationManifest: generatedAt, totalGroups=5, groups[] sorted by groupOrder (groupId, title, items[] sorted by itemOrder, itemCount, executionBlocked), defaultPage='overview'",
    dataShape: "UINavigationManifest { generatedAt: string; totalGroups: number; groups: UINavigationGroup[]; defaultPage: string; executionBlocked: true }",
  },
  {
    path: "/api/workspace/ui/pages",
    layerId: "pages",
    description: "UI Page Manifest — page registry derived from the render model and skeleton; UIPageManifest: generatedAt, totalPages=5, pages[] sorted by pageOrder (pageId, title, route, sectionIds[], description, panelCount, executionBlocked)",
    dataShape: "UIPageManifest { generatedAt: string; totalPages: number; pages: UIPageEntry[]; executionBlocked: true }",
  },
  {
    path: "/api/workspace/ui/panels",
    layerId: "panels",
    description: "UI Panel Manifest — panel registry combining skeleton panel layouts with render model panel titles; UIPanelManifest: generatedAt, totalPanels=15, panels[] sorted alphabetically by panelId (panelId, title, pageId, widgetCount, cardStyle, layoutDirection, executionBlocked)",
    dataShape: "UIPanelManifest { generatedAt: string; totalPanels: number; panels: UIPanelEntry[]; executionBlocked: true }",
  },
  {
    path: "/api/workspace/ui/theme",
    layerId: "theme",
    description: "UI Theme Manifest — scalar theme token configuration derived from the render model; UIThemeManifest: generatedAt, themeTokens (colorMode=dark, density=compact, cardRadius=4px, gridGap=16px, typographyScale=sm, executionBlocked)",
    dataShape: "UIThemeManifest { generatedAt: string; themeTokens: UIThemeTokens; executionBlocked: true }",
  },
  {
    path: "/api/workspace/ui/widgets",
    layerId: "widgets",
    description: "UI Widget Manifest — flat widget registry derived from the render model; UIWidgetManifest: generatedAt, totalWidgets=37, widgets[] sorted alphabetically by widgetId (widgetId, type, panelId, dataSourceEndpoint, refreshMode, executionBlocked)",
    dataShape: "UIWidgetManifest { generatedAt: string; totalWidgets: number; widgets: UIWidgetEntry[]; executionBlocked: true }",
  },
];

export function getUIManifestCatalogue(): UIManifestCatalogue {
  const entries: UIManifestEntry[] = CATALOGUE_ENTRIES.map((e) => ({
    ...e,
    executionBlocked: true,
  }));
  return {
    generatedAt: new Date().toISOString(),
    totalEntries: entries.length,
    entries,
    executionBlocked: true,
  };
}
