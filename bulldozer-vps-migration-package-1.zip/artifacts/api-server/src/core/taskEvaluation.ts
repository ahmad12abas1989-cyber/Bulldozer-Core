import { logger } from "../lib/logger";
import { emit, subscribe } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { getTask, markTaskBlocked } from "./taskQueue";
import { evaluateTaskPolicy, type PolicyDecision } from "./taskPolicy";

export type EvaluationCategory = "safe" | "warning" | "blocked";

export interface EvaluationResult {
  category: EvaluationCategory;
  reason: string;
}

export interface TaskEvaluationState {
  evaluationMode: "controlled";
  executionStillBlocked: true;
  totalEvaluations: number;
  approvedTasks: number;
  blockedTasks: number;
  warningTasks: number;
  lastEvaluationAt: string | null;
  lastBlockedReason: string | null;
}

const EVALUATION_MODE = "controlled" as const;
const EXECUTION_STILL_BLOCKED: true = true;

let totalEvaluations = 0;
let approvedCount = 0;
let blockedCount = 0;
let warningCount = 0;
let lastEvaluationAt: string | null = null;
let lastBlockedReason: string | null = null;

function policyDecisionToCategory(decision: PolicyDecision): EvaluationCategory {
  switch (decision) {
    case "allow": return "safe";
    case "warn": return "warning";
    case "approval_required": return "warning";
    case "block": return "blocked";
  }
}

export function evaluateTaskSafety(task: { type: string; payload: unknown }): EvaluationResult {
  const policyResult = evaluateTaskPolicy(task);
  return {
    category: policyDecisionToCategory(policyResult.decision),
    reason: policyResult.reason,
  };
}

export function evaluateTask(task: { id: string; type: string; payload: unknown }): EvaluationResult {
  const now = new Date().toISOString();
  const result = evaluateTaskSafety(task);

  totalEvaluations++;
  lastEvaluationAt = now;

  if (result.category === "blocked") {
    blockedCount++;
    lastBlockedReason = result.reason;
    markTaskBlocked(task.id, result.reason);
    emit("task_evaluation:blocked", "task-evaluation", { id: task.id, type: task.type, reason: result.reason });
    logger.warn({ id: task.id, type: task.type, reason: result.reason }, "Task evaluation: blocked");
  } else if (result.category === "warning") {
    warningCount++;
    emit("task_evaluation:warning", "task-evaluation", { id: task.id, type: task.type, reason: result.reason });
    logger.warn({ id: task.id, type: task.type, reason: result.reason }, "Task evaluation: warning");
  } else {
    approvedCount++;
    emit("task_evaluation:approved", "task-evaluation", { id: task.id, type: task.type });
    logger.info({ id: task.id, type: task.type }, "Task evaluation: approved");
  }

  if (totalEvaluations === 1) {
    addTimelineEvent({
      level: "info",
      source: "task-evaluation",
      message: `First task evaluated: ${result.category} — ${task.type}`,
      metadata: { id: task.id, category: result.category },
    });
  }

  return result;
}

export function getTaskEvaluationStatus(): TaskEvaluationState & { timestamp: string } {
  return {
    evaluationMode: EVALUATION_MODE,
    executionStillBlocked: EXECUTION_STILL_BLOCKED,
    totalEvaluations,
    approvedTasks: approvedCount,
    blockedTasks: blockedCount,
    warningTasks: warningCount,
    lastEvaluationAt,
    lastBlockedReason,
    timestamp: new Date().toISOString(),
  };
}

export function initTaskEvaluation(): void {
  subscribe("task_queue:task_created", (event) => {
    const id = event.payload["id"] as string;
    const task = id ? getTask(id) : undefined;
    if (task) {
      evaluateTask(task);
    }
  });

  emit("task_evaluation:initialized", "task-evaluation", {});
  addTimelineEvent({
    level: "info",
    source: "task-evaluation",
    message: "Task evaluation layer initialized",
  });
  logger.info({ evaluationMode: EVALUATION_MODE, executionStillBlocked: EXECUTION_STILL_BLOCKED }, "Task evaluation layer initialized");
}
