import type { IncomingMessage, ServerResponse } from "node:http";
import { getTaskPersistenceStatus } from "../core/taskPersistence";
import { sendJson } from "../lib/response";

export function handleTaskPersistence(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getTaskPersistenceStatus());
}
