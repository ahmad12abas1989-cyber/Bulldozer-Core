// Virtual Package Core — Phase 224
// Deterministic, non-executing, in-memory virtual package registry.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no filesystem writes, no package
// installation, no runtime execution, no deployment packaging, no sandbox
// execution, no external registry access, no plugin install execution.
// Not wired to runtime.ts or startRuntime().

import { randomBytes } from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type PackageValidationState = "structurally_valid" | "failed" | "pending";

export type PackageType = "crud_app_package";

export interface VirtualDependency {
  name: string;
  version: string;
  category: "runtime" | "devDependency" | "peerDependency";
  descriptor: string;
}

export interface VirtualScriptDescriptor {
  name: string;
  descriptor: string;
}

export interface VirtualBuildDescriptor {
  tool: string;
  outputFormat: string;
  descriptor: string;
}

export interface VirtualRuntimeDescriptor {
  nodeVersion: string;
  environmentType: "development" | "production";
  descriptor: string;
}

export interface VirtualVersionDescriptor {
  semver: string;
  releaseType: "patch" | "minor" | "major" | "prerelease";
  descriptor: string;
}

export interface PackageValidationCheck {
  name: string;
  status: "pass" | "fail" | "skipped";
  detail: string;
}

export interface VirtualPackageRecord {
  readonly packageId: string;
  readonly artifactId: string;
  readonly generationId: string;
  readonly packageType: PackageType;
  readonly approvalRequired: true;
  readonly validationState: PackageValidationState;
  readonly packageJsonDescriptor: string;
  readonly dependencies: VirtualDependency[];
  readonly scriptManifest: VirtualScriptDescriptor[];
  readonly buildManifest: VirtualBuildDescriptor;
  readonly runtimeManifest: VirtualRuntimeDescriptor;
  readonly versionManifest: VirtualVersionDescriptor;
  readonly validationChecks: PackageValidationCheck[];
  readonly dependencyCount: number;
  readonly scriptCount: number;
  readonly createdAt: string;
}

export interface CreateVirtualPackageInput {
  artifactId: string;
  generationId: string;
  projectName: string;
  requestedByActorType: string;
  requestedByActorId: string;
}

export interface VirtualPackageSummary {
  totalPackages: number;
  byValidationState: Record<PackageValidationState, number>;
  pendingReviewCount: number;
  packageType: PackageType;
  approvalRequired: true;
  executionEnabled: false;
  installationEnabled: false;
  persistenceEnabled: false;
  implementationPhase: "skeleton";
}

// ---------------------------------------------------------------------------
// Floating version detector — rejects latest / ^ / ~ / * / ranges
// ---------------------------------------------------------------------------

const FORBIDDEN_VERSION_PATTERNS = [
  /^latest$/i,
  /^\*/,
  /^\^/,
  /^~/,
  /^>/,
  /^</,
  /^=/,
  /^x\./i,
];

function isFixedVersion(version: string): boolean {
  return !FORBIDDEN_VERSION_PATTERNS.some((re) => re.test(version.trim()));
}

// ---------------------------------------------------------------------------
// Deterministic dependency list — 6 fixed-version entries
// ---------------------------------------------------------------------------

function buildDependencies(projectName: string): VirtualDependency[] {
  const name = projectName.toLowerCase().replace(/[^a-z0-9]/g, "-");
  return [
    {
      name: "node",
      version: "24.0.0",
      category: "runtime",
      descriptor: `Node.js runtime for ${name}. Fixed version only — no floating range permitted.`,
    },
    {
      name: "typescript",
      version: "5.9.0",
      category: "devDependency",
      descriptor: `TypeScript compiler for ${name}. Fixed version only — no floating range permitted.`,
    },
    {
      name: "zod",
      version: "3.23.8",
      category: "runtime",
      descriptor: `Schema validation library for ${name} request/response types. Fixed version only.`,
    },
    {
      name: "esbuild",
      version: "0.25.0",
      category: "devDependency",
      descriptor: `ESM bundler for ${name} production build. Fixed version only — no floating range permitted.`,
    },
    {
      name: "tsx",
      version: "4.19.0",
      category: "devDependency",
      descriptor: `TypeScript runner for ${name} development mode. Fixed version only — no floating range permitted.`,
    },
    {
      name: `@${name}/types`,
      version: "0.1.0",
      category: "peerDependency",
      descriptor: `Virtual type package for ${name}. Fixed version only — text descriptor only, not a real installable package.`,
    },
  ];
}

// ---------------------------------------------------------------------------
// Script manifest — 4 virtual script stubs (no executable bodies)
// ---------------------------------------------------------------------------

function buildScriptManifest(projectName: string): VirtualScriptDescriptor[] {
  return [
    {
      name: "dev",
      descriptor: `Development server script for ${projectName}. Runs tsx in watch mode. Virtual descriptor only — no executable body.`,
    },
    {
      name: "build",
      descriptor: `Production build script for ${projectName}. Runs esbuild to produce ESM bundle. Virtual descriptor only — no executable body.`,
    },
    {
      name: "typecheck",
      descriptor: `TypeScript type-check script for ${projectName}. Runs tsc --noEmit. Virtual descriptor only — no executable body.`,
    },
    {
      name: "start",
      descriptor: `Production start script for ${projectName}. Runs the compiled ESM bundle. Virtual descriptor only — no executable body.`,
    },
  ];
}

// ---------------------------------------------------------------------------
// Build manifest
// ---------------------------------------------------------------------------

function buildBuildDescriptor(projectName: string): VirtualBuildDescriptor {
  return {
    tool: "esbuild",
    outputFormat: "esm",
    descriptor: `Virtual build configuration for ${projectName}. Tool: esbuild, format: ESM, target: node24. Text descriptor only — not a real build config.`,
  };
}

// ---------------------------------------------------------------------------
// Runtime manifest
// ---------------------------------------------------------------------------

function buildRuntimeDescriptor(projectName: string): VirtualRuntimeDescriptor {
  return {
    nodeVersion: "24.0.0",
    environmentType: "production",
    descriptor: `Virtual runtime environment for ${projectName}. Node.js 24.0.0, production mode, zero-framework. Text descriptor only — not a real runtime config.`,
  };
}

// ---------------------------------------------------------------------------
// Version manifest
// ---------------------------------------------------------------------------

function buildVersionDescriptor(projectName: string): VirtualVersionDescriptor {
  return {
    semver: "0.1.0",
    releaseType: "minor",
    descriptor: `Virtual version manifest for ${projectName}. Initial version 0.1.0. All versions are fixed — no floating ranges or latest tags permitted.`,
  };
}

// ---------------------------------------------------------------------------
// Package.json descriptor — text only, never real installable JSON
// ---------------------------------------------------------------------------

function buildPackageJsonDescriptor(projectName: string): string {
  return (
    `Virtual package.json descriptor for ${projectName}. ` +
    `Text description only — not a real installable package.json. ` +
    `No dependencies object, no scripts block, no engines field. ` +
    `packageType=crud_app_package, approvalRequired=true, installationEnabled=false.`
  );
}

// ---------------------------------------------------------------------------
// Validation checks — 8 structural checks
// ---------------------------------------------------------------------------

function buildValidationChecks(
  deps: VirtualDependency[],
  scripts: VirtualScriptDescriptor[],
  build: VirtualBuildDescriptor,
  runtime: VirtualRuntimeDescriptor,
  version: VirtualVersionDescriptor,
): PackageValidationCheck[] {
  const allVersionsFixed = deps.every((d) => isFixedVersion(d.version));
  const hasDependencies  = deps.length > 0;
  const hasScripts       = scripts.length > 0;
  const hasBuildManifest = build.tool.length > 0;
  const hasRuntimeManifest = runtime.nodeVersion.length > 0;
  const hasVersionManifest = version.semver.length > 0;
  const noLatestTags     = deps.every((d) => !/latest/i.test(d.version));
  const noFloatingRanges = deps.every((d) => isFixedVersion(d.version));

  return [
    {
      name: "dependency_manifest_present",
      status: hasDependencies ? "pass" : "fail",
      detail: hasDependencies
        ? `${deps.length} virtual dependency entries declared`
        : "No dependency entries declared",
    },
    {
      name: "version_manifest_present",
      status: hasVersionManifest ? "pass" : "fail",
      detail: hasVersionManifest
        ? `Version manifest present: ${version.semver}`
        : "Version manifest missing",
    },
    {
      name: "build_manifest_present",
      status: hasBuildManifest ? "pass" : "fail",
      detail: hasBuildManifest
        ? `Build manifest present: tool=${build.tool}, format=${build.outputFormat}`
        : "Build manifest missing",
    },
    {
      name: "runtime_manifest_present",
      status: hasRuntimeManifest ? "pass" : "fail",
      detail: hasRuntimeManifest
        ? `Runtime manifest present: node=${runtime.nodeVersion}, env=${runtime.environmentType}`
        : "Runtime manifest missing",
    },
    {
      name: "script_manifest_present",
      status: hasScripts ? "pass" : "fail",
      detail: hasScripts
        ? `${scripts.length} virtual script descriptors declared`
        : "Script manifest missing",
    },
    {
      name: "fixed_versions_only",
      status: allVersionsFixed ? "pass" : "fail",
      detail: allVersionsFixed
        ? "All dependency versions are fixed — no floating ranges detected"
        : "Floating version range detected — latest/^/~/*/> are prohibited",
    },
    {
      name: "no_latest_tags",
      status: noLatestTags ? "pass" : "fail",
      detail: noLatestTags
        ? "No latest tags detected in dependency versions"
        : "latest tag detected — prohibited",
    },
    {
      name: "install_execution",
      status: "skipped",
      detail: "Install execution check skipped — installationEnabled=false in this phase",
    },
    {
      name: "no_floating_ranges",
      status: noFloatingRanges ? "pass" : "fail",
      detail: noFloatingRanges
        ? "No floating ranges (^/~/*/>) detected in dependency versions"
        : "Floating range detected — ^/~/*/> are prohibited",
    },
  ];
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const store: VirtualPackageRecord[] = [];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createVirtualPackageRecord(
  input: CreateVirtualPackageInput,
): VirtualPackageRecord {
  const packageId    = randomBytes(16).toString("hex");
  const createdAt    = new Date().toISOString();
  const deps         = buildDependencies(input.projectName);
  const scripts      = buildScriptManifest(input.projectName);
  const build        = buildBuildDescriptor(input.projectName);
  const runtime      = buildRuntimeDescriptor(input.projectName);
  const version      = buildVersionDescriptor(input.projectName);
  const checks       = buildValidationChecks(deps, scripts, build, runtime, version);
  const pkgJsonDesc  = buildPackageJsonDescriptor(input.projectName);

  const record: VirtualPackageRecord = {
    packageId,
    artifactId:           input.artifactId,
    generationId:         input.generationId,
    packageType:          "crud_app_package",
    approvalRequired:     true,
    validationState:      "structurally_valid",
    packageJsonDescriptor: pkgJsonDesc,
    dependencies:         deps,
    scriptManifest:       scripts,
    buildManifest:        build,
    runtimeManifest:      runtime,
    versionManifest:      version,
    validationChecks:     checks,
    dependencyCount:      deps.length,
    scriptCount:          scripts.length,
    createdAt,
  };

  store.push(record);
  return record;
}

export function listVirtualPackageRecords(): VirtualPackageRecord[] {
  return [...store].reverse();
}

export function getVirtualPackageSummary(): VirtualPackageSummary {
  const byValidationState: Record<PackageValidationState, number> = {
    structurally_valid: 0,
    failed:  0,
    pending: 0,
  };
  for (const r of store) {
    byValidationState[r.validationState] =
      (byValidationState[r.validationState] ?? 0) + 1;
  }
  return {
    totalPackages:      store.length,
    byValidationState,
    pendingReviewCount: store.filter((r) => r.validationState === "pending").length,
    packageType:        "crud_app_package",
    approvalRequired:   true,
    executionEnabled:   false,
    installationEnabled: false,
    persistenceEnabled: false,
    implementationPhase: "skeleton",
  };
}
