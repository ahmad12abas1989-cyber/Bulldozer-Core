// Virtual Workspace Observe Route — Phase 241
// GET /api/workspaces/virtual
// Read-only diagnostic view of the in-memory virtual workspace registry.
// No workspace creation, no real directory creation, no filesystem writes,
// no package installation, no shell execution, no network access,
// no vault access, no runtime execution, no deployment package.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  listVirtualWorkspaceRecords,
  getVirtualWorkspaceSummary,
} from "../core/virtualWorkspaceCore";

export function handleVirtualWorkspaceObserve(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  const workspaces = listVirtualWorkspaceRecords();
  const summary    = getVirtualWorkspaceSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    workspaceEnabled:   false,
    filesystemEnabled:  false,
    executionEnabled:   false,
    deploymentEnabled:  false,
    persistenceEnabled: false,
    filesystemBlocked:  true,
    executionBlocked:   true,
    deploymentBlocked:  true,
    totalWorkspaces:    workspaces.length,
    summary,
    workspaces,
  });
}
