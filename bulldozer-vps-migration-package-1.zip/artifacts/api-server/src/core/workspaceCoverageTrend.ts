import { createHash } from "node:crypto";
import {
  getPolicyComplianceLedger,
  type ComplianceLedgerEntry,
} from "./workspacePolicyComplianceLedger";
import { listWorkspaceSnapshots } from "./workspaceSnapshots";

const EXECUTION_BLOCKED: true = true;
const HOT_MIN = 10;
const WARM_MIN = 1;
const MAX_COMPARE = 5;

// --- Types ---

export type TrendDirection = "improving" | "stable" | "degrading";

export interface HeatShift {
  hotCountCurrent: number;
  warmCountCurrent: number;
  coldCountCurrent: number;
  observedDelta: number | null;
  unobservedDelta: number | null;
  executionBlocked: true;
}

export interface SnapshotCoveragePoint {
  snapshotId: string;
  snapshotCreatedAt: string;
  historicalObservedCount: number;
  historicalCoveragePercent: number;
  executionBlocked: true;
}

export interface CoverageTrendSummary {
  currentCoveragePercent: number;
  previousCoveragePercent: number | null;
  coverageDelta: number | null;
  heatShift: HeatShift;
  trendDirection: TrendDirection | null;
  comparedSnapshotCount: number;
  totalPolicies: number;
  currentObservedCount: number;
  executionBlocked: true;
}

export interface WorkspaceCoverageTrend {
  trendId: string;
  generatedAt: string;
  summary: CoverageTrendSummary;
  snapshotHistory: SnapshotCoveragePoint[];
  auditEntriesScanned: number;
  executionBlocked: true;
}

// --- Internal helpers ---

function classifyBand(observationCount: number): "cold" | "warm" | "hot" {
  if (observationCount >= HOT_MIN) return "hot";
  if (observationCount >= WARM_MIN) return "warm";
  return "cold";
}

function coveragePercent(observed: number, total: number): number {
  if (total === 0) return 0;
  return Math.min(100, Math.round((observed / total) * 100));
}

function buildSnapshotPoint(
  snapshotId: string,
  snapshotCreatedAt: string,
  entries: ComplianceLedgerEntry[],
  totalPolicies: number,
): SnapshotCoveragePoint {
  const historicalObservedCount = entries.filter(
    (e) => e.firstObservedAt !== null && e.firstObservedAt <= snapshotCreatedAt,
  ).length;
  return {
    snapshotId,
    snapshotCreatedAt,
    historicalObservedCount,
    historicalCoveragePercent: coveragePercent(historicalObservedCount, totalPolicies),
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function deriveTrendDirection(delta: number | null): TrendDirection | null {
  if (delta === null) return null;
  if (delta > 0) return "improving";
  if (delta < 0) return "degrading";
  return "stable";
}

// --- Public API ---

export function getWorkspaceCoverageTrend(): WorkspaceCoverageTrend {
  const generatedAt = new Date().toISOString();
  const trendId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  // Current live state from compliance ledger
  const ledger = getPolicyComplianceLedger();
  const entries = ledger.entries;
  const totalPolicies = entries.length;

  let hotCount = 0;
  let warmCount = 0;
  let coldCount = 0;
  for (const e of entries) {
    const band = classifyBand(e.observationCount);
    if (band === "hot") hotCount++;
    else if (band === "warm") warmCount++;
    else coldCount++;
  }

  const currentObservedCount = hotCount + warmCount;
  const currentCoveragePercent = coveragePercent(currentObservedCount, totalPolicies);

  // Historical comparison window — newest-first, bounded to MAX_COMPARE
  const snapshotResult = listWorkspaceSnapshots();
  const windowSnapshots = snapshotResult.snapshots.slice(0, MAX_COMPARE);

  const snapshotHistory: SnapshotCoveragePoint[] = windowSnapshots.map((snap) =>
    buildSnapshotPoint(snap.snapshotId, snap.createdAt, entries, totalPolicies),
  );

  // Derive trend from the most recent snapshot (index 0)
  const latestPoint: SnapshotCoveragePoint | null = snapshotHistory[0] ?? null;
  const previousCoveragePercent: number | null =
    latestPoint?.historicalCoveragePercent ?? null;
  const previousObservedCount: number | null =
    latestPoint?.historicalObservedCount ?? null;

  const coverageDelta: number | null =
    previousCoveragePercent !== null
      ? currentCoveragePercent - previousCoveragePercent
      : null;

  const observedDelta: number | null =
    previousObservedCount !== null
      ? currentObservedCount - previousObservedCount
      : null;

  const heatShift: HeatShift = {
    hotCountCurrent: hotCount,
    warmCountCurrent: warmCount,
    coldCountCurrent: coldCount,
    observedDelta,
    unobservedDelta: observedDelta !== null ? -observedDelta : null,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const summary: CoverageTrendSummary = {
    currentCoveragePercent,
    previousCoveragePercent,
    coverageDelta,
    heatShift,
    trendDirection: deriveTrendDirection(coverageDelta),
    comparedSnapshotCount: snapshotHistory.length,
    totalPolicies,
    currentObservedCount,
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    trendId,
    generatedAt,
    summary,
    snapshotHistory,
    auditEntriesScanned: ledger.auditEntriesScanned,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
