import { randomBytes } from "node:crypto";
import { registerSubsystemState } from "./runtimeStateRegistry";
import { listRoleDefinitions, type ActorType, type Role, type PermissionEntry } from "./identityAccess";
import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";
import { readStore, writeStore } from "./persistentStore";

export interface SessionLifecycle {
  statusCode: number;
  latencyMs: number;
  finishedAt: string;
}

export interface SessionContext {
  id: string;
  requestId: string;
  correlationId: string;
  actorType: ActorType;
  role: Role;
  actorId?: string;
  permissions: PermissionEntry[];
  route: string;
  method: string;
  timestamp: string;
  lifecycle?: SessionLifecycle;
  remoteAddress?: string;
  clientIp?: string;
  executionBlocked: true;
}

export interface SessionContextInput {
  requestId: string;
  method: string;
  route: string;
  correlationId?: string;
  actorType?: ActorType;
  role?: Role;
  actorId?: string;
  remoteAddress?: string;
  clientIp?: string;
}

export interface SessionFilter {
  actorId?: string;
  actorType?: string;
  role?: string;
  route?: string;
  method?: string;
  limit?: number;
}

export interface SessionContextStatus {
  operational: boolean;
  subsystemName: "session_context";
  sessionCount: number;
  capacity: number;
  oldestSessionAt: string | null;
  newestSessionAt: string | null;
  defaultActorType: ActorType;
  defaultRole: Role;
  authEnabled: false;
  executionBlocked: true;
  recoveryBlocked: true;
  initializedAt: string | null;
}

export interface SessionContextRecent {
  executionBlocked: true;
  recoveryBlocked: true;
  sessionCount: number;
  capacity: number;
  limit: number;
  filteredCount: number;
  filtersApplied: Record<string, string>;
  sessions: SessionContext[];
  timestamp: string;
}

const MAX_SESSIONS = 200;
const MAX_QUERY_LIMIT = 100;
const PERSIST_LIMIT = 200;
const STORE_KEY = "session-context";
const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;
const DEFAULT_ACTOR_TYPE: ActorType = "anonymous";
const DEFAULT_ROLE: Role = "guest";

const sessionBuffer: SessionContext[] = [];
let isOperational = false;
let initializedAt: string | null = null;

function isValidSessionContext(obj: unknown): obj is SessionContext {
  if (typeof obj !== "object" || obj === null) return false;
  const s = obj as Record<string, unknown>;
  return (
    typeof s["id"] === "string" &&
    typeof s["requestId"] === "string" &&
    typeof s["correlationId"] === "string" &&
    typeof s["actorType"] === "string" &&
    typeof s["role"] === "string" &&
    Array.isArray(s["permissions"]) &&
    typeof s["route"] === "string" &&
    typeof s["method"] === "string" &&
    typeof s["timestamp"] === "string" &&
    s["executionBlocked"] === true
  );
}

function flushSessionContext(): void {
  try {
    writeStore(STORE_KEY, sessionBuffer.slice(-PERSIST_LIMIT));
  } catch (err) {
    logger.warn({ err: String(err) }, "Session context: failed to flush to persistent store");
  }
}

function resolveActorType(): ActorType {
  return DEFAULT_ACTOR_TYPE;
}

function resolveRole(): Role {
  return DEFAULT_ROLE;
}

function resolvePermissions(role: Role): PermissionEntry[] {
  try {
    const result = listRoleDefinitions();
    const roleDef = result.roles.find((r) => r.role === role);
    if (roleDef) {
      return roleDef.permissions.map((p) => ({ ...p }));
    }
  } catch {
  }
  return [];
}

export function initSessionContext(): void {
  if (isOperational) return;

  registerSubsystemState({
    subsystemName: "session_context",
    category: "observability",
    dependencies: ["identity_access", "runtime_state_registry"],
    metadata: {
      description:
        "Session context layer — per-request identity tracking, 200-entry ring buffer, authEnabled: false, executionBlocked always true. Persists all 200 entries across restarts.",
    },
  });

  const stored = readStore<unknown>(STORE_KEY);
  let restoredCount = 0;
  if (Array.isArray(stored)) {
    for (const item of stored) {
      if (isValidSessionContext(item) && sessionBuffer.length < MAX_SESSIONS) {
        sessionBuffer.push(item);
        restoredCount++;
      }
    }
  }

  isOperational = true;
  initializedAt = new Date().toISOString();

  addTimelineEvent({
    level: "info",
    source: "session-context",
    message: `Session context layer initialized — ${restoredCount} session${restoredCount === 1 ? "" : "s"} restored from persistent store`,
    metadata: {
      capacity: MAX_SESSIONS,
      restoredCount,
      defaultActorType: DEFAULT_ACTOR_TYPE,
      defaultRole: DEFAULT_ROLE,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  emit("session_context:initialized", "session-context", {
    capacity: MAX_SESSIONS,
    restoredCount,
    defaultActorType: DEFAULT_ACTOR_TYPE,
    defaultRole: DEFAULT_ROLE,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "session_context.initialized",
    source: "session-context",
    severity: "info",
    category: "runtime",
    payload: {
      capacity: MAX_SESSIONS,
      restoredCount,
      defaultActorType: DEFAULT_ACTOR_TYPE,
      defaultRole: DEFAULT_ROLE,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    { capacity: MAX_SESSIONS, restoredCount, persistLimit: PERSIST_LIMIT, defaultActorType: DEFAULT_ACTOR_TYPE, defaultRole: DEFAULT_ROLE, executionBlocked: EXECUTION_BLOCKED },
    "Session context layer initialized",
  );
}

export function createSessionContext(input: SessionContextInput): SessionContext {
  const actorType = input.actorType ?? resolveActorType();
  const role = input.role ?? resolveRole();
  const permissions = resolvePermissions(role);
  const correlationId = input.correlationId ?? randomBytes(8).toString("hex");

  const ctx: SessionContext = {
    id: randomBytes(8).toString("hex"),
    requestId: input.requestId,
    correlationId,
    actorType,
    role,
    ...(input.actorId !== undefined ? { actorId: input.actorId } : {}),
    permissions,
    route: input.route,
    method: input.method,
    timestamp: new Date().toISOString(),
    ...(input.remoteAddress !== undefined ? { remoteAddress: input.remoteAddress } : {}),
    ...(input.clientIp !== undefined ? { clientIp: input.clientIp } : {}),
    executionBlocked: EXECUTION_BLOCKED,
  };

  if (isOperational) {
    if (sessionBuffer.length >= MAX_SESSIONS) {
      sessionBuffer.shift();
    }
    sessionBuffer.push(ctx);
    flushSessionContext();
  }

  return ctx;
}

export function getSessionContextStatus(): SessionContextStatus {
  return {
    operational: isOperational,
    subsystemName: "session_context",
    sessionCount: sessionBuffer.length,
    capacity: MAX_SESSIONS,
    oldestSessionAt: sessionBuffer.length > 0 ? sessionBuffer[0].timestamp : null,
    newestSessionAt: sessionBuffer.length > 0 ? sessionBuffer[sessionBuffer.length - 1].timestamp : null,
    defaultActorType: DEFAULT_ACTOR_TYPE,
    defaultRole: DEFAULT_ROLE,
    authEnabled: false,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    initializedAt,
  };
}

export function completeSessionLifecycle(requestId: string, lifecycle: SessionLifecycle): void {
  for (let i = sessionBuffer.length - 1; i >= 0; i--) {
    if (sessionBuffer[i].requestId === requestId) {
      sessionBuffer[i] = { ...sessionBuffer[i], lifecycle };
      return;
    }
  }
}

export function getRecentSessions(limit: number = 50): SessionContextRecent {
  const clamped = Math.max(1, Math.min(limit, MAX_SESSIONS));
  const sessions = sessionBuffer.slice(-clamped);
  return {
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    sessionCount: sessionBuffer.length,
    capacity: MAX_SESSIONS,
    limit: clamped,
    filteredCount: sessions.length,
    filtersApplied: {},
    sessions,
    timestamp: new Date().toISOString(),
  };
}

export function getFilteredSessions(filter: SessionFilter): SessionContextRecent {
  const limit = Math.max(1, Math.min(filter.limit ?? 50, MAX_QUERY_LIMIT));
  const filtersApplied: Record<string, string> = {};

  let sessions = sessionBuffer.slice();

  if (filter.actorId !== undefined) {
    sessions = sessions.filter((s) => s.actorId === filter.actorId);
    filtersApplied["actorId"] = filter.actorId;
  }

  if (filter.actorType !== undefined) {
    sessions = sessions.filter((s) => s.actorType === filter.actorType);
    filtersApplied["actorType"] = filter.actorType;
  }

  if (filter.role !== undefined) {
    sessions = sessions.filter((s) => s.role === filter.role);
    filtersApplied["role"] = filter.role;
  }

  if (filter.route !== undefined) {
    sessions = sessions.filter((s) => s.route === filter.route);
    filtersApplied["route"] = filter.route;
  }

  if (filter.method !== undefined) {
    sessions = sessions.filter((s) => s.method === filter.method);
    filtersApplied["method"] = filter.method;
  }

  const filteredCount = sessions.length;
  const sliced = sessions.slice(-limit);

  return {
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    sessionCount: sessionBuffer.length,
    capacity: MAX_SESSIONS,
    limit,
    filteredCount,
    filtersApplied,
    sessions: sliced,
    timestamp: new Date().toISOString(),
  };
}
