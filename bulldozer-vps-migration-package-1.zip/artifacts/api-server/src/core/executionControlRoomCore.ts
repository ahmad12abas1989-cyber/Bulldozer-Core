// executionControlRoomCore.ts
// Phase 283 — Execution Control Room UI Core (updated Phase 348 — Production Extraction era)
// Pure HTML section builder — no init, no subsystem, no health check, no persistence.
// No client-side JavaScript. No forms. executionBlocked always true. readOnly always true.
// Injected into the /ui/observation page only.

function esc(s: string): string {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ---------------------------------------------------------------------------
// Compile-time stack descriptor — matches sealed cores exactly
// ---------------------------------------------------------------------------

interface StackLayer {
  readonly layer:       number;
  readonly label:       string;
  readonly file:        string;
  readonly state:       string;
  readonly sealedPhase: number;
  readonly blocked:     string;
}

const WRITE_STACK: readonly StackLayer[] = [
  { layer: 0,  label: "Experimental Production Flow",  file: "experimentalProductionFlowCore.ts",    state: "observe_ready",                        sealedPhase: 248, blocked: "executionBlocked=true"        },
  { layer: 1,  label: "Controlled Execution",          file: "controlledExecutionCore.ts",            state: "awaiting_operator_execution_approval",  sealedPhase: 254, blocked: "executionBlocked=true"        },
  { layer: 2,  label: "Sandbox Filesystem",            file: "sandboxFilesystemCore.ts",              state: "descriptor_mount_planned",             sealedPhase: 263, blocked: "filesystemMutationBlocked=true" },
  { layer: 3,  label: "Write Guard",                   file: "controlledWriteGuardCore.ts",           state: "descriptor_guard_ready",               sealedPhase: 263, blocked: "realWritesEnabled=false"      },
  { layer: 4,  label: "Write Enablement Gate",         file: "realWriteEnablementGateCore.ts",        state: "pre_write_ready",                      sealedPhase: 263, blocked: "realWritesEnabled=false"      },
  { layer: 5,  label: "Write Plan",                    file: "sandboxWritePlanCore.ts",               state: "descriptor_write_plan_ready",          sealedPhase: 263, blocked: "actualWritesEnabled=false"    },
  { layer: 6,  label: "Guarded Write",                 file: "guardedSandboxWriteCore.ts",            state: "guarded_descriptor_ready",             sealedPhase: 272, blocked: "actualWritesEnabled=false"    },
  { layer: 7,  label: "Write Audit",                   file: "sandboxWriteAuditCore.ts",              state: "descriptor_audit_ready",               sealedPhase: 272, blocked: "mutationBlocked=true"         },
  { layer: 8,  label: "Rollback Snapshot",             file: "sandboxWriteRollbackSnapshotCore.ts",   state: "descriptor_snapshot_ready",            sealedPhase: 272, blocked: "filesystemMutationBlocked=true" },
  { layer: 9,  label: "Commit Gate",                   file: "sandboxWriteCommitGateCore.ts",         state: "descriptor_commit_gate_ready",         sealedPhase: 272, blocked: "commitEnabled=false"          },
  { layer: 10, label: "Actual Write Enablement",       file: "actualSandboxWriteEnablementCore.ts",   state: "actual_write_pre_enablement_ready",    sealedPhase: 281, blocked: "actualWritesEnabled=false"    },
  { layer: 11, label: "Dry Run",                       file: "actualSandboxWriteDryRunCore.ts",       state: "descriptor_dry_run_ready",             sealedPhase: 281, blocked: "dryRunOnly=true"              },
  { layer: 12, label: "Approval Token",                file: "actualSandboxWriteApprovalTokenCore.ts",state: "descriptor_approval_pending",          sealedPhase: 281, blocked: "approvalGranted=false"        },
  { layer: 13, label: "Final Preflight",               file: "actualSandboxWritePreflightCore.ts",    state: "descriptor_preflight_ready",           sealedPhase: 281, blocked: "finalWriteAllowed=false"      },
] as const;

// ---------------------------------------------------------------------------
// Display flags — compile-time constants mirroring sealed cores
// ---------------------------------------------------------------------------

const FLAGS = {
  actualWritesEnabled:       false,
  finalWriteAllowed:         false,
  approvalGranted:           false,
  preflightPassed:           false,
  filesystemMutationBlocked: true,
  graphCycles:               0,
  totalLayers:               14,
  sealedCores:               13,
  executionBlocked:          true,
  readOnly:                  true,
} as const;

// ---------------------------------------------------------------------------
// Blocked reason list
// ---------------------------------------------------------------------------

const BLOCKED_REASONS = [
  "actualWritesEnabled=false — compile-time literal across all 13 sealed write layers",
  "finalWriteAllowed=false — first appears in layer 13 (actualSandboxWritePreflightCore.ts); no execution phase has changed it",
  "approvalGranted=false — approval token is in descriptor_approval_pending state; explicit operator action required in a future execution phase",
  "preflightPassed=false — final preflight is descriptor-only; no real write is cleared by this layer",
  "filesystemMutationBlocked=true — compile-time literal in layers 2, 6, 8, and all preflight layers",
  "commitEnabled=false — commit gate layer (9) has not been activated; sealed at Phase 272",
  "No execution phase exists yet — all 13 layers are descriptor-only seals; the first real sandbox write activation blueprint has not been created",
] as const;

// ---------------------------------------------------------------------------
// Next safe action
// ---------------------------------------------------------------------------

const NEXT_SAFE_ACTION =
  "Create the first real sandbox write activation blueprint (Phase 282+) — which will define the conditions under which a future execution phase may set actualWritesEnabled=true, subject to explicit operator approval, preflight pass, and rollback readiness. No mutation until that blueprint is sealed and an execution phase explicitly grants it.";

// ---------------------------------------------------------------------------
// Production Extraction Era — status indicators
// ---------------------------------------------------------------------------

interface ExtractionStatusItem {
  readonly label:  string;
  readonly status: "READY" | "BLOCKED" | "PENDING" | "ACTIVE ERA";
  readonly note:   string;
}

const EXTRACTION_STATUS: readonly ExtractionStatusItem[] = [
  { label: "Runtime Stability",       status: "READY",      note: "ep=162 · hc=38 · allHealthy=true · 0 cycles · server nominal"                                          },
  { label: "Governance Chain",        status: "READY",      note: "37 sealed layers · access enforcement · audit log · session context · rate limiter all active"         },
  { label: "Rollback Integrity",      status: "READY",      note: "rollbackChainValid delegates end-to-end through 26 binding layers; rollback snapshot anchored at layer 37" },
  { label: "Sandbox Mutation Path",   status: "READY",      note: "approval → authorization → permit → gate → enablement → surface → apply → commit chain sealed; targetScope=sandbox_approved_only" },
  { label: "Actual Writes",           status: "BLOCKED",    note: "actualWritesEnabled=false · filesystemMutationApprovalGranted=false · filesystemMutationBlocked=true"   },
  { label: "Artifact Generation",     status: "PENDING",    note: "sandbox mutation approval path complete; artifact generation phase not yet initiated"                    },
  { label: "App Generation",          status: "PENDING",    note: "depends on artifact generation; app generation phase not yet initiated"                                 },
  { label: "First Product Extraction",status: "ACTIVE ERA", note: "strategic era: Infrastructure Construction complete → Production Extraction era now active"             },
] as const;

const PRIORITY_ORDER: readonly string[] = [
  "1. Grant filesystem mutation approval (filesystemMutationApprovalGranted → true) — operator explicit action required",
  "2. Execute first sandbox write within approved scope (targetScope=sandbox_approved_only)",
  "3. Verify rollback integrity end-to-end after first write",
  "4. Generate first artifact from approved sandbox write output",
  "5. Generate first app from artifact output",
  "6. Mark first product extraction complete",
] as const;

const STRATEGIC_OBJECTIVE =
  "The Infrastructure Construction era is complete (Phases 1–346). All 37 write-preparation, governance, and mutation-control layers are sealed and verified. The Production Extraction era is now active. The immediate objective is to advance from descriptor-only mutation planning to the first approved, rollback-safe, sandbox-scoped write — and from that write to the first generated artifact and app. Every step requires explicit operator approval. No autonomous execution. No self-repair. No unrestricted filesystem mutation.";

// ---------------------------------------------------------------------------
// HTML builder
// ---------------------------------------------------------------------------

export function buildExecutionControlRoomSection(accent: string): string {
  const stackRows = WRITE_STACK.map((l) => `
    <tr>
      <td class="td-id">${l.layer}</td>
      <td>${esc(l.label)}</td>
      <td class="td-id" style="font-size:9px">${esc(l.file)}</td>
      <td><span style="font-size:9px;color:#6c757d">${esc(l.state)}</span></td>
      <td class="td-id">Ph ${l.sealedPhase}</td>
      <td><span style="font-size:9px;padding:1px 6px;background:#fef2f2;color:#dc2626;border:1px solid #fecaca;border-radius:2px">${esc(l.blocked)}</span></td>
    </tr>`).join("");

  const flagPairs: Array<[string, string, boolean]> = [
    ["actualWritesEnabled",       String(FLAGS.actualWritesEnabled),       false],
    ["finalWriteAllowed",         String(FLAGS.finalWriteAllowed),          false],
    ["approvalGranted",           String(FLAGS.approvalGranted),            false],
    ["preflightPassed",           String(FLAGS.preflightPassed),            false],
    ["filesystemMutationBlocked", String(FLAGS.filesystemMutationBlocked),  true ],
    ["graphCycles",               String(FLAGS.graphCycles),                true ],
    ["executionBlocked",          String(FLAGS.executionBlocked),           true ],
    ["readOnly",                  String(FLAGS.readOnly),                   true ],
  ];

  const flagCards = flagPairs.map(([k, v, isOk]) => {
    const color = isOk ? "#16a34a" : "#dc2626";
    const bg    = isOk ? "#f0fdf4" : "#fef2f2";
    const border= isOk ? "#bbf7d0" : "#fecaca";
    return `<div style="background:#ffffff;border:1px solid #dee2e6;border-top:2px solid ${accent};border-radius:5px;padding:12px 14px;min-width:0">
      <div style="font-size:20px;font-weight:800;color:${color};line-height:1;margin-bottom:5px">${esc(v)}</div>
      <div style="font-size:8px;color:#6c757d;text-transform:uppercase;letter-spacing:1.5px">${esc(k)}</div>
      <div style="margin-top:6px;display:inline-block;padding:1px 7px;font-size:9px;font-weight:700;background:${bg};color:${color};border:1px solid ${border};border-radius:2px">${isOk ? "EXPECTED" : "BLOCKED"}</div>
    </div>`;
  }).join("");

  const reasonRows = BLOCKED_REASONS.map((r, i) => `
    <tr>
      <td class="td-id">${i + 1}</td>
      <td style="font-size:10px;color:#495057">${esc(r)}</td>
    </tr>`).join("");

  // Production Extraction status cards
  const extractionCards = EXTRACTION_STATUS.map((item) => {
    type StatusKey = typeof item.status;
    const colorMap: Record<StatusKey, string> = {
      "READY":      "#16a34a",
      "BLOCKED":    "#dc2626",
      "PENDING":    "#b45309",
      "ACTIVE ERA": "#1d4ed8",
    };
    const bgMap: Record<StatusKey, string> = {
      "READY":      "#f0fdf4",
      "BLOCKED":    "#fef2f2",
      "PENDING":    "#fffbeb",
      "ACTIVE ERA": "#eff6ff",
    };
    const borderMap: Record<StatusKey, string> = {
      "READY":      "#bbf7d0",
      "BLOCKED":    "#fecaca",
      "PENDING":    "#fde68a",
      "ACTIVE ERA": "#bfdbfe",
    };
    const c = colorMap[item.status];
    const b = bgMap[item.status];
    const br = borderMap[item.status];
    return `<div style="background:#ffffff;border:1px solid #dee2e6;border-top:3px solid ${c};border-radius:5px;padding:12px 14px;min-width:0">
      <div style="font-size:9px;font-weight:700;letter-spacing:1.5px;color:#6c757d;text-transform:uppercase;margin-bottom:4px">${esc(item.label)}</div>
      <div style="display:inline-block;padding:2px 10px;font-size:11px;font-weight:800;background:${b};color:${c};border:1px solid ${br};border-radius:3px;margin-bottom:6px">${esc(item.status)}</div>
      <div style="font-size:9px;color:#6c757d;line-height:1.5">${esc(item.note)}</div>
    </div>`;
  }).join("");

  const priorityRows = PRIORITY_ORDER.map((step, i) => `
    <tr>
      <td class="td-id">${i + 1}</td>
      <td style="font-size:10px;color:#495057">${esc(step)}</td>
    </tr>`).join("");

  return `
  <!-- ARCHITECTURE ERA BANNER -->
  <div class="op-section" id="ecr-era-banner" style="border-top:3px solid #1d4ed8;background:linear-gradient(135deg,#eff6ff 0%,#f8fafc 100%)">
    <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
      <div style="flex:1;min-width:200px">
        <div style="font-size:9px;font-weight:700;letter-spacing:2px;color:#1d4ed8;text-transform:uppercase;margin-bottom:4px">Architecture Era</div>
        <div style="font-size:18px;font-weight:900;color:#1e3a5f;letter-spacing:-0.5px;line-height:1.2">Production Extraction</div>
        <div style="font-size:10px;color:#6c757d;margin-top:4px">Infrastructure Construction era complete · Phases 1–346 sealed · 37 mutation-control layers verified</div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <span style="font-size:9px;padding:3px 10px;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;border-radius:3px;font-weight:700">INFRA LOCKED</span>
        <span style="font-size:9px;padding:3px 10px;background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;border-radius:3px;font-weight:700">EXTRACTION ACTIVE</span>
        <span style="font-size:9px;padding:3px 10px;background:#fef2f2;color:#dc2626;border:1px solid #fecaca;border-radius:3px;font-weight:700">WRITES BLOCKED</span>
        <span style="font-size:9px;padding:3px 10px;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;border-radius:3px;font-weight:700">READ ONLY</span>
      </div>
    </div>
  </div>

  <!-- PRODUCTION EXTRACTION STATUS -->
  <div class="op-section" id="ecr-extraction-status">
    <div class="op-sh">Production extraction status <span class="op-ct">8 indicators &middot; sandbox-approved-only scope &middot; operator approval required</span></div>
    <p class="page-desc">Current readiness state across all strategic extraction dimensions. Runtime and governance infrastructure is fully ready. Actual writes remain blocked pending explicit approval. Artifact and app generation phases are next.</p>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin-bottom:4px">
      ${extractionCards}
    </div>
  </div>

  <!-- CURRENT STRATEGIC OBJECTIVE -->
  <div class="op-section" id="ecr-objective">
    <div class="op-sh">Current strategic objective <span class="op-ct">Production Extraction era</span></div>
    <div style="background:#ffffff;border:1px solid #dee2e6;border-left:3px solid #1d4ed8;border-radius:4px;padding:14px 16px">
      <div style="font-size:9px;font-weight:700;letter-spacing:1.5px;color:#1d4ed8;text-transform:uppercase;margin-bottom:6px">STRATEGIC OBJECTIVE</div>
      <p style="font-size:11px;color:#495057;line-height:1.7">${esc(STRATEGIC_OBJECTIVE)}</p>
      <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
        <span style="font-size:9px;padding:2px 8px;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;border-radius:2px;font-weight:700">PHASES 1–346 SEALED</span>
        <span style="font-size:9px;padding:2px 8px;background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;border-radius:2px;font-weight:700">ERA: PRODUCTION EXTRACTION</span>
        <span style="font-size:9px;padding:2px 8px;background:#fef2f2;color:#dc2626;border:1px solid #fecaca;border-radius:2px;font-weight:700">NO AUTONOMOUS EXECUTION</span>
        <span style="font-size:9px;padding:2px 8px;background:#fffbeb;color:#b45309;border:1px solid #fde68a;border-radius:2px;font-weight:700">APPROVAL REQUIRED</span>
      </div>
    </div>
  </div>

  <!-- PRODUCTION PRIORITY ORDER -->
  <div class="op-section" id="ecr-priority">
    <div class="op-sh">Production priority order <span class="op-ct">${PRIORITY_ORDER.length} steps &middot; operator-gated</span></div>
    <div class="table-wrap"><table>
      <thead><tr><th>#</th><th>Step</th></tr></thead>
      <tbody>${priorityRows}</tbody>
    </table></div>
  </div>

  <!-- EXISTING: EXECUTION CONTROL ROOM FLAGS -->
  <div class="op-section" id="ecr-flags">
    <div class="op-sh">Execution control room <span class="op-ct">${FLAGS.totalLayers} layers &middot; ${FLAGS.sealedCores} sealed cores &middot; all writes blocked</span></div>
    <p class="page-desc">Read-only view of the sealed write-preparation and preflight stack. Every layer is a compile-time descriptor. No actual write has been enabled. The operator can see exactly why writing is still blocked and what the next safe action is.</p>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:20px">
      ${flagCards}
    </div>
  </div>

  <div class="op-section" id="ecr-stack">
    <div class="op-sh">Write-preparation + preflight layer stack <span class="op-ct">layers 0–13</span></div>
    <div class="table-wrap"><table>
      <thead><tr><th>#</th><th>Layer</th><th>Core File</th><th>State</th><th>Sealed</th><th>Blocked By</th></tr></thead>
      <tbody>${stackRows}</tbody>
    </table></div>
  </div>

  <div class="op-section" id="ecr-blocked">
    <div class="op-sh">Why writing is still blocked <span class="op-ct">${BLOCKED_REASONS.length} reasons</span></div>
    <div class="table-wrap"><table>
      <thead><tr><th>#</th><th>Reason</th></tr></thead>
      <tbody>${reasonRows}</tbody>
    </table></div>
  </div>

  <div class="op-section" id="ecr-next">
    <div class="op-sh">Next safe action</div>
    <div style="background:#ffffff;border:1px solid #dee2e6;border-left:3px solid ${accent};border-radius:4px;padding:14px 16px">
      <div style="font-size:9px;font-weight:700;letter-spacing:1.5px;color:${accent};text-transform:uppercase;margin-bottom:6px">OPERATOR GUIDANCE</div>
      <p style="font-size:11px;color:#495057;line-height:1.7">${esc(NEXT_SAFE_ACTION)}</p>
      <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
        <span style="font-size:9px;padding:2px 8px;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;border-radius:2px;font-weight:700">NO MUTATION</span>
        <span style="font-size:9px;padding:2px 8px;background:#fef2f2;color:#dc2626;border:1px solid #fecaca;border-radius:2px;font-weight:700">EXECUTION BLOCKED</span>
        <span style="font-size:9px;padding:2px 8px;background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;border-radius:2px;font-weight:700">APPROVAL REQUIRED</span>
        <span style="font-size:9px;padding:2px 8px;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;border-radius:2px;font-weight:700">READ ONLY</span>
      </div>
    </div>
  </div>`;
}
