// Vault Observe Route — Phase 197
// GET /api/auth/vault
// Read-only diagnostic view of the in-memory vault metadata store.
// No secret values. No registration route. No retrieval route. No deletion route.
// No persistence.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { listVaultSecretMetadata, getVaultSummary } from "../core/vaultCore";

export function handleVaultObserve(_req: IncomingMessage, res: ServerResponse): void {
  const metadata = listVaultSecretMetadata();
  const summary  = getVaultSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    metadataOnly:       true,
    encryptionEnabled:  false,
    persistenceEnabled: false,
    executionBlocked:   true,
    totalSecrets:       metadata.length,
    summary,
    metadata,
  });
}
