// Sandbox Observe Route — Phase 201
// GET /api/sandbox/runs
// Read-only diagnostic view of the in-memory sandbox run registry.
// No execution, no shell commands, no filesystem access, no network access,
// no vault access, no create-run route, no approval route, no status transition route.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { listSandboxRuns, getSandboxSummary } from "../core/sandboxCore";

export function handleSandboxObserve(_req: IncomingMessage, res: ServerResponse): void {
  const runs    = listSandboxRuns();
  const summary = getSandboxSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    executionEnabled:   false,
    persistenceEnabled: false,
    approvalRequired:   true,
    executionBlocked:   true,
    totalRuns:          runs.length,
    summary,
    runs,
  });
}
