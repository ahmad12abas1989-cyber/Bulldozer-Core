import type { IncomingMessage, ServerResponse } from "node:http";
import { getSecureConfigStatus } from "../core/secureConfig";
import { sendJson } from "../lib/response";

export function handleConfigStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getSecureConfigStatus());
}
