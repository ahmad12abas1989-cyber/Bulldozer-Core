// Template Artifact Observe Route — Phase 221
// GET /api/artifacts/virtual
// Read-only diagnostic view of the in-memory virtual artifact registry.
// No artifact creation, no filesystem writes, no package installation,
// no runtime execution, no deployment packaging, no sandbox execution,
// no plugin execution, no vault access.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  listTemplateArtifactRecords,
  getTemplateArtifactSummary,
} from "../core/templateArtifactCore";

export function handleTemplateArtifactObserve(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  const artifacts = listTemplateArtifactRecords();
  const summary   = getTemplateArtifactSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    generationEnabled:  false,
    executionEnabled:   false,
    deploymentEnabled:  false,
    persistenceEnabled: false,
    executionBlocked:   true,
    deploymentBlocked:  true,
    totalArtifacts:     artifacts.length,
    summary,
    artifacts,
  });
}
