import { randomBytes } from "node:crypto";

export function generateRequestId(): string {
  return randomBytes(8).toString("hex");
}
