#!/usr/bin/env bash
# deploy/scripts/stop.sh
# Gracefully stop Bulldozer Mother Core.
# Sends SIGTERM to the container and waits for clean shutdown.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPLOY_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ENV_FILE="${DEPLOY_DIR}/.env"
COMPOSE_FILE="${DEPLOY_DIR}/docker-compose.yml"

echo "[bulldozer] Stopping Bulldozer Mother Core..."

docker compose \
  --env-file "${ENV_FILE}" \
  --file "${COMPOSE_FILE}" \
  down --timeout 30

echo "[bulldozer] Container stopped cleanly."
