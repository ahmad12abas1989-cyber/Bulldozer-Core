// Widget Data Contracts Registry — Phase 102
// Pure static module: no imports from live data sources, no node:crypto needed.
// All contracts are declared at module scope for deterministic ordering.

const EXECUTION_BLOCKED: true = true;
const SCHEMA_VERSION = "1";

// --- Primitive field types ---

export type WidgetFieldType =
  | "string"
  | "number"
  | "boolean"
  | "string|null"
  | "number|null"
  | "string[]";

// --- Core types ---

export interface WidgetField {
  fieldName: string;
  fieldType: WidgetFieldType;
  description: string;
  nullable: boolean;
  executionBlocked: true;
}

export interface WidgetEnumeration {
  field: string;
  values: string[];
  executionBlocked: true;
}

export interface WidgetSourceContract {
  sourceEndpoint: string;
  compactDataType: string;
  schemaVersion: string;
  executionBlocked: true;
}

export interface WidgetContract {
  widgetId: string;
  widgetType: string;
  title: string;
  sectionId: string;
  sourceEndpoint: string;
  recommendedSize: string;
  refreshCategory: string;
  compactDataType: string;
  schemaVersion: string;
  fields: WidgetField[];
  requiredFields: string[];
  enumerations: WidgetEnumeration[];
  examplePayload: Record<string, unknown>;
  executionBlocked: true;
}

export interface WidgetContractSummaryItem {
  widgetId: string;
  widgetType: string;
  title: string;
  sectionId: string;
  sourceEndpoint: string;
  compactDataType: string;
  schemaVersion: string;
  fieldCount: number;
  requiredFieldCount: number;
  executionBlocked: true;
}

export interface WidgetContractSummary {
  totalContracts: number;
  contractsByCompactDataType: Record<string, number>;
  contractsByWidgetType: Record<string, number>;
  contractsBySectionId: Record<string, number>;
  schemaVersion: string;
  executionBlocked: true;
}

export interface WidgetContractListResult {
  contracts: WidgetContractSummaryItem[];
  total: number;
  summary: WidgetContractSummary;
  executionBlocked: true;
}

// --- Field + enumeration builder helpers ---

function f(
  fieldName: string,
  fieldType: WidgetFieldType,
  description: string,
  nullable = false,
): WidgetField {
  return { fieldName, fieldType, description, nullable, executionBlocked: EXECUTION_BLOCKED };
}

function en(field: string, values: string[]): WidgetEnumeration {
  return { field, values, executionBlocked: EXECUTION_BLOCKED };
}

// --- Shared compact field definitions (by compactDataType) ---

// dataType field appears in every compact payload
const F_DATA_TYPE = f("dataType", "string", "Discriminator identifying the compact payload type; value is always the compactDataType for this widget");
const F_EB        = f("executionBlocked", "boolean", "Governance invariant; always true; signals that no execution has occurred in producing this payload");

// governance
const FIELDS_GOVERNANCE: WidgetField[] = [
  F_DATA_TYPE,
  f("governanceScore",      "number",  "Weighted composite governance score, 0–100"),
  f("governanceGrade",      "string",  "Letter grade derived from governanceScore: A (≥90), B (≥75), C (≥60), D (≥45), F (<45)"),
  f("dimensionCount",       "number",  "Number of scoring dimensions in the governance scorecard breakdown; currently 5"),
  f("recommendationCount",  "number",  "Number of active advisory recommendations returned by the scorecard"),
  F_EB,
];
const ENUM_GOVERNANCE: WidgetEnumeration[] = [
  en("governanceGrade", ["A", "B", "C", "D", "F"]),
];
const EXAMPLE_GOVERNANCE: Record<string, unknown> = {
  dataType: "governance",
  governanceScore: 75,
  governanceGrade: "B",
  dimensionCount: 5,
  recommendationCount: 2,
  executionBlocked: true,
};

// observation_coverage
const FIELDS_OBS_COVERAGE: WidgetField[] = [
  F_DATA_TYPE,
  f("coveragePercent",      "number",  "Percentage of policies that have been observed at least once, 0–100"),
  f("observedPolicies",     "number",  "Count of policies with at least one audit log observation"),
  f("unobservedPolicies",   "number",  "Count of policies with zero audit log observations"),
  f("totalPolicies",        "number",  "Total policies in the access enforcement registry"),
  F_EB,
];
const ENUM_OBS_COVERAGE: WidgetEnumeration[] = [];
const EXAMPLE_OBS_COVERAGE: Record<string, unknown> = {
  dataType: "observation_coverage",
  coveragePercent: 42,
  observedPolicies: 42,
  unobservedPolicies: 57,
  totalPolicies: 99,
  executionBlocked: true,
};

// exposure
const FIELDS_EXPOSURE: WidgetField[] = [
  F_DATA_TYPE,
  f("exposureScore",                 "number",  "Inverse-risk score 0–100; higher means lower exposure risk"),
  f("exposureGrade",                 "string",  "Letter grade derived from exposureScore: A (≥90), B (≥75), C (≥60), D (≥45), F (<45)"),
  f("totalWritePolicies",            "number",  "Total number of write-permission policies in the registry"),
  f("unobservedWritePolicies",       "number",  "Write policies with zero observations (highest risk)"),
  f("rarelyObservedWritePolicies",   "number",  "Write policies with 1–9 observations"),
  f("wellObservedWritePolicies",     "number",  "Write policies with ≥10 observations (lowest risk)"),
  F_EB,
];
const ENUM_EXPOSURE: WidgetEnumeration[] = [
  en("exposureGrade", ["A", "B", "C", "D", "F"]),
];
const EXAMPLE_EXPOSURE: Record<string, unknown> = {
  dataType: "exposure",
  exposureScore: 100,
  exposureGrade: "A",
  totalWritePolicies: 8,
  unobservedWritePolicies: 0,
  rarelyObservedWritePolicies: 0,
  wellObservedWritePolicies: 8,
  executionBlocked: true,
};

// probe
const FIELDS_PROBE: WidgetField[] = [
  F_DATA_TYPE,
  f("allProbesPassed",    "boolean",  "True only when all 5 sub-probes passed schema validation and executionBlocked invariant"),
  f("passedProbeCount",  "number",   "Count of sub-probes that passed"),
  f("failedProbeCount",  "number",   "Count of sub-probes that failed"),
  f("totalProbes",       "number",   "Total sub-probes in the sweep; currently 5"),
  f("totalProbeTimeMs",  "number",   "Sum of responseTimeMs across all sub-probes in milliseconds"),
  F_EB,
];
const ENUM_PROBE: WidgetEnumeration[] = [];
const EXAMPLE_PROBE: Record<string, unknown> = {
  dataType: "probe",
  allProbesPassed: true,
  passedProbeCount: 5,
  failedProbeCount: 0,
  totalProbes: 5,
  totalProbeTimeMs: 12,
  executionBlocked: true,
};

// heatmap
const FIELDS_HEATMAP: WidgetField[] = [
  F_DATA_TYPE,
  f("coldCount",        "number",  "Policies with zero observations (cold band)"),
  f("warmCount",        "number",  "Policies with 1–9 observations (warm band)"),
  f("hotCount",         "number",  "Policies with ≥10 observations (hot band)"),
  f("coveragePercent",  "number",  "Percentage of policies that are warm or hot, 0–100"),
  F_EB,
];
const ENUM_HEATMAP: WidgetEnumeration[] = [];
const EXAMPLE_HEATMAP: Record<string, unknown> = {
  dataType: "heatmap",
  coldCount: 57,
  warmCount: 30,
  hotCount: 12,
  coveragePercent: 42,
  executionBlocked: true,
};

// trend
const FIELDS_TREND: WidgetField[] = [
  F_DATA_TYPE,
  f("trendDirection",          "string|null",  "Direction of coverage change vs oldest snapshot; null if fewer than 2 snapshots", true),
  f("coverageDelta",           "number|null",  "Percentage point change from previous to current coverage; null if no prior snapshot", true),
  f("currentCoveragePercent",  "number",       "Current observation coverage percent, 0–100"),
  f("comparedSnapshotCount",   "number",       "Number of snapshots used in the trend comparison, max 5"),
  F_EB,
];
const ENUM_TREND: WidgetEnumeration[] = [
  en("trendDirection", ["improving", "stable", "degrading", "null"]),
];
const EXAMPLE_TREND: Record<string, unknown> = {
  dataType: "trend",
  trendDirection: "stable",
  coverageDelta: 0,
  currentCoveragePercent: 42,
  comparedSnapshotCount: 0,
  executionBlocked: true,
};

// ledger
const FIELDS_LEDGER: WidgetField[] = [
  F_DATA_TYPE,
  f("overallObservationHealth",  "string",  "Aggregate health: critical if probe fails/coverage<25/risk=high; degraded if partial/coverage<50/risk=medium/grade D or F; else healthy"),
  f("governanceReadiness",       "string",  "Governance grade A–F from weighted scorecard"),
  f("observationCoverage",       "number",  "Observation coverage percent, 0–100"),
  f("exposureRiskLevel",         "string",  "Write-surface risk: none (0 write policies), low (grade A/B), medium (grade C/D), high (grade F)"),
  f("probeHealth",               "string",  "Probe sweep result: all_passed, partial, or none_passed"),
  F_EB,
];
const ENUM_LEDGER: WidgetEnumeration[] = [
  en("overallObservationHealth", ["healthy", "degraded", "critical"]),
  en("governanceReadiness",      ["A", "B", "C", "D", "F"]),
  en("exposureRiskLevel",        ["none", "low", "medium", "high"]),
  en("probeHealth",              ["all_passed", "partial", "none_passed"]),
];
const EXAMPLE_LEDGER: Record<string, unknown> = {
  dataType: "ledger",
  overallObservationHealth: "degraded",
  governanceReadiness: "B",
  observationCoverage: 42,
  exposureRiskLevel: "none",
  probeHealth: "all_passed",
  executionBlocked: true,
};

// health
const FIELDS_HEALTH: WidgetField[] = [
  F_DATA_TYPE,
  f("status",        "string",  "Aggregate health status derived from all registered health checks"),
  f("totalChecks",   "number",  "Total number of registered health checks"),
  f("passingChecks", "number",  "Count of health checks with status=pass"),
  f("failingChecks", "number",  "Count of health checks with status=fail"),
  F_EB,
];
const ENUM_HEALTH: WidgetEnumeration[] = [
  en("status", ["healthy", "degraded", "unhealthy"]),
];
const EXAMPLE_HEALTH: Record<string, unknown> = {
  dataType: "health",
  status: "healthy",
  totalChecks: 37,
  passingChecks: 37,
  failingChecks: 0,
  executionBlocked: true,
};

// metrics
const FIELDS_METRICS: WidgetField[] = [
  F_DATA_TYPE,
  f("totalRequests",  "number",  "Total HTTP requests handled since process start"),
  f("totalErrors",    "number",  "Total error boundary activations since process start"),
  f("memoryUsedMb",   "number",  "Heap memory used by the process in megabytes (rounded to nearest MB)"),
  F_EB,
];
const ENUM_METRICS: WidgetEnumeration[] = [];
const EXAMPLE_METRICS: Record<string, unknown> = {
  dataType: "metrics",
  totalRequests: 1024,
  totalErrors: 0,
  memoryUsedMb: 48,
  executionBlocked: true,
};

// freeze
const FIELDS_FREEZE: WidgetField[] = [
  F_DATA_TYPE,
  f("status",       "string",  "Event loop freeze detector state"),
  f("freezeCount",  "number",  "Number of freeze events detected (lag ≥500ms) since process start"),
  f("lastLagMs",    "number",  "Most recent event loop lag measurement in milliseconds"),
  F_EB,
];
const ENUM_FREEZE: WidgetEnumeration[] = [
  en("status", ["normal", "warning", "frozen"]),
];
const EXAMPLE_FREEZE: Record<string, unknown> = {
  dataType: "freeze",
  status: "normal",
  freezeCount: 0,
  lastLagMs: 0,
  executionBlocked: true,
};

// crash
const FIELDS_CRASH: WidgetField[] = [
  F_DATA_TYPE,
  f("status",        "string",  "Crash detector state"),
  f("crashCount",    "number",  "Count of uncaughtException or unhandledRejection events since process start"),
  f("warningCount",  "number",  "Count of process warning events since process start"),
  F_EB,
];
const ENUM_CRASH: WidgetEnumeration[] = [
  en("status", ["stable", "warning", "crashed"]),
];
const EXAMPLE_CRASH: Record<string, unknown> = {
  dataType: "crash",
  status: "stable",
  crashCount: 0,
  warningCount: 0,
  executionBlocked: true,
};

// projects
const FIELDS_PROJECTS: WidgetField[] = [
  F_DATA_TYPE,
  f("total",               "number",  "Total projects in the registry"),
  f("active",              "number",  "Projects with status=active"),
  f("archived",            "number",  "Projects with status=archived"),
  f("suspended",           "number",  "Projects with status=suspended"),
  f("utilizationPercent",  "number",  "Registry capacity utilization: round(total/maxProjects×100)"),
  F_EB,
];
const ENUM_PROJECTS: WidgetEnumeration[] = [];
const EXAMPLE_PROJECTS: Record<string, unknown> = {
  dataType: "projects",
  total: 0,
  active: 0,
  archived: 0,
  suspended: 0,
  utilizationPercent: 0,
  executionBlocked: true,
};

// members
const FIELDS_MEMBERS: WidgetField[] = [
  F_DATA_TYPE,
  f("totalMemberRecords",        "number",  "Total project-member records across all projects"),
  f("projectsWithCustomQuotas",  "number",  "Projects that have custom quota overrides"),
  f("projectsUsingDefaults",     "number",  "Projects using the default quota values"),
  F_EB,
];
const ENUM_MEMBERS: WidgetEnumeration[] = [];
const EXAMPLE_MEMBERS: Record<string, unknown> = {
  dataType: "members",
  totalMemberRecords: 0,
  projectsWithCustomQuotas: 0,
  projectsUsingDefaults: 0,
  executionBlocked: true,
};

// audit
const FIELDS_AUDIT: WidgetField[] = [
  F_DATA_TYPE,
  f("retainedReportCount",  "number",  "Number of audit reports currently retained in the ring buffer (max 10)"),
  F_EB,
];
const ENUM_AUDIT: WidgetEnumeration[] = [];
const EXAMPLE_AUDIT: Record<string, unknown> = {
  dataType: "audit",
  retainedReportCount: 0,
  executionBlocked: true,
};

// static_reference
const FIELDS_STATIC: WidgetField[] = [
  F_DATA_TYPE,
  f("sourceEndpoint",  "string",  "API path of the endpoint that provides full data for this widget"),
  f("note",            "string",  "Human-readable message directing consumers to fetch full data from sourceEndpoint"),
  F_EB,
];
const ENUM_STATIC: WidgetEnumeration[] = [];
const EXAMPLE_STATIC: Record<string, unknown> = {
  dataType: "static_reference",
  sourceEndpoint: "/api/workspace/timeline",
  note: "Live timeline data — fetch from sourceEndpoint for full event list",
  executionBlocked: true,
};

// --- Required fields (dataType + all domain fields, excluding executionBlocked) ---

function requiredFrom(fields: WidgetField[]): string[] {
  return fields.filter((f) => f.fieldName !== "executionBlocked" && !f.nullable).map((f) => f.fieldName);
}

// --- Contract builder ---

function contract(
  widgetId: string,
  widgetType: string,
  title: string,
  sectionId: string,
  sourceEndpoint: string,
  recommendedSize: string,
  refreshCategory: string,
  compactDataType: string,
  fields: WidgetField[],
  enumerations: WidgetEnumeration[],
  examplePayload: Record<string, unknown>,
): WidgetContract {
  return {
    widgetId,
    widgetType,
    title,
    sectionId,
    sourceEndpoint,
    recommendedSize,
    refreshCategory,
    compactDataType,
    schemaVersion: SCHEMA_VERSION,
    fields,
    requiredFields: requiredFrom(fields),
    enumerations,
    examplePayload,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Static contract registry (37 entries, deterministic order) ---

const CONTRACT_REGISTRY: WidgetContract[] = [
  // --- Governance section ---
  contract("governance-score-gauge",     "gauge",     "Governance Score",           "governance",   "/api/workspace/governance/scorecard", "small",  "on-demand", "governance",            FIELDS_GOVERNANCE,   ENUM_GOVERNANCE,    EXAMPLE_GOVERNANCE),
  contract("governance-grade-badge",     "badge",     "Governance Grade",           "governance",   "/api/workspace/governance/scorecard", "small",  "on-demand", "governance",            FIELDS_GOVERNANCE,   ENUM_GOVERNANCE,    EXAMPLE_GOVERNANCE),
  contract("governance-breakdown-table", "table",     "Score Breakdown",            "governance",   "/api/workspace/governance/scorecard", "medium", "on-demand", "governance",            FIELDS_GOVERNANCE,   ENUM_GOVERNANCE,    EXAMPLE_GOVERNANCE),
  contract("governance-recommendations", "list",      "Advisory Recommendations",   "governance",   "/api/workspace/governance/scorecard", "medium", "on-demand", "governance",            FIELDS_GOVERNANCE,   ENUM_GOVERNANCE,    EXAMPLE_GOVERNANCE),
  contract("compliance-coverage-gauge",  "gauge",     "Coverage Percent",           "governance",   "/api/workspace/policy/compliance",    "medium", "periodic",  "observation_coverage",  FIELDS_OBS_COVERAGE, ENUM_OBS_COVERAGE,  EXAMPLE_OBS_COVERAGE),
  contract("compliance-policy-table",    "table",     "Policy Ledger",              "governance",   "/api/workspace/policy/compliance",    "large",  "on-demand", "observation_coverage",  FIELDS_OBS_COVERAGE, ENUM_OBS_COVERAGE,  EXAMPLE_OBS_COVERAGE),
  contract("exposure-score-metric",      "metric",    "Exposure Score",             "governance",   "/api/workspace/observation/exposure", "small",  "periodic",  "exposure",              FIELDS_EXPOSURE,     ENUM_EXPOSURE,      EXAMPLE_EXPOSURE),
  contract("exposure-grade-badge",       "badge",     "Exposure Grade",             "governance",   "/api/workspace/observation/exposure", "small",  "periodic",  "exposure",              FIELDS_EXPOSURE,     ENUM_EXPOSURE,      EXAMPLE_EXPOSURE),
  contract("exposure-risk-table",        "table",     "Write Policy Risks",         "governance",   "/api/workspace/observation/exposure", "medium", "on-demand", "exposure",              FIELDS_EXPOSURE,     ENUM_EXPOSURE,      EXAMPLE_EXPOSURE),
  // --- Observation section ---
  contract("heatmap-matrix",             "heatmap",   "Policy Activity Heatmap",    "observation",  "/api/workspace/observation/heatmap",  "full",   "on-demand", "heatmap",               FIELDS_HEATMAP,      ENUM_HEATMAP,       EXAMPLE_HEATMAP),
  contract("heatmap-coverage-pct",       "gauge",     "Heatmap Coverage",           "observation",  "/api/workspace/observation/heatmap",  "small",  "on-demand", "heatmap",               FIELDS_HEATMAP,      ENUM_HEATMAP,       EXAMPLE_HEATMAP),
  contract("heatmap-band-counts",        "metric",    "Band Distribution",          "observation",  "/api/workspace/observation/heatmap",  "small",  "on-demand", "heatmap",               FIELDS_HEATMAP,      ENUM_HEATMAP,       EXAMPLE_HEATMAP),
  contract("coverage-trend-chart",       "chart",     "Coverage Trend",             "observation",  "/api/workspace/observation/trend",    "large",  "periodic",  "trend",                 FIELDS_TREND,        ENUM_TREND,         EXAMPLE_TREND),
  contract("coverage-delta-badge",       "badge",     "Trend Direction",            "observation",  "/api/workspace/observation/trend",    "small",  "periodic",  "trend",                 FIELDS_TREND,        ENUM_TREND,         EXAMPLE_TREND),
  contract("coverage-delta-value",       "metric",    "Coverage Delta",             "observation",  "/api/workspace/observation/trend",    "small",  "periodic",  "trend",                 FIELDS_TREND,        ENUM_TREND,         EXAMPLE_TREND),
  contract("probe-status-badge",         "badge",     "Probe Health",               "observation",  "/api/workspace/observation/probe",    "small",  "realtime",  "probe",                 FIELDS_PROBE,        ENUM_PROBE,         EXAMPLE_PROBE),
  contract("probe-timing-table",         "table",     "Sub-probe Timings",          "observation",  "/api/workspace/observation/probe",    "medium", "on-demand", "probe",                 FIELDS_PROBE,        ENUM_PROBE,         EXAMPLE_PROBE),
  contract("probe-pass-count",           "metric",    "Passed Probes",              "observation",  "/api/workspace/observation/probe",    "small",  "on-demand", "probe",                 FIELDS_PROBE,        ENUM_PROBE,         EXAMPLE_PROBE),
  contract("ledger-analytics-scorecard", "scorecard", "Analytics Summary",          "observation",  "/api/workspace/observation/ledger/analytics", "medium", "on-demand", "ledger",        FIELDS_LEDGER,       ENUM_LEDGER,        EXAMPLE_LEDGER),
  contract("ledger-history-chart",       "chart",     "Coverage Progression",       "observation",  "/api/workspace/observation/ledger/analytics", "large",  "on-demand", "ledger",        FIELDS_LEDGER,       ENUM_LEDGER,        EXAMPLE_LEDGER),
  contract("ledger-transitions-metric",  "metric",    "Governance Transitions",     "observation",  "/api/workspace/observation/ledger/analytics", "small",  "on-demand", "ledger",        FIELDS_LEDGER,       ENUM_LEDGER,        EXAMPLE_LEDGER),
  // --- Diagnostics section ---
  contract("health-status-badge",        "badge",     "Health Status",              "diagnostics",  "/api/healthz",      "small", "realtime",  "health",    FIELDS_HEALTH,   ENUM_HEALTH,   EXAMPLE_HEALTH),
  contract("health-checks-table",        "table",     "All Health Checks",          "diagnostics",  "/api/health/full",  "large", "periodic",  "health",    FIELDS_HEALTH,   ENUM_HEALTH,   EXAMPLE_HEALTH),
  contract("memory-usage-gauge",         "gauge",     "Memory Usage",               "diagnostics",  "/api/metrics",      "small", "realtime",  "metrics",   FIELDS_METRICS,  ENUM_METRICS,  EXAMPLE_METRICS),
  contract("request-count-metric",       "metric",    "Total Requests",             "diagnostics",  "/api/metrics",      "small", "realtime",  "metrics",   FIELDS_METRICS,  ENUM_METRICS,  EXAMPLE_METRICS),
  contract("error-count-metric",         "metric",    "Total Errors",               "diagnostics",  "/api/metrics",      "small", "realtime",  "metrics",   FIELDS_METRICS,  ENUM_METRICS,  EXAMPLE_METRICS),
  contract("freeze-status-badge",        "badge",     "Freeze Detector",            "diagnostics",  "/api/freeze",       "small", "realtime",  "freeze",    FIELDS_FREEZE,   ENUM_FREEZE,   EXAMPLE_FREEZE),
  contract("crash-status-badge",         "badge",     "Crash Detector",             "diagnostics",  "/api/crash",        "small", "realtime",  "crash",     FIELDS_CRASH,    ENUM_CRASH,    EXAMPLE_CRASH),
  // --- Projects section ---
  contract("project-count-metric",       "metric",    "Total Projects",             "projects",     "/api/workspace/summary", "small", "periodic",  "projects",  FIELDS_PROJECTS, ENUM_PROJECTS, EXAMPLE_PROJECTS),
  contract("capacity-gauge",             "gauge",     "Registry Capacity",          "projects",     "/api/workspace/summary", "small", "periodic",  "projects",  FIELDS_PROJECTS, ENUM_PROJECTS, EXAMPLE_PROJECTS),
  contract("projects-status-table",      "table",     "Projects List",              "projects",     "/api/projects",          "large", "on-demand", "projects",  FIELDS_PROJECTS, ENUM_PROJECTS, EXAMPLE_PROJECTS),
  contract("member-count-metric",        "metric",    "Total Member Records",       "projects",     "/api/workspace/summary", "small", "periodic",  "members",   FIELDS_MEMBERS,  ENUM_MEMBERS,  EXAMPLE_MEMBERS),
  contract("quota-coverage-metric",      "metric",    "Projects with Quotas",       "projects",     "/api/workspace/summary", "small", "periodic",  "members",   FIELDS_MEMBERS,  ENUM_MEMBERS,  EXAMPLE_MEMBERS),
  // --- Activity section ---
  contract("timeline-feed",              "timeline",  "Event Timeline",             "activity",     "/api/workspace/timeline",      "full",   "periodic",  "static_reference", FIELDS_STATIC, ENUM_STATIC, { ...EXAMPLE_STATIC, sourceEndpoint: "/api/workspace/timeline",      note: "Live timeline data — fetch from sourceEndpoint for full event list" }),
  contract("diff-pairs-table",           "table",     "Snapshot Diff Pairs",        "activity",     "/api/workspace/diff",          "medium", "on-demand", "static_reference", FIELDS_STATIC, ENUM_STATIC, { ...EXAMPLE_STATIC, sourceEndpoint: "/api/workspace/diff",          note: "Diff pair data — fetch from sourceEndpoint for full snapshot comparison list" }),
  contract("audit-reports-list",         "list",      "Audit Reports",              "activity",     "/api/workspace/audit/reports", "large",  "on-demand", "audit",            FIELDS_AUDIT,  ENUM_AUDIT,  EXAMPLE_AUDIT),
  contract("audit-digest-scorecard",     "scorecard", "Audit Digest",               "activity",     "/api/workspace/audit/digest",  "medium", "on-demand", "audit",            FIELDS_AUDIT,  ENUM_AUDIT,  EXAMPLE_AUDIT),
];

// Build index for O(1) lookups
const CONTRACT_INDEX: Map<string, WidgetContract> = new Map(
  CONTRACT_REGISTRY.map((c) => [c.widgetId, c]),
);

// --- Summary computation ---

function buildSummary(): WidgetContractSummary {
  const byDataType: Record<string, number> = {};
  const byWidgetType: Record<string, number> = {};
  const bySectionId: Record<string, number> = {};

  for (const c of CONTRACT_REGISTRY) {
    byDataType[c.compactDataType] = (byDataType[c.compactDataType] ?? 0) + 1;
    byWidgetType[c.widgetType] = (byWidgetType[c.widgetType] ?? 0) + 1;
    bySectionId[c.sectionId] = (bySectionId[c.sectionId] ?? 0) + 1;
  }

  return {
    totalContracts: CONTRACT_REGISTRY.length,
    contractsByCompactDataType: byDataType,
    contractsByWidgetType: byWidgetType,
    contractsBySectionId: bySectionId,
    schemaVersion: SCHEMA_VERSION,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// Pre-compute summary (pure derivation from static registry — safe to compute at module load)
const REGISTRY_SUMMARY: WidgetContractSummary = buildSummary();

// --- Public API ---

export function listWidgetContracts(): WidgetContractListResult {
  const items: WidgetContractSummaryItem[] = CONTRACT_REGISTRY.map((c) => ({
    widgetId: c.widgetId,
    widgetType: c.widgetType,
    title: c.title,
    sectionId: c.sectionId,
    sourceEndpoint: c.sourceEndpoint,
    compactDataType: c.compactDataType,
    schemaVersion: c.schemaVersion,
    fieldCount: c.fields.length,
    requiredFieldCount: c.requiredFields.length,
    executionBlocked: EXECUTION_BLOCKED,
  }));

  return {
    contracts: items,
    total: items.length,
    summary: REGISTRY_SUMMARY,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getWidgetContract(widgetId: string): WidgetContract | null {
  return CONTRACT_INDEX.get(widgetId) ?? null;
}

export function getWidgetContractCount(): number {
  return CONTRACT_REGISTRY.length;
}

export function getAllWidgetContracts(): ReadonlyArray<WidgetContract> {
  return CONTRACT_REGISTRY;
}
