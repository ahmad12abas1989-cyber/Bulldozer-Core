import { createHash } from "node:crypto";
import {
  getPolicyComplianceLedger,
  type ComplianceLedgerEntry,
} from "./workspacePolicyComplianceLedger";

const EXECUTION_BLOCKED: true = true;

// --- Band thresholds ---
const WARM_MIN = 1;
const HOT_MIN = 10;

// --- Canonical orderings (stable, deterministic) ---
const PERMISSION_ORDER: string[] = ["read", "monitor", "write"];
const ROLE_ORDER: string[] = ["owner", "admin", "operator", "viewer", "guest"];

// --- Types ---

export type ActivityBand = "cold" | "warm" | "hot";

export interface BandCounts {
  cold: number;
  warm: number;
  hot: number;
  total: number;
  executionBlocked: true;
}

export interface HeatmapPolicyRef {
  method: string;
  path: string;
  permission: string;
  minimumRole: string;
  observationCount: number;
  band: ActivityBand;
  executionBlocked: true;
}

export interface HeatmapSummary {
  totalPolicies: number;
  coldCount: number;
  warmCount: number;
  hotCount: number;
  coveragePercent: number;
  hottestPolicy: HeatmapPolicyRef | null;
  coldestPolicy: HeatmapPolicyRef | null;
  executionBlocked: true;
}

export interface WorkspaceObservationHeatmap {
  heatmapId: string;
  generatedAt: string;
  summary: HeatmapSummary;
  permissionMatrix: Record<string, BandCounts>;
  roleTierMatrix: Record<string, BandCounts>;
  policies: HeatmapPolicyRef[];
  auditEntriesScanned: number;
  executionBlocked: true;
}

// --- Internal helpers ---

function classifyBand(observationCount: number): ActivityBand {
  if (observationCount >= HOT_MIN) return "hot";
  if (observationCount >= WARM_MIN) return "warm";
  return "cold";
}

function toRef(entry: ComplianceLedgerEntry): HeatmapPolicyRef {
  return {
    method: entry.method,
    path: entry.path,
    permission: entry.permission,
    minimumRole: entry.minimumRole,
    observationCount: entry.observationCount,
    band: classifyBand(entry.observationCount),
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function entryKey(ref: HeatmapPolicyRef): string {
  return `${ref.method}:${ref.path}`;
}

function sortRefs(refs: HeatmapPolicyRef[]): HeatmapPolicyRef[] {
  const hot = refs
    .filter((r) => r.band === "hot")
    .sort((a, b) =>
      b.observationCount !== a.observationCount
        ? b.observationCount - a.observationCount
        : entryKey(a).localeCompare(entryKey(b)),
    );
  const warm = refs
    .filter((r) => r.band === "warm")
    .sort((a, b) =>
      b.observationCount !== a.observationCount
        ? b.observationCount - a.observationCount
        : entryKey(a).localeCompare(entryKey(b)),
    );
  const cold = refs
    .filter((r) => r.band === "cold")
    .sort((a, b) => entryKey(a).localeCompare(entryKey(b)));
  return [...hot, ...warm, ...cold];
}

function emptyBandCounts(): BandCounts {
  return { cold: 0, warm: 0, hot: 0, total: 0, executionBlocked: EXECUTION_BLOCKED };
}

function buildPermissionMatrix(refs: HeatmapPolicyRef[]): Record<string, BandCounts> {
  const matrix: Record<string, BandCounts> = {};
  for (const perm of PERMISSION_ORDER) {
    matrix[perm] = emptyBandCounts();
  }
  for (const ref of refs) {
    const key = PERMISSION_ORDER.includes(ref.permission)
      ? ref.permission
      : ref.permission;
    if (!(key in matrix)) matrix[key] = emptyBandCounts();
    matrix[key][ref.band]++;
    matrix[key].total++;
  }
  return matrix;
}

function buildRoleTierMatrix(refs: HeatmapPolicyRef[]): Record<string, BandCounts> {
  const matrix: Record<string, BandCounts> = {};
  for (const role of ROLE_ORDER) {
    matrix[role] = emptyBandCounts();
  }
  for (const ref of refs) {
    const key = ROLE_ORDER.includes(ref.minimumRole)
      ? ref.minimumRole
      : ref.minimumRole;
    if (!(key in matrix)) matrix[key] = emptyBandCounts();
    matrix[key][ref.band]++;
    matrix[key].total++;
  }
  return matrix;
}

function findHottestPolicy(refs: HeatmapPolicyRef[]): HeatmapPolicyRef | null {
  let best: HeatmapPolicyRef | null = null;
  for (const ref of refs) {
    if (
      best === null ||
      ref.observationCount > best.observationCount ||
      (ref.observationCount === best.observationCount &&
        entryKey(ref) < entryKey(best))
    ) {
      best = ref;
    }
  }
  return best;
}

function findColdestPolicy(refs: HeatmapPolicyRef[]): HeatmapPolicyRef | null {
  let best: HeatmapPolicyRef | null = null;
  for (const ref of refs) {
    if (
      best === null ||
      ref.observationCount < best.observationCount ||
      (ref.observationCount === best.observationCount &&
        entryKey(ref) < entryKey(best))
    ) {
      best = ref;
    }
  }
  return best;
}

// --- Public API ---

export function getWorkspaceObservationHeatmap(): WorkspaceObservationHeatmap {
  const generatedAt = new Date().toISOString();
  const heatmapId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  const ledger = getPolicyComplianceLedger();
  const refs = sortRefs(ledger.entries.map(toRef));

  const totalPolicies = refs.length;
  const coldCount = refs.filter((r) => r.band === "cold").length;
  const warmCount = refs.filter((r) => r.band === "warm").length;
  const hotCount = refs.filter((r) => r.band === "hot").length;
  const coveragePercent =
    totalPolicies > 0
      ? Math.min(100, Math.round(((warmCount + hotCount) / totalPolicies) * 100))
      : 0;

  const hottestPolicy = refs.length > 0 ? findHottestPolicy(refs) : null;
  const coldestPolicy = refs.length > 0 ? findColdestPolicy(refs) : null;

  const summary: HeatmapSummary = {
    totalPolicies,
    coldCount,
    warmCount,
    hotCount,
    coveragePercent,
    hottestPolicy,
    coldestPolicy,
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    heatmapId,
    generatedAt,
    summary,
    permissionMatrix: buildPermissionMatrix(refs),
    roleTierMatrix: buildRoleTierMatrix(refs),
    policies: refs,
    auditEntriesScanned: ledger.auditEntriesScanned,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
