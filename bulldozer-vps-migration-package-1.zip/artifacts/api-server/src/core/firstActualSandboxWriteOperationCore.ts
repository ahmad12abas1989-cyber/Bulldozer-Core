// firstActualSandboxWriteOperationCore.ts
// Phase 315 — First Actual Sandbox Write Operation Core Skeleton
// In-memory first actual sandbox write operation descriptor engine.
// Layer 24 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate stack.
// Defines the first actual sandbox write operation model.
// Restricts future writes to sandbox-approved targets only.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms.
// No unrestricted writes. No Mother Core writes. No vault access.
// No shell execution. No network access.
// runtimeWriteExecutorEnabled=false — the runtime write executor has not been enabled.
// actualWriteOperationPrepared=true — descriptor-readiness established for a future runtime write executor phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { ActualSandboxWriteExecutionGateRecord }  from "./actualSandboxWriteExecutionGateCore.js";
import type { FirstScopedSandboxWriteActivationRecord } from "./firstScopedSandboxWriteActivationCore.js";
import type { ActualSandboxWritePermissionGateRecord }  from "./actualSandboxWritePermissionGateCore.js";
import type { FirstActualSandboxMutationSwitchRecord }  from "./firstActualSandboxMutationSwitchCore.js";
import type { FirstGuardedWriteEnableRecord }            from "./firstGuardedWriteEnableCore.js";
import type { ControlledExecutionRecord }                from "./controlledExecutionCore.js";
import { randomUUID }                                    from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type WriteOperationState = "descriptor_actual_write_operation_ready";

export type OperationSafetyCheckRule =
  | "execution_gate_exists"
  | "scoped_activation_exists"
  | "permission_gate_exists"
  | "mutation_switch_exists"
  | "guarded_write_enable_exists"
  | "execution_record_exists"
  | "execution_gate_bound_to_scoped_activation"
  | "scoped_activation_bound_to_permission_gate"
  | "permission_gate_bound_to_mutation_switch"
  | "mutation_switch_bound_to_guarded_enable"
  | "runtime_executor_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface OperationSafetyCheck {
  readonly rule: OperationSafetyCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface WriteOperationPlanEntry {
  readonly planEntryId:      string;
  readonly targetScope:      "sandbox_approved_only";
  readonly operationType:    "descriptor_planned";
  readonly mutationBlocked:  true;
  readonly planNote:         string;
}

export interface BlockedOperationReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface RollbackOperationReference {
  readonly writeExecutionGateId:       string;
  readonly scopedWriteActivationId:    string;
  readonly writePermissionGateId:      string;
  readonly mutationSwitchId:           string;
  readonly rollbackSnapshotId:         string;
  readonly actualWriteOperationPrepared: true;
  readonly runtimeWriteExecutorEnabled:  false;
  readonly actualWritesEnabled:          false;
  readonly rollbackChainValid:           boolean;
  readonly referenceNote:                string;
}

export interface WriteOperationReadinessReport {
  readonly actualWriteOperationPrepared:  true;
  readonly runtimeWriteExecutorEnabled:   false;
  readonly writeExecutionGateEnabled:     false;
  readonly scopedActivationEnabled:       false;
  readonly writePermissionEnabled:        false;
  readonly mutationSwitchEnabled:         false;
  readonly guardedWriteEnabled:           false;
  readonly actualWritesEnabled:           false;
  readonly realWritesEnabled:             false;
  readonly approvalRequired:              true;
  readonly allChecksPass:                 boolean;
  readonly blockedReasonCount:            number;
  readonly rollbackChainValid:            boolean;
  readonly summary:                       string;
}

export interface FirstActualSandboxWriteOperationRecord {
  readonly actualWriteOperationId:      string;
  readonly operationState:              WriteOperationState;
  readonly approvalRequired:            true;
  readonly actualWriteOperationPrepared: true;
  readonly runtimeWriteExecutorEnabled:  false;
  readonly actualWritesEnabled:          false;
  readonly filesystemMutationBlocked:    true;
  readonly motherCoreMutationBlocked:    true;
  readonly vaultMutationBlocked:         true;
  readonly shellBlocked:                 true;
  readonly networkBlocked:               true;
  readonly implementationPhase:          "descriptor_only";
  readonly writeExecutionGateId:         string;
  readonly scopedWriteActivationId:      string;
  readonly writePermissionGateId:        string;
  readonly mutationSwitchId:             string;
  readonly guardedWriteEnableId:         string;
  readonly controlledExecutionId:        string;
  readonly writeOperationPlan:           readonly WriteOperationPlanEntry[];
  readonly operationSafetyChecks:        readonly OperationSafetyCheck[];
  readonly blockedOperationReasons:      readonly BlockedOperationReason[];
  readonly rollbackOperationReference:   RollbackOperationReference;
  readonly writeOperationReadinessReport: WriteOperationReadinessReport;
  readonly createdAt:                    string;
}

export interface CreateWriteOperationInput {
  readonly writeExecutionGateRecord:  ActualSandboxWriteExecutionGateRecord;
  readonly scopedActivationRecord:    FirstScopedSandboxWriteActivationRecord;
  readonly writePermissionGateRecord: ActualSandboxWritePermissionGateRecord;
  readonly mutationSwitchRecord:      FirstActualSandboxMutationSwitchRecord;
  readonly guardedWriteEnableRecord:  FirstGuardedWriteEnableRecord;
  readonly executionRecord:           ControlledExecutionRecord;
}

export interface FirstActualSandboxWriteOperationSummary {
  readonly total:                        number;
  readonly byState:                      Record<WriteOperationState, number>;
  readonly actualWriteOperationPrepared:  true;
  readonly runtimeWriteExecutorEnabled:   false;
  readonly actualWritesEnabled:           false;
  readonly approvalRequired:             true;
  readonly filesystemMutationBlocked:    true;
  readonly motherCoreMutationBlocked:    true;
  readonly operationState:              WriteOperationState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstActualSandboxWriteOperationRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildSafetyChecks(input: CreateWriteOperationInput): readonly OperationSafetyCheck[] {
  const { writeExecutionGateRecord, scopedActivationRecord, writePermissionGateRecord, mutationSwitchRecord, guardedWriteEnableRecord, executionRecord } = input;

  const gateExists    = writeExecutionGateRecord.writeExecutionGateId.length > 0;
  const scopedExists  = scopedActivationRecord.scopedWriteActivationId.length > 0;
  const permExists    = writePermissionGateRecord.writePermissionGateId.length > 0;
  const switchExists  = mutationSwitchRecord.mutationSwitchId.length > 0;
  const guardedExists = guardedWriteEnableRecord.guardedWriteEnableId.length > 0;
  const execExists    = executionRecord.controlledExecutionId.length > 0;

  const gateBound    = writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId;
  const scopedBound  = scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId;
  const permBound    = writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId;
  const switchBound  = mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId;

  return [
    {
      rule: "execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`
        : "writeExecutionGateRecord.writeExecutionGateId is empty",
    },
    {
      rule: "scoped_activation_exists",
      pass: scopedExists,
      note: scopedExists
        ? `scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`
        : "scopedActivationRecord.scopedWriteActivationId is empty",
    },
    {
      rule: "permission_gate_exists",
      pass: permExists,
      note: permExists
        ? `writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`
        : "writePermissionGateRecord.writePermissionGateId is empty",
    },
    {
      rule: "mutation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`
        : "mutationSwitchRecord.mutationSwitchId is empty",
    },
    {
      rule: "guarded_write_enable_exists",
      pass: guardedExists,
      note: guardedExists
        ? `guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`
        : "guardedWriteEnableRecord.guardedWriteEnableId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: execExists,
      note: execExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "execution_gate_bound_to_scoped_activation",
      pass: gateBound,
      note: gateBound
        ? `writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId (${scopedActivationRecord.scopedWriteActivationId})`
        : `execution-gate/scoped-activation mismatch: gate.scopedWriteActivationId=${writeExecutionGateRecord.scopedWriteActivationId} vs scoped.scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`,
    },
    {
      rule: "scoped_activation_bound_to_permission_gate",
      pass: scopedBound,
      note: scopedBound
        ? `scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId (${writePermissionGateRecord.writePermissionGateId})`
        : `scoped-activation/permission-gate mismatch: scoped.writePermissionGateId=${scopedActivationRecord.writePermissionGateId} vs gate.writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`,
    },
    {
      rule: "permission_gate_bound_to_mutation_switch",
      pass: permBound,
      note: permBound
        ? `writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId (${mutationSwitchRecord.mutationSwitchId})`
        : `permission-gate/mutation-switch mismatch: gate.mutationSwitchId=${writePermissionGateRecord.mutationSwitchId} vs switch.mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`,
    },
    {
      rule: "mutation_switch_bound_to_guarded_enable",
      pass: switchBound,
      note: switchBound
        ? `mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId (${guardedWriteEnableRecord.guardedWriteEnableId})`
        : `mutation-switch/guarded-enable mismatch: switch.guardedWriteEnableId=${mutationSwitchRecord.guardedWriteEnableId} vs guarded.guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`,
    },
    {
      rule: "runtime_executor_still_disabled",
      pass: true,
      note: "runtimeWriteExecutorEnabled=false — compile-time literal; no runtime write executor phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "operationState=descriptor_actual_write_operation_ready — output is a descriptor only; runtime filesystem mutation is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly OperationSafetyCheck[]): readonly BlockedOperationReason[] {
  const staticReasons: BlockedOperationReason[] = [
    { code: "runtime_executor_disabled", reason: "runtimeWriteExecutorEnabled=false — compile-time literal; an explicit runtime write executor phase must enable the executor before any sandbox write target can be touched",                                                                                                          static: true },
    { code: "approval_required",         reason: "approvalRequired=true — explicit operator approval is required before the runtime write executor can be started",                                                                                                                                                                      static: true },
    { code: "actual_writes_disabled",    reason: "actualWritesEnabled=false — compile-time literal across all 24 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, and execution-gate layers", static: true },
  ];
  const dynamicReasons: BlockedOperationReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildRollbackOperationReference(
  input: CreateWriteOperationInput,
  rollbackChainValid: boolean,
): RollbackOperationReference {
  const { writeExecutionGateRecord, scopedActivationRecord, writePermissionGateRecord, mutationSwitchRecord } = input;
  return {
    writeExecutionGateId:         writeExecutionGateRecord.writeExecutionGateId,
    scopedWriteActivationId:      scopedActivationRecord.scopedWriteActivationId,
    writePermissionGateId:        writePermissionGateRecord.writePermissionGateId,
    mutationSwitchId:             mutationSwitchRecord.mutationSwitchId,
    rollbackSnapshotId:           writeExecutionGateRecord.linkedExecutionGateReference.rollbackSnapshotId,
    actualWriteOperationPrepared: true,
    runtimeWriteExecutorEnabled:  false,
    actualWritesEnabled:          false,
    rollbackChainValid,
    referenceNote: "rollback reference sources rollbackSnapshotId from writeExecutionGateRecord.linkedExecutionGateReference; runtime executor disabled; filesystem mutation blocked; descriptor-only",
  };
}

function buildWriteOperationPlan(): readonly WriteOperationPlanEntry[] {
  return [
    {
      planEntryId:     randomUUID(),
      targetScope:     "sandbox_approved_only",
      operationType:   "descriptor_planned",
      mutationBlocked: true,
      planNote:        "All write targets restricted to sandbox-approved paths only. No filesystem mutation until runtime write executor phase. descriptor_actual_write_operation_ready state — plan captured as descriptor only.",
    },
  ];
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createWriteOperationRecord(
  input: CreateWriteOperationInput,
): FirstActualSandboxWriteOperationRecord {
  const { writeExecutionGateRecord, scopedActivationRecord, writePermissionGateRecord, mutationSwitchRecord, guardedWriteEnableRecord, executionRecord } = input;

  const checks = buildSafetyChecks(input);

  const rollbackChainValid = writeExecutionGateRecord.executionGateReadinessReport.rollbackChainValid;

  const allChecksPass      = checks.every((c) => c.pass);
  const blockedReasons     = buildBlockedReasons(checks);
  const rollbackRef        = buildRollbackOperationReference(input, rollbackChainValid);
  const plan               = buildWriteOperationPlan();

  const writeOperationReadinessReport: WriteOperationReadinessReport = {
    actualWriteOperationPrepared:  true,
    runtimeWriteExecutorEnabled:   false,
    writeExecutionGateEnabled:     false,
    scopedActivationEnabled:       false,
    writePermissionEnabled:        false,
    mutationSwitchEnabled:         false,
    guardedWriteEnabled:           false,
    actualWritesEnabled:           false,
    realWritesEnabled:             false,
    approvalRequired:              true,
    allChecksPass,
    blockedReasonCount:            blockedReasons.length,
    rollbackChainValid,
    summary: `operationState=descriptor_actual_write_operation_ready; runtimeWriteExecutorEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstActualSandboxWriteOperationRecord = {
    actualWriteOperationId:        randomUUID(),
    operationState:                "descriptor_actual_write_operation_ready",
    approvalRequired:              true,
    actualWriteOperationPrepared:  true,
    runtimeWriteExecutorEnabled:   false,
    actualWritesEnabled:           false,
    filesystemMutationBlocked:     true,
    motherCoreMutationBlocked:     true,
    vaultMutationBlocked:          true,
    shellBlocked:                  true,
    networkBlocked:                true,
    implementationPhase:           "descriptor_only",
    writeExecutionGateId:          writeExecutionGateRecord.writeExecutionGateId,
    scopedWriteActivationId:       scopedActivationRecord.scopedWriteActivationId,
    writePermissionGateId:         writePermissionGateRecord.writePermissionGateId,
    mutationSwitchId:              mutationSwitchRecord.mutationSwitchId,
    guardedWriteEnableId:          guardedWriteEnableRecord.guardedWriteEnableId,
    controlledExecutionId:         executionRecord.controlledExecutionId,
    writeOperationPlan:            plan,
    operationSafetyChecks:         checks,
    blockedOperationReasons:       blockedReasons,
    rollbackOperationReference:    rollbackRef,
    writeOperationReadinessReport,
    createdAt:                     new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listWriteOperationRecords(): readonly FirstActualSandboxWriteOperationRecord[] {
  return _store.slice();
}

export function getWriteOperationSummary(): FirstActualSandboxWriteOperationSummary {
  return {
    total:                          _store.length,
    byState:                        { descriptor_actual_write_operation_ready: _store.length },
    actualWriteOperationPrepared:   true,
    runtimeWriteExecutorEnabled:    false,
    actualWritesEnabled:            false,
    approvalRequired:               true,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    operationState:                 "descriptor_actual_write_operation_ready",
    implementationPhase:            "descriptor_only",
  };
}
