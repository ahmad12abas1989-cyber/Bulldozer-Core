// firstActualSandboxMutationSwitchCore.ts
// Phase 303 — First Actual Sandbox Mutation Switch Core Skeleton
// In-memory first sandbox mutation-switch descriptor engine.
// Layer 20 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable stack.
// Prepares the transition from guarded write readiness toward future actual sandbox mutation.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem writes. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// mutationSwitchEnabled=false — the mutation switch has not been activated.
// mutationSwitchPrepared=true — descriptor-readiness established for a future sandbox mutation phase.

import type { FirstGuardedWriteEnableRecord }          from "./firstGuardedWriteEnableCore.js";
import type { FirstBridgeOpenRecord }                  from "./firstBridgeOpenCore.js";
import type { ControlledWriteActivationBridgeRecord }  from "./controlledWriteActivationBridgeCore.js";
import type { FirstExecutionTransitionRecord }          from "./firstExecutionTransitionCore.js";
import type { FirstActivationSwitchRecord }             from "./firstActivationSwitchCore.js";
import type { ControlledExecutionRecord }               from "./controlledExecutionCore.js";
import { randomUUID }                                   from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type MutationSwitchState = "descriptor_mutation_switch_pending";

export type MutationSwitchCheckRule =
  | "guarded_write_enable_exists"
  | "bridge_open_exists"
  | "bridge_record_exists"
  | "execution_transition_exists"
  | "activation_switch_exists"
  | "execution_record_exists"
  | "guarded_enable_bound_to_bridge_open"
  | "bridge_open_bound_to_bridge"
  | "bridge_bound_to_transition"
  | "transition_bound_to_switch"
  | "mutation_switch_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface MutationSwitchCheck {
  readonly rule: MutationSwitchCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface MutationSwitchBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedMutationSwitchReference {
  readonly guardedWriteEnableId:       string;
  readonly bridgeOpenId:               string;
  readonly writeActivationBridgeId:    string;
  readonly executionTransitionId:      string;
  readonly rollbackSnapshotId:         string;
  readonly mutationSwitchPrepared:     true;
  readonly mutationSwitchEnabled:      false;
  readonly guardedWriteEnabled:        false;
  readonly bridgeOpenEnabled:          false;
  readonly rollbackChainValid:         boolean;
  readonly referenceNote:              string;
}

export interface MutationSwitchReadinessReport {
  readonly mutationSwitchPrepared:      true;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly summary:                     string;
}

export interface FirstActualSandboxMutationSwitchRecord {
  readonly mutationSwitchId:            string;
  readonly mutationSwitchState:         MutationSwitchState;
  readonly approvalRequired:            true;
  readonly mutationSwitchPrepared:      true;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly implementationPhase:         "descriptor_only";
  readonly guardedWriteEnableId:        string;
  readonly bridgeOpenId:                string;
  readonly writeActivationBridgeId:     string;
  readonly executionTransitionId:       string;
  readonly activationSwitchId:          string;
  readonly controlledExecutionId:       string;
  readonly mutationSwitchChecks:        readonly MutationSwitchCheck[];
  readonly mutationSwitchBlockedReasons: readonly MutationSwitchBlockedReason[];
  readonly mutationSwitchReadinessReport: MutationSwitchReadinessReport;
  readonly linkedMutationSwitchReference: LinkedMutationSwitchReference;
  readonly createdAt:                   string;
}

export interface CreateMutationSwitchInput {
  readonly guardedWriteEnableRecord: FirstGuardedWriteEnableRecord;
  readonly bridgeOpenRecord:         FirstBridgeOpenRecord;
  readonly bridgeRecord:             ControlledWriteActivationBridgeRecord;
  readonly transitionRecord:         FirstExecutionTransitionRecord;
  readonly switchRecord:             FirstActivationSwitchRecord;
  readonly executionRecord:          ControlledExecutionRecord;
}

export interface FirstActualSandboxMutationSwitchSummary {
  readonly total:                       number;
  readonly byState:                     Record<MutationSwitchState, number>;
  readonly mutationSwitchPrepared:      true;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly mutationSwitchState:         MutationSwitchState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstActualSandboxMutationSwitchRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateMutationSwitchInput): readonly MutationSwitchCheck[] {
  const { guardedWriteEnableRecord, bridgeOpenRecord, bridgeRecord, transitionRecord, switchRecord, executionRecord } = input;

  const guardedExists    = guardedWriteEnableRecord.guardedWriteEnableId.length > 0;
  const bridgeOpenExists = bridgeOpenRecord.bridgeOpenId.length > 0;
  const bridgeExists     = bridgeRecord.writeActivationBridgeId.length > 0;
  const transitionExists = transitionRecord.executionTransitionId.length > 0;
  const switchExists     = switchRecord.activationSwitchId.length > 0;
  const executionExists  = executionRecord.controlledExecutionId.length > 0;

  const guardedBound     = guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId;
  const bridgeOpenBound  = bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId;
  const bridgeBound      = bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId;
  const transitionBound  = transitionRecord.activationSwitchId === switchRecord.activationSwitchId;

  return [
    {
      rule: "guarded_write_enable_exists",
      pass: guardedExists,
      note: guardedExists
        ? `guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`
        : "guardedWriteEnableRecord.guardedWriteEnableId is empty",
    },
    {
      rule: "bridge_open_exists",
      pass: bridgeOpenExists,
      note: bridgeOpenExists
        ? `bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`
        : "bridgeOpenRecord.bridgeOpenId is empty",
    },
    {
      rule: "bridge_record_exists",
      pass: bridgeExists,
      note: bridgeExists
        ? `writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`
        : "bridgeRecord.writeActivationBridgeId is empty",
    },
    {
      rule: "execution_transition_exists",
      pass: transitionExists,
      note: transitionExists
        ? `executionTransitionId=${transitionRecord.executionTransitionId}`
        : "transitionRecord.executionTransitionId is empty",
    },
    {
      rule: "activation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `activationSwitchId=${switchRecord.activationSwitchId}`
        : "switchRecord.activationSwitchId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "guarded_enable_bound_to_bridge_open",
      pass: guardedBound,
      note: guardedBound
        ? `guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId (${bridgeOpenRecord.bridgeOpenId})`
        : `guarded-enable/bridge-open mismatch: guarded.bridgeOpenId=${guardedWriteEnableRecord.bridgeOpenId} vs bridgeOpen.bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`,
    },
    {
      rule: "bridge_open_bound_to_bridge",
      pass: bridgeOpenBound,
      note: bridgeOpenBound
        ? `bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId (${bridgeRecord.writeActivationBridgeId})`
        : `bridge-open/bridge mismatch: bridgeOpen.writeActivationBridgeId=${bridgeOpenRecord.writeActivationBridgeId} vs bridge.writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`,
    },
    {
      rule: "bridge_bound_to_transition",
      pass: bridgeBound,
      note: bridgeBound
        ? `bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId (${transitionRecord.executionTransitionId})`
        : `bridge-transition mismatch: bridge.executionTransitionId=${bridgeRecord.executionTransitionId} vs transition.executionTransitionId=${transitionRecord.executionTransitionId}`,
    },
    {
      rule: "transition_bound_to_switch",
      pass: transitionBound,
      note: transitionBound
        ? `transitionRecord.activationSwitchId === switchRecord.activationSwitchId (${switchRecord.activationSwitchId})`
        : `transition-switch mismatch: transition.activationSwitchId=${transitionRecord.activationSwitchId} vs switch.activationSwitchId=${switchRecord.activationSwitchId}`,
    },
    {
      rule: "mutation_switch_still_disabled",
      pass: true,
      note: "mutationSwitchEnabled=false — compile-time literal; no sandbox mutation execution phase has activated the switch",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "mutationSwitchState=descriptor_mutation_switch_pending — output is a descriptor only; mutation switch is not yet live",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly MutationSwitchCheck[]): readonly MutationSwitchBlockedReason[] {
  const staticReasons: MutationSwitchBlockedReason[] = [
    { code: "mutation_switch_disabled", reason: "mutationSwitchEnabled=false — compile-time literal; an explicit sandbox mutation execution phase must activate the switch",                                                    static: true },
    { code: "approval_required",        reason: "approvalRequired=true — explicit operator approval is required before the mutation switch can be activated",                                                                    static: true },
    { code: "actual_writes_disabled",   reason: "actualWritesEnabled=false — compile-time literal across all 20 sealed write-preparation, activation, switch, transition, bridge, bridge-open, and guarded-write-enable layers", static: true },
  ];
  const dynamicReasons: MutationSwitchBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedMutationSwitchReference(
  input: CreateMutationSwitchInput,
  rollbackChainValid: boolean,
): LinkedMutationSwitchReference {
  const { guardedWriteEnableRecord, bridgeOpenRecord, bridgeRecord, transitionRecord } = input;
  return {
    guardedWriteEnableId:    guardedWriteEnableRecord.guardedWriteEnableId,
    bridgeOpenId:            bridgeOpenRecord.bridgeOpenId,
    writeActivationBridgeId: bridgeRecord.writeActivationBridgeId,
    executionTransitionId:   transitionRecord.executionTransitionId,
    rollbackSnapshotId:      guardedWriteEnableRecord.linkedGuardedEnableReference.rollbackSnapshotId,
    mutationSwitchPrepared:  true,
    mutationSwitchEnabled:   false,
    guardedWriteEnabled:     false,
    bridgeOpenEnabled:       false,
    rollbackChainValid,
    referenceNote:           "linked mutation-switch reference sources rollbackSnapshotId from guardedWriteEnableRecord.linkedGuardedEnableReference; mutation switch disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createMutationSwitchRecord(
  input: CreateMutationSwitchInput,
): FirstActualSandboxMutationSwitchRecord {
  const { guardedWriteEnableRecord, bridgeOpenRecord, bridgeRecord, transitionRecord, switchRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = guardedWriteEnableRecord.guardedEnableReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedMutationSwitchReference(input, rollbackChainValid);

  const mutationSwitchReadinessReport: MutationSwitchReadinessReport = {
    mutationSwitchPrepared:       true,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    bridgeOpenEnabled:            false,
    bridgeEnabled:                false,
    executionTransitionEnabled:   false,
    activationSwitchEnabled:      false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    summary: `mutationSwitchState=descriptor_mutation_switch_pending; mutationSwitchEnabled=false; guardedWriteEnabled=false; bridgeOpenEnabled=false; actualWritesEnabled=false; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstActualSandboxMutationSwitchRecord = {
    mutationSwitchId:              randomUUID(),
    mutationSwitchState:           "descriptor_mutation_switch_pending",
    approvalRequired:              true,
    mutationSwitchPrepared:        true,
    mutationSwitchEnabled:         false,
    guardedWriteEnabled:           false,
    bridgeOpenEnabled:             false,
    bridgeEnabled:                 false,
    executionTransitionEnabled:    false,
    activationSwitchEnabled:       false,
    actualWritesEnabled:           false,
    realWritesEnabled:             false,
    filesystemMutationBlocked:     true,
    motherCoreMutationBlocked:     true,
    vaultMutationBlocked:          true,
    shellBlocked:                  true,
    networkBlocked:                true,
    implementationPhase:           "descriptor_only",
    guardedWriteEnableId:          guardedWriteEnableRecord.guardedWriteEnableId,
    bridgeOpenId:                  bridgeOpenRecord.bridgeOpenId,
    writeActivationBridgeId:       bridgeRecord.writeActivationBridgeId,
    executionTransitionId:         transitionRecord.executionTransitionId,
    activationSwitchId:            switchRecord.activationSwitchId,
    controlledExecutionId:         executionRecord.controlledExecutionId,
    mutationSwitchChecks:          checks,
    mutationSwitchBlockedReasons:  blockedReasons,
    mutationSwitchReadinessReport,
    linkedMutationSwitchReference: linkedRef,
    createdAt:                     new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listMutationSwitchRecords(): readonly FirstActualSandboxMutationSwitchRecord[] {
  return _store.slice();
}

export function getMutationSwitchSummary(): FirstActualSandboxMutationSwitchSummary {
  return {
    total:                         _store.length,
    byState:                       { descriptor_mutation_switch_pending: _store.length },
    mutationSwitchPrepared:        true,
    mutationSwitchEnabled:         false,
    guardedWriteEnabled:           false,
    bridgeOpenEnabled:             false,
    bridgeEnabled:                 false,
    executionTransitionEnabled:    false,
    activationSwitchEnabled:       false,
    actualWritesEnabled:           false,
    realWritesEnabled:             false,
    approvalRequired:              true,
    filesystemMutationBlocked:     true,
    motherCoreMutationBlocked:     true,
    mutationSwitchState:           "descriptor_mutation_switch_pending",
    implementationPhase:           "descriptor_only",
  };
}
