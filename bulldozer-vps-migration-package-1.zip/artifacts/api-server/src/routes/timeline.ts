import type { IncomingMessage, ServerResponse } from "node:http";
import { getTimeline } from "../core/timeline";
import { sendJson } from "../lib/response";

export function handleTimeline(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "/";
  const qIndex = rawUrl.indexOf("?");
  const limitStr = qIndex !== -1
    ? new URLSearchParams(rawUrl.slice(qIndex + 1)).get("limit")
    : null;
  const limit = limitStr !== null ? parseInt(limitStr, 10) : undefined;
  const validLimit = limit != null && !isNaN(limit) && limit > 0 ? limit : undefined;
  const slice = getTimeline(validLimit);
  sendJson(res, 200, { count: slice.length, events: slice });
}
