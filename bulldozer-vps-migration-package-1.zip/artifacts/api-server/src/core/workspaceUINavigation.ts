// workspaceUINavigation.ts
// Phase 137 — UI Navigation Manifest
// Pure derivation from getUIRenderModel().navigation only.
// No init. No persistence. No subsystem. No health check.
// No HTML/CSS/frontend framework code. executionBlocked always true.

import { getUIRenderModel } from "./workspaceUIRenderModel";

// ── Types ──────────────────────────────────────────────────────────────────

export interface UINavigationItem {
  readonly itemId: string;
  readonly title: string;
  readonly endpoint: string;
  readonly itemOrder: number;
  readonly executionBlocked: true;
}

export interface UINavigationGroup {
  readonly groupId: string;
  readonly title: string;
  readonly items: readonly UINavigationItem[];
  readonly itemCount: number;
  readonly executionBlocked: true;
}

export interface UINavigationManifest {
  readonly generatedAt: string;
  readonly totalGroups: number;
  readonly groups: readonly UINavigationGroup[];
  readonly defaultPage: "overview";
  readonly executionBlocked: true;
}

// ── Public API ─────────────────────────────────────────────────────────────

export function getUINavigationManifest(): UINavigationManifest {
  const nav = getUIRenderModel().navigation;

  const groups: UINavigationGroup[] = (nav.groups as readonly {
    groupId: string;
    title: string;
    groupOrder: number;
    items: readonly {
      itemId: string;
      title: string;
      route: string;
      itemOrder: number;
      executionBlocked: true;
    }[];
    executionBlocked: true;
  }[])
    .slice()
    .sort((a, b) => a.groupOrder - b.groupOrder)
    .map((g) => {
      const items: UINavigationItem[] = g.items
        .slice()
        .sort((a, b) => a.itemOrder - b.itemOrder)
        .map((item) => ({
          itemId: item.itemId,
          title: item.title,
          endpoint: item.route,
          itemOrder: item.itemOrder,
          executionBlocked: true as const,
        }));

      return {
        groupId: g.groupId,
        title: g.title,
        items,
        itemCount: items.length,
        executionBlocked: true as const,
      };
    });

  return {
    generatedAt: new Date().toISOString(),
    totalGroups: groups.length,
    groups,
    defaultPage: "overview",
    executionBlocked: true,
  };
}
