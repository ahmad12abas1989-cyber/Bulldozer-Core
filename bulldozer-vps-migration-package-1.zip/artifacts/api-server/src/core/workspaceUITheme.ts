import { getUIRenderModel } from "./workspaceUIRenderModel.js";

export interface UIThemeTokens {
  colorMode: string;
  density: string;
  cardRadius: string;
  gridGap: string;
  typographyScale: string;
  executionBlocked: true;
}

export interface UIThemeManifest {
  generatedAt: string;
  themeTokens: UIThemeTokens;
  executionBlocked: true;
}

export function getUIThemeManifest(): UIThemeManifest {
  const { themeTokens } = getUIRenderModel();

  return {
    generatedAt: new Date().toISOString(),
    themeTokens: {
      colorMode: themeTokens.colorMode,
      density: themeTokens.density,
      cardRadius: themeTokens.cardRadius,
      gridGap: themeTokens.gridGap,
      typographyScale: themeTokens.typographyScale,
      executionBlocked: true,
    },
    executionBlocked: true,
  };
}
