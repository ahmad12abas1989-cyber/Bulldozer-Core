// controlledFilesystemMutationEnablementCore.ts
// Phase 338 — Controlled Filesystem Mutation Enablement Descriptor Core Skeleton
// In-memory controlled filesystem mutation enablement descriptor engine.
// Layer 33 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply + mutation-surface stack.
// Prepares the controlled filesystem mutation enablement descriptor.
// Preserves sandbox-approved-only target scope from layers 24–32 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem mutation. No shell execution. No network access.
// No vault access. No Mother Core mutation.
// filesystemMutationEnablementEnabled=false — enablement has not been activated.
// filesystemMutationEnablementPrepared=true — descriptor-readiness established for a future
//   first controlled filesystem mutation activation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstActualSandboxMutationSurfaceRecord }       from "./firstActualSandboxMutationSurfaceCore.js";
import type { FirstActualSandboxMutationApplyRecord }         from "./firstActualSandboxMutationApplyCore.js";
import type { FirstActualSandboxMutationCommitRecord }        from "./firstActualSandboxMutationCommitCore.js";
import type { FirstActualSandboxMutationExecutorRecord }      from "./firstActualSandboxMutationExecutorCore.js";
import type { ActualSandboxWriteCommitExecutionGateRecord }   from "./actualSandboxWriteCommitExecutionGateCore.js";
import type { ControlledExecutionRecord }                     from "./controlledExecutionCore.js";
import { randomUUID }                                         from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FilesystemMutationEnablementState =
  "descriptor_filesystem_mutation_enablement_pending";

export type FilesystemMutationEnablementCheckRule =
  | "mutation_surface_exists"
  | "mutation_apply_exists"
  | "mutation_commit_exists"
  | "mutation_executor_exists"
  | "commit_execution_gate_exists"
  | "execution_record_exists"
  | "mutation_surface_bound_to_apply"
  | "mutation_apply_bound_to_commit"
  | "mutation_commit_bound_to_executor"
  | "mutation_executor_bound_to_commit_execution_gate"
  | "filesystem_mutation_enablement_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface FilesystemMutationEnablementCheck {
  readonly rule: FilesystemMutationEnablementCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface FilesystemMutationEnablementBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface FilesystemMutationEnablementPlanEntry {
  readonly entryId:                             string;
  readonly operationType:                       "descriptor_filesystem_mutation_enablement_planned";
  readonly targetScope:                         "sandbox_approved_only";
  readonly filesystemMutationEnablementEnabled: false;
  readonly mutationBlocked:                     true;
  readonly note:                                string;
}

export interface LinkedFilesystemMutationReference {
  readonly mutationSurfaceId:                   string;
  readonly mutationApplyId:                     string;
  readonly mutationCommitId:                    string;
  readonly mutationExecutorId:                  string;
  readonly rollbackSnapshotId:                  string;
  readonly filesystemMutationEnablementPrepared: true;
  readonly filesystemMutationEnablementEnabled: false;
  readonly mutationSurfaceEnabled:              false;
  readonly mutationApplyEnabled:                false;
  readonly actualWritesEnabled:                 false;
  readonly rollbackChainValid:                  boolean;
  readonly referenceNote:                       string;
}

export interface FilesystemMutationEnablementReadinessReport {
  readonly filesystemMutationEnablementPrepared: true;
  readonly filesystemMutationEnablementEnabled: false;
  readonly mutationSurfaceEnabled:              false;
  readonly mutationApplyEnabled:                false;
  readonly mutationCommitEnabled:               false;
  readonly mutationExecutorEnabled:             false;
  readonly commitExecutionGateEnabled:          false;
  readonly sandboxWriteCommitEnabled:           false;
  readonly runtimeWriteExecutorEnabled:         false;
  readonly writeExecutionGateEnabled:           false;
  readonly scopedActivationEnabled:             false;
  readonly writePermissionEnabled:              false;
  readonly mutationSwitchEnabled:               false;
  readonly guardedWriteEnabled:                 false;
  readonly actualWritesEnabled:                 false;
  readonly realWritesEnabled:                   false;
  readonly approvalRequired:                    true;
  readonly allChecksPass:                       boolean;
  readonly blockedReasonCount:                  number;
  readonly rollbackChainValid:                  boolean;
  readonly targetScope:                         "sandbox_approved_only";
  readonly summary:                             string;
}

export interface ControlledFilesystemMutationEnablementRecord {
  readonly filesystemMutationEnablementId:          string;
  readonly filesystemMutationEnablementState:       FilesystemMutationEnablementState;
  readonly approvalRequired:                        true;
  readonly filesystemMutationEnablementPrepared:    true;
  readonly filesystemMutationEnablementEnabled:     false;
  readonly mutationSurfaceEnabled:                  false;
  readonly mutationApplyEnabled:                    false;
  readonly mutationCommitEnabled:                   false;
  readonly mutationExecutorEnabled:                 false;
  readonly actualWritesEnabled:                     false;
  readonly filesystemMutationBlocked:               true;
  readonly motherCoreMutationBlocked:               true;
  readonly vaultMutationBlocked:                    true;
  readonly shellBlocked:                            true;
  readonly networkBlocked:                          true;
  readonly targetScope:                             "sandbox_approved_only";
  readonly implementationPhase:                     "descriptor_only";
  readonly mutationSurfaceId:                       string;
  readonly mutationApplyId:                         string;
  readonly mutationCommitId:                        string;
  readonly mutationExecutorId:                      string;
  readonly commitExecutionGateId:                   string;
  readonly controlledExecutionId:                   string;
  readonly filesystemMutationEnablementPlan:        readonly FilesystemMutationEnablementPlanEntry[];
  readonly filesystemMutationEnablementChecks:      readonly FilesystemMutationEnablementCheck[];
  readonly filesystemMutationEnablementBlockedReasons: readonly FilesystemMutationEnablementBlockedReason[];
  readonly filesystemMutationEnablementReadinessReport: FilesystemMutationEnablementReadinessReport;
  readonly linkedFilesystemMutationReference:       LinkedFilesystemMutationReference;
  readonly createdAt:                               string;
}

export interface CreateControlledFilesystemMutationEnablementInput {
  readonly mutationSurfaceRecord:       FirstActualSandboxMutationSurfaceRecord;
  readonly mutationApplyRecord:         FirstActualSandboxMutationApplyRecord;
  readonly mutationCommitRecord:        FirstActualSandboxMutationCommitRecord;
  readonly mutationExecutorRecord:      FirstActualSandboxMutationExecutorRecord;
  readonly commitExecutionGateRecord:   ActualSandboxWriteCommitExecutionGateRecord;
  readonly executionRecord:             ControlledExecutionRecord;
}

export interface ControlledFilesystemMutationEnablementSummary {
  readonly total:                               number;
  readonly byState:                             Record<FilesystemMutationEnablementState, number>;
  readonly filesystemMutationEnablementPrepared: true;
  readonly filesystemMutationEnablementEnabled: false;
  readonly mutationSurfaceEnabled:              false;
  readonly mutationApplyEnabled:                false;
  readonly mutationCommitEnabled:               false;
  readonly mutationExecutorEnabled:             false;
  readonly actualWritesEnabled:                 false;
  readonly approvalRequired:                    true;
  readonly filesystemMutationBlocked:           true;
  readonly motherCoreMutationBlocked:           true;
  readonly targetScope:                         "sandbox_approved_only";
  readonly filesystemMutationEnablementState:   FilesystemMutationEnablementState;
  readonly implementationPhase:                 "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: ControlledFilesystemMutationEnablementRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateControlledFilesystemMutationEnablementInput,
): readonly FilesystemMutationEnablementCheck[] {
  const { mutationSurfaceRecord, mutationApplyRecord, mutationCommitRecord, mutationExecutorRecord, commitExecutionGateRecord, executionRecord } = input;

  const surfaceExists = mutationSurfaceRecord.mutationSurfaceId.length > 0;
  const applyExists   = mutationApplyRecord.mutationApplyId.length > 0;
  const commitExists  = mutationCommitRecord.mutationCommitId.length > 0;
  const execExists    = mutationExecutorRecord.mutationExecutorId.length > 0;
  const gateExists    = commitExecutionGateRecord.commitExecutionGateId.length > 0;
  const ctrlExists    = executionRecord.controlledExecutionId.length > 0;

  const surfaceBound  = mutationSurfaceRecord.mutationApplyId === mutationApplyRecord.mutationApplyId;
  const applyBound    = mutationApplyRecord.mutationCommitId === mutationCommitRecord.mutationCommitId;
  const commitBound   = mutationCommitRecord.mutationExecutorId === mutationExecutorRecord.mutationExecutorId;
  const execBound     = mutationExecutorRecord.commitExecutionGateId === commitExecutionGateRecord.commitExecutionGateId;

  return [
    {
      rule: "mutation_surface_exists",
      pass: surfaceExists,
      note: surfaceExists
        ? `mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`
        : "mutationSurfaceRecord.mutationSurfaceId is empty",
    },
    {
      rule: "mutation_apply_exists",
      pass: applyExists,
      note: applyExists
        ? `mutationApplyId=${mutationApplyRecord.mutationApplyId}`
        : "mutationApplyRecord.mutationApplyId is empty",
    },
    {
      rule: "mutation_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `mutationCommitId=${mutationCommitRecord.mutationCommitId}`
        : "mutationCommitRecord.mutationCommitId is empty",
    },
    {
      rule: "mutation_executor_exists",
      pass: execExists,
      note: execExists
        ? `mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`
        : "mutationExecutorRecord.mutationExecutorId is empty",
    },
    {
      rule: "commit_execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`
        : "commitExecutionGateRecord.commitExecutionGateId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "mutation_surface_bound_to_apply",
      pass: surfaceBound,
      note: surfaceBound
        ? `mutationSurfaceRecord.mutationApplyId === mutationApplyRecord.mutationApplyId (${mutationApplyRecord.mutationApplyId})`
        : `surface/apply mismatch: surface.mutationApplyId=${mutationSurfaceRecord.mutationApplyId} vs apply.mutationApplyId=${mutationApplyRecord.mutationApplyId}`,
    },
    {
      rule: "mutation_apply_bound_to_commit",
      pass: applyBound,
      note: applyBound
        ? `mutationApplyRecord.mutationCommitId === mutationCommitRecord.mutationCommitId (${mutationCommitRecord.mutationCommitId})`
        : `apply/commit mismatch: apply.mutationCommitId=${mutationApplyRecord.mutationCommitId} vs commit.mutationCommitId=${mutationCommitRecord.mutationCommitId}`,
    },
    {
      rule: "mutation_commit_bound_to_executor",
      pass: commitBound,
      note: commitBound
        ? `mutationCommitRecord.mutationExecutorId === mutationExecutorRecord.mutationExecutorId (${mutationExecutorRecord.mutationExecutorId})`
        : `commit/executor mismatch: commit.mutationExecutorId=${mutationCommitRecord.mutationExecutorId} vs executor.mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`,
    },
    {
      rule: "mutation_executor_bound_to_commit_execution_gate",
      pass: execBound,
      note: execBound
        ? `mutationExecutorRecord.commitExecutionGateId === commitExecutionGateRecord.commitExecutionGateId (${commitExecutionGateRecord.commitExecutionGateId})`
        : `executor/gate mismatch: executor.commitExecutionGateId=${mutationExecutorRecord.commitExecutionGateId} vs gate.commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`,
    },
    {
      rule: "filesystem_mutation_enablement_still_disabled",
      pass: true,
      note: "filesystemMutationEnablementEnabled=false — compile-time literal; no filesystem mutation enablement activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "filesystemMutationEnablementState=descriptor_filesystem_mutation_enablement_pending — output is a descriptor only; filesystem mutation enablement is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly FilesystemMutationEnablementCheck[],
): readonly FilesystemMutationEnablementBlockedReason[] {
  const staticReasons: FilesystemMutationEnablementBlockedReason[] = [
    { code: "filesystem_mutation_enablement_disabled", reason: "filesystemMutationEnablementEnabled=false — compile-time literal; an explicit first controlled filesystem mutation activation phase must activate the enablement before any sandbox target can receive filesystem writes",                                                                                                                                                                                                                                                                                                                           static: true },
    { code: "approval_required",                       reason: "approvalRequired=true — explicit operator approval is required before the filesystem mutation enablement can be activated",                                                                                                                                                                                                                                                                                                                                                                                                                         static: true },
    { code: "actual_writes_disabled",                  reason: "actualWritesEnabled=false — compile-time literal across all 33 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, mutation-apply, and mutation-surface layers", static: true },
  ];
  const dynamicReasons: FilesystemMutationEnablementBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedFilesystemMutationReference(
  input: CreateControlledFilesystemMutationEnablementInput,
  rollbackChainValid: boolean,
): LinkedFilesystemMutationReference {
  const { mutationSurfaceRecord, mutationApplyRecord, mutationCommitRecord, mutationExecutorRecord } = input;
  return {
    mutationSurfaceId:                    mutationSurfaceRecord.mutationSurfaceId,
    mutationApplyId:                      mutationApplyRecord.mutationApplyId,
    mutationCommitId:                     mutationCommitRecord.mutationCommitId,
    mutationExecutorId:                   mutationExecutorRecord.mutationExecutorId,
    rollbackSnapshotId:                   mutationSurfaceRecord.linkedMutationSurfaceReference.rollbackSnapshotId,
    filesystemMutationEnablementPrepared: true,
    filesystemMutationEnablementEnabled:  false,
    mutationSurfaceEnabled:               false,
    mutationApplyEnabled:                 false,
    actualWritesEnabled:                  false,
    rollbackChainValid,
    referenceNote: "linked filesystem mutation reference sources rollbackSnapshotId from mutationSurfaceRecord.linkedMutationSurfaceReference; filesystem mutation enablement disabled; mutation surface disabled; mutation apply disabled; mutation commit disabled; mutation executor disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createControlledFilesystemMutationEnablementRecord(
  input: CreateControlledFilesystemMutationEnablementInput,
): ControlledFilesystemMutationEnablementRecord {
  const { mutationSurfaceRecord, mutationApplyRecord, mutationCommitRecord, mutationExecutorRecord, commitExecutionGateRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = mutationSurfaceRecord.mutationSurfaceReadinessReport.rollbackChainValid;

  const allChecksPass   = checks.every((c) => c.pass);
  const blockedReasons  = buildBlockedReasons(checks);
  const linkedRef       = buildLinkedFilesystemMutationReference(input, rollbackChainValid);

  const filesystemMutationEnablementPlan: FilesystemMutationEnablementPlanEntry[] = [
    {
      entryId:                             randomUUID(),
      operationType:                       "descriptor_filesystem_mutation_enablement_planned",
      targetScope:                         "sandbox_approved_only",
      filesystemMutationEnablementEnabled: false,
      mutationBlocked:                     true,
      note:                                "filesystem mutation enablement planned in descriptor-only mode; targetScope=sandbox_approved_only; filesystemMutationEnablementEnabled=false; filesystemMutationBlocked=true; first controlled filesystem mutation activation phase required to activate",
    },
  ];

  const filesystemMutationEnablementReadinessReport: FilesystemMutationEnablementReadinessReport = {
    filesystemMutationEnablementPrepared:  true,
    filesystemMutationEnablementEnabled:   false,
    mutationSurfaceEnabled:                false,
    mutationApplyEnabled:                  false,
    mutationCommitEnabled:                 false,
    mutationExecutorEnabled:               false,
    commitExecutionGateEnabled:            false,
    sandboxWriteCommitEnabled:             false,
    runtimeWriteExecutorEnabled:           false,
    writeExecutionGateEnabled:             false,
    scopedActivationEnabled:               false,
    writePermissionEnabled:                false,
    mutationSwitchEnabled:                 false,
    guardedWriteEnabled:                   false,
    actualWritesEnabled:                   false,
    realWritesEnabled:                     false,
    approvalRequired:                      true,
    allChecksPass,
    blockedReasonCount:                    blockedReasons.length,
    rollbackChainValid,
    targetScope:                           "sandbox_approved_only",
    summary: `filesystemMutationEnablementState=descriptor_filesystem_mutation_enablement_pending; filesystemMutationEnablementEnabled=false; mutationSurfaceEnabled=false; mutationApplyEnabled=false; mutationCommitEnabled=false; mutationExecutorEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: ControlledFilesystemMutationEnablementRecord = {
    filesystemMutationEnablementId:           randomUUID(),
    filesystemMutationEnablementState:        "descriptor_filesystem_mutation_enablement_pending",
    approvalRequired:                         true,
    filesystemMutationEnablementPrepared:     true,
    filesystemMutationEnablementEnabled:      false,
    mutationSurfaceEnabled:                   false,
    mutationApplyEnabled:                     false,
    mutationCommitEnabled:                    false,
    mutationExecutorEnabled:                  false,
    actualWritesEnabled:                      false,
    filesystemMutationBlocked:                true,
    motherCoreMutationBlocked:                true,
    vaultMutationBlocked:                     true,
    shellBlocked:                             true,
    networkBlocked:                           true,
    targetScope:                              "sandbox_approved_only",
    implementationPhase:                      "descriptor_only",
    mutationSurfaceId:                        mutationSurfaceRecord.mutationSurfaceId,
    mutationApplyId:                          mutationApplyRecord.mutationApplyId,
    mutationCommitId:                         mutationCommitRecord.mutationCommitId,
    mutationExecutorId:                       mutationExecutorRecord.mutationExecutorId,
    commitExecutionGateId:                    commitExecutionGateRecord.commitExecutionGateId,
    controlledExecutionId:                    executionRecord.controlledExecutionId,
    filesystemMutationEnablementPlan,
    filesystemMutationEnablementChecks:       checks,
    filesystemMutationEnablementBlockedReasons: blockedReasons,
    filesystemMutationEnablementReadinessReport,
    linkedFilesystemMutationReference:        linkedRef,
    createdAt:                                new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listControlledFilesystemMutationEnablementRecords(): readonly ControlledFilesystemMutationEnablementRecord[] {
  return _store.slice();
}

export function getControlledFilesystemMutationEnablementSummary(): ControlledFilesystemMutationEnablementSummary {
  return {
    total:                                  _store.length,
    byState:                                { descriptor_filesystem_mutation_enablement_pending: _store.length },
    filesystemMutationEnablementPrepared:   true,
    filesystemMutationEnablementEnabled:    false,
    mutationSurfaceEnabled:                 false,
    mutationApplyEnabled:                   false,
    mutationCommitEnabled:                  false,
    mutationExecutorEnabled:                false,
    actualWritesEnabled:                    false,
    approvalRequired:                       true,
    filesystemMutationBlocked:              true,
    motherCoreMutationBlocked:              true,
    targetScope:                            "sandbox_approved_only",
    filesystemMutationEnablementState:      "descriptor_filesystem_mutation_enablement_pending",
    implementationPhase:                    "descriptor_only",
  };
}
