import { startRuntime } from "./core/runtime";
import { logger } from "./lib/logger";

startRuntime().catch((err: unknown) => {
  logger.error({ err: String(err) }, "Failed to start Bulldozer Core");
  process.exit(1);
});
