// Auth Model — Phase 180
// Observe-only auth classification skeleton. No blocking. No sessions. No credentials.
// Defines actor types, access tiers (Phase 170 blueprint), and AuthDecision for future enforcement.
// Pure module — no init, no subsystem registration, no health checks, no event emission, no side effects.

export type AuthActorType =
  | "root_operator"
  | "internal_operator"
  | "employee"
  | "customer"
  | "service_token"
  | "anonymous";

export type AccessTier = 1 | 2 | 3 | 4;

export interface AccessTierDefinition {
  tier: AccessTier;
  label: string;
  actorTypes: readonly AuthActorType[];
  nucleusAccess: boolean;
  uiAccess: boolean;
  vaultAccess: boolean;
  description: string;
}

export interface AuthDecision {
  allowed: boolean;
  actorType: AuthActorType;
  tier: AccessTier | null;
  reason: string;
  observeOnly: true;
  evaluatedAt: string;
}

export interface AuthRequest {
  method: string;
  path: string;
  actorType?: string;
}

export interface AuthModelStatus {
  subsystemName: "auth_model";
  observeOnly: true;
  enforcing: false;
  actorTypeCount: number;
  actorTypes: readonly AuthActorType[];
  accessTierCount: number;
  authEnabled: false;
  implementationPhase: "skeleton";
  note: string;
}

// Sealed access tier map — Phase 170 Operator Access Architecture Blueprint
const ACCESS_TIER_DEFINITIONS: readonly AccessTierDefinition[] = [
  {
    tier: 1,
    label: "Root Operator",
    actorTypes: ["root_operator"],
    nucleusAccess: true,
    uiAccess: true,
    vaultAccess: true,
    description:
      "Single owner per deployment — full nucleus, /ui/*, vault, approval authority, rollback authority",
  },
  {
    tier: 2,
    label: "Internal Operators",
    actorTypes: ["internal_operator"],
    nucleusAccess: true,
    uiAccess: true,
    vaultAccess: false,
    description:
      "Trusted internal staff — operational access to nucleus, no structural mutation, no vault values",
  },
  {
    tier: 3,
    label: "Employees",
    actorTypes: ["employee"],
    nucleusAccess: false,
    uiAccess: false,
    vaultAccess: false,
    description:
      "Project-scoped workspace only — no nucleus API access, no /ui/*, no vault, sandbox ceiling",
  },
  {
    tier: 4,
    label: "Generated Product Customers",
    actorTypes: ["customer"],
    nucleusAccess: false,
    uiAccess: false,
    vaultAccess: false,
    description:
      "No Mother Core access — generated product boundary only, separate data and auth surface",
  },
];

const AUTH_ACTOR_TYPES: readonly AuthActorType[] = [
  "root_operator",
  "internal_operator",
  "employee",
  "customer",
  "service_token",
  "anonymous",
];

const VALID_ACTOR_TYPE_SET = new Set<string>(AUTH_ACTOR_TYPES as readonly string[]);

// Resolve a raw string to a known AuthActorType. Unknown values default to anonymous.
export function resolveActorType(raw: string | undefined): AuthActorType {
  if (typeof raw === "string" && VALID_ACTOR_TYPE_SET.has(raw)) {
    return raw as AuthActorType;
  }
  return "anonymous";
}

// Resolve an actor type to its Phase 170 access tier.
// service_token and anonymous have no tier (they are cross-cutting or ungrouped).
export function resolveAccessTier(actorType: AuthActorType): AccessTier | null {
  for (const def of ACCESS_TIER_DEFINITIONS) {
    if ((def.actorTypes as readonly string[]).includes(actorType)) {
      return def.tier;
    }
  }
  return null;
}

// Observe-only auth evaluator — never blocks, always returns observeOnly=true.
// Classifies the request and returns what enforcement *would* decide if auth were active.
// No credentials are checked. No sessions are consulted. No side effects produced.
export function evaluateAuthObserveOnly(req: AuthRequest): AuthDecision {
  const actorType = resolveActorType(req.actorType);
  const tier = resolveAccessTier(actorType);

  let reason: string;

  if (actorType === "anonymous") {
    reason = "observe: anonymous actor — would be denied on all routes after auth implementation";
  } else if (actorType === "customer") {
    reason = "observe: customer actor — no Mother Core access permitted on any route";
  } else if (actorType === "employee") {
    if (req.path.startsWith("/ui/") || req.path.startsWith("/api/")) {
      reason =
        "observe: employee actor — /ui/* and /api/* nucleus routes prohibited; employee workspace only";
    } else {
      reason = "observe: employee actor — route outside nucleus; scoped project access only";
    }
  } else if (actorType === "service_token") {
    reason =
      "observe: service_token actor — scoped per-token limits apply after rate limiting implementation";
  } else {
    reason = `observe: tier-${tier ?? "none"} actor (${actorType}) — would be evaluated against route access policy`;
  }

  return {
    allowed: true, // observe mode: never block
    actorType,
    tier,
    reason,
    observeOnly: true,
    evaluatedAt: new Date().toISOString(),
  };
}

export function listAuthActorTypes(): readonly AuthActorType[] {
  return AUTH_ACTOR_TYPES;
}

export function listAccessTiers(): readonly AccessTierDefinition[] {
  return ACCESS_TIER_DEFINITIONS;
}

export function getAuthModelStatus(): AuthModelStatus {
  return {
    subsystemName: "auth_model",
    observeOnly: true,
    enforcing: false,
    actorTypeCount: AUTH_ACTOR_TYPES.length,
    actorTypes: AUTH_ACTOR_TYPES,
    accessTierCount: ACCESS_TIER_DEFINITIONS.length,
    authEnabled: false,
    implementationPhase: "skeleton",
    note: "Phase 180 skeleton — observe-only classification, no credentials, no sessions, no blocking",
  };
}
