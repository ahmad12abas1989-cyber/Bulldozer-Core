import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson, sendError } from "../lib/response";
import {
  listCapabilityRecords,
  getCapabilityRecord,
  getCapabilityMatrixStatus,
} from "../core/runtimeCapabilityMatrix";

export function handleCapabilityMatrixList(_req: IncomingMessage, res: ServerResponse): void {
  const status = getCapabilityMatrixStatus();
  const matrixRecords = listCapabilityRecords();

  sendJson(res, 200, {
    ...status,
    subsystems: matrixRecords,
  });
}

export function handleCapabilityMatrixStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getCapabilityMatrixStatus());
}

export function handleCapabilityMatrixByName(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const subsystemName = segments[segments.length - 1] ?? "";

  if (!subsystemName) {
    sendError(res, 400, "Subsystem name is required");
    return;
  }

  const record = getCapabilityRecord(subsystemName);
  if (!record) {
    sendError(
      res,
      404,
      `Capability record not found: "${subsystemName}". Use GET /api/runtime/capabilities to list all subsystems.`,
    );
    return;
  }

  sendJson(res, 200, record);
}
