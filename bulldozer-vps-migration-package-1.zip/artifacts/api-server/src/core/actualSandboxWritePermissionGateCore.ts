// actualSandboxWritePermissionGateCore.ts
// Phase 306 — Actual Sandbox Write Permission Gate Core Skeleton
// In-memory first actual sandbox write permission gate descriptor engine.
// Layer 21 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable + mutation-switch stack.
// Defines the final permission gate before any real sandbox write.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// writePermissionEnabled=false — the write permission gate has not been opened.
// writePermissionPrepared=true — descriptor-readiness established for a future scoped sandbox write permission activation.

import type { FirstActualSandboxMutationSwitchRecord } from "./firstActualSandboxMutationSwitchCore.js";
import type { FirstGuardedWriteEnableRecord }           from "./firstGuardedWriteEnableCore.js";
import type { FirstBridgeOpenRecord }                   from "./firstBridgeOpenCore.js";
import type { ControlledWriteActivationBridgeRecord }   from "./controlledWriteActivationBridgeCore.js";
import type { FirstExecutionTransitionRecord }           from "./firstExecutionTransitionCore.js";
import type { ControlledExecutionRecord }                from "./controlledExecutionCore.js";
import { randomUUID }                                    from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type WritePermissionGateState = "descriptor_write_permission_pending";

export type PermissionCheckRule =
  | "mutation_switch_exists"
  | "guarded_write_enable_exists"
  | "bridge_open_exists"
  | "bridge_record_exists"
  | "execution_transition_exists"
  | "execution_record_exists"
  | "mutation_switch_bound_to_guarded_enable"
  | "guarded_enable_bound_to_bridge_open"
  | "bridge_open_bound_to_bridge"
  | "bridge_bound_to_transition"
  | "write_permission_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface PermissionCheck {
  readonly rule: PermissionCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface PermissionBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedPermissionReference {
  readonly mutationSwitchId:           string;
  readonly guardedWriteEnableId:       string;
  readonly bridgeOpenId:               string;
  readonly writeActivationBridgeId:    string;
  readonly rollbackSnapshotId:         string;
  readonly writePermissionPrepared:    true;
  readonly writePermissionEnabled:     false;
  readonly mutationSwitchEnabled:      false;
  readonly guardedWriteEnabled:        false;
  readonly rollbackChainValid:         boolean;
  readonly referenceNote:              string;
}

export interface PermissionReadinessReport {
  readonly writePermissionPrepared:     true;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly summary:                     string;
}

export interface ActualSandboxWritePermissionGateRecord {
  readonly writePermissionGateId:       string;
  readonly permissionState:             WritePermissionGateState;
  readonly approvalRequired:            true;
  readonly writePermissionPrepared:     true;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly implementationPhase:         "descriptor_only";
  readonly mutationSwitchId:            string;
  readonly guardedWriteEnableId:        string;
  readonly bridgeOpenId:                string;
  readonly writeActivationBridgeId:     string;
  readonly executionTransitionId:       string;
  readonly controlledExecutionId:       string;
  readonly permissionChecks:            readonly PermissionCheck[];
  readonly permissionBlockedReasons:    readonly PermissionBlockedReason[];
  readonly permissionReadinessReport:   PermissionReadinessReport;
  readonly linkedPermissionReference:   LinkedPermissionReference;
  readonly createdAt:                   string;
}

export interface CreateWritePermissionGateInput {
  readonly mutationSwitchRecord:     FirstActualSandboxMutationSwitchRecord;
  readonly guardedWriteEnableRecord: FirstGuardedWriteEnableRecord;
  readonly bridgeOpenRecord:         FirstBridgeOpenRecord;
  readonly bridgeRecord:             ControlledWriteActivationBridgeRecord;
  readonly transitionRecord:         FirstExecutionTransitionRecord;
  readonly executionRecord:          ControlledExecutionRecord;
}

export interface ActualSandboxWritePermissionGateSummary {
  readonly total:                       number;
  readonly byState:                     Record<WritePermissionGateState, number>;
  readonly writePermissionPrepared:     true;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly bridgeEnabled:               false;
  readonly executionTransitionEnabled:  false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly permissionState:             WritePermissionGateState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: ActualSandboxWritePermissionGateRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateWritePermissionGateInput): readonly PermissionCheck[] {
  const { mutationSwitchRecord, guardedWriteEnableRecord, bridgeOpenRecord, bridgeRecord, transitionRecord, executionRecord } = input;

  const switchExists     = mutationSwitchRecord.mutationSwitchId.length > 0;
  const guardedExists    = guardedWriteEnableRecord.guardedWriteEnableId.length > 0;
  const bridgeOpenExists = bridgeOpenRecord.bridgeOpenId.length > 0;
  const bridgeExists     = bridgeRecord.writeActivationBridgeId.length > 0;
  const transitionExists = transitionRecord.executionTransitionId.length > 0;
  const executionExists  = executionRecord.controlledExecutionId.length > 0;

  const switchBound      = mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId;
  const guardedBound     = guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId;
  const bridgeOpenBound  = bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId;
  const bridgeBound      = bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId;

  return [
    {
      rule: "mutation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`
        : "mutationSwitchRecord.mutationSwitchId is empty",
    },
    {
      rule: "guarded_write_enable_exists",
      pass: guardedExists,
      note: guardedExists
        ? `guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`
        : "guardedWriteEnableRecord.guardedWriteEnableId is empty",
    },
    {
      rule: "bridge_open_exists",
      pass: bridgeOpenExists,
      note: bridgeOpenExists
        ? `bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`
        : "bridgeOpenRecord.bridgeOpenId is empty",
    },
    {
      rule: "bridge_record_exists",
      pass: bridgeExists,
      note: bridgeExists
        ? `writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`
        : "bridgeRecord.writeActivationBridgeId is empty",
    },
    {
      rule: "execution_transition_exists",
      pass: transitionExists,
      note: transitionExists
        ? `executionTransitionId=${transitionRecord.executionTransitionId}`
        : "transitionRecord.executionTransitionId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "mutation_switch_bound_to_guarded_enable",
      pass: switchBound,
      note: switchBound
        ? `mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId (${guardedWriteEnableRecord.guardedWriteEnableId})`
        : `mutation-switch/guarded-enable mismatch: switch.guardedWriteEnableId=${mutationSwitchRecord.guardedWriteEnableId} vs guarded.guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`,
    },
    {
      rule: "guarded_enable_bound_to_bridge_open",
      pass: guardedBound,
      note: guardedBound
        ? `guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId (${bridgeOpenRecord.bridgeOpenId})`
        : `guarded-enable/bridge-open mismatch: guarded.bridgeOpenId=${guardedWriteEnableRecord.bridgeOpenId} vs bridgeOpen.bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`,
    },
    {
      rule: "bridge_open_bound_to_bridge",
      pass: bridgeOpenBound,
      note: bridgeOpenBound
        ? `bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId (${bridgeRecord.writeActivationBridgeId})`
        : `bridge-open/bridge mismatch: bridgeOpen.writeActivationBridgeId=${bridgeOpenRecord.writeActivationBridgeId} vs bridge.writeActivationBridgeId=${bridgeRecord.writeActivationBridgeId}`,
    },
    {
      rule: "bridge_bound_to_transition",
      pass: bridgeBound,
      note: bridgeBound
        ? `bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId (${transitionRecord.executionTransitionId})`
        : `bridge-transition mismatch: bridge.executionTransitionId=${bridgeRecord.executionTransitionId} vs transition.executionTransitionId=${transitionRecord.executionTransitionId}`,
    },
    {
      rule: "write_permission_still_disabled",
      pass: true,
      note: "writePermissionEnabled=false — compile-time literal; no write permission activation phase has opened the gate",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "permissionState=descriptor_write_permission_pending — output is a descriptor only; write permission gate is not yet live",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly PermissionCheck[]): readonly PermissionBlockedReason[] {
  const staticReasons: PermissionBlockedReason[] = [
    { code: "write_permission_disabled", reason: "writePermissionEnabled=false — compile-time literal; an explicit write permission activation phase must open the gate",                                                                          static: true },
    { code: "approval_required",         reason: "approvalRequired=true — explicit operator approval is required before the write permission gate can be opened",                                                                                   static: true },
    { code: "actual_writes_disabled",    reason: "actualWritesEnabled=false — compile-time literal across all 21 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, and mutation-switch layers", static: true },
  ];
  const dynamicReasons: PermissionBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedPermissionReference(
  input: CreateWritePermissionGateInput,
  rollbackChainValid: boolean,
): LinkedPermissionReference {
  const { mutationSwitchRecord, guardedWriteEnableRecord, bridgeOpenRecord, bridgeRecord } = input;
  return {
    mutationSwitchId:        mutationSwitchRecord.mutationSwitchId,
    guardedWriteEnableId:    guardedWriteEnableRecord.guardedWriteEnableId,
    bridgeOpenId:            bridgeOpenRecord.bridgeOpenId,
    writeActivationBridgeId: bridgeRecord.writeActivationBridgeId,
    rollbackSnapshotId:      mutationSwitchRecord.linkedMutationSwitchReference.rollbackSnapshotId,
    writePermissionPrepared: true,
    writePermissionEnabled:  false,
    mutationSwitchEnabled:   false,
    guardedWriteEnabled:     false,
    rollbackChainValid,
    referenceNote:           "linked permission reference sources rollbackSnapshotId from mutationSwitchRecord.linkedMutationSwitchReference; write permission disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createWritePermissionGateRecord(
  input: CreateWritePermissionGateInput,
): ActualSandboxWritePermissionGateRecord {
  const { mutationSwitchRecord, guardedWriteEnableRecord, bridgeOpenRecord, bridgeRecord, transitionRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = mutationSwitchRecord.mutationSwitchReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedPermissionReference(input, rollbackChainValid);

  const permissionReadinessReport: PermissionReadinessReport = {
    writePermissionPrepared:      true,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    bridgeOpenEnabled:            false,
    bridgeEnabled:                false,
    executionTransitionEnabled:   false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    summary: `permissionState=descriptor_write_permission_pending; writePermissionEnabled=false; mutationSwitchEnabled=false; guardedWriteEnabled=false; actualWritesEnabled=false; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: ActualSandboxWritePermissionGateRecord = {
    writePermissionGateId:        randomUUID(),
    permissionState:              "descriptor_write_permission_pending",
    approvalRequired:             true,
    writePermissionPrepared:      true,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    bridgeOpenEnabled:            false,
    bridgeEnabled:                false,
    executionTransitionEnabled:   false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    filesystemMutationBlocked:    true,
    motherCoreMutationBlocked:    true,
    vaultMutationBlocked:         true,
    shellBlocked:                 true,
    networkBlocked:               true,
    implementationPhase:          "descriptor_only",
    mutationSwitchId:             mutationSwitchRecord.mutationSwitchId,
    guardedWriteEnableId:         guardedWriteEnableRecord.guardedWriteEnableId,
    bridgeOpenId:                 bridgeOpenRecord.bridgeOpenId,
    writeActivationBridgeId:      bridgeRecord.writeActivationBridgeId,
    executionTransitionId:        transitionRecord.executionTransitionId,
    controlledExecutionId:        executionRecord.controlledExecutionId,
    permissionChecks:             checks,
    permissionBlockedReasons:     blockedReasons,
    permissionReadinessReport,
    linkedPermissionReference:    linkedRef,
    createdAt:                    new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listWritePermissionGateRecords(): readonly ActualSandboxWritePermissionGateRecord[] {
  return _store.slice();
}

export function getWritePermissionGateSummary(): ActualSandboxWritePermissionGateSummary {
  return {
    total:                         _store.length,
    byState:                       { descriptor_write_permission_pending: _store.length },
    writePermissionPrepared:       true,
    writePermissionEnabled:        false,
    mutationSwitchEnabled:         false,
    guardedWriteEnabled:           false,
    bridgeOpenEnabled:             false,
    bridgeEnabled:                 false,
    executionTransitionEnabled:    false,
    actualWritesEnabled:           false,
    realWritesEnabled:             false,
    approvalRequired:              true,
    filesystemMutationBlocked:     true,
    motherCoreMutationBlocked:     true,
    permissionState:               "descriptor_write_permission_pending",
    implementationPhase:           "descriptor_only",
  };
}
