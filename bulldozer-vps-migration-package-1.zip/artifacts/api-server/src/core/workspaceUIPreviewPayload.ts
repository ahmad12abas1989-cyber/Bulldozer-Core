// Workspace UI Preview Payload — Phase 134
// Renderer-safe preview payload aggregating all UI-layer systems.
// No rendering engines. No React. No HTML/CSS/JSX. No mutation paths.
// No persistence. No new subsystems. No health checks. No init().
// Sources: workspaceUIRenderModel, workspaceDashboardSkeleton,
//          workspaceUICoherence, healthMonitor, runtimeDependencyGraph.

import { getUIRenderModel }                from "./workspaceUIRenderModel";
import { getDashboardSkeleton }            from "./workspaceDashboardSkeleton";
import { getUICoherence }                  from "./workspaceUICoherence";
import { getFullHealth }                   from "./healthMonitor";
import { getRuntimeDependencyGraphStatus } from "./runtimeDependencyGraph";

const EXECUTION_BLOCKED: true = true;

// ---------------------------------------------------------------------------
// Type definitions
// ---------------------------------------------------------------------------

export interface ShellPreview {
  appName:         string;
  shellType:       string;
  shellMode:       string;
  sidebarEnabled:  boolean;
  topbarEnabled:   boolean;
  executionBlocked: true;
}

export interface NavigationPreviewGroup {
  groupId:          string;
  title:            string;
  itemCount:        number;
  executionBlocked: true;
}

export interface NavigationPreview {
  totalGroups:      number;
  groups:           NavigationPreviewGroup[];
  executionBlocked: true;
}

export interface PagePreviewEntry {
  pageId:           string;
  title:            string;
  panelCount:       number;
  widgetCount:      number;
  layoutStyle:      string;
  executionBlocked: true;
}

export interface PanelPreviewEntry {
  panelId:          string;
  pageId:           string;
  widgetCount:      number;
  cardStyle:        string;
  layoutDirection:  string;
  executionBlocked: true;
}

export interface WidgetPreviewEntry {
  widgetId:         string;
  widgetType:       string;
  renderHint:       string;
  size:             string;
  priority:         number;
  sourceEndpoint:   string;
  executionBlocked: true;
}

export interface PreviewResponsiveBreakpoint {
  minWidth:         string;
  columns:          number;
  sidebarVisible:   boolean;
  executionBlocked: true;
}

export interface ResponsivePreview {
  desktop:          PreviewResponsiveBreakpoint;
  tablet:           PreviewResponsiveBreakpoint;
  mobile:           PreviewResponsiveBreakpoint;
  collapseBehavior: string;
  maxColumns:       number;
  executionBlocked: true;
}

export interface PreviewHealthSummary {
  allLayersCoherent:       boolean;
  bindingCoveragePercent:  number;
  diagnosticsHealthy:      boolean;
  graphHealthy:            boolean;
  executionBlocked:        true;
}

export interface UIPreviewPayload {
  generatedAt:       string;
  previewVersion:    string;
  uiVersion:         string;
  dashboardVersion:  string;
  shellPreview:      ShellPreview;
  navigationPreview: NavigationPreview;
  pagePreview:       PagePreviewEntry[];
  panelPreview:      PanelPreviewEntry[];
  widgetPreview:     WidgetPreviewEntry[];
  responsivePreview: ResponsivePreview;
  healthSummary:     PreviewHealthSummary;
  executionBlocked:  true;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function projectBreakpoint(bp: { minWidth: string; columns: number; sidebarVisible: boolean }): PreviewResponsiveBreakpoint {
  return {
    minWidth:         bp.minWidth,
    columns:          bp.columns,
    sidebarVisible:   bp.sidebarVisible,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
// All derivations are read-only aggregations from existing modules.
// No HTML, no CSS, no JSX, no rendering engines, no mutation paths.
// pagePreview[] — ordered by skeleton.pageLayouts order (intentional page order).
// panelPreview[] — sorted alphabetically by panelId (stable, bounded: 15 entries).
// widgetPreview[] — sorted alphabetically by widgetId (stable, bounded: 37 entries).
// navigationPreview.groups[] — ordered by groupOrder (ascending) then groupId.
// executionBlocked: true on every nested object.

export function getUIPreviewPayload(): UIPreviewPayload {
  const renderModel = getUIRenderModel();
  const skeleton    = getDashboardSkeleton();
  const coherence   = getUICoherence();
  const health      = getFullHealth();
  const graphStatus = getRuntimeDependencyGraphStatus();

  // --- shellPreview ---
  const shellPreview: ShellPreview = {
    appName:          renderModel.layout.appName,
    shellType:        renderModel.layout.shellType,
    shellMode:        skeleton.shell.shellMode,
    sidebarEnabled:   renderModel.layout.sidebarEnabled,
    topbarEnabled:    renderModel.layout.topbarEnabled,
    executionBlocked: EXECUTION_BLOCKED,
  };

  // --- navigationPreview ---
  const navGroups: NavigationPreviewGroup[] = renderModel.navigation.groups
    .slice()
    .sort((a, b) => a.groupOrder - b.groupOrder || a.groupId.localeCompare(b.groupId))
    .map((g) => ({
      groupId:          g.groupId,
      title:            g.title,
      itemCount:        g.items.length,
      executionBlocked: EXECUTION_BLOCKED,
    }));

  const navigationPreview: NavigationPreview = {
    totalGroups:      renderModel.navigation.totalGroups,
    groups:           navGroups,
    executionBlocked: EXECUTION_BLOCKED,
  };

  // --- widgetLayout priority lookup: widgetId → priority ---
  const widgetPriorityMap = new Map<string, number>(
    skeleton.widgetLayouts.map((wl) => [wl.widgetId, wl.priority]),
  );

  // --- widgetLayout pageId count per page ---
  const pageWidgetCountMap = new Map<string, number>();
  for (const wl of skeleton.widgetLayouts) {
    pageWidgetCountMap.set(wl.pageId, (pageWidgetCountMap.get(wl.pageId) ?? 0) + 1);
  }

  // --- pagePreview[] — ordered by skeleton.pageLayouts (intentional page order) ---
  const pagePreview: PagePreviewEntry[] = skeleton.pageLayouts.map((pl) => ({
    pageId:           pl.pageId,
    title:            pl.pageTitle,
    panelCount:       pl.panelIds.length,
    widgetCount:      pageWidgetCountMap.get(pl.pageId) ?? 0,
    layoutStyle:      pl.layoutStyle,
    executionBlocked: EXECUTION_BLOCKED,
  }));

  // --- panelPreview[] — alphabetical by panelId (15 entries) ---
  const panelPreview: PanelPreviewEntry[] = skeleton.panelLayouts
    .slice()
    .sort((a, b) => a.panelId.localeCompare(b.panelId))
    .map((pl) => ({
      panelId:          pl.panelId,
      pageId:           pl.pageId,
      widgetCount:      pl.widgetIds.length,
      cardStyle:        pl.cardStyle,
      layoutDirection:  pl.layoutDirection,
      executionBlocked: EXECUTION_BLOCKED,
    }));

  // --- widgetPreview[] — alphabetical by widgetId (37 entries) ---
  const widgetPreview: WidgetPreviewEntry[] = renderModel.widgets
    .slice()
    .sort((a, b) => a.widgetId.localeCompare(b.widgetId))
    .map((w) => ({
      widgetId:         w.widgetId,
      widgetType:       w.widgetType,
      renderHint:       w.renderHint,
      size:             w.size,
      priority:         widgetPriorityMap.get(w.widgetId) ?? 0,
      sourceEndpoint:   w.sourceEndpoint,
      executionBlocked: EXECUTION_BLOCKED,
    }));

  // --- responsivePreview ---
  const rr = skeleton.responsiveRules;
  const responsivePreview: ResponsivePreview = {
    desktop:          projectBreakpoint(rr.desktop),
    tablet:           projectBreakpoint(rr.tablet),
    mobile:           projectBreakpoint(rr.mobile),
    collapseBehavior: rr.collapseBehavior,
    maxColumns:       rr.maxColumns,
    executionBlocked: EXECUTION_BLOCKED,
  };

  // --- healthSummary ---
  const allLayersCoherent =
    coherence.allWidgetsCoherent &&
    coherence.allPanelsCoherent  &&
    coherence.allPagesCoherent;

  const healthSummary: PreviewHealthSummary = {
    allLayersCoherent,
    bindingCoveragePercent:  coherence.bindingCoverage.coveragePercent,
    diagnosticsHealthy:      health.status !== "unhealthy",
    graphHealthy:            !graphStatus.hasCycles,
    executionBlocked:        EXECUTION_BLOCKED,
  };

  return {
    generatedAt:       new Date().toISOString(),
    previewVersion:    "1",
    uiVersion:         renderModel.uiVersion,
    dashboardVersion:  skeleton.dashboardVersion,
    shellPreview,
    navigationPreview,
    pagePreview,
    panelPreview,
    widgetPreview,
    responsivePreview,
    healthSummary,
    executionBlocked:  EXECUTION_BLOCKED,
  };
}
