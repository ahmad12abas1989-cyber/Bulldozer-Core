// workspaceUIPages.ts
// Phase 138 — UI Page Manifest
// Pure derivation from getUIRenderModel().pages + getDashboardSkeleton().pageLayouts.
// No init. No persistence. No subsystem. No health check.
// No HTML/CSS/frontend framework code. executionBlocked always true.

import { getUIRenderModel } from "./workspaceUIRenderModel";
import { getDashboardSkeleton } from "./workspaceDashboardSkeleton";

// ── Types ──────────────────────────────────────────────────────────────────

export interface UIPageEntry {
  readonly pageId: string;
  readonly title: string;
  readonly route: string;
  readonly sectionIds: readonly string[];
  readonly description: string;
  readonly panelCount: number;
  readonly executionBlocked: true;
}

export interface UIPageManifest {
  readonly generatedAt: string;
  readonly totalPages: number;
  readonly pages: readonly UIPageEntry[];
  readonly executionBlocked: true;
}

// ── Public API ─────────────────────────────────────────────────────────────

export function getUIPageManifest(): UIPageManifest {
  const renderModel = getUIRenderModel();
  const skeleton = getDashboardSkeleton();

  // Build panelCount lookup from skeleton pageLayouts — O(5)
  const panelCountMap = new Map<string, number>();
  for (const pl of skeleton.pageLayouts) {
    panelCountMap.set(pl.pageId, pl.panelIds.length);
  }

  // Sort render model pages by pageOrder ascending — O(5 log 5)
  const pages: UIPageEntry[] = (renderModel.pages as readonly {
    pageId: string;
    title: string;
    route: string;
    sectionIds: readonly string[];
    description: string;
    pageOrder: number;
    executionBlocked: true;
  }[])
    .slice()
    .sort((a, b) => a.pageOrder - b.pageOrder)
    .map((p) => ({
      pageId: p.pageId,
      title: p.title,
      route: p.route,
      sectionIds: p.sectionIds,
      description: p.description,
      panelCount: panelCountMap.get(p.pageId) ?? 0,
      executionBlocked: true as const,
    }));

  return {
    generatedAt: new Date().toISOString(),
    totalPages: pages.length,
    pages,
    executionBlocked: true,
  };
}
