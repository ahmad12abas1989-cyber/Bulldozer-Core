// firstControlledFilesystemMutationApprovalCore.ts
// Phase 346 — First Controlled Filesystem Mutation Approval Descriptor Core Skeleton
// In-memory first controlled filesystem mutation approval descriptor engine.
// Layer 37 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply + mutation-surface +
//   filesystem-mutation-enablement + filesystem-mutation-gate +
//   filesystem-mutation-permit + filesystem-mutation-authorization stack.
// Defines the first controlled filesystem mutation approval descriptor.
// Binds approval to filesystem mutation authorization and to permit/gate/enablement/surface chain.
// Preserves sandbox-approved-only target scope from layers 24–36 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem mutation. No shell execution. No network access.
// No vault access. No Mother Core mutation.
// filesystemMutationApprovalGranted=false — approval has not been granted.
// filesystemMutationApprovalPrepared=true — descriptor-readiness established for a future
//   first controlled filesystem mutation approval grant phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstControlledFilesystemMutationAuthorizationRecord } from "./firstControlledFilesystemMutationAuthorizationCore.js";
import type { FirstControlledFilesystemMutationPermitRecord }        from "./firstControlledFilesystemMutationPermitCore.js";
import type { FirstControlledFilesystemMutationGateRecord }          from "./firstControlledFilesystemMutationGateCore.js";
import type { ControlledFilesystemMutationEnablementRecord }         from "./controlledFilesystemMutationEnablementCore.js";
import type { FirstActualSandboxMutationSurfaceRecord }              from "./firstActualSandboxMutationSurfaceCore.js";
import type { ControlledExecutionRecord }                            from "./controlledExecutionCore.js";
import { randomUUID }                                                from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FilesystemMutationApprovalState =
  "descriptor_filesystem_mutation_approval_pending";

export type FilesystemMutationApprovalCheckRule =
  | "filesystem_mutation_authorization_exists"
  | "filesystem_mutation_permit_exists"
  | "filesystem_mutation_gate_exists"
  | "filesystem_mutation_enablement_exists"
  | "mutation_surface_exists"
  | "execution_record_exists"
  | "filesystem_mutation_authorization_bound_to_permit"
  | "filesystem_mutation_permit_bound_to_gate"
  | "filesystem_mutation_gate_bound_to_enablement"
  | "filesystem_mutation_enablement_bound_to_surface"
  | "filesystem_mutation_approval_not_granted"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface FilesystemMutationApprovalCheck {
  readonly rule: FilesystemMutationApprovalCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface FilesystemMutationApprovalBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface FilesystemMutationApprovalPlanEntry {
  readonly entryId:                          string;
  readonly operationType:                    "descriptor_filesystem_mutation_approval_planned";
  readonly targetScope:                      "sandbox_approved_only";
  readonly filesystemMutationApprovalGranted: false;
  readonly mutationBlocked:                  true;
  readonly note:                             string;
}

export interface LinkedFilesystemMutationApprovalReference {
  readonly filesystemMutationAuthorizationId: string;
  readonly filesystemMutationPermitId:        string;
  readonly filesystemMutationGateId:          string;
  readonly filesystemMutationEnablementId:    string;
  readonly rollbackSnapshotId:                string;
  readonly filesystemMutationApprovalPrepared: true;
  readonly filesystemMutationApprovalGranted:  false;
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly filesystemMutationPermitEnabled:    false;
  readonly filesystemMutationGateEnabled:      false;
  readonly filesystemMutationEnablementEnabled: false;
  readonly mutationSurfaceEnabled:             false;
  readonly actualWritesEnabled:                false;
  readonly rollbackChainValid:                 boolean;
  readonly referenceNote:                      string;
}

export interface FilesystemMutationApprovalReadinessReport {
  readonly filesystemMutationApprovalPrepared:     true;
  readonly filesystemMutationApprovalGranted:      false;
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly filesystemMutationPermitEnabled:        false;
  readonly filesystemMutationGateEnabled:          false;
  readonly filesystemMutationEnablementEnabled:    false;
  readonly mutationSurfaceEnabled:                 false;
  readonly mutationApplyEnabled:                   false;
  readonly mutationCommitEnabled:                  false;
  readonly mutationExecutorEnabled:                false;
  readonly commitExecutionGateEnabled:             false;
  readonly sandboxWriteCommitEnabled:              false;
  readonly runtimeWriteExecutorEnabled:            false;
  readonly writeExecutionGateEnabled:              false;
  readonly scopedActivationEnabled:                false;
  readonly writePermissionEnabled:                 false;
  readonly mutationSwitchEnabled:                  false;
  readonly guardedWriteEnabled:                    false;
  readonly actualWritesEnabled:                    false;
  readonly realWritesEnabled:                      false;
  readonly approvalRequired:                       true;
  readonly allChecksPass:                          boolean;
  readonly blockedReasonCount:                     number;
  readonly rollbackChainValid:                     boolean;
  readonly targetScope:                            "sandbox_approved_only";
  readonly summary:                                string;
}

export interface FirstControlledFilesystemMutationApprovalRecord {
  readonly filesystemMutationApprovalId:             string;
  readonly filesystemMutationApprovalState:          FilesystemMutationApprovalState;
  readonly approvalRequired:                         true;
  readonly filesystemMutationApprovalPrepared:       true;
  readonly filesystemMutationApprovalGranted:        false;
  readonly filesystemMutationAuthorizationEnabled:   false;
  readonly filesystemMutationPermitEnabled:          false;
  readonly filesystemMutationGateEnabled:            false;
  readonly filesystemMutationEnablementEnabled:      false;
  readonly mutationSurfaceEnabled:                   false;
  readonly actualWritesEnabled:                      false;
  readonly filesystemMutationBlocked:                true;
  readonly motherCoreMutationBlocked:                true;
  readonly vaultMutationBlocked:                     true;
  readonly shellBlocked:                             true;
  readonly networkBlocked:                           true;
  readonly targetScope:                              "sandbox_approved_only";
  readonly implementationPhase:                      "descriptor_only";
  readonly filesystemMutationAuthorizationId:        string;
  readonly filesystemMutationPermitId:               string;
  readonly filesystemMutationGateId:                 string;
  readonly filesystemMutationEnablementId:           string;
  readonly mutationSurfaceId:                        string;
  readonly controlledExecutionId:                    string;
  readonly filesystemMutationApprovalPlan:           readonly FilesystemMutationApprovalPlanEntry[];
  readonly filesystemMutationApprovalChecks:         readonly FilesystemMutationApprovalCheck[];
  readonly filesystemMutationApprovalBlockedReasons: readonly FilesystemMutationApprovalBlockedReason[];
  readonly filesystemMutationApprovalReadinessReport: FilesystemMutationApprovalReadinessReport;
  readonly linkedFilesystemMutationApprovalReference: LinkedFilesystemMutationApprovalReference;
  readonly createdAt:                                string;
}

export interface CreateFirstControlledFilesystemMutationApprovalInput {
  readonly authorizationRecord:   FirstControlledFilesystemMutationAuthorizationRecord;
  readonly permitRecord:          FirstControlledFilesystemMutationPermitRecord;
  readonly gateRecord:            FirstControlledFilesystemMutationGateRecord;
  readonly enablementRecord:      ControlledFilesystemMutationEnablementRecord;
  readonly mutationSurfaceRecord: FirstActualSandboxMutationSurfaceRecord;
  readonly executionRecord:       ControlledExecutionRecord;
}

export interface FirstControlledFilesystemMutationApprovalSummary {
  readonly total:                                    number;
  readonly byState:                                  Record<FilesystemMutationApprovalState, number>;
  readonly filesystemMutationApprovalPrepared:       true;
  readonly filesystemMutationApprovalGranted:        false;
  readonly filesystemMutationAuthorizationEnabled:   false;
  readonly filesystemMutationPermitEnabled:          false;
  readonly filesystemMutationGateEnabled:            false;
  readonly filesystemMutationEnablementEnabled:      false;
  readonly mutationSurfaceEnabled:                   false;
  readonly actualWritesEnabled:                      false;
  readonly approvalRequired:                         true;
  readonly filesystemMutationBlocked:                true;
  readonly motherCoreMutationBlocked:                true;
  readonly targetScope:                              "sandbox_approved_only";
  readonly filesystemMutationApprovalState:          FilesystemMutationApprovalState;
  readonly implementationPhase:                      "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstControlledFilesystemMutationApprovalRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstControlledFilesystemMutationApprovalInput,
): readonly FilesystemMutationApprovalCheck[] {
  const { authorizationRecord, permitRecord, gateRecord, enablementRecord, mutationSurfaceRecord, executionRecord } = input;

  const authorizationExists = authorizationRecord.filesystemMutationAuthorizationId.length > 0;
  const permitExists        = permitRecord.filesystemMutationPermitId.length > 0;
  const gateExists          = gateRecord.filesystemMutationGateId.length > 0;
  const enablementExists    = enablementRecord.filesystemMutationEnablementId.length > 0;
  const surfaceExists       = mutationSurfaceRecord.mutationSurfaceId.length > 0;
  const ctrlExists          = executionRecord.controlledExecutionId.length > 0;

  const authBound           = authorizationRecord.filesystemMutationPermitId === permitRecord.filesystemMutationPermitId;
  const permitBound         = permitRecord.filesystemMutationGateId === gateRecord.filesystemMutationGateId;
  const gateBound           = gateRecord.filesystemMutationEnablementId === enablementRecord.filesystemMutationEnablementId;
  const enablementBound     = enablementRecord.mutationSurfaceId === mutationSurfaceRecord.mutationSurfaceId;

  return [
    {
      rule: "filesystem_mutation_authorization_exists",
      pass: authorizationExists,
      note: authorizationExists
        ? `filesystemMutationAuthorizationId=${authorizationRecord.filesystemMutationAuthorizationId}`
        : "authorizationRecord.filesystemMutationAuthorizationId is empty",
    },
    {
      rule: "filesystem_mutation_permit_exists",
      pass: permitExists,
      note: permitExists
        ? `filesystemMutationPermitId=${permitRecord.filesystemMutationPermitId}`
        : "permitRecord.filesystemMutationPermitId is empty",
    },
    {
      rule: "filesystem_mutation_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `filesystemMutationGateId=${gateRecord.filesystemMutationGateId}`
        : "gateRecord.filesystemMutationGateId is empty",
    },
    {
      rule: "filesystem_mutation_enablement_exists",
      pass: enablementExists,
      note: enablementExists
        ? `filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`
        : "enablementRecord.filesystemMutationEnablementId is empty",
    },
    {
      rule: "mutation_surface_exists",
      pass: surfaceExists,
      note: surfaceExists
        ? `mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`
        : "mutationSurfaceRecord.mutationSurfaceId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "filesystem_mutation_authorization_bound_to_permit",
      pass: authBound,
      note: authBound
        ? `authorizationRecord.filesystemMutationPermitId === permitRecord.filesystemMutationPermitId (${permitRecord.filesystemMutationPermitId})`
        : `authorization/permit mismatch: authorization.filesystemMutationPermitId=${authorizationRecord.filesystemMutationPermitId} vs permit.filesystemMutationPermitId=${permitRecord.filesystemMutationPermitId}`,
    },
    {
      rule: "filesystem_mutation_permit_bound_to_gate",
      pass: permitBound,
      note: permitBound
        ? `permitRecord.filesystemMutationGateId === gateRecord.filesystemMutationGateId (${gateRecord.filesystemMutationGateId})`
        : `permit/gate mismatch: permit.filesystemMutationGateId=${permitRecord.filesystemMutationGateId} vs gate.filesystemMutationGateId=${gateRecord.filesystemMutationGateId}`,
    },
    {
      rule: "filesystem_mutation_gate_bound_to_enablement",
      pass: gateBound,
      note: gateBound
        ? `gateRecord.filesystemMutationEnablementId === enablementRecord.filesystemMutationEnablementId (${enablementRecord.filesystemMutationEnablementId})`
        : `gate/enablement mismatch: gate.filesystemMutationEnablementId=${gateRecord.filesystemMutationEnablementId} vs enablement.filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`,
    },
    {
      rule: "filesystem_mutation_enablement_bound_to_surface",
      pass: enablementBound,
      note: enablementBound
        ? `enablementRecord.mutationSurfaceId === mutationSurfaceRecord.mutationSurfaceId (${mutationSurfaceRecord.mutationSurfaceId})`
        : `enablement/surface mismatch: enablement.mutationSurfaceId=${enablementRecord.mutationSurfaceId} vs surface.mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`,
    },
    {
      rule: "filesystem_mutation_approval_not_granted",
      pass: true,
      note: "filesystemMutationApprovalGranted=false — compile-time literal; no filesystem mutation approval grant phase has been started; approval remains pending",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "filesystemMutationApprovalState=descriptor_filesystem_mutation_approval_pending — output is a descriptor only; filesystem mutation approval is not yet granted",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly FilesystemMutationApprovalCheck[],
): readonly FilesystemMutationApprovalBlockedReason[] {
  const staticReasons: FilesystemMutationApprovalBlockedReason[] = [
    { code: "filesystem_mutation_approval_not_granted", reason: "filesystemMutationApprovalGranted=false — compile-time literal; an explicit first controlled filesystem mutation approval grant phase must grant approval before any sandbox target can receive filesystem writes",                                                                                                                                                                                                                                                                                                                                                                             static: true },
    { code: "approval_required",                        reason: "approvalRequired=true — explicit operator approval is required before the filesystem mutation approval can be granted",                                                                                                                                                                                                                                                                                                                                                                                                                                                                          static: true },
    { code: "actual_writes_disabled",                   reason: "actualWritesEnabled=false — compile-time literal across all 37 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, mutation-apply, mutation-surface, filesystem-mutation-enablement, filesystem-mutation-gate, filesystem-mutation-permit, and filesystem-mutation-authorization layers", static: true },
  ];
  const dynamicReasons: FilesystemMutationApprovalBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedApprovalReference(
  input: CreateFirstControlledFilesystemMutationApprovalInput,
  rollbackChainValid: boolean,
): LinkedFilesystemMutationApprovalReference {
  const { authorizationRecord, permitRecord, gateRecord, enablementRecord } = input;
  return {
    filesystemMutationAuthorizationId:    authorizationRecord.filesystemMutationAuthorizationId,
    filesystemMutationPermitId:           permitRecord.filesystemMutationPermitId,
    filesystemMutationGateId:             gateRecord.filesystemMutationGateId,
    filesystemMutationEnablementId:       enablementRecord.filesystemMutationEnablementId,
    rollbackSnapshotId:                   authorizationRecord.linkedFilesystemMutationAuthorizationReference.rollbackSnapshotId,
    filesystemMutationApprovalPrepared:   true,
    filesystemMutationApprovalGranted:    false,
    filesystemMutationAuthorizationEnabled: false,
    filesystemMutationPermitEnabled:      false,
    filesystemMutationGateEnabled:        false,
    filesystemMutationEnablementEnabled:  false,
    mutationSurfaceEnabled:               false,
    actualWritesEnabled:                  false,
    rollbackChainValid,
    referenceNote: "linked filesystem mutation approval reference sources rollbackSnapshotId from authorizationRecord.linkedFilesystemMutationAuthorizationReference; filesystem mutation approval not granted; filesystem mutation authorization disabled; filesystem mutation permit disabled; filesystem mutation gate disabled; filesystem mutation enablement disabled; mutation surface disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstControlledFilesystemMutationApprovalRecord(
  input: CreateFirstControlledFilesystemMutationApprovalInput,
): FirstControlledFilesystemMutationApprovalRecord {
  const { authorizationRecord, permitRecord, gateRecord, enablementRecord, mutationSurfaceRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = authorizationRecord.filesystemMutationAuthorizationReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedApprovalReference(input, rollbackChainValid);

  const filesystemMutationApprovalPlan: FilesystemMutationApprovalPlanEntry[] = [
    {
      entryId:                            randomUUID(),
      operationType:                      "descriptor_filesystem_mutation_approval_planned",
      targetScope:                        "sandbox_approved_only",
      filesystemMutationApprovalGranted:  false,
      mutationBlocked:                    true,
      note:                               "filesystem mutation approval planned in descriptor-only mode; targetScope=sandbox_approved_only; filesystemMutationApprovalGranted=false; filesystemMutationBlocked=true; first controlled filesystem mutation approval grant phase required to grant",
    },
  ];

  const filesystemMutationApprovalReadinessReport: FilesystemMutationApprovalReadinessReport = {
    filesystemMutationApprovalPrepared:      true,
    filesystemMutationApprovalGranted:       false,
    filesystemMutationAuthorizationEnabled:  false,
    filesystemMutationPermitEnabled:         false,
    filesystemMutationGateEnabled:           false,
    filesystemMutationEnablementEnabled:     false,
    mutationSurfaceEnabled:                  false,
    mutationApplyEnabled:                    false,
    mutationCommitEnabled:                   false,
    mutationExecutorEnabled:                 false,
    commitExecutionGateEnabled:              false,
    sandboxWriteCommitEnabled:               false,
    runtimeWriteExecutorEnabled:             false,
    writeExecutionGateEnabled:               false,
    scopedActivationEnabled:                 false,
    writePermissionEnabled:                  false,
    mutationSwitchEnabled:                   false,
    guardedWriteEnabled:                     false,
    actualWritesEnabled:                     false,
    realWritesEnabled:                       false,
    approvalRequired:                        true,
    allChecksPass,
    blockedReasonCount:                      blockedReasons.length,
    rollbackChainValid,
    targetScope:                             "sandbox_approved_only",
    summary: `filesystemMutationApprovalState=descriptor_filesystem_mutation_approval_pending; filesystemMutationApprovalGranted=false; filesystemMutationAuthorizationEnabled=false; filesystemMutationPermitEnabled=false; filesystemMutationGateEnabled=false; filesystemMutationEnablementEnabled=false; mutationSurfaceEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstControlledFilesystemMutationApprovalRecord = {
    filesystemMutationApprovalId:               randomUUID(),
    filesystemMutationApprovalState:            "descriptor_filesystem_mutation_approval_pending",
    approvalRequired:                           true,
    filesystemMutationApprovalPrepared:         true,
    filesystemMutationApprovalGranted:          false,
    filesystemMutationAuthorizationEnabled:     false,
    filesystemMutationPermitEnabled:            false,
    filesystemMutationGateEnabled:              false,
    filesystemMutationEnablementEnabled:        false,
    mutationSurfaceEnabled:                     false,
    actualWritesEnabled:                        false,
    filesystemMutationBlocked:                  true,
    motherCoreMutationBlocked:                  true,
    vaultMutationBlocked:                       true,
    shellBlocked:                               true,
    networkBlocked:                             true,
    targetScope:                                "sandbox_approved_only",
    implementationPhase:                        "descriptor_only",
    filesystemMutationAuthorizationId:          authorizationRecord.filesystemMutationAuthorizationId,
    filesystemMutationPermitId:                 permitRecord.filesystemMutationPermitId,
    filesystemMutationGateId:                   gateRecord.filesystemMutationGateId,
    filesystemMutationEnablementId:             enablementRecord.filesystemMutationEnablementId,
    mutationSurfaceId:                          mutationSurfaceRecord.mutationSurfaceId,
    controlledExecutionId:                      executionRecord.controlledExecutionId,
    filesystemMutationApprovalPlan,
    filesystemMutationApprovalChecks:           checks,
    filesystemMutationApprovalBlockedReasons:   blockedReasons,
    filesystemMutationApprovalReadinessReport,
    linkedFilesystemMutationApprovalReference:  linkedRef,
    createdAt:                                  new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstControlledFilesystemMutationApprovalRecords(): readonly FirstControlledFilesystemMutationApprovalRecord[] {
  return _store.slice();
}

export function getFirstControlledFilesystemMutationApprovalSummary(): FirstControlledFilesystemMutationApprovalSummary {
  return {
    total:                                      _store.length,
    byState:                                    { descriptor_filesystem_mutation_approval_pending: _store.length },
    filesystemMutationApprovalPrepared:         true,
    filesystemMutationApprovalGranted:          false,
    filesystemMutationAuthorizationEnabled:     false,
    filesystemMutationPermitEnabled:            false,
    filesystemMutationGateEnabled:              false,
    filesystemMutationEnablementEnabled:        false,
    mutationSurfaceEnabled:                     false,
    actualWritesEnabled:                        false,
    approvalRequired:                           true,
    filesystemMutationBlocked:                  true,
    motherCoreMutationBlocked:                  true,
    targetScope:                                "sandbox_approved_only",
    filesystemMutationApprovalState:            "descriptor_filesystem_mutation_approval_pending",
    implementationPhase:                        "descriptor_only",
  };
}
