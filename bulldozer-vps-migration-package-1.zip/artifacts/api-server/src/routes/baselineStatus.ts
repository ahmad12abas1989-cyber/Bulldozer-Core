import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { getBaselineStatus } from "../core/baseline";

export function handleBaselineStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getBaselineStatus());
}
