import { createHash } from "node:crypto";
import {
  getPolicyComplianceLedger,
  type ComplianceLedgerEntry,
} from "./workspacePolicyComplianceLedger";

const EXECUTION_BLOCKED: true = true;

// Band thresholds — identical to heatmap/trend
const HOT_MIN = 10;
const WARM_MIN = 1;

// Exposure score weights (inverse-risk: well-observed = full credit, rarely = half, unobserved = none)
const WEIGHT_WELL = 1.0;
const WEIGHT_RARELY = 0.5;
const WEIGHT_UNOBSERVED = 0.0;

// Grade thresholds (identical to governance scorecard)
const GRADE_A = 90;
const GRADE_B = 75;
const GRADE_C = 60;
const GRADE_D = 45;

// --- Types ---

export type WriteRiskLevel =
  | "unobserved_write"
  | "rarely_observed_write"
  | "well_observed_write";

export type ExposureGrade = "A" | "B" | "C" | "D" | "F";

export interface ExposureIndexEntry {
  method: string;
  path: string;
  permission: string;
  minimumRole: string;
  observationCount: number;
  riskLevel: WriteRiskLevel;
  allowedCount: number;
  deniedCount: number;
  lastObservedAt: string | null;
  firstObservedAt: string | null;
  executionBlocked: true;
}

export interface ExposureWriteRef {
  method: string;
  path: string;
  permission: string;
  minimumRole: string;
  observationCount: number;
  riskLevel: WriteRiskLevel;
  executionBlocked: true;
}

export interface ExposureIndexSummary {
  totalWritePolicies: number;
  unobservedWritePolicies: number;
  rarelyObservedWritePolicies: number;
  wellObservedWritePolicies: number;
  exposureScore: number;
  exposureGrade: ExposureGrade;
  highestRiskPolicy: ExposureWriteRef | null;
  lowestRiskPolicy: ExposureWriteRef | null;
  executionBlocked: true;
}

export interface WorkspacePolicyExposureIndex {
  exposureId: string;
  generatedAt: string;
  summary: ExposureIndexSummary;
  entries: ExposureIndexEntry[];
  totalPoliciesScanned: number;
  auditEntriesScanned: number;
  executionBlocked: true;
}

// --- Internal helpers ---

function classifyRisk(observationCount: number): WriteRiskLevel {
  if (observationCount >= HOT_MIN) return "well_observed_write";
  if (observationCount >= WARM_MIN) return "rarely_observed_write";
  return "unobserved_write";
}

function deriveGrade(score: number): ExposureGrade {
  if (score >= GRADE_A) return "A";
  if (score >= GRADE_B) return "B";
  if (score >= GRADE_C) return "C";
  if (score >= GRADE_D) return "D";
  return "F";
}

function computeExposureScore(
  wellCount: number,
  rarelyCount: number,
  unobservedCount: number,
): number {
  const total = wellCount + rarelyCount + unobservedCount;
  if (total === 0) return 100; // No write surface — vacuous compliance
  const weighted =
    wellCount * WEIGHT_WELL +
    rarelyCount * WEIGHT_RARELY +
    unobservedCount * WEIGHT_UNOBSERVED;
  return Math.min(100, Math.round((weighted / total) * 100));
}

function toEntry(ledgerEntry: ComplianceLedgerEntry): ExposureIndexEntry {
  return {
    method: ledgerEntry.method,
    path: ledgerEntry.path,
    permission: ledgerEntry.permission,
    minimumRole: ledgerEntry.minimumRole,
    observationCount: ledgerEntry.observationCount,
    riskLevel: classifyRisk(ledgerEntry.observationCount),
    allowedCount: ledgerEntry.allowedCount,
    deniedCount: ledgerEntry.deniedCount,
    lastObservedAt: ledgerEntry.lastObservedAt,
    firstObservedAt: ledgerEntry.firstObservedAt,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function entryKey(method: string, path: string): string {
  return `${method}:${path}`;
}

function sortEntries(entries: ExposureIndexEntry[]): ExposureIndexEntry[] {
  const unobserved = entries
    .filter((e) => e.riskLevel === "unobserved_write")
    .sort((a, b) =>
      entryKey(a.method, a.path).localeCompare(entryKey(b.method, b.path)),
    );

  const rarely = entries
    .filter((e) => e.riskLevel === "rarely_observed_write")
    .sort((a, b) => {
      if (a.observationCount !== b.observationCount) {
        return a.observationCount - b.observationCount; // Ascending: least observed = highest risk first
      }
      return entryKey(a.method, a.path).localeCompare(
        entryKey(b.method, b.path),
      );
    });

  const well = entries
    .filter((e) => e.riskLevel === "well_observed_write")
    .sort((a, b) => {
      if (a.observationCount !== b.observationCount) {
        return a.observationCount - b.observationCount; // Ascending: least observed first
      }
      return entryKey(a.method, a.path).localeCompare(
        entryKey(b.method, b.path),
      );
    });

  return [...unobserved, ...rarely, ...well];
}

function toRef(entry: ExposureIndexEntry): ExposureWriteRef {
  return {
    method: entry.method,
    path: entry.path,
    permission: entry.permission,
    minimumRole: entry.minimumRole,
    observationCount: entry.observationCount,
    riskLevel: entry.riskLevel,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function findHighestRisk(entries: ExposureIndexEntry[]): ExposureWriteRef | null {
  // Highest risk = lowest observationCount, tie-break method:path ASC
  let best: ExposureIndexEntry | null = null;
  for (const e of entries) {
    if (
      best === null ||
      e.observationCount < best.observationCount ||
      (e.observationCount === best.observationCount &&
        entryKey(e.method, e.path) < entryKey(best.method, best.path))
    ) {
      best = e;
    }
  }
  return best !== null ? toRef(best) : null;
}

function findLowestRisk(entries: ExposureIndexEntry[]): ExposureWriteRef | null {
  // Lowest risk = highest observationCount, tie-break method:path ASC
  let best: ExposureIndexEntry | null = null;
  for (const e of entries) {
    if (
      best === null ||
      e.observationCount > best.observationCount ||
      (e.observationCount === best.observationCount &&
        entryKey(e.method, e.path) < entryKey(best.method, best.path))
    ) {
      best = e;
    }
  }
  return best !== null ? toRef(best) : null;
}

// --- Public API ---

export function getWorkspacePolicyExposureIndex(): WorkspacePolicyExposureIndex {
  const generatedAt = new Date().toISOString();
  const exposureId = createHash("sha256")
    .update(generatedAt)
    .digest("hex")
    .slice(0, 16);

  const ledger = getPolicyComplianceLedger();
  const allEntries = ledger.entries;
  const totalPoliciesScanned = allEntries.length;

  // Filter to write policies only
  const writeEntries = allEntries
    .filter((e) => e.isWritePolicy)
    .map(toEntry);

  const sorted = sortEntries(writeEntries);

  const unobservedCount = sorted.filter(
    (e) => e.riskLevel === "unobserved_write",
  ).length;
  const rarelyCount = sorted.filter(
    (e) => e.riskLevel === "rarely_observed_write",
  ).length;
  const wellCount = sorted.filter(
    (e) => e.riskLevel === "well_observed_write",
  ).length;

  const exposureScore = computeExposureScore(wellCount, rarelyCount, unobservedCount);
  const exposureGrade = deriveGrade(exposureScore);

  const summary: ExposureIndexSummary = {
    totalWritePolicies: sorted.length,
    unobservedWritePolicies: unobservedCount,
    rarelyObservedWritePolicies: rarelyCount,
    wellObservedWritePolicies: wellCount,
    exposureScore,
    exposureGrade,
    highestRiskPolicy: findHighestRisk(sorted),
    lowestRiskPolicy: findLowestRisk(sorted),
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    exposureId,
    generatedAt,
    summary,
    entries: sorted,
    totalPoliciesScanned,
    auditEntriesScanned: ledger.auditEntriesScanned,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
