// Dual Comparison Gateway — Phase 123
// Single-call aggregation of Governance Scorecard comparison and Observation Ledger comparison.
// Pure read-only aggregation layer — delegates entirely to existing comparison modules.
// No persistence mutation, no live recomputation, no rendering, no autonomous execution.

import {
  compareGovernanceScorecards,
  ScorecardComparisonResult,
  ScorecardComparisonNotFound,
} from "./workspaceGovernanceScorecardComparison";
import {
  compareObservationLedgerSnapshots,
  LedgerComparisonResult,
  LedgerComparisonNotFound,
} from "./workspaceObservationLedgerComparison";

const EXECUTION_BLOCKED: true = true;

// --- Types ---

export interface DualComparisonResult {
  generatedAt: string;
  scorecardComparison: ScorecardComparisonResult;
  ledgerComparison: LedgerComparisonResult;
  executionBlocked: true;
}

// Discriminated error union — returned as a value, never thrown.
export type DualComparisonError =
  | { error: "scorecard_not_found"; detail: ScorecardComparisonNotFound; scorecardFrom: number; scorecardTo: number }
  | { error: "ledger_not_found";    detail: LedgerComparisonNotFound;    ledgerFrom: number;    ledgerTo: number    }
  | { error: "both_not_found";      scorecard: ScorecardComparisonNotFound; ledger: LedgerComparisonNotFound; scorecardFrom: number; scorecardTo: number; ledgerFrom: number; ledgerTo: number };

// --- Public API ---

// Delegates to compareGovernanceScorecards() and compareObservationLedgerSnapshots().
// O(10)×2 + O(20)×2 bounded ring lookups — no I/O, no persistence mutation.
// Returns DualComparisonResult on success, DualComparisonError when any captureSeq is missing.
// Both comparisons are always attempted so the error response is maximally informative.
export function getDualComparison(
  scorecardFrom: number,
  scorecardTo: number,
  ledgerFrom: number,
  ledgerTo: number,
): DualComparisonResult | DualComparisonError {
  const scorecardResult = compareGovernanceScorecards(scorecardFrom, scorecardTo);
  const ledgerResult    = compareObservationLedgerSnapshots(ledgerFrom, ledgerTo);

  const scorecardFailed = "error" in scorecardResult;
  const ledgerFailed    = "error" in ledgerResult;

  if (scorecardFailed && ledgerFailed) {
    return {
      error: "both_not_found",
      scorecard: scorecardResult as ScorecardComparisonNotFound,
      ledger:    ledgerResult    as LedgerComparisonNotFound,
      scorecardFrom,
      scorecardTo,
      ledgerFrom,
      ledgerTo,
    };
  }

  if (scorecardFailed) {
    return {
      error: "scorecard_not_found",
      detail: scorecardResult as ScorecardComparisonNotFound,
      scorecardFrom,
      scorecardTo,
    };
  }

  if (ledgerFailed) {
    return {
      error: "ledger_not_found",
      detail: ledgerResult as LedgerComparisonNotFound,
      ledgerFrom,
      ledgerTo,
    };
  }

  return {
    generatedAt: new Date().toISOString(),
    scorecardComparison: scorecardResult as ScorecardComparisonResult,
    ledgerComparison:    ledgerResult    as LedgerComparisonResult,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
