import { getUINavigationManifest } from "./workspaceUINavigation.js";
import { getUIPageManifest }       from "./workspaceUIPages.js";
import { getUIPanelManifest }      from "./workspaceUIPanels.js";
import { getUIWidgetManifest }     from "./workspaceUIWidgets.js";
import { getUIBindingManifest }    from "./workspaceUIBindings.js";
import { getUIBadgeManifest }      from "./workspaceUIBadges.js";
import { getUIThemeManifest }      from "./workspaceUITheme.js";
import { getUILayoutManifest }     from "./workspaceUILayout.js";

export interface UIAuditCheck {
  layerId: string;
  endpoint: string;
  healthy: boolean;
  totalInvariantValid: boolean;
  executionBlocked: true;
}

export interface UILayerAudit {
  generatedAt: string;
  auditVersion: "1";
  layersChecked: number;
  allHealthy: boolean;
  checks: UIAuditCheck[];
  executionBlocked: true;
}

export function getUILayerAudit(): UILayerAudit {
  const nav    = getUINavigationManifest();
  const pages  = getUIPageManifest();
  const panels = getUIPanelManifest();
  const widgets = getUIWidgetManifest();
  const bindings = getUIBindingManifest();
  const badges = getUIBadgeManifest();
  const theme  = getUIThemeManifest();
  const layout = getUILayoutManifest();

  const checks: UIAuditCheck[] = [
    {
      layerId: "navigation",
      endpoint: "/api/workspace/ui/navigation",
      totalInvariantValid: nav.totalGroups === nav.groups.length,
      healthy: false, // set below
      executionBlocked: true,
    },
    {
      layerId: "pages",
      endpoint: "/api/workspace/ui/pages",
      totalInvariantValid: pages.totalPages === pages.pages.length,
      healthy: false,
      executionBlocked: true,
    },
    {
      layerId: "panels",
      endpoint: "/api/workspace/ui/panels",
      totalInvariantValid: panels.totalPanels === panels.panels.length,
      healthy: false,
      executionBlocked: true,
    },
    {
      layerId: "widgets",
      endpoint: "/api/workspace/ui/widgets",
      totalInvariantValid: widgets.totalWidgets === widgets.widgets.length,
      healthy: false,
      executionBlocked: true,
    },
    {
      layerId: "bindings",
      endpoint: "/api/workspace/ui/bindings",
      totalInvariantValid: bindings.totalBindings === bindings.bindings.length,
      healthy: false,
      executionBlocked: true,
    },
    {
      layerId: "badges",
      endpoint: "/api/workspace/ui/badges",
      totalInvariantValid: badges.totalBadges === badges.badges.length,
      healthy: false,
      executionBlocked: true,
    },
    {
      layerId: "theme",
      endpoint: "/api/workspace/ui/theme",
      totalInvariantValid: true, // scalar object — no array invariant
      healthy: false,
      executionBlocked: true,
    },
    {
      layerId: "layout",
      endpoint: "/api/workspace/ui/layout",
      totalInvariantValid: true, // scalar object — no array invariant
      healthy: false,
      executionBlocked: true,
    },
  ];

  for (const c of checks) {
    c.healthy = c.totalInvariantValid && c.executionBlocked === true;
  }

  const allHealthy = checks.every((c) => c.healthy);

  return {
    generatedAt: new Date().toISOString(),
    auditVersion: "1",
    layersChecked: checks.length,
    allHealthy,
    checks,
    executionBlocked: true,
  };
}
