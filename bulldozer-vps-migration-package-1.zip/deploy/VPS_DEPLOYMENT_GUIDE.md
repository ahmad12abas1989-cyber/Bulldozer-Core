# Bulldozer Mother Core — VPS Deployment Guide

> **Scope:** migration preparation only. This guide covers installation, configuration, and first-run verification on a fresh VPS. It does NOT activate filesystem mutations, enable actual writes, or change any sealed architecture.

---

## Prerequisites

| Requirement | Minimum |
|---|---|
| OS | Ubuntu 22.04 LTS / Debian 12 / any systemd distro |
| CPU | 1 vCPU |
| RAM | 512 MB (1 GB recommended) |
| Disk | 10 GB (+ storage growth for snapshots/audit logs) |
| Docker | 24.x or later |
| Docker Compose | v2.x (bundled with Docker Desktop / `docker compose` plugin) |
| Open ports | 8080 (or whichever HOST_PORT you choose) |
| Node.js | Not required on host — runs inside container |

---

## Step 1 — Install Docker

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# Log out and back in for the group to take effect
docker --version   # expect 24.x+
```

---

## Step 2 — Transfer the project to the VPS

Option A — Git clone (recommended):
```bash
git clone <your-repo-url> /opt/bulldozer/app
cd /opt/bulldozer/app
```

Option B — rsync from local machine:
```bash
rsync -avz --exclude node_modules --exclude .git \
  ./ user@your-vps-ip:/opt/bulldozer/app/
```

---

## Step 3 — Create persistent storage directory

```bash
sudo mkdir -p /opt/bulldozer/storage
sudo chown 1000:1000 /opt/bulldozer/storage

sudo mkdir -p /opt/bulldozer/backups
sudo chown $USER:$USER /opt/bulldozer/backups
```

Storage layout inside the container (mounted from `/opt/bulldozer/storage`):
```
storage/
├── snapshots/              # ring buffer, max 20 files
├── runtime-snapshots/      # active + archived
│   ├── active/
│   └── archived/
├── runtime-state/          # single atomic file
├── tasks/                  # task state, max 100 tasks
└── store/                  # key-value: audit-log, session-contexts, etc.
```

---

## Step 4 — Configure environment

```bash
cd /opt/bulldozer/app/deploy
cp .env.example .env
```

Edit `.env` — at minimum set:

```bash
# Generate a strong secret (minimum 64 hex chars)
openssl rand -hex 64

# Paste the output as SESSION_SECRET in .env
SESSION_SECRET=<output-from-above>

# Confirm paths
STORAGE_PATH=/opt/bulldozer/storage
BACKUP_DIR=/opt/bulldozer/backups
HOST_PORT=8080
```

**Never** commit `.env` to version control. Verify it is in `.gitignore`.

---

## Step 5 — Build the Docker image

From the project root:

```bash
cd /opt/bulldozer/app

docker build \
  --file deploy/Dockerfile \
  --tag bulldozer-core:latest \
  .
```

Expected build time: 60–120 seconds on first run (dependency install). Subsequent builds use layer cache.

---

## Step 6 — Start the server

```bash
cd /opt/bulldozer/app/deploy
chmod +x scripts/*.sh
./scripts/start.sh
```

The start script:
1. Validates `.env` is present and `SESSION_SECRET` is not the placeholder
2. Ensures the storage directory exists
3. Runs `docker compose up -d`
4. Waits 5 seconds and hits `/api/healthz` to confirm readiness

---

## Step 7 — Run the full health check suite

```bash
./scripts/health-check.sh
```

Expected output: all checks `PASS`, summary shows `0` failures.

Key invariants verified:
- `allHealthy=true`
- `cycleCount=0` (no dependency graph cycles)
- `routePolicyCount=162`
- `actualWritesEnabled=false` (Mother Core remains write-blocked)

---

## Step 8 — Configure a reverse proxy (recommended)

Use nginx or Caddy to terminate TLS and proxy to the container.

**Caddy (simplest — auto TLS via Let's Encrypt):**

```Caddyfile
your-domain.com {
    reverse_proxy localhost:8080
}
```

```bash
sudo apt install -y caddy
sudo systemctl enable --now caddy
```

**nginx:**

```nginx
server {
    listen 443 ssl;
    server_name your-domain.com;

    ssl_certificate     /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    location / {
        proxy_pass         http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
    }
}
```

---

## Step 9 — Set up automatic backups (optional but recommended)

```bash
# Run backup every day at 02:00 UTC
(crontab -l 2>/dev/null; echo "0 2 * * * /opt/bulldozer/app/deploy/scripts/backup.sh >> /var/log/bulldozer-backup.log 2>&1") | crontab -
```

---

## Step 10 — Verify container auto-restart on reboot

The `docker-compose.yml` already sets `restart: unless-stopped`. To confirm Docker itself starts on boot:

```bash
sudo systemctl enable docker
```

Test the full cycle:
```bash
sudo reboot
# After reboot:
./scripts/health-check.sh
```

---

## Updating the server (future releases)

```bash
# 1. Take a backup
./scripts/backup.sh

# 2. Pull latest code
git pull

# 3. Rebuild image
docker build --file deploy/Dockerfile --tag bulldozer-core:latest .

# 4. Restart
./scripts/stop.sh
./scripts/start.sh

# 5. Verify
./scripts/health-check.sh
```

---

## Firewall recommendations

```bash
# Allow SSH, HTTP, HTTPS; deny everything else
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw deny 8080/tcp   # only expose via reverse proxy, not directly
sudo ufw enable
```

---

## Key invariants to preserve on VPS

| Invariant | Value |
|---|---|
| Total endpoints | 162 |
| Access policies | 162 |
| Health checks | 38 |
| Registered subsystems | 27 |
| Dependency graph nodes | 27 (0 cycles) |
| `actualWritesEnabled` | **false** — compile-time literal |
| `filesystemMutationBlocked` | **true** — compile-time literal |
| Sealed core files | Never modify without explicit phase approval |

Mother Core mutation, shell execution, vault access, and autonomous execution remain blocked at all times. No operator action on the VPS can override compile-time literals in sealed cores.
