// firstControlledFilesystemMutationGrantCore.ts
// Phase 350 — First Controlled Filesystem Mutation Grant Descriptor Core Skeleton
// In-memory first controlled filesystem mutation grant descriptor engine.
// Layer 38 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply + mutation-surface +
//   filesystem-mutation-enablement + filesystem-mutation-gate +
//   filesystem-mutation-permit + filesystem-mutation-authorization +
//   filesystem-mutation-approval stack.
// Defines the first controlled filesystem mutation grant descriptor.
// Binds grant to filesystem mutation approval and to authorization/permit/gate/enablement chain.
// Preserves sandbox-approved-only target scope from layers 24–37 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem mutation. No shell execution. No network access.
// No vault access. No Mother Core mutation.
// filesystemMutationGrantEnabled=false — grant has not been enabled.
// filesystemMutationGrantPrepared=true — descriptor-readiness established for a future
//   first controlled filesystem mutation grant activation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstControlledFilesystemMutationApprovalRecord }      from "./firstControlledFilesystemMutationApprovalCore.js";
import type { FirstControlledFilesystemMutationAuthorizationRecord } from "./firstControlledFilesystemMutationAuthorizationCore.js";
import type { FirstControlledFilesystemMutationPermitRecord }        from "./firstControlledFilesystemMutationPermitCore.js";
import type { FirstControlledFilesystemMutationGateRecord }          from "./firstControlledFilesystemMutationGateCore.js";
import type { ControlledFilesystemMutationEnablementRecord }         from "./controlledFilesystemMutationEnablementCore.js";
import type { ControlledExecutionRecord }                            from "./controlledExecutionCore.js";
import { randomUUID }                                                from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FilesystemMutationGrantState =
  "descriptor_filesystem_mutation_grant_pending";

export type FilesystemMutationGrantCheckRule =
  | "filesystem_mutation_approval_exists"
  | "filesystem_mutation_authorization_exists"
  | "filesystem_mutation_permit_exists"
  | "filesystem_mutation_gate_exists"
  | "filesystem_mutation_enablement_exists"
  | "execution_record_exists"
  | "filesystem_mutation_approval_bound_to_authorization"
  | "filesystem_mutation_authorization_bound_to_permit"
  | "filesystem_mutation_permit_bound_to_gate"
  | "filesystem_mutation_gate_bound_to_enablement"
  | "filesystem_mutation_grant_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface FilesystemMutationGrantCheck {
  readonly rule: FilesystemMutationGrantCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface FilesystemMutationGrantBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface FilesystemMutationGrantPlanEntry {
  readonly entryId:                        string;
  readonly operationType:                  "descriptor_filesystem_mutation_grant_planned";
  readonly targetScope:                    "sandbox_approved_only";
  readonly filesystemMutationGrantEnabled: false;
  readonly mutationBlocked:                true;
  readonly note:                           string;
}

export interface LinkedFilesystemMutationGrantReference {
  readonly filesystemMutationApprovalId:      string;
  readonly filesystemMutationAuthorizationId: string;
  readonly filesystemMutationPermitId:        string;
  readonly filesystemMutationGateId:          string;
  readonly rollbackSnapshotId:                string;
  readonly filesystemMutationGrantPrepared:   true;
  readonly filesystemMutationGrantEnabled:    false;
  readonly filesystemMutationApprovalGranted: false;
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly filesystemMutationPermitEnabled:   false;
  readonly filesystemMutationGateEnabled:     false;
  readonly filesystemMutationEnablementEnabled: false;
  readonly actualWritesEnabled:               false;
  readonly rollbackChainValid:                boolean;
  readonly referenceNote:                     string;
}

export interface FilesystemMutationGrantReadinessReport {
  readonly filesystemMutationGrantPrepared:      true;
  readonly filesystemMutationGrantEnabled:       false;
  readonly filesystemMutationApprovalGranted:    false;
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly filesystemMutationPermitEnabled:      false;
  readonly filesystemMutationGateEnabled:        false;
  readonly filesystemMutationEnablementEnabled:  false;
  readonly mutationSurfaceEnabled:               false;
  readonly mutationApplyEnabled:                 false;
  readonly mutationCommitEnabled:                false;
  readonly mutationExecutorEnabled:              false;
  readonly commitExecutionGateEnabled:           false;
  readonly sandboxWriteCommitEnabled:            false;
  readonly runtimeWriteExecutorEnabled:          false;
  readonly writeExecutionGateEnabled:            false;
  readonly scopedActivationEnabled:              false;
  readonly writePermissionEnabled:               false;
  readonly mutationSwitchEnabled:                false;
  readonly guardedWriteEnabled:                  false;
  readonly actualWritesEnabled:                  false;
  readonly realWritesEnabled:                    false;
  readonly approvalRequired:                     true;
  readonly allChecksPass:                        boolean;
  readonly blockedReasonCount:                   number;
  readonly rollbackChainValid:                   boolean;
  readonly targetScope:                          "sandbox_approved_only";
  readonly summary:                              string;
}

export interface FirstControlledFilesystemMutationGrantRecord {
  readonly filesystemMutationGrantId:             string;
  readonly filesystemMutationGrantState:          FilesystemMutationGrantState;
  readonly approvalRequired:                      true;
  readonly filesystemMutationGrantPrepared:       true;
  readonly filesystemMutationGrantEnabled:        false;
  readonly filesystemMutationApprovalGranted:     false;
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly filesystemMutationPermitEnabled:       false;
  readonly filesystemMutationGateEnabled:         false;
  readonly filesystemMutationEnablementEnabled:   false;
  readonly actualWritesEnabled:                   false;
  readonly filesystemMutationBlocked:             true;
  readonly motherCoreMutationBlocked:             true;
  readonly vaultMutationBlocked:                  true;
  readonly shellBlocked:                          true;
  readonly networkBlocked:                        true;
  readonly targetScope:                           "sandbox_approved_only";
  readonly implementationPhase:                   "descriptor_only";
  readonly filesystemMutationApprovalId:          string;
  readonly filesystemMutationAuthorizationId:     string;
  readonly filesystemMutationPermitId:            string;
  readonly filesystemMutationGateId:              string;
  readonly filesystemMutationEnablementId:        string;
  readonly controlledExecutionId:                 string;
  readonly filesystemMutationGrantPlan:           readonly FilesystemMutationGrantPlanEntry[];
  readonly filesystemMutationGrantChecks:         readonly FilesystemMutationGrantCheck[];
  readonly filesystemMutationGrantBlockedReasons: readonly FilesystemMutationGrantBlockedReason[];
  readonly filesystemMutationGrantReadinessReport: FilesystemMutationGrantReadinessReport;
  readonly linkedFilesystemMutationGrantReference: LinkedFilesystemMutationGrantReference;
  readonly createdAt:                             string;
}

export interface CreateFirstControlledFilesystemMutationGrantInput {
  readonly approvalRecord:       FirstControlledFilesystemMutationApprovalRecord;
  readonly authorizationRecord:  FirstControlledFilesystemMutationAuthorizationRecord;
  readonly permitRecord:         FirstControlledFilesystemMutationPermitRecord;
  readonly gateRecord:           FirstControlledFilesystemMutationGateRecord;
  readonly enablementRecord:     ControlledFilesystemMutationEnablementRecord;
  readonly executionRecord:      ControlledExecutionRecord;
}

export interface FirstControlledFilesystemMutationGrantSummary {
  readonly total:                                  number;
  readonly byState:                                Record<FilesystemMutationGrantState, number>;
  readonly filesystemMutationGrantPrepared:        true;
  readonly filesystemMutationGrantEnabled:         false;
  readonly filesystemMutationApprovalGranted:      false;
  readonly filesystemMutationAuthorizationEnabled: false;
  readonly filesystemMutationPermitEnabled:        false;
  readonly filesystemMutationGateEnabled:          false;
  readonly filesystemMutationEnablementEnabled:    false;
  readonly actualWritesEnabled:                    false;
  readonly approvalRequired:                       true;
  readonly filesystemMutationBlocked:              true;
  readonly motherCoreMutationBlocked:              true;
  readonly targetScope:                            "sandbox_approved_only";
  readonly filesystemMutationGrantState:           FilesystemMutationGrantState;
  readonly implementationPhase:                    "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstControlledFilesystemMutationGrantRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstControlledFilesystemMutationGrantInput,
): readonly FilesystemMutationGrantCheck[] {
  const { approvalRecord, authorizationRecord, permitRecord, gateRecord, enablementRecord, executionRecord } = input;

  const approvalExists       = approvalRecord.filesystemMutationApprovalId.length > 0;
  const authorizationExists  = authorizationRecord.filesystemMutationAuthorizationId.length > 0;
  const permitExists         = permitRecord.filesystemMutationPermitId.length > 0;
  const gateExists           = gateRecord.filesystemMutationGateId.length > 0;
  const enablementExists     = enablementRecord.filesystemMutationEnablementId.length > 0;
  const ctrlExists           = executionRecord.controlledExecutionId.length > 0;

  const approvalBound        = approvalRecord.filesystemMutationAuthorizationId === authorizationRecord.filesystemMutationAuthorizationId;
  const authorizationBound   = authorizationRecord.filesystemMutationPermitId === permitRecord.filesystemMutationPermitId;
  const permitBound          = permitRecord.filesystemMutationGateId === gateRecord.filesystemMutationGateId;
  const gateBound            = gateRecord.filesystemMutationEnablementId === enablementRecord.filesystemMutationEnablementId;

  return [
    {
      rule: "filesystem_mutation_approval_exists",
      pass: approvalExists,
      note: approvalExists
        ? `filesystemMutationApprovalId=${approvalRecord.filesystemMutationApprovalId}`
        : "approvalRecord.filesystemMutationApprovalId is empty",
    },
    {
      rule: "filesystem_mutation_authorization_exists",
      pass: authorizationExists,
      note: authorizationExists
        ? `filesystemMutationAuthorizationId=${authorizationRecord.filesystemMutationAuthorizationId}`
        : "authorizationRecord.filesystemMutationAuthorizationId is empty",
    },
    {
      rule: "filesystem_mutation_permit_exists",
      pass: permitExists,
      note: permitExists
        ? `filesystemMutationPermitId=${permitRecord.filesystemMutationPermitId}`
        : "permitRecord.filesystemMutationPermitId is empty",
    },
    {
      rule: "filesystem_mutation_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `filesystemMutationGateId=${gateRecord.filesystemMutationGateId}`
        : "gateRecord.filesystemMutationGateId is empty",
    },
    {
      rule: "filesystem_mutation_enablement_exists",
      pass: enablementExists,
      note: enablementExists
        ? `filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`
        : "enablementRecord.filesystemMutationEnablementId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "filesystem_mutation_approval_bound_to_authorization",
      pass: approvalBound,
      note: approvalBound
        ? `approvalRecord.filesystemMutationAuthorizationId === authorizationRecord.filesystemMutationAuthorizationId (${authorizationRecord.filesystemMutationAuthorizationId})`
        : `approval/authorization mismatch: approval.filesystemMutationAuthorizationId=${approvalRecord.filesystemMutationAuthorizationId} vs authorization.filesystemMutationAuthorizationId=${authorizationRecord.filesystemMutationAuthorizationId}`,
    },
    {
      rule: "filesystem_mutation_authorization_bound_to_permit",
      pass: authorizationBound,
      note: authorizationBound
        ? `authorizationRecord.filesystemMutationPermitId === permitRecord.filesystemMutationPermitId (${permitRecord.filesystemMutationPermitId})`
        : `authorization/permit mismatch: authorization.filesystemMutationPermitId=${authorizationRecord.filesystemMutationPermitId} vs permit.filesystemMutationPermitId=${permitRecord.filesystemMutationPermitId}`,
    },
    {
      rule: "filesystem_mutation_permit_bound_to_gate",
      pass: permitBound,
      note: permitBound
        ? `permitRecord.filesystemMutationGateId === gateRecord.filesystemMutationGateId (${gateRecord.filesystemMutationGateId})`
        : `permit/gate mismatch: permit.filesystemMutationGateId=${permitRecord.filesystemMutationGateId} vs gate.filesystemMutationGateId=${gateRecord.filesystemMutationGateId}`,
    },
    {
      rule: "filesystem_mutation_gate_bound_to_enablement",
      pass: gateBound,
      note: gateBound
        ? `gateRecord.filesystemMutationEnablementId === enablementRecord.filesystemMutationEnablementId (${enablementRecord.filesystemMutationEnablementId})`
        : `gate/enablement mismatch: gate.filesystemMutationEnablementId=${gateRecord.filesystemMutationEnablementId} vs enablement.filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`,
    },
    {
      rule: "filesystem_mutation_grant_still_disabled",
      pass: true,
      note: "filesystemMutationGrantEnabled=false — compile-time literal; no filesystem mutation grant activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "filesystemMutationGrantState=descriptor_filesystem_mutation_grant_pending — output is a descriptor only; filesystem mutation grant is not yet enabled",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly FilesystemMutationGrantCheck[],
): readonly FilesystemMutationGrantBlockedReason[] {
  const staticReasons: FilesystemMutationGrantBlockedReason[] = [
    { code: "filesystem_mutation_grant_disabled", reason: "filesystemMutationGrantEnabled=false — compile-time literal; an explicit first controlled filesystem mutation grant activation phase must enable the grant before any sandbox target can receive filesystem writes",                                                                                                                                                                                                                                                                                                                                                                                      static: true },
    { code: "approval_required",                  reason: "approvalRequired=true — explicit operator approval is required before the filesystem mutation grant can be enabled",                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   static: true },
    { code: "actual_writes_disabled",             reason: "actualWritesEnabled=false — compile-time literal across all 38 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, mutation-apply, mutation-surface, filesystem-mutation-enablement, filesystem-mutation-gate, filesystem-mutation-permit, filesystem-mutation-authorization, and filesystem-mutation-approval layers", static: true },
  ];
  const dynamicReasons: FilesystemMutationGrantBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedGrantReference(
  input: CreateFirstControlledFilesystemMutationGrantInput,
  rollbackChainValid: boolean,
): LinkedFilesystemMutationGrantReference {
  const { approvalRecord, authorizationRecord, permitRecord, gateRecord } = input;
  return {
    filesystemMutationApprovalId:           approvalRecord.filesystemMutationApprovalId,
    filesystemMutationAuthorizationId:      authorizationRecord.filesystemMutationAuthorizationId,
    filesystemMutationPermitId:             permitRecord.filesystemMutationPermitId,
    filesystemMutationGateId:               gateRecord.filesystemMutationGateId,
    rollbackSnapshotId:                     approvalRecord.linkedFilesystemMutationApprovalReference.rollbackSnapshotId,
    filesystemMutationGrantPrepared:        true,
    filesystemMutationGrantEnabled:         false,
    filesystemMutationApprovalGranted:      false,
    filesystemMutationAuthorizationEnabled: false,
    filesystemMutationPermitEnabled:        false,
    filesystemMutationGateEnabled:          false,
    filesystemMutationEnablementEnabled:    false,
    actualWritesEnabled:                    false,
    rollbackChainValid,
    referenceNote: "linked filesystem mutation grant reference sources rollbackSnapshotId from approvalRecord.linkedFilesystemMutationApprovalReference; filesystem mutation grant disabled; filesystem mutation approval not granted; filesystem mutation authorization disabled; filesystem mutation permit disabled; filesystem mutation gate disabled; filesystem mutation enablement disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstControlledFilesystemMutationGrantRecord(
  input: CreateFirstControlledFilesystemMutationGrantInput,
): FirstControlledFilesystemMutationGrantRecord {
  const { approvalRecord, authorizationRecord, permitRecord, gateRecord, enablementRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = approvalRecord.filesystemMutationApprovalReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedGrantReference(input, rollbackChainValid);

  const filesystemMutationGrantPlan: FilesystemMutationGrantPlanEntry[] = [
    {
      entryId:                        randomUUID(),
      operationType:                  "descriptor_filesystem_mutation_grant_planned",
      targetScope:                    "sandbox_approved_only",
      filesystemMutationGrantEnabled: false,
      mutationBlocked:                true,
      note:                           "filesystem mutation grant planned in descriptor-only mode; targetScope=sandbox_approved_only; filesystemMutationGrantEnabled=false; filesystemMutationBlocked=true; first controlled filesystem mutation grant activation phase required to enable",
    },
  ];

  const filesystemMutationGrantReadinessReport: FilesystemMutationGrantReadinessReport = {
    filesystemMutationGrantPrepared:       true,
    filesystemMutationGrantEnabled:        false,
    filesystemMutationApprovalGranted:     false,
    filesystemMutationAuthorizationEnabled: false,
    filesystemMutationPermitEnabled:       false,
    filesystemMutationGateEnabled:         false,
    filesystemMutationEnablementEnabled:   false,
    mutationSurfaceEnabled:                false,
    mutationApplyEnabled:                  false,
    mutationCommitEnabled:                 false,
    mutationExecutorEnabled:               false,
    commitExecutionGateEnabled:            false,
    sandboxWriteCommitEnabled:             false,
    runtimeWriteExecutorEnabled:           false,
    writeExecutionGateEnabled:             false,
    scopedActivationEnabled:               false,
    writePermissionEnabled:                false,
    mutationSwitchEnabled:                 false,
    guardedWriteEnabled:                   false,
    actualWritesEnabled:                   false,
    realWritesEnabled:                     false,
    approvalRequired:                      true,
    allChecksPass,
    blockedReasonCount:                    blockedReasons.length,
    rollbackChainValid,
    targetScope:                           "sandbox_approved_only",
    summary: `filesystemMutationGrantState=descriptor_filesystem_mutation_grant_pending; filesystemMutationGrantEnabled=false; filesystemMutationApprovalGranted=false; filesystemMutationAuthorizationEnabled=false; filesystemMutationPermitEnabled=false; filesystemMutationGateEnabled=false; filesystemMutationEnablementEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstControlledFilesystemMutationGrantRecord = {
    filesystemMutationGrantId:              randomUUID(),
    filesystemMutationGrantState:           "descriptor_filesystem_mutation_grant_pending",
    approvalRequired:                       true,
    filesystemMutationGrantPrepared:        true,
    filesystemMutationGrantEnabled:         false,
    filesystemMutationApprovalGranted:      false,
    filesystemMutationAuthorizationEnabled: false,
    filesystemMutationPermitEnabled:        false,
    filesystemMutationGateEnabled:          false,
    filesystemMutationEnablementEnabled:    false,
    actualWritesEnabled:                    false,
    filesystemMutationBlocked:              true,
    motherCoreMutationBlocked:              true,
    vaultMutationBlocked:                   true,
    shellBlocked:                           true,
    networkBlocked:                         true,
    targetScope:                            "sandbox_approved_only",
    implementationPhase:                    "descriptor_only",
    filesystemMutationApprovalId:           approvalRecord.filesystemMutationApprovalId,
    filesystemMutationAuthorizationId:      authorizationRecord.filesystemMutationAuthorizationId,
    filesystemMutationPermitId:             permitRecord.filesystemMutationPermitId,
    filesystemMutationGateId:               gateRecord.filesystemMutationGateId,
    filesystemMutationEnablementId:         enablementRecord.filesystemMutationEnablementId,
    controlledExecutionId:                  executionRecord.controlledExecutionId,
    filesystemMutationGrantPlan,
    filesystemMutationGrantChecks:          checks,
    filesystemMutationGrantBlockedReasons:  blockedReasons,
    filesystemMutationGrantReadinessReport,
    linkedFilesystemMutationGrantReference: linkedRef,
    createdAt:                              new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstControlledFilesystemMutationGrantRecords(): readonly FirstControlledFilesystemMutationGrantRecord[] {
  return _store.slice();
}

export function getFirstControlledFilesystemMutationGrantSummary(): FirstControlledFilesystemMutationGrantSummary {
  return {
    total:                                   _store.length,
    byState:                                 { descriptor_filesystem_mutation_grant_pending: _store.length },
    filesystemMutationGrantPrepared:         true,
    filesystemMutationGrantEnabled:          false,
    filesystemMutationApprovalGranted:       false,
    filesystemMutationAuthorizationEnabled:  false,
    filesystemMutationPermitEnabled:         false,
    filesystemMutationGateEnabled:           false,
    filesystemMutationEnablementEnabled:     false,
    actualWritesEnabled:                     false,
    approvalRequired:                        true,
    filesystemMutationBlocked:               true,
    motherCoreMutationBlocked:               true,
    targetScope:                             "sandbox_approved_only",
    filesystemMutationGrantState:            "descriptor_filesystem_mutation_grant_pending",
    implementationPhase:                     "descriptor_only",
  };
}
