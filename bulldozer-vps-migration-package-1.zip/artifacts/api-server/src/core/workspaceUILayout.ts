import { getUIRenderModel } from "./workspaceUIRenderModel.js";

export interface UILayoutConfig {
  appName: string;
  shellType: string;
  sidebarEnabled: boolean;
  topbarEnabled: boolean;
  contentGrid: string;
  executionBlocked: true;
}

export interface UILayoutManifest {
  generatedAt: string;
  layout: UILayoutConfig;
  executionBlocked: true;
}

export function getUILayoutManifest(): UILayoutManifest {
  const { layout } = getUIRenderModel();

  return {
    generatedAt: new Date().toISOString(),
    layout: {
      appName: layout.appName,
      shellType: layout.shellType,
      sidebarEnabled: layout.sidebarEnabled,
      topbarEnabled: layout.topbarEnabled,
      contentGrid: layout.contentGrid,
      executionBlocked: true,
    },
    executionBlocked: true,
  };
}
