// firstControlledFilesystemMutationGateCore.ts
// Phase 340 — First Controlled Filesystem Mutation Gate Descriptor Core Skeleton
// In-memory first controlled filesystem mutation gate descriptor engine.
// Layer 34 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply + mutation-surface +
//   filesystem-mutation-enablement stack.
// Defines the first controlled filesystem mutation gate descriptor.
// Binds gate to filesystem mutation enablement and to mutation surface/apply/commit/executor chain.
// Preserves sandbox-approved-only target scope from layers 24–33 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem mutation. No shell execution. No network access.
// No vault access. No Mother Core mutation.
// filesystemMutationGateEnabled=false — gate has not been activated.
// filesystemMutationGatePrepared=true — descriptor-readiness established for a future
//   first controlled filesystem mutation gate activation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { ControlledFilesystemMutationEnablementRecord } from "./controlledFilesystemMutationEnablementCore.js";
import type { FirstActualSandboxMutationSurfaceRecord }       from "./firstActualSandboxMutationSurfaceCore.js";
import type { FirstActualSandboxMutationApplyRecord }         from "./firstActualSandboxMutationApplyCore.js";
import type { FirstActualSandboxMutationCommitRecord }        from "./firstActualSandboxMutationCommitCore.js";
import type { FirstActualSandboxMutationExecutorRecord }      from "./firstActualSandboxMutationExecutorCore.js";
import type { ControlledExecutionRecord }                     from "./controlledExecutionCore.js";
import { randomUUID }                                         from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FilesystemMutationGateState =
  "descriptor_filesystem_mutation_gate_pending";

export type FilesystemMutationGateCheckRule =
  | "filesystem_mutation_enablement_exists"
  | "mutation_surface_exists"
  | "mutation_apply_exists"
  | "mutation_commit_exists"
  | "mutation_executor_exists"
  | "execution_record_exists"
  | "filesystem_mutation_enablement_bound_to_surface"
  | "mutation_surface_bound_to_apply"
  | "mutation_apply_bound_to_commit"
  | "mutation_commit_bound_to_executor"
  | "filesystem_mutation_gate_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface FilesystemMutationGateCheck {
  readonly rule: FilesystemMutationGateCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface FilesystemMutationGateBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedFilesystemMutationGateReference {
  readonly filesystemMutationEnablementId: string;
  readonly mutationSurfaceId:              string;
  readonly mutationApplyId:                string;
  readonly mutationCommitId:               string;
  readonly rollbackSnapshotId:             string;
  readonly filesystemMutationGatePrepared:        true;
  readonly filesystemMutationGateEnabled:         false;
  readonly filesystemMutationEnablementEnabled:   false;
  readonly mutationSurfaceEnabled:                false;
  readonly mutationApplyEnabled:                  false;
  readonly actualWritesEnabled:                   false;
  readonly rollbackChainValid:                    boolean;
  readonly referenceNote:                         string;
}

export interface FilesystemMutationGateReadinessReport {
  readonly filesystemMutationGatePrepared:        true;
  readonly filesystemMutationGateEnabled:         false;
  readonly filesystemMutationEnablementEnabled:   false;
  readonly mutationSurfaceEnabled:                false;
  readonly mutationApplyEnabled:                  false;
  readonly mutationCommitEnabled:                 false;
  readonly mutationExecutorEnabled:               false;
  readonly commitExecutionGateEnabled:            false;
  readonly sandboxWriteCommitEnabled:             false;
  readonly runtimeWriteExecutorEnabled:           false;
  readonly writeExecutionGateEnabled:             false;
  readonly scopedActivationEnabled:               false;
  readonly writePermissionEnabled:                false;
  readonly mutationSwitchEnabled:                 false;
  readonly guardedWriteEnabled:                   false;
  readonly actualWritesEnabled:                   false;
  readonly realWritesEnabled:                     false;
  readonly approvalRequired:                      true;
  readonly allChecksPass:                         boolean;
  readonly blockedReasonCount:                    number;
  readonly rollbackChainValid:                    boolean;
  readonly targetScope:                           "sandbox_approved_only";
  readonly summary:                               string;
}

export interface FirstControlledFilesystemMutationGateRecord {
  readonly filesystemMutationGateId:              string;
  readonly filesystemMutationGateState:           FilesystemMutationGateState;
  readonly approvalRequired:                      true;
  readonly filesystemMutationGatePrepared:        true;
  readonly filesystemMutationGateEnabled:         false;
  readonly filesystemMutationEnablementEnabled:   false;
  readonly mutationSurfaceEnabled:                false;
  readonly mutationApplyEnabled:                  false;
  readonly mutationCommitEnabled:                 false;
  readonly mutationExecutorEnabled:               false;
  readonly actualWritesEnabled:                   false;
  readonly filesystemMutationBlocked:             true;
  readonly motherCoreMutationBlocked:             true;
  readonly vaultMutationBlocked:                  true;
  readonly shellBlocked:                          true;
  readonly networkBlocked:                        true;
  readonly targetScope:                           "sandbox_approved_only";
  readonly implementationPhase:                   "descriptor_only";
  readonly filesystemMutationEnablementId:        string;
  readonly mutationSurfaceId:                     string;
  readonly mutationApplyId:                       string;
  readonly mutationCommitId:                      string;
  readonly mutationExecutorId:                    string;
  readonly controlledExecutionId:                 string;
  readonly filesystemMutationGateChecks:          readonly FilesystemMutationGateCheck[];
  readonly filesystemMutationGateBlockedReasons:  readonly FilesystemMutationGateBlockedReason[];
  readonly filesystemMutationGateReadinessReport: FilesystemMutationGateReadinessReport;
  readonly linkedFilesystemMutationGateReference: LinkedFilesystemMutationGateReference;
  readonly createdAt:                             string;
}

export interface CreateFirstControlledFilesystemMutationGateInput {
  readonly enablementRecord:        ControlledFilesystemMutationEnablementRecord;
  readonly mutationSurfaceRecord:   FirstActualSandboxMutationSurfaceRecord;
  readonly mutationApplyRecord:     FirstActualSandboxMutationApplyRecord;
  readonly mutationCommitRecord:    FirstActualSandboxMutationCommitRecord;
  readonly mutationExecutorRecord:  FirstActualSandboxMutationExecutorRecord;
  readonly executionRecord:         ControlledExecutionRecord;
}

export interface FirstControlledFilesystemMutationGateSummary {
  readonly total:                               number;
  readonly byState:                             Record<FilesystemMutationGateState, number>;
  readonly filesystemMutationGatePrepared:        true;
  readonly filesystemMutationGateEnabled:         false;
  readonly filesystemMutationEnablementEnabled:   false;
  readonly mutationSurfaceEnabled:                false;
  readonly mutationApplyEnabled:                  false;
  readonly mutationCommitEnabled:                 false;
  readonly mutationExecutorEnabled:               false;
  readonly actualWritesEnabled:                   false;
  readonly approvalRequired:                      true;
  readonly filesystemMutationBlocked:             true;
  readonly motherCoreMutationBlocked:             true;
  readonly targetScope:                           "sandbox_approved_only";
  readonly filesystemMutationGateState:           FilesystemMutationGateState;
  readonly implementationPhase:                   "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstControlledFilesystemMutationGateRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstControlledFilesystemMutationGateInput,
): readonly FilesystemMutationGateCheck[] {
  const { enablementRecord, mutationSurfaceRecord, mutationApplyRecord, mutationCommitRecord, mutationExecutorRecord, executionRecord } = input;

  const enablementExists = enablementRecord.filesystemMutationEnablementId.length > 0;
  const surfaceExists    = mutationSurfaceRecord.mutationSurfaceId.length > 0;
  const applyExists      = mutationApplyRecord.mutationApplyId.length > 0;
  const commitExists     = mutationCommitRecord.mutationCommitId.length > 0;
  const execExists       = mutationExecutorRecord.mutationExecutorId.length > 0;
  const ctrlExists       = executionRecord.controlledExecutionId.length > 0;

  const enablementBound  = enablementRecord.mutationSurfaceId === mutationSurfaceRecord.mutationSurfaceId;
  const surfaceBound     = mutationSurfaceRecord.mutationApplyId === mutationApplyRecord.mutationApplyId;
  const applyBound       = mutationApplyRecord.mutationCommitId === mutationCommitRecord.mutationCommitId;
  const commitBound      = mutationCommitRecord.mutationExecutorId === mutationExecutorRecord.mutationExecutorId;

  return [
    {
      rule: "filesystem_mutation_enablement_exists",
      pass: enablementExists,
      note: enablementExists
        ? `filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`
        : "enablementRecord.filesystemMutationEnablementId is empty",
    },
    {
      rule: "mutation_surface_exists",
      pass: surfaceExists,
      note: surfaceExists
        ? `mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`
        : "mutationSurfaceRecord.mutationSurfaceId is empty",
    },
    {
      rule: "mutation_apply_exists",
      pass: applyExists,
      note: applyExists
        ? `mutationApplyId=${mutationApplyRecord.mutationApplyId}`
        : "mutationApplyRecord.mutationApplyId is empty",
    },
    {
      rule: "mutation_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `mutationCommitId=${mutationCommitRecord.mutationCommitId}`
        : "mutationCommitRecord.mutationCommitId is empty",
    },
    {
      rule: "mutation_executor_exists",
      pass: execExists,
      note: execExists
        ? `mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`
        : "mutationExecutorRecord.mutationExecutorId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "filesystem_mutation_enablement_bound_to_surface",
      pass: enablementBound,
      note: enablementBound
        ? `enablementRecord.mutationSurfaceId === mutationSurfaceRecord.mutationSurfaceId (${mutationSurfaceRecord.mutationSurfaceId})`
        : `enablement/surface mismatch: enablement.mutationSurfaceId=${enablementRecord.mutationSurfaceId} vs surface.mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`,
    },
    {
      rule: "mutation_surface_bound_to_apply",
      pass: surfaceBound,
      note: surfaceBound
        ? `mutationSurfaceRecord.mutationApplyId === mutationApplyRecord.mutationApplyId (${mutationApplyRecord.mutationApplyId})`
        : `surface/apply mismatch: surface.mutationApplyId=${mutationSurfaceRecord.mutationApplyId} vs apply.mutationApplyId=${mutationApplyRecord.mutationApplyId}`,
    },
    {
      rule: "mutation_apply_bound_to_commit",
      pass: applyBound,
      note: applyBound
        ? `mutationApplyRecord.mutationCommitId === mutationCommitRecord.mutationCommitId (${mutationCommitRecord.mutationCommitId})`
        : `apply/commit mismatch: apply.mutationCommitId=${mutationApplyRecord.mutationCommitId} vs commit.mutationCommitId=${mutationCommitRecord.mutationCommitId}`,
    },
    {
      rule: "mutation_commit_bound_to_executor",
      pass: commitBound,
      note: commitBound
        ? `mutationCommitRecord.mutationExecutorId === mutationExecutorRecord.mutationExecutorId (${mutationExecutorRecord.mutationExecutorId})`
        : `commit/executor mismatch: commit.mutationExecutorId=${mutationCommitRecord.mutationExecutorId} vs executor.mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`,
    },
    {
      rule: "filesystem_mutation_gate_still_disabled",
      pass: true,
      note: "filesystemMutationGateEnabled=false — compile-time literal; no filesystem mutation gate activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "filesystemMutationGateState=descriptor_filesystem_mutation_gate_pending — output is a descriptor only; filesystem mutation gate is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly FilesystemMutationGateCheck[],
): readonly FilesystemMutationGateBlockedReason[] {
  const staticReasons: FilesystemMutationGateBlockedReason[] = [
    { code: "filesystem_mutation_gate_disabled", reason: "filesystemMutationGateEnabled=false — compile-time literal; an explicit first controlled filesystem mutation gate activation phase must activate the gate before any sandbox target can receive filesystem writes",                                                                                                                                                                                                                                                                                                                                        static: true },
    { code: "approval_required",                 reason: "approvalRequired=true — explicit operator approval is required before the filesystem mutation gate can be activated",                                                                                                                                                                                                                                                                                                                                                                                                                                    static: true },
    { code: "actual_writes_disabled",            reason: "actualWritesEnabled=false — compile-time literal across all 34 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, mutation-apply, mutation-surface, and filesystem-mutation-enablement layers", static: true },
  ];
  const dynamicReasons: FilesystemMutationGateBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedGateReference(
  input: CreateFirstControlledFilesystemMutationGateInput,
  rollbackChainValid: boolean,
): LinkedFilesystemMutationGateReference {
  const { enablementRecord, mutationSurfaceRecord, mutationApplyRecord, mutationCommitRecord } = input;
  return {
    filesystemMutationEnablementId: enablementRecord.filesystemMutationEnablementId,
    mutationSurfaceId:              mutationSurfaceRecord.mutationSurfaceId,
    mutationApplyId:                mutationApplyRecord.mutationApplyId,
    mutationCommitId:               mutationCommitRecord.mutationCommitId,
    rollbackSnapshotId:             enablementRecord.linkedFilesystemMutationReference.rollbackSnapshotId,
    filesystemMutationGatePrepared:        true,
    filesystemMutationGateEnabled:         false,
    filesystemMutationEnablementEnabled:   false,
    mutationSurfaceEnabled:                false,
    mutationApplyEnabled:                  false,
    actualWritesEnabled:                   false,
    rollbackChainValid,
    referenceNote: "linked filesystem mutation gate reference sources rollbackSnapshotId from enablementRecord.linkedFilesystemMutationReference; filesystem mutation gate disabled; filesystem mutation enablement disabled; mutation surface disabled; mutation apply disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstControlledFilesystemMutationGateRecord(
  input: CreateFirstControlledFilesystemMutationGateInput,
): FirstControlledFilesystemMutationGateRecord {
  const { enablementRecord, mutationSurfaceRecord, mutationApplyRecord, mutationCommitRecord, mutationExecutorRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = enablementRecord.filesystemMutationEnablementReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedGateReference(input, rollbackChainValid);

  const filesystemMutationGateReadinessReport: FilesystemMutationGateReadinessReport = {
    filesystemMutationGatePrepared:        true,
    filesystemMutationGateEnabled:         false,
    filesystemMutationEnablementEnabled:   false,
    mutationSurfaceEnabled:                false,
    mutationApplyEnabled:                  false,
    mutationCommitEnabled:                 false,
    mutationExecutorEnabled:               false,
    commitExecutionGateEnabled:            false,
    sandboxWriteCommitEnabled:             false,
    runtimeWriteExecutorEnabled:           false,
    writeExecutionGateEnabled:             false,
    scopedActivationEnabled:               false,
    writePermissionEnabled:                false,
    mutationSwitchEnabled:                 false,
    guardedWriteEnabled:                   false,
    actualWritesEnabled:                   false,
    realWritesEnabled:                     false,
    approvalRequired:                      true,
    allChecksPass,
    blockedReasonCount:                    blockedReasons.length,
    rollbackChainValid,
    targetScope:                           "sandbox_approved_only",
    summary: `filesystemMutationGateState=descriptor_filesystem_mutation_gate_pending; filesystemMutationGateEnabled=false; filesystemMutationEnablementEnabled=false; mutationSurfaceEnabled=false; mutationApplyEnabled=false; mutationCommitEnabled=false; mutationExecutorEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstControlledFilesystemMutationGateRecord = {
    filesystemMutationGateId:               randomUUID(),
    filesystemMutationGateState:            "descriptor_filesystem_mutation_gate_pending",
    approvalRequired:                       true,
    filesystemMutationGatePrepared:         true,
    filesystemMutationGateEnabled:          false,
    filesystemMutationEnablementEnabled:    false,
    mutationSurfaceEnabled:                 false,
    mutationApplyEnabled:                   false,
    mutationCommitEnabled:                  false,
    mutationExecutorEnabled:                false,
    actualWritesEnabled:                    false,
    filesystemMutationBlocked:              true,
    motherCoreMutationBlocked:              true,
    vaultMutationBlocked:                   true,
    shellBlocked:                           true,
    networkBlocked:                         true,
    targetScope:                            "sandbox_approved_only",
    implementationPhase:                    "descriptor_only",
    filesystemMutationEnablementId:         enablementRecord.filesystemMutationEnablementId,
    mutationSurfaceId:                      mutationSurfaceRecord.mutationSurfaceId,
    mutationApplyId:                        mutationApplyRecord.mutationApplyId,
    mutationCommitId:                       mutationCommitRecord.mutationCommitId,
    mutationExecutorId:                     mutationExecutorRecord.mutationExecutorId,
    controlledExecutionId:                  executionRecord.controlledExecutionId,
    filesystemMutationGateChecks:           checks,
    filesystemMutationGateBlockedReasons:   blockedReasons,
    filesystemMutationGateReadinessReport,
    linkedFilesystemMutationGateReference:  linkedRef,
    createdAt:                              new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstControlledFilesystemMutationGateRecords(): readonly FirstControlledFilesystemMutationGateRecord[] {
  return _store.slice();
}

export function getFirstControlledFilesystemMutationGateSummary(): FirstControlledFilesystemMutationGateSummary {
  return {
    total:                                _store.length,
    byState:                              { descriptor_filesystem_mutation_gate_pending: _store.length },
    filesystemMutationGatePrepared:        true,
    filesystemMutationGateEnabled:         false,
    filesystemMutationEnablementEnabled:   false,
    mutationSurfaceEnabled:                false,
    mutationApplyEnabled:                  false,
    mutationCommitEnabled:                 false,
    mutationExecutorEnabled:               false,
    actualWritesEnabled:                   false,
    approvalRequired:                      true,
    filesystemMutationBlocked:             true,
    motherCoreMutationBlocked:             true,
    targetScope:                           "sandbox_approved_only",
    filesystemMutationGateState:           "descriptor_filesystem_mutation_gate_pending",
    implementationPhase:                   "descriptor_only",
  };
}
