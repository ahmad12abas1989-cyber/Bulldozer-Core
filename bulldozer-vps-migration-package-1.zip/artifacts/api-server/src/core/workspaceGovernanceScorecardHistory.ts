// Governance Scorecard History Capture — Phase 114
// Persistent ring buffer for point-in-time Governance Scorecard snapshots.
// Max 10 entries, atomic write semantics, load-on-boot, bounded pruning.
// No rendering, no autonomous execution, no mutation outside the ring.

import { readStore, writeStore } from "./persistentStore";
import { logger } from "../lib/logger";
import {
  getWorkspaceGovernanceScorecard,
  type WorkspaceGovernanceScorecard,
  type GovernanceGrade,
} from "./workspaceGovernanceScorecard";

const EXECUTION_BLOCKED: true = true;
const MAX_ENTRIES = 10;
const STORE_KEY = "workspace-governance-scorecard-history";

// --- Types ---

export interface ScorecardHistoryEntry {
  captureSeq: number;
  createdAt: string;
  scorecardId: string;
  snapshot: WorkspaceGovernanceScorecard;
  executionBlocked: true;
}

// Summary projection — excludes full breakdown[], recommendations[], and signals.
// Exposes only the Phase-112 validation_integrity fields and core score/grade.
export interface ScorecardHistoryListItem {
  captureSeq: number;
  createdAt: string;
  scorecardId: string;
  governanceScore: number;
  governanceGrade: GovernanceGrade;
  validationIntegrityScore: number;
  validationIntegrityWeight: number;
  widgetRegistryHealthy: boolean;
  widgetContractViolations: number;
  executionBlocked: true;
}

export interface ScorecardHistoryCaptureResult {
  captureSeq: number;
  createdAt: string;
  scorecardId: string;
  governanceScore: number;
  governanceGrade: GovernanceGrade;
  validationIntegrityScore: number;
  validationIntegrityWeight: number;
  widgetRegistryHealthy: boolean;
  widgetContractViolations: number;
  ringSize: number;
  executionBlocked: true;
}

export interface ScorecardHistoryListResult {
  entries: ScorecardHistoryListItem[];
  total: number;
  maxRetained: number;
  storeKey: string;
  executionBlocked: true;
}

// Full detail projection — includes complete stored WorkspaceGovernanceScorecard
// with breakdown[], recommendations[], and signals. Read-only, O(10) ring lookup.
export interface ScorecardHistoryDetailResult {
  captureSeq: number;
  createdAt: string;
  scorecardId: string;
  scorecardSnapshot: WorkspaceGovernanceScorecard;
  executionBlocked: true;
}

// --- Module state ---

let historyRing: ScorecardHistoryEntry[] = [];
let nextCaptureSeq = 1;
let loadedOnBoot = 0;
let isInitialized = false;

// --- Persistence helpers ---

function flush(): void {
  try {
    writeStore<ScorecardHistoryEntry[]>(STORE_KEY, historyRing);
  } catch (err) {
    logger.error(
      { err, storeKey: STORE_KEY },
      "Scorecard history: flush failed — ring preserved in memory",
    );
  }
}

function isValidEntry(obj: unknown): obj is ScorecardHistoryEntry {
  if (obj === null || typeof obj !== "object") return false;
  const e = obj as Record<string, unknown>;
  return (
    typeof e["captureSeq"] === "number" &&
    typeof e["createdAt"] === "string" &&
    typeof e["scorecardId"] === "string" &&
    e["snapshot"] !== null &&
    typeof e["snapshot"] === "object" &&
    e["executionBlocked"] === true
  );
}

// --- Init ---

export function initWorkspaceGovernanceScorecardHistory(): void {
  if (isInitialized) return;

  const stored = readStore<unknown[]>(STORE_KEY);
  if (Array.isArray(stored)) {
    const valid = stored.filter(isValidEntry);
    historyRing = valid.slice(-MAX_ENTRIES);
    loadedOnBoot = historyRing.length;
    if (valid.length !== stored.length) {
      logger.warn(
        { total: stored.length, valid: valid.length, key: STORE_KEY },
        "Scorecard history load: skipped invalid entries on boot",
      );
    }
    // Resume captureSeq from the highest persisted seq to avoid collisions
    if (historyRing.length > 0) {
      const maxSeq = Math.max(...historyRing.map((e) => e.captureSeq));
      nextCaptureSeq = maxSeq + 1;
    }
  }

  isInitialized = true;
  logger.info(
    {
      subsystem: "workspace_governance_scorecard_history",
      loadedOnBoot,
      maxRetained: MAX_ENTRIES,
      storeKey: STORE_KEY,
      nextCaptureSeq,
    },
    "Workspace governance scorecard history initialized",
  );
}

// --- Capture ---

export function captureGovernanceScorecardSnapshot(): ScorecardHistoryCaptureResult {
  const scorecard = getWorkspaceGovernanceScorecard();
  const captureSeq = nextCaptureSeq++;
  const createdAt = scorecard.generatedAt;
  const scorecardId = scorecard.scorecardId;

  const entry: ScorecardHistoryEntry = {
    captureSeq,
    createdAt,
    scorecardId,
    snapshot: scorecard,
    executionBlocked: EXECUTION_BLOCKED,
  };

  historyRing.push(entry);

  // Prune to ring cap — oldest (lowest captureSeq) removed first
  while (historyRing.length > MAX_ENTRIES) {
    historyRing.shift();
  }

  flush();

  return {
    captureSeq,
    createdAt,
    scorecardId,
    governanceScore: scorecard.governanceScore,
    governanceGrade: scorecard.governanceGrade,
    validationIntegrityScore: scorecard.signals.validationIntegrityScore,
    validationIntegrityWeight: scorecard.signals.validationIntegrityWeight,
    widgetRegistryHealthy: scorecard.signals.widgetRegistryHealthy,
    widgetContractViolations: scorecard.signals.widgetContractViolations,
    ringSize: historyRing.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Raw access (for analytics) ---

export function getRawScorecardHistoryEntries(): ScorecardHistoryEntry[] {
  return [...historyRing];
}

// --- Detail lookup ---

// O(10) bounded scan — ring max is 10.
// Returns null if captureSeq is not in the current ring (pruned or never existed).
// No persistence mutation, no live scorecard recomputation.
export function getGovernanceScorecardHistoryDetail(
  captureSeq: number,
): ScorecardHistoryDetailResult | null {
  const entry = historyRing.find((e) => e.captureSeq === captureSeq) ?? null;
  if (entry === null) return null;
  return {
    captureSeq: entry.captureSeq,
    createdAt: entry.createdAt,
    scorecardId: entry.scorecardId,
    scorecardSnapshot: entry.snapshot,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- List ---

export function listGovernanceScorecardHistory(): ScorecardHistoryListResult {
  // Newest-first (highest captureSeq first)
  const sorted = [...historyRing].sort((a, b) => b.captureSeq - a.captureSeq);

  const entries: ScorecardHistoryListItem[] = sorted.map((e) => ({
    captureSeq: e.captureSeq,
    createdAt: e.createdAt,
    scorecardId: e.scorecardId,
    governanceScore: e.snapshot.governanceScore,
    governanceGrade: e.snapshot.governanceGrade,
    validationIntegrityScore: e.snapshot.signals.validationIntegrityScore,
    validationIntegrityWeight: e.snapshot.signals.validationIntegrityWeight,
    widgetRegistryHealthy: e.snapshot.signals.widgetRegistryHealthy,
    widgetContractViolations: e.snapshot.signals.widgetContractViolations,
    executionBlocked: EXECUTION_BLOCKED,
  }));

  return {
    entries,
    total: entries.length,
    maxRetained: MAX_ENTRIES,
    storeKey: STORE_KEY,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
