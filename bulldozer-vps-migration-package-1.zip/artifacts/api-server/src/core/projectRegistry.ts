import { randomBytes } from "node:crypto";
import { registerSubsystemState } from "./runtimeStateRegistry";
import { readStore, writeStore } from "./persistentStore";
import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";

export type ProjectStatus = "active" | "archived" | "suspended";

export interface Project {
  projectId: string;
  projectName: string;
  createdAt: string;
  updatedAt: string;
  owner: string;
  status: ProjectStatus;
  executionBlocked: true;
}

export interface ProjectRegistryPersistenceInfo {
  storeKey: string;
  loadedOnBoot: number;
  flushCount: number;
  lastFlushedAt: string | null;
}

export interface ProjectRegistryStatus {
  operational: boolean;
  projectCount: number;
  maxProjects: number;
  atCapacity: boolean;
  initializedAt: string | null;
  executionBlocked: true;
  recoveryBlocked: true;
  persistence: ProjectRegistryPersistenceInfo;
}

export interface ProjectCreateResult {
  success: boolean;
  project?: Project;
  error?: string;
  errorType?: "validation" | "conflict" | "capacity";
  executionBlocked: true;
}

export interface ProjectTransitionResult {
  success: boolean;
  project?: Project;
  previousStatus?: ProjectStatus;
  error?: string;
  errorType?: "validation" | "not_found" | "invalid_transition";
  executionBlocked: true;
}

export type MemberRole = "owner" | "operator" | "maintainer" | "observer" | "auditor";

export interface ProjectMember {
  actorId: string;
  role: MemberRole;
  addedAt: string;
  executionBlocked: true;
}

export interface ProjectMembershipResult {
  success: boolean;
  member?: ProjectMember;
  error?: string;
  errorType?: "validation" | "not_found" | "conflict" | "capacity";
  executionBlocked: true;
}

export interface ProjectMembersListResult {
  success: boolean;
  projectId: string;
  members: ProjectMember[];
  count: number;
  error?: string;
  errorType?: "not_found";
  executionBlocked: true;
}

export interface ProjectRemoveMemberResult {
  success: boolean;
  removedActorId?: string;
  error?: string;
  errorType?: "validation" | "not_found" | "not_member";
  executionBlocked: true;
}

const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;
const MAX_PROJECTS = 100;
const PROJECT_NAME_MAX = 100;
const OWNER_MAX = 64;
const VALID_STATUSES = new Set<string>(["active", "archived", "suspended"]);
const STORE_KEY = "project-registry";

const TRANSITION_TABLE = new Map<ProjectStatus, ReadonlySet<ProjectStatus>>([
  ["active",    new Set<ProjectStatus>(["archived", "suspended"])],
  ["suspended", new Set<ProjectStatus>(["active"])],
  ["archived",  new Set<ProjectStatus>(["active"])],
]);

const projectsById = new Map<string, Project>();
let isOperational = false;
let initializedAt: string | null = null;
let loadedOnBoot = 0;
let flushCount = 0;
let lastFlushedAt: string | null = null;

function isValidProject(obj: unknown): obj is Project {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  const p = obj as Record<string, unknown>;
  return (
    typeof p["projectId"] === "string" &&
    /^[0-9a-f]{16}$/.test(p["projectId"]) &&
    typeof p["projectName"] === "string" &&
    p["projectName"].length > 0 &&
    p["projectName"].length <= PROJECT_NAME_MAX &&
    typeof p["owner"] === "string" &&
    p["owner"].length > 0 &&
    p["owner"].length <= OWNER_MAX &&
    typeof p["status"] === "string" &&
    VALID_STATUSES.has(p["status"]) &&
    typeof p["createdAt"] === "string" &&
    p["createdAt"].length > 0 &&
    typeof p["updatedAt"] === "string" &&
    p["updatedAt"].length > 0 &&
    p["executionBlocked"] === true
  );
}

function flushProjectRegistry(): void {
  try {
    const snapshot = Array.from(projectsById.values()).sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
    );
    writeStore<Project[]>(STORE_KEY, snapshot);
    lastFlushedAt = new Date().toISOString();
    flushCount++;
  } catch (err) {
    logger.error({ err }, "Project registry flush failed");
  }
}

export function initProjectRegistry(): void {
  if (isOperational) return;

  // Load persisted projects before marking operational
  let booted = 0;
  try {
    const stored = readStore<unknown[]>(STORE_KEY);
    if (Array.isArray(stored)) {
      for (const raw of stored) {
        if (booted >= MAX_PROJECTS) break;
        if (!isValidProject(raw)) {
          logger.warn({ raw }, "Skipping malformed project registry entry on boot");
          continue;
        }
        if (!projectsById.has(raw.projectId)) {
          projectsById.set(raw.projectId, raw);
          booted++;
        }
      }
    }
  } catch (err) {
    logger.error({ err }, "Project registry load failed — starting empty");
  }
  loadedOnBoot = booted;

  registerSubsystemState({
    subsystemName: "project_registry",
    category: "workspace",
    dependencies: ["runtime_state_registry"],
    metadata: {
      description:
        "Project registry — atomic JSON persistence, max 100 projects, survives restart, no execution",
      maxProjects: MAX_PROJECTS,
      storeKey: STORE_KEY,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  isOperational = true;
  initializedAt = new Date().toISOString();

  addTimelineEvent({
    level: "info",
    source: "project-registry",
    message: "Project registry initialized",
    metadata: {
      maxProjects: MAX_PROJECTS,
      loadedOnBoot,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  emit("project_registry:initialized", "project-registry", {
    maxProjects: MAX_PROJECTS,
    loadedOnBoot,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "project_registry.initialized",
    source: "project-registry",
    severity: "info",
    category: "runtime",
    payload: { maxProjects: MAX_PROJECTS, loadedOnBoot, executionBlocked: EXECUTION_BLOCKED },
  });

  logger.info({ maxProjects: MAX_PROJECTS, loadedOnBoot }, "Project registry initialized");
}

export function getProjectRegistryStatus(): ProjectRegistryStatus {
  return {
    operational: isOperational,
    projectCount: projectsById.size,
    maxProjects: MAX_PROJECTS,
    atCapacity: projectsById.size >= MAX_PROJECTS,
    initializedAt,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    persistence: {
      storeKey: STORE_KEY,
      loadedOnBoot,
      flushCount,
      lastFlushedAt,
    },
  };
}

export function createProject(input: {
  projectName: unknown;
  owner: unknown;
  status?: unknown;
}): ProjectCreateResult {
  const name = typeof input.projectName === "string" ? input.projectName.trim() : "";
  const owner = typeof input.owner === "string" ? input.owner.trim() : "";
  const rawStatus = input.status;
  const status: ProjectStatus =
    typeof rawStatus === "string" && VALID_STATUSES.has(rawStatus)
      ? (rawStatus as ProjectStatus)
      : "active";

  if (!name) {
    return {
      success: false,
      error: 'Field "projectName" is required and must be a non-empty string',
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  if (name.length > PROJECT_NAME_MAX) {
    return {
      success: false,
      error: `Field "projectName" must not exceed ${PROJECT_NAME_MAX} characters`,
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  if (!owner) {
    return {
      success: false,
      error: 'Field "owner" is required and must be a non-empty string',
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  if (owner.length > OWNER_MAX) {
    return {
      success: false,
      error: `Field "owner" must not exceed ${OWNER_MAX} characters`,
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const nameLower = name.toLowerCase();
  for (const existing of projectsById.values()) {
    if (existing.projectName.toLowerCase() === nameLower) {
      return {
        success: false,
        error: `A project named "${name}" already exists`,
        errorType: "conflict",
        executionBlocked: EXECUTION_BLOCKED,
      };
    }
  }

  if (projectsById.size >= MAX_PROJECTS) {
    return {
      success: false,
      error: `Project registry is at capacity (max ${MAX_PROJECTS} projects)`,
      errorType: "capacity",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const now = new Date().toISOString();
  const projectId = randomBytes(8).toString("hex");

  const project: Project = {
    projectId,
    projectName: name,
    createdAt: now,
    updatedAt: now,
    owner,
    status,
    executionBlocked: EXECUTION_BLOCKED,
  };

  projectsById.set(projectId, project);
  flushProjectRegistry();

  addTimelineEvent({
    level: "info",
    source: "project-registry",
    message: "Project created",
    metadata: {
      projectId,
      projectName: name,
      owner,
      status,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  emit("project_registry:created", "project-registry", {
    projectId,
    projectName: name,
    owner,
    status,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "project_registry.created",
    source: "project-registry",
    severity: "info",
    category: "runtime",
    payload: { projectId, projectName: name, owner, status, executionBlocked: EXECUTION_BLOCKED },
  });

  logger.info({ projectId, projectName: name, owner, status }, "Project created");
  recordActivity(projectId, "project_created", owner, { projectName: name, status });

  return { success: true, project, executionBlocked: EXECUTION_BLOCKED };
}

export function transitionProjectStatus(
  projectId: string,
  rawTarget: unknown,
): ProjectTransitionResult {
  if (typeof rawTarget !== "string" || !VALID_STATUSES.has(rawTarget)) {
    return {
      success: false,
      error: `Field "status" must be one of: ${Array.from(VALID_STATUSES).sort().join(", ")}`,
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  const targetStatus = rawTarget as ProjectStatus;

  const existing = projectsById.get(projectId);
  if (!existing) {
    return {
      success: false,
      error: `Project not found: "${projectId}"`,
      errorType: "not_found",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const allowed = TRANSITION_TABLE.get(existing.status);
  if (!allowed || !allowed.has(targetStatus)) {
    const allowedList = Array.from(TRANSITION_TABLE.get(existing.status) ?? []).sort().join(", ") || "none";
    return {
      success: false,
      error: `Transition from "${existing.status}" to "${targetStatus}" is not permitted. Allowed targets from "${existing.status}": ${allowedList}`,
      errorType: "invalid_transition",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const previousStatus = existing.status;
  const updated: Project = {
    ...existing,
    status: targetStatus,
    updatedAt: new Date().toISOString(),
  };
  projectsById.set(projectId, updated);
  flushProjectRegistry();

  addTimelineEvent({
    level: "info",
    source: "project-registry",
    message: "Project status transition",
    metadata: {
      projectId,
      projectName: updated.projectName,
      previousStatus,
      currentStatus: targetStatus,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  emit("project_registry:status_changed", "project-registry", {
    projectId,
    previousStatus,
    currentStatus: targetStatus,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "project_registry.status_changed",
    source: "project-registry",
    severity: "info",
    category: "runtime",
    payload: {
      projectId,
      previousStatus,
      currentStatus: targetStatus,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    { projectId, projectName: updated.projectName, previousStatus, currentStatus: targetStatus },
    "Project status transition",
  );
  recordActivity(projectId, "status_transition", "system", {
    previousStatus,
    currentStatus: targetStatus,
  });

  return {
    success: true,
    project: updated,
    previousStatus,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getProject(projectId: string): Project | null {
  return projectsById.get(projectId) ?? null;
}

export function listProjects(): Project[] {
  return Array.from(projectsById.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

// --- Project Membership ---

const VALID_MEMBER_ROLES = new Set<string>([
  "owner", "operator", "maintainer", "observer", "auditor",
]);
const ACTOR_ID_MAX = 128;
const MEMBERS_STORE_KEY = "project-members";

interface StoredMember {
  projectId: string;
  actorId: string;
  role: string;
  addedAt: string;
  executionBlocked: true;
}

// projectId → (actorId → ProjectMember)
const membersMap = new Map<string, Map<string, ProjectMember>>();
let memberFlushCount = 0;
let memberLastFlushedAt: string | null = null;
let memberLoadedOnBoot = 0;

function isValidStoredMember(obj: unknown): obj is StoredMember {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  const m = obj as Record<string, unknown>;
  return (
    typeof m["projectId"] === "string" && m["projectId"].length > 0 &&
    typeof m["actorId"] === "string" && m["actorId"].length > 0 && m["actorId"].length <= ACTOR_ID_MAX &&
    typeof m["role"] === "string" && VALID_MEMBER_ROLES.has(m["role"]) &&
    typeof m["addedAt"] === "string" && m["addedAt"].length > 0 &&
    m["executionBlocked"] === true
  );
}

function flushProjectMembers(): void {
  try {
    const snapshot: StoredMember[] = [];
    for (const [projectId, actorMap] of membersMap) {
      for (const member of actorMap.values()) {
        snapshot.push({
          projectId,
          actorId: member.actorId,
          role: member.role,
          addedAt: member.addedAt,
          executionBlocked: EXECUTION_BLOCKED,
        });
      }
    }
    snapshot.sort(
      (a, b) => a.projectId.localeCompare(b.projectId) || a.addedAt.localeCompare(b.addedAt),
    );
    writeStore<StoredMember[]>(MEMBERS_STORE_KEY, snapshot);
    memberLastFlushedAt = new Date().toISOString();
    memberFlushCount++;
  } catch (err) {
    logger.error({ err }, "Project members flush failed");
  }
}

export function initProjectMembers(): void {
  let booted = 0;
  try {
    const stored = readStore<unknown[]>(MEMBERS_STORE_KEY);
    if (Array.isArray(stored)) {
      for (const raw of stored) {
        if (!isValidStoredMember(raw)) {
          logger.warn({ raw }, "Skipping malformed member entry on boot");
          continue;
        }
        if (!projectsById.has(raw.projectId)) {
          logger.warn(
            { projectId: raw.projectId, actorId: raw.actorId },
            "Skipping orphaned member entry on boot — project not found",
          );
          continue;
        }
        let actorMap = membersMap.get(raw.projectId);
        if (!actorMap) {
          actorMap = new Map();
          membersMap.set(raw.projectId, actorMap);
        }
        if (!actorMap.has(raw.actorId)) {
          actorMap.set(raw.actorId, {
            actorId: raw.actorId,
            role: raw.role as MemberRole,
            addedAt: raw.addedAt,
            executionBlocked: EXECUTION_BLOCKED,
          });
          booted++;
        }
      }
    }
  } catch (err) {
    logger.error({ err }, "Project members load failed — starting empty");
  }
  memberLoadedOnBoot = booted;
  logger.info({ loadedOnBoot: booted }, "Project members initialized");
}

export function addProjectMember(
  projectId: string,
  rawActorId: unknown,
  rawRole: unknown,
): ProjectMembershipResult {
  const actorId = typeof rawActorId === "string" ? rawActorId.trim() : "";
  if (!actorId) {
    return {
      success: false,
      error: 'Field "actorId" is required and must be a non-empty string',
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  if (actorId.length > ACTOR_ID_MAX) {
    return {
      success: false,
      error: `Field "actorId" must not exceed ${ACTOR_ID_MAX} characters`,
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  if (typeof rawRole !== "string" || !VALID_MEMBER_ROLES.has(rawRole)) {
    return {
      success: false,
      error: `Field "role" must be one of: ${Array.from(VALID_MEMBER_ROLES).sort().join(", ")}`,
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  const role = rawRole as MemberRole;

  if (!projectsById.has(projectId)) {
    return {
      success: false,
      error: `Project not found: "${projectId}"`,
      errorType: "not_found",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  let actorMap = membersMap.get(projectId);
  if (actorMap?.has(actorId)) {
    return {
      success: false,
      error: `Actor "${actorId}" is already a member of project "${projectId}"`,
      errorType: "conflict",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const currentMemberCount = actorMap?.size ?? 0;
  const effectiveMaxMembers = getEffectiveMaxMembers(projectId);
  if (currentMemberCount >= effectiveMaxMembers) {
    return {
      success: false,
      error: `Project "${projectId}" member limit of ${effectiveMaxMembers} has been reached`,
      errorType: "capacity",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  if (!actorMap) {
    actorMap = new Map();
    membersMap.set(projectId, actorMap);
  }
  const member: ProjectMember = {
    actorId,
    role,
    addedAt: new Date().toISOString(),
    executionBlocked: EXECUTION_BLOCKED,
  };
  actorMap.set(actorId, member);
  flushProjectMembers();

  addTimelineEvent({
    level: "info",
    source: "project-registry",
    message: "Project member added",
    metadata: { projectId, actorId, role, executionBlocked: EXECUTION_BLOCKED },
  });
  emit("project_registry:member_added", "project-registry", {
    projectId, actorId, role, executionBlocked: EXECUTION_BLOCKED,
  });
  emitRuntimeEvent({
    eventType: "project_registry.member_added",
    source: "project-registry",
    severity: "info",
    category: "runtime",
    payload: { projectId, actorId, role, executionBlocked: EXECUTION_BLOCKED },
  });
  logger.info({ projectId, actorId, role }, "Project member added");
  recordActivity(projectId, "member_added", actorId, { role });

  return { success: true, member, executionBlocked: EXECUTION_BLOCKED };
}

export function listProjectMembers(projectId: string): ProjectMembersListResult {
  if (!projectsById.has(projectId)) {
    return {
      success: false,
      projectId,
      members: [],
      count: 0,
      error: `Project not found: "${projectId}"`,
      errorType: "not_found",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  const actorMap = membersMap.get(projectId);
  const members = actorMap
    ? Array.from(actorMap.values()).sort((a, b) => a.addedAt.localeCompare(b.addedAt))
    : [];
  return {
    success: true,
    projectId,
    members,
    count: members.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function removeProjectMember(
  projectId: string,
  actorId: string,
): ProjectRemoveMemberResult {
  if (!actorId) {
    return {
      success: false,
      error: "Actor ID is required",
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  if (!projectsById.has(projectId)) {
    return {
      success: false,
      error: `Project not found: "${projectId}"`,
      errorType: "not_found",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  const actorMap = membersMap.get(projectId);
  if (!actorMap?.has(actorId)) {
    return {
      success: false,
      error: `Actor "${actorId}" is not a member of project "${projectId}"`,
      errorType: "not_member",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  actorMap.delete(actorId);
  if (actorMap.size === 0) {
    membersMap.delete(projectId);
  }
  flushProjectMembers();

  addTimelineEvent({
    level: "info",
    source: "project-registry",
    message: "Project member removed",
    metadata: { projectId, actorId, executionBlocked: EXECUTION_BLOCKED },
  });
  emit("project_registry:member_removed", "project-registry", {
    projectId, actorId, executionBlocked: EXECUTION_BLOCKED,
  });
  emitRuntimeEvent({
    eventType: "project_registry.member_removed",
    source: "project-registry",
    severity: "info",
    category: "runtime",
    payload: { projectId, actorId, executionBlocked: EXECUTION_BLOCKED },
  });
  logger.info({ projectId, actorId }, "Project member removed");
  recordActivity(projectId, "member_removed", actorId, {});

  return { success: true, removedActorId: actorId, executionBlocked: EXECUTION_BLOCKED };
}

export function getMemberStats(): {
  totalMemberRecords: number;
  memberFlushCount: number;
  memberLastFlushedAt: string | null;
  memberLoadedOnBoot: number;
} {
  let total = 0;
  for (const m of membersMap.values()) total += m.size;
  return { totalMemberRecords: total, memberFlushCount, memberLastFlushedAt, memberLoadedOnBoot };
}

// --- Project Activity Ledger ---

export type ActivityType =
  | "project_created"
  | "status_transition"
  | "member_added"
  | "member_removed"
  | "quota_updated"
  | "quota_reset";

export interface ProjectActivity {
  activityId: string;
  projectId: string;
  type: ActivityType;
  actorId: string;
  createdAt: string;
  metadata: Record<string, string | number | boolean>;
  executionBlocked: true;
}

export interface ActivityLedgerResult {
  success: boolean;
  projectId: string;
  activities: ProjectActivity[];
  count: number;
  total: number;
  filtersApplied: string[];
  error?: string;
  errorType?: "not_found";
  executionBlocked: true;
}

export interface ActivityLedgerStats {
  totalActivityRecords: number;
  activityFlushCount: number;
  activityLastFlushedAt: string | null;
  activityLoadedOnBoot: number;
}

interface StoredActivity {
  activityId: string;
  projectId: string;
  type: string;
  actorId: string;
  createdAt: string;
  metadata: Record<string, string | number | boolean>;
  executionBlocked: true;
}

const VALID_ACTIVITY_TYPES = new Set<string>([
  "project_created",
  "status_transition",
  "member_added",
  "member_removed",
  "quota_updated",
  "quota_reset",
]);
const MAX_ACTIVITIES_PER_PROJECT = 500;
const METADATA_KEY_MAX = 64;
const METADATA_VALUE_MAX = 256;
const METADATA_MAX_KEYS = 20;
const ACTIVITY_STORE_KEY = "project-activity";

// projectId → ProjectActivity[] maintained oldest-first
const activityByProject = new Map<string, ProjectActivity[]>();
let activityFlushCount = 0;
let activityLastFlushedAt: string | null = null;
let activityLoadedOnBoot = 0;

function sanitizeMetadata(raw: unknown): Record<string, string | number | boolean> {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {};
  const out: Record<string, string | number | boolean> = {};
  let count = 0;
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (count >= METADATA_MAX_KEYS) break;
    if (typeof k !== "string" || k.length === 0 || k.length > METADATA_KEY_MAX) continue;
    if (typeof v === "boolean" || typeof v === "number") {
      out[k] = v;
      count++;
    } else if (typeof v === "string") {
      out[k] = v.slice(0, METADATA_VALUE_MAX);
      count++;
    }
  }
  return out;
}

function isValidStoredActivity(obj: unknown): obj is StoredActivity {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  const a = obj as Record<string, unknown>;
  return (
    typeof a["activityId"] === "string" &&
    /^[0-9a-f]{16}$/.test(a["activityId"]) &&
    typeof a["projectId"] === "string" &&
    a["projectId"].length > 0 &&
    typeof a["type"] === "string" &&
    VALID_ACTIVITY_TYPES.has(a["type"]) &&
    typeof a["actorId"] === "string" &&
    a["actorId"].length > 0 &&
    typeof a["createdAt"] === "string" &&
    a["createdAt"].length > 0 &&
    a["metadata"] !== null &&
    typeof a["metadata"] === "object" &&
    !Array.isArray(a["metadata"]) &&
    a["executionBlocked"] === true
  );
}

function flushProjectActivity(): void {
  try {
    const snapshot: StoredActivity[] = [];
    for (const [projectId, entries] of activityByProject) {
      for (const entry of entries) {
        snapshot.push({
          activityId: entry.activityId,
          projectId,
          type: entry.type,
          actorId: entry.actorId,
          createdAt: entry.createdAt,
          metadata: entry.metadata,
          executionBlocked: EXECUTION_BLOCKED,
        });
      }
    }
    snapshot.sort(
      (a, b) =>
        a.projectId.localeCompare(b.projectId) || a.createdAt.localeCompare(b.createdAt),
    );
    writeStore<StoredActivity[]>(ACTIVITY_STORE_KEY, snapshot);
    activityLastFlushedAt = new Date().toISOString();
    activityFlushCount++;
  } catch (err) {
    logger.error({ err }, "Project activity flush failed");
  }
}

export function initProjectActivity(): void {
  let booted = 0;
  try {
    const stored = readStore<unknown[]>(ACTIVITY_STORE_KEY);
    if (Array.isArray(stored)) {
      for (const raw of stored) {
        if (!isValidStoredActivity(raw)) {
          logger.warn({ raw }, "Skipping malformed activity entry on boot");
          continue;
        }
        if (!projectsById.has(raw.projectId)) {
          logger.warn(
            { projectId: raw.projectId, activityId: raw.activityId },
            "Skipping orphaned activity entry on boot — project not found",
          );
          continue;
        }
        let entries = activityByProject.get(raw.projectId);
        if (!entries) {
          entries = [];
          activityByProject.set(raw.projectId, entries);
        }
        if (entries.length >= MAX_ACTIVITIES_PER_PROJECT) {
          entries.shift();
        }
        entries.push({
          activityId: raw.activityId,
          projectId: raw.projectId,
          type: raw.type as ActivityType,
          actorId: raw.actorId,
          createdAt: raw.createdAt,
          metadata: sanitizeMetadata(raw.metadata),
          executionBlocked: EXECUTION_BLOCKED,
        });
        booted++;
      }
    }
  } catch (err) {
    logger.error({ err }, "Project activity load failed — starting empty");
  }
  activityLoadedOnBoot = booted;
  logger.info({ loadedOnBoot: booted }, "Project activity ledger initialized");
}

export function recordActivity(
  projectId: string,
  type: ActivityType,
  actorId: string,
  metadata: Record<string, string | number | boolean>,
): void {
  let entries = activityByProject.get(projectId);
  if (!entries) {
    entries = [];
    activityByProject.set(projectId, entries);
  }
  const effectiveMaxEntries = getEffectiveMaxActivityEntries(projectId);
  while (entries.length >= effectiveMaxEntries) {
    entries.shift();
  }
  const activity: ProjectActivity = {
    activityId: randomBytes(8).toString("hex"),
    projectId,
    type,
    actorId,
    createdAt: new Date().toISOString(),
    metadata: sanitizeMetadata(metadata),
    executionBlocked: EXECUTION_BLOCKED,
  };
  entries.push(activity);
  flushProjectActivity();
}

export function getProjectActivity(
  projectId: string,
  filters: { type?: string; actorId?: string; limit?: number },
): ActivityLedgerResult {
  if (!projectsById.has(projectId)) {
    return {
      success: false,
      projectId,
      activities: [],
      count: 0,
      total: 0,
      filtersApplied: [],
      error: `Project not found: "${projectId}"`,
      errorType: "not_found",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const raw = activityByProject.get(projectId) ?? [];
  const filtersApplied: string[] = [];
  let filtered = [...raw];

  if (typeof filters.type === "string" && VALID_ACTIVITY_TYPES.has(filters.type)) {
    filtered = filtered.filter((a) => a.type === filters.type);
    filtersApplied.push("type");
  }

  if (typeof filters.actorId === "string" && filters.actorId.length > 0) {
    filtered = filtered.filter((a) => a.actorId === filters.actorId);
    filtersApplied.push("actorId");
  }

  const total = filtered.length;
  const limit =
    typeof filters.limit === "number" &&
    filters.limit > 0 &&
    filters.limit <= 100
      ? filters.limit
      : 50;

  const activities = filtered.slice().reverse().slice(0, limit);

  return {
    success: true,
    projectId,
    activities,
    count: activities.length,
    total,
    filtersApplied,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getActivityStats(): ActivityLedgerStats {
  let total = 0;
  for (const entries of activityByProject.values()) total += entries.length;
  return {
    totalActivityRecords: total,
    activityFlushCount,
    activityLastFlushedAt,
    activityLoadedOnBoot,
  };
}

// --- Project Resource Quotas ---

const DEFAULT_MAX_MEMBERS = 10;
const DEFAULT_MAX_ACTIVITY_ENTRIES = 500;
const DEFAULT_MAX_TAGS = 10;

const QUOTA_MAX_MEMBERS_MIN = 1;
const QUOTA_MAX_MEMBERS_MAX = 50;
const QUOTA_MAX_ACTIVITY_ENTRIES_MIN = 100;
const QUOTA_MAX_ACTIVITY_ENTRIES_MAX = 500;
const QUOTA_MAX_TAGS_MIN = 0;
const QUOTA_MAX_TAGS_MAX = 20;

const QUOTA_STORE_KEY = "project-quotas";

export interface ProjectQuota {
  projectId: string;
  maxMembers: number;
  maxActivityEntries: number;
  maxTags: number;
  updatedAt: string;
  executionBlocked: true;
}

export interface ProjectQuotaResult {
  success: boolean;
  projectId: string;
  quota: ProjectQuota;
  isDefault: boolean;
  error?: string;
  errorType?: "not_found" | "validation";
  executionBlocked: true;
}

export interface ProjectQuotaResetResult {
  success: boolean;
  projectId: string;
  quota: ProjectQuota;
  error?: string;
  errorType?: "not_found";
  executionBlocked: true;
}

export interface QuotaUpdateInput {
  maxMembers?: unknown;
  maxActivityEntries?: unknown;
  maxTags?: unknown;
}

interface StoredQuota {
  projectId: string;
  maxMembers: number;
  maxActivityEntries: number;
  maxTags: number;
  updatedAt: string;
  executionBlocked: true;
}

// projectId → ProjectQuota (absent key means "use all defaults")
const quotasByProject = new Map<string, ProjectQuota>();
let quotaFlushCount = 0;
let quotaLastFlushedAt: string | null = null;
let quotaLoadedOnBoot = 0;

function makeDefaultQuota(projectId: string): ProjectQuota {
  return {
    projectId,
    maxMembers: DEFAULT_MAX_MEMBERS,
    maxActivityEntries: DEFAULT_MAX_ACTIVITY_ENTRIES,
    maxTags: DEFAULT_MAX_TAGS,
    updatedAt: new Date().toISOString(),
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function isValidStoredQuota(obj: unknown): obj is StoredQuota {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
  const q = obj as Record<string, unknown>;
  return (
    typeof q["projectId"] === "string" &&
    q["projectId"].length > 0 &&
    typeof q["maxMembers"] === "number" &&
    Number.isInteger(q["maxMembers"]) &&
    (q["maxMembers"] as number) >= QUOTA_MAX_MEMBERS_MIN &&
    (q["maxMembers"] as number) <= QUOTA_MAX_MEMBERS_MAX &&
    typeof q["maxActivityEntries"] === "number" &&
    Number.isInteger(q["maxActivityEntries"]) &&
    (q["maxActivityEntries"] as number) >= QUOTA_MAX_ACTIVITY_ENTRIES_MIN &&
    (q["maxActivityEntries"] as number) <= QUOTA_MAX_ACTIVITY_ENTRIES_MAX &&
    typeof q["maxTags"] === "number" &&
    Number.isInteger(q["maxTags"]) &&
    (q["maxTags"] as number) >= QUOTA_MAX_TAGS_MIN &&
    (q["maxTags"] as number) <= QUOTA_MAX_TAGS_MAX &&
    typeof q["updatedAt"] === "string" &&
    q["updatedAt"].length > 0 &&
    q["executionBlocked"] === true
  );
}

function flushProjectQuotas(): void {
  try {
    const snapshot: StoredQuota[] = Array.from(quotasByProject.values()).sort(
      (a, b) => a.projectId.localeCompare(b.projectId),
    );
    writeStore<StoredQuota[]>(QUOTA_STORE_KEY, snapshot);
    quotaLastFlushedAt = new Date().toISOString();
    quotaFlushCount++;
  } catch (err) {
    logger.error({ err }, "Project quota flush failed");
  }
}

export function initProjectQuotas(): void {
  let booted = 0;
  try {
    const stored = readStore<unknown[]>(QUOTA_STORE_KEY);
    if (Array.isArray(stored)) {
      for (const raw of stored) {
        if (!isValidStoredQuota(raw)) {
          logger.warn({ raw }, "Skipping malformed quota entry on boot");
          continue;
        }
        if (!projectsById.has(raw.projectId)) {
          logger.warn(
            { projectId: raw.projectId },
            "Skipping orphaned quota entry on boot — project not found",
          );
          continue;
        }
        quotasByProject.set(raw.projectId, {
          projectId: raw.projectId,
          maxMembers: raw.maxMembers,
          maxActivityEntries: raw.maxActivityEntries,
          maxTags: raw.maxTags,
          updatedAt: raw.updatedAt,
          executionBlocked: EXECUTION_BLOCKED,
        });
        booted++;
      }
    }
  } catch (err) {
    logger.error({ err }, "Project quota load failed — starting empty");
  }
  quotaLoadedOnBoot = booted;
  logger.info({ loadedOnBoot: booted }, "Project quota registry initialized");
}

export function getEffectiveMaxMembers(projectId: string): number {
  return quotasByProject.get(projectId)?.maxMembers ?? DEFAULT_MAX_MEMBERS;
}

export function getEffectiveMaxActivityEntries(projectId: string): number {
  return quotasByProject.get(projectId)?.maxActivityEntries ?? DEFAULT_MAX_ACTIVITY_ENTRIES;
}

export function getProjectQuota(projectId: string): ProjectQuotaResult {
  if (!projectsById.has(projectId)) {
    return {
      success: false,
      projectId,
      quota: makeDefaultQuota(projectId),
      isDefault: true,
      error: `Project not found: "${projectId}"`,
      errorType: "not_found",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }
  const stored = quotasByProject.get(projectId);
  const isDefault = stored === undefined;
  const quota = stored ?? makeDefaultQuota(projectId);
  return {
    success: true,
    projectId,
    quota,
    isDefault,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function setProjectQuota(
  projectId: string,
  input: QuotaUpdateInput,
): ProjectQuotaResult {
  if (!projectsById.has(projectId)) {
    return {
      success: false,
      projectId,
      quota: makeDefaultQuota(projectId),
      isDefault: true,
      error: `Project not found: "${projectId}"`,
      errorType: "not_found",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const existing = quotasByProject.get(projectId);
  const errors: string[] = [];

  let maxMembers: number;
  if (input.maxMembers !== undefined) {
    const v = input.maxMembers;
    if (
      typeof v !== "number" ||
      !Number.isInteger(v) ||
      v < QUOTA_MAX_MEMBERS_MIN ||
      v > QUOTA_MAX_MEMBERS_MAX
    ) {
      errors.push(
        `"maxMembers" must be an integer between ${QUOTA_MAX_MEMBERS_MIN} and ${QUOTA_MAX_MEMBERS_MAX}`,
      );
      maxMembers = existing?.maxMembers ?? DEFAULT_MAX_MEMBERS;
    } else {
      maxMembers = v;
    }
  } else {
    maxMembers = existing?.maxMembers ?? DEFAULT_MAX_MEMBERS;
  }

  let maxActivityEntries: number;
  if (input.maxActivityEntries !== undefined) {
    const v = input.maxActivityEntries;
    if (
      typeof v !== "number" ||
      !Number.isInteger(v) ||
      v < QUOTA_MAX_ACTIVITY_ENTRIES_MIN ||
      v > QUOTA_MAX_ACTIVITY_ENTRIES_MAX
    ) {
      errors.push(
        `"maxActivityEntries" must be an integer between ${QUOTA_MAX_ACTIVITY_ENTRIES_MIN} and ${QUOTA_MAX_ACTIVITY_ENTRIES_MAX}`,
      );
      maxActivityEntries = existing?.maxActivityEntries ?? DEFAULT_MAX_ACTIVITY_ENTRIES;
    } else {
      maxActivityEntries = v;
    }
  } else {
    maxActivityEntries = existing?.maxActivityEntries ?? DEFAULT_MAX_ACTIVITY_ENTRIES;
  }

  let maxTags: number;
  if (input.maxTags !== undefined) {
    const v = input.maxTags;
    if (
      typeof v !== "number" ||
      !Number.isInteger(v) ||
      v < QUOTA_MAX_TAGS_MIN ||
      v > QUOTA_MAX_TAGS_MAX
    ) {
      errors.push(
        `"maxTags" must be an integer between ${QUOTA_MAX_TAGS_MIN} and ${QUOTA_MAX_TAGS_MAX}`,
      );
      maxTags = existing?.maxTags ?? DEFAULT_MAX_TAGS;
    } else {
      maxTags = v;
    }
  } else {
    maxTags = existing?.maxTags ?? DEFAULT_MAX_TAGS;
  }

  if (errors.length > 0) {
    return {
      success: false,
      projectId,
      quota: existing ?? makeDefaultQuota(projectId),
      isDefault: existing === undefined,
      error: errors.join("; "),
      errorType: "validation",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const quota: ProjectQuota = {
    projectId,
    maxMembers,
    maxActivityEntries,
    maxTags,
    updatedAt: new Date().toISOString(),
    executionBlocked: EXECUTION_BLOCKED,
  };
  quotasByProject.set(projectId, quota);
  flushProjectQuotas();

  logger.info({ projectId, maxMembers, maxActivityEntries, maxTags }, "Project quota updated");
  recordActivity(projectId, "quota_updated", "system", { maxMembers, maxActivityEntries, maxTags });

  return {
    success: true,
    projectId,
    quota,
    isDefault: false,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function resetProjectQuota(projectId: string): ProjectQuotaResetResult {
  if (!projectsById.has(projectId)) {
    return {
      success: false,
      projectId,
      quota: makeDefaultQuota(projectId),
      error: `Project not found: "${projectId}"`,
      errorType: "not_found",
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  quotasByProject.delete(projectId);
  flushProjectQuotas();

  const quota = makeDefaultQuota(projectId);
  logger.info({ projectId }, "Project quota reset to defaults");
  recordActivity(projectId, "quota_reset", "system", {
    maxMembers: DEFAULT_MAX_MEMBERS,
    maxActivityEntries: DEFAULT_MAX_ACTIVITY_ENTRIES,
    maxTags: DEFAULT_MAX_TAGS,
  });

  return {
    success: true,
    projectId,
    quota,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Product Layer Health Aggregation (Phase 81) ---

export interface ProductLayerHealth {
  checkedAt: string;
  registryOperational: boolean;
  projectCount: number;
  maxProjects: number;
  atCapacity: boolean;
  totalMembers: number;
  totalActivityRecords: number;
  customQuotaCount: number;
  storeKeys: string[];
  executionBlocked: true;
}

export function getProductLayerHealth(): ProductLayerHealth {
  const status = getProjectRegistryStatus();
  const memberStats = getMemberStats();
  const activityStats = getActivityStats();
  return {
    checkedAt: new Date().toISOString(),
    registryOperational: status.operational,
    projectCount: status.projectCount,
    maxProjects: status.maxProjects,
    atCapacity: status.atCapacity,
    totalMembers: memberStats.totalMemberRecords,
    totalActivityRecords: activityStats.totalActivityRecords,
    customQuotaCount: quotasByProject.size,
    storeKeys: [STORE_KEY, MEMBERS_STORE_KEY, ACTIVITY_STORE_KEY, QUOTA_STORE_KEY],
    executionBlocked: EXECUTION_BLOCKED,
  };
}
