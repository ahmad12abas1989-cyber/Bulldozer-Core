// sandboxWriteCommitEnableCore.ts
// Phase 324 — Sandbox Write Commit Enable Descriptor Core Skeleton
// In-memory sandbox write commit enable descriptor engine.
// Layer 27 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit stack.
// Prepares the sandbox write commit enable layer.
// Preserves sandbox-approved-only target scope from layers 24–26.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. commitEnabled=false — commit has not been enabled.
// sandboxWriteCommitEnablePrepared=true — descriptor-readiness established for a future first sandbox write activation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstSandboxWriteCommitRecord }            from "./firstSandboxWriteCommitCore.js";
import type { RuntimeWriteExecutorRecord }               from "./runtimeWriteExecutorCore.js";
import type { FirstActualSandboxWriteOperationRecord }   from "./firstActualSandboxWriteOperationCore.js";
import type { ActualSandboxWriteExecutionGateRecord }    from "./actualSandboxWriteExecutionGateCore.js";
import type { FirstScopedSandboxWriteActivationRecord }  from "./firstScopedSandboxWriteActivationCore.js";
import type { ControlledExecutionRecord }                from "./controlledExecutionCore.js";
import { randomUUID }                                    from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type CommitEnableState = "descriptor_sandbox_write_commit_enable_pending";

export type CommitEnableCheckRule =
  | "sandbox_write_commit_exists"
  | "runtime_write_executor_exists"
  | "actual_write_operation_exists"
  | "execution_gate_exists"
  | "scoped_activation_exists"
  | "execution_record_exists"
  | "commit_bound_to_executor"
  | "executor_bound_to_write_operation"
  | "write_operation_bound_to_execution_gate"
  | "execution_gate_bound_to_scoped_activation"
  | "commit_enable_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface CommitEnableCheck {
  readonly rule: CommitEnableCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface CommitEnableBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedCommitEnableReference {
  readonly sandboxWriteCommitId:              string;
  readonly runtimeWriteExecutorId:            string;
  readonly actualWriteOperationId:            string;
  readonly writeExecutionGateId:              string;
  readonly rollbackSnapshotId:                string;
  readonly sandboxWriteCommitEnablePrepared:  true;
  readonly sandboxWriteCommitEnabled:         false;
  readonly runtimeWriteExecutorEnabled:       false;
  readonly actualWritesEnabled:               false;
  readonly rollbackChainValid:                boolean;
  readonly referenceNote:                     string;
}

export interface CommitEnableReadinessReport {
  readonly sandboxWriteCommitEnablePrepared:  true;
  readonly sandboxWriteCommitEnabled:         false;
  readonly runtimeWriteExecutorEnabled:       false;
  readonly writeExecutionGateEnabled:         false;
  readonly scopedActivationEnabled:           false;
  readonly writePermissionEnabled:            false;
  readonly mutationSwitchEnabled:             false;
  readonly guardedWriteEnabled:               false;
  readonly actualWritesEnabled:               false;
  readonly realWritesEnabled:                 false;
  readonly approvalRequired:                  true;
  readonly allChecksPass:                     boolean;
  readonly blockedReasonCount:                number;
  readonly rollbackChainValid:                boolean;
  readonly targetScope:                       "sandbox_approved_only";
  readonly summary:                           string;
}

export interface SandboxWriteCommitEnableRecord {
  readonly sandboxWriteCommitEnableId:        string;
  readonly commitEnableState:                 CommitEnableState;
  readonly approvalRequired:                  true;
  readonly sandboxWriteCommitEnablePrepared:  true;
  readonly sandboxWriteCommitEnabled:         false;
  readonly runtimeWriteExecutorEnabled:       false;
  readonly actualWritesEnabled:               false;
  readonly filesystemMutationBlocked:         true;
  readonly motherCoreMutationBlocked:         true;
  readonly vaultMutationBlocked:              true;
  readonly shellBlocked:                      true;
  readonly networkBlocked:                    true;
  readonly targetScope:                       "sandbox_approved_only";
  readonly implementationPhase:               "descriptor_only";
  readonly sandboxWriteCommitId:              string;
  readonly runtimeWriteExecutorId:            string;
  readonly actualWriteOperationId:            string;
  readonly writeExecutionGateId:              string;
  readonly scopedWriteActivationId:           string;
  readonly controlledExecutionId:             string;
  readonly commitEnableChecks:                readonly CommitEnableCheck[];
  readonly commitEnableBlockedReasons:        readonly CommitEnableBlockedReason[];
  readonly commitEnableReadinessReport:       CommitEnableReadinessReport;
  readonly linkedCommitEnableReference:       LinkedCommitEnableReference;
  readonly createdAt:                         string;
}

export interface CreateSandboxWriteCommitEnableInput {
  readonly commitRecord:             FirstSandboxWriteCommitRecord;
  readonly executorRecord:           RuntimeWriteExecutorRecord;
  readonly writeOperationRecord:     FirstActualSandboxWriteOperationRecord;
  readonly writeExecutionGateRecord: ActualSandboxWriteExecutionGateRecord;
  readonly scopedActivationRecord:   FirstScopedSandboxWriteActivationRecord;
  readonly executionRecord:          ControlledExecutionRecord;
}

export interface SandboxWriteCommitEnableSummary {
  readonly total:                             number;
  readonly byState:                           Record<CommitEnableState, number>;
  readonly sandboxWriteCommitEnablePrepared:  true;
  readonly sandboxWriteCommitEnabled:         false;
  readonly runtimeWriteExecutorEnabled:       false;
  readonly actualWritesEnabled:               false;
  readonly approvalRequired:                  true;
  readonly filesystemMutationBlocked:         true;
  readonly motherCoreMutationBlocked:         true;
  readonly targetScope:                       "sandbox_approved_only";
  readonly commitEnableState:                 CommitEnableState;
  readonly implementationPhase:               "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: SandboxWriteCommitEnableRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateSandboxWriteCommitEnableInput): readonly CommitEnableCheck[] {
  const { commitRecord, executorRecord, writeOperationRecord, writeExecutionGateRecord, scopedActivationRecord, executionRecord } = input;

  const commitExists  = commitRecord.sandboxWriteCommitId.length > 0;
  const execExists    = executorRecord.runtimeWriteExecutorId.length > 0;
  const opExists      = writeOperationRecord.actualWriteOperationId.length > 0;
  const gateExists    = writeExecutionGateRecord.writeExecutionGateId.length > 0;
  const scopedExists  = scopedActivationRecord.scopedWriteActivationId.length > 0;
  const ctrlExists    = executionRecord.controlledExecutionId.length > 0;

  const commitBound   = commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId;
  const execBound     = executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId;
  const opBound       = writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId;
  const gateBound     = writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId;

  return [
    {
      rule: "sandbox_write_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`
        : "commitRecord.sandboxWriteCommitId is empty",
    },
    {
      rule: "runtime_write_executor_exists",
      pass: execExists,
      note: execExists
        ? `runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`
        : "executorRecord.runtimeWriteExecutorId is empty",
    },
    {
      rule: "actual_write_operation_exists",
      pass: opExists,
      note: opExists
        ? `actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`
        : "writeOperationRecord.actualWriteOperationId is empty",
    },
    {
      rule: "execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`
        : "writeExecutionGateRecord.writeExecutionGateId is empty",
    },
    {
      rule: "scoped_activation_exists",
      pass: scopedExists,
      note: scopedExists
        ? `scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`
        : "scopedActivationRecord.scopedWriteActivationId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "commit_bound_to_executor",
      pass: commitBound,
      note: commitBound
        ? `commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId (${executorRecord.runtimeWriteExecutorId})`
        : `commit/executor mismatch: commit.runtimeWriteExecutorId=${commitRecord.runtimeWriteExecutorId} vs executor.runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`,
    },
    {
      rule: "executor_bound_to_write_operation",
      pass: execBound,
      note: execBound
        ? `executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId (${writeOperationRecord.actualWriteOperationId})`
        : `executor/write-operation mismatch: executor.actualWriteOperationId=${executorRecord.actualWriteOperationId} vs op.actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`,
    },
    {
      rule: "write_operation_bound_to_execution_gate",
      pass: opBound,
      note: opBound
        ? `writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId (${writeExecutionGateRecord.writeExecutionGateId})`
        : `write-operation/execution-gate mismatch: op.writeExecutionGateId=${writeOperationRecord.writeExecutionGateId} vs gate.writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`,
    },
    {
      rule: "execution_gate_bound_to_scoped_activation",
      pass: gateBound,
      note: gateBound
        ? `writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId (${scopedActivationRecord.scopedWriteActivationId})`
        : `execution-gate/scoped-activation mismatch: gate.scopedWriteActivationId=${writeExecutionGateRecord.scopedWriteActivationId} vs scoped.scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`,
    },
    {
      rule: "commit_enable_still_disabled",
      pass: true,
      note: "sandboxWriteCommitEnabled=false — compile-time literal; no commit enable activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "commitEnableState=descriptor_sandbox_write_commit_enable_pending — output is a descriptor only; sandbox write commit enable is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly CommitEnableCheck[]): readonly CommitEnableBlockedReason[] {
  const staticReasons: CommitEnableBlockedReason[] = [
    { code: "commit_enable_disabled",  reason: "sandboxWriteCommitEnabled=false — compile-time literal; an explicit sandbox write commit activation phase must enable the commit before any sandbox write target can be touched",                                                                                                                                          static: true },
    { code: "approval_required",       reason: "approvalRequired=true — explicit operator approval is required before the sandbox write commit can be enabled",                                                                                                                                                                                                              static: true },
    { code: "actual_writes_disabled",  reason: "actualWritesEnabled=false — compile-time literal across all 27 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, and sandbox-write-commit layers", static: true },
  ];
  const dynamicReasons: CommitEnableBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedCommitEnableReference(
  input: CreateSandboxWriteCommitEnableInput,
  rollbackChainValid: boolean,
): LinkedCommitEnableReference {
  const { commitRecord, executorRecord, writeOperationRecord, writeExecutionGateRecord } = input;
  return {
    sandboxWriteCommitId:             commitRecord.sandboxWriteCommitId,
    runtimeWriteExecutorId:           executorRecord.runtimeWriteExecutorId,
    actualWriteOperationId:           writeOperationRecord.actualWriteOperationId,
    writeExecutionGateId:             writeExecutionGateRecord.writeExecutionGateId,
    rollbackSnapshotId:               commitRecord.linkedCommitReference.rollbackSnapshotId,
    sandboxWriteCommitEnablePrepared: true,
    sandboxWriteCommitEnabled:        false,
    runtimeWriteExecutorEnabled:      false,
    actualWritesEnabled:              false,
    rollbackChainValid,
    referenceNote: "linked commit enable reference sources rollbackSnapshotId from commitRecord.linkedCommitReference; sandbox write commit enable disabled; sandbox write commit disabled; runtime write executor disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createSandboxWriteCommitEnableRecord(
  input: CreateSandboxWriteCommitEnableInput,
): SandboxWriteCommitEnableRecord {
  const { commitRecord, executorRecord, writeOperationRecord, writeExecutionGateRecord, scopedActivationRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = commitRecord.commitReadinessReport.rollbackChainValid;

  const allChecksPass   = checks.every((c) => c.pass);
  const blockedReasons  = buildBlockedReasons(checks);
  const linkedRef       = buildLinkedCommitEnableReference(input, rollbackChainValid);

  const commitEnableReadinessReport: CommitEnableReadinessReport = {
    sandboxWriteCommitEnablePrepared:  true,
    sandboxWriteCommitEnabled:         false,
    runtimeWriteExecutorEnabled:       false,
    writeExecutionGateEnabled:         false,
    scopedActivationEnabled:           false,
    writePermissionEnabled:            false,
    mutationSwitchEnabled:             false,
    guardedWriteEnabled:               false,
    actualWritesEnabled:               false,
    realWritesEnabled:                 false,
    approvalRequired:                  true,
    allChecksPass,
    blockedReasonCount:                blockedReasons.length,
    rollbackChainValid,
    targetScope:                       "sandbox_approved_only",
    summary: `commitEnableState=descriptor_sandbox_write_commit_enable_pending; sandboxWriteCommitEnabled=false; runtimeWriteExecutorEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: SandboxWriteCommitEnableRecord = {
    sandboxWriteCommitEnableId:        randomUUID(),
    commitEnableState:                 "descriptor_sandbox_write_commit_enable_pending",
    approvalRequired:                  true,
    sandboxWriteCommitEnablePrepared:  true,
    sandboxWriteCommitEnabled:         false,
    runtimeWriteExecutorEnabled:       false,
    actualWritesEnabled:               false,
    filesystemMutationBlocked:         true,
    motherCoreMutationBlocked:         true,
    vaultMutationBlocked:              true,
    shellBlocked:                      true,
    networkBlocked:                    true,
    targetScope:                       "sandbox_approved_only",
    implementationPhase:               "descriptor_only",
    sandboxWriteCommitId:              commitRecord.sandboxWriteCommitId,
    runtimeWriteExecutorId:            executorRecord.runtimeWriteExecutorId,
    actualWriteOperationId:            writeOperationRecord.actualWriteOperationId,
    writeExecutionGateId:              writeExecutionGateRecord.writeExecutionGateId,
    scopedWriteActivationId:           scopedActivationRecord.scopedWriteActivationId,
    controlledExecutionId:             executionRecord.controlledExecutionId,
    commitEnableChecks:                checks,
    commitEnableBlockedReasons:        blockedReasons,
    commitEnableReadinessReport,
    linkedCommitEnableReference:       linkedRef,
    createdAt:                         new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listSandboxWriteCommitEnableRecords(): readonly SandboxWriteCommitEnableRecord[] {
  return _store.slice();
}

export function getSandboxWriteCommitEnableSummary(): SandboxWriteCommitEnableSummary {
  return {
    total:                             _store.length,
    byState:                           { descriptor_sandbox_write_commit_enable_pending: _store.length },
    sandboxWriteCommitEnablePrepared:  true,
    sandboxWriteCommitEnabled:         false,
    runtimeWriteExecutorEnabled:       false,
    actualWritesEnabled:               false,
    approvalRequired:                  true,
    filesystemMutationBlocked:         true,
    motherCoreMutationBlocked:         true,
    targetScope:                       "sandbox_approved_only",
    commitEnableState:                 "descriptor_sandbox_write_commit_enable_pending",
    implementationPhase:               "descriptor_only",
  };
}
