// actualSandboxWriteExecutionGateCore.ts
// Phase 312 — Actual Sandbox Write Execution Gate Core Skeleton
// In-memory actual sandbox write execution gate descriptor engine.
// Layer 23 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation stack.
// Defines the final execution gate before the first real sandbox write.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// writeExecutionGateEnabled=false — the write execution gate has not been opened.
// writeExecutionGatePrepared=true — descriptor-readiness established for a future first real sandbox write operation.

import type { FirstScopedSandboxWriteActivationRecord } from "./firstScopedSandboxWriteActivationCore.js";
import type { ActualSandboxWritePermissionGateRecord }   from "./actualSandboxWritePermissionGateCore.js";
import type { FirstActualSandboxMutationSwitchRecord }   from "./firstActualSandboxMutationSwitchCore.js";
import type { FirstGuardedWriteEnableRecord }             from "./firstGuardedWriteEnableCore.js";
import type { FirstBridgeOpenRecord }                     from "./firstBridgeOpenCore.js";
import type { ControlledExecutionRecord }                  from "./controlledExecutionCore.js";
import { randomUUID }                                      from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type WriteExecutionGateState = "descriptor_write_execution_gate_pending";

export type ExecutionGateCheckRule =
  | "scoped_activation_exists"
  | "write_permission_gate_exists"
  | "mutation_switch_exists"
  | "guarded_write_enable_exists"
  | "bridge_open_exists"
  | "execution_record_exists"
  | "scoped_activation_bound_to_permission_gate"
  | "permission_gate_bound_to_mutation_switch"
  | "mutation_switch_bound_to_guarded_enable"
  | "guarded_enable_bound_to_bridge_open"
  | "write_execution_gate_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface ExecutionGateCheck {
  readonly rule: ExecutionGateCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface ExecutionGateBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedExecutionGateReference {
  readonly scopedWriteActivationId:    string;
  readonly writePermissionGateId:      string;
  readonly mutationSwitchId:           string;
  readonly guardedWriteEnableId:       string;
  readonly rollbackSnapshotId:         string;
  readonly writeExecutionGatePrepared: true;
  readonly writeExecutionGateEnabled:  false;
  readonly scopedActivationEnabled:    false;
  readonly writePermissionEnabled:     false;
  readonly rollbackChainValid:         boolean;
  readonly referenceNote:              string;
}

export interface ExecutionGateReadinessReport {
  readonly writeExecutionGatePrepared:  true;
  readonly writeExecutionGateEnabled:   false;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly summary:                     string;
}

export interface ActualSandboxWriteExecutionGateRecord {
  readonly writeExecutionGateId:        string;
  readonly executionGateState:          WriteExecutionGateState;
  readonly approvalRequired:            true;
  readonly writeExecutionGatePrepared:  true;
  readonly writeExecutionGateEnabled:   false;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly bridgeOpenEnabled:           false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly implementationPhase:         "descriptor_only";
  readonly scopedWriteActivationId:     string;
  readonly writePermissionGateId:       string;
  readonly mutationSwitchId:            string;
  readonly guardedWriteEnableId:        string;
  readonly bridgeOpenId:                string;
  readonly controlledExecutionId:       string;
  readonly executionGateChecks:         readonly ExecutionGateCheck[];
  readonly executionGateBlockedReasons: readonly ExecutionGateBlockedReason[];
  readonly executionGateReadinessReport: ExecutionGateReadinessReport;
  readonly linkedExecutionGateReference: LinkedExecutionGateReference;
  readonly createdAt:                   string;
}

export interface CreateExecutionGateInput {
  readonly scopedActivationRecord:   FirstScopedSandboxWriteActivationRecord;
  readonly writePermissionGateRecord: ActualSandboxWritePermissionGateRecord;
  readonly mutationSwitchRecord:     FirstActualSandboxMutationSwitchRecord;
  readonly guardedWriteEnableRecord: FirstGuardedWriteEnableRecord;
  readonly bridgeOpenRecord:         FirstBridgeOpenRecord;
  readonly executionRecord:          ControlledExecutionRecord;
}

export interface ActualSandboxWriteExecutionGateSummary {
  readonly total:                       number;
  readonly byState:                     Record<WriteExecutionGateState, number>;
  readonly writeExecutionGatePrepared:  true;
  readonly writeExecutionGateEnabled:   false;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly executionGateState:          WriteExecutionGateState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: ActualSandboxWriteExecutionGateRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateExecutionGateInput): readonly ExecutionGateCheck[] {
  const { scopedActivationRecord, writePermissionGateRecord, mutationSwitchRecord, guardedWriteEnableRecord, bridgeOpenRecord, executionRecord } = input;

  const scopedExists     = scopedActivationRecord.scopedWriteActivationId.length > 0;
  const gateExists       = writePermissionGateRecord.writePermissionGateId.length > 0;
  const switchExists     = mutationSwitchRecord.mutationSwitchId.length > 0;
  const guardedExists    = guardedWriteEnableRecord.guardedWriteEnableId.length > 0;
  const bridgeOpenExists = bridgeOpenRecord.bridgeOpenId.length > 0;
  const executionExists  = executionRecord.controlledExecutionId.length > 0;

  const scopedBound      = scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId;
  const gateBound        = writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId;
  const switchBound      = mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId;
  const guardedBound     = guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId;

  return [
    {
      rule: "scoped_activation_exists",
      pass: scopedExists,
      note: scopedExists
        ? `scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`
        : "scopedActivationRecord.scopedWriteActivationId is empty",
    },
    {
      rule: "write_permission_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`
        : "writePermissionGateRecord.writePermissionGateId is empty",
    },
    {
      rule: "mutation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`
        : "mutationSwitchRecord.mutationSwitchId is empty",
    },
    {
      rule: "guarded_write_enable_exists",
      pass: guardedExists,
      note: guardedExists
        ? `guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`
        : "guardedWriteEnableRecord.guardedWriteEnableId is empty",
    },
    {
      rule: "bridge_open_exists",
      pass: bridgeOpenExists,
      note: bridgeOpenExists
        ? `bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`
        : "bridgeOpenRecord.bridgeOpenId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "scoped_activation_bound_to_permission_gate",
      pass: scopedBound,
      note: scopedBound
        ? `scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId (${writePermissionGateRecord.writePermissionGateId})`
        : `scoped-activation/permission-gate mismatch: scoped.writePermissionGateId=${scopedActivationRecord.writePermissionGateId} vs gate.writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`,
    },
    {
      rule: "permission_gate_bound_to_mutation_switch",
      pass: gateBound,
      note: gateBound
        ? `writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId (${mutationSwitchRecord.mutationSwitchId})`
        : `permission-gate/mutation-switch mismatch: gate.mutationSwitchId=${writePermissionGateRecord.mutationSwitchId} vs switch.mutationSwitchId=${mutationSwitchRecord.mutationSwitchId}`,
    },
    {
      rule: "mutation_switch_bound_to_guarded_enable",
      pass: switchBound,
      note: switchBound
        ? `mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId (${guardedWriteEnableRecord.guardedWriteEnableId})`
        : `mutation-switch/guarded-enable mismatch: switch.guardedWriteEnableId=${mutationSwitchRecord.guardedWriteEnableId} vs guarded.guardedWriteEnableId=${guardedWriteEnableRecord.guardedWriteEnableId}`,
    },
    {
      rule: "guarded_enable_bound_to_bridge_open",
      pass: guardedBound,
      note: guardedBound
        ? `guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId (${bridgeOpenRecord.bridgeOpenId})`
        : `guarded-enable/bridge-open mismatch: guarded.bridgeOpenId=${guardedWriteEnableRecord.bridgeOpenId} vs bridgeOpen.bridgeOpenId=${bridgeOpenRecord.bridgeOpenId}`,
    },
    {
      rule: "write_execution_gate_still_disabled",
      pass: true,
      note: "writeExecutionGateEnabled=false — compile-time literal; no write execution phase has opened this gate",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "executionGateState=descriptor_write_execution_gate_pending — output is a descriptor only; write execution gate is not yet live",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly ExecutionGateCheck[]): readonly ExecutionGateBlockedReason[] {
  const staticReasons: ExecutionGateBlockedReason[] = [
    { code: "write_execution_gate_disabled", reason: "writeExecutionGateEnabled=false — compile-time literal; an explicit first real sandbox write phase must open the execution gate",                                                                                                   static: true },
    { code: "approval_required",             reason: "approvalRequired=true — explicit operator approval is required before the write execution gate can be opened",                                                                                                                        static: true },
    { code: "actual_writes_disabled",        reason: "actualWritesEnabled=false — compile-time literal across all 23 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, and scoped-activation layers", static: true },
  ];
  const dynamicReasons: ExecutionGateBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedExecutionGateReference(
  input: CreateExecutionGateInput,
  rollbackChainValid: boolean,
): LinkedExecutionGateReference {
  const { scopedActivationRecord, writePermissionGateRecord, mutationSwitchRecord, guardedWriteEnableRecord } = input;
  return {
    scopedWriteActivationId:  scopedActivationRecord.scopedWriteActivationId,
    writePermissionGateId:    writePermissionGateRecord.writePermissionGateId,
    mutationSwitchId:         mutationSwitchRecord.mutationSwitchId,
    guardedWriteEnableId:     guardedWriteEnableRecord.guardedWriteEnableId,
    rollbackSnapshotId:       scopedActivationRecord.linkedScopedActivationReference.rollbackSnapshotId,
    writeExecutionGatePrepared: true,
    writeExecutionGateEnabled:  false,
    scopedActivationEnabled:    false,
    writePermissionEnabled:     false,
    rollbackChainValid,
    referenceNote:            "linked execution-gate reference sources rollbackSnapshotId from scopedActivationRecord.linkedScopedActivationReference; write execution gate disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createWriteExecutionGateRecord(
  input: CreateExecutionGateInput,
): ActualSandboxWriteExecutionGateRecord {
  const { scopedActivationRecord, writePermissionGateRecord, mutationSwitchRecord, guardedWriteEnableRecord, bridgeOpenRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = scopedActivationRecord.scopedActivationReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedExecutionGateReference(input, rollbackChainValid);

  const executionGateReadinessReport: ExecutionGateReadinessReport = {
    writeExecutionGatePrepared:   true,
    writeExecutionGateEnabled:    false,
    scopedActivationEnabled:      false,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    bridgeOpenEnabled:            false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    summary: `executionGateState=descriptor_write_execution_gate_pending; writeExecutionGateEnabled=false; scopedActivationEnabled=false; writePermissionEnabled=false; actualWritesEnabled=false; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: ActualSandboxWriteExecutionGateRecord = {
    writeExecutionGateId:         randomUUID(),
    executionGateState:           "descriptor_write_execution_gate_pending",
    approvalRequired:             true,
    writeExecutionGatePrepared:   true,
    writeExecutionGateEnabled:    false,
    scopedActivationEnabled:      false,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    bridgeOpenEnabled:            false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    filesystemMutationBlocked:    true,
    motherCoreMutationBlocked:    true,
    vaultMutationBlocked:         true,
    shellBlocked:                 true,
    networkBlocked:               true,
    implementationPhase:          "descriptor_only",
    scopedWriteActivationId:      scopedActivationRecord.scopedWriteActivationId,
    writePermissionGateId:        writePermissionGateRecord.writePermissionGateId,
    mutationSwitchId:             mutationSwitchRecord.mutationSwitchId,
    guardedWriteEnableId:         guardedWriteEnableRecord.guardedWriteEnableId,
    bridgeOpenId:                 bridgeOpenRecord.bridgeOpenId,
    controlledExecutionId:        executionRecord.controlledExecutionId,
    executionGateChecks:          checks,
    executionGateBlockedReasons:  blockedReasons,
    executionGateReadinessReport,
    linkedExecutionGateReference: linkedRef,
    createdAt:                    new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listWriteExecutionGateRecords(): readonly ActualSandboxWriteExecutionGateRecord[] {
  return _store.slice();
}

export function getWriteExecutionGateSummary(): ActualSandboxWriteExecutionGateSummary {
  return {
    total:                         _store.length,
    byState:                       { descriptor_write_execution_gate_pending: _store.length },
    writeExecutionGatePrepared:    true,
    writeExecutionGateEnabled:     false,
    scopedActivationEnabled:       false,
    writePermissionEnabled:        false,
    mutationSwitchEnabled:         false,
    guardedWriteEnabled:           false,
    actualWritesEnabled:           false,
    realWritesEnabled:             false,
    approvalRequired:              true,
    filesystemMutationBlocked:     true,
    motherCoreMutationBlocked:     true,
    executionGateState:            "descriptor_write_execution_gate_pending",
    implementationPhase:           "descriptor_only",
  };
}
