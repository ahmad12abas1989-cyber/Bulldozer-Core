import type { IncomingMessage, ServerResponse } from "node:http";
import { evaluateRestartRecommendation, getRestartSupervisorStatus } from "../core/restartSupervisor";
import { sendJson } from "../lib/response";

export function handleRestartSupervisor(_req: IncomingMessage, res: ServerResponse): void {
  evaluateRestartRecommendation();
  sendJson(res, 200, getRestartSupervisorStatus());
}
