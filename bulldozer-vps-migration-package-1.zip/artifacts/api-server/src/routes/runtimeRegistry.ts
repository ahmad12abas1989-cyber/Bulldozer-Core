import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson, sendError } from "../lib/response";
import {
  listSubsystemStates,
  getSubsystemState,
  getRuntimeStateRegistryStatus,
} from "../core/runtimeStateRegistry";

export function handleRuntimeRegistryList(_req: IncomingMessage, res: ServerResponse): void {
  const states = listSubsystemStates();
  const status = getRuntimeStateRegistryStatus();

  sendJson(res, 200, {
    ...status,
    subsystems: states,
  });
}

export function handleRuntimeRegistryStatus(_req: IncomingMessage, res: ServerResponse): void {
  const status = getRuntimeStateRegistryStatus();
  sendJson(res, 200, status);
}

export function handleRuntimeRegistryByName(req: IncomingMessage, res: ServerResponse): void {
  const rawPath = (req.url ?? "").split("?")[0];
  const segments = rawPath.split("/");
  const subsystemName = segments[segments.length - 1] ?? "";

  if (!subsystemName) {
    sendError(res, 400, "Subsystem name is required");
    return;
  }

  const state = getSubsystemState(subsystemName);
  if (!state) {
    sendError(
      res,
      404,
      `Subsystem not found in registry: "${subsystemName}". Use GET /api/runtime/registry to list all registered subsystems.`,
    );
    return;
  }

  sendJson(res, 200, state);
}
