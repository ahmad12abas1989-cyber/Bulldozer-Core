import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  getAccessEnforcementStatus,
  getAccessEnforcementPolicies,
} from "../core/accessEnforcement";

export function handleAccessStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getAccessEnforcementStatus());
}

export function handleAccessPolicies(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getAccessEnforcementPolicies());
}
