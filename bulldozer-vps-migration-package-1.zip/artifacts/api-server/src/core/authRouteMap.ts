// Auth Route Classification Map — Phase 181
// Pure route classification layer. No blocking. No sessions. No enforcement.
// Labels every Mother Core route by the access tier required for future auth enforcement.
// Pure module — no init, no subsystem registration, no health checks, no event emission, no side effects.

export type RouteCategory =
  | "mother_core_ui"
  | "mother_core_api"
  | "employee_workspace"
  | "generated_product"
  | "public";

export type RequiredTier =
  | "internal_operator_or_root"
  | "employee_project_scope"
  | "product_customer_scope"
  | "none";

export interface RouteClassification {
  category: RouteCategory;
  requiredTier: RequiredTier;
  description: string;
  observeOnly: true;
  matchedPattern: string;
}

export interface AuthRouteMapSummary {
  subsystemName: "auth_route_map";
  observeOnly: true;
  enforcing: false;
  totalCategories: number;
  categories: RouteCategory[];
  publicRouteCount: 0;
  note: string;
}

// Route category definitions with pattern matching priority (first match wins)
interface CategoryDefinition {
  category: RouteCategory;
  requiredTier: RequiredTier;
  description: string;
  patterns: readonly string[];
  patternType: "prefix" | "exact";
}

const CATEGORY_DEFINITIONS: readonly CategoryDefinition[] = [
  {
    category: "mother_core_ui",
    requiredTier: "internal_operator_or_root",
    description:
      "Operator Dashboard — /ui and /ui/* require Tier 1 (Root Operator) or Tier 2 (Internal Operator); employees and customers prohibited",
    patterns: ["/ui"],
    patternType: "prefix",
  },
  {
    category: "mother_core_api",
    requiredTier: "internal_operator_or_root",
    description:
      "Mother Core nucleus API — /api/* routes require Tier 1 (Root Operator) or Tier 2 (Internal Operator); no employee or customer access",
    patterns: ["/api/"],
    patternType: "prefix",
  },
  {
    category: "employee_workspace",
    requiredTier: "employee_project_scope",
    description:
      "Employee Workspace — future route namespace for project-scoped employee surfaces; no nucleus access, no /ui/*, no /api/* nucleus routes",
    patterns: [],
    patternType: "prefix",
  },
  {
    category: "generated_product",
    requiredTier: "product_customer_scope",
    description:
      "Generated Product — future route namespace for product-specific customer-facing surfaces; completely separate from Mother Core auth",
    patterns: [],
    patternType: "prefix",
  },
  {
    category: "public",
    requiredTier: "none",
    description:
      "Public — no public Mother Core routes exist or are planned; this category exists for completeness only",
    patterns: [],
    patternType: "prefix",
  },
];

const ROUTE_CATEGORIES: readonly RouteCategory[] = [
  "mother_core_ui",
  "mother_core_api",
  "employee_workspace",
  "generated_product",
  "public",
];

// Classify a request path to its auth route category and required future tier.
// Matching is first-match-wins, prefix-based.
// Returns mother_core_api classification for any unrecognised /api/* path.
// Returns mother_core_ui classification for any unrecognised /ui or /ui/* path.
// Unrecognised paths that match no pattern are classified as mother_core_api by default
// since all uncharted nucleus paths require operator-level access.
export function classifyAuthRoute(path: string): RouteClassification {
  // Strip query string and fragment for matching
  const cleanPath = path.split("?")[0]!.split("#")[0]!;

  for (const def of CATEGORY_DEFINITIONS) {
    if (def.patterns.length === 0) continue;

    for (const pattern of def.patterns) {
      if (def.patternType === "prefix") {
        if (cleanPath === pattern || cleanPath.startsWith(pattern + "/") || cleanPath.startsWith(pattern)) {
          return {
            category: def.category,
            requiredTier: def.requiredTier,
            description: def.description,
            observeOnly: true,
            matchedPattern: pattern,
          };
        }
      } else {
        if (cleanPath === pattern) {
          return {
            category: def.category,
            requiredTier: def.requiredTier,
            description: def.description,
            observeOnly: true,
            matchedPattern: pattern,
          };
        }
      }
    }
  }

  // Default: unrecognised paths in the nucleus server are operator-grade
  return {
    category: "mother_core_api",
    requiredTier: "internal_operator_or_root",
    description:
      "Unrecognised nucleus path — defaulting to operator-grade access requirement",
    observeOnly: true,
    matchedPattern: "(default)",
  };
}

export function getAuthRouteMapSummary(): AuthRouteMapSummary {
  return {
    subsystemName: "auth_route_map",
    observeOnly: true,
    enforcing: false,
    totalCategories: ROUTE_CATEGORIES.length,
    categories: [...ROUTE_CATEGORIES],
    publicRouteCount: 0,
    note: "Phase 181 — pure classification map, observe-only, no enforcement, no blocking, no sessions",
  };
}

export function listRouteCategories(): readonly RouteCategory[] {
  return ROUTE_CATEGORIES;
}

export function listCategoryDefinitions(): readonly CategoryDefinition[] {
  return CATEGORY_DEFINITIONS;
}
