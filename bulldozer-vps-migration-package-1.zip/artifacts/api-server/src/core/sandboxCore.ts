// Sandbox Core Skeleton — Phase 200
// Metadata-only in-memory registry for sandbox run descriptors.
// Never executes code, never runs shell commands, never accesses the filesystem,
// never makes network calls, never touches vault secrets.
// No init, no subsystem registration, no health checks, no event emission,
// no persistence, not wired to request flow.

import { randomBytes } from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type SandboxRunType =
  | "app_build"
  | "plugin_execution"
  | "test_run"
  | "security_scan"
  | "diff_summary";

export type SandboxRunStatus =
  | "pending_approval"  // default — awaiting operator approval
  | "approved"          // operator approved — not yet executing
  | "rejected"          // operator rejected — terminal
  | "completed"         // execution finished — future phase
  | "failed";           // execution failed — future phase

export interface SandboxRunRecord {
  readonly sandboxRunId:          string;       // server-generated, 16-byte hex
  readonly projectId:             string;       // caller-supplied
  readonly runType:               SandboxRunType;
  readonly requestedByActorType:  string;       // caller-supplied actor type label
  readonly requestedByActorId:    string;       // caller-supplied actor ID
  readonly approvalRequired:      true;         // always true in skeleton
  readonly status:                SandboxRunStatus;
  readonly createdAt:             string;       // ISO 8601, server-generated
  // Prohibited fields — never accepted or stored:
  //   command, script, path, networkAccess, secretValue
}

export interface CreateSandboxRunInput {
  readonly projectId:             string;
  readonly runType:               SandboxRunType;
  readonly requestedByActorType:  string;
  readonly requestedByActorId:    string;
  // approvalRequired is always true — not caller-settable
  // Prohibited fields — never accepted:
  //   command, script, path, networkAccess, secretValue
}

export interface CreateSandboxRunResult {
  readonly ok:     true;
  readonly record: SandboxRunRecord;
}

export interface SandboxSummary {
  readonly totalRuns:              number;
  readonly byRunType:              Partial<Record<SandboxRunType, number>>;
  readonly byStatus:               Partial<Record<SandboxRunStatus, number>>;
  readonly pendingApprovalCount:   number;
  readonly executionEnabled:       false;
  readonly persistenceEnabled:     false;
  readonly implementationPhase:    "skeleton";
}

// ---------------------------------------------------------------------------
// Store — in-memory only, never persisted
// ---------------------------------------------------------------------------

const store = new Map<string, SandboxRunRecord>();

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

/**
 * Register a sandbox run descriptor (metadata only).
 * Never accepts command, script, path, networkAccess, or secretValue fields.
 * All runs are created with status="pending_approval" and approvalRequired=true.
 * Returns the generated record.
 */
export function createSandboxRunRecord(
  input: CreateSandboxRunInput,
): CreateSandboxRunResult {
  const sandboxRunId = randomBytes(16).toString("hex");
  const createdAt    = new Date().toISOString();

  const record: SandboxRunRecord = {
    sandboxRunId,
    projectId:            input.projectId,
    runType:              input.runType,
    requestedByActorType: input.requestedByActorType,
    requestedByActorId:   input.requestedByActorId,
    approvalRequired:     true,
    status:               "pending_approval",
    createdAt,
  };

  store.set(sandboxRunId, record);

  return { ok: true, record };
}

/**
 * Return all registered sandbox run records, newest-first.
 */
export function listSandboxRuns(): readonly SandboxRunRecord[] {
  const records = Array.from(store.values());
  records.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return records;
}

/**
 * Return a summary of the sandbox run registry state.
 */
export function getSandboxSummary(): SandboxSummary {
  const records = Array.from(store.values());

  const byRunType: Partial<Record<SandboxRunType, number>>   = {};
  const byStatus:  Partial<Record<SandboxRunStatus, number>> = {};
  let pendingApprovalCount = 0;

  for (const r of records) {
    byRunType[r.runType] = (byRunType[r.runType] ?? 0) + 1;
    byStatus[r.status]   = (byStatus[r.status]   ?? 0) + 1;
    if (r.status === "pending_approval") pendingApprovalCount++;
  }

  return {
    totalRuns:           store.size,
    byRunType,
    byStatus,
    pendingApprovalCount,
    executionEnabled:    false,
    persistenceEnabled:  false,
    implementationPhase: "skeleton",
  };
}
