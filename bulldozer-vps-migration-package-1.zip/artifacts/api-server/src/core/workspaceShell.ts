import {
  listProjects,
  getProjectRegistryStatus,
  getMemberStats,
  getActivityStats,
  listProjectMembers,
  getProjectQuota,
  getProjectActivity,
  getProductLayerHealth,
} from "./projectRegistry";

const EXECUTION_BLOCKED: true = true;

// --- Workspace Summary ---

export interface WorkspaceProjectCounts {
  total: number;
  active: number;
  archived: number;
  suspended: number;
}

export interface WorkspaceCapacity {
  max: number;
  used: number;
  available: number;
  utilizationPercent: number;
  atCapacity: boolean;
}

export interface WorkspaceMemberStats {
  totalRecords: number;
}

export interface WorkspaceActivityStats {
  totalRecords: number;
}

export interface WorkspaceQuotaStats {
  projectsWithCustomQuotas: number;
  projectsUsingDefaults: number;
}

export interface WorkspaceSummary {
  checkedAt: string;
  projects: WorkspaceProjectCounts;
  capacity: WorkspaceCapacity;
  members: WorkspaceMemberStats;
  activity: WorkspaceActivityStats;
  quotas: WorkspaceQuotaStats;
  executionBlocked: true;
}

export function getWorkspaceSummary(): WorkspaceSummary {
  const projects = listProjects();
  const registryStatus = getProjectRegistryStatus();
  const memberStats = getMemberStats();
  const activityStats = getActivityStats();
  const plh = getProductLayerHealth();

  const active = projects.filter((p) => p.status === "active").length;
  const archived = projects.filter((p) => p.status === "archived").length;
  const suspended = projects.filter((p) => p.status === "suspended").length;
  const used = projects.length;
  const max = registryStatus.maxProjects;
  const available = max - used;
  const utilizationPercent = max > 0 ? Math.round((used / max) * 100) : 0;

  return {
    checkedAt: new Date().toISOString(),
    projects: { total: used, active, archived, suspended },
    capacity: {
      max,
      used,
      available,
      utilizationPercent,
      atCapacity: registryStatus.atCapacity,
    },
    members: { totalRecords: memberStats.totalMemberRecords },
    activity: { totalRecords: activityStats.totalActivityRecords },
    quotas: {
      projectsWithCustomQuotas: plh.customQuotaCount,
      projectsUsingDefaults: used - plh.customQuotaCount,
    },
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Project Overview ---

export interface ProjectOverviewItem {
  projectId: string;
  projectName: string;
  status: string;
  owner: string;
  createdAt: string;
  updatedAt: string;
  memberCount: number;
  hasCustomQuota: boolean;
  activityCount: number;
  executionBlocked: true;
}

export interface ProjectOverviewResult {
  checkedAt: string;
  projects: ProjectOverviewItem[];
  count: number;
  total: number;
  filtersApplied: string[];
  limit: number;
  executionBlocked: true;
}

export interface ProjectOverviewFilters {
  status?: string;
  limit?: number;
}

export function getProjectsOverview(
  filters: ProjectOverviewFilters = {},
): ProjectOverviewResult {
  const checkedAt = new Date().toISOString();
  const all = listProjects();
  const filtersApplied: string[] = [];

  let filtered = all;

  if (
    typeof filters.status === "string" &&
    ["active", "archived", "suspended"].includes(filters.status)
  ) {
    filtered = all.filter((p) => p.status === filters.status);
    filtersApplied.push(`status=${filters.status}`);
  }

  const rawLimit = filters.limit;
  const limit =
    typeof rawLimit === "number" && Number.isInteger(rawLimit) && rawLimit > 0
      ? Math.min(rawLimit, 50)
      : 50;

  const total = filtered.length;
  const slice = filtered.slice(0, limit);

  const items: ProjectOverviewItem[] = slice.map((p) => {
    const members = listProjectMembers(p.projectId);
    const quota = getProjectQuota(p.projectId);
    const activity = getProjectActivity(p.projectId, {});
    return {
      projectId: p.projectId,
      projectName: p.projectName,
      status: p.status,
      owner: p.owner,
      createdAt: p.createdAt,
      updatedAt: p.updatedAt,
      memberCount: members.count,
      hasCustomQuota: !quota.isDefault,
      activityCount: activity.total,
      executionBlocked: EXECUTION_BLOCKED,
    };
  });

  return {
    checkedAt,
    projects: items,
    count: items.length,
    total,
    filtersApplied,
    limit,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Navigation Layer (Phase 84) ---

export interface WorkspacePanelRef {
  panelId: string;
  title: string;
  description: string;
  endpoint: string;
  permission: string;
  minimumRole: string;
  executionBlocked: true;
}

export interface WorkspaceSection {
  sectionId: string;
  title: string;
  description: string;
  panelCount: number;
  panels: WorkspacePanelRef[];
  executionBlocked: true;
}

export interface WorkspaceNavigationResult {
  checkedAt: string;
  sections: WorkspaceSection[];
  totalSections: number;
  totalPanels: number;
  executionBlocked: true;
}

export interface WorkspacePanelMeta {
  panelId: string;
  title: string;
  description: string;
  section: string;
  endpoint: string;
  permission: string;
  executionBlocked: true;
}

export interface WorkspacePanelListResult {
  checkedAt: string;
  panels: WorkspacePanelMeta[];
  count: number;
  executionBlocked: true;
}

const PANEL_REGISTRY: WorkspacePanelMeta[] = [
  {
    panelId: "diagnostics",
    title: "Diagnostics",
    description: "System health, registry operational status, product layer health, and store key count",
    section: "overview",
    endpoint: "/api/workspace/panels/diagnostics",
    permission: "read",
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "projects",
    title: "Projects",
    description: "Project counts by status, capacity utilization, and most recently created projects",
    section: "overview",
    endpoint: "/api/workspace/panels/projects",
    permission: "read",
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "quotas",
    title: "Resource Quotas",
    description: "Quota adoption rate, projects with custom quotas vs system defaults, default bound reference",
    section: "governance",
    endpoint: "/api/workspace/panels/quotas",
    permission: "read",
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "membership",
    title: "Membership",
    description: "Total member records, projects with at least one member, role distribution across all projects",
    section: "governance",
    endpoint: "/api/workspace/panels/membership",
    permission: "read",
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "activity",
    title: "Activity Ledger",
    description: "Total activity records across all projects, projects with recorded activity, load-on-boot stats",
    section: "audit",
    endpoint: "/api/workspace/panels/activity",
    permission: "read",
    executionBlocked: EXECUTION_BLOCKED,
  },
];

const SECTION_DEFINITIONS: Array<{
  sectionId: string;
  title: string;
  description: string;
  panelIds: string[];
}> = [
  {
    sectionId: "overview",
    title: "Overview",
    description: "High-level workspace health and project summary",
    panelIds: ["diagnostics", "projects"],
  },
  {
    sectionId: "governance",
    title: "Governance & Quotas",
    description: "Resource quota adoption and project membership management",
    panelIds: ["quotas", "membership"],
  },
  {
    sectionId: "audit",
    title: "Audit & Activity",
    description: "Project activity ledger and audit trail visibility",
    panelIds: ["activity"],
  },
];

export function getWorkspaceNavigation(): WorkspaceNavigationResult {
  const checkedAt = new Date().toISOString();
  const sections: WorkspaceSection[] = SECTION_DEFINITIONS.map((def) => {
    const panels: WorkspacePanelRef[] = def.panelIds
      .map((pid) => PANEL_REGISTRY.find((p) => p.panelId === pid))
      .filter((p): p is WorkspacePanelMeta => p !== undefined)
      .map((p) => ({
        panelId: p.panelId,
        title: p.title,
        description: p.description,
        endpoint: p.endpoint,
        permission: p.permission,
        minimumRole: "viewer",
        executionBlocked: EXECUTION_BLOCKED,
      }));
    return {
      sectionId: def.sectionId,
      title: def.title,
      description: def.description,
      panelCount: panels.length,
      panels,
      executionBlocked: EXECUTION_BLOCKED,
    };
  });
  return {
    checkedAt,
    sections,
    totalSections: sections.length,
    totalPanels: PANEL_REGISTRY.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function listWorkspacePanels(): WorkspacePanelListResult {
  return {
    checkedAt: new Date().toISOString(),
    panels: PANEL_REGISTRY.map((p) => ({ ...p })),
    count: PANEL_REGISTRY.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Panel Data Models (Phase 84) ---

export interface DiagnosticsPanel {
  panelId: "diagnostics";
  title: string;
  checkedAt: string;
  status: "ok" | "degraded";
  registryOperational: boolean;
  totalProjects: number;
  totalMembers: number;
  totalActivityRecords: number;
  customQuotaProjects: number;
  storeKeyCount: number;
  layer: "product";
  executionBlocked: true;
}

export interface RecentProjectEntry {
  projectId: string;
  projectName: string;
  status: string;
  owner: string;
  createdAt: string;
}

export interface ProjectsByStatus {
  active: number;
  archived: number;
  suspended: number;
}

export interface ProjectsPanelCapacity {
  max: number;
  used: number;
  available: number;
  utilizationPercent: number;
  atCapacity: boolean;
}

export interface ProjectsPanel {
  panelId: "projects";
  title: string;
  checkedAt: string;
  total: number;
  byStatus: ProjectsByStatus;
  capacity: ProjectsPanelCapacity;
  recentProjects: RecentProjectEntry[];
  executionBlocked: true;
}

export interface QuotaSystemDefaults {
  maxMembers: number;
  maxActivityEntries: number;
  maxTags: number;
}

export interface QuotasPanel {
  panelId: "quotas";
  title: string;
  checkedAt: string;
  totalProjects: number;
  projectsWithCustomQuotas: number;
  projectsUsingDefaults: number;
  systemDefaults: QuotaSystemDefaults;
  executionBlocked: true;
}

export interface ActivityPanel {
  panelId: "activity";
  title: string;
  checkedAt: string;
  totalRecords: number;
  loadedOnBoot: number;
  projectsWithActivity: number;
  totalProjects: number;
  executionBlocked: true;
}

export interface MembershipPanel {
  panelId: "membership";
  title: string;
  checkedAt: string;
  totalRecords: number;
  loadedOnBoot: number;
  projectsWithMembers: number;
  totalProjects: number;
  roleDistribution: Record<string, number>;
  executionBlocked: true;
}

export type WorkspacePanelData =
  | DiagnosticsPanel
  | ProjectsPanel
  | QuotasPanel
  | ActivityPanel
  | MembershipPanel;

const QUOTA_SYSTEM_DEFAULTS: QuotaSystemDefaults = {
  maxMembers: 10,
  maxActivityEntries: 500,
  maxTags: 10,
};

function buildDiagnosticsPanel(): DiagnosticsPanel {
  const plh = getProductLayerHealth();
  return {
    panelId: "diagnostics",
    title: "Diagnostics",
    checkedAt: new Date().toISOString(),
    status: plh.registryOperational ? "ok" : "degraded",
    registryOperational: plh.registryOperational,
    totalProjects: plh.projectCount,
    totalMembers: plh.totalMembers,
    totalActivityRecords: plh.totalActivityRecords,
    customQuotaProjects: plh.customQuotaCount,
    storeKeyCount: plh.storeKeys.length,
    layer: "product",
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function buildProjectsPanel(): ProjectsPanel {
  const projects = listProjects();
  const registryStatus = getProjectRegistryStatus();
  const total = projects.length;
  const active = projects.filter((p) => p.status === "active").length;
  const archived = projects.filter((p) => p.status === "archived").length;
  const suspended = projects.filter((p) => p.status === "suspended").length;
  const max = registryStatus.maxProjects;
  const available = max - total;
  const utilizationPercent = max > 0 ? Math.round((total / max) * 100) : 0;
  const recentProjects: RecentProjectEntry[] = projects
    .slice(-5)
    .reverse()
    .map((p) => ({
      projectId: p.projectId,
      projectName: p.projectName,
      status: p.status,
      owner: p.owner,
      createdAt: p.createdAt,
    }));
  return {
    panelId: "projects",
    title: "Projects",
    checkedAt: new Date().toISOString(),
    total,
    byStatus: { active, archived, suspended },
    capacity: {
      max,
      used: total,
      available,
      utilizationPercent,
      atCapacity: registryStatus.atCapacity,
    },
    recentProjects,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function buildQuotasPanel(): QuotasPanel {
  const plh = getProductLayerHealth();
  const totalProjects = plh.projectCount;
  const projectsWithCustomQuotas = plh.customQuotaCount;
  return {
    panelId: "quotas",
    title: "Resource Quotas",
    checkedAt: new Date().toISOString(),
    totalProjects,
    projectsWithCustomQuotas,
    projectsUsingDefaults: totalProjects - projectsWithCustomQuotas,
    systemDefaults: { ...QUOTA_SYSTEM_DEFAULTS },
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function buildActivityPanel(): ActivityPanel {
  const stats = getActivityStats();
  const projects = listProjects();
  let projectsWithActivity = 0;
  for (const p of projects) {
    if (getProjectActivity(p.projectId, {}).total > 0) projectsWithActivity++;
  }
  return {
    panelId: "activity",
    title: "Activity Ledger",
    checkedAt: new Date().toISOString(),
    totalRecords: stats.totalActivityRecords,
    loadedOnBoot: stats.activityLoadedOnBoot,
    projectsWithActivity,
    totalProjects: projects.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

function buildMembershipPanel(): MembershipPanel {
  const stats = getMemberStats();
  const projects = listProjects();
  const roleDistribution: Record<string, number> = {};
  let projectsWithMembers = 0;
  for (const p of projects) {
    const result = listProjectMembers(p.projectId);
    if (result.count > 0) projectsWithMembers++;
    for (const m of result.members) {
      roleDistribution[m.role] = (roleDistribution[m.role] ?? 0) + 1;
    }
  }
  return {
    panelId: "membership",
    title: "Membership",
    checkedAt: new Date().toISOString(),
    totalRecords: stats.totalMemberRecords,
    loadedOnBoot: stats.memberLoadedOnBoot,
    projectsWithMembers,
    totalProjects: projects.length,
    roleDistribution,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export const KNOWN_PANEL_IDS = ["diagnostics", "projects", "quotas", "activity", "membership"] as const;
export type KnownPanelId = (typeof KNOWN_PANEL_IDS)[number];

export function getPanel(panelId: string): WorkspacePanelData | null {
  switch (panelId) {
    case "diagnostics": return buildDiagnosticsPanel();
    case "projects":    return buildProjectsPanel();
    case "quotas":      return buildQuotasPanel();
    case "activity":    return buildActivityPanel();
    case "membership":  return buildMembershipPanel();
    default:            return null;
  }
}

// --- Workspace Health ---

export type WorkspaceHealthStatus = "ok" | "degraded";

export interface WorkspaceHealthSummary {
  checkedAt: string;
  status: WorkspaceHealthStatus;
  registryOperational: boolean;
  totalProjects: number;
  totalMembers: number;
  totalActivityRecords: number;
  customQuotaProjects: number;
  storeKeyCount: number;
  executionBlocked: true;
}

export function getWorkspaceHealth(): WorkspaceHealthSummary {
  const plh = getProductLayerHealth();
  const status: WorkspaceHealthStatus = plh.registryOperational ? "ok" : "degraded";
  return {
    checkedAt: new Date().toISOString(),
    status,
    registryOperational: plh.registryOperational,
    totalProjects: plh.projectCount,
    totalMembers: plh.totalMembers,
    totalActivityRecords: plh.totalActivityRecords,
    customQuotaProjects: plh.customQuotaCount,
    storeKeyCount: plh.storeKeys.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
