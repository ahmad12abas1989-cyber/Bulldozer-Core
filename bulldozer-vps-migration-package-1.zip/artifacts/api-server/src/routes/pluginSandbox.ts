import type { IncomingMessage, ServerResponse } from "node:http";
import { getPluginSandboxStatus } from "../core/pluginSandbox";
import { sendJson } from "../lib/response";

export function handlePluginSandbox(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getPluginSandboxStatus());
}
