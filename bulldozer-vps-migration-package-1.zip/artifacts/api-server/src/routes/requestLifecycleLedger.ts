import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { getLifecycleLedgerStatus, getFilteredLifecycleRecords, type LifecycleFilter } from "../core/requestLifecycleLedger";

const MAX_LIMIT = 100;
const DEFAULT_LIMIT = 50;

function decodeParam(val: string | undefined): string | undefined {
  if (val === undefined) return undefined;
  try {
    return decodeURIComponent(val);
  } catch {
    return undefined;
  }
}

export function handleLifecycleStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getLifecycleLedgerStatus());
}

export function handleLifecycleRecent(req: IncomingMessage, res: ServerResponse): void {
  const rawUrl = req.url ?? "";
  const queryStart = rawUrl.indexOf("?");
  const queryString = queryStart >= 0 ? rawUrl.slice(queryStart + 1) : "";

  const filter: LifecycleFilter = { limit: DEFAULT_LIMIT };

  if (queryString) {
    for (const part of queryString.split("&")) {
      const eqIdx = part.indexOf("=");
      if (eqIdx < 0) continue;
      const rawKey = part.slice(0, eqIdx);
      const rawVal = part.slice(eqIdx + 1);
      const key = decodeParam(rawKey);
      const val = decodeParam(rawVal);
      if (key === undefined || val === undefined || val === "") continue;

      switch (key) {
        case "limit": {
          const parsed = parseInt(val, 10);
          if (!isNaN(parsed) && parsed > 0) {
            filter.limit = Math.min(parsed, MAX_LIMIT);
          }
          break;
        }
        case "statusCode": {
          const parsed = parseInt(val, 10);
          if (!isNaN(parsed) && Number.isFinite(parsed) && parsed > 0) {
            filter.statusCode = parsed;
          }
          break;
        }
        case "route":
          filter.route = val;
          break;
        case "method":
          filter.method = val.toUpperCase();
          break;
        case "minLatencyMs": {
          const parsed = parseFloat(val);
          if (!isNaN(parsed) && parsed >= 0) {
            filter.minLatencyMs = parsed;
          }
          break;
        }
        case "maxLatencyMs": {
          const parsed = parseFloat(val);
          if (!isNaN(parsed) && parsed >= 0) {
            filter.maxLatencyMs = parsed;
          }
          break;
        }
        default:
          break;
      }
    }
  }

  sendJson(res, 200, getFilteredLifecycleRecords(filter));
}
