// App Factory Core — Phase 208
// In-memory, metadata-only App Factory request registry.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no file generation, no sandbox execution,
// no plugin execution, no deployment, no network access, no vault access,
// not wired to any request flow.
// All requests default to status="received_project_spec".

import { randomBytes } from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type AppFactoryAppType =
  | "crud_app"
  | "pos_invoice_app"
  | "dashboard_app"
  | "api_service"
  | "admin_panel"
  | "content_production_module";

export type AppFactoryPipelineStatus =
  | "received_project_spec"
  | "select_template"
  | "generate_files"
  | "sandbox_build"
  | "sandbox_test"
  | "security_scan"
  | "artifact_package"
  | "operator_review"
  | "approved"
  | "rejected"
  | "deployment_candidate";

export interface AppFactoryRequestRecord {
  readonly factoryRequestId:       string;
  readonly appType:                AppFactoryAppType;
  readonly projectName:            string;
  readonly requestedByActorType:   string;
  readonly requestedByActorId:     string;
  readonly specSummary:            string;
  readonly status:                 AppFactoryPipelineStatus;
  readonly createdAt:              string;
}

// Accepted input — structurally excludes: code, files, command, script,
// deploy flag, secretValue, and any vault value.
export interface CreateAppFactoryRequestInput {
  readonly appType:                AppFactoryAppType;
  readonly projectName:            string;
  readonly requestedByActorType:   string;
  readonly requestedByActorId:     string;
  readonly specSummary:            string;
}

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

export interface AppFactorySummary {
  readonly totalRequests:          number;
  readonly byAppType:              Partial<Record<AppFactoryAppType, number>>;
  readonly byStatus:               Partial<Record<AppFactoryPipelineStatus, number>>;
  readonly pendingReviewCount:     number;
  readonly generationEnabled:      false;
  readonly executionEnabled:       false;
  readonly persistenceEnabled:     false;
  readonly implementationPhase:    "skeleton";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const factoryStore = new Map<string, AppFactoryRequestRecord>();

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

export function createAppFactoryRequestRecord(
  input: CreateAppFactoryRequestInput,
): { ok: true; record: AppFactoryRequestRecord } {
  const factoryRequestId = randomBytes(16).toString("hex");
  const createdAt        = new Date().toISOString();

  const record: AppFactoryRequestRecord = {
    factoryRequestId,
    appType:               input.appType,
    projectName:           input.projectName,
    requestedByActorType:  input.requestedByActorType,
    requestedByActorId:    input.requestedByActorId,
    specSummary:           input.specSummary,
    status:                "received_project_spec",
    createdAt,
  };

  factoryStore.set(factoryRequestId, record);
  return { ok: true, record };
}

export function listAppFactoryRequestRecords(): AppFactoryRequestRecord[] {
  return Array.from(factoryStore.values()).sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getAppFactorySummary(): AppFactorySummary {
  const records   = listAppFactoryRequestRecords();
  const byAppType: Partial<Record<AppFactoryAppType, number>>          = {};
  const byStatus:  Partial<Record<AppFactoryPipelineStatus, number>>   = {};

  for (const r of records) {
    byAppType[r.appType] = (byAppType[r.appType] ?? 0) + 1;
    byStatus[r.status]   = (byStatus[r.status]   ?? 0) + 1;
  }

  return {
    totalRequests:       records.length,
    byAppType,
    byStatus,
    pendingReviewCount:  byStatus["operator_review"] ?? 0,
    generationEnabled:   false,
    executionEnabled:    false,
    persistenceEnabled:  false,
    implementationPhase: "skeleton",
  };
}
