# Bulldozer Mother Core

A cloud-first production nucleus. Node.js 24, TypeScript 5.9, zero runtime framework dependencies.

For full architecture, phase history, principles, roadmaps, and design decisions, see **[ARCHITECTURE.md](./ARCHITECTURE.md)**.
For the nucleus completion seal and full verification record, see **[NUCLEUS_LOCK.md](./NUCLEUS_LOCK.md)**.
For the foundation freeze baseline documentation, see **[BASELINE.md](./BASELINE.md)**.
For import constraints, safe invariants, and implementation rules, see **[GOTCHAS.md](./GOTCHAS.md)**.
For archived phase history (Phases 1–126), see **[PHASE_ARCHIVE.md](./PHASE_ARCHIVE.md)**.

---

## Session Checkpoint — May 15 2026

| Item | Value |
|---|---|
| Completed phases | 1 → 354 (compact batch 353–354) |
| Phase archive | Phases 1–354 → **[PHASE_ARCHIVE.md](./PHASE_ARCHIVE.md)** |
| Workspace state | Running — server ready, 162 endpoints active, 38 health checks passing |
| Current progress | **Phases 353–354 compact batch complete — First Controlled Filesystem Mutation Release Blueprint (Phase 353, doc-only) + Core Skeleton (Phase 354, core/firstControlledFilesystemMutationReleaseCore.ts); no new endpoints, no new policies, no new subsystems; layer 40 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate + write-operation + runtime-write-executor + sandbox-write-commit + sandbox-write-commit-enable + commit-execution-gate + mutation-executor + mutation-commit + mutation-apply + mutation-surface + filesystem-mutation-enablement + filesystem-mutation-gate + filesystem-mutation-permit + filesystem-mutation-authorization + filesystem-mutation-approval + filesystem-mutation-grant + filesystem-mutation-final-approval stack; inputs (6): finalApprovalRecord, grantRecord, approvalRecord, authorizationRecord, permitRecord, executionRecord; 7 checks; 4-check forward-binding chain (final_approval_bound_to_grant → grant_bound_to_approval → approval_bound_to_authorization → authorization_bound_to_permit); rollbackChainValid delegates to finalApprovalRecord.filesystemMutationFinalApprovalReadinessReport.rollbackChainValid; linkedFilesystemMutationReleaseReference carries 5 anchors (filesystemMutationFinalApprovalId+filesystemMutationGrantId+filesystemMutationApprovalId+filesystemMutationAuthorizationId+rollbackSnapshotId); rollbackSnapshotId sourced from finalApprovalRecord.linkedFilesystemMutationFinalApprovalReference.rollbackSnapshotId; 3 static + dynamic filesystemMutationReleaseBlockedReasons; filesystemMutationReleasePlan[] with 1 descriptor entry (targetScope=sandbox_approved_only, filesystemMutationReleaseEnabled=false); compile-time literals: filesystemMutationReleasePrepared=true, filesystemMutationReleaseEnabled=false, filesystemMutationFinalApprovalGranted=false, filesystemMutationGrantEnabled=false, filesystemMutationApprovalGranted=false, filesystemMutationAuthorizationEnabled=false, filesystemMutationPermitEnabled=false, actualWritesEnabled=false, filesystemMutationBlocked=true, targetScope=sandbox_approved_only (first-class field), filesystemMutationReleaseState="descriptor_filesystem_mutation_release_pending"; no init, no subsystem, no health check; typecheck clean; ep=162, pol=162, hc=38, sub=27, graph=27/0** |

---

## Run and Operate

- `pnpm --filter @workspace/api-server run dev` — run the server with tsx (port assigned via `$PORT`)
- `pnpm --filter @workspace/api-server run build` — bundle for production with esbuild
- `pnpm --filter @workspace/api-server run typecheck` — typecheck this package only
- `pnpm run typecheck` — full typecheck across all packages

---

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- HTTP: `node:http` (no Express)
- Logging: structured JSON to stderr (no Pino)
- Build: esbuild (ESM bundle for prod), tsx (dev transpile)
- Zero runtime framework dependencies

---

## Where Things Live

```
artifacts/api-server/src/
├── index.ts                    # Entry point — boots the runtime
├── server.ts                   # node:http server + request router (83 routes)
├── core/
│   ├── config.ts               # Config Loader: reads PORT, NODE_ENV, LOG_LEVEL from env
│   ├── plugins.ts              # Plugin Manager: register / loadAll / list
│   ├── runtime.ts              # Core Runtime: startup lifecycle + status tracking
│   ├── shutdown.ts             # Graceful Shutdown: SIGTERM / SIGINT → server.close()
│   ├── errorBoundary.ts        # Error Boundary: wraps handlers, increments error counters
│   ├── router.ts               # Request Router: method+path exact matching
│   ├── metrics.ts              # Runtime Metrics: memory, cpu, request/error counters
│   ├── healthMonitor.ts        # Health Monitor: synchronous checks → healthy/degraded/unhealthy
│   ├── freezeDetector.ts       # Freeze Detector: event loop lag via setInterval + .unref()
│   ├── crashDetector.ts        # Crash Detector: uncaughtException / unhandledRejection / warning
│   ├── snapshots.ts            # Snapshot Layer: in-memory ring buffer, max 10 snapshots
│   ├── snapshotStorage.ts      # Snapshot Storage: atomic disk writes, max 20 files, prune-on-write
│   ├── timeline.ts             # Runtime Timeline: chronological event log, max 200 events
│   ├── eventBus.ts             # Event Bus: emit / subscribe / unsubscribe, in-memory, synchronous
│   ├── watchdog.ts             # Watchdog Core: 15 s passive monitor, reads raw state, 8 event types
│   ├── restartSupervisor.ts    # Restart Supervisor: 5-threshold decision layer, blockedExecution always true
│   ├── pluginSandbox.ts        # Plugin Sandbox: all-denied permission model, in-memory registry
│   ├── runtimeState.ts         # Persistent Runtime State: atomic single-file, 5 save triggers
│   ├── recoveryTracker.ts      # Recovery Tracker: 10 event subscriptions, passive observation only
│   ├── hardening.ts            # Production Hardening: 5 block types, 2 warning types, security headers
│   ├── secureConfig.ts         # Secure Config: masking, validation, 3-status model
│   ├── taskQueue.ts            # Task Queue: create/list/get/block, executionBlocked always true
│   ├── taskEvaluation.ts       # Task Evaluation: delegates to taskPolicy, executionStillBlocked always true
│   ├── taskPolicy.ts           # Task Policy Engine: 10 ordered policies, source of truth, executionBlocked always true
│   ├── taskPersistence.ts      # Task Persistence: atomic disk writes, load-on-boot, max 100 tasks, executionBlocked always true
│   ├── queueOrchestrator.ts    # Queue Orchestrator: planning-only readiness scan, peekTaskPolicy, executionBlocked always true
│   ├── taskLifecycle.ts        # Task Lifecycle: 5-state machine, safe transitions only, executionBlocked always true
│   ├── runtimeSnapshot.ts      # Runtime Snapshot: cross-system capture, max 50 active + archive, dry-run recovery, executionBlocked always true
│   ├── runtimeEventBus.ts      # Runtime Event Bus: 9-category model, 1000-event ring buffer, bridge subscriptions, handler failure isolation
│   ├── commandGateway.ts       # Command Gateway: intake-only, risk classification, 4-policy model, max 500 commands, commandExecutionBlocked always true
│   ├── runtimeStateRegistry.ts # Runtime State Registry: 20 seeded subsystems, register/update/list/get, executionBlocked always true
│   ├── runtimeDependencyGraph.ts # Dependency Graph: 27 nodes, upstream/downstream/transitive, cycle detection, read-only
│   ├── runtimeCapabilityMatrix.ts # Capability Matrix: 27 subsystems, read/write/emit/subscribe/access per subsystem, reference validation
│   ├── requestLifecycleLedger.ts  # Request Lifecycle Ledger: 500-entry ring buffer, statusCode+latencyMs+finishedAt, executionBlocked always true
│   ├── diagnostics.ts          # Diagnostics Snapshot: read-only aggregation of all subsystems + productLayerHealth
│   ├── accessEnforcement.ts    # Access Enforcement: 81-policy map, observe mode, all execute blocked
│   ├── identityAccess.ts       # Identity Access: 4 actor types, 5 roles, 7 permissions
│   ├── auditLog.ts             # Audit Log: 1000-entry ring buffer, persisted, every access check recorded
│   ├── sessionContext.ts       # Session Context: per-request identity, 200-entry ring buffer, persisted
│   ├── rateLimiter.ts          # Rate Limiter: fixed 60-s window, identity-keyed, anomaly logging
│   ├── apiKeyAuth.ts           # API Key Auth: timing-safe comparison, owner + service keys
│   ├── secretVault.ts          # Secrets Vault: metadata-only, 5 known secrets, no value exposure
│   ├── projectRegistry.ts     # Project Registry: max 100 projects, members, activity, quotas, persisted
│   ├── workspaceShell.ts       # Workspace Shell: pure read-only aggregation — summary, overview, health, navigation, 5 panels
│   ├── workspaceSnapshots.ts   # Workspace Snapshots: ring buffer max 20, atomic persistence, load-on-boot, executionBlocked always true
│   ├── workspaceTimeline.ts    # Workspace Timeline: pure read-only aggregation — 7 event types, 4 sources, 500-event cap, filterable
│   └── workspaceDiff.ts        # Workspace Diff: pure read-only computation — summaryDelta, projectChanges, membershipDelta, quotaDelta, activityDelta; no persistence, no init
├── lib/
│   ├── logger.ts               # Structured JSON logger (stderr, no dependencies)
│   ├── response.ts             # sendJson / sendError helpers
│   ├── validate.ts             # Request validation: method allowlist, path checks
│   ├── body.ts                 # readJsonBody: async JSON body parser, max 64 KB, node:http only
│   └── requestContext.ts       # requestId attachment (16-char hex via node:crypto)
└── routes/
    ├── health.ts               # GET /api/healthz
    ├── status.ts               # GET /api/status
    ├── metrics.ts              # GET /api/metrics
    ├── healthFull.ts           # GET /api/health/full
    ├── freeze.ts               # GET /api/freeze
    ├── crash.ts                # GET /api/crash
    ├── snapshot.ts             # GET /api/snapshot
    ├── snapshots.ts            # GET /api/snapshots
    ├── snapshotLatest.ts       # GET /api/snapshot/latest
    ├── snapshotHistory.ts      # GET /api/snapshot/history
    ├── timeline.ts             # GET /api/timeline
    ├── events.ts               # GET /api/events
    ├── watchdog.ts             # GET /api/watchdog
    ├── restartSupervisor.ts    # GET /api/restart-supervisor
    ├── pluginSandbox.ts        # GET /api/plugin-sandbox
    ├── runtimeState.ts         # GET /api/runtime-state
    ├── recoveryTracker.ts      # GET /api/recovery-tracker
    ├── hardening.ts            # GET /api/hardening
    ├── configStatus.ts         # GET /api/config/status
    ├── tasks.ts                # GET /api/tasks; POST /api/tasks
    ├── taskEvaluation.ts       # GET /api/task-evaluation
    ├── taskPolicy.ts           # GET /api/task-policy
    ├── taskPersistence.ts      # GET /api/tasks/persistence
    ├── queueOrchestration.ts   # GET /api/queue/orchestration
    ├── taskLifecycle.ts        # GET /api/tasks/lifecycle; POST /api/tasks/lifecycle/transition
    ├── runtimeSnapshots.ts     # GET /api/runtime/snapshots; GET …/:id; POST …/create; POST …/recovery/dry-run
    ├── runtimeEvents.ts        # GET /api/runtime/events; GET …/recent; GET …/subscribers
    ├── commands.ts             # GET /api/commands; GET …/status; POST /api/commands
    ├── runtimeRegistry.ts      # GET /api/runtime/registry; GET …/status; GET …/:subsystemName
    ├── runtimeDependencyGraph.ts # GET /api/runtime/graph; GET …/status; GET …/:subsystemName
    ├── runtimeCapabilityMatrix.ts # GET /api/runtime/capabilities; GET …/status; GET …/:subsystemName
    ├── sessionContext.ts       # GET /api/session/status; GET /api/session/recent
    ├── requestLifecycleLedger.ts  # GET /api/lifecycle/status; GET /api/lifecycle/recent
    ├── diagnostics.ts          # GET /api/diagnostics/snapshot
    ├── storage.ts              # GET /api/storage/status
    ├── baseline.ts             # GET /api/baseline/status
    ├── identityAccess.ts       # GET /api/identity/status; GET /api/identity/roles
    ├── accessEnforcement.ts    # GET /api/access/status; GET /api/access/policies
    ├── auditLog.ts             # GET /api/audit/status; GET /api/audit/log
    └── projects.ts             # GET /api/projects; POST /api/projects; GET /api/projects/:id;
                                #   PATCH /api/projects/:id; GET/POST /api/projects/:id/members;
                                #   DELETE /api/projects/:id/members/:actorId;
                                #   GET /api/projects/:id/activity;
                                #   GET/POST/DELETE /api/projects/:id/quotas
```

---

## Storage Layout

```
artifacts/api-server/storage/
├── snapshots/              # max 20 files, atomic writes, prune-on-write
│   └── snapshot-<timestamp>-<id>.json
├── runtime-snapshots/      # max 50 active, unlimited archived, atomic writes
│   ├── active/
│   │   └── <timestamp>-<id>.json
│   └── archived/
│       └── <timestamp>-<id>.json
├── runtime-state/          # single file, atomic overwrite
│   └── runtime-state.json
├── tasks/                  # single file, atomic overwrite, max 100 tasks
│   └── task-state.json
└── store/                  # key-value store, one file per key, atomic writes
    ├── audit-log.json
    ├── session-contexts.json
    ├── lifecycle-ledger.json
    ├── project-registry.json
    ├── project-members.json
    ├── project-activity.json
    └── project-quotas.json
```

---

## Active Endpoints and Health Checks

Full endpoint reference (method, route, purpose, subsystem, safety flags) and health check table are in **[ENDPOINTS.md](./ENDPOINTS.md)**.

Quick summary:

| Metric | Value |
|---|---|
| Total endpoints | 141 |
| Health checks | 38 |
| Registered subsystems | 27 |
| Dependency graph nodes | 27 (0 cycles) |
| Capability matrix records | 27 (validationStatus: valid) |
| Access policies | 141 |
| `BASELINE_LOCK.json` | Frozen at Phase 43 — ep=59, hc=36, sub=26, graph=26 |
| Intentional drift | endpointCount (59→141), healthCheckCount (36→38), subsystemCount (26→27), graphNodeCount (26→27) |

---

## User Preferences

- No AI, no dashboard, no workers, no loops, no self-healing, no auto-restart.
- Use only Node.js built-in modules where possible.
- No Express, no Pino, no frameworks.
- Keep it lightweight, stable, modular, and easy to extend.

---

## Gotchas

See **[GOTCHAS.md](./GOTCHAS.md)** for the full list of import constraints, safe invariants, init-order rules, and implementation gotchas accumulated across all phases.
