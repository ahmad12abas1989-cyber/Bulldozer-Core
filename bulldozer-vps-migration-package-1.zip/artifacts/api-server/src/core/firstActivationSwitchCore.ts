// firstActivationSwitchCore.ts
// Phase 288 — First Activation Switch Core Skeleton
// In-memory first activation-switch descriptor engine.
// Layer 15 of the write-preparation + preflight + activation stack.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No real writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// activationSwitchEnabled=false — explicitly separates "prepared" from "enabled".
// executionTransitionPending=true — marks readiness for future execution transition.

import type { FirstRealSandboxWriteActivationRecord } from "./firstRealSandboxWriteActivationCore.js";
import type { ActualSandboxWritePreflightRecord }      from "./actualSandboxWritePreflightCore.js";
import type { ActualSandboxWriteApprovalTokenRecord }  from "./actualSandboxWriteApprovalTokenCore.js";
import type { ActualSandboxWriteDryRunRecord }         from "./actualSandboxWriteDryRunCore.js";
import type { SandboxWriteCommitGateRecord }           from "./sandboxWriteCommitGateCore.js";
import type { ControlledExecutionRecord }              from "./controlledExecutionCore.js";
import { randomUUID }                                  from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type SwitchState = "descriptor_switch_pending";

export type SwitchCheckRule =
  | "activation_record_exists"
  | "preflight_record_exists"
  | "approval_token_exists"
  | "dry_run_exists"
  | "commit_gate_exists"
  | "execution_record_exists"
  | "activation_bound_to_preflight"
  | "preflight_bound_to_approval"
  | "approval_bound_to_dry_run"
  | "rollback_chain_valid"
  | "activation_switch_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface SwitchCheck {
  readonly rule: SwitchCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface SwitchBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedActivationReference {
  readonly activationId:           string;
  readonly preflightId:            string;
  readonly approvalTokenId:        string;
  readonly rollbackSnapshotId:     string;
  readonly commitGateId:           string;
  readonly activationPrepared:     true;
  readonly activationSwitchEnabled:false;
  readonly rollbackChainValid:     boolean;
  readonly referenceNote:          string;
}

export interface SwitchReadinessReport {
  readonly activationPrepared:       true;
  readonly activationSwitchEnabled:  false;
  readonly actualWritesEnabled:      false;
  readonly realWritesEnabled:        false;
  readonly executionTransitionPending: true;
  readonly approvalRequired:         true;
  readonly allChecksPass:            boolean;
  readonly blockedReasonCount:       number;
  readonly rollbackChainValid:       boolean;
  readonly summary:                  string;
}

export interface FirstActivationSwitchRecord {
  readonly activationSwitchId:         string;
  readonly switchState:                SwitchState;
  readonly approvalRequired:           true;
  readonly activationPrepared:         true;
  readonly activationSwitchEnabled:    false;
  readonly actualWritesEnabled:        false;
  readonly realWritesEnabled:          false;
  readonly executionTransitionPending: true;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly implementationPhase:        "descriptor_only";
  readonly activationId:               string;
  readonly preflightId:                string;
  readonly approvalTokenId:            string;
  readonly dryRunId:                   string;
  readonly commitGateId:               string;
  readonly controlledExecutionId:      string;
  readonly switchChecks:               readonly SwitchCheck[];
  readonly switchBlockedReasons:       readonly SwitchBlockedReason[];
  readonly switchReadinessReport:      SwitchReadinessReport;
  readonly linkedActivationReference:  LinkedActivationReference;
  readonly createdAt:                  string;
}

export interface CreateSwitchInput {
  readonly activationRecord:    FirstRealSandboxWriteActivationRecord;
  readonly preflightRecord:     ActualSandboxWritePreflightRecord;
  readonly approvalTokenRecord: ActualSandboxWriteApprovalTokenRecord;
  readonly dryRunRecord:        ActualSandboxWriteDryRunRecord;
  readonly commitGateRecord:    SandboxWriteCommitGateRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface FirstActivationSwitchSummary {
  readonly total:                      number;
  readonly byState:                    Record<SwitchState, number>;
  readonly activationPrepared:         true;
  readonly activationSwitchEnabled:    false;
  readonly actualWritesEnabled:        false;
  readonly realWritesEnabled:          false;
  readonly executionTransitionPending: true;
  readonly approvalRequired:           true;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly switchState:                SwitchState;
  readonly implementationPhase:        "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstActivationSwitchRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateSwitchInput): readonly SwitchCheck[] {
  const { activationRecord, preflightRecord, approvalTokenRecord, dryRunRecord, commitGateRecord, executionRecord } = input;

  const activationExists  = activationRecord.activationId.length > 0;
  const preflightExists   = preflightRecord.preflightId.length > 0;
  const approvalExists    = approvalTokenRecord.approvalTokenId.length > 0;
  const dryRunExists      = dryRunRecord.dryRunId.length > 0;
  const commitGateExists  = commitGateRecord.commitGateId.length > 0;
  const executionExists   = executionRecord.controlledExecutionId.length > 0;

  const activationBound   = activationRecord.preflightId === preflightRecord.preflightId;
  const preflightBound    = preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId;
  const approvalBound     = approvalTokenRecord.dryRunId === dryRunRecord.dryRunId;

  const rollbackChainValid =
    activationRecord.activationReadinessReport.rollbackReady &&
    preflightRecord.preflightReadinessReport.rollbackReady &&
    approvalTokenRecord.approvalReadinessReport.rollbackReady &&
    dryRunRecord.dryRunReadinessReport.rollbackReady &&
    commitGateRecord.commitReadinessReport.rollbackReady;

  return [
    {
      rule: "activation_record_exists",
      pass: activationExists,
      note: activationExists
        ? `activationId=${activationRecord.activationId}`
        : "activationRecord.activationId is empty",
    },
    {
      rule: "preflight_record_exists",
      pass: preflightExists,
      note: preflightExists
        ? `preflightId=${preflightRecord.preflightId}`
        : "preflightRecord.preflightId is empty",
    },
    {
      rule: "approval_token_exists",
      pass: approvalExists,
      note: approvalExists
        ? `approvalTokenId=${approvalTokenRecord.approvalTokenId}`
        : "approvalTokenRecord.approvalTokenId is empty",
    },
    {
      rule: "dry_run_exists",
      pass: dryRunExists,
      note: dryRunExists
        ? `dryRunId=${dryRunRecord.dryRunId}`
        : "dryRunRecord.dryRunId is empty",
    },
    {
      rule: "commit_gate_exists",
      pass: commitGateExists,
      note: commitGateExists
        ? `commitGateId=${commitGateRecord.commitGateId}`
        : "commitGateRecord.commitGateId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "activation_bound_to_preflight",
      pass: activationBound,
      note: activationBound
        ? `activationRecord.preflightId === preflightRecord.preflightId (${preflightRecord.preflightId})`
        : `activation-preflight mismatch: activation.preflightId=${activationRecord.preflightId} vs preflight.preflightId=${preflightRecord.preflightId}`,
    },
    {
      rule: "preflight_bound_to_approval",
      pass: preflightBound,
      note: preflightBound
        ? `preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId (${approvalTokenRecord.approvalTokenId})`
        : `preflight-approval mismatch: preflight.approvalTokenId=${preflightRecord.approvalTokenId} vs token.approvalTokenId=${approvalTokenRecord.approvalTokenId}`,
    },
    {
      rule: "approval_bound_to_dry_run",
      pass: approvalBound,
      note: approvalBound
        ? `approvalTokenRecord.dryRunId === dryRunRecord.dryRunId (${dryRunRecord.dryRunId})`
        : `approval-dryRun mismatch: token.dryRunId=${approvalTokenRecord.dryRunId} vs dryRun.dryRunId=${dryRunRecord.dryRunId}`,
    },
    {
      rule: "rollback_chain_valid",
      pass: rollbackChainValid,
      note: rollbackChainValid
        ? "combined rollbackReady=true across activation + preflight + approvalToken + dryRun + commitGate records"
        : "combined rollbackReady=false — one or more upstream records report rollbackReady=false",
    },
    {
      rule: "activation_switch_still_disabled",
      pass: true,
      note: "activationSwitchEnabled=false — compile-time literal; no execution phase has enabled the activation switch",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "switchState=descriptor_switch_pending — output is a descriptor only; explicitly separating prepared from enabled",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly SwitchCheck[]): readonly SwitchBlockedReason[] {
  const staticReasons: SwitchBlockedReason[] = [
    { code: "activation_switch_disabled",  reason: "activationSwitchEnabled=false — compile-time literal; an explicit activation-switch execution phase must set this to true", static: true },
    { code: "approval_required",           reason: "approvalRequired=true — explicit operator approval is required before the activation switch can be flipped",               static: true },
    { code: "actual_writes_disabled",      reason: "actualWritesEnabled=false — compile-time literal across all 15 sealed write-preparation and activation layers",            static: true },
  ];
  const dynamicReasons: SwitchBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedActivationReference(
  input: CreateSwitchInput,
  rollbackChainValid: boolean,
): LinkedActivationReference {
  const { activationRecord, preflightRecord, approvalTokenRecord, commitGateRecord } = input;
  return {
    activationId:            activationRecord.activationId,
    preflightId:             preflightRecord.preflightId,
    approvalTokenId:         approvalTokenRecord.approvalTokenId,
    rollbackSnapshotId:      activationRecord.rollbackActivationReference.rollbackSnapshotId,
    commitGateId:            commitGateRecord.commitGateId,
    activationPrepared:      true,
    activationSwitchEnabled: false,
    rollbackChainValid,
    referenceNote:           "linked activation reference sources rollbackSnapshotId from activationRecord.rollbackActivationReference; switch disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createSwitchRecord(input: CreateSwitchInput): FirstActivationSwitchRecord {
  const { activationRecord, preflightRecord, approvalTokenRecord, dryRunRecord, commitGateRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid =
    activationRecord.activationReadinessReport.rollbackReady &&
    preflightRecord.preflightReadinessReport.rollbackReady &&
    approvalTokenRecord.approvalReadinessReport.rollbackReady &&
    dryRunRecord.dryRunReadinessReport.rollbackReady &&
    commitGateRecord.commitReadinessReport.rollbackReady;

  const allChecksPass    = checks.every((c) => c.pass);
  const blockedReasons   = buildBlockedReasons(checks);
  const linkedRef        = buildLinkedActivationReference(input, rollbackChainValid);

  const switchReadinessReport: SwitchReadinessReport = {
    activationPrepared:        true,
    activationSwitchEnabled:   false,
    actualWritesEnabled:       false,
    realWritesEnabled:         false,
    executionTransitionPending:true,
    approvalRequired:          true,
    allChecksPass,
    blockedReasonCount:        blockedReasons.length,
    rollbackChainValid,
    summary: `switchState=descriptor_switch_pending; activationSwitchEnabled=false; actualWritesEnabled=false; executionTransitionPending=true; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstActivationSwitchRecord = {
    activationSwitchId:          randomUUID(),
    switchState:                 "descriptor_switch_pending",
    approvalRequired:            true,
    activationPrepared:          true,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    executionTransitionPending:  true,
    filesystemMutationBlocked:   true,
    motherCoreMutationBlocked:   true,
    vaultMutationBlocked:        true,
    shellBlocked:                true,
    networkBlocked:              true,
    implementationPhase:         "descriptor_only",
    activationId:                activationRecord.activationId,
    preflightId:                 preflightRecord.preflightId,
    approvalTokenId:             approvalTokenRecord.approvalTokenId,
    dryRunId:                    dryRunRecord.dryRunId,
    commitGateId:                commitGateRecord.commitGateId,
    controlledExecutionId:       executionRecord.controlledExecutionId,
    switchChecks:                checks,
    switchBlockedReasons:        blockedReasons,
    switchReadinessReport,
    linkedActivationReference:   linkedRef,
    createdAt:                   new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listSwitchRecords(): readonly FirstActivationSwitchRecord[] {
  return _store.slice();
}

export function getSwitchSummary(): FirstActivationSwitchSummary {
  return {
    total:                       _store.length,
    byState:                     { descriptor_switch_pending: _store.length },
    activationPrepared:          true,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    executionTransitionPending:  true,
    approvalRequired:            true,
    filesystemMutationBlocked:   true,
    motherCoreMutationBlocked:   true,
    switchState:                 "descriptor_switch_pending",
    implementationPhase:         "descriptor_only",
  };
}
