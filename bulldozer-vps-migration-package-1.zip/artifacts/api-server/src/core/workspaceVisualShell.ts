import { createHash } from "node:crypto";

const EXECUTION_BLOCKED: true = true;

// --- Canonical type enums ---

export type WidgetType =
  | "metric"
  | "status"
  | "table"
  | "timeline"
  | "gauge"
  | "list"
  | "heatmap"
  | "scorecard"
  | "badge"
  | "chart";

export type WidgetSize = "small" | "medium" | "large" | "full";

export type RefreshCategory = "realtime" | "periodic" | "on-demand" | "static";

export type SectionId = "governance" | "observation" | "diagnostics" | "projects" | "activity";

export type NavigationGroupId = "overview" | "governance" | "observation" | "audit" | "diagnostics";

// --- Widget ---

export interface VisualWidget {
  widgetId: string;
  widgetType: WidgetType;
  title: string;
  sourceEndpoint: string;
  recommendedSize: WidgetSize;
  refreshCategory: RefreshCategory;
  executionBlocked: true;
}

// --- Panel ---

export interface VisualPanel {
  panelId: string;
  title: string;
  description: string;
  sectionId: SectionId;
  panelOrder: number;
  widgets: VisualWidget[];
  executionBlocked: true;
}

// --- Section summary ---

export interface VisualSection {
  sectionId: SectionId;
  title: string;
  description: string;
  sectionOrder: number;
  panelCount: number;
  widgetCount: number;
  executionBlocked: true;
}

// --- Layout summary ---

export interface WidgetLayout {
  totalWidgets: number;
  totalPanels: number;
  totalSections: number;
  widgetsByType: Record<WidgetType, number>;
  widgetsBySize: Record<WidgetSize, number>;
  widgetsByRefreshCategory: Record<RefreshCategory, number>;
  executionBlocked: true;
}

// --- Navigation ---

export interface DashboardNavigationItem {
  itemId: string;
  title: string;
  endpoint: string;
  itemOrder: number;
  executionBlocked: true;
}

export interface DashboardNavigationGroup {
  groupId: NavigationGroupId;
  title: string;
  groupOrder: number;
  items: DashboardNavigationItem[];
  executionBlocked: true;
}

// --- Root ---

export interface WorkspaceVisualShell {
  shellId: string;
  generatedAt: string;
  sections: VisualSection[];
  panels: VisualPanel[];
  navigationGroups: DashboardNavigationGroup[];
  layout: WidgetLayout;
  executionBlocked: true;
}

// --- Static panel + widget definitions ---

function w(
  widgetId: string,
  widgetType: WidgetType,
  title: string,
  sourceEndpoint: string,
  recommendedSize: WidgetSize,
  refreshCategory: RefreshCategory,
): VisualWidget {
  return { widgetId, widgetType, title, sourceEndpoint, recommendedSize, refreshCategory, executionBlocked: EXECUTION_BLOCKED };
}

function navItem(itemId: string, title: string, endpoint: string, itemOrder: number): DashboardNavigationItem {
  return { itemId, title, endpoint, itemOrder, executionBlocked: EXECUTION_BLOCKED };
}

// Governance panels
const PANELS_GOVERNANCE: VisualPanel[] = [
  {
    panelId: "governance-overview",
    title: "Governance Overview",
    description: "Weighted governance score, grade, and per-dimension breakdown",
    sectionId: "governance",
    panelOrder: 1,
    widgets: [
      w("governance-score-gauge",     "gauge",     "Governance Score",          "/api/workspace/governance/scorecard", "small",  "on-demand"),
      w("governance-grade-badge",     "badge",     "Governance Grade",          "/api/workspace/governance/scorecard", "small",  "on-demand"),
      w("governance-breakdown-table", "table",     "Score Breakdown",           "/api/workspace/governance/scorecard", "medium", "on-demand"),
      w("governance-recommendations", "list",      "Advisory Recommendations",  "/api/workspace/governance/scorecard", "medium", "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "policy-compliance",
    title: "Policy Compliance Ledger",
    description: "Per-policy observed/unobserved status with coverage metrics",
    sectionId: "governance",
    panelOrder: 2,
    widgets: [
      w("compliance-coverage-gauge",  "gauge",  "Coverage Percent",     "/api/workspace/policy/compliance", "medium", "periodic"),
      w("compliance-policy-table",    "table",  "Policy Ledger",        "/api/workspace/policy/compliance", "large",  "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "exposure-risk",
    title: "Policy Exposure Risk",
    description: "Write-surface risk classification and exposure scoring",
    sectionId: "governance",
    panelOrder: 3,
    widgets: [
      w("exposure-score-metric", "metric", "Exposure Score",      "/api/workspace/observation/exposure", "small",  "periodic"),
      w("exposure-grade-badge",  "badge",  "Exposure Grade",      "/api/workspace/observation/exposure", "small",  "periodic"),
      w("exposure-risk-table",   "table",  "Write Policy Risks",  "/api/workspace/observation/exposure", "medium", "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
];

// Observation panels
const PANELS_OBSERVATION: VisualPanel[] = [
  {
    panelId: "observation-heatmap",
    title: "Observation Heatmap",
    description: "Cold/warm/hot activity band matrix across all policies",
    sectionId: "observation",
    panelOrder: 1,
    widgets: [
      w("heatmap-matrix",        "heatmap", "Policy Activity Heatmap",  "/api/workspace/observation/heatmap", "full",   "on-demand"),
      w("heatmap-coverage-pct",  "gauge",   "Heatmap Coverage",         "/api/workspace/observation/heatmap", "small",  "on-demand"),
      w("heatmap-band-counts",   "metric",  "Band Distribution",         "/api/workspace/observation/heatmap", "small",  "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "coverage-trend",
    title: "Coverage Trend",
    description: "Current vs historical coverage comparison with delta and direction",
    sectionId: "observation",
    panelOrder: 2,
    widgets: [
      w("coverage-trend-chart", "chart",  "Coverage Trend",    "/api/workspace/observation/trend", "large", "periodic"),
      w("coverage-delta-badge", "badge",  "Trend Direction",   "/api/workspace/observation/trend", "small", "periodic"),
      w("coverage-delta-value", "metric", "Coverage Delta",    "/api/workspace/observation/trend", "small", "periodic"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "observation-probe",
    title: "Observation Probe",
    description: "Sequential health sweep across all 5 governance observation modules",
    sectionId: "observation",
    panelOrder: 3,
    widgets: [
      w("probe-status-badge",   "badge",  "Probe Health",        "/api/workspace/observation/probe", "small",  "realtime"),
      w("probe-timing-table",   "table",  "Sub-probe Timings",   "/api/workspace/observation/probe", "medium", "on-demand"),
      w("probe-pass-count",     "metric", "Passed Probes",       "/api/workspace/observation/probe", "small",  "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "ledger-analytics",
    title: "Ledger Analytics",
    description: "Historical governance analytics derived from the observation ledger history ring",
    sectionId: "observation",
    panelOrder: 4,
    widgets: [
      w("ledger-analytics-scorecard", "scorecard", "Analytics Summary",          "/api/workspace/observation/ledger/analytics", "medium", "on-demand"),
      w("ledger-history-chart",       "chart",     "Coverage Progression",       "/api/workspace/observation/ledger/analytics", "large",  "on-demand"),
      w("ledger-transitions-metric",  "metric",    "Governance Transitions",     "/api/workspace/observation/ledger/analytics", "small",  "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
];

// Diagnostics panels
const PANELS_DIAGNOSTICS: VisualPanel[] = [
  {
    panelId: "system-health",
    title: "System Health",
    description: "Live health check results across all registered subsystems",
    sectionId: "diagnostics",
    panelOrder: 1,
    widgets: [
      w("health-status-badge",  "badge", "Health Status",    "/api/healthz",      "small", "realtime"),
      w("health-checks-table",  "table", "All Health Checks","/api/health/full",  "large", "periodic"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "runtime-metrics",
    title: "Runtime Metrics",
    description: "Memory, CPU, request, and error counters from the running process",
    sectionId: "diagnostics",
    panelOrder: 2,
    widgets: [
      w("memory-usage-gauge",   "gauge",  "Memory Usage",     "/api/metrics", "small", "realtime"),
      w("request-count-metric", "metric", "Total Requests",   "/api/metrics", "small", "realtime"),
      w("error-count-metric",   "metric", "Total Errors",     "/api/metrics", "small", "realtime"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "event-detection",
    title: "Freeze & Crash Detection",
    description: "Event loop freeze detector and uncaught exception crash detector status",
    sectionId: "diagnostics",
    panelOrder: 3,
    widgets: [
      w("freeze-status-badge", "badge",  "Freeze Detector",  "/api/freeze", "small", "realtime"),
      w("crash-status-badge",  "badge",  "Crash Detector",   "/api/crash",  "small", "realtime"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
];

// Projects panels
const PANELS_PROJECTS: VisualPanel[] = [
  {
    panelId: "project-registry",
    title: "Project Registry",
    description: "Active, archived, and suspended project counts with capacity utilization",
    sectionId: "projects",
    panelOrder: 1,
    widgets: [
      w("project-count-metric",  "metric", "Total Projects",     "/api/workspace/summary", "small", "periodic"),
      w("capacity-gauge",        "gauge",  "Registry Capacity",  "/api/workspace/summary", "small", "periodic"),
      w("projects-status-table", "table",  "Projects List",      "/api/projects",           "large", "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "workspace-membership",
    title: "Workspace Membership",
    description: "Aggregate member records and quota adoption across the workspace",
    sectionId: "projects",
    panelOrder: 2,
    widgets: [
      w("member-count-metric", "metric", "Total Member Records", "/api/workspace/summary", "small", "periodic"),
      w("quota-coverage-metric","metric", "Projects with Quotas", "/api/workspace/summary", "small", "periodic"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
];

// Activity panels
const PANELS_ACTIVITY: VisualPanel[] = [
  {
    panelId: "workspace-timeline",
    title: "Workspace Timeline",
    description: "Chronological event feed spanning projects, membership, quota, and snapshot events",
    sectionId: "activity",
    panelOrder: 1,
    widgets: [
      w("timeline-feed", "timeline", "Event Timeline", "/api/workspace/timeline", "full", "periodic"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "change-detection",
    title: "Change Detection",
    description: "Snapshot diff pairs with field-level delta summaries",
    sectionId: "activity",
    panelOrder: 2,
    widgets: [
      w("diff-pairs-table", "table", "Snapshot Diff Pairs", "/api/workspace/diff", "medium", "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    panelId: "audit-trail",
    title: "Audit Trail",
    description: "Retained audit reports and aggregated governance digest",
    sectionId: "activity",
    panelOrder: 3,
    widgets: [
      w("audit-reports-list",     "list",      "Audit Reports",   "/api/workspace/audit/reports", "large",  "on-demand"),
      w("audit-digest-scorecard", "scorecard", "Audit Digest",    "/api/workspace/audit/digest",  "medium", "on-demand"),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
];

const ALL_PANELS: VisualPanel[] = [
  ...PANELS_GOVERNANCE,
  ...PANELS_OBSERVATION,
  ...PANELS_DIAGNOSTICS,
  ...PANELS_PROJECTS,
  ...PANELS_ACTIVITY,
];

// --- Navigation groups ---

const NAVIGATION_GROUPS: DashboardNavigationGroup[] = [
  {
    groupId: "overview",
    title: "Overview",
    groupOrder: 1,
    items: [
      navItem("nav-workspace-summary",    "Workspace Summary",   "/api/workspace/summary",    1),
      navItem("nav-workspace-health",     "Workspace Health",    "/api/workspace/health",     2),
      navItem("nav-workspace-navigation", "Navigation Panels",   "/api/workspace/navigation", 3),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    groupId: "governance",
    title: "Governance",
    groupOrder: 2,
    items: [
      navItem("nav-governance-scorecard", "Governance Scorecard", "/api/workspace/governance/scorecard", 1),
      navItem("nav-policy-compliance",    "Policy Compliance",    "/api/workspace/policy/compliance",    2),
      navItem("nav-exposure-index",       "Exposure Risk Index",  "/api/workspace/observation/exposure", 3),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    groupId: "observation",
    title: "Observation",
    groupOrder: 3,
    items: [
      navItem("nav-observation-heatmap",  "Policy Heatmap",      "/api/workspace/observation/heatmap",          1),
      navItem("nav-coverage-trend",       "Coverage Trend",      "/api/workspace/observation/trend",            2),
      navItem("nav-observation-probe",    "Observation Probe",   "/api/workspace/observation/probe",            3),
      navItem("nav-observation-ledger",   "Observation Ledger",  "/api/workspace/observation/ledger",           4),
      navItem("nav-ledger-history",       "Ledger History",      "/api/workspace/observation/ledger/history",   5),
      navItem("nav-ledger-analytics",     "Ledger Analytics",    "/api/workspace/observation/ledger/analytics", 6),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    groupId: "audit",
    title: "Audit",
    groupOrder: 4,
    items: [
      navItem("nav-audit-reports",  "Audit Reports",     "/api/workspace/audit/reports",  1),
      navItem("nav-audit-digest",   "Audit Digest",      "/api/workspace/audit/digest",   2),
      navItem("nav-snapshots",      "Workspace Snapshots","/api/workspace/snapshots",      3),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    groupId: "diagnostics",
    title: "Diagnostics",
    groupOrder: 5,
    items: [
      navItem("nav-health-full",     "Health Checks",       "/api/health/full",           1),
      navItem("nav-metrics",         "Runtime Metrics",     "/api/metrics",               2),
      navItem("nav-freeze",          "Freeze Detector",     "/api/freeze",                3),
      navItem("nav-crash",           "Crash Detector",      "/api/crash",                 4),
      navItem("nav-diag-snapshot",   "Diagnostics Snapshot","/api/diagnostics/snapshot",  5),
    ],
    executionBlocked: EXECUTION_BLOCKED,
  },
];

// --- Layout computation ---

function computeLayout(panels: VisualPanel[]): WidgetLayout {
  const allWidgets = panels.flatMap((p) => p.widgets);

  const byType: Record<WidgetType, number> = {
    metric: 0, status: 0, table: 0, timeline: 0, gauge: 0,
    list: 0, heatmap: 0, scorecard: 0, badge: 0, chart: 0,
  };
  const bySize: Record<WidgetSize, number> = { small: 0, medium: 0, large: 0, full: 0 };
  const byRefresh: Record<RefreshCategory, number> = { realtime: 0, periodic: 0, "on-demand": 0, static: 0 };

  for (const w of allWidgets) {
    byType[w.widgetType]++;
    bySize[w.recommendedSize]++;
    byRefresh[w.refreshCategory]++;
  }

  return {
    totalWidgets: allWidgets.length,
    totalPanels: panels.length,
    totalSections: 5,
    widgetsByType: byType,
    widgetsBySize: bySize,
    widgetsByRefreshCategory: byRefresh,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Section ordering ---

const SECTION_DEFS: Array<{ sectionId: SectionId; title: string; description: string; sectionOrder: number }> = [
  { sectionId: "governance",   title: "Governance",   description: "Policy compliance, governance scoring, and write-surface exposure risk",                           sectionOrder: 1 },
  { sectionId: "observation",  title: "Observation",  description: "Policy observation heatmap, coverage trend, probe health, and ledger analytics",                   sectionOrder: 2 },
  { sectionId: "diagnostics",  title: "Diagnostics",  description: "Runtime health checks, process metrics, freeze detection, and crash detection",                    sectionOrder: 3 },
  { sectionId: "projects",     title: "Projects",     description: "Project registry, capacity, membership records, and quota adoption",                               sectionOrder: 4 },
  { sectionId: "activity",     title: "Activity",     description: "Workspace timeline, snapshot change detection, and audit trail",                                   sectionOrder: 5 },
];

// --- Public API ---

export function getWorkspaceVisualShell(): WorkspaceVisualShell {
  const generatedAt = new Date().toISOString();
  const shellId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  const sections: VisualSection[] = SECTION_DEFS.map((def) => {
    const sectionPanels = ALL_PANELS.filter((p) => p.sectionId === def.sectionId);
    const widgetCount = sectionPanels.reduce((sum, p) => sum + p.widgets.length, 0);
    return {
      sectionId: def.sectionId,
      title: def.title,
      description: def.description,
      sectionOrder: def.sectionOrder,
      panelCount: sectionPanels.length,
      widgetCount,
      executionBlocked: EXECUTION_BLOCKED,
    };
  });

  const layout = computeLayout(ALL_PANELS);

  return {
    shellId,
    generatedAt,
    sections,
    panels: ALL_PANELS,
    navigationGroups: NAVIGATION_GROUPS,
    layout,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
