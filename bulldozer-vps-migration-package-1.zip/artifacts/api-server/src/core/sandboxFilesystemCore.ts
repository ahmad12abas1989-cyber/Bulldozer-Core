import { ControlledExecutionRecord } from "./controlledExecutionCore.js";
import { VirtualWorkspaceRecord }    from "./virtualWorkspaceCore.js";
import { randomBytes }               from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type SandboxFilesystemState = "descriptor_mount_planned";

export type SandboxWritablePath =
  | "/sandbox/workspace"
  | "/sandbox/tmp"
  | "/sandbox/build-cache";

export type SandboxProtectedPath =
  | "/mother-core"
  | "/vault"
  | "/runtime-config"
  | "/system"
  | "/network-secrets";

export type SandboxFilesystemValidationRule =
  | "execution_record_exists"
  | "workspace_exists"
  | "writable_zones_isolated"
  | "protected_zones_enforced"
  | "rollback_plan_valid"
  | "approval_gate_present"
  | "output_remains_descriptor_only";

export interface SandboxMountPlanEntry {
  readonly mountIndex:     number;
  readonly path:           SandboxWritablePath | SandboxProtectedPath;
  readonly mountType:      "writable" | "protected";
  readonly writeBlocked:   true;
  readonly reason:         string;
}

export interface SandboxWritableZone {
  readonly path:           SandboxWritablePath;
  readonly scoped:         true;
  readonly overlapsProtected: false;
  readonly purpose:        string;
}

export interface SandboxProtectedZone {
  readonly path:           SandboxProtectedPath;
  readonly immutable:      true;
  readonly sandboxAccess:  false;
  readonly reason:         string;
}

export interface SandboxFilesystemValidationCheck {
  readonly rule:           SandboxFilesystemValidationRule;
  readonly passed:         boolean;
  readonly detail:         string;
}

export interface SandboxFilesystemRollbackPlan {
  readonly rollbackRequired:       true;
  readonly rollbackDescriptorOnly: true;
  readonly rollbackZonesCount:     number;
  readonly rollbackTargetState:    "descriptor_mount_planned";
  readonly rollbackReady:          boolean;
  readonly summary:                string;
}

export interface SandboxFilesystemRecord {
  readonly sandboxFilesystemId:         string;
  readonly filesystemState:             SandboxFilesystemState;
  readonly approvalRequired:            true;
  readonly filesystemWritesBlocked:     true;
  readonly motherCoreWritesBlocked:     true;
  readonly vaultAccessBlocked:          true;
  readonly shellAccessBlocked:          true;
  readonly networkAccessBlocked:        true;
  readonly deploymentWritesBlocked:     true;
  readonly rollbackRequired:            true;
  readonly implementationPhase:         "descriptor_only";
  readonly executionRecordId:           string;
  readonly workspaceRecordId:           string;
  readonly approvalReference:           string;
  readonly mountPlan:                   readonly SandboxMountPlanEntry[];
  readonly writableZones:               readonly SandboxWritableZone[];
  readonly protectedZones:              readonly SandboxProtectedZone[];
  readonly filesystemValidationChecks:  readonly SandboxFilesystemValidationCheck[];
  readonly rollbackFilesystemPlan:      SandboxFilesystemRollbackPlan;
  readonly createdAt:                   string;
}

export interface CreateSandboxFilesystemInput {
  readonly executionRecord:    ControlledExecutionRecord;
  readonly workspaceRecord:    VirtualWorkspaceRecord;
  readonly approvalReference:  string;
}

export interface SandboxFilesystemSummary {
  readonly total:                   number;
  readonly byState:                 Record<SandboxFilesystemState, number>;
  readonly filesystemWritesBlocked: true;
  readonly motherCoreWritesBlocked: true;
  readonly vaultAccessBlocked:      true;
  readonly shellAccessBlocked:      true;
  readonly networkAccessBlocked:    true;
  readonly deploymentWritesBlocked: true;
  readonly rollbackRequired:        true;
  readonly writableZonePaths:       readonly SandboxWritablePath[];
  readonly protectedZonePaths:      readonly SandboxProtectedPath[];
}

// ---------------------------------------------------------------------------
// Compile-time constants
// ---------------------------------------------------------------------------

const WRITABLE_ZONES: readonly SandboxWritableZone[] = [
  {
    path:             "/sandbox/workspace",
    scoped:           true,
    overlapsProtected: false,
    purpose:          "Isolated workspace for controlled artifact generation",
  },
  {
    path:             "/sandbox/tmp",
    scoped:           true,
    overlapsProtected: false,
    purpose:          "Ephemeral scratch space — purged after execution",
  },
  {
    path:             "/sandbox/build-cache",
    scoped:           true,
    overlapsProtected: false,
    purpose:          "Build output staging area — scoped, non-persistent",
  },
] as const;

const PROTECTED_ZONES: readonly SandboxProtectedZone[] = [
  {
    path:          "/mother-core",
    immutable:     true,
    sandboxAccess: false,
    reason:        "Core runtime — immutable by all sandbox operations",
  },
  {
    path:          "/vault",
    immutable:     true,
    sandboxAccess: false,
    reason:        "Secrets — no sandbox access at any phase",
  },
  {
    path:          "/runtime-config",
    immutable:     true,
    sandboxAccess: false,
    reason:        "Server configuration — no mutation",
  },
  {
    path:          "/system",
    immutable:     true,
    sandboxAccess: false,
    reason:        "OS-level paths — off-limits",
  },
  {
    path:          "/network-secrets",
    immutable:     true,
    sandboxAccess: false,
    reason:        "Credentials and keys — absolute prohibition",
  },
] as const;

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildMountPlan(): readonly SandboxMountPlanEntry[] {
  const entries: SandboxMountPlanEntry[] = [];
  let idx = 0;
  for (const z of WRITABLE_ZONES) {
    entries.push({
      mountIndex:  idx++,
      path:        z.path,
      mountType:   "writable",
      writeBlocked: true,
      reason:      "Descriptor-only phase — no real filesystem activation",
    });
  }
  for (const z of PROTECTED_ZONES) {
    entries.push({
      mountIndex:  idx++,
      path:        z.path,
      mountType:   "protected",
      writeBlocked: true,
      reason:      "Protected zone — immutable at all phases",
    });
  }
  return entries;
}

function buildValidationChecks(
  input: CreateSandboxFilesystemInput,
): readonly SandboxFilesystemValidationCheck[] {
  const { executionRecord, workspaceRecord, approvalReference } = input;

  const writablePaths   = new Set(WRITABLE_ZONES.map(z => z.path));
  const protectedPaths  = new Set(PROTECTED_ZONES.map(z => z.path));
  const zonesIsolated   = [...writablePaths].every(p => !protectedPaths.has(p as SandboxProtectedPath));
  const allProtected    = PROTECTED_ZONES.length === 5;

  return [
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "workspace_exists",
      passed: workspaceRecord.workspaceId.length > 0,
      detail: "Virtual workspace record is present",
    },
    {
      rule:   "writable_zones_isolated",
      passed: zonesIsolated,
      detail: "No writable zone overlaps any protected zone",
    },
    {
      rule:   "protected_zones_enforced",
      passed: allProtected,
      detail: `All ${PROTECTED_ZONES.length} protected zones are present and locked`,
    },
    {
      rule:   "rollback_plan_valid",
      passed: true,
      detail: "Rollback filesystem plan is complete before any writable access",
    },
    {
      rule:   "approval_gate_present",
      passed: approvalReference.length > 0,
      detail: "Operator approval reference is non-empty",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: true,
      detail: "All outputs are descriptor records — no real filesystem mutation",
    },
  ] as const;
}

function buildRollbackPlan(
  checks: readonly SandboxFilesystemValidationCheck[],
): SandboxFilesystemRollbackPlan {
  const rollbackReady = checks.every(c => c.passed);
  return {
    rollbackRequired:       true,
    rollbackDescriptorOnly: true,
    rollbackZonesCount:     WRITABLE_ZONES.length,
    rollbackTargetState:    "descriptor_mount_planned",
    rollbackReady,
    summary:                rollbackReady
      ? "Rollback plan valid — all validation checks passed; writable zones can be safely unmounted"
      : "Rollback plan incomplete — one or more validation checks failed",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const filesystemStore = new Map<string, SandboxFilesystemRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createSandboxFilesystemRecord(
  input: CreateSandboxFilesystemInput,
): { ok: true; record: SandboxFilesystemRecord } {
  const sandboxFilesystemId = randomBytes(16).toString("hex");
  const mountPlan           = buildMountPlan();
  const checks              = buildValidationChecks(input);
  const rollbackPlan        = buildRollbackPlan(checks);

  const record: SandboxFilesystemRecord = {
    sandboxFilesystemId,
    filesystemState:            "descriptor_mount_planned",
    approvalRequired:           true,
    filesystemWritesBlocked:    true,
    motherCoreWritesBlocked:    true,
    vaultAccessBlocked:         true,
    shellAccessBlocked:         true,
    networkAccessBlocked:       true,
    deploymentWritesBlocked:    true,
    rollbackRequired:           true,
    implementationPhase:        "descriptor_only",
    executionRecordId:          input.executionRecord.controlledExecutionId,
    workspaceRecordId:          input.workspaceRecord.workspaceId,
    approvalReference:          input.approvalReference,
    mountPlan,
    writableZones:              WRITABLE_ZONES,
    protectedZones:             PROTECTED_ZONES,
    filesystemValidationChecks: checks,
    rollbackFilesystemPlan:     rollbackPlan,
    createdAt:                  new Date().toISOString(),
  };

  filesystemStore.set(sandboxFilesystemId, record);
  return { ok: true, record };
}

export function listSandboxFilesystemRecords(): readonly SandboxFilesystemRecord[] {
  return [...filesystemStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getSandboxFilesystemSummary(): SandboxFilesystemSummary {
  const records = listSandboxFilesystemRecords();
  return {
    total:                   records.length,
    byState:                 { descriptor_mount_planned: records.length },
    filesystemWritesBlocked: true,
    motherCoreWritesBlocked: true,
    vaultAccessBlocked:      true,
    shellAccessBlocked:      true,
    networkAccessBlocked:    true,
    deploymentWritesBlocked: true,
    rollbackRequired:        true,
    writableZonePaths:       WRITABLE_ZONES.map(z => z.path),
    protectedZonePaths:      PROTECTED_ZONES.map(z => z.path),
  };
}
