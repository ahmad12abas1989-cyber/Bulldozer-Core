import { IncomingMessage, ServerResponse } from "node:http";
import { sendJson }                        from "../lib/response.js";
import {
  listExperimentalProductionFlowRecords,
  getExperimentalProductionFlowSummary,
} from "../core/experimentalProductionFlowCore.js";

export function handleExperimentalProductionFlowObserve(
  req: IncomingMessage,
  res: ServerResponse,
): void {
  const flows   = listExperimentalProductionFlowRecords();
  const summary = getExperimentalProductionFlowSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    flowEnabled:        false,
    executionEnabled:   false,
    filesystemEnabled:  false,
    deploymentEnabled:  false,
    persistenceEnabled: false,
    allStagesBlocked:   true,
    executionBlocked:   true,
    filesystemBlocked:  true,
    deploymentBlocked:  true,
    totalFlows:         flows.length,
    summary,
    flows,
  });
}
