// Template Registry Core — Phase 212
// In-memory, metadata-only template registry.
// Pure module — no init, not wired to runtime.ts, not wired to any request flow.
// No file generation, no executable code, no filesystem writes, no network access,
// no vault access, no deployment access. Metadata descriptors only.

import { randomBytes } from "node:crypto";

// ─── Types ────────────────────────────────────────────────────────────────────

export type TemplateType =
  | "crud_template"
  | "pos_invoice_template"
  | "dashboard_template"
  | "api_service_template"
  | "admin_panel_template"
  | "content_module_template";

export type TemplateLifecycleStatus =
  | "register_metadata"
  | "review"
  | "sandbox_validate"
  | "operator_approval"
  | "enable"
  | "deprecate"
  | "revoke";

// AppFactoryAppType mirrored here to avoid cross-module coupling — Phase 208 defines the canonical set.
export type SupportedAppType =
  | "crud_app"
  | "pos_invoice_app"
  | "dashboard_app"
  | "api_service"
  | "admin_panel"
  | "content_production_module";

export interface TemplateMetadataRecord {
  readonly templateId: string;             // server-generated 16-byte hex
  readonly templateType: TemplateType;
  readonly name: string;
  readonly version: string;
  readonly supportedAppTypes: readonly SupportedAppType[];
  readonly requiredInputs: readonly string[];
  readonly generatedArtifactTypes: readonly string[];
  readonly requestedByActorType: string;
  readonly requestedByActorId: string;
  readonly approvalRequired: true;         // literal — always true, never configurable
  readonly status: "register_metadata";    // always at creation — lifecycle transitions are future-phase
  readonly registeredAt: string;           // server-generated ISO 8601
}

// Input accepted from callers — structurally excludes:
// code, files, command, script, path, networkFlag, secretValue
export interface RegisterTemplateMetadataInput {
  readonly templateType: TemplateType;
  readonly name: string;
  readonly version: string;
  readonly supportedAppTypes: readonly SupportedAppType[];
  readonly requiredInputs: readonly string[];
  readonly generatedArtifactTypes: readonly string[];
  readonly requestedByActorType: string;
  readonly requestedByActorId: string;
}

export interface TemplateRegistrySummary {
  readonly totalTemplates: number;
  readonly byType: Record<TemplateType, number>;
  readonly byStatus: Record<TemplateLifecycleStatus, number>;
  readonly pendingReviewCount: number;       // status === "review"
  readonly approvalRequired: true;           // literal
  readonly executionEnabled: false;          // literal
  readonly persistenceEnabled: false;        // literal
  readonly implementationPhase: "skeleton";  // literal
}

// ─── In-memory store ──────────────────────────────────────────────────────────

const store: TemplateMetadataRecord[] = [];

// ─── Public API ───────────────────────────────────────────────────────────────

export function registerTemplateMetadata(
  input: RegisterTemplateMetadataInput,
): { ok: true; record: TemplateMetadataRecord } {
  const record: TemplateMetadataRecord = {
    templateId:             randomBytes(16).toString("hex"),
    templateType:           input.templateType,
    name:                   input.name,
    version:                input.version,
    supportedAppTypes:      input.supportedAppTypes,
    requiredInputs:         input.requiredInputs,
    generatedArtifactTypes: input.generatedArtifactTypes,
    requestedByActorType:   input.requestedByActorType,
    requestedByActorId:     input.requestedByActorId,
    approvalRequired:       true,
    status:                 "register_metadata",
    registeredAt:           new Date().toISOString(),
  };
  store.push(record);
  return { ok: true, record };
}

export function listTemplateMetadata(): TemplateMetadataRecord[] {
  return store.slice().reverse(); // newest-first
}

export function getTemplateSummary(): TemplateRegistrySummary {
  const byType = {
    crud_template:           0,
    pos_invoice_template:    0,
    dashboard_template:      0,
    api_service_template:    0,
    admin_panel_template:    0,
    content_module_template: 0,
  } satisfies Record<TemplateType, number>;

  const byStatus = {
    register_metadata: 0,
    review:            0,
    sandbox_validate:  0,
    operator_approval: 0,
    enable:            0,
    deprecate:         0,
    revoke:            0,
  } satisfies Record<TemplateLifecycleStatus, number>;

  for (const r of store) {
    byType[r.templateType]++;
    byStatus[r.status]++;
  }

  return {
    totalTemplates:      store.length,
    byType,
    byStatus,
    pendingReviewCount:  byStatus.review,
    approvalRequired:    true,
    executionEnabled:    false,
    persistenceEnabled:  false,
    implementationPhase: "skeleton",
  };
}
