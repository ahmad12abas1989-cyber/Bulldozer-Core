import { registerSubsystemState } from "./runtimeStateRegistry";
import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";

export type ActorType = "system" | "owner" | "service" | "anonymous";
export type Role = "owner" | "admin" | "operator" | "viewer" | "guest";
export type PermissionCategory =
  | "read"
  | "write"
  | "monitor"
  | "configure"
  | "billing"
  | "deploy"
  | "execute";

export interface PermissionEntry {
  category: PermissionCategory;
  granted: boolean;
  blocked: boolean;
}

export interface RoleDefinition {
  role: Role;
  description: string;
  actorTypes: ActorType[];
  permissions: PermissionEntry[];
}

export interface IdentityAccessStatus {
  operational: boolean;
  subsystemName: "identity_access";
  authEnabled: false;
  actorTypes: ActorType[];
  roleCount: number;
  permissionCategories: PermissionCategory[];
  executeBlocked: true;
  executionBlocked: true;
  recoveryBlocked: true;
  initializedAt: string | null;
}

export interface IdentityRolesResult {
  executionBlocked: true;
  recoveryBlocked: true;
  count: number;
  roles: RoleDefinition[];
}

const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;
const EXECUTE_BLOCKED: true = true;

const ACTOR_TYPES: ActorType[] = ["system", "owner", "service", "anonymous"];

const PERMISSION_CATEGORIES: PermissionCategory[] = [
  "read",
  "write",
  "monitor",
  "configure",
  "billing",
  "deploy",
  "execute",
];

const ROLE_DEFINITIONS: RoleDefinition[] = [
  {
    role: "owner",
    description: "Full infrastructure visibility except execute — owner actor only",
    actorTypes: ["owner", "system"],
    permissions: [
      { category: "read", granted: true, blocked: false },
      { category: "write", granted: true, blocked: false },
      { category: "monitor", granted: true, blocked: false },
      { category: "configure", granted: true, blocked: false },
      { category: "billing", granted: true, blocked: false },
      { category: "deploy", granted: true, blocked: false },
      { category: "execute", granted: false, blocked: true },
    ],
  },
  {
    role: "admin",
    description: "Read, write, monitor, configure — no billing, deploy, or execute",
    actorTypes: ["service"],
    permissions: [
      { category: "read", granted: true, blocked: false },
      { category: "write", granted: true, blocked: false },
      { category: "monitor", granted: true, blocked: false },
      { category: "configure", granted: true, blocked: false },
      { category: "billing", granted: false, blocked: false },
      { category: "deploy", granted: false, blocked: false },
      { category: "execute", granted: false, blocked: true },
    ],
  },
  {
    role: "operator",
    description: "Read and monitor only — no write, configure, billing, deploy, or execute",
    actorTypes: ["service"],
    permissions: [
      { category: "read", granted: true, blocked: false },
      { category: "write", granted: false, blocked: false },
      { category: "monitor", granted: true, blocked: false },
      { category: "configure", granted: false, blocked: false },
      { category: "billing", granted: false, blocked: false },
      { category: "deploy", granted: false, blocked: false },
      { category: "execute", granted: false, blocked: true },
    ],
  },
  {
    role: "viewer",
    description: "Read and monitor only — read-only observation, no side effects",
    actorTypes: ["service", "anonymous"],
    permissions: [
      { category: "read", granted: true, blocked: false },
      { category: "write", granted: false, blocked: false },
      { category: "monitor", granted: true, blocked: false },
      { category: "configure", granted: false, blocked: false },
      { category: "billing", granted: false, blocked: false },
      { category: "deploy", granted: false, blocked: false },
      { category: "execute", granted: false, blocked: true },
    ],
  },
  {
    role: "guest",
    description: "Read only — minimal access, no monitor, configure, billing, deploy, or execute",
    actorTypes: ["anonymous"],
    permissions: [
      { category: "read", granted: true, blocked: false },
      { category: "write", granted: false, blocked: false },
      { category: "monitor", granted: false, blocked: false },
      { category: "configure", granted: false, blocked: false },
      { category: "billing", granted: false, blocked: false },
      { category: "deploy", granted: false, blocked: false },
      { category: "execute", granted: false, blocked: true },
    ],
  },
];

let isOperational = false;
let initializedAt: string | null = null;

export function initIdentityAccess(): void {
  if (isOperational) return;

  registerSubsystemState({
    subsystemName: "identity_access",
    category: "identity",
    dependencies: ["runtime_state_registry"],
    metadata: {
      description:
        "Identity & access foundation — 4 actor types, 5 roles, 7 permission categories, execute always blocked",
    },
  });

  isOperational = true;
  initializedAt = new Date().toISOString();

  addTimelineEvent({
    level: "info",
    source: "identity-access",
    message: "Identity access foundation initialized",
    metadata: {
      actorTypes: ACTOR_TYPES.length,
      roles: ROLE_DEFINITIONS.length,
      permissionCategories: PERMISSION_CATEGORIES.length,
      executeBlocked: EXECUTE_BLOCKED,
    },
  });

  emit("identity_access:initialized", "identity-access", {
    actorTypes: ACTOR_TYPES.length,
    roles: ROLE_DEFINITIONS.length,
    executeBlocked: EXECUTE_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "identity_access.initialized",
    source: "identity-access",
    severity: "info",
    category: "runtime",
    payload: {
      actorTypes: ACTOR_TYPES.length,
      roles: ROLE_DEFINITIONS.length,
      permissionCategories: PERMISSION_CATEGORIES.length,
      executeBlocked: EXECUTE_BLOCKED,
    },
  });

  logger.info(
    {
      actorTypes: ACTOR_TYPES.length,
      roles: ROLE_DEFINITIONS.length,
      executeBlocked: EXECUTE_BLOCKED,
    },
    "Identity access foundation initialized",
  );
}

export function getIdentityAccessStatus(): IdentityAccessStatus {
  return {
    operational: isOperational,
    subsystemName: "identity_access",
    authEnabled: false,
    actorTypes: [...ACTOR_TYPES],
    roleCount: ROLE_DEFINITIONS.length,
    permissionCategories: [...PERMISSION_CATEGORIES],
    executeBlocked: EXECUTE_BLOCKED,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    initializedAt,
  };
}

export interface ResolvedIdentity {
  actorId: string | undefined;
  actorType: ActorType;
  role: Role;
  source: "api_key" | "headers" | "default";
}

const VALID_ACTOR_TYPE_SET = new Set<string>(ACTOR_TYPES);
const VALID_ROLE_SET = new Set<string>(["owner", "admin", "operator", "viewer", "guest"] as const);
const ACTOR_ID_MAX_LENGTH = 128;

export function resolveRequestIdentity(
  rawActorId: string | undefined,
  rawActorType: string | undefined,
  rawRole: string | undefined,
): ResolvedIdentity {
  const actorId =
    typeof rawActorId === "string" && rawActorId.length > 0 && rawActorId.length <= ACTOR_ID_MAX_LENGTH
      ? rawActorId
      : undefined;

  const actorType: ActorType =
    typeof rawActorType === "string" && VALID_ACTOR_TYPE_SET.has(rawActorType)
      ? (rawActorType as ActorType)
      : "anonymous";

  const role: Role =
    typeof rawRole === "string" && VALID_ROLE_SET.has(rawRole)
      ? (rawRole as Role)
      : "guest";

  const headerPresent =
    rawActorId !== undefined || rawActorType !== undefined || rawRole !== undefined;

  return { actorId, actorType, role, source: headerPresent ? "headers" : "default" };
}

export function listRoleDefinitions(): IdentityRolesResult {
  return {
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    count: ROLE_DEFINITIONS.length,
    roles: ROLE_DEFINITIONS.map((r) => ({
      ...r,
      actorTypes: [...r.actorTypes],
      permissions: r.permissions.map((p) => ({ ...p })),
    })),
  };
}
