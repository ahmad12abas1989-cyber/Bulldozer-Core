import { mkdirSync, writeFileSync, readFileSync, renameSync, existsSync } from "node:fs";
import { join } from "node:path";
import { logger } from "../lib/logger";
import { config } from "./config";
import { getRuntimeInfo } from "./runtime";
import { getWatchdogStatus } from "./watchdog";
import { getRestartSupervisorStatus } from "./restartSupervisor";
import { getFreezeStatus } from "./freezeDetector";
import { getCrashStatus } from "./crashDetector";
import { emit, subscribe } from "./eventBus";
import { addTimelineEvent } from "./timeline";

export interface PersistedRuntimeState {
  savedAt: string;
  runtime: {
    state: string;
    uptimeMs: number;
    env: string;
    port: number;
  };
  watchdog: {
    status: string;
    degradedCount: number;
    missedHealthChecks: number;
    lastDegradedAt: string | null;
  };
  restartSupervisor: {
    restartRecommended: boolean;
    recommendationReason: string | null;
    recommendationCount: number;
    blockedExecution: true;
  };
  freeze: {
    status: string;
    freezeCount: number;
  };
  crash: {
    status: string;
    crashCount: number;
  };
  lastSnapshotId: string | null;
  healthSummary: "healthy" | "degraded" | "unhealthy";
}

export interface RuntimeStatePersistenceStatus {
  operational: boolean;
  lastSavedAt: string | null;
  lastLoadedAt: string | null;
  saveCount: number;
  hasPersistedState: boolean;
  latestState: PersistedRuntimeState | null;
  storageDir: string;
  timestamp: string;
}

const STORAGE_DIR = join(config.storageDir, "runtime-state");
const STATE_FILE = join(STORAGE_DIR, "runtime-state.json");
const STATE_FILE_TMP = join(STORAGE_DIR, "runtime-state.json.tmp");
const STALE_THRESHOLD_MS = 120_000;

let lastSavedAt: string | null = null;
let lastLoadedAt: string | null = null;
let saveCount = 0;
let hasPersistedState = false;
let latestState: PersistedRuntimeState | null = null;
let lastSnapshotId: string | null = null;

function deriveHealthSummary(
  crashStatus: string,
  restartRecommended: boolean,
  watchdogStatus: string,
  freezeStatus: string,
): "healthy" | "degraded" | "unhealthy" {
  if (crashStatus === "crashed" || restartRecommended) return "unhealthy";
  if (watchdogStatus === "degraded" || freezeStatus !== "normal") return "degraded";
  return "healthy";
}

export function saveRuntimeState(): void {
  try {
    mkdirSync(STORAGE_DIR, { recursive: true });

    const runtimeInfo = getRuntimeInfo();
    const watchdogState = getWatchdogStatus();
    const supervisorState = getRestartSupervisorStatus();
    const freezeState = getFreezeStatus();
    const crashState = getCrashStatus();

    const now = new Date().toISOString();

    const state: PersistedRuntimeState = {
      savedAt: now,
      runtime: {
        state: runtimeInfo.state,
        uptimeMs: runtimeInfo.uptimeMs,
        env: runtimeInfo.env,
        port: runtimeInfo.port,
      },
      watchdog: {
        status: watchdogState.status,
        degradedCount: watchdogState.degradedCount,
        missedHealthChecks: watchdogState.missedHealthChecks,
        lastDegradedAt: watchdogState.lastDegradedAt,
      },
      restartSupervisor: {
        restartRecommended: supervisorState.restartRecommended,
        recommendationReason: supervisorState.recommendationReason,
        recommendationCount: supervisorState.recommendationCount,
        blockedExecution: true,
      },
      freeze: {
        status: freezeState.status,
        freezeCount: freezeState.freezeCount,
      },
      crash: {
        status: crashState.status,
        crashCount: crashState.crashCount,
      },
      lastSnapshotId,
      healthSummary: deriveHealthSummary(
        crashState.status,
        supervisorState.restartRecommended,
        watchdogState.status,
        freezeState.status,
      ),
    };

    writeFileSync(STATE_FILE_TMP, JSON.stringify(state, null, 2), "utf8");
    renameSync(STATE_FILE_TMP, STATE_FILE);

    lastSavedAt = now;
    saveCount++;
    latestState = state;
    hasPersistedState = true;

    logger.info({ saveCount, healthSummary: state.healthSummary }, "Runtime state persisted");
  } catch (err) {
    logger.warn({ err: String(err) }, "Failed to persist runtime state");
  }
}

export function loadRuntimeState(): PersistedRuntimeState | null {
  try {
    if (!existsSync(STATE_FILE)) return null;
    const content = readFileSync(STATE_FILE, "utf8");
    const state = JSON.parse(content) as PersistedRuntimeState;
    lastLoadedAt = new Date().toISOString();
    hasPersistedState = true;
    latestState = state;
    logger.info({ savedAt: state.savedAt }, "Runtime state loaded from disk");
    return state;
  } catch (err) {
    logger.warn({ err: String(err) }, "Failed to load runtime state from disk");
    return null;
  }
}

export function initRuntimeStatePersistence(): void {
  mkdirSync(STORAGE_DIR, { recursive: true });

  const existing = loadRuntimeState();
  if (existing) {
    addTimelineEvent({
      level: "info",
      source: "runtime-state",
      message: "Previous runtime state found on disk",
      metadata: { savedAt: existing.savedAt, healthSummary: existing.healthSummary },
    });
  }

  subscribe("snapshot:created", (event) => {
    const id = event.payload["id"];
    if (typeof id === "string") lastSnapshotId = id;
    saveRuntimeState();
  });

  subscribe("watchdog:heartbeat", () => {
    saveRuntimeState();
  });

  subscribe("watchdog:degraded", () => {
    saveRuntimeState();
    emit("runtime_state:saved", "runtime-state", { trigger: "watchdog_degraded" });
    addTimelineEvent({
      level: "warn",
      source: "runtime-state",
      message: "Runtime state persisted after watchdog degraded observation",
    });
  });

  emit("runtime_state:initialized", "runtime-state", { storageDir: STORAGE_DIR });
  logger.info({ storageDir: STORAGE_DIR }, "Runtime state persistence initialized");
}

export function getRuntimeStatePersistenceStatus(): RuntimeStatePersistenceStatus {
  return {
    operational: true,
    lastSavedAt,
    lastLoadedAt,
    saveCount,
    hasPersistedState,
    latestState,
    storageDir: STORAGE_DIR,
    timestamp: new Date().toISOString(),
  };
}

export function isRuntimeStateStale(): boolean {
  if (lastSavedAt === null) return true;
  return Date.now() - new Date(lastSavedAt).getTime() > STALE_THRESHOLD_MS;
}
