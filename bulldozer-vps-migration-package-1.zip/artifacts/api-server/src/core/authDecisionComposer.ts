// Auth Decision Composer — Phase 182
// Combines actor classification (authModel) with route classification (authRouteMap)
// into a single AuthCompositeDecision. Observe-only — never blocks any request.
// Pure module — no init, no subsystem registration, no health checks, no event emission.

import { evaluateAuthObserveOnly, type AuthActorType, type AccessTier } from "./authModel";
import { classifyAuthRoute, type RouteCategory, type RequiredTier } from "./authRouteMap";

export interface AuthCompositeDecision {
  allowed: boolean;
  actorType: AuthActorType;
  tier: AccessTier | null;
  routeCategory: RouteCategory;
  requiredTier: RequiredTier;
  reason: string;
  observeOnly: true;
  evaluatedAt: string;
}

export interface AuthComposerStatus {
  subsystemName: "auth_decision_composer";
  observeOnly: true;
  enforcing: false;
  authEnabled: false;
  implementationPhase: "skeleton";
  note: string;
}

// Mother Core surfaces that require operator-grade access
const MOTHER_CORE_CATEGORIES: readonly RouteCategory[] = [
  "mother_core_ui",
  "mother_core_api",
];

// Actor types that are prohibited from accessing Mother Core in future enforcement
const PROHIBITED_ON_MOTHER_CORE: readonly AuthActorType[] = [
  "employee",
  "customer",
  "anonymous",
];

// Compose a full auth decision by combining actor and route classification.
// Always returns allowed=true in observe mode.
// reason field records what enforcement would decide once auth is implemented.
export function composeAuthDecision(
  rawActorType: string | undefined,
  requestPath: string,
  requestMethod: string = "GET",
): AuthCompositeDecision {
  const actorDecision = evaluateAuthObserveOnly({
    method: requestMethod,
    path: requestPath,
    actorType: rawActorType,
  });

  const routeClassification = classifyAuthRoute(requestPath);

  const { actorType, tier } = actorDecision;
  const { category: routeCategory, requiredTier } = routeClassification;

  const isMotherCoreSurface = (MOTHER_CORE_CATEGORIES as readonly string[]).includes(routeCategory);
  const isProhibitedActor = (PROHIBITED_ON_MOTHER_CORE as readonly string[]).includes(actorType);

  let reason: string;

  if (isMotherCoreSurface && isProhibitedActor) {
    // These actors would be denied once auth is enforced
    if (actorType === "anonymous") {
      reason = `observe-warn: anonymous actor on ${routeCategory} (${requestPath}) — would be denied after auth implementation; no credentials presented`;
    } else if (actorType === "customer") {
      reason = `observe-warn: customer actor on ${routeCategory} (${requestPath}) — no Mother Core access permitted; customer boundary violation`;
    } else if (actorType === "employee") {
      reason = `observe-warn: employee actor on ${routeCategory} (${requestPath}) — prohibited; employee workspace routes only`;
    } else {
      reason = `observe-warn: actor (${actorType}) on ${routeCategory} (${requestPath}) — would be denied`;
    }
  } else if (isMotherCoreSurface && !isProhibitedActor) {
    // Operators and service tokens on Mother Core — would be evaluated against route policy
    if (actorType === "root_operator") {
      reason = `observe: root_operator (tier-1) on ${routeCategory} (${requestPath}) — full access; would be allowed`;
    } else if (actorType === "internal_operator") {
      reason = `observe: internal_operator (tier-2) on ${routeCategory} (${requestPath}) — would be evaluated against capability grant`;
    } else if (actorType === "service_token") {
      reason = `observe: service_token on ${routeCategory} (${requestPath}) — would be evaluated against token scope`;
    } else {
      reason = `observe: actor (${actorType}, tier-${tier ?? "none"}) on ${routeCategory} (${requestPath}) — would be evaluated against route policy`;
    }
  } else {
    // Non-Mother-Core surfaces (employee_workspace, generated_product, public — future)
    reason = `observe: actor (${actorType}) on ${routeCategory} (${requestPath}) — future surface, no enforcement model yet`;
  }

  return {
    allowed: true, // observe mode: never block
    actorType,
    tier,
    routeCategory,
    requiredTier,
    reason,
    observeOnly: true,
    evaluatedAt: new Date().toISOString(),
  };
}

export function getAuthComposerStatus(): AuthComposerStatus {
  return {
    subsystemName: "auth_decision_composer",
    observeOnly: true,
    enforcing: false,
    authEnabled: false,
    implementationPhase: "skeleton",
    note: "Phase 182 skeleton — observe-only composition of authModel + authRouteMap, no credentials, no sessions, no blocking",
  };
}
