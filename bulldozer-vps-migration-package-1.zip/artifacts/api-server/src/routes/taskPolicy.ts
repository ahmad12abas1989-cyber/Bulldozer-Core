import type { IncomingMessage, ServerResponse } from "node:http";
import { getTaskPolicyStatus, listTaskPolicies } from "../core/taskPolicy";
import { sendJson } from "../lib/response";

export function handleTaskPolicy(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, {
    ...getTaskPolicyStatus(),
    policies: listTaskPolicies(),
  });
}
