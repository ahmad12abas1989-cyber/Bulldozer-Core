// Plugin Core — Phase 204
// In-memory, metadata-only plugin registry.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no execution, no shell commands,
// no filesystem access, no network access, no vault access,
// not wired to any request flow.
// All plugins default to status="registered_metadata".

import { randomBytes } from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type PluginType =
  | "generator"
  | "validator"
  | "exporter"
  | "test-runner"
  | "integration";

export type PluginLifecycleStatus =
  | "registered_metadata"
  | "review"
  | "sandbox_test"
  | "operator_approval"
  | "enable"
  | "monitor"
  | "disabled"
  | "revoked";

export type PluginPermissionScope =
  | "read_project"
  | "read_vault_named"
  | "write_artifact"
  | "network_declared"
  | "sandbox_only";

export interface PluginMetadataRecord {
  readonly pluginId:               string;
  readonly name:                   string;
  readonly pluginType:             PluginType;
  readonly requestedByActorType:   string;
  readonly requestedByActorId:     string;
  readonly permissionScopes:       readonly PluginPermissionScope[];
  readonly status:                 PluginLifecycleStatus;
  readonly registeredAt:           string;
}

// Accepted input — structurally excludes: code, command, script, path,
// network flag (inline), secretValue, and any vault value.
export interface RegisterPluginInput {
  readonly name:                 string;
  readonly pluginType:           PluginType;
  readonly requestedByActorType: string;
  readonly requestedByActorId:   string;
  readonly permissionScopes:     readonly PluginPermissionScope[];
}

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

export interface PluginSummary {
  readonly totalPlugins:          number;
  readonly byType:                Partial<Record<PluginType, number>>;
  readonly byStatus:              Partial<Record<PluginLifecycleStatus, number>>;
  readonly pendingReviewCount:    number;
  readonly executionEnabled:      false;
  readonly persistenceEnabled:    false;
  readonly implementationPhase:   "skeleton";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const pluginStore = new Map<string, PluginMetadataRecord>();

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

export function registerPluginMetadata(input: RegisterPluginInput): { ok: true; record: PluginMetadataRecord } {
  const pluginId     = randomBytes(16).toString("hex");
  const registeredAt = new Date().toISOString();

  const record: PluginMetadataRecord = {
    pluginId,
    name:                  input.name,
    pluginType:            input.pluginType,
    requestedByActorType:  input.requestedByActorType,
    requestedByActorId:    input.requestedByActorId,
    permissionScopes:      input.permissionScopes,
    status:                "registered_metadata",
    registeredAt,
  };

  pluginStore.set(pluginId, record);
  return { ok: true, record };
}

export function listPluginMetadata(): PluginMetadataRecord[] {
  return Array.from(pluginStore.values()).sort(
    (a, b) => b.registeredAt.localeCompare(a.registeredAt),
  );
}

export function getPluginSummary(): PluginSummary {
  const records     = listPluginMetadata();
  const byType:     Partial<Record<PluginType, number>>            = {};
  const byStatus:   Partial<Record<PluginLifecycleStatus, number>> = {};

  for (const r of records) {
    byType[r.pluginType]   = (byType[r.pluginType]   ?? 0) + 1;
    byStatus[r.status]     = (byStatus[r.status]     ?? 0) + 1;
  }

  return {
    totalPlugins:        records.length,
    byType,
    byStatus,
    pendingReviewCount:  byStatus["registered_metadata"] ?? 0,
    executionEnabled:    false,
    persistenceEnabled:  false,
    implementationPhase: "skeleton",
  };
}
