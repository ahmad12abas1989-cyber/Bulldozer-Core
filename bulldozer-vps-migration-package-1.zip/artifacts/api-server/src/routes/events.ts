import type { IncomingMessage, ServerResponse } from "node:http";
import { getEventStats } from "../core/eventBus";
import { sendJson } from "../lib/response";

export function handleEvents(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getEventStats());
}
