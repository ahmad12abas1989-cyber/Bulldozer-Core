import type { IncomingMessage, ServerResponse } from "node:http";
import { getHardeningStatus } from "../core/hardening";
import { sendJson } from "../lib/response";

export function handleHardening(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getHardeningStatus());
}
