// Validation Probe Snapshot Capture — Phase 104
// Persistent ring buffer for Widget Contract Validation Probe results.
// Max 10 entries, atomic write semantics, load-on-boot, bounded pruning.
// No rendering, no autonomous execution, no mutation outside the ring.

import { readStore, writeStore } from "./persistentStore";
import { logger } from "../lib/logger";
import {
  runWidgetValidationProbe,
  type WidgetValidationProbeResult,
} from "./workspaceWidgetValidationProbe";

const EXECUTION_BLOCKED: true = true;
const MAX_ENTRIES = 10;
const STORE_KEY = "workspace-widget-validation-history";

// --- Types ---

export interface ValidationHistoryEntry {
  captureSeq: number;
  createdAt: string;
  probeId: string;
  snapshot: WidgetValidationProbeResult;
  executionBlocked: true;
}

export interface ValidationHistoryCaptureResult {
  captureSeq: number;
  createdAt: string;
  probeId: string;
  allWidgetsValid: boolean;
  passedWidgets: number;
  failedWidgets: number;
  fieldCoveragePercent: number;
  failedFieldCount: number;
  widgetCoveragePercent: number;
  ringSize: number;
  executionBlocked: true;
}

export interface ValidationHistoryListItem {
  captureSeq: number;
  createdAt: string;
  probeId: string;
  allWidgetsValid: boolean;
  passedWidgets: number;
  failedWidgets: number;
  fieldCoveragePercent: number;
  failedFieldCount: number;
  widgetCoveragePercent: number;
  executionBlocked: true;
}

export interface ValidationHistoryListResult {
  entries: ValidationHistoryListItem[];
  total: number;
  maxRetained: number;
  storeKey: string;
  executionBlocked: true;
}

export interface ValidationHistoryDetailResult {
  captureSeq: number;
  createdAt: string;
  probeId: string;
  probeSnapshot: WidgetValidationProbeResult;
  executionBlocked: true;
}

// --- Module state ---

let historyRing: ValidationHistoryEntry[] = [];
let nextCaptureSeq = 1;
let loadedOnBoot = 0;
let isInitialized = false;

// --- Persistence helpers ---

function flush(): void {
  try {
    writeStore<ValidationHistoryEntry[]>(STORE_KEY, historyRing);
  } catch (err) {
    logger.error(
      { err, storeKey: STORE_KEY },
      "Widget validation history: flush failed — ring preserved in memory",
    );
  }
}

function isValidEntry(obj: unknown): obj is ValidationHistoryEntry {
  if (obj === null || typeof obj !== "object") return false;
  const e = obj as Record<string, unknown>;
  return (
    typeof e["captureSeq"] === "number" &&
    typeof e["createdAt"] === "string" &&
    typeof e["probeId"] === "string" &&
    e["snapshot"] !== null &&
    typeof e["snapshot"] === "object" &&
    e["executionBlocked"] === true
  );
}

// --- Init ---

export function initWorkspaceWidgetValidationHistory(): void {
  if (isInitialized) return;

  const stored = readStore<unknown[]>(STORE_KEY);
  if (Array.isArray(stored)) {
    const valid = stored.filter(isValidEntry);
    historyRing = valid.slice(-MAX_ENTRIES);
    loadedOnBoot = historyRing.length;
    if (valid.length !== stored.length) {
      logger.warn(
        { total: stored.length, valid: valid.length, key: STORE_KEY },
        "Widget validation history load: skipped invalid entries on boot",
      );
    }
    // Resume captureSeq from the highest persisted seq
    if (historyRing.length > 0) {
      const maxSeq = Math.max(...historyRing.map((e) => e.captureSeq));
      nextCaptureSeq = maxSeq + 1;
    }
  }

  isInitialized = true;
  logger.info(
    {
      subsystem: "workspace_widget_validation_history",
      loadedOnBoot,
      maxRetained: MAX_ENTRIES,
      storeKey: STORE_KEY,
      nextCaptureSeq,
    },
    "Workspace widget validation history initialized",
  );
}

// --- Capture ---

export function captureWidgetValidationSnapshot(): ValidationHistoryCaptureResult {
  const probe = runWidgetValidationProbe();
  const captureSeq = nextCaptureSeq++;
  const createdAt = probe.generatedAt;
  const probeId = probe.probeId;

  const entry: ValidationHistoryEntry = {
    captureSeq,
    createdAt,
    probeId,
    snapshot: probe,
    executionBlocked: EXECUTION_BLOCKED,
  };

  historyRing.push(entry);

  // Prune to ring cap — oldest (lowest captureSeq) removed first
  while (historyRing.length > MAX_ENTRIES) {
    historyRing.shift();
  }

  flush();

  return {
    captureSeq,
    createdAt,
    probeId,
    allWidgetsValid: probe.summary.allWidgetsValid,
    passedWidgets: probe.summary.passedWidgets,
    failedWidgets: probe.summary.failedWidgets,
    fieldCoveragePercent: probe.fieldCoverage.coveragePercent,
    failedFieldCount: probe.summary.failedFieldCount,
    widgetCoveragePercent: probe.summary.widgetCoveragePercent,
    ringSize: historyRing.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- List ---

// --- Detail ---

export function getWidgetValidationHistoryDetail(captureSeq: number): ValidationHistoryDetailResult | null {
  const entry = historyRing.find((e) => e.captureSeq === captureSeq);
  if (entry === undefined) return null;
  return {
    captureSeq: entry.captureSeq,
    createdAt: entry.createdAt,
    probeId: entry.probeId,
    probeSnapshot: entry.snapshot,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- List ---

export function listWidgetValidationHistory(): ValidationHistoryListResult {
  // Newest-first (highest captureSeq first)
  const sorted = [...historyRing].sort((a, b) => b.captureSeq - a.captureSeq);

  const entries: ValidationHistoryListItem[] = sorted.map((e) => ({
    captureSeq: e.captureSeq,
    createdAt: e.createdAt,
    probeId: e.probeId,
    allWidgetsValid: e.snapshot.summary.allWidgetsValid,
    passedWidgets: e.snapshot.summary.passedWidgets,
    failedWidgets: e.snapshot.summary.failedWidgets,
    fieldCoveragePercent: e.snapshot.fieldCoverage.coveragePercent,
    failedFieldCount: e.snapshot.summary.failedFieldCount,
    widgetCoveragePercent: e.snapshot.summary.widgetCoveragePercent,
    executionBlocked: EXECUTION_BLOCKED,
  }));

  return {
    entries,
    total: entries.length,
    maxRetained: MAX_ENTRIES,
    storeKey: STORE_KEY,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
