import { logger } from "../lib/logger";
import { getRuntimeInfo } from "./runtime";
import { getWatchdogStatus } from "./watchdog";
import { getFreezeStatus } from "./freezeDetector";
import { getCrashStatus } from "./crashDetector";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";

export interface RestartRecommendation {
  restartRecommended: boolean;
  recommendationReason: string | null;
  blockedExecution: true;
}

export interface RestartSupervisorState {
  status: "operational";
  restartRecommended: boolean;
  recommendationReason: string | null;
  lastRecommendationAt: string | null;
  recommendationCount: number;
  blockedExecution: true;
  timestamp: string;
}

let restartRecommended = false;
let recommendationReason: string | null = null;
let lastRecommendationAt: string | null = null;
let recommendationCount = 0;
let previouslyRecommended = false;

export function evaluateRestartRecommendation(): RestartRecommendation {
  const runtimeInfo = getRuntimeInfo();
  const watchdogState = getWatchdogStatus();
  const freezeState = getFreezeStatus();
  const crashState = getCrashStatus();

  let recommended = false;
  let reason: string | null = null;

  if (runtimeInfo.state === "failed") {
    recommended = true;
    reason = "runtime_failed";
  } else if (crashState.status === "crashed") {
    recommended = true;
    reason = "crash_detected";
  } else if (watchdogState.missedHealthChecks > 3) {
    recommended = true;
    reason = "repeated_health_misses";
  } else if (freezeState.freezeCount > 2) {
    recommended = true;
    reason = "repeated_freezes";
  } else if (watchdogState.degradedCount > 5) {
    recommended = true;
    reason = "sustained_degradation";
  }

  restartRecommended = recommended;
  recommendationReason = reason;

  if (recommended) {
    const now = new Date().toISOString();

    if (!previouslyRecommended) {
      recommendationCount++;
      lastRecommendationAt = now;
      emit("restart_supervisor:recommended", "restart-supervisor", {
        reason,
        recommendationCount,
        blockedExecution: true,
      });
      addTimelineEvent({
        level: "warn",
        source: "restart-supervisor",
        message: `Restart recommended: ${reason}`,
        metadata: { reason, recommendationCount, blockedExecution: true },
      });
      logger.warn({ reason, recommendationCount }, "Restart supervisor: restart recommended (blocked — observation only)");
    }
  } else {
    if (previouslyRecommended) {
      emit("restart_supervisor:cleared", "restart-supervisor", { blockedExecution: true });
      addTimelineEvent({
        level: "info",
        source: "restart-supervisor",
        message: "Restart recommendation cleared",
        metadata: { blockedExecution: true },
      });
    }
  }

  previouslyRecommended = recommended;

  return {
    restartRecommended: recommended,
    recommendationReason: reason,
    blockedExecution: true,
  };
}

export function getRestartSupervisorStatus(): RestartSupervisorState {
  return {
    status: "operational",
    restartRecommended,
    recommendationReason,
    lastRecommendationAt,
    recommendationCount,
    blockedExecution: true,
    timestamp: new Date().toISOString(),
  };
}
