// firstActualSandboxMutationCommitCore.ts
// Phase 331 — First Actual Sandbox Mutation Commit Descriptor Core Skeleton
// In-memory first actual sandbox mutation commit descriptor engine.
// Layer 30 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor stack.
// Prepares the first actual sandbox mutation commit descriptor.
// Preserves sandbox-approved-only target scope from layers 24–29 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. mutationCommitEnabled=false — commit has not been enabled.
// mutationCommitPrepared=true — descriptor-readiness established for a future first actual sandbox write mutation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstActualSandboxMutationExecutorRecord }      from "./firstActualSandboxMutationExecutorCore.js";
import type { ActualSandboxWriteCommitExecutionGateRecord }   from "./actualSandboxWriteCommitExecutionGateCore.js";
import type { SandboxWriteCommitEnableRecord }                from "./sandboxWriteCommitEnableCore.js";
import type { FirstSandboxWriteCommitRecord }                 from "./firstSandboxWriteCommitCore.js";
import type { RuntimeWriteExecutorRecord }                    from "./runtimeWriteExecutorCore.js";
import type { ControlledExecutionRecord }                     from "./controlledExecutionCore.js";
import { randomUUID }                                         from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type MutationCommitState = "descriptor_mutation_commit_pending";

export type MutationCommitCheckRule =
  | "mutation_executor_exists"
  | "commit_execution_gate_exists"
  | "commit_enable_record_exists"
  | "sandbox_write_commit_exists"
  | "runtime_write_executor_exists"
  | "execution_record_exists"
  | "mutation_executor_bound_to_commit_execution_gate"
  | "commit_execution_gate_bound_to_commit_enable"
  | "commit_enable_bound_to_commit"
  | "commit_bound_to_executor"
  | "mutation_commit_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface MutationCommitCheck {
  readonly rule: MutationCommitCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface MutationCommitBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface MutationCommitPlanEntry {
  readonly entryId:               string;
  readonly operationType:         "descriptor_mutation_commit_planned";
  readonly targetScope:           "sandbox_approved_only";
  readonly mutationCommitEnabled: false;
  readonly mutationBlocked:       true;
  readonly note:                  string;
}

export interface LinkedMutationCommitReference {
  readonly mutationExecutorId:          string;
  readonly commitExecutionGateId:       string;
  readonly sandboxWriteCommitEnableId:  string;
  readonly sandboxWriteCommitId:        string;
  readonly rollbackSnapshotId:          string;
  readonly mutationCommitPrepared:      true;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly commitExecutionGateEnabled:  false;
  readonly actualWritesEnabled:         false;
  readonly rollbackChainValid:          boolean;
  readonly referenceNote:               string;
}

export interface MutationCommitReadinessReport {
  readonly mutationCommitPrepared:      true;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly commitExecutionGateEnabled:  false;
  readonly sandboxWriteCommitEnabled:   false;
  readonly runtimeWriteExecutorEnabled: false;
  readonly writeExecutionGateEnabled:   false;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly targetScope:                 "sandbox_approved_only";
  readonly summary:                     string;
}

export interface FirstActualSandboxMutationCommitRecord {
  readonly mutationCommitId:            string;
  readonly mutationCommitState:         MutationCommitState;
  readonly approvalRequired:            true;
  readonly mutationCommitPrepared:      true;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly commitExecutionGateEnabled:  false;
  readonly sandboxWriteCommitEnabled:   false;
  readonly runtimeWriteExecutorEnabled: false;
  readonly actualWritesEnabled:         false;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly vaultMutationBlocked:        true;
  readonly shellBlocked:                true;
  readonly networkBlocked:              true;
  readonly targetScope:                 "sandbox_approved_only";
  readonly implementationPhase:         "descriptor_only";
  readonly mutationExecutorId:          string;
  readonly commitExecutionGateId:       string;
  readonly sandboxWriteCommitEnableId:  string;
  readonly sandboxWriteCommitId:        string;
  readonly runtimeWriteExecutorId:      string;
  readonly controlledExecutionId:       string;
  readonly mutationCommitPlan:          readonly MutationCommitPlanEntry[];
  readonly mutationCommitChecks:        readonly MutationCommitCheck[];
  readonly mutationCommitBlockedReasons: readonly MutationCommitBlockedReason[];
  readonly mutationCommitReadinessReport: MutationCommitReadinessReport;
  readonly linkedMutationCommitReference: LinkedMutationCommitReference;
  readonly createdAt:                   string;
}

export interface CreateFirstActualSandboxMutationCommitInput {
  readonly mutationExecutorRecord:      FirstActualSandboxMutationExecutorRecord;
  readonly commitExecutionGateRecord:   ActualSandboxWriteCommitExecutionGateRecord;
  readonly commitEnableRecord:          SandboxWriteCommitEnableRecord;
  readonly commitRecord:                FirstSandboxWriteCommitRecord;
  readonly executorRecord:              RuntimeWriteExecutorRecord;
  readonly executionRecord:             ControlledExecutionRecord;
}

export interface FirstActualSandboxMutationCommitSummary {
  readonly total:                       number;
  readonly byState:                     Record<MutationCommitState, number>;
  readonly mutationCommitPrepared:      true;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly commitExecutionGateEnabled:  false;
  readonly sandboxWriteCommitEnabled:   false;
  readonly runtimeWriteExecutorEnabled: false;
  readonly actualWritesEnabled:         false;
  readonly approvalRequired:            true;
  readonly filesystemMutationBlocked:   true;
  readonly motherCoreMutationBlocked:   true;
  readonly targetScope:                 "sandbox_approved_only";
  readonly mutationCommitState:         MutationCommitState;
  readonly implementationPhase:         "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstActualSandboxMutationCommitRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstActualSandboxMutationCommitInput,
): readonly MutationCommitCheck[] {
  const { mutationExecutorRecord, commitExecutionGateRecord, commitEnableRecord, commitRecord, executorRecord, executionRecord } = input;

  const execExists    = mutationExecutorRecord.mutationExecutorId.length > 0;
  const gateExists    = commitExecutionGateRecord.commitExecutionGateId.length > 0;
  const enableExists  = commitEnableRecord.sandboxWriteCommitEnableId.length > 0;
  const commitExists  = commitRecord.sandboxWriteCommitId.length > 0;
  const rtExecExists  = executorRecord.runtimeWriteExecutorId.length > 0;
  const ctrlExists    = executionRecord.controlledExecutionId.length > 0;

  const execBound     = mutationExecutorRecord.commitExecutionGateId === commitExecutionGateRecord.commitExecutionGateId;
  const gateBound     = commitExecutionGateRecord.sandboxWriteCommitEnableId === commitEnableRecord.sandboxWriteCommitEnableId;
  const enableBound   = commitEnableRecord.sandboxWriteCommitId === commitRecord.sandboxWriteCommitId;
  const commitBound   = commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId;

  return [
    {
      rule: "mutation_executor_exists",
      pass: execExists,
      note: execExists
        ? `mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`
        : "mutationExecutorRecord.mutationExecutorId is empty",
    },
    {
      rule: "commit_execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`
        : "commitExecutionGateRecord.commitExecutionGateId is empty",
    },
    {
      rule: "commit_enable_record_exists",
      pass: enableExists,
      note: enableExists
        ? `sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`
        : "commitEnableRecord.sandboxWriteCommitEnableId is empty",
    },
    {
      rule: "sandbox_write_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`
        : "commitRecord.sandboxWriteCommitId is empty",
    },
    {
      rule: "runtime_write_executor_exists",
      pass: rtExecExists,
      note: rtExecExists
        ? `runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`
        : "executorRecord.runtimeWriteExecutorId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "mutation_executor_bound_to_commit_execution_gate",
      pass: execBound,
      note: execBound
        ? `mutationExecutorRecord.commitExecutionGateId === commitExecutionGateRecord.commitExecutionGateId (${commitExecutionGateRecord.commitExecutionGateId})`
        : `executor/gate mismatch: executor.commitExecutionGateId=${mutationExecutorRecord.commitExecutionGateId} vs gate.commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`,
    },
    {
      rule: "commit_execution_gate_bound_to_commit_enable",
      pass: gateBound,
      note: gateBound
        ? `commitExecutionGateRecord.sandboxWriteCommitEnableId === commitEnableRecord.sandboxWriteCommitEnableId (${commitEnableRecord.sandboxWriteCommitEnableId})`
        : `gate/commit-enable mismatch: gate.sandboxWriteCommitEnableId=${commitExecutionGateRecord.sandboxWriteCommitEnableId} vs enable.sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`,
    },
    {
      rule: "commit_enable_bound_to_commit",
      pass: enableBound,
      note: enableBound
        ? `commitEnableRecord.sandboxWriteCommitId === commitRecord.sandboxWriteCommitId (${commitRecord.sandboxWriteCommitId})`
        : `commit-enable/commit mismatch: enable.sandboxWriteCommitId=${commitEnableRecord.sandboxWriteCommitId} vs commit.sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`,
    },
    {
      rule: "commit_bound_to_executor",
      pass: commitBound,
      note: commitBound
        ? `commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId (${executorRecord.runtimeWriteExecutorId})`
        : `commit/executor mismatch: commit.runtimeWriteExecutorId=${commitRecord.runtimeWriteExecutorId} vs executor.runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`,
    },
    {
      rule: "mutation_commit_still_disabled",
      pass: true,
      note: "mutationCommitEnabled=false — compile-time literal; no mutation commit activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "mutationCommitState=descriptor_mutation_commit_pending — output is a descriptor only; mutation commit is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly MutationCommitCheck[],
): readonly MutationCommitBlockedReason[] {
  const staticReasons: MutationCommitBlockedReason[] = [
    { code: "mutation_commit_disabled", reason: "mutationCommitEnabled=false — compile-time literal; an explicit first actual sandbox write mutation phase must activate the commit before any sandbox target can be mutated",                                                                                                                                                                                                                                                                static: true },
    { code: "approval_required",        reason: "approvalRequired=true — explicit operator approval is required before the mutation commit can be activated",                                                                                                                                                                                                                                                                                                                             static: true },
    { code: "actual_writes_disabled",   reason: "actualWritesEnabled=false — compile-time literal across all 30 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, and mutation-executor layers", static: true },
  ];
  const dynamicReasons: MutationCommitBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedMutationCommitReference(
  input: CreateFirstActualSandboxMutationCommitInput,
  rollbackChainValid: boolean,
): LinkedMutationCommitReference {
  const { mutationExecutorRecord, commitExecutionGateRecord, commitEnableRecord, commitRecord } = input;
  return {
    mutationExecutorId:         mutationExecutorRecord.mutationExecutorId,
    commitExecutionGateId:      commitExecutionGateRecord.commitExecutionGateId,
    sandboxWriteCommitEnableId: commitEnableRecord.sandboxWriteCommitEnableId,
    sandboxWriteCommitId:       commitRecord.sandboxWriteCommitId,
    rollbackSnapshotId:         mutationExecutorRecord.linkedMutationExecutorReference.rollbackSnapshotId,
    mutationCommitPrepared:     true,
    mutationCommitEnabled:      false,
    mutationExecutorEnabled:    false,
    commitExecutionGateEnabled: false,
    actualWritesEnabled:        false,
    rollbackChainValid,
    referenceNote: "linked mutation commit reference sources rollbackSnapshotId from mutationExecutorRecord.linkedMutationExecutorReference; mutation commit disabled; mutation executor disabled; commit execution gate disabled; sandbox write commit enable disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstActualSandboxMutationCommitRecord(
  input: CreateFirstActualSandboxMutationCommitInput,
): FirstActualSandboxMutationCommitRecord {
  const { mutationExecutorRecord, commitExecutionGateRecord, commitEnableRecord, commitRecord, executorRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = mutationExecutorRecord.mutationExecutorReadinessReport.rollbackChainValid;

  const allChecksPass   = checks.every((c) => c.pass);
  const blockedReasons  = buildBlockedReasons(checks);
  const linkedRef       = buildLinkedMutationCommitReference(input, rollbackChainValid);

  const mutationCommitPlan: MutationCommitPlanEntry[] = [
    {
      entryId:              randomUUID(),
      operationType:        "descriptor_mutation_commit_planned",
      targetScope:          "sandbox_approved_only",
      mutationCommitEnabled: false,
      mutationBlocked:      true,
      note:                 "mutation commit planned in descriptor-only mode; targetScope=sandbox_approved_only; mutationCommitEnabled=false; filesystemMutationBlocked=true; first actual sandbox write mutation phase required to activate",
    },
  ];

  const mutationCommitReadinessReport: MutationCommitReadinessReport = {
    mutationCommitPrepared:       true,
    mutationCommitEnabled:        false,
    mutationExecutorEnabled:      false,
    commitExecutionGateEnabled:   false,
    sandboxWriteCommitEnabled:    false,
    runtimeWriteExecutorEnabled:  false,
    writeExecutionGateEnabled:    false,
    scopedActivationEnabled:      false,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    targetScope:                  "sandbox_approved_only",
    summary: `mutationCommitState=descriptor_mutation_commit_pending; mutationCommitEnabled=false; mutationExecutorEnabled=false; commitExecutionGateEnabled=false; sandboxWriteCommitEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstActualSandboxMutationCommitRecord = {
    mutationCommitId:               randomUUID(),
    mutationCommitState:            "descriptor_mutation_commit_pending",
    approvalRequired:               true,
    mutationCommitPrepared:         true,
    mutationCommitEnabled:          false,
    mutationExecutorEnabled:        false,
    commitExecutionGateEnabled:     false,
    sandboxWriteCommitEnabled:      false,
    runtimeWriteExecutorEnabled:    false,
    actualWritesEnabled:            false,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    vaultMutationBlocked:           true,
    shellBlocked:                   true,
    networkBlocked:                 true,
    targetScope:                    "sandbox_approved_only",
    implementationPhase:            "descriptor_only",
    mutationExecutorId:             mutationExecutorRecord.mutationExecutorId,
    commitExecutionGateId:          commitExecutionGateRecord.commitExecutionGateId,
    sandboxWriteCommitEnableId:     commitEnableRecord.sandboxWriteCommitEnableId,
    sandboxWriteCommitId:           commitRecord.sandboxWriteCommitId,
    runtimeWriteExecutorId:         executorRecord.runtimeWriteExecutorId,
    controlledExecutionId:          executionRecord.controlledExecutionId,
    mutationCommitPlan,
    mutationCommitChecks:           checks,
    mutationCommitBlockedReasons:   blockedReasons,
    mutationCommitReadinessReport,
    linkedMutationCommitReference:  linkedRef,
    createdAt:                      new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstActualSandboxMutationCommitRecords(): readonly FirstActualSandboxMutationCommitRecord[] {
  return _store.slice();
}

export function getFirstActualSandboxMutationCommitSummary(): FirstActualSandboxMutationCommitSummary {
  return {
    total:                          _store.length,
    byState:                        { descriptor_mutation_commit_pending: _store.length },
    mutationCommitPrepared:         true,
    mutationCommitEnabled:          false,
    mutationExecutorEnabled:        false,
    commitExecutionGateEnabled:     false,
    sandboxWriteCommitEnabled:      false,
    runtimeWriteExecutorEnabled:    false,
    actualWritesEnabled:            false,
    approvalRequired:               true,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    targetScope:                    "sandbox_approved_only",
    mutationCommitState:            "descriptor_mutation_commit_pending",
    implementationPhase:            "descriptor_only",
  };
}
