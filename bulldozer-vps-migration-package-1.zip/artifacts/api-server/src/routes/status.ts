import type { IncomingMessage, ServerResponse } from "node:http";
import { getRuntimeInfo } from "../core/runtime";
import { sendJson } from "../lib/response";

export function handleStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getRuntimeInfo());
}
