import type { IncomingMessage, ServerResponse } from "node:http";
import { createTask, getTaskQueueStatus, listTasks } from "../core/taskQueue";
import { readJsonBody } from "../lib/body";
import { sendJson, sendError } from "../lib/response";

export function handleTasksGet(_req: IncomingMessage, res: ServerResponse): void {
  const status = getTaskQueueStatus();
  sendJson(res, 200, {
    status,
    tasks: listTasks(),
    executionBlocked: true,
    timestamp: new Date().toISOString(),
  });
}

export function handleTasksPost(req: IncomingMessage, res: ServerResponse): void {
  readJsonBody(req)
    .then((body) => {
      if (!body || typeof body !== "object" || Array.isArray(body)) {
        sendError(res, 400, "Request body must be a JSON object");
        return;
      }

      const { type, payload, metadata } = body as Record<string, unknown>;

      if (!type || typeof type !== "string" || !type.trim()) {
        sendError(res, 400, "Field \"type\" is required and must be a non-empty string");
        return;
      }

      if (metadata !== undefined && (typeof metadata !== "object" || Array.isArray(metadata) || metadata === null)) {
        sendError(res, 400, "Field \"metadata\" must be a plain object if provided");
        return;
      }

      const task = createTask(
        type.trim(),
        payload ?? {},
        (metadata as Record<string, unknown>) ?? {},
      );

      sendJson(res, 201, {
        task,
        executionBlocked: true,
        note: "Task recorded. Execution is blocked — no workers exist.",
      });
    })
    .catch((err: Error) => {
      sendError(res, 400, err.message ?? "Bad Request");
    });
}
