// Governance Scorecard History Analytics — Phase 115 / Phase 116
// Pure read-only derivation from the in-memory scorecard history ring.
// No new persistence, no live recomputation, no mutation paths.
// No rendering, no autonomous execution, no AI orchestration.

import { createHash } from "node:crypto";
import { getRawScorecardHistoryEntries } from "./workspaceGovernanceScorecardHistory";
import type { GovernanceGrade } from "./workspaceGovernanceScorecard";

const EXECUTION_BLOCKED: true = true;

// --- Grade ordering (lower index = better) ---
const GRADE_ORDER: GovernanceGrade[] = ["A", "B", "C", "D", "F"];

// Phase 116 — canonical 6 dimension keys, alphabetically sorted for deterministic output
const DIMENSION_KEYS = [
  "audit_report_coverage",
  "capacity_utilization",
  "member_project_ratio",
  "quota_adoption",
  "snapshot_availability",
  "validation_integrity",
] as const;

type DimensionKey = (typeof DIMENSION_KEYS)[number];

// --- Types ---

export type ScorecardTrendDirection = "improving" | "stable" | "degrading" | null;

export interface ScorecardAnalyticsSummary {
  totalSnapshotsAnalyzed: number;
  averageGovernanceScore: number;
  highestGovernanceScore: number | null;
  lowestGovernanceScore: number | null;
  currentGovernanceGrade: GovernanceGrade | null;
  bestValidationIntegrityScore: number | null;
  worstValidationIntegrityScore: number | null;
  governanceTrendDirection: ScorecardTrendDirection;
  validationTrendDirection: ScorecardTrendDirection;
  latestCaptureSeq: number | null;
  executionBlocked: true;
}

export interface ScorecardAnalyticsTransitions {
  governanceGradeChanges: number;
  validationIntegrityChanges: number;
  improvementCount: number;
  degradationCount: number;
  executionBlocked: true;
}

export interface ScorecardAnalyticsHistoryPoint {
  captureSeq: number;
  createdAt: string;
  governanceScore: number;
  governanceGrade: GovernanceGrade;
  validationIntegrityScore: number;
  widgetRegistryHealthy: boolean;
  executionBlocked: true;
}

// Phase 116 — per-dimension historical analytics entry
export interface DimensionBreakdownEntry {
  dimensionKey: DimensionKey;
  averageWeightedScore: number;
  minimumWeightedScore: number | null;
  maximumWeightedScore: number | null;
  currentWeightedScore: number | null;
  trendDirection: ScorecardTrendDirection;
  snapshotsAnalyzed: number;
  executionBlocked: true;
}

export interface WorkspaceGovernanceScorecardAnalytics {
  analyticsId: string;
  generatedAt: string;
  summary: ScorecardAnalyticsSummary;
  transitions: ScorecardAnalyticsTransitions;
  series: ScorecardAnalyticsHistoryPoint[];
  dimensionBreakdown: DimensionBreakdownEntry[];
  snapshotsInRing: number;
  executionBlocked: true;
}

// --- Derivation helpers ---

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function deriveTrend(oldest: number, newest: number): Exclude<ScorecardTrendDirection, null> {
  if (newest > oldest) return "improving";
  if (newest < oldest) return "degrading";
  return "stable";
}

function bestGrade(grades: GovernanceGrade[]): GovernanceGrade | null {
  if (grades.length === 0) return null;
  return grades.reduce((best, g) =>
    GRADE_ORDER.indexOf(g) < GRADE_ORDER.indexOf(best) ? g : best,
  );
}

// --- Public API ---

export function getWorkspaceGovernanceScorecardAnalytics(): WorkspaceGovernanceScorecardAnalytics {
  const generatedAt = new Date().toISOString();
  const analyticsId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  // Read from in-memory ring — no I/O, no mutation
  const entries = getRawScorecardHistoryEntries();

  // Sort oldest-first for transition analysis
  const oldestFirst = [...entries].sort((a, b) => a.captureSeq - b.captureSeq);

  const snapshotsInRing = oldestFirst.length;

  // --- Extract per-entry signals ---

  const scores = oldestFirst.map((e) => e.snapshot.governanceScore);
  const grades = oldestFirst.map((e) => e.snapshot.governanceGrade);
  const viScores = oldestFirst.map((e) => e.snapshot.signals.validationIntegrityScore);
  const registryHealthy = oldestFirst.map((e) => e.snapshot.signals.widgetRegistryHealthy);
  const seqs = oldestFirst.map((e) => e.captureSeq);

  // --- Summary derivations ---

  const averageGovernanceScore =
    scores.length > 0 ? round1(scores.reduce((s, v) => s + v, 0) / scores.length) : 0;

  const highestGovernanceScore = scores.length > 0 ? Math.max(...scores) : null;
  const lowestGovernanceScore = scores.length > 0 ? Math.min(...scores) : null;

  // currentGovernanceGrade = newest entry (highest captureSeq)
  const newestEntry = oldestFirst.length > 0 ? oldestFirst[oldestFirst.length - 1] : null;
  const currentGovernanceGrade: GovernanceGrade | null = newestEntry
    ? newestEntry.snapshot.governanceGrade
    : null;

  const bestValidationIntegrityScore = viScores.length > 0 ? Math.max(...viScores) : null;
  const worstValidationIntegrityScore = viScores.length > 0 ? Math.min(...viScores) : null;

  const latestCaptureSeq = seqs.length > 0 ? Math.max(...seqs) : null;

  const governanceTrendDirection: ScorecardTrendDirection =
    oldestFirst.length >= 2 ? deriveTrend(scores[0], scores[scores.length - 1]) : null;

  const validationTrendDirection: ScorecardTrendDirection =
    oldestFirst.length >= 2 ? deriveTrend(viScores[0], viScores[viScores.length - 1]) : null;

  // bestGrade is used only in helpers; suppress unused-variable.
  void bestGrade;

  const summary: ScorecardAnalyticsSummary = {
    totalSnapshotsAnalyzed: snapshotsInRing,
    averageGovernanceScore,
    highestGovernanceScore,
    lowestGovernanceScore,
    currentGovernanceGrade,
    bestValidationIntegrityScore,
    worstValidationIntegrityScore,
    governanceTrendDirection,
    validationTrendDirection,
    latestCaptureSeq,
    executionBlocked: EXECUTION_BLOCKED,
  };

  // --- Transition metrics (consecutive oldest-first pairs) ---

  let governanceGradeChanges = 0;
  let validationIntegrityChanges = 0;
  let improvementCount = 0;
  let degradationCount = 0;

  for (let i = 1; i < oldestFirst.length; i++) {
    if (grades[i] !== grades[i - 1]) governanceGradeChanges++;
    if (viScores[i] !== viScores[i - 1]) validationIntegrityChanges++;
    if (scores[i] > scores[i - 1]) improvementCount++;
    if (scores[i] < scores[i - 1]) degradationCount++;
  }

  const transitions: ScorecardAnalyticsTransitions = {
    governanceGradeChanges,
    validationIntegrityChanges,
    improvementCount,
    degradationCount,
    executionBlocked: EXECUTION_BLOCKED,
  };

  // --- Series: newest-first ---

  const newestFirst = [...oldestFirst].reverse();

  const series: ScorecardAnalyticsHistoryPoint[] = newestFirst.map((e, i) => {
    // Reverse index maps back to oldestFirst index for pre-computed arrays
    const idx = oldestFirst.length - 1 - i;
    return {
      captureSeq: e.captureSeq,
      createdAt: e.createdAt,
      governanceScore: scores[idx],
      governanceGrade: grades[idx],
      validationIntegrityScore: viScores[idx],
      widgetRegistryHealthy: registryHealthy[idx],
      executionBlocked: EXECUTION_BLOCKED,
    };
  });

  // --- Phase 116: Dimension breakdown ---
  // For each canonical dimension key (alphabetical), collect weightedScore values
  // from snapshot.breakdown[] across all retained ring entries, oldest-first.

  const dimensionBreakdown: DimensionBreakdownEntry[] = DIMENSION_KEYS.map((key) => {
    // Collect the weightedScore for this dimension from each snapshot, oldest-first.
    // Defensive: if a snapshot's breakdown[] doesn't contain this key (e.g. pre-Phase-112
    // entries missing validation_integrity), skip that entry — do not default to 0.
    const dimWeightedScores: number[] = oldestFirst
      .map((e) => {
        const cat = e.snapshot.breakdown.find((c) => c.category === key);
        return cat !== undefined ? cat.weightedScore : null;
      })
      .filter((v): v is number => v !== null);

    const n = dimWeightedScores.length;
    const averageWeightedScore = n > 0 ? round1(dimWeightedScores.reduce((s, v) => s + v, 0) / n) : 0;
    const minimumWeightedScore = n > 0 ? round1(Math.min(...dimWeightedScores)) : null;
    const maximumWeightedScore = n > 0 ? round1(Math.max(...dimWeightedScores)) : null;

    // currentWeightedScore = value from the newest entry (highest captureSeq)
    const currentWeightedScore = (() => {
      if (newestEntry === null) return null;
      const cat = newestEntry.snapshot.breakdown.find((c) => c.category === key);
      return cat !== undefined ? cat.weightedScore : null;
    })();

    // trendDirection: compare oldest vs newest observed weighted score for this dimension
    const trendDirection: ScorecardTrendDirection =
      dimWeightedScores.length >= 2
        ? deriveTrend(dimWeightedScores[0], dimWeightedScores[dimWeightedScores.length - 1])
        : null;

    return {
      dimensionKey: key,
      averageWeightedScore,
      minimumWeightedScore,
      maximumWeightedScore,
      currentWeightedScore,
      trendDirection,
      snapshotsAnalyzed: n,
      executionBlocked: EXECUTION_BLOCKED,
    };
  });

  return {
    analyticsId,
    generatedAt,
    summary,
    transitions,
    series,
    dimensionBreakdown,
    snapshotsInRing,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
