# Bulldozer Mother Core — Architecture Reference

This file contains the full architecture history, principles, roadmaps, and design decisions for the Bulldozer Mother Core project.

For live operational reference (endpoints, run commands, file tree, gotchas), see `replit.md`.

---

## Project Identity

Bulldozer Mother Core is a cloud-first production nucleus. The Mother Core always remains the top-level controller and guardian of all systems that run on top of it.

### Current stage

Infrastructure expansion — foundation phase complete.

### Current restrictions

- No AI systems yet
- No autonomous systems yet
- No self-development yet
- No self-repair yet
- No app-generation systems yet
- No billing or treasury systems yet
- No wallet connections yet
- No rate limiting yet
- No secrets vault yet
- No auth layer yet

### Priority right now

Deepen infrastructure hardening and observability before adding any intelligence, financial, or execution layers.

### Future capabilities (only after nucleus completion)

All of the following are planned for future stages and must not be built until the nucleus is complete and stable:

- Application generation
- Production management
- Controlled self-development
- Controlled self-repair
- Supervised evolution
- Advanced runtime monitoring
- Recovery execution systems
- Cloud orchestration
- Treasury management
- Billing and subscription routing
- SaaS revenue infrastructure

All future self-development and self-repair must remain:

- Controlled
- Sandboxed
- Rollback-safe
- Command-driven
- User-supervised

---

## Completed Phase History

Every phase below was built, typechecked, tested against all live endpoints, and verified before the next phase began. No phase was skipped. No phase was started before the preceding one was stable.

### Phase 1 — Runtime Core

Entry point, HTTP server, request router, error boundary, JSON helpers, structured logger, request ID tracing, graceful shutdown. Runtime state machine: `starting → ready → stopping → stopped`. Config loaded once at startup — fails fast if PORT missing.

### Phase 2 — Metrics and Health Monitor

Runtime metrics (`process.memoryUsage`, `process.cpuUsage`, request/error counters). Health monitor: synchronous multi-check composite report. Introduced `healthy / degraded / unhealthy` status model.

### Phase 3 — Freeze and Crash Detection

Freeze detector: single `setInterval` with `.unref()` measuring event loop lag. Crash detector: `uncaughtException`, `unhandledRejection`, `warning` listeners. Detection and recording only — no recovery, no restart.

### Phase 4 — Snapshot Layer

In-memory snapshot ring buffer (max 10). Captures runtime state, metrics, health, freeze, and crash state on demand. No imports from `healthMonitor.ts` — reads raw sources directly.

### Phase 5 — Persistent Snapshot Storage

Atomic disk writes (`.tmp` → `rename`). Max 20 persisted files. Prune-on-write. Storage failure never propagates to in-memory flow. Zero imports beyond `node:fs`, `node:path`, and `logger`.

### Phase 6 — Runtime Timeline

Chronological event log, max 200 entries, ring buffer. Newest-first on read. Zero project imports — everything emits into it, it never imports back.

### Phase 7 — Runtime Event Bus

Internal pub/sub channel. Synchronous, in-memory. Handler errors are swallowed so the bus never throws. Zero project imports — same isolation rule as `timeline.ts`. Decouples producers from consumers across all core modules.

### Phase 8 — Watchdog Core

Passive observer on a 15-second `setInterval` with `.unref()`. Reads raw state from runtime, freeze detector, crash detector, restart supervisor, and metrics directly. Never calls `getFullHealth()` to avoid circular dependencies. Emits 8 typed events to the event bus. Detection and recording only.

### Phase 9 — Restart Supervisor

On-demand decision engine. Evaluates five threshold conditions. `blockedExecution: true` is a hardcoded constitutional constant — never a runtime flag, never toggled, never overridden. Recommendations are logged and timestamped. No execution path exists anywhere in the codebase.

### Phase 10 — Plugin Sandbox Isolation

Isolated registration context for plugins. Five permission types: `filesystem`, `network`, `processControl`, `shellExecution`, `externalApi`. All denied by default and by construction. No grant path exists. No dynamic imports, no shell execution, no plugin activation.

### Phase 11 — Persistent Runtime State

Single-file atomic persistence (`storage/runtime-state/runtime-state.json`). Five save triggers: startup, `snapshot:created` event, `watchdog:heartbeat`, `watchdog:degraded`, shutdown. `isRuntimeStateStale()` with 120-second threshold. Load-on-boot for observation only — no auto-repair from persisted state.

### Phase 12 — Recovery Tracking Layer

Passive observation of conditions that would require recovery. Subscribes to 10 event bus events from freeze detector, crash detector, watchdog, and restart supervisor. Edge-triggered: one observation record per condition key; repeated events increment `occurrenceCount`. Severity can only escalate. `clearRecoveryTrackingHistory()` archives active observations to history (max 50). No recovery execution, no rollback, no restart.

### Phase 13 — Production Hardening Foundation

Five block types: `method_not_allowed`, `malformed_url`, `url_too_long` (>512 chars), `path_traversal` (`../`, `..\\`, `%2e%2e`), `control_chars`. Two warning types: `double_slash`, `missing_host`. Security headers on every response: `X-Content-Type-Options`, `X-Frame-Options`, `X-XSS-Protection`, `Referrer-Policy`, `X-Permitted-Cross-Domain-Policies`. Path traversal checked against raw `req.url` before URL parser normalization. Violation tracking with blocked/warning counts, timestamps, and event bus emission.

### Phase 14 — Secure Config Management Foundation

Independent env var validation layer. Required key check (`PORT`), optional key check (`NODE_ENV`, `LOG_LEVEL`). `NODE_ENV` and `LOG_LEVEL` validated against known-good value sets. Sensitive key detection via `SENSITIVE_PATTERN` regex across all `process.env` keys — matches `SECRET`, `KEY`, `TOKEN`, `PASSWORD`, `PASSWD`, `PRIVATE`, `CREDENTIAL`, `AUTH`, `API_KEY`, `SIGNING`. All matched values replaced with `***MASKED***` in reports. Three-status model: `safe / degraded / unsafe`. No duplicates of `config.ts` — reads env independently, on demand.

### Phase 15 — Task Queue

In-memory task queue (`Map<string, Task>`). `createTask` / `getTask` / `listTasks` / `markTaskBlocked`. Emits `task_queue:task_created` to event bus. `executionBlocked: true` typed as literal `true`. `completedTasks` and `failedTasks` typed as literal `0`. POST body parsed via `lib/body.ts`. 18th health check (`task_queue`).

### Phase 16 — Controlled Task Evaluation Layer

Thin classification adapter. `evaluateTaskSafety(task)` delegates to `evaluateTaskPolicy()` from the policy engine and maps `PolicyDecision` → `EvaluationCategory`: `allow→safe`, `warn→warning`, `approval_required→warning`, `block→blocked`. `evaluateTask(task)` updates own counters, calls `markTaskBlocked` if blocked, emits typed events to bus. `initTaskEvaluation()` subscribes to `task_queue:task_created` — synchronous bus means evaluation completes before POST response returns. `executionStillBlocked: true` typed as literal `true`. 19th health check (`task_evaluation`): pass if operational, warn if warningTasks > 0, fail on internal error.

### Phase 17 — Task Policy Engine Foundation

Centralized policy engine — the single source of truth for all task safety decisions. Ten ordered policies evaluated in priority sequence; first match wins. Four `block` policies: invalid type format, shell/process tasks, filesystem mutation tasks, network execution tasks. One `block_invalid_payload` policy. One `warn` policy: oversized payload (>10 KB serialized). One `approval_required` policy: `deploy:` namespace. Two `warn` policies: `external|provision|cloud|orchestrate` namespaces, unknown namespaces. One `allow` policy: 16 approved safe namespaces. `evaluateTaskPolicy(task)` → `{ decision, policyId, reason }`. `getTaskPolicyStatus()` tracks `totalPolicyEvaluations`, `allowedCount`, `warningCount`, `blockedCount`, `approvalRequiredCount`. `listTaskPolicies()` returns the full ordered policy list. `executionBlocked: true` typed as literal `true`. 20th health check (`task_policy`): pass if operational, warn if blockedCount > 0 or approvalRequiredCount > 0, fail on internal error.

### Phase 84 — Workspace Navigation & Panel Composition Layer

Extends the Workspace UI Shell (Phase 83) into a structured navigational and panel-composition layer. Three new aggregation endpoints, five reusable panel models, a three-section navigation structure — all pure read-only, no new subsystem, no new health check, no persistence.

**Motivation:** Phase 83 established a flat workspace aggregate view (summary, project overview, health). Phase 84 organises that state into a coherent navigational hierarchy — sections with grouped panels — so the workspace API is consumable as a structured UI model without adding any execution risk.

**Architecture invariants:**
- All Phase 84 additions are appended to `core/workspaceShell.ts`. No other core module is modified. No new module is introduced. No import is added beyond those already present from Phase 83.
- `PANEL_REGISTRY` and `SECTION_DEFINITIONS` are module-level constants — computed once at module load, never mutated at runtime.
- `getPanel(panelId: string)` dispatches via a `switch` statement to five private builder functions. Unknown `panelId` returns `null`; the route handler maps `null` to HTTP 404 with the known panel IDs listed.
- `buildActivityPanel()` and `buildMembershipPanel()` iterate `listProjects()` (O(n), max 100 projects). All iteration is synchronous, in-memory, and bounded.
- `QUOTA_SYSTEM_DEFAULTS` is a module-level const in `workspaceShell.ts` (not imported from `projectRegistry`). This prevents any accidental tight coupling to projectRegistry internals — if defaults change there, this const must be updated explicitly (by design, not silently).

**New exports in `core/workspaceShell.ts`:**

| Export | Kind | Detail |
|---|---|---|
| `WorkspacePanelRef` | interface | `panelId`, `title`, `description`, `endpoint`, `permission`, `minimumRole`, `executionBlocked: true` |
| `WorkspaceSection` | interface | `sectionId`, `title`, `description`, `panelCount`, `panels: WorkspacePanelRef[]`, `executionBlocked: true` |
| `WorkspaceNavigationResult` | interface | `sections`, `totalSections`, `totalPanels`, `checkedAt`, `executionBlocked: true` |
| `WorkspacePanelMeta` | interface | `panelId`, `title`, `description`, `section`, `endpoint`, `permission`, `executionBlocked: true` |
| `WorkspacePanelListResult` | interface | `panels: WorkspacePanelMeta[]`, `count`, `checkedAt`, `executionBlocked: true` |
| `DiagnosticsPanel` | interface | `panelId: "diagnostics"`, `status`, `registryOperational`, `totalProjects/Members/Activity`, `customQuotaProjects`, `storeKeyCount`, `layer: "product"`, `executionBlocked: true` |
| `ProjectsPanel` | interface | `panelId: "projects"`, `total`, `byStatus`, `capacity`, `recentProjects[]` (last 5 newest-first), `executionBlocked: true` |
| `QuotasPanel` | interface | `panelId: "quotas"`, `totalProjects`, `projectsWithCustomQuotas`, `projectsUsingDefaults`, `systemDefaults`, `executionBlocked: true` |
| `ActivityPanel` | interface | `panelId: "activity"`, `totalRecords`, `loadedOnBoot`, `projectsWithActivity`, `totalProjects`, `executionBlocked: true` |
| `MembershipPanel` | interface | `panelId: "membership"`, `totalRecords`, `loadedOnBoot`, `projectsWithMembers`, `totalProjects`, `roleDistribution: Record<string,number>`, `executionBlocked: true` |
| `WorkspacePanelData` | type | Union of all five panel types |
| `KNOWN_PANEL_IDS` | const | `["diagnostics","projects","quotas","activity","membership"]` as `readonly` tuple |
| `KnownPanelId` | type | `"diagnostics" \| "projects" \| "quotas" \| "activity" \| "membership"` |
| `getWorkspaceNavigation()` | function | Returns `WorkspaceNavigationResult` — static structure built from `SECTION_DEFINITIONS` + `PANEL_REGISTRY` |
| `listWorkspacePanels()` | function | Returns `WorkspacePanelListResult` — shallow copy of `PANEL_REGISTRY` |
| `getPanel(panelId)` | function | Returns `WorkspacePanelData \| null` — dispatches to builder function or returns `null` for unknown IDs |

**Navigation structure — 3 sections:**

| Section | Title | Panels |
|---|---|---|
| `overview` | Overview | diagnostics, projects |
| `governance` | Governance & Quotas | quotas, membership |
| `audit` | Audit & Activity | activity |

**New endpoints:**

| Method | Route | Permission | Min Role | Description |
|---|---|---|---|---|
| GET | `/api/workspace/navigation` | read | viewer | Workspace nav structure: 3 sections, 5 panel refs with endpoints and permission metadata |
| GET | `/api/workspace/panels` | read | viewer | Panel metadata list: all 5 available panels — id, title, description, section, endpoint, permission |
| GET | `/api/workspace/panels/:panelId` | read | viewer | Panel data: aggregated read-only data for diagnostics/projects/quotas/activity/membership; unknown panelId → 404 |

**Per-panel computation summary:**

| Panel | Key Sources | Computation |
|---|---|---|
| `diagnostics` | `getProductLayerHealth()` | O(1) |
| `projects` | `listProjects()`, `getProjectRegistryStatus()` | O(n) filter + O(5) slice for recentProjects |
| `quotas` | `getProductLayerHealth()` | O(1) + const defaults |
| `activity` | `getActivityStats()`, `listProjects()`, `getProjectActivity()` | O(n) project iteration; `.total` read only |
| `membership` | `getMemberStats()`, `listProjects()`, `listProjectMembers()` | O(n × m) for role distribution; n ≤ 100, m ≤ 50 |

**Count changes:** Endpoints 73→76 · Policies 73→76 · Health checks 37 (unchanged) · Subsystems 27 (unchanged) · Graph nodes 27 (unchanged) · `accessEnforcement.ts` description updated to "76-route policy map"

---

### Phase 85 — Workspace Snapshot & Export Layer

**Motivation:** The workspace shell (Phases 83–84) established real-time aggregation views. Phase 85 adds point-in-time immutable snapshots — a governed record of full workspace state at any moment, suitable for audit trails, baseline comparison, and change detection over time.

**Design decisions:**
- New module `core/workspaceSnapshots.ts` — atomic persistence via `writeStore`/`readStore` (key `workspace-snapshots`), bounded ring buffer (max 20), load-on-boot, prune-on-create.
- No new subsystem, no new health check — the snapshot store is a data layer that sits above the existing persistent store subsystem.
- `initWorkspaceSnapshots()` called from `runtime.ts` after `initProjectQuotas()`, before `initRuntimeDependencyGraph()`.
- Snapshot schema: `snapshotId` (16-char hex), `schemaVersion "1"`, `createdAt`, `summary`, `navigation`, all 5 `panels`, `diagnosticsExcerpt`, `executionBlocked: true`.
- `POST /api/workspace/snapshots/create` requires `minimumRole: operator`; both GET endpoints are `minimumRole: viewer`.

**Count changes:** Endpoints 76→79 · Policies 76→79 · Health checks 37 (unchanged) · Subsystems 27 (unchanged) · Graph nodes 27 (unchanged)

**Phase 85 test results (50/50 ALL PASS)**

---

### Phase 87 — Workspace Diff & Change-Detection Layer

**Motivation:** Phases 83–86 established real-time views, point-in-time snapshots, and a temporal event stream. Phase 87 closes the audit loop — given any two retained snapshots, it computes a bounded, structured diff report covering summary counts, project changes, membership, quotas, and activity. All computation is pure and stateless; no new subsystem, no new persistence, no new health check.

**New module:** `core/workspaceDiff.ts` — pure read-only computation, no init function, no subsystem registration, no persistence, no import of `workspaceShell` directly.

- Imports only `./workspaceSnapshots` (`listWorkspaceSnapshots`, `getWorkspaceSnapshotById`).
- `getWorkspaceSnapshotById` added to `workspaceSnapshots.ts` — linear scan of in-memory ring, returns `WorkspaceSnapshot | null`.
- `computeDiff(from, to)` — internal pure function; never throws, never logs, never mutates.
- `getWorkspaceDiff(fromId, toId)` — tagged-union return: `{ result }` or `{ error, status }`.
- `listWorkspaceDiffPairs()` — builds consecutive pairs from listing newest-first; pair[0] = most-recent interval.
- `diffId` = `fromSnapshotId-toSnapshotId` (concatenated with `-`).
- `summaryDelta` — 10 `WorkspaceDiffCountDelta` fields: each has `from`, `to`, `delta`, `increased`, `decreased`, `unchanged`.
- `projectChanges.newlyObserved` — bounded comparison of `recentProjects` arrays (max 5 entries each); not a full registry scan.
- `membershipDelta.roleDeltas` — capped at `MAX_DIFF_ROLE_KEYS = 10` role entries, sorted alphabetically.
- `changeCount` — sum of non-unchanged deltas + newly observed project count.
- `hasChanges` — `changeCount > 0`.
- `timeDeltaMs` may be negative if `from` is newer than `to` (reversed diff is valid, no guard applied).

**New endpoints:**
- `GET /api/workspace/diff` — lists all consecutive snapshot pairs from the ring.
- `GET /api/workspace/diff/:fromSnapshotId/:toSnapshotId` — computes full structured diff between any two retained snapshots; 404 if either ID is absent, error message cites the missing ID.

**Count changes:** Endpoints 81→83 · Policies 81→83 · Health checks 37 (unchanged) · Subsystems 27 (unchanged) · Graph nodes 27 (unchanged)

**Phase 87 test results (60/60 ALL PASS)**

| Test group | Result |
|---|---|
| T01: Policy count 83 | ✅ |
| T02: `GET /api/workspace/diff` 200, shape, executionBlocked, note | ✅ |
| T03: Missing IDs → 404 with error message | ✅ |
| T04: Create two snapshots — IDs distinct | ✅ |
| T05: Diff list — availableSnapshots ≥2, availablePairs ≥1, pair shape, executionBlocked | ✅ |
| T06: `GET /diff/:id/:id` 200 — diffId, from/to IDs, computedAt, timeDeltaMs/Seconds, hasChanges, changeCount | ✅ |
| T07: summaryDelta — 10 fields, each with from/to/delta/increased/decreased/unchanged; same-state → unchanged=true | ✅ |
| T08: projectChanges — note, newlyObserved array, counts | ✅ |
| T09: membershipDelta — totalRecordsDelta, projectsWithMembersDelta, roleDeltas array and item shape | ✅ |
| T10: quotaDelta and activityDelta shape | ✅ |
| T11: from/to metadata — projectCount, memberCount, activityCount | ✅ |
| T12: Reversed diff 200, diffId reversed, executionBlocked | ✅ |
| T13: Bad fromId → 404, error cites missing ID | ✅ |
| T14: Bad toId → 404, error cites missing ID | ✅ |
| T15: POST/DELETE on diff endpoints blocked (404/405) | ✅ |
| T16: No secrets in diff response | ✅ |
| T17: Diff policies — count 2, all viewer+read | ✅ |
| T18: Graph 0 cycles | ✅ |
| T19: healthz 200 | ✅ |
| T20: Security headers present on diff endpoint | ✅ |

---

### Phase 86 — Workspace Timeline & Activity Feed Layer

**Motivation:** Phases 83–85 established real-time views and point-in-time snapshots. Phase 86 adds a unified temporal observability stream — aggregating project lifecycle events, membership changes, quota updates, and snapshot creation into a filterable, bounded timeline. This closes the workspace platform's read-only observability layer.

**Design decisions:**
- New module `core/workspaceTimeline.ts` — pure read-only aggregation, no persistence, no init function, no subsystem registration. Re-aggregates from live data on every call.
- Data sources: `listProjects()` + `getProjectActivity(pid, { limit: 100 })` per project + `listWorkspaceSnapshots()` from Phase 85.
- Event types: `project_created`, `status_transition`, `member_added`, `member_removed`, `quota_updated`, `quota_reset`, `workspace_snapshot_created`.
- Sources: `project_registry`, `membership`, `quota`, `workspace_snapshots`.
- Global event cap: 500 (`MAX_TIMELINE_EVENTS`). Merge is O(n log n) on bounded set (max ~10,100 input events).
- Filters: `?projectId` (exact match), `?eventType` (allowlisted — invalid silently ignored), `?limit` (default 100, max 500 — out-of-range defaults to 100).
- `GET /api/workspace/activity-feed` groups events by project, most-recently-active first, 5 recent events per project, workspace snapshot count included.
- Metadata is sanitized to `Record<string, string | number | boolean | null>` — no nested objects, no secret keys.
- `workspace_snapshot_created` events have `projectId: null` / `projectName: null` — workspace-scoped, excluded by `?projectId` filter (by design).

**Count changes:** Endpoints 79→81 · Policies 79→81 · Health checks 37 (unchanged) · Subsystems 27 (unchanged) · Graph nodes 27 (unchanged)

**Phase 86 test results (76/76 ALL PASS)**

**Phase 84 test results (100/100 ALL PASS — see PHASE_ARCHIVE.md for full record):**

| Test group | Result |
|---|---|
| T1–T7: All 6 new endpoints + all 5 panel routes return 200 | ✅ |
| T8–T18: Navigation shape — executionBlocked, sections array, totalSections=3, totalPanels=5, sectionIds | ✅ |
| T19–T27: Panel list shape — executionBlocked, count=5, all 5 panelIds, endpoints, sections, permission | ✅ |
| T28–T34: Diagnostics panel — panelId, status, registryOperational, totalProjects, layer, storeKeyCount | ✅ |
| T35–T44: Projects panel — panelId, total, byStatus sum, recentProjects ≤5, capacity math | ✅ |
| T45–T49: Quotas panel — panelId, custom+defaults=total, systemDefaults (10/500/10) | ✅ |
| T50–T54: Activity panel — panelId, totalRecords, projectsWithActivity ≤ totalProjects | ✅ |
| T55–T59: Membership panel — panelId, totalRecords, projectsWithMembers ≤ totalProjects, roleDistribution | ✅ |
| T60–T62: Unknown panelId → 404 with known IDs in message | ✅ |
| T63–T69: Live state reflection — create project, add member, set quota, all panels reflect changes | ✅ |
| T70–T73: Nav panel-to-section mapping correct for all 5 panels | ✅ |
| T74–T78: recentProjects shape — projectId/name/status/owner/createdAt | ✅ |
| T79–T83: Policy parity — 76 policies, 6 workspace paths, navigation/panels/panels/:panelId present | ✅ |
| T84–T92: Core invariants — healthz, health/full=37, diagnostics counts, graph cycles=0, caps invalid=0, BASELINE_LOCK frozen | ✅ |
| T93–T96: No secrets, executionBlocked present, no mutation paths, all GET | ✅ |
| T97–T100: Cross-endpoint consistency + Phase 83 routes still working | ✅ |

**Files changed:** `core/workspaceShell.ts` (navigation + panel layer appended), `routes/workspace.ts` (3 new handlers + sendError import), `core/accessEnforcement.ts` (3 policies added + description updated), `server.ts` (3 new imports + 3 route registrations), `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `ENDPOINTS.md`, `replit.md`, `ARCHITECTURE.md`

---

### Phase 83 — Workspace UI Shell Foundation

Introduces the first governed UI-facing workspace shell layer. Three new read-only aggregation endpoints — no new subsystem, no new health check, no persistence, no mutation paths. Pure facade over existing product-layer exports.

**Motivation:** The project registry, membership, activity, and quota systems (Phases 75–80) created rich per-project state. Phase 83 surfaces a workspace-level aggregate view of that state — suitable for dashboard consumption — without exposing internal mechanics, secrets, or mutation vectors.

**Architecture invariants:**
- `core/workspaceShell.ts` is a pure aggregation module: no imports from `persistentStore`, no `readStore`/`writeStore`, no `initX()` function, no subsystem registration, no health check, no graph node. It only imports from `core/projectRegistry.ts`.
- No persistence: the workspace shell computes on every call from in-memory state. No files written, no ring buffers owned.
- No mutation: all three route handlers call only `getWorkspaceSummary()`, `getProjectsOverview()`, `getWorkspaceHealth()` — all pure reads.
- No secrets: none of the workspace responses include auth keys, API keys, vault entries, or session tokens. The `owner` field (project creator identity) is included — it is a user-supplied string, not a credential.
- `executionBlocked: true` typed as literal `true` on all three response interfaces and all `ProjectOverviewItem` entries.

**New core module: `core/workspaceShell.ts`**

| Export | Kind | Detail |
|---|---|---|
| `WorkspaceSummary` | interface | `projects` (total/active/archived/suspended), `capacity` (max/used/available/utilizationPercent/atCapacity), `members.totalRecords`, `activity.totalRecords`, `quotas` (projectsWithCustomQuotas/projectsUsingDefaults), `executionBlocked: true` |
| `ProjectOverviewResult` | interface | `projects: ProjectOverviewItem[]`, `count`, `total`, `filtersApplied`, `limit`, `executionBlocked: true` |
| `ProjectOverviewItem` | interface | `projectId`, `projectName`, `status`, `owner`, `createdAt`, `updatedAt`, `memberCount`, `hasCustomQuota`, `activityCount`, `executionBlocked: true` |
| `WorkspaceHealthSummary` | interface | `status` (ok/degraded), `registryOperational`, `totalProjects`, `totalMembers`, `totalActivityRecords`, `customQuotaProjects`, `storeKeyCount`, `executionBlocked: true` |
| `WorkspaceProjectCounts` | interface | `total`, `active`, `archived`, `suspended` |
| `WorkspaceCapacity` | interface | `max`, `used`, `available`, `utilizationPercent`, `atCapacity` |
| `WorkspaceHealthStatus` | type | `"ok" \| "degraded"` |
| `ProjectOverviewFilters` | interface | `status?`, `limit?` |
| `getWorkspaceSummary()` | function | Calls `listProjects()`, `getProjectRegistryStatus()`, `getMemberStats()`, `getActivityStats()`, `getProductLayerHealth()` — all in-memory |
| `getProjectsOverview(filters?)` | function | Calls `listProjects()`, then for each project in slice: `listProjectMembers()`, `getProjectQuota()`, `getProjectActivity()` — all in-memory; `?status` filter (active/archived/suspended); `?limit` capped at 50 |
| `getWorkspaceHealth()` | function | Calls `getProductLayerHealth()` only — single in-memory read |

**New route file: `routes/workspace.ts`**

Three handlers, all `_req`-agnostic except the overview which parses `?status` and `?limit` from `req.url` using the built-in `URL` class.

**New endpoints:**

| Method | Route | Permission | Min Role | Description |
|---|---|---|---|---|
| GET | `/api/workspace/summary` | read | viewer | Workspace-level aggregate: project counts by status, capacity utilization %, member/activity/quota totals |
| GET | `/api/workspace/projects/overview` | read | viewer | Per-project enriched listing: memberCount, activityCount, hasCustomQuota; `?status` filter; `?limit` ≤50 |
| GET | `/api/workspace/health` | monitor | viewer | Workspace health facade: registry operational, project/member/activity totals, store key count |

**Count changes:** Endpoints 70→73 · Policies 70→73 · Health checks 37 (unchanged) · Subsystems 27 (unchanged) · Graph nodes 27 (unchanged) · `accessEnforcement.ts` subsystem description updated to "73-route policy map"

**`getProjectsOverview` per-project computation:**

For each project in the sliced result set, the function makes three in-memory calls:
1. `listProjectMembers(projectId)` → `.count` → `memberCount`
2. `getProjectQuota(projectId)` → `!isDefault` → `hasCustomQuota`
3. `getProjectActivity(projectId, {})` → `.total` → `activityCount` (total unfiltered activity records for that project)

All three calls are O(1) Map lookups. `listProjectMembers` iterates the actorMap to sort by `addedAt` — O(m) where m = member count per project. `getProjectActivity` reverse-slices the activity array — O(a) where a = activity count per project. For the default limit of 50 projects, worst case is O(50 × (m + a)) which is bounded and non-blocking.

**Security review:**

- No auth tokens, no API keys, no vault secrets in any workspace response field
- `owner` field is user-supplied project creator identity (not a credential)
- No stack traces, no internal module paths, no file paths exposed
- All input from query params is validated: unknown status values silently ignored, non-integer/negative limit values silently ignored
- No POST, PATCH, or DELETE methods registered under `/api/workspace/*`

**Phase 83 test results (78/78 ALL PASS):**

| Test group | Result |
|---|---|
| T1–T3: Basic 200 responses — summary, overview, health | ✅ |
| T4–T16: WorkspaceSummary shape — executionBlocked, checkedAt, all project/capacity/member/activity/quota fields, math invariants | ✅ |
| T17–T24: ProjectOverviewResult shape — executionBlocked, checkedAt, projects array, count/total/limit/filtersApplied | ✅ |
| T25–T32: WorkspaceHealthSummary shape — executionBlocked, status, registryOperational, totals, storeKeyCount | ✅ |
| T33–T38: Live state reflection — summary reflects create/member-add/quota-set changes | ✅ |
| T39–T47: Per-project overview items — projectId/name/memberCount/activityCount/hasCustomQuota correct for created project | ✅ |
| T48–T56: Filters — ?status=active/archived, ?limit=1, invalid status silently ignored | ✅ |
| T57: No secrets/tokens/keys in any response | ✅ |
| T58–T60: Policy parity — 73 policies, 3 workspace paths, all GET | ✅ |
| T61–T70: Core invariants — healthz/health-full/diagnostics-snapshot counts, graph cycles, cap invalid refs, BASELINE_LOCK frozen | ✅ |
| T71–T78: Read-only guarantees, cross-endpoint consistency, math verification, executionBlocked presence | ✅ |

**Files changed:** `core/workspaceShell.ts` (new), `routes/workspace.ts` (new), `core/accessEnforcement.ts` (3 policies added + description updated), `server.ts` (import + 3 route registrations), `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `ENDPOINTS.md`, `replit.md`, `ARCHITECTURE.md`

---

### Phase 82 — replit.md Phase Archive Compaction

Documentation-only phase. No source code changes. No new endpoints, health checks, subsystems, graph nodes, or access policies. All runtime behavior, persistence, and diagnostics unchanged.

**Motivation:** After 82 phases, `replit.md` had grown to 30,633 bytes / 222 lines. The Session Checkpoint table contained 36 rows (Phases 34–70) whose implementation detail is already fully preserved in `ARCHITECTURE.md`, `GOTCHAS.md`, `NUCLEUS_LOCK.md`, and `ENDPOINTS.md`. Carrying all of them in `replit.md` made the file heavy for the AI context window without providing navigational value.

**Changes:**

| File | Action |
|---|---|
| `PHASE_ARCHIVE.md` | **Created** — new file containing full preserved phase history for Phases 1–70; each phase has its complete implementation summary exactly as it appeared in `replit.md`; cross-references to ARCHITECTURE.md, NUCLEUS_LOCK.md, BASELINE.md, GOTCHAS.md |
| `replit.md` | **Compacted** — Session Checkpoint table now shows only Phases 71–82; Phase 34–70 rows removed (moved to PHASE_ARCHIVE.md); archive reference row added; `PHASE_ARCHIVE.md` added to the top-level reference list; `server.ts` route count corrected 46→70; storage layout section extended with all 7 store keys; `runtimeDependencyGraph` + `runtimeCapabilityMatrix` node counts corrected 20→27; missing core modules (diagnostics, accessEnforcement, identityAccess, auditLog, sessionContext, rateLimiter, apiKeyAuth, secretVault, projectRegistry) added to directory tree; missing route files (baseline, identityAccess, accessEnforcement, auditLog, projects) added to route listing; Quick summary updated with access policies count and drift state; endpoints count corrected 67→70 |
| `NUCLEUS_LOCK.md` | Phase 82 row added to phase table; Total row unchanged (70 endpoints, 37 health checks) |
| `ARCHITECTURE.md` | Phase 82 section added (this entry) |

**Size reduction:**

| File | Before | After |
|---|---|---|
| `replit.md` | 30,633 bytes / 222 lines | ~9,600 bytes / ~140 lines |
| `PHASE_ARCHIVE.md` | — | ~9,200 bytes / ~255 lines |

**No historical loss:** Every phase entry moved to `PHASE_ARCHIVE.md` is preserved verbatim. ARCHITECTURE.md retains the full narrative for every phase. GOTCHAS.md retains all phase-specific implementation invariants. NUCLEUS_LOCK.md retains the complete phase table.

**Verification:** TypeScript typecheck clean · `/api/healthz` → 200 · `/api/health/full` 37 checks · graph 0 cycles · caps 0 invalid refs · 70 policies matched to 70 routes · no forbidden execution patterns

---

### Phase 81 — Product Layer Stabilization Checkpoint

Full stabilization and governance review of the product layer introduced across Phases 75–80. Zero new endpoints, zero new subsystems, zero new health checks, zero new access policies. Two targeted changes: a bug fix and an additive diagnostics field.

**Motivation:** Six consecutive product-layer phases (75–80) added the project registry, persistence, status transitions, memberships, activity ledger, and resource quotas. Phase 81 creates a clean checkpoint before introducing additional product complexity. It validates all invariants, confirms all bounded limits, reviews all persistence guarantees, and ensures security flags are intact across the full product layer.

**Stabilization review findings:**

| Area | Finding | Status |
|---|---|---|
| Route registration | 70 routes in `server.ts`, 70 policies in `accessEnforcement.ts` — exact parity | ✓ Clean |
| Route ordering | Specific paths (`/api/projects`, `/api/projects/:id`) registered before parameterized sub-routes — no ambiguity | ✓ Clean |
| Segment extraction | All sub-resource handlers use `segments[3]` for `projectId`; `handleProjectMemberDelete` uses `segments[5]` for `actorId`; both correct for 6-segment URLs | ✓ Clean |
| Init order | `initProjectRegistry()` → `initProjectMembers()` → `initProjectActivity()` → `initProjectQuotas()` — each depends on the prior | ✓ Clean |
| Store keys | All 4 keys present in storage (`project-registry`, `project-members`, `project-activity`, `project-quotas`) | ✓ Clean |
| Mutation paths | All 6 mutation functions return `executionBlocked: true` — no exceptions | ✓ Clean |
| Error handling | All `catch` blocks log before proceeding — no silent swallows | ✓ Clean |
| Bounded limits | `MAX_PROJECTS=100`, `MAX_ACTIVITIES_PER_PROJECT=500` (governed by quota), member cap governed by quota (default 10, max 50) | ✓ Clean |
| Immutable fields | `createdAt`, `owner`, `projectId`, `projectName` never mutated by `transitionProjectStatus()` | ✓ Clean |
| Orphaned entries | Both `initProjectMembers()` and `initProjectActivity()` skip entries whose `projectId` is not in `projectsById` | ✓ Clean |
| Quota eviction | Member add blocks when at limit (409); activity `while` loop evicts oldest before push — never exceeds limit | ✓ Clean |
| Security fields | No secrets, keys, tokens, or credentials in any product-layer response field | ✓ Clean |
| Hidden execution | No `exec`, `spawn`, `fork`, `eval`, autonomous code generation, or network mutation paths anywhere in product layer | ✓ Clean |
| Policy drift | 70 policies exactly match 70 route registrations — no orphaned or missing policies | ✓ Clean |
| Persistence guarantees | All 4 store files use atomic `tmp → rename` writes; malformed entries are logged and skipped on boot | ✓ Clean |
| Drift state | `endpointCount` (59→70), `subsystemCount` (26→27), `graphNodeCount` (26→27) — intentional since Phase 75, documented | ✓ Expected |
| `BASELINE_LOCK.json` | Phase=43, ep=59 — untouched | ✓ Frozen |

**Bug found and fixed: `HEALTH_CHECKS_TOTAL = 36` in `core/diagnostics.ts`**

The constant was seeded at 36 and never updated when health checks #36 (`persistent_store`) and #37 (`project_registry`) were added in Phases 43 and 75 respectively. Effect: `GET /api/diagnostics/snapshot` → `counts.healthChecks` reported `36` while `/api/health/full` → `checks.length` correctly returned `37`. The snapshot consistency check also used this stale constant as the reference value when comparing against stored runtime snapshots.

Fix: `const HEALTH_CHECKS_TOTAL = 37` in `core/diagnostics.ts`. No interface changes, no endpoint changes.

**Additive diagnostics field: `productLayerHealth`**

Added `productLayerHealth` field to `GET /api/diagnostics/snapshot` (additive, no new endpoint, no new subsystem, no new health check, no new policy). Assembled from existing exported functions — pure read-only aggregation.

**New exported items in `core/projectRegistry.ts`:**

| Item | Kind | Detail |
|---|---|---|
| `ProductLayerHealth` | interface | `checkedAt`, `registryOperational`, `projectCount`, `maxProjects`, `atCapacity`, `totalMembers`, `totalActivityRecords`, `customQuotaCount`, `storeKeys[]`, `executionBlocked: true` |
| `getProductLayerHealth()` | function | Calls `getProjectRegistryStatus()`, `getMemberStats()`, `getActivityStats()`, and reads `quotasByProject.size` — all in-memory, no disk I/O, no side effects |

**`productLayerHealth` field semantics:**

| Field | Source | Note |
|---|---|---|
| `registryOperational` | `getProjectRegistryStatus().operational` | `true` after `initProjectRegistry()` |
| `projectCount` | `getProjectRegistryStatus().projectCount` | Live count from `projectsById.size` |
| `maxProjects` | constant `MAX_PROJECTS` (100) | Never changes |
| `atCapacity` | `projectCount >= maxProjects` | `false` until 100 projects exist |
| `totalMembers` | `getMemberStats().totalMemberRecords` | Sum across all projects' member maps |
| `totalActivityRecords` | `getActivityStats().totalActivityRecords` | Sum across all projects' activity arrays |
| `customQuotaCount` | `quotasByProject.size` | Projects with explicitly set quotas (not using defaults) |
| `storeKeys` | constant array of 4 strings | Always `["project-registry", "project-members", "project-activity", "project-quotas"]` |
| `executionBlocked` | literal `true` | Constitutional — typed as literal |

**Other changes:**

| File | Change |
|---|---|
| `core/diagnostics.ts` | `HEALTH_CHECKS_TOTAL: 36 → 37`; import + re-export of `getProductLayerHealth`/`ProductLayerHealth`; `productLayerHealth` added to `DiagnosticsSnapshot` interface + `getDiagnosticsSnapshot()` return |
| `core/projectRegistry.ts` | `ProductLayerHealth` interface + `getProductLayerHealth()` appended at end of file |

**Count changes:** Endpoints remain 70. Policies remain 70. Health checks remain 37 (count was always 37 — bug was in the reporting constant). Subsystems remain 27. Graph nodes remain 27. `BASELINE_LOCK.json` not mutated.

**Phase 81 test results (45/45 ALL PASS):**

| Tests | Result |
|---|---|
| T1–T12: productLayerHealth shape — field present, executionBlocked, checkedAt, registryOperational, projectCount, maxProjects, atCapacity, totalMembers, totalActivityRecords, customQuotaCount, storeKeys length=4, storeKeys content | ✅ |
| T13: counts.healthChecks === 37 (bug fix confirmed — was 36) | ✅ |
| T14–T17: No new endpoints (70), subsystems (27), graph nodes (27), policies (70) | ✅ |
| T18: health/full checks.length === 37 | ✅ |
| T19–T21: Graph 0 cycles, capabilities 27/0 invalid refs | ✅ |
| T22–T23: BASELINE_LOCK frozen at ep=59, endpointCount drifted to 70 (intentional) | ✅ |
| T24: /api/healthz 200 | ✅ |
| T25: No secrets in productLayerHealth | ✅ |
| T26–T30: Live state tracking — projectCount increments on create, totalMembers on member add, totalActivityRecords on events | ✅ |
| T31–T34: customQuotaCount increments on quota set, decrements on reset | ✅ |
| T35–T36: atCapacity=false, registryOperational=true | ✅ |
| T37–T38: healthCheckCount not drifted (37==37), counts.healthChecks=37 confirmed | ✅ |
| T39: No execution path fields in productLayerHealth | ✅ |
| T40–T44: Policy count stable, snapshotConsistency present, diagBaseline intentional drift, consecutive calls consistent | ✅ |
| T45: executionBlocked=true present in productLayerHealth JSON | ✅ |

**Stabilization assessment — product layer (Phases 75–80):**

- All 11 product-layer endpoints correctly registered and policy-mapped (GET/POST/PATCH/DELETE across 6 sub-resources)
- All 4 persistence paths use atomic writes with malformed-data guards and restart-survival
- All mutation paths return `executionBlocked: true` as a typed literal constant
- No hidden execution, recovery, or autonomous-action paths in any product-layer module
- Quota enforcement is point-of-write (not eventually consistent): `addProjectMember()` checks before insert, `recordActivity()` evicts before push
- Activity ledger ring buffer and quota-governed activity cap work independently — quota governs the cap, ring buffer implements the eviction
- Drift is fully intentional and documented: `BASELINE_LOCK.json` is sealed at Phase 43 (ep=59, hc=36, sub=26, graph=26); product-layer growth creates expected drift on 3 of 6 dimensions

**Files changed:** `core/projectRegistry.ts` (interface + function appended), `core/diagnostics.ts` (bug fix + import + interface field + return field), `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `ENDPOINTS.md`, `replit.md`, `ARCHITECTURE.md`.

---

### Phase 80 — Project Resource Quotas

Introduces a per-project resource quota system that enforces configurable capacity limits on membership and activity. Three new endpoints (+3), three new access policies (+3), zero new subsystems, zero new health checks, zero new graph nodes.

**Motivation:** Phases 75–79 built the project registry, persistence, lifecycle, membership, and activity ledger. Phase 80 adds governance enforcement — every project now has bounded resource limits that are inspectable, configurable, and enforced at the point of mutation. The quota system closes the loop: `addProjectMember()` blocks when the project is at its member limit, and `recordActivity()` evicts old entries when the project is at its activity limit. Both limits are soft defaults that operators can tighten or loosen per project within defined bounds.

**Quota fields and bounds:**

| Field | Default | Min | Max | Type |
|---|---|---|---|---|
| `maxMembers` | 10 | 1 | 50 | integer |
| `maxActivityEntries` | 500 | 100 | 500 | integer |
| `maxTags` | 0 | 0 | 20 | integer (reserved for future tagging) |

**`isDefault` semantics:** `true` when no quota has ever been explicitly set for the project (all fields at defaults), `false` once any field has been set via POST. A DELETE (reset) restores all fields to defaults and sets `isDefault` back to `true`.

**Quota enforcement points:**

| Enforcement site | Quota field | Behaviour when at limit |
|---|---|---|
| `addProjectMember()` | `maxMembers` | Returns `{ success: false, errorType: "capacity" }` → HTTP 409 |
| `recordActivity()` | `maxActivityEntries` | `while` loop evicts oldest entries until count < limit before push |

**No eviction of existing members:** Reducing `maxMembers` below the current member count does not remove existing members — only new additions are blocked. Existing members are always preserved.

**New exported items in `core/projectRegistry.ts`:**

| Item | Kind | Detail |
|---|---|---|
| `ProjectQuota` | interface | `projectId`, `maxMembers`, `maxActivityEntries`, `maxTags`, `updatedAt`, `executionBlocked: true` |
| `ProjectQuotaResult` | interface | `success`, `projectId`, `isDefault`, `quota`, `executionBlocked`, `timestamp`, `error?`, `errorType?` |
| `ProjectQuotaResetResult` | interface | `success`, `projectId`, `reset: true`, `quota`, `executionBlocked`, `timestamp` |
| `initProjectQuotas()` | function | Load-on-boot after `initProjectActivity()`, validate, skip orphaned/malformed |
| `getProjectQuota(projectId)` | function | Returns effective quota (defaults if never set), plus `isDefault` flag |
| `setProjectQuota(projectId, patch)` | function | Partial update — merges over existing values, validates all provided fields, rejects on unknown projectId |
| `resetProjectQuota(projectId)` | function | Removes custom quota entry, restores defaults |
| `getEffectiveMaxMembers(projectId)` | function declaration | Returns custom `maxMembers` or default (10); hoisted — callable from membership block above |
| `getEffectiveMaxActivityEntries(projectId)` | function declaration | Returns custom `maxActivityEntries` or default (500); hoisted — callable from activity block above |
| `ActivityType` (extended) | type | Now includes `"quota_updated"` and `"quota_reset"` in addition to 4 prior types |
| `ProjectMembershipResult.errorType` (extended) | union | Now includes `"capacity"` in addition to `"not_found"`, `"conflict"`, `"validation"` |

**Validation rules for POST /api/projects/:id/quotas:**

All provided fields validated before any write. Errors from all invalid fields are collected and returned as a single semicolon-delimited message.

| Rule | Condition | Error |
|---|---|---|
| Type check | Not a number | Field name + "must be an integer" |
| Integer check | `!Number.isInteger(val)` | Field name + "must be an integer" |
| Range check | Outside field-specific bounds | Field name + "must be an integer between X and Y" |

**Activity types added (auto-recorded on quota mutations):**

| Type | Trigger function | actorId |
|---|---|---|
| `quota_updated` | `setProjectQuota()` | `"system"` |
| `quota_reset` | `resetProjectQuota()` | `"system"` |

**Store file:** `artifacts/api-server/storage/store/project-quotas.json`

Flat JSON array of all non-default quota records (projects using defaults are NOT written to disk — only customized quotas). Sorted by `projectId` for stable diffs. `executionBlocked: true` on every disk entry.

**Load-on-boot validation in `initProjectQuotas()`:**

```
readStore<unknown[]>("project-quotas")
  → null/error → start empty, log error
  → Array → iterate each entry:
      isValidStoredQuota(raw) → false → logger.warn + skip
      projectsById.has(raw.projectId) → false → logger.warn + skip (orphaned)
      push into quotasByProject Map
      booted++
```

**Handler-to-HTTP status mapping for member capacity errors:**

`addProjectMember()` returns `{ success: false, errorType: "capacity" }` when the project is at its member limit. The route handler maps this to HTTP 409 (same as `"conflict"`) — both represent a resource contention state, not a client validation error (400).

**Other changes:**

| File | Change |
|---|---|
| `routes/projects.ts` | 3 new handlers (`handleProjectQuotasGet`, `handleProjectQuotasPost`, `handleProjectQuotasDelete`); capacity errorType → 409 in `handleProjectMembersPost` |
| `server.ts` | 3 new route registrations; import extended |
| `core/accessEnforcement.ts` | 3 new policies (GET viewer+, POST/DELETE operator+); metadata "67-route" → "70-route" |
| `core/runtime.ts` | Import + call `initProjectQuotas()` after `initProjectActivity()` |

**Count changes:** Endpoints 67→70. Policies 67→70. Health checks remain 37. Subsystems remain 27. Graph nodes remain 27. `BASELINE_LOCK.json` not mutated — intentional drift continues.

**Phase 80 test results (116/116 ALL PASS):**

| Tests | Result |
|---|---|
| T1–T2g: GET quotas — 200, shape, projectId, isDefault=true, defaults (10/500/10), executionBlocked | ✅ |
| T3–T3f: POST full update — 200, isDefault=false, all three fields updated, executionBlocked | ✅ |
| T4–T4d: GET after update reflects new values | ✅ |
| T5–T5d: Partial update (maxMembers only) — other fields preserved | ✅ |
| T6–T6c: Partial update (maxTags only) — other fields preserved | ✅ |
| T7–T7f: DELETE reset — 200, reset=true, all fields back to defaults, isDefault=true | ✅ |
| T8–T8b: GET after reset shows isDefault=true | ✅ |
| T9–T9f: Out-of-bounds values rejected → 400 for all 6 boundary violations | ✅ |
| T10: Invalid calls do not mutate quota | ✅ |
| T11–T13: Float, string, boolean types rejected → 400 | ✅ |
| T14: Null body handled safely (200 no-op or 400) | ✅ |
| T15–T15c: Unknown project → 404 for GET/POST/DELETE | ✅ |
| T16–T17: Member add blocked at quota limit → 409; error message contains "limit" and quota value | ✅ |
| T18: Increasing quota allows previously blocked member → 201 | ✅ |
| T19–T19e: quota_updated activity recorded with actorId=system and all metadata fields | ✅ |
| T20–T20b: quota_reset activity recorded | ✅ |
| T21–T21b: quota_updated / quota_reset are valid activity type filters | ✅ |
| T22–T22b: maxActivityEntries quota respected in recordActivity | ✅ |
| T23–T23f: All 6 boundary values (min/max per field) accepted → 200 | ✅ |
| T24: quota.executionBlocked=true in all response shapes | ✅ |
| T25–T25b: Multi-field invalid → 400, all invalid field names in error message | ✅ |
| T26–T29: Disk persistence — file exists, array, required fields, executionBlocked=true, sorted by projectId | ✅ |
| T30: storage/status includes project-quotas key | ✅ |
| T31–T33d: Policy count=70, 3 quota policies (GET viewer, POST/DELETE operator) | ✅ |
| T32: endpoint count=70 in diagnostics snapshot | ✅ |
| T34: graph 27 nodes, 0 cycles | ✅ |
| T35: capabilities 27 subsystems, 0 invalid refs | ✅ |
| T36: health checks=37 | ✅ |
| T37: BASELINE_LOCK not mutated (phase=43, ep=59) | ✅ |
| T38: /api/healthz ok | ✅ |
| T39: Forbidden patterns clean | ✅ |
| T40: No secrets in quota response | ✅ |
| T41–T41b: Empty body POST preserves existing values | ✅ |
| T42–T43: quota_updated/quota_reset recorded multiple times across test run | ✅ |
| T44–T44b: Existing members not evicted by quota reduction; new add blocked → 409 | ✅ |
| T45–T45b: All 3 fields invalid simultaneously → 400 with all 3 field names in error | ✅ |
| T46: Drift on endpointCount still detected (intentional) | ✅ |
| T47: All disk quota values within valid ranges | ✅ |
| T48–T48c: GET/POST/DELETE response shapes all have full quota fields | ✅ |
| T49: quota_updated recognized as valid activity type filter | ✅ |
| T50–T50c: Quota file present, all entries executionBlocked=true, all required fields present | ✅ |

**Files changed:** `core/projectRegistry.ts` (quota block + `getEffectiveMax*` function declarations + 2 `ActivityType` extensions + `errorType` extension + quota enforcement in `addProjectMember()` and `recordActivity()`), `routes/projects.ts` (3 new handlers + capacity→409 fix), `server.ts` (imports + 3 routes), `core/accessEnforcement.ts` (3 policies + metadata), `core/runtime.ts` (import + init call), `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `ENDPOINTS.md`, `replit.md`, `ARCHITECTURE.md`.

---

### Phase 79 — Project Activity Ledger & Audit Timeline

Introduces an append-only per-project activity ledger that automatically traces every project lifecycle action. One new endpoint (+1), one new access policy (+1), zero new subsystems, zero new health checks, zero new graph nodes.

**Motivation:** Phases 75–78 built the project registry, persistence, lifecycle transitions, and membership. Phase 79 closes the observability gap — every mutation now leaves a durable, queryable, structured audit trail per project. This satisfies the requirement for traceable governance without autonomous execution, workers, or new infrastructure.

**Activity types recorded (auto, not user-triggered):**

| Type | Trigger function | actorId |
|---|---|---|
| `project_created` | `createProject()` | project `owner` |
| `status_transition` | `transitionProjectStatus()` | `"system"` |
| `member_added` | `addProjectMember()` | member `actorId` |
| `member_removed` | `removeProjectMember()` | removed `actorId` |

**New exported items in `core/projectRegistry.ts`:**

| Item | Kind | Detail |
|---|---|---|
| `ActivityType` | type | `"project_created" \| "status_transition" \| "member_added" \| "member_removed"` |
| `ProjectActivity` | interface | `activityId` (16-char hex), `projectId`, `type`, `actorId`, `createdAt`, `metadata`, `executionBlocked: true` |
| `ActivityLedgerResult` | interface | `success`, `projectId`, `activities[]`, `count`, `total`, `filtersApplied[]`, `error?`, `errorType?`, `executionBlocked: true` |
| `ActivityLedgerStats` | interface | `totalActivityRecords`, `activityFlushCount`, `activityLastFlushedAt`, `activityLoadedOnBoot` |
| `initProjectActivity()` | function | Load-on-boot, validate, skip orphaned/malformed |
| `recordActivity(projectId, type, actorId, metadata)` | function | Append + trim + flush (no-op on unknown projectId gracefully) |
| `getProjectActivity(projectId, filters)` | function | List with type/actorId/limit filter, newest-first |
| `getActivityStats()` | function | Aggregate totals |

**Internal function (not exported):**

| Function | Purpose |
|---|---|
| `sanitizeMetadata(raw)` | Max 20 keys, key ≤64 chars, value ≤256 chars (string), string/number/boolean only — all other values silently dropped |
| `isValidStoredActivity(obj)` | Type guard for disk entries — activityId hex, type in set, all string fields present, executionBlocked=true |
| `flushProjectActivity()` | Serialize `activityByProject` to flat sorted array, `try/catch` wrapped |

**In-memory data structure:**

```
activityByProject: Map<projectId, ProjectActivity[]>
  — each array maintained oldest-first
  — max MAX_ACTIVITIES_PER_PROJECT (500) per project
  — overflow: entries.shift() before push (sliding window)
  — never mutated by getProjectActivity() — uses slice().reverse()
```

**Store file:** `artifacts/api-server/storage/store/project-activity.json`

Flat JSON array of all activity records across all projects, sorted by `(projectId, createdAt)` for stable diffs and deterministic reconstruction on restart.

**Load-on-boot validation in `initProjectActivity()`:**

```
readStore<unknown[]>("project-activity")
  → null/error → start empty, log error
  → Array → iterate each entry:
      isValidStoredActivity(raw) → false → logger.warn + skip
      projectsById.has(raw.projectId) → false → logger.warn + skip (orphaned)
      over MAX_ACTIVITIES_PER_PROJECT → entries.shift() first
      push sanitized entry into activityByProject
      booted++
```

**Query parameter handling for `GET /api/projects/:id/activity`:**

| Param | Valid range | Invalid behaviour |
|---|---|---|
| `?type` | One of 4 valid types | Silently ignored — no filter applied |
| `?actorId` | Any non-empty string | Unknown actor returns empty results (not error) |
| `?limit` | 1–100 | Non-positive, non-numeric, >100 → defaults to 50 (>100 capped at 100) |
| Unknown params | — | Silently ignored |

**`total` vs `count` semantics:**

- `total` = number of entries after type/actorId filters, before limit slice
- `count` = number of entries returned (≤ limit)
- Caller can detect truncation via `total > count`

**Function-declaration hoisting:**

`recordActivity()` is a function declaration appearing at the bottom of `projectRegistry.ts` but called from `createProject()`, `transitionProjectStatus()`, `addProjectMember()`, and `removeProjectMember()` which appear earlier. JavaScript function declarations are hoisted to module scope — this is safe and intentional. Do NOT change `recordActivity()` to a function expression.

**Other changes:**

| File | Change |
|---|---|
| `routes/projects.ts` | `handleProjectActivityGet` handler; import `getProjectActivity` |
| `server.ts` | Import + `router.get("/api/projects/:id/activity", handleProjectActivityGet)` |
| `core/accessEnforcement.ts` | 1 new policy (GET /activity, read, viewer+); metadata "66-route" → "67-route" |
| `core/runtime.ts` | Import + call `initProjectActivity()` after `initProjectMembers()` |

**Count changes:** Endpoints 66→67. Policies 66→67. Health checks remain 37. Subsystems remain 27. Graph nodes remain 27. `BASELINE_LOCK.json` not mutated — intentional drift continues.

**Phase 79 test results (91/91 ALL PASS):**

| Tests | Result |
|---|---|
| T1–T1h: GET activity shape — 200, array, projectId, executionBlocked, timestamp, filtersApplied, count, total | ✅ |
| T2–T2g: project_created auto-recorded — activityId hex, actorId=owner, createdAt, metadata.projectName/status, executionBlocked | ✅ |
| T3–T3f: status_transition auto-recorded — actorId=system, previousStatus/currentStatus in metadata | ✅ |
| T4–T4c: member_added auto-recorded — actorId, metadata.role | ✅ |
| T5–T5b: member_removed auto-recorded — actorId | ✅ |
| T6–T6b: newest-first ordering verified | ✅ |
| T7–T9: type filter (project_created, status_transition, member_added) | ✅ |
| T10–T10c: actorId filter, filtersApplied, count | ✅ |
| T11–T11b: combined type+actorId filter, filtersApplied length=2 | ✅ |
| T12–T13: invalid type silently ignored, unknown actorId returns empty | ✅ |
| T14–T18: limit default/max/cap/invalid handling | ✅ |
| T19–T19b: unknown project → 404 with error body | ✅ |
| T20–T21: project-scoped isolation, all activities have matching projectId | ✅ |
| T22–T29: persistence — file exists, fields, executionBlocked, sort order, valid types, activityId hex, metadata object/values | ✅ |
| T30–T34: policy=67, endpoint=67, graph=27/0, caps=27/0, health=37 | ✅ |
| T35–T37: BASELINE_LOCK intact, /api/healthz ok, forbidden patterns clean | ✅ |
| T38–T39: activity policy shape, no secrets in response | ✅ |
| T40–T43: multiple transitions/members recorded, actorId=system filter, actorId=phase79 filter | ✅ |
| T44–T47: total vs count semantics, limit=0/negative/unknown params | ✅ |
| T48–T50b: storage key present, disk survival, executionBlocked=true on all disk entries | ✅ |

**Files changed:** `core/projectRegistry.ts` (activity block appended, 4 `recordActivity()` call-sites inserted), `routes/projects.ts` (1 handler + import), `server.ts` (import + route), `core/accessEnforcement.ts` (1 policy + metadata), `core/runtime.ts` (import + init call), `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `ENDPOINTS.md`, `replit.md`, `ARCHITECTURE.md`.

### Phase 78 — Project Membership & Role Assignment

Adds a governed multi-actor membership layer to the project registry. Three new endpoints (+3), three new access policies (+3), one new `delete()` router method, one `"DELETE"` type extension in `RouteAccessPolicy`. No new subsystems, no new health checks, no new graph nodes.

**Motivation:** Phase 77 gave projects lifecycle states. Phase 78 makes projects multi-actor — each project can have a bounded set of named actors with explicit project-scoped roles. Membership is a sub-resource of the project registry, not an independent subsystem. The membership layer follows the exact same read-validate-mutate-flush pattern established by Phases 43–47.

**Member roles (project-scoped, not system identity roles):**

| Role | Description |
|---|---|
| `owner` | Full project authority |
| `operator` | Operational control |
| `maintainer` | Day-to-day maintenance |
| `observer` | Read-only visibility |
| `auditor` | Audit access |

These are entirely separate from the system `Role` type (`owner | admin | operator | viewer | guest` from `identityAccess.ts`). They share some names by coincidence; they are different types with different semantics.

**New exported items in `core/projectRegistry.ts`:**

| Item | Kind | Detail |
|---|---|---|
| `MemberRole` | type | `"owner" \| "operator" \| "maintainer" \| "observer" \| "auditor"` |
| `ProjectMember` | interface | `actorId`, `role`, `addedAt`, `executionBlocked: true` |
| `ProjectMembershipResult` | interface | `success`, `member?`, `error?`, `errorType?`, `executionBlocked: true` |
| `ProjectMembersListResult` | interface | `success`, `projectId`, `members[]`, `count`, `error?`, `errorType?`, `executionBlocked: true` |
| `ProjectRemoveMemberResult` | interface | `success`, `removedActorId?`, `error?`, `errorType?`, `executionBlocked: true` |
| `initProjectMembers()` | function | Load-on-boot from `project-members` store; validates each entry; skips orphaned/malformed |
| `addProjectMember(projectId, rawActorId, rawRole)` | function | Validates → looks up project → checks duplicate → adds → flushes |
| `listProjectMembers(projectId)` | function | Returns members sorted by `addedAt` asc; 404 if project not found |
| `removeProjectMember(projectId, actorId)` | function | Validates → looks up project → checks membership → removes → flushes |
| `getMemberStats()` | function | `{ totalMemberRecords, memberFlushCount, memberLastFlushedAt, memberLoadedOnBoot }` |

**Internal data structure:**

```
membersMap: Map<projectId, Map<actorId, ProjectMember>>
```

- O(1) lookup by projectId + actorId
- Empty inner map removed after last member deleted
- Not exported; accessed only via the exported functions above

**Store file:** `artifacts/api-server/storage/store/project-members.json`

Written as a JSON array of `StoredMember` records, sorted by `projectId` ascending then `addedAt` ascending for stable diffs and deterministic restart-recovery.

**Load-on-boot validation in `initProjectMembers()`:**

```
readStore<unknown[]>("project-members")
  → null → start empty, log error
  → Array → iterate:
      isValidStoredMember(raw) → false → logger.warn + skip
      projectsById.has(raw.projectId) → false → logger.warn + skip (orphaned)
      actorMap.has(raw.actorId) → skip duplicate
      else → actorMap.set(raw.actorId, member); booted++
```

**Validation order for `addProjectMember()`:**

1. `rawActorId` is non-empty string ≤ 128 chars → 400 on failure
2. `rawRole` is in `VALID_MEMBER_ROLES` → 400 on failure
3. `projectsById.has(projectId)` → 404 on failure
4. `actorMap.has(actorId)` → 409 on conflict
5. Create member, add to `membersMap`, `flushProjectMembers()`, emit events → 201

**Other changes:**

| File | Change |
|---|---|
| `core/router.ts` | Added `delete(path, handler)` convenience method to `Router` class |
| `core/accessEnforcement.ts` | `method` union extended: `"GET" \| "POST" \| "PATCH" \| "DELETE"`; 3 new policies (GET/POST/DELETE); metadata "63-route" → "66-route" |
| `server.ts` | Import 3 new handlers; register 3 new routes |
| `core/runtime.ts` | Import + call `initProjectMembers()` after `initProjectRegistry()` |

**HTTP error map for membership endpoints:**

| Endpoint | Condition | Status |
|---|---|---|
| POST members | Body not object | 400 |
| POST members | `actorId` missing/empty/too-long | 400 |
| POST members | `role` not in allowed set | 400 |
| POST members | Project not found | 404 |
| POST members | Actor already a member | 409 |
| GET members | Project not found | 404 |
| DELETE members | `actorId` missing | 400 |
| DELETE members | Project not found | 404 |
| DELETE members | Actor not a member | 404 |

**Count changes:** Endpoints 63→66. Policies 63→66. Health checks remain 37. Subsystems remain 27. Graph nodes remain 27. `BASELINE_LOCK.json` not mutated — intentional drift continues from Phase 75.

**Phase 78 test results (76/76 ALL PASS):**

| Tests | Result |
|---|---|
| T1–T1e: GET members on empty project — 200, members=[], count=0, projectId, executionBlocked | ✅ |
| T2–T2g: POST add member — 201, actorId, role, addedAt, executionBlocked, note | ✅ |
| T3: All 5 member roles accepted (operator, maintainer, observer, auditor) | ✅ |
| T4–T4c: GET after 5 adds — count=5, array length=5, timestamp present | ✅ |
| T5–T5b: Duplicate member → 409 with error body | ✅ |
| T6–T6b: Invalid role → 400, error lists valid roles | ✅ |
| T7–T10: Missing actorId/role, empty actorId, empty body → 400 | ✅ |
| T11–T12: Unknown project GET/POST → 404 | ✅ |
| T13–T13e: DELETE member → 200, removedActorId, projectId, executionBlocked, timestamp | ✅ |
| T14–T14b: After delete count=4, actor gone | ✅ |
| T15–T16: Delete non-member / unknown project → 404 | ✅ |
| T17: Project B has 0 members (project-scoped isolation) | ✅ |
| T18: actorId > 128 chars → 400 | ✅ |
| T19–T20: Persistence flush on add and remove | ✅ |
| T21: Members sorted addedAt ascending in GET response | ✅ |
| T22: No secrets in membership response | ✅ |
| T23–T24: policy count=66, endpoint count=66 | ✅ |
| T25–T26: graph nodes=27 cycles=0, caps 27 subs 0 invalid | ✅ |
| T27–T29: health checks=37, BASELINE_LOCK intact, /api/healthz ok | ✅ |
| T30: forbidden patterns CLEAN | ✅ |
| T31–T34: disk format fields, executionBlocked, sort order, valid roles | ✅ |
| T35: same actorId in different project allowed (project-scoped) | ✅ |
| T36: drift detection still shows intentional endpointCount drift | ✅ |
| T37–T38: store file is valid JSON array; members on archived project accessible | ✅ |
| T39–T39d: 3 membership policies registered with correct methods | ✅ |
| T40: re-add after delete works (201) | ✅ |
| T41–T41b: POST response has note field, member shape correct | ✅ |
| T42: storage has `project-members` key | ✅ |
| T43–T44: DELETE unknown project / members on suspended project | ✅ |
| T45–T46b: roles present in list, disk state correct | ✅ |

**Files changed:** `core/projectRegistry.ts` (membership block appended), `routes/projects.ts` (3 handlers + imports), `core/router.ts` (delete method), `server.ts` (imports + 3 routes), `core/accessEnforcement.ts` (method type + 3 policies + metadata), `core/runtime.ts` (import + initProjectMembers call), `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `ENDPOINTS.md`, `replit.md`, `ARCHITECTURE.md`.

### Phase 77 — Project Status Transitions

Adds a governed `PATCH /api/projects/:id` endpoint that enforces a strict four-transition state machine over the project registry. No new subsystems, no new health checks. One new endpoint (+1), one new access policy (+1). Extends the `Router` class and the `RouteAccessPolicy` type to support `PATCH` as a first-class HTTP method.

**Motivation:** Phase 76 made the registry durable. Phase 77 adds lifecycle control — projects can move through `active`, `archived`, and `suspended` states according to an explicit transition table. Only the four safe transitions are permitted; all others (including self-transitions) are rejected with 409 and leave the record unmutated. This mirrors the pattern established by `taskLifecycle.ts` (Phase 33) — a `TRANSITION_TABLE` Map of Sets, checked before any write.

**Transition table:**

| From | Allowed targets |
|---|---|
| `active` | `archived`, `suspended` |
| `suspended` | `active` |
| `archived` | `active` |

All transitions not listed above are forbidden (returns 409, no mutation, no flush).

**New exported items in `core/projectRegistry.ts`:**

| Item | Type | Detail |
|---|---|---|
| `ProjectTransitionResult` | interface | `success`, `project?`, `previousStatus?`, `error?`, `errorType?`, `executionBlocked: true` |
| `transitionProjectStatus(projectId, rawTarget)` | function | Validates target → looks up project → checks transition → applies + flushes |
| `TRANSITION_TABLE` | `Map<ProjectStatus, ReadonlySet<ProjectStatus>>` | Module-level, never exported |

**Validation order in `transitionProjectStatus()`:**

1. `rawTarget` is a string in `VALID_STATUSES` → 400 `validation` on failure
2. `projectsById.get(projectId)` exists → 404 `not_found` on failure
3. `TRANSITION_TABLE.get(existing.status)?.has(targetStatus)` → 409 `invalid_transition` on failure
4. Spread-update project → `flushProjectRegistry()` → events → return success

**On success:** `{ ...existing, status: targetStatus, updatedAt: new Date().toISOString() }` — all immutable fields (`projectId`, `projectName`, `owner`, `createdAt`, `executionBlocked`) preserved by spread. `flushProjectRegistry()` called. `flushCount` increments. Events emitted on `eventBus` and `runtimeEventBus`.

**On rejection:** No mutation of `projectsById`. No `flushProjectRegistry()` call. `flushCount` does not change. `updatedAt` is not written.

**New handler in `routes/projects.ts`:**

`handleProjectPatch` — extracts `projectId` from last URL segment (identical pattern to `handleProjectById`), reads JSON body, delegates to `transitionProjectStatus()`, maps `errorType` to HTTP status code (400/404/409), returns `{ project, previousStatus, executionBlocked: true, timestamp }`.

**Other changes:**

| File | Change |
|---|---|
| `core/router.ts` | Added `patch(path, handler)` convenience method to `Router` class |
| `core/accessEnforcement.ts` | `RouteAccessPolicy.method` union extended: `"GET" \| "POST" \| "PATCH"`; 1 new policy (`PATCH /api/projects/:id`, write, operator); metadata string updated to "63-route" |
| `server.ts` | Import `handleProjectPatch`; `router.patch("/api/projects/:id", handleProjectPatch)` |

**HTTP status code map for `PATCH /api/projects/:id`:**

| Condition | Status | Body |
|---|---|---|
| Body not a JSON object | 400 | error string |
| `status` missing or not in `{active,archived,suspended}` | 400 | error with valid values |
| Project not found | 404 | error with projectId |
| Transition not in table (incl. self-transition) | 409 | error with current status + allowed targets |
| Success | 200 | `project`, `previousStatus`, `executionBlocked: true`, `timestamp` |

**Count changes:** Endpoints 62→63. Policies 62→63. Health checks remain 37. Subsystems remain 27. Graph nodes remain 27. Capability records remain 27. `BASELINE_LOCK.json` not mutated — intentional drift at `endpointCount` continues from Phase 75.

**Phase 77 test results (46/46 ALL PASS):**

| Tests | Result |
|---|---|
| T1–T7: valid active→archived returns 200, correct shape, previousStatus, status, executionBlocked, updatedAt | ✅ |
| T8–T11: createdAt/projectId/owner/projectName unchanged after transition (immutable) | ✅ |
| T12–T14: archived→active, active→suspended, suspended→active all return 200 with correct state | ✅ |
| T15–T17: archived→suspended (409), suspended→archived (409), self-transition (409) | ✅ |
| T18: unknown project → 404 | ✅ |
| T19: invalid status string → 400 | ✅ |
| T20: missing status field → 400 | ✅ |
| T21: empty body → 400 | ✅ |
| T22–T23: no mutation on rejected transition — status and updatedAt unchanged | ✅ |
| T24: successful transition flushed to disk (store file updated) | ✅ |
| T25: flushCount increments on success | ✅ |
| T26: flushCount unchanged on rejection | ✅ |
| T27–T28: policy count=63, endpoint count=63 | ✅ |
| T29–T30: graph nodes=27 cycles=0, caps 27 subs 0 invalid | ✅ |
| T31: health check count=37 | ✅ |
| T32: BASELINE_LOCK not mutated (phase=43, ep=59) | ✅ |
| T33: /api/healthz ok | ✅ |
| T34: forbidden patterns clean | ✅ |
| T35–T37: no secrets in response, error bodies well-formed, allowed targets in error | ✅ |
| T38: drift detection still shows intentional endpointCount drift | ✅ |
| T39–T40: post-transition status persisted to disk | ✅ |

**Files changed:** `core/projectRegistry.ts` (transition function + interface + table), `routes/projects.ts` (PATCH handler), `core/router.ts` (patch method), `server.ts` (import + route), `core/accessEnforcement.ts` (type + policy + metadata), `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `ENDPOINTS.md`, `replit.md`, `ARCHITECTURE.md`.

### Phase 76 — Project Registry Persistence

Wires atomic JSON persistence into `core/projectRegistry.ts` using the existing `persistentStore` infrastructure. No new files, no new endpoints, no new health checks, no new subsystems. Pure additive change inside a single module.

**Motivation:** Phase 75 established the in-memory project registry. Phase 76 makes it durable — projects survive server restarts, container recycles, and workflow reloads. The persistence pattern mirrors Phase 45 (audit log), 46 (session), and 47 (lifecycle) exactly: atomic file write via `writeStore`, load-on-boot with a type guard, malformed-data guard that skips bad entries without crashing.

**Changes to `core/projectRegistry.ts`:**

| Change | Detail |
|---|---|
| New imports | `readStore`, `writeStore` from `./persistentStore` |
| New constant | `STORE_KEY = "project-registry"` |
| New type guard | `isValidProject(obj: unknown): obj is Project` |
| New internal function | `flushProjectRegistry()` — wraps `writeStore` in try/catch |
| `initProjectRegistry()` | Calls `readStore` before marking operational; runs each entry through `isValidProject`; skips malformed; loads up to `MAX_PROJECTS` |
| `createProject()` | Calls `flushProjectRegistry()` after every successful `projectsById.set(...)` |
| `ProjectRegistryStatus` | New `persistence` sub-object (additive): `storeKey`, `loadedOnBoot`, `flushCount`, `lastFlushedAt` |
| `ProjectRegistryPersistenceInfo` | New exported interface |

**Store file:** `artifacts/api-server/storage/store/project-registry.json`

Written as a JSON array sorted oldest-first (`createdAt` ascending) for stable diffs. The in-memory `listProjects()` API response continues to return newest-first.

**Load-on-boot logic:**

```
readStore<unknown[]>("project-registry")
  → null (file missing / parse failure) → start empty, log error
  → Array → iterate:
      isValidProject(entry) → false → logger.warn + skip
      booted >= MAX_PROJECTS → break
      projectsById.has(entry.projectId) → skip duplicate
      else → projectsById.set(entry.projectId, entry); booted++
loadedOnBoot = booted
```

**`isValidProject()` guard — fields checked:**

| Field | Rule |
|---|---|
| `projectId` | `string`, matches `/^[0-9a-f]{16}$/` |
| `projectName` | `string`, non-empty, ≤100 chars |
| `owner` | `string`, non-empty, ≤64 chars |
| `status` | one of `"active"`, `"archived"`, `"suspended"` |
| `createdAt` | `string`, non-empty |
| `updatedAt` | `string`, non-empty |
| `executionBlocked` | strictly `=== true` |

Any entry failing any check is silently skipped (with `logger.warn`). The server never throws on malformed persisted data.

**Flush safety:** `flushProjectRegistry()` is wrapped in `try/catch`. A disk write failure is logged via `logger.error` but does not throw, does not roll back the in-memory insert, and does not affect the API response. The project is live in memory and will be retried on the next flush.

**Count changes:** None. Endpoints remain 62, health checks 37, subsystems 27, graph nodes 27, capability records 27. `BASELINE_LOCK.json` not mutated.

**Phase 76 test results (30/30 ALL PASS):**

| Tests | Result |
|---|---|
| T1–T4: Post-restart count=7, loadedOnBoot=7, storeKey correct, flushCount=0 at boot | ✅ |
| T5–T9: Both specific projects accessible by ID, status/executionBlocked preserved | ✅ |
| T10–T11: Duplicate protection active for disk-loaded names (exact + case-insensitive) | ✅ |
| T12–T14: New project creation + disk flush + flushCount increment work post-restart | ✅ |
| T15–T16: Malformed-entry guard skips 5 invalid entries in mixed set of 13 | ✅ |
| T17: Validation rules unchanged post-restart | ✅ |
| T18–T22: All infrastructure invariants unchanged (endpoints/subsystems/graph/caps/policies) | ✅ |
| T23–T25: Health checks, BASELINE_LOCK, forbidden patterns all clean | ✅ |
| T26–T30: /api/healthz ok, no secrets, persistence sub-object well-formed | ✅ |

**Files changed:** `core/projectRegistry.ts` (persistence wired in — only modified file), `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `replit.md`, `ARCHITECTURE.md`.

### Phase 75 — Workspace Foundation & Project Registry Layer

First product-layer phase. Introduces a governed, in-memory project registry as the foundation for workspace identity — no persistence, no execution, no AI, no autonomy. Three new endpoints (+3), one new health check (+1), one new subsystem/graph-node/capability-record (+1 each). `BASELINE_LOCK.json` not mutated.

**Motivation:** The infrastructure nucleus (Phases 1–74) provides a solid, fully observable runtime platform. Phase 75 begins the first product-layer construct: a workspace project registry. Projects are the top-level organizational unit; every future pipeline, workflow, or artifact will reference a projectId. Starting with an in-memory-only, bounded, governed registry enforces the phased rollout philosophy — persistence, search, and external integrations are deferred to later phases.

**New module — `core/projectRegistry.ts`:**

```typescript
export type ProjectStatus = "active" | "archived" | "suspended";

export interface Project {
  projectId: string;      // 16-char hex (randomBytes(8))
  projectName: string;    // trimmed, ≤100 chars, case-insensitive unique
  createdAt: string;      // ISO
  updatedAt: string;      // ISO
  owner: string;          // trimmed, ≤64 chars
  status: ProjectStatus;  // defaults to "active"
  executionBlocked: true;
}

export interface ProjectRegistryStatus {
  operational: boolean;
  projectCount: number;
  maxProjects: number;        // 100
  atCapacity: boolean;
  initializedAt: string | null;
  executionBlocked: true;
  recoveryBlocked: true;
}

export interface ProjectCreateResult {
  success: boolean;
  project?: Project;
  error?: string;
  errorType?: "validation" | "conflict" | "capacity";
  executionBlocked: true;
}
```

**Exported functions:** `initProjectRegistry()`, `getProjectRegistryStatus()`, `createProject(input)`, `getProject(projectId)`, `listProjects()`.

**Limits and validation:**

| Rule | Detail |
|---|---|
| Max projects | 100 |
| projectName max | 100 chars |
| owner max | 64 chars |
| Duplicate check | Case-insensitive; O(n) linear scan over at most 100 projects |
| Invalid status | Silently defaults to `"active"` |
| projectId | `randomBytes(8).toString("hex")` — 16 hex chars |
| Projects on restart | Lost (no persistence in Phase 75) |

**HTTP error codes from `POST /api/projects`:**

| Scenario | HTTP status |
|---|---|
| Validation error (missing/invalid field) | 400 |
| Duplicate project name | 409 |
| Registry at capacity | 507 |

**New routes — `routes/projects.ts`:**

| Method | Route | Handler | Description |
|---|---|---|---|
| GET | `/api/projects` | `handleProjectsGet` | List all projects + registry status |
| POST | `/api/projects` | `handleProjectsPost` | Create a project record |
| GET | `/api/projects/:id` | `handleProjectById` | Fetch single project by ID |

Param extraction in `handleProjectById` follows the established pattern: `req.url.split("?")[0].split("/")` last segment + `decodeURIComponent`.

**Subsystem registration:** `project_registry` registered via `registerSubsystemState` with `category: "workspace"` and `dependencies: ["runtime_state_registry"]`. Init order: `initSecretVault()` → `initProjectRegistry()` → `initRuntimeDependencyGraph()` — ensures the node is present in the graph when the graph is built.

**Health check:** `project_registry` — `pass` when operational and not at capacity; `warn` when not yet initialized or at capacity; `fail` on internal error.

**Capability matrix entry:**

| Field | Value |
|---|---|
| subsystemName | project_registry |
| category | workspace |
| read | [] |
| write | [event_bus, timeline, runtime_event_bus] |
| emit | [project_registry:initialized, project_registry:created] |
| subscribe | [] |
| access | [node:crypto] |

`health_monitor` capability record updated: `project_registry` added to its `read` list.

**Access policies (added to `ROUTE_ACCESS_POLICIES`):**

| Method | Path | Permission | Minimum role |
|---|---|---|---|
| GET | /api/projects | read | viewer |
| POST | /api/projects | write | operator |
| GET | /api/projects/:id | read | viewer |

`accessEnforcement.ts` metadata description updated from "58-route policy map" to "62-route policy map".

**Count changes:**

| Metric | Before | After | Delta |
|---|---|---|---|
| Endpoints | 59 | 62 | +3 |
| Health checks | 36 | 37 | +1 |
| Subsystems | 26 | 27 | +1 |
| Graph nodes | 26 | 27 | +1 |
| Capability records | 26 | 27 | +1 |
| BASELINE_LOCK.json | 59/36/26 | **unchanged** | 0 |

The drift detector reports `endpointCount.drifted=true`, `subsystemCount.drifted=true`, `graphNodeCount.drifted=true`. This is intentional — Phase 75 is the first phase to deliberately grow beyond the Phase 43 baseline. `healthCheckCount.drifted` and `cycleCount.drifted` also reflect the change.

**Phase 75 test results (40/40 ALL PASS):**

| Tests | Result |
|---|---|
| T1–T5: GET /api/projects structure and initialization | ✅ |
| T6–T7: Validation — missing required fields | ✅ |
| T8–T13: Valid project creation — all fields correct | ✅ |
| T14–T15: Duplicate protection (case-sensitive and case-insensitive) | ✅ |
| T16–T17: Multiple projects, list shows all | ✅ |
| T18–T19: GET /api/projects/:id — found and not-found | ✅ |
| T20: Invalid status silently defaults to active | ✅ |
| T21–T22: Field length limits enforced | ✅ |
| T23: project_registry check in /api/health/full | ✅ |
| T24: BASELINE_LOCK.json not mutated | ✅ |
| T25–T26: Live endpoint count=62, subsystem count=27 | ✅ |
| T27–T28: Graph nodes=27, 0 cycles | ✅ |
| T29: Capability matrix 27 records, 0 invalid refs | ✅ |
| T30: Policy parity 62/62 | ✅ |
| T31: Health check count=37 | ✅ |
| T32–T33: No secrets leaked, no forbidden patterns | ✅ |
| T34: /api/healthz still ok | ✅ |
| T35: Drift detected on endpointCount (expected) | ✅ |

**Files changed:** `core/projectRegistry.ts` (new), `routes/projects.ts` (new), `server.ts` (import + 3 routes), `core/accessEnforcement.ts` (3 policies + metadata string), `core/healthMonitor.ts` (import + health check), `core/runtimeCapabilityMatrix.ts` (project_registry seed + health_monitor read list), `core/runtime.ts` (import + initProjectRegistry call), `ENDPOINTS.md`, `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `replit.md`, `ARCHITECTURE.md`.

### Phase 74 — Diagnostics Polling Cadence Awareness

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars, no new imports. One file changed in code: `core/diagnostics.ts`. Four files updated in docs: `ENDPOINTS.md`, `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `replit.md`.

**Problem:** Phases 68–73 built a rich in-process observability stack, but operators had no way to know how frequently `GET /api/diagnostics/snapshot` was being polled. A low polling cadence means short-lived status transitions (e.g. a 5-second `degraded` spike) could be silently missed between two polls. Without cadence data, the `statusHistory` ring buffer is difficult to interpret — were the 0 transitions because the system was stable, or because nobody was watching?

**Solution:** Add `pollingCadence: PollingCadence` to `DiagnosticsHealthSummary`. Every successful call to `getDiagnosticsSnapshot()` increments a counter, records the timestamp, computes the interval from the previous call, and pushes it into a bounded ring buffer. avg/min/max are derived on each read.

**New exported interface — `PollingCadence`:**

```typescript
export interface PollingCadence {
  totalPollCount: number;       // monotonic — counts every successful snapshot call
  lastPolledAt: string;         // ISO — when this snapshot was produced
  previousPolledAt: string | null; // ISO — when the prior snapshot was produced (null on first)
  recentIntervalsMs: number[];  // bounded ring buffer of recent inter-poll gaps (max 50)
  avgIntervalMs: number | null; // Math.round(avg) — null until second poll
  minIntervalMs: number | null; // raw minimum — null until second poll
  maxIntervalMs: number | null; // raw maximum — null until second poll
}
```

**Module-level state (all private, never exported):**

| Variable | Type | Initial value | Role |
|---|---|---|---|
| `POLLING_INTERVAL_CAPACITY` | `50` (const) | — | Ring buffer capacity |
| `totalPollCount` | `number` | `0` | Monotonic counter of successful snapshots |
| `lastPolledAt` | `string \| null` | `null` | ISO timestamp of previous call |
| `previousPolledAt` | `string \| null` | `null` | ISO timestamp of the call before last |
| `pollingIntervalBuffer` | `number[]` | `[]` | Oldest-first ring buffer of inter-poll intervals |

**`recordAndGetPollingCadence()` logic:**

```
now = new Date().toISOString()
totalPollCount++

if lastPolledAt !== null:
  intervalMs = Date.now() - new Date(lastPolledAt).getTime()
  previousPolledAt = lastPolledAt
  pollingIntervalBuffer.push(intervalMs)
  if buffer.length > 50: buffer.shift()

lastPolledAt = now

avg = buffer.length > 0 ? Math.round(sum/count) : null
min = buffer.length > 0 ? Math.min(...buffer) : null
max = buffer.length > 0 ? Math.max(...buffer) : null

return { totalPollCount, lastPolledAt: now, previousPolledAt, recentIntervalsMs: [...buffer], avgIntervalMs: avg, minIntervalMs: min, maxIntervalMs: max }
```

**`buildDiagnosticsHealth` return type** narrowed to `Omit<DiagnosticsHealthSummary, "statusHistory" | "currentStatusSince" | "pollingCadence">`. `pollingCadence` merged in `getDiagnosticsSnapshot`:

```typescript
const pollingCadence = recordAndGetPollingCadence();
const diagnosticsHealth: DiagnosticsHealthSummary = {
  ...diagnosticsHealthBase,
  currentStatusSince: currentStatusSince!,
  statusHistory,
  pollingCadence,
};
```

**First-poll state:**
```json
{
  "totalPollCount": 1,
  "lastPolledAt": "2026-05-13T06:33:20.963Z",
  "previousPolledAt": null,
  "recentIntervalsMs": [],
  "avgIntervalMs": null,
  "minIntervalMs": null,
  "maxIntervalMs": null
}
```

**Live example with populated buffer (rapid polling):**
```json
{
  "totalPollCount": 62,
  "lastPolledAt": "2026-05-13T06:36:18.893Z",
  "previousPolledAt": "2026-05-13T06:36:18.859Z",
  "recentIntervalsMs": [13, 11, 10, 11, 12, "...45 more"],
  "avgIntervalMs": 3555,
  "minIntervalMs": 10,
  "maxIntervalMs": 177145
}
```

**Important operational note:** The anonymous/guest rate limit is 60 requests per 60-second window. Test suites that hammer `GET /api/diagnostics/snapshot` will trip this limit and receive HTTP 429 responses — which do not contain `diagnosticsHealth`. The T25 test in the Phase 74 initial run confirmed this scenario: 52 rapid-fire requests in T17 exhausted the window, causing T25 responses to parse as 429 bodies. Confirmed passing in a clean window.

**Phase 74 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | `pollingCadence` field present | ✅ PASS |
| T2 | All `pollingCadence` keys present | ✅ PASS |
| T3 | `totalPollCount=1` on first poll | ✅ PASS |
| T4 | `lastPolledAt` valid ISO string | ✅ PASS |
| T5 | `previousPolledAt=null` on first poll | ✅ PASS |
| T6 | `recentIntervalsMs=[]` on first poll | ✅ PASS |
| T7 | avg/min/max null on first poll | ✅ PASS |
| T8 | `totalPollCount=2` after second poll | ✅ PASS |
| T9 | `previousPolledAt` set after second poll | ✅ PASS |
| T10 | One interval in buffer after second poll | ✅ PASS |
| T11 | Interval is a non-negative number | ✅ PASS |
| T12 | `avgIntervalMs` equals the single interval | ✅ PASS |
| T13 | `min=max=interval` when one entry | ✅ PASS |
| T14 | `totalPollCount=3` after third poll | ✅ PASS |
| T15 | Two intervals in buffer after third poll | ✅ PASS |
| T16 | `avgIntervalMs` is a rounded integer | ✅ PASS |
| T17 | `recentIntervalsMs` capped at 50 after 52+ polls | ✅ PASS |
| T18 | `totalPollCount` continues past cap | ✅ PASS |
| T19 | No secrets in `pollingCadence` | ✅ PASS |
| T20 | All `diagnosticsHealth` keys present (backward compat) | ✅ PASS |
| T21 | All snapshot top-level fields present | ✅ PASS |
| T22 | `BASELINE_LOCK.json` not mutated | ✅ PASS |
| T23 | Runtime snapshot count unchanged | ✅ PASS |
| T24 | Endpoint count = 59 | ✅ PASS |
| T25 | `lastPolledAt` advances across sequential calls | ✅ PASS (confirmed in clean rate-limit window) |

**Files changed:** `core/diagnostics.ts` (`PollingCadence` interface exported; `pollingCadence: PollingCadence` added to `DiagnosticsHealthSummary`; `buildDiagnosticsHealth` Omit extended to exclude `"pollingCadence"`; four module-level state variables added; `recordAndGetPollingCadence()` private function added; `getDiagnosticsSnapshot()` wired to call it and spread result into `diagnosticsHealth`), `ENDPOINTS.md` (updated `GET /api/diagnostics/snapshot` row).

### Phase 73 — Diagnostics Status Duration Tracking

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars, no new imports. One file changed in code: `core/diagnostics.ts`. Four files updated in docs: `ENDPOINTS.md`, `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `replit.md`.

**Problem:** Phase 71 gave operators a `statusHistory` of *what* transitions occurred and *when*, but not *how long* the system spent in each state. An operator looking at a `degraded` status had no way to know whether it had been degraded for 2 seconds or 2 hours. Similarly, there was no way to know when the current status first became active.

**Solution:** Two additive fields:
1. `currentStatusSince: string` on `DiagnosticsHealthSummary` — ISO timestamp of when `overallDiagnosticsStatus` first became active (set on first call, updated on each transition).
2. `durationMs: number` on `StatusTransition` — how many milliseconds `fromStatus` was active before this transition occurred (computed at transition-record time using `currentStatusSince`).

**Updated interfaces:**

```typescript
export interface StatusTransition {
  fromStatus: OverallDiagnosticsStatus;
  toStatus: OverallDiagnosticsStatus;
  detectedAt: string;
  durationMs: number;   // NEW — ms fromStatus was active before this transition
  reasons: string[];
}

export interface DiagnosticsHealthSummary {
  overallDiagnosticsStatus: OverallDiagnosticsStatus;
  checkedAt: string;
  currentStatusSince: string;  // NEW — when current status first became active
  reasons: string[];
  baselineOk: boolean;
  driftOk: boolean;
  snapshotConsistencyOk: boolean;
  statusHistory: StatusTransitionHistory;
}
```

**Module-level state additions:**

| Variable | Type | Initial value | Role |
|---|---|---|---|
| `currentStatusSince` | `string \| null` | `null` | ISO timestamp of when the current status became active |

**Updated `recordAndGetStatusHistory` logic:**

```
now = new Date().toISOString()

if lastKnownStatus === null:
  currentStatusSince = now           // first call — seed, no transition recorded
else if lastKnownStatus !== newStatus:
  durationMs = Date.now() - new Date(currentStatusSince).getTime()
  push { fromStatus, toStatus: newStatus, detectedAt: now, durationMs, reasons: [...reasons] }
  if buffer.length > 50: buffer.shift()
  totalStatusTransitions++
  currentStatusSince = now           // reset for next duration measurement

lastKnownStatus = newStatus
```

**`buildDiagnosticsHealth` return type** narrowed to `Omit<DiagnosticsHealthSummary, "statusHistory" | "currentStatusSince">` — both injected fields are merged by `getDiagnosticsSnapshot` after calling `recordAndGetStatusHistory`:

```typescript
const diagnosticsHealth: DiagnosticsHealthSummary = {
  ...diagnosticsHealthBase,
  currentStatusSince: currentStatusSince!,
  statusHistory,
};
```

**Timestamp semantics:**

| Field | Updates | Meaning |
|---|---|---|
| `checkedAt` | Every call | When this specific snapshot was computed |
| `currentStatusSince` | First call + each transition | When the current `overallDiagnosticsStatus` first became active |
| `StatusTransition.detectedAt` | At each transition | When the new status was first observed |
| `StatusTransition.durationMs` | At each transition | Milliseconds `fromStatus` was active |

**Normal-state `diagnosticsHealth` (with duration tracking active):**
```json
{
  "overallDiagnosticsStatus": "ok",
  "checkedAt": "2026-05-13T06:17:42.710Z",
  "currentStatusSince": "2026-05-13T06:17:42.695Z",
  "reasons": [],
  "baselineOk": true,
  "driftOk": true,
  "snapshotConsistencyOk": true,
  "statusHistory": {
    "capacity": 50,
    "totalTransitions": 0,
    "transitions": []
  }
}
```

**Example `statusHistory` after `ok → degraded → ok` with durations:**
```json
{
  "transitions": [
    {
      "fromStatus": "degraded",
      "toStatus": "ok",
      "detectedAt": "2026-05-13T06:22:10.000Z",
      "durationMs": 47000,
      "reasons": []
    },
    {
      "fromStatus": "ok",
      "toStatus": "degraded",
      "detectedAt": "2026-05-13T06:21:23.000Z",
      "durationMs": 218000,
      "reasons": ["Baseline drift detected in one or more fields"]
    }
  ]
}
```

**Phase 73 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | `currentStatusSince` field present | ✅ PASS |
| T2 | `currentStatusSince` is valid ISO timestamp | ✅ PASS |
| T3 | `currentStatusSince` is recent (<10s of boot) | ✅ PASS |
| T4 | `statusHistory` shape intact (Phase 71 not broken) | ✅ PASS |
| T5 | `transitions=[]` in stable state | ✅ PASS |
| T6 | Six identical-status calls — no new entries | ✅ PASS |
| T7 | `currentStatusSince` unchanged across stable calls | ✅ PASS |
| T8 | All `diagnosticsHealth` keys present (backward compat) | ✅ PASS |
| T9 | No spurious entries in stable state | ✅ PASS |
| T10 | All snapshot top-level fields present | ✅ PASS |
| T11 | `BASELINE_LOCK.json` not mutated | ✅ PASS |
| T12 | Runtime snapshot count unchanged | ✅ PASS |
| T13 | Endpoint count = 59 | ✅ PASS |
| T14 | No secrets in `diagnosticsHealth` | ✅ PASS |
| T15 | `executionBlocked=true` && `recoveryBlocked=true` | ✅ PASS |
| T16 | `driftReport` well-formed (Phase 68 intact) | ✅ PASS |
| T17 | `snapshotConsistency` well-formed (Phase 69 intact) | ✅ PASS |
| T18 | `StatusTransition` interface contains `durationMs` | ✅ PASS |
| T19 | `DiagnosticsHealthSummary` interface contains `currentStatusSince` | ✅ PASS |
| T20 | `checkedAt` advances each call; `currentStatusSince` stays fixed | ✅ PASS |

**Files changed:** `core/diagnostics.ts` (`durationMs: number` added to `StatusTransition`; `currentStatusSince: string` added to `DiagnosticsHealthSummary`; `buildDiagnosticsHealth` return type narrowed to `Omit<…, "statusHistory" | "currentStatusSince">`; `let currentStatusSince: string | null = null` added; `recordAndGetStatusHistory` rewritten to compute `durationMs` and maintain `currentStatusSince`; `getDiagnosticsSnapshot` spreads `currentStatusSince: currentStatusSince!` into `diagnosticsHealth`), `ENDPOINTS.md` (updated `GET /api/diagnostics/snapshot` row).

### Phase 71 — Diagnostics Observation History & Change-Detection Ledger

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars, no new imports. One file changed in code: `core/diagnostics.ts`. Four files updated in docs: `ENDPOINTS.md`, `GOTCHAS.md`, `NUCLEUS_LOCK.md`, `replit.md`.

**Problem:** Phase 70 gave operators a real-time `overallDiagnosticsStatus` but no record of when it last changed. If a server went `ok → degraded → ok` between two polls, the transition was invisible. Operators had no way to determine how long the system had been in its current state or how many status changes had occurred since boot.

**Solution:** Add a `statusHistory: StatusTransitionHistory` field to `DiagnosticsHealthSummary`. A module-level ring buffer (max 50 entries) records every `overallDiagnosticsStatus` change since boot. Each entry captures `fromStatus`, `toStatus`, `detectedAt`, and a copy of the `reasons[]` active at the moment of transition. No new endpoints, no persistence, no baseline changes.

**New exported interfaces — `StatusTransition` and `StatusTransitionHistory`:**

```typescript
export interface StatusTransition {
  fromStatus: OverallDiagnosticsStatus;
  toStatus: OverallDiagnosticsStatus;
  detectedAt: string;   // ISO timestamp when the change was first detected
  reasons: string[];    // snapshot copy of reasons[] for the new toStatus
}

export interface StatusTransitionHistory {
  capacity: number;         // always 50
  totalTransitions: number; // monotonic counter — increments even after eviction
  transitions: StatusTransition[]; // newest-first; bounded to capacity entries
}
```

**Module-level state (all private, never exported):**

| Variable | Type | Initial value | Role |
|---|---|---|---|
| `lastKnownStatus` | `OverallDiagnosticsStatus \| null` | `null` | Tracks the status from the previous call |
| `totalStatusTransitions` | `number` | `0` | Monotonic count of all transitions ever recorded |
| `statusTransitionBuffer` | `StatusTransition[]` | `[]` | Oldest-first ring buffer, max 50 entries |

**`recordAndGetStatusHistory(newStatus, reasons)` logic:**

```
if lastKnownStatus !== null AND lastKnownStatus !== newStatus:
  push { fromStatus: lastKnownStatus, toStatus: newStatus, detectedAt: now, reasons: [...reasons] }
  if buffer.length > 50: buffer.shift()   // evict oldest
  totalStatusTransitions++
lastKnownStatus = newStatus
return { capacity: 50, totalTransitions, transitions: [...buffer].reverse() }
```

**First-call behaviour:** `lastKnownStatus` starts as `null`. The condition `lastKnownStatus !== null` is false, so no transition is recorded. `lastKnownStatus` is set to the first observed status. `totalTransitions=0`, `transitions=[]`.

**No-change behaviour:** Repeated calls with the same status leave `totalTransitions` and `transitions` unchanged. The buffer never grows when status is stable.

**Integration point in `getDiagnosticsSnapshot()`:**

```
diagnosticsHealthBase = buildDiagnosticsHealth(...)   // pure, returns Omit<..., "statusHistory">
statusHistory = recordAndGetStatusHistory(base.overallDiagnosticsStatus, base.reasons)
diagnosticsHealth = { ...diagnosticsHealthBase, statusHistory }
```

`buildDiagnosticsHealth` return type changed to `Omit<DiagnosticsHealthSummary, "statusHistory">` to enforce the separation between pure aggregation and stateful history recording.

**Normal-state `statusHistory` (fresh server):**
```json
{
  "capacity": 50,
  "totalTransitions": 0,
  "transitions": []
}
```

**Example `statusHistory` after one transition (ok → degraded → ok):**
```json
{
  "capacity": 50,
  "totalTransitions": 2,
  "transitions": [
    { "fromStatus": "degraded", "toStatus": "ok", "detectedAt": "...", "reasons": [] },
    { "fromStatus": "ok", "toStatus": "degraded", "detectedAt": "...", "reasons": ["Baseline drift detected in one or more fields"] }
  ]
}
```

**Phase 71 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | `statusHistory` field present in `diagnosticsHealth` | ✅ PASS |
| T2 | `statusHistory.capacity=50` | ✅ PASS |
| T3 | `totalTransitions=0` on fresh server | ✅ PASS |
| T4 | `transitions=[]` on first call | ✅ PASS |
| T5 | `overallDiagnosticsStatus=ok` still present (Phase 70 intact) | ✅ PASS |
| T6 | Second call same status — `totalTransitions` still 0 | ✅ PASS |
| T7 | Second call same status — `transitions` still empty | ✅ PASS |
| T8 | Third call — no flapping — `transitions=[]` | ✅ PASS |
| T9 | `transitions` is an array | ✅ PASS |
| T10 | All `diagnosticsHealth` fields present (backward compat) | ✅ PASS |
| T11 | All diagnostics snapshot fields present (backward compat) | ✅ PASS |
| T12 | `BASELINE_LOCK.json` not mutated | ✅ PASS |
| T13 | Runtime snapshot count unchanged after diagnostics calls | ✅ PASS |
| T14 | Endpoint count = 59 | ✅ PASS |
| T15 | No secret values in `statusHistory` | ✅ PASS |
| T16 | `statusHistory` has `capacity`/`totalTransitions`/`transitions` keys | ✅ PASS |
| T17 | `capacity` is a number | ✅ PASS |
| T18 | `totalTransitions` is a non-negative integer | ✅ PASS |
| T19 | `driftReport` still well-formed (Phase 68 not broken) | ✅ PASS |
| T20 | `snapshotConsistency` still well-formed (Phase 69 not broken) | ✅ PASS |

**Files changed:** `core/diagnostics.ts` (`StatusTransition`/`StatusTransitionHistory` interfaces exported; `statusHistory: StatusTransitionHistory` added to `DiagnosticsHealthSummary`; `buildDiagnosticsHealth` return type narrowed to `Omit<DiagnosticsHealthSummary, "statusHistory">`; three module-level state variables added; `recordAndGetStatusHistory()` private function added; `getDiagnosticsSnapshot()` wired to call `recordAndGetStatusHistory` and spread result into `diagnosticsHealth`).

### Phase 70 — Diagnostics Health Aggregation

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars, no new imports. One file changed in code: `core/diagnostics.ts`. Two files updated in docs: `ENDPOINTS.md`, `GOTCHAS.md`.

**Problem:** Phases 68 and 69 added `driftReport` and `snapshotConsistency` to the diagnostics snapshot. Operators now had three independent observability layers to poll (`baseline.allFieldsMatch`, `driftReport.driftDetected`, `snapshotConsistency.consistent`) with no unified roll-up. A monitoring script had to combine all three to decide whether the system was healthy.

**Solution:** Add a `diagnosticsHealth: DiagnosticsHealthSummary` field that aggregates the three conditions into a single `overallDiagnosticsStatus` enum (`ok` / `warning` / `degraded`) with a human-readable `reasons[]` array and three boolean flags. No new data is fetched — `buildDiagnosticsHealth()` receives the already-computed `diagBaseline`, `driftReport`, and `snapshotConsistency` as parameters.

**New exported types — `OverallDiagnosticsStatus` and `DiagnosticsHealthSummary`:**

```typescript
export type OverallDiagnosticsStatus = "ok" | "warning" | "degraded";

export interface DiagnosticsHealthSummary {
  overallDiagnosticsStatus: OverallDiagnosticsStatus;
  checkedAt: string;           // ISO timestamp of this aggregation
  reasons: string[];           // empty in ok state; one entry per failing condition
  baselineOk: boolean;         // true when baseline.allFieldsMatch
  driftOk: boolean;            // true when !driftReport.driftDetected
  snapshotConsistencyOk: boolean; // true when snapshotConsistency.consistent
}
```

**Status precedence (strict, ordered):**

| Priority | Condition | Status |
|---|---|---|
| 1 (highest) | `!baselineOk` OR `!driftOk` | `degraded` |
| 2 | `!snapshotConsistencyOk` (baseline intact, no drift) | `warning` |
| 3 (default) | all three ok | `ok` |

**`reasons[]` population order (fixed):**
1. `"Baseline field mismatch detected"` — when `!allFieldsMatch`
2. `"Baseline drift detected in one or more fields"` — when `driftDetected`
3. `"Live state inconsistent with latest runtime snapshot"` — when `!snapshotConsistency.consistent`

**`buildDiagnosticsHealth()` logic:**

```
baselineOk = diagBaseline.allFieldsMatch
driftOk = !driftReport.driftDetected
snapshotConsistencyOk = snapshotConsistency.consistent

reasons = []
if !baselineOk → reasons.push("Baseline field mismatch detected")
if !driftOk    → reasons.push("Baseline drift detected in one or more fields")
if !snapshotConsistencyOk → reasons.push("Live state inconsistent with latest runtime snapshot")

if !baselineOk || !driftOk → overallDiagnosticsStatus = "degraded"
else if !snapshotConsistencyOk → overallDiagnosticsStatus = "warning"
else → overallDiagnosticsStatus = "ok"
```

**Data flow:** `getDiagnosticsSnapshot()` → `buildDriftReport(diagBaseline)` → `buildSnapshotConsistency(...)` → `buildDiagnosticsHealth(diagBaseline, driftReport, snapshotConsistency)` → `diagnosticsHealth` field in response. No I/O inside `buildDiagnosticsHealth()`. No module-level state.

**Normal-state `diagnosticsHealth`:**
```json
{
  "overallDiagnosticsStatus": "ok",
  "checkedAt": "2026-05-13T03:24:52.021Z",
  "reasons": [],
  "baselineOk": true,
  "driftOk": true,
  "snapshotConsistencyOk": true
}
```

**Phase 70 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | `diagnosticsHealth` field present | ✅ PASS |
| T2 | `overallDiagnosticsStatus` is one of ok/warning/degraded | ✅ PASS |
| T3 | `overallDiagnosticsStatus=ok` in normal state | ✅ PASS |
| T4 | `reasons` is empty array in normal state | ✅ PASS |
| T5 | `baselineOk=true` | ✅ PASS |
| T6 | `driftOk=true` | ✅ PASS |
| T7 | `snapshotConsistencyOk=true` | ✅ PASS |
| T8 | `checkedAt` is valid ISO timestamp | ✅ PASS |
| T9 | `checkedAt` is recent (<5s) | ✅ PASS |
| T10 | `overallDiagnosticsStatus` consistent with all three boolean flags | ✅ PASS |
| T11 | All prior diagnostics fields present (backward compat) | ✅ PASS |
| T12 | `driftReport` still well-formed (Phase 68 not broken) | ✅ PASS |
| T13 | `snapshotConsistency` still well-formed (Phase 69 not broken) | ✅ PASS |
| T14 | `baselineOk` matches `baseline.allFieldsMatch` | ✅ PASS |
| T15 | `driftOk` is inverse of `driftReport.driftDetected` | ✅ PASS |
| T16 | `snapshotConsistencyOk` matches `snapshotConsistency.consistent` | ✅ PASS |
| T17 | `BASELINE_LOCK.json` not mutated | ✅ PASS |
| T18 | No secret values in `diagnosticsHealth` | ✅ PASS |
| T19 | Endpoint count = 59 | ✅ PASS |
| T20 | Multiple calls — `overallDiagnosticsStatus` stays `ok` (not flapping) | ✅ PASS |

**Files changed:** `core/diagnostics.ts` (`OverallDiagnosticsStatus` type exported; `DiagnosticsHealthSummary` interface exported; private `buildDiagnosticsHealth()` function added; `diagnosticsHealth` field added to `DiagnosticsSnapshot` interface and return object), `ENDPOINTS.md` (updated `GET /api/diagnostics/snapshot` row).

### Phase 69 — Runtime Snapshot Drift Correlation & Diagnostics Consistency Validation

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars. One file changed in code: `core/diagnostics.ts`. Two files updated in docs: `ENDPOINTS.md`, `GOTCHAS.md`.

**Problem:** After Phase 68 introduced `driftReport` to surface baseline drift, operators still had no way to tell whether the live system's state was consistent with the system as it existed at the time of the last persisted runtime snapshot. A runtime snapshot captures `endpointCount` and `healthCheckCount` at creation time; if these values change between snapshots, there is no mechanism to detect the divergence from the diagnostics endpoint.

**Solution:** Extend `getDiagnosticsSnapshot()` with a `snapshotConsistency: SnapshotConsistency` field. The field is built by the new private `buildSnapshotConsistency(liveEndpoints, liveHealthChecks)` function, which calls `listRuntimeSnapshots()`, finds the newest snapshot by `createdAt`, and compares `endpointCount` and `healthCheckCount` against the current live values. `subsystemCount` and `graphNodeCount` are not stored in snapshot metadata — they are surfaced in `untrackedFields[]` so operators know those dimensions cannot be compared. No snapshot files are mutated. No baseline files are mutated. No new routes.

**New exported types — `SnapshotConsistencyMismatch` and `SnapshotConsistency`:**

```typescript
export interface SnapshotConsistencyMismatch {
  field: string;       // e.g. "endpointCount"
  liveValue: number;   // current live value from diagnostics
  snapshotValue: number; // value recorded in latest snapshot
}

export interface SnapshotConsistency {
  consistencyCheckedAt: string;           // ISO timestamp of this check
  snapshotCountCompared: number;          // 0 if no snapshots, 1 if latest compared
  consistent: boolean;                    // true if all compared fields match
  mismatchFields: SnapshotConsistencyMismatch[]; // non-empty when drift detected
  comparedFields: string[];               // fields actually compared (["endpointCount","healthCheckCount"] when snapshot exists, [] when none)
  untrackedFields: string[];              // fields not in snapshot metadata (["subsystemCount","graphNodeCount"])
  latestSnapshotId: string | null;        // null if no snapshots
  latestSnapshotCreatedAt: string | null; // null if no snapshots
}
```

**`buildSnapshotConsistency()` logic:**

```
snapshotList = listRuntimeSnapshots()
all = active + archived
if all is empty:
  return consistent=true, count=0, mismatchFields=[], comparedFields=[], latestId=null
sorted = all.sort(by createdAt desc)
latest = sorted[0]
mismatchFields = []
if latest.endpointCount !== liveEndpoints:
  push { field: "endpointCount", liveValue, snapshotValue }
if latest.healthCheckCount !== liveHealthChecks:
  push { field: "healthCheckCount", liveValue, snapshotValue }
return consistent=(mismatchFields.length===0), count=1, comparedFields=["endpointCount","healthCheckCount"],
       untrackedFields=["subsystemCount","graphNodeCount"], latestSnapshotId, latestSnapshotCreatedAt
```

**Data flow:** `POST /api/runtime/snapshots/create → createRuntimeSnapshot() → write endpointCount/healthCheckCount to disk`. Then: `GET /api/diagnostics/snapshot → getDiagnosticsSnapshot() → buildSnapshotConsistency(liveEndpoints, liveHealthChecks) → listRuntimeSnapshots() → readFileSync per summary → compare → snapshotConsistency field`. No file is written or mutated on the read path.

**Import added:** `import { listRuntimeSnapshots } from "./runtimeSnapshot"` in `core/diagnostics.ts`. No circular dependency — `runtimeSnapshot.ts` does not import from `diagnostics.ts`.

**Normal-state `snapshotConsistency` (with at least one snapshot, all counts matching):**
```json
{
  "consistencyCheckedAt": "2026-05-13T03:14:56.673Z",
  "snapshotCountCompared": 1,
  "consistent": true,
  "mismatchFields": [],
  "comparedFields": ["endpointCount", "healthCheckCount"],
  "untrackedFields": ["subsystemCount", "graphNodeCount"],
  "latestSnapshotId": "a18680b183ca2e2b",
  "latestSnapshotCreatedAt": "2026-05-13T03:14:56.663Z"
}
```

**Phase 69 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | `snapshotConsistency` field present in diagnostics snapshot | ✅ PASS |
| T2 | `consistencyCheckedAt` is valid ISO timestamp | ✅ PASS |
| T3 | `consistent` is boolean | ✅ PASS |
| T4 | `mismatchFields` is array | ✅ PASS |
| T5 | `snapshotCountCompared` is number ≥ 0 | ✅ PASS |
| T6 | With snapshots: count=1, latestSnapshotId set, latestSnapshotCreatedAt valid ISO | ✅ PASS |
| T7 | `consistent=true` in normal matching state | ✅ PASS |
| T8 | `mismatchFields` empty in matching state | ✅ PASS |
| T9 | `comparedFields` is array of strings | ✅ PASS |
| T10 | `untrackedFields` contains `subsystemCount` and `graphNodeCount` | ✅ PASS |
| T11 | All existing diagnostics fields present (backward compat, including `driftReport`) | ✅ PASS |
| T12 | `driftReport` still well-formed (Phase 68 not broken) | ✅ PASS |
| T13 | After snapshot creation: count=1, latestSnapshotId non-null and matches created snapshot | ✅ PASS |
| T14 | After snapshot creation: `consistent=true`, `mismatchFields=[]` | ✅ PASS |
| T15 | `latestSnapshotCreatedAt` is valid ISO timestamp | ✅ PASS |
| T16 | `BASELINE_LOCK.json` not mutated (phase=43, executionBlocked=true) | ✅ PASS |
| T17 | No secret values in `snapshotConsistency` | ✅ PASS |
| T18 | Endpoint count = 59 | ✅ PASS |
| T19 | `consistencyCheckedAt` is recent (<5s from call) | ✅ PASS |
| T20 | `comparedFields` contains `endpointCount` and `healthCheckCount` | ✅ PASS |

**Files changed:** `core/diagnostics.ts` (new import `listRuntimeSnapshots`; new `SnapshotConsistencyMismatch` and `SnapshotConsistency` interfaces exported; `SNAPSHOT_COMPARED_FIELDS` and `SNAPSHOT_UNTRACKED_FIELDS` `as const` arrays; private `buildSnapshotConsistency()` function; `snapshotConsistency` field added to `DiagnosticsSnapshot` interface and return object), `ENDPOINTS.md` (updated `GET /api/diagnostics/snapshot` row).

### Phase 68 — Diagnostics Snapshot Baseline Drift Detection

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars. One file changed in code: `core/diagnostics.ts`. One file updated in docs: `ENDPOINTS.md`.

**Problem:** `GET /api/diagnostics/snapshot` already surfaced a `baseline` field (via `getBaselineStatus()`) that compared live runtime counts against the frozen baseline. Operators wanting to know whether anything had drifted had to manually inspect six subfields (`endpointCount.match`, `healthCheckCount.match`, etc.) and cross-reference against the phase-43 expected values. There was no single `driftDetected` boolean, no timestamp for when drift was first seen, and no clean per-field report.

**Solution:** Extend `getDiagnosticsSnapshot()` with a `driftReport: DriftReport` field. The report is built by the new private `buildDriftReport(baseline: DiagnosticsBaseline)` function, which iterates over the 6 baseline dimensions and computes per-field drift status. An in-memory `Map<string, string>` (`driftFirstDetected`) tracks when each field first drifted, with entries cleared automatically when drift resolves. No new routes, no new subsystems, no baseline file writes.

**New exported types — `DriftField` and `DriftReport`:**

```typescript
export interface DriftField {
  name: string;             // field name (e.g. "endpointCount")
  expected: number;         // frozen baseline value from BASELINE_LOCK.json
  actual: number;           // current live value
  drifted: boolean;         // true if actual !== expected
  firstDetectedAt: string | null;  // ISO timestamp when drift was first seen; null if not drifted
}

export interface DriftReport {
  driftDetected: boolean;   // true if any field is drifted
  checkedAt: string;        // ISO timestamp of this drift check
  fields: DriftField[];     // one entry per tracked dimension (6 total)
}
```

**Tracked dimensions (order preserved in `fields[]`):**

| Index | Name | Expected (Phase 43 baseline) |
|---|---|---|
| 0 | `endpointCount` | 59 |
| 1 | `healthCheckCount` | 36 |
| 2 | `subsystemCount` | 26 |
| 3 | `graphNodeCount` | 26 |
| 4 | `cycleCount` | 0 |
| 5 | `invalidReferenceCount` | 0 |

**`buildDriftReport()` logic:**

```
for each field name in DRIFT_FIELD_NAMES:
  drifted = !baseline[name].match
  if drifted and not in driftFirstDetected map:
    set driftFirstDetected[name] = now
  if not drifted and in driftFirstDetected map:
    delete driftFirstDetected[name]
  push { name, expected: baseline[name].baseline, actual: baseline[name].live,
          drifted, firstDetectedAt: driftFirstDetected[name] ?? null }
return { driftDetected: any field drifted, checkedAt: now, fields }
```

**Data flow:** `BASELINE_LOCK.json` → `baseline.ts:loadLock()` → `getBaselineStatus()` → `getDiagnosticsSnapshot():baseline` → `diagBaseline: DiagnosticsBaseline` → `buildDriftReport(diagBaseline)` → `driftReport` field in response. `buildDriftReport()` never accesses `BASELINE_LOCK.json` directly or calls any file I/O.

**`diagBaseline` refactoring:** Pre-Phase 68, the `DiagnosticsBaseline` object was built inline inside the return statement. Phase 68 extracts it into a named `diagBaseline` local variable so it can be passed to `buildDriftReport()` before the return. The behavior is identical — this is a pure refactor of the construction site, not a logic change.

**Normal-state `driftReport` (baseline intact):**
```json
{
  "driftDetected": false,
  "checkedAt": "2026-05-13T02:59:46.430Z",
  "fields": [
    { "name": "endpointCount",         "expected": 59, "actual": 59, "drifted": false, "firstDetectedAt": null },
    { "name": "healthCheckCount",      "expected": 36, "actual": 36, "drifted": false, "firstDetectedAt": null },
    { "name": "subsystemCount",        "expected": 26, "actual": 26, "drifted": false, "firstDetectedAt": null },
    { "name": "graphNodeCount",        "expected": 26, "actual": 26, "drifted": false, "firstDetectedAt": null },
    { "name": "cycleCount",            "expected": 0,  "actual": 0,  "drifted": false, "firstDetectedAt": null },
    { "name": "invalidReferenceCount", "expected": 0,  "actual": 0,  "drifted": false, "firstDetectedAt": null }
  ]
}
```

**Phase 68 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | `driftReport` field present in diagnostics snapshot | ✅ PASS |
| T2 | `driftDetected` is boolean | ✅ PASS |
| T3 | `driftDetected === false` in normal baseline-matching state | ✅ PASS |
| T4 | `checkedAt` is valid ISO timestamp | ✅ PASS |
| T5 | `fields` array has exactly 6 entries | ✅ PASS |
| T6 | All 6 required field names present | ✅ PASS |
| T7 | Each field has `name`/`expected`/`actual`/`drifted`/`firstDetectedAt` | ✅ PASS |
| T8 | All fields `drifted=false` and `firstDetectedAt=null` in normal state | ✅ PASS |
| T9 | `expected` values match `BASELINE_LOCK.json` (59/36/26/26/0/0) | ✅ PASS |
| T10 | `actual` values are live values (endpoints=59, healthChecks=36) | ✅ PASS |
| T11 | All existing diagnostics fields still present (backward compat) | ✅ PASS |
| T12 | `baseline.allFieldsMatch=true` consistent with `driftDetected=false` | ✅ PASS |
| T13 | `BASELINE_LOCK.json` not mutated (phase=43, executionBlocked=true) | ✅ PASS |
| T14 | Multiple calls — `driftDetected` stays false (not flapping) | ✅ PASS |
| T15 | No actual secret values in `driftReport` | ✅ PASS |
| T16 | Endpoint count = 59 | ✅ PASS |
| T17 | `driftReport.checkedAt` and `snapshot.timestamp` both recent (<5s) | ✅ PASS |

**Files changed:** `core/diagnostics.ts` (new `DriftField` and `DriftReport` interfaces exported; `driftFirstDetected: Map<string,string>` module-level; `DRIFT_FIELD_NAMES as const`; private `buildDriftReport()` function; `diagBaseline` local variable extracted; `driftReport` added to return object; `DiagnosticsSnapshot` interface updated with `driftReport: DriftReport`), `ENDPOINTS.md` (updated `GET /api/diagnostics/snapshot` row).

### Phase 67 — Runtime Snapshot Search & Filtering

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars. Two files changed in code: `core/runtimeSnapshot.ts` and `routes/runtimeSnapshots.ts`. One file updated in docs: `ENDPOINTS.md`.

**Problem:** `GET /api/runtime/snapshots` returned all active (up to 50) and all archived snapshots with no filtering. With 160+ snapshots on disk across active and archived directories, finding snapshots by their creation trigger, health state, or storage tier required full client-side iteration over the `active` + `archived` arrays.

**Solution:** Extend the existing `GET /api/runtime/snapshots` route with four optional query-string filters (`status`, `triggeredBy`, `snapshotType`, `subsystem`) and a `limit` parameter (default 50, max 100). All filtering is in-memory inside `getFilteredSnapshots()` in the core module, which calls the existing `listRuntimeSnapshots()` internally.

**New exported types — `SnapshotFilter` and `SnapshotFilterResult`:**

```typescript
export interface SnapshotFilter {
  status?: string;       // exact match on RuntimeSnapshotSummary.status ("active" | "archived")
  triggeredBy?: string;  // exact match on RuntimeSnapshotSummary.reason
  snapshotType?: string; // exact match on RuntimeSnapshotSummary.reason (reason encodes type)
  subsystem?: string;    // exact match on RuntimeSnapshotSummary.reason (reason encodes triggering subsystem)
  limit?: number;        // max 100 (MAX_QUERY_LIMIT); default 50 (DEFAULT_QUERY_LIMIT)
}

export interface SnapshotFilterResult {
  active: RuntimeSnapshotSummary[];
  archived: RuntimeSnapshotSummary[];
  totalActive: number;         // unfiltered count from disk
  totalArchived: number;       // unfiltered count from disk
  filteredCount: number;       // total matching before limit
  total: number;               // unfiltered total (active + archived)
  limit: number;               // effective limit applied
  filtersApplied: Record<string, string>;
  maxActiveSnapshots: number;
  executionBlocked: true;
  timestamp: string;
}
```

**Why `triggeredBy`, `snapshotType`, and `subsystem` all map to `reason`:**

`RuntimeSnapshotSummary.reason` is the single field that encodes what triggered a snapshot at creation time (e.g. `"manual"`, `"watchdog"`, `"boot-check"`, `"taskQueue"`). It serves three roles:
- **triggeredBy**: the event/cause that triggered this snapshot
- **snapshotType**: the classification of the snapshot (manual vs automated vs subsystem-triggered)
- **subsystem**: which subsystem caused the snapshot to be created

Operators can use whichever param name is most semantically meaningful for their use case. All three perform the same exact string match against `reason`. Combining two with different values returns 0 results (impossible intersection) — correct and safe.

**Filter application order** (each narrows the combined active+archived working set):
1. `status` — exact match on `summary.status`
2. `triggeredBy` — exact match on `summary.reason`
3. `snapshotType` — exact match on `summary.reason`
4. `subsystem` — exact match on `summary.reason`

After filtering, `filteredCount` is recorded. Then candidates are sorted newest-first (`createdAt` descending), `slice(0, limit)` is applied, and the limited set is re-split into `active` and `archived` arrays.

**`totalActive` / `totalArchived` semantics:** These always reflect the unfiltered counts from `listRuntimeSnapshots()` — the number of snapshot files on disk. This preserves backward compatibility with callers that used these fields to understand total disk usage. `filteredCount` is the new field for "how many matched the filter."

**Phase 67 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | No filters — `filtersApplied: {}`, `filteredCount`, `limit`, all new fields present | ✅ PASS |
| T2 | `?status=active` — active.length=50, archived.length=0, all active | ✅ PASS |
| T3 | `?status=archived` — active.length=0, archived filtered correctly | ✅ PASS |
| T4 | `?triggeredBy=manual` — matched=3, all reason==="manual" | ✅ PASS |
| T5 | `?triggeredBy=watchdog` — matched=1, all reason==="watchdog" | ✅ PASS |
| T6 | `?snapshotType=manual` — matched=3, all reason==="manual" | ✅ PASS |
| T7 | `?subsystem=watchdog` — matched=1, all reason==="watchdog" | ✅ PASS |
| T8 | `?status=active&triggeredBy=manual` — combined, all match, archived.length=0 | ✅ PASS |
| T9 | `?triggeredBy=manual&snapshotType=manual` — same field same value, matched=3 | ✅ PASS |
| T10 | `?triggeredBy=manual&subsystem=watchdog` — impossible combination, 0 results, no crash | ✅ PASS |
| T11 | `?limit=2` — exactly 2 returned (active+archived combined) | ✅ PASS |
| T12 | `?limit=9999` — capped to 100 | ✅ PASS |
| T13 | Unknown params silently ignored, `filtersApplied: {}` | ✅ PASS |
| T14 | Malformed `%GG` — triggeredBy skipped, `status=active` applied | ✅ PASS |
| T15 | Empty `triggeredBy=` ignored, `status=active` applied | ✅ PASS |
| T16 | `?triggeredBy=nonexistent-trigger` — 0 results, no crash | ✅ PASS |
| T17 | `?status=pending` — 0 results, no crash | ✅ PASS |
| T18 | `?triggeredBy=manual&limit=1` — `filteredCount=3`, returned=1 (truncation visible) | ✅ PASS |
| T19 | Combined active+archived result set sorted newest-first | ✅ PASS |
| T20 | No actual secret values in response | ✅ PASS |
| T21 | `GET /api/runtime/snapshots/:id` unchanged | ✅ PASS |
| T22 | Endpoint count = 59 | ✅ PASS |

**Files changed:** `core/runtimeSnapshot.ts` (new `SnapshotFilter` and `SnapshotFilterResult` interfaces; `MAX_QUERY_LIMIT = 100`; `DEFAULT_QUERY_LIMIT = 50`; `getFilteredSnapshots()` exported; all existing exports including `listRuntimeSnapshots()` preserved unchanged), `routes/runtimeSnapshots.ts` (new `MAX_LIMIT=100`; `DEFAULT_LIMIT=50`; `decodeParam()` helper; `URLSearchParams`-based switch parser for all 5 params; `handleRuntimeSnapshotsList` changed from `_req` to `req`, now calls `getFilteredSnapshots(filter)`; `handleRuntimeSnapshotById`, `handleRuntimeSnapshotsCreate`, `handleRuntimeRecoveryDryRun` unchanged), `ENDPOINTS.md` (updated `GET /api/runtime/snapshots` row).

### Phase 66 — Runtime Event Bus Search & Filtering

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars. Two files changed in code: `core/runtimeEventBus.ts` and `routes/runtimeEvents.ts`. One file updated in docs: `ENDPOINTS.md`.

**Problem:** `GET /api/runtime/events/recent` returned the most-recent N events from the 1000-entry ring buffer with no filtering. The runtime event bus is the highest-volume buffer in the system — every subsystem lifecycle emits here — making it the most valuable target for filtering. Locating events from a specific source, of a specific severity, or correlated to a specific request required fetching the full buffer client-side.

**Solution:** Extend the existing `GET /api/runtime/events/recent` route to support five optional query-string filters (`eventType`, `source`, `severity`, `category`, `correlationId`) and lower the `limit` cap to 100 (from the previous 200). All filtering is in-memory inside `getFilteredRuntimeEvents()` in the core module.

**New exported types — `RuntimeEventFilter` and `RuntimeEventFilterResult`:**

```typescript
export interface RuntimeEventFilter {
  eventType?: string;      // exact match; eventType uses dot notation (e.g. runtime.ready)
  source?: string;         // exact match (e.g. "runtime-event-bus", "runtime")
  severity?: string;       // exact match; EventSeverity: "info" | "warning" | "critical"
  category?: string;       // exact match; EventCategory: 9 known values
  correlationId?: string;  // exact match; only non-null string values ever matched
  limit?: number;          // max 100 (MAX_QUERY_LIMIT); default 50
}

export interface RuntimeEventFilterResult {
  events: RuntimeEvent[];
  count: number;
  limit: number;
  filteredCount: number;
  filtersApplied: Record<string, string>;
  maxRetainedEvents: number;
  executionBlocked: true;
  timestamp: string;
}
```

**Filter application order** (each narrows the working set):
1. `eventType` — exact `===` match on `RuntimeEvent.eventType`
2. `source` — exact match on `RuntimeEvent.source`
3. `severity` — exact match on `RuntimeEvent.severity`
4. `category` — exact match on `RuntimeEvent.category`
5. `correlationId` — exact match on `RuntimeEvent.correlationId` (null never matches)

After filtering, `records.slice(-limit).reverse()` returns the most-recent `limit` matching events, newest-first.

**`correlationId` filter semantics:** `RuntimeEvent.correlationId` is `string | null`. A `?correlationId=someId` query performs `e.correlationId === "someId"`. Events where `correlationId === null` are never returned — null is not equal to any string. This is the only filter that can explicitly distinguish "has a correlationId" from "does not have one."

**Security note — `totalSecrets` in event payload:** The `secret_vault.initialized` event has payload fields `totalSecrets`, `configuredCount`, `placeholderCount`. These are metadata counts with no secret values. The substring "secret" appearing in a field name is not a secret leak — only actual credential values (API keys, tokens) would constitute a leak. All event payloads are safe metadata.

**Limit cap change:** Pre-Phase 66 the route allowed `?limit=` up to 200. Phase 66 lowers this to 100 (`MAX_QUERY_LIMIT`) to match the Phases 63–65 convention. The ring buffer still holds 1000 events (`MAX_EVENTS`).

**Phase 66 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | No filters — `filtersApplied: {}`, safety flags, backward compat | ✅ PASS |
| T2 | `?category=runtime` — matched=15, all `category==="runtime"` | ✅ PASS |
| T3 | `?severity=info` — matched=21, all `severity==="info"` | ✅ PASS |
| T4 | `?severity=warning` — matched=0 (none at boot), allWarn=true (vacuously) | ✅ PASS |
| T5 | `?source=runtime-event-bus` — matched=1, all from runtime-event-bus | ✅ PASS |
| T6 | `?eventType=runtime.ready` — matched=1, all `runtime.ready` | ✅ PASS |
| T7 | `?category=snapshot` — matched=5, all snapshot category | ✅ PASS |
| T8 | `?correlationId=<id>` — exact match on non-null correlationId | ✅ PASS |
| T9 | `?category=runtime&severity=info` — combined, all match | ✅ PASS |
| T10 | `?limit=3` — exactly 3 events returned | ✅ PASS |
| T10b | `?limit=9999` — capped to 100 | ✅ PASS |
| T11 | Unknown params silently ignored, `filtersApplied: {}` | ✅ PASS |
| T12 | Malformed `%GG` — category skipped, `severity=info` applied | ✅ PASS |
| T13 | Empty `category=` ignored, `severity=info` applied | ✅ PASS |
| T14 | `?category=nonexistent-cat` — 0 results, no crash | ✅ PASS |
| T15 | `?severity=extreme` — 0 results, no crash | ✅ PASS |
| T16 | `?severity=info&limit=1` — `filteredCount=21`, `events.length=1` | ✅ PASS |
| T17 | Events returned newest-first (descending timestamp) | ✅ PASS |
| T18 | No actual secret values in response (corrected check — field names containing "secret" are safe metadata) | ✅ PASS |
| T19 | Endpoint count = 59 | ✅ PASS |
| T20 | `GET /api/runtime/events` (status endpoint) unchanged | ✅ PASS |
| T21 | `GET /api/runtime/subscribers` unchanged | ✅ PASS |

**Files changed:** `core/runtimeEventBus.ts` (new `RuntimeEventFilter` and `RuntimeEventFilterResult` interfaces, `MAX_QUERY_LIMIT = 100`, `getFilteredRuntimeEvents()` exported; all existing exports including `listRecentRuntimeEvents()` preserved unchanged), `routes/runtimeEvents.ts` (new `decodeParam()`, `MAX_LIMIT=100`, `DEFAULT_LIMIT=50`, switch-based param parser for all 6 params, `handleRuntimeEventsRecent` now calls `getFilteredRuntimeEvents()`; `handleRuntimeEvents` and `handleRuntimeSubscribers` unchanged), `ENDPOINTS.md` (updated `GET /api/runtime/events/recent` row).

### Phase 65 — Command Gateway Search & Filtering

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars. Two files changed in code: `core/commandGateway.ts` and `routes/commands.ts`. One file updated in docs: `ENDPOINTS.md`.

**Problem:** `GET /api/commands` returned all retained commands (up to 500) with no filtering. Auditing blocked commands, tracing commands from a specific source, or finding all commands from a given actor required fetching the entire command log and filtering client-side.

**Solution:** Extend the existing `GET /api/commands` route to support five optional query-string filters (`riskLevel`, `commandType`, `requestedBy`, `status`, `source`) and a `limit` cap of 100. All filtering is in-memory inside `getFilteredCommands()` in the core module.

**`Command` field mapping for filters:**

| Query param | `Command` field | Match type |
|---|---|---|
| `riskLevel` | `riskLevel` | Exact `===` |
| `commandType` | `commandType` | Exact `===` (URL-decode needed for `:`) |
| `requestedBy` | `requestedBy` | Exact `===` |
| `status` | `status` | Exact `===` |
| `source` | `source` | Exact `===` |

Note: `route` filter was not implemented — `Command` has no `route` field. The `requestedBy` param is the "actorId" analog for the command gateway.

**New exported types — `CommandFilter` and `CommandListResult`:**

```typescript
export interface CommandFilter {
  riskLevel?: string;
  commandType?: string;
  requestedBy?: string;
  status?: string;
  source?: string;
  limit?: number;
}

export interface CommandListResult {
  // all CommandGatewayStatus fields (operational, counters, flags, timestamp)
  filteredCount: number;
  filtersApplied: Record<string, string>;
  limit: number;
  commands: Command[];
  commandCount: number;
}
```

**New exported function — `getFilteredCommands(filter: CommandFilter)`:**

Filter application order (each narrows the working set):
1. `riskLevel` → exact match
2. `commandType` → exact match
3. `requestedBy` → exact match
4. `status` → exact match
5. `source` → exact match

After filtering, `records.slice(-limit).reverse()` returns the most-recent `limit` matching commands, newest-first (matching `listCommands()` order).

**`MAX_QUERY_LIMIT = 100`** — default limit when no `?limit=` param is provided. Previous behavior returned all commands (up to 500); Phase 65 defaults to 100 as the safe bounded response.

**Key differences from Phases 62–64:**

| Dimension | Ph 62 (audit) | Ph 63 (session) | Ph 64 (lifecycle) | Ph 65 (commands) |
|---|---|---|---|---|
| Buffer size | 1000 | 200 | 500 | 500 |
| `limit` cap | 200 | 100 | 100 | 100 |
| Numeric filters | None | None | `statusCode`, latency range | None |
| Default limit | 50 | 50 | 50 | 100 |
| Response order | N/A (ring) | N/A (ring) | Oldest→newest (ring) | Newest-first (reversed) |
| Enum guards | `decision` (hard guard) | None | None | None |
| `commandCount` field | N/A | N/A | N/A | Added (len of filtered slice) |

**Phase 65 test results:**

| Test | Scenario | Result |
|---|---|---|
| T1 | No filters — `filtersApplied: {}`, safety flags `true`, backward compat | ✅ PASS |
| T2 | `?riskLevel=low` — matched=4, all `riskLevel==="low"` | ✅ PASS |
| T3 | `?riskLevel=critical` — matched=2 (blocked commands), all critical | ✅ PASS |
| T4 | `?commandType=status%3Aget` — URL-decoded colon, exact match | ✅ PASS |
| T5 | `?requestedBy=actor-alpha` — matched=2, all from actor-alpha | ✅ PASS |
| T6 | `?status=blocked` — matched=2, all blocked | ✅ PASS |
| T7 | `?status=approval_required` — matched=1, all approval_required | ✅ PASS |
| T8 | `?source=dashboard` — matched=3, all from dashboard | ✅ PASS |
| T9 | `?source=api-client&riskLevel=low` — combined, matched=2, all match | ✅ PASS |
| T10 | `?limit=2` — exactly 2 commands returned | ✅ PASS |
| T10b | `?limit=9999` — capped to 100 | ✅ PASS |
| T11 | Unknown params silently ignored, `filtersApplied: {}` | ✅ PASS |
| T12 | Malformed `%GG` — riskLevel skipped, `status=blocked` applied | ✅ PASS |
| T13 | Empty `source=` ignored, `status=blocked` applied | ✅ PASS |
| T14 | `?riskLevel=nonexistent-risk` — 0 results, no crash | ✅ PASS |
| T15 | `?riskLevel=low&limit=1` — `filteredCount=4`, `commands.length=1` | ✅ PASS |
| T16 | No secrets in response | ✅ PASS |
| T17 | Endpoint count = 59 | ✅ PASS |
| T18 | `GET /api/commands/status` unchanged | ✅ PASS |
| T19 | `POST /api/commands` still works (201, commandExecutionBlocked=true) | ✅ PASS |
| T20 | Commands returned newest-first (descending createdAt) | ✅ PASS |

**Files changed:** `core/commandGateway.ts` (new `CommandFilter` and `CommandListResult` interfaces, `MAX_QUERY_LIMIT = 100`, `getFilteredCommands()` exported; `listCommands()` and all existing exports preserved), `routes/commands.ts` (new `decodeParam()`, `MAX_LIMIT=100`, `DEFAULT_LIMIT=100`, switch-based param parser, `handleCommandsGet` now calls `getFilteredCommands()`; `handleCommandsStatus` and `handleCommandsPost` unchanged), `ENDPOINTS.md` (updated `GET /api/commands` row).

### Phase 64 — Lifecycle Ledger Search & Filtering

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars. Two files changed in code: `core/requestLifecycleLedger.ts` and `routes/requestLifecycleLedger.ts`. One file updated in docs: `ENDPOINTS.md`.

**Problem:** `GET /api/lifecycle/recent` returned the last N lifecycle records from the 500-entry ring buffer with no filtering. Investigating slow requests or specific error rates required fetching all records and filtering client-side.

**Solution:** Extend the existing `GET /api/lifecycle/recent` route to support five optional query-string filters (`statusCode`, `route`, `method`, `minLatencyMs`, `maxLatencyMs`) and tighten the `limit` cap to 100. Latency range filtering is the new dimension unique to this phase — it enables direct slow-request investigation from the API. All filtering is in-memory inside `getFilteredLifecycleRecords()` in the core module.

**New exported function — `getFilteredLifecycleRecords(filter: LifecycleFilter)`:**

```typescript
export interface LifecycleFilter {
  statusCode?: number;      // exact integer match; 0/negative/non-numeric silently ignored
  route?: string;           // exact string match; URL-decoded by route handler
  method?: string;          // exact match; uppercased by route handler
  minLatencyMs?: number;    // r.latencyMs >= minLatencyMs; negative silently ignored
  maxLatencyMs?: number;    // r.latencyMs <= maxLatencyMs; negative silently ignored
  limit?: number;           // max 100 (MAX_QUERY_LIMIT)
}
```

Filter application order (each narrows the working set):
1. `statusCode` — exact `===` match on `LifecycleRecord.statusCode` (integer)
2. `route` — exact match on `LifecycleRecord.route`
3. `method` — exact match on `LifecycleRecord.method` (stored uppercase)
4. `minLatencyMs` — `r.latencyMs >= minLatencyMs`
5. `maxLatencyMs` — `r.latencyMs <= maxLatencyMs`

After filtering, `records.slice(-limit)` returns the most-recent `limit` matching records.

**`LifecycleLedgerResult` additions:**

```typescript
filteredCount: number;                  // count of records matching all filters, before limit slice
filtersApplied: Record<string, string>; // active filter key→value pairs (empty when no filters)
```

**Numeric filter validation (route handler):**

| Param | Parser | Acceptance condition | Rejection |
|---|---|---|---|
| `statusCode` | `parseInt(val, 10)` | `!isNaN && isFinite && parsed > 0` | NaN, 0, negative, float strings → silently ignored |
| `minLatencyMs` | `parseFloat(val)` | `!isNaN && parsed >= 0` | NaN, negative → silently ignored |
| `maxLatencyMs` | `parseFloat(val)` | `!isNaN && parsed >= 0` | NaN, negative → silently ignored |

`parseFloat` is used for latency filters (not `parseInt`) so fractional milliseconds like `0.5` are accepted. In practice `LifecycleRecord.latencyMs` values are rounded integers, but the filter accepts any non-negative float for forward compatibility.

**Impossible latency range:** If `minLatencyMs > maxLatencyMs`, both filters are applied independently. The first pass (`>= min`) keeps records with latency above the minimum; the second pass (`<= max`) then eliminates all of them. Result: 0 records, `filteredCount: 0`. No special-casing, no error — correct mathematical behaviour.

**Difference from Phases 62–63:**

| Dimension | Ph 62 (audit) | Ph 63 (session) | Ph 64 (lifecycle) |
|---|---|---|---|
| Buffer size | 1000 | 200 | 500 |
| `limit` cap | 200 | 100 | 100 |
| Numeric filters | None | None | `statusCode`, `minLatencyMs`, `maxLatencyMs` |
| Range filter | None | None | `minLatencyMs` + `maxLatencyMs` |
| Enum validation | `decision` (3 values) | None | None |
| `filtersApplied` for nums | N/A | N/A | `String(parsedValue)` |

**Phase 64 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| T1 | No filters — backward compatible | `filtersApplied: {}`, safety flags present | ✅ PASS |
| T2 | `?statusCode=200` | All records have `statusCode=200` (matched=100) | ✅ PASS |
| T3 | `?statusCode=404` | All records have `statusCode=404` (matched=3) | ✅ PASS |
| T4 | `?route=%2Fapi%2Fmetrics` | URL-decoded, exact match (matched=11) | ✅ PASS |
| T5 | `?method=get` | Uppercased to GET, all matched GET (matched=100) | ✅ PASS |
| T6 | `?minLatencyMs=0` | All records ≥ 0ms (matched=100) | ✅ PASS |
| T7 | `?maxLatencyMs=9999` | All records ≤ 9999ms (matched=100) | ✅ PASS |
| T8 | `?minLatencyMs=0&maxLatencyMs=500` | All records in [0, 500]ms | ✅ PASS |
| T9 | `?limit=3` | Exactly 3 records, `limit=3` in response | ✅ PASS |
| T9b | `?limit=9999` | Capped to 100 | ✅ PASS |
| T10 | `?statusCode=foobar` | Filter silently ignored, full result | ✅ PASS |
| T11 | `?minLatencyMs=-100` | Negative — silently ignored | ✅ PASS |
| T12 | `?maxLatencyMs=-1` | Negative — silently ignored | ✅ PASS |
| T13 | `?foo=bar&unknown=value` | `filtersApplied: {}`, no crash | ✅ PASS |
| T14 | `?route=%GG&statusCode=200` | Malformed param skipped, `statusCode=200` applied | ✅ PASS |
| T15 | `?route=&statusCode=200` | Empty `route=` ignored, `statusCode=200` applied | ✅ PASS |
| T16 | `?statusCode=200&limit=1` | `records.length=1`, `filteredCount=497` (truncation) | ✅ PASS |
| T17 | No secrets in response | No API keys, passwords, secrets, auth headers | ✅ PASS |
| T18 | Endpoint count | 59 | ✅ PASS |
| T19 | `?route=%2Fapi%2Fstatus&statusCode=200` | Both filters active, all matched (matched=100) | ✅ PASS |
| T20 | `?minLatencyMs=9999&maxLatencyMs=0` | Impossible range — 0 results, no crash | ✅ PASS |

**Files changed:** `core/requestLifecycleLedger.ts` (new `LifecycleFilter` interface, `MAX_QUERY_LIMIT = 100`, `filteredCount`/`filtersApplied` added to `LifecycleLedgerResult` interface, `getFilteredLifecycleRecords()` exported, `getRecentLifecycleRecords()` updated to return new fields with safe defaults), `routes/requestLifecycleLedger.ts` (new `decodeParam()`, `MAX_LIMIT=100`, `DEFAULT_LIMIT=50`, switch-based param parser with numeric validation for `statusCode`/`minLatencyMs`/`maxLatencyMs` and `method` uppercasing, calls `getFilteredLifecycleRecords()`), `ENDPOINTS.md` (updated `GET /api/lifecycle/recent` row).

### Phase 63 — Session Context Search & Filtering

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars. Two files changed in code: `core/sessionContext.ts` and `routes/sessionContext.ts`. One file updated in docs: `ENDPOINTS.md`.

**Problem:** `GET /api/session/recent` returned the last N session context records from the 200-entry ring buffer with no filtering. Inspecting sessions for a specific actor, role, or route required fetching all sessions and filtering client-side.

**Solution:** Extend the existing `GET /api/session/recent` route to support five optional query-string filters (`actorId`, `actorType`, `role`, `route`, `method`) and tighten the `limit` cap to 100. All filtering is in-memory inside `getFilteredSessions()` in the core module. No new routes, no new subsystems, no baseline change.

**New exported function — `getFilteredSessions(filter: SessionFilter)`:**

```typescript
export interface SessionFilter {
  actorId?: string;
  actorType?: string;
  role?: string;
  route?: string;
  method?: string;   // normalised to uppercase before storage (see route handler)
  limit?: number;    // max 100 (MAX_QUERY_LIMIT)
}
```

Filter application order (each narrows the working set further):
1. `actorId` — exact `===` match on `SessionContext.actorId`
2. `actorType` — exact match on `SessionContext.actorType`
3. `role` — exact match on `SessionContext.role`
4. `route` — exact match on `SessionContext.route`
5. `method` — exact match on `SessionContext.method` (stored uppercase; route handler uppercases the incoming value)

After filtering, `sessions.slice(-limit)` returns the most-recent `limit` matching sessions.

**`SessionContextRecent` additions:**

```typescript
filteredCount: number;                  // count of sessions matching all filters, before limit slice
filtersApplied: Record<string, string>; // active filter key→value pairs (empty when no filters)
```

**Route handler changes (`routes/sessionContext.ts`):**

- Switched from `getRecentSessions(limit)` to `getFilteredSessions(filter)` for all calls
- `MAX_LIMIT = 100` (down from 200) applied before `getFilteredSessions`
- `DEFAULT_LIMIT = 50` unchanged
- `decodeParam(val)`: wraps `decodeURIComponent()` in try/catch — malformed percent-encoding returns `undefined`, silently skipping the param
- Empty values (`actorType=`) guarded by `val === ""` → `continue`
- `method` value uppercased via `.toUpperCase()` before storage in filter — normalises case without rejecting valid inputs
- `switch(key)` over known param names: `limit`, `actorId`, `actorType`, `role`, `route`, `method`; default case is a no-op (unknown params silently ignored)

**Difference from Phase 62 (audit log filtering):**

| Dimension | Phase 62 (audit log) | Phase 63 (session context) |
|---|---|---|
| Filter fields | `role`, `actorType`, `decision`, `route`, `authSource` | `actorId`, `actorType`, `role`, `route`, `method` |
| `limit` cap | 200 | 100 |
| Enum validation | `decision` — 3 valid values, invalid silently ignored | None — unknown values return 0 results safely |
| Case normalisation | None | `method` uppercased via `.toUpperCase()` |
| Buffer size | 1000 entries | 200 entries |

**Safety properties:**

| Property | Implementation |
|---|---|
| No crash on unknown filter value | Exact `===` match — no enum cast, no validation throw |
| No crash on malformed URL-encoding | `decodeParam()` wraps `decodeURIComponent` in try/catch → returns `undefined` |
| No crash on empty values | `val === ""` guard → `continue` |
| No crash on unknown params | `default: break` in switch |
| No secrets exposed | `SessionContext` stores no raw headers, API keys, or request body |
| Live buffer never mutated | `sessionBuffer.slice()` taken first; all filter chaining is on the copy |
| `executionBlocked: true` preserved | Typed literal `true` on every `SessionContext` and on the `SessionContextRecent` wrapper |
| `recoveryBlocked: true` preserved | Typed literal `true` on `SessionContextRecent` wrapper |
| Backward compatibility | No filters → `filtersApplied: {}`, `filteredCount = sessionCount`, response identical to pre-Phase 63 |
| `getRecentSessions()` preserved | Still exported, returns new fields with safe defaults, available for internal consumers |

**Phase 63 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| T1 | No filters — `filtersApplied: {}`, safety flags present | Backward compatible | ✅ PASS |
| T2 | `?actorId=svc-seed-01` | All returned sessions have `actorId=svc-seed-01` (matched=3) | ✅ PASS |
| T3 | `?actorType=anonymous` | All returned sessions have `actorType=anonymous` (matched=50) | ✅ PASS |
| T4 | `?role=operator` | All returned sessions have `role=operator` (matched=5) | ✅ PASS |
| T5 | `?route=%2Fapi%2Fmetrics` | URL-decoded → exact match on `/api/metrics` (matched=6) | ✅ PASS |
| T6 | `?method=get` | Uppercased to GET, all matched sessions have `method=GET` (matched=50) | ✅ PASS |
| T7 | `?limit=3` | Exactly 3 sessions returned, `limit=3` in response | ✅ PASS |
| T7b | `?limit=9999` | Capped to 100 | ✅ PASS |
| T8 | `?actorType=robot` | No crash, 0 results, `filtersApplied.actorType="robot"` | ✅ PASS |
| T9 | `?foo=bar&unknown=value` | `filtersApplied: {}`, no crash | ✅ PASS |
| T10 | `?actorType=service&role=operator` | Both filters active, all 5 matched sessions satisfy both | ✅ PASS |
| T11 | No secrets in response | No API keys, passwords, secrets, auth headers | ✅ PASS |
| T12 | Endpoint count | 59 | ✅ PASS |
| T13 | `?actorId=%GG` — malformed URL-encoding | No crash, malformed param skipped, valid params still applied | ✅ PASS |
| T14 | `?actorType=&role=guest` | Empty `actorType=` ignored, `role=guest` applied | ✅ PASS |
| T15 | `?actorType=anonymous&limit=1` | `sessions.length=1`, `filteredCount=195` (truncation visible) | ✅ PASS |
| T16 | `?actorId=nonexistent-actor-xyz` | `sessions.length=0`, `filteredCount=0`, graceful empty result | ✅ PASS |

**Files changed:** `core/sessionContext.ts` (new `SessionFilter` interface, `MAX_QUERY_LIMIT = 100`, `filteredCount`/`filtersApplied` added to `SessionContextRecent` interface, `getFilteredSessions()` exported, `getRecentSessions()` updated to return new fields with safe defaults), `routes/sessionContext.ts` (new `decodeParam()`, `MAX_LIMIT=100`, `DEFAULT_LIMIT=50`, param parsing via switch with `method` uppercasing, calls `getFilteredSessions()`), `ENDPOINTS.md` (updated `GET /api/session/recent` row with filter documentation).

### Phase 62 — Audit Log Search & Filtering

Observability enhancement — no new endpoints, no new health checks, no new registered subsystems, no new env vars. Two files changed in code: `core/auditLog.ts` and `routes/auditLog.ts`. One file updated in docs: `ENDPOINTS.md`.

**Problem:** `GET /api/audit/log` returned the last N entries from the 1000-entry ring buffer with no filtering. When the buffer is near capacity, operators needing to inspect a specific role, actor type, decision outcome, or route had to fetch all entries and filter client-side. With 1000 entries this is unwieldy and wasteful.

**Solution:** Extend the existing `GET /api/audit/log` route to support five optional query-string filters (`role`, `actorType`, `decision`, `route`, `authSource`) and tighten the `limit` cap to 200. All filtering is in-memory inside `getFilteredAuditEntries()` in the core module. No new routes, no new subsystems, no baseline change.

**New exported function — `getFilteredAuditEntries(filter: AuditFilter)`:**

```typescript
export interface AuditFilter {
  role?: string;
  actorType?: string;
  decision?: string;    // validated against AuditDecision enum before filtering
  route?: string;
  authSource?: string;
  limit?: number;       // max 200 (MAX_QUERY_LIMIT)
}
```

Filter application order (each narrows the working set further):
1. `role` — exact `===` match on `AuditEntry.role`
2. `actorType` — exact match on `AuditEntry.actorType`
3. `decision` — enum-validated match (`"allowed"` | `"denied"` | `"no_policy"`); invalid values silently ignored
4. `route` — exact match on `AuditEntry.route`
5. `authSource` — exact match on `AuditEntry.authSource`

After filtering, `entries.slice(-limit)` returns the most-recent `limit` matching entries.

**`AuditLogResult` additions:**

```typescript
filteredCount: number;               // count of entries matching all filters, before limit slice
filtersApplied: Record<string, string>; // active filter key→value pairs (empty when no filters)
```

`filteredCount > entries.length` signals truncation — there are more matching entries than the limit returned. `filtersApplied: {}` (empty object) signals no active filters — response is equivalent to the unfiltered baseline.

**Route handler changes (`routes/auditLog.ts`):**

- Switched from `getAuditLogEntries(limit)` to `getFilteredAuditEntries(filter)` for all calls
- `MAX_LIMIT = 200` (down from 1000) applied before `getFilteredAuditEntries`
- `DEFAULT_LIMIT = 100` unchanged
- `decodeParam(val)`: wraps `decodeURIComponent()` in try/catch — malformed percent-encoding (e.g. `%GG`) returns `undefined`, silently skipping the param
- Empty values (`role=`) guarded by `val === ""` check — treated as absent
- `switch(key)` over known param names: `limit`, `role`, `actorType`, `decision`, `route`, `authSource`; default case is a no-op (unknown params silently ignored)

**Safety properties:**

| Property | Implementation |
|---|---|
| No crash on invalid `decision` | `VALID_DECISIONS.includes(val)` guard before cast; ignored if invalid |
| No crash on malformed URL-encoding | `decodeParam()` wraps `decodeURIComponent` in try/catch → returns `undefined` |
| No crash on empty values | `val === ""` guard → `continue` |
| No crash on unknown params | `default: break` in switch |
| No secrets exposed | Filtering is on `AuditEntry` fields — no raw headers, API keys, or request body appear in `AuditEntry` |
| Live buffer never mutated | `buffer.slice()` called first; all filter chaining is on the copy |
| `executionBlocked: true` preserved | Typed literal `true` on every `AuditEntry` and on the `AuditLogResult` wrapper |
| `recoveryBlocked: true` preserved | Typed literal `true` on `AuditLogResult` wrapper |
| Backward compatibility | No filters → `filtersApplied: {}`, `filteredCount = entryCount`, response identical to pre-Phase 62 behaviour (minus limit cap change 1000→200) |
| `getAuditLogEntries()` preserved | Still exported, unchanged, available for internal consumers needing raw access up to 1000 entries |

**Query string examples:**

```
GET /api/audit/log                                  → last 100 entries (no filter)
GET /api/audit/log?limit=50                         → last 50 entries (no filter)
GET /api/audit/log?role=viewer                      → last 100 entries where role=viewer
GET /api/audit/log?decision=denied                  → last 100 denied entries
GET /api/audit/log?decision=foobar                  → last 100 entries (filter silently ignored)
GET /api/audit/log?role=guest&decision=allowed      → last 100 allowed entries by guests
GET /api/audit/log?route=%2Fapi%2Fstatus            → last 100 entries for /api/status
GET /api/audit/log?authSource=api_key&limit=200     → last 200 api_key-authed entries
GET /api/audit/log?unknown=value                    → last 100 entries (unknown param ignored)
GET /api/audit/log?role=                            → last 100 entries (empty value ignored)
```

**Phase 62 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| T1 | No filters — backward compatible | status 200, `filtersApplied: {}`, `executionBlocked: true`, `recoveryBlocked: true` | ✅ PASS |
| T2 | `?role=guest` | All entries have `role=guest`, `filtersApplied.role="guest"` | ✅ PASS |
| T3 | `?actorType=user` | All entries have `actorType=user`, `filtersApplied.actorType="user"` | ✅ PASS |
| T4 | `?decision=allowed` | All entries have `decision=allowed`, `filtersApplied.decision="allowed"` | ✅ PASS |
| T5 | `?route=%2Fapi%2Fstatus` | URL-decoded → exact match on `/api/status` | ✅ PASS |
| T6 | `?authSource=<first found>` | All entries have matching `authSource` | ✅ PASS |
| T7 | `?limit=5` | `entries.length=5`, `limit=5` in response | ✅ PASS |
| T7b | `?limit=9999` | Capped to 200 | ✅ PASS |
| T8 | `?decision=foobar` | `filtersApplied.decision` absent, full result returned | ✅ PASS |
| T9 | `?unknown=value&foo=bar` | `filtersApplied: {}`, no crash | ✅ PASS |
| T10 | `?role=guest&decision=allowed` | Both filters active and correct | ✅ PASS |
| T11 | No secrets in response | No API keys, passwords, secrets, auth headers | ✅ PASS |
| T12 | Endpoint count | 59 | ✅ PASS |
| T13 | Malformed URL-encoding `%GG` | No crash, malformed param skipped | ✅ PASS |
| T14 | `?role=&decision=allowed` | Empty `role=` ignored, `decision=allowed` applied | ✅ PASS |
| T15 | `?role=guest&limit=1` | `entries.length=1`, `filteredCount ≥ 1` (shows truncation) | ✅ PASS |

**Files changed:** `core/auditLog.ts` (new `AuditFilter` interface, `MAX_QUERY_LIMIT = 200`, `VALID_DECISIONS` constant, `filteredCount`/`filtersApplied` added to `AuditLogResult` interface, `getFilteredAuditEntries()` exported, `getAuditLogEntries()` updated to return new fields with defaults), `routes/auditLog.ts` (new `decodeParam()`, `MAX_LIMIT=200`, `DEFAULT_LIMIT=100`, param parsing via switch, calls `getFilteredAuditEntries()`), `ENDPOINTS.md` (updated `GET /api/audit/log` row with filter documentation).

### Phase 61 — Rate Limit Anomaly Logging

Observability-only addition — no new endpoints, no new health checks, no new registered subsystems, no new env vars. Two files changed in code: `core/rateLimiter.ts` and `core/diagnostics.ts`. One line added in `server.ts` (the `recordRateLimitAnomaly()` call).

**Problem:** The rate limiter (Phase 51) tracked aggregate block counts via `totalBlocked` and `lastBlockedKey`, but provided no time-series visibility into which identities were blocked, on which routes, or in what sequence. A burst of 429s against a single endpoint was indistinguishable in the diagnostics snapshot from a low-rate spray across many routes.

**Solution:** A 25-entry in-memory ring buffer of `RateLimitAnomaly` records. Each entry is written exactly once per HTTP 429 response by `recordRateLimitAnomaly()`, called from `server.ts` dispatch in the `!rl.allowed` branch. The buffer and its summary fields (`anomalyCount`, `lastAnomalyAt`) are surfaced through the existing `GET /api/diagnostics/snapshot` → `rateLimit` field. No new routes are added.

**`RateLimitAnomaly` interface:**

```typescript
export interface RateLimitAnomaly {
  timestamp: string;       // ISO 8601
  identityKey: string;     // rate limiter bucket key ("anonymous:guest" or "id:<actorId>")
  route: string;           // request path (e.g. "/api/status")
  method: string;          // HTTP verb (e.g. "GET")
  retryAfterSeconds: number; // seconds remaining in current rate limit window
  blockedCount: number;    // per-bucket cumulative block count at time of recording
  executionBlocked: true;  // typed literal — observational only, no remediation implied
}
```

**What is intentionally excluded:**

| Field | Reason excluded |
|---|---|
| Raw `X-API-Key` value | API key secret — never logged |
| IP address | Not available at dispatch when `TRUSTED_PROXIES` is unset; avoids PII |
| Raw request headers | Could contain credentials or sensitive values |
| Request body | Could contain credentials or sensitive values |
| `correlationId` | Only set after `createSessionContext()`, which is never reached for 429 responses |
| `requestId` | Available but not needed — the anomaly buffer is for behavioral patterns, not per-request tracing |

**Buffer design:**

```
MAX_ANOMALY_ENTRIES = 25
anomalyBuffer: RateLimitAnomaly[]  (plain array, shift() eviction)
anomalyCount: number               (monotonically increasing, persists across buffer wrap)
lastAnomalyAt: string | null       (ISO string of most recent anomaly timestamp)
```

When `anomalyBuffer.length >= 25`, the oldest entry is removed via `anomalyBuffer.shift()` before the new entry is pushed. `anomalyCount` always reflects the total number of anomalies recorded since the last server restart — it does not reset when entries are evicted from the buffer.

**`getRateLimiterStatus()` additions:**

```typescript
anomalyCount: number;
recentAnomalies: RateLimitAnomaly[];   // anomalyBuffer.slice() — shallow copy
lastAnomalyAt: string | null;
```

**`DiagnosticsRateLimit` additions (in `diagnostics.ts`):**

```typescript
anomalyCount: number;
recentAnomalies: RateLimitAnomaly[];
lastAnomalyAt: string | null;
```

`RateLimitAnomaly` is re-exported from `diagnostics.ts` so consumers that import from the diagnostics module have the type available.

**Wiring in `server.ts` dispatch (inside `!rl.allowed` branch):**

```
// after: const retryAfterSec = Math.max(1, Math.ceil(...));
// after: log.warn(...)
recordRateLimitAnomaly({
  timestamp: new Date().toISOString(),
  identityKey: rl.identityKey,
  route: path,
  method,
  retryAfterSeconds: retryAfterSec,
  blockedCount: rl.blockedCount,
  executionBlocked: true,
});
// after: res.setHeader("retry-after", ...)
// after: sendError(res, 429, ...)
```

This mirrors the pattern used by `recordHardeningViolation()` for hardening blocks — the recording call sits between the log emit and the HTTP response, keeping the 429 response path intact.

**Updated dispatch pipeline — anomaly recording position:**
```
...
checkRateLimit()      → RateLimitResult
  !rl.allowed:
    log.warn(...)
    recordRateLimitAnomaly(...)   ← Phase 61: new
    res.setHeader("retry-after")
    sendError(res, 429)
    return
  rl.allowed → continue
createSessionContext() → resolvedCtx assigned (records begin here)
...
```

`/api/healthz` is exempt from rate limiting (existing Phase 51 gate: `if (path !== "/api/healthz")`). Since `checkRateLimit()` is never called for healthz, `recordRateLimitAnomaly()` is also never called for healthz — no anomaly is recorded regardless of how many healthz requests arrive.

**Phase 61 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| T1 | Server healthy before test | 200 OK | ✅ PASS |
| T2 | Clean baseline: `anomalyCount=0`, `recentAnomalies=[]`, `lastAnomalyAt=null` | All zero/null | ✅ PASS |
| T3 | Fire 65 requests (limit=60) → 5 blocked | `blocked=5` | ✅ PASS |
| T4 | Diagnostics shows `anomalyCount=5` | `5` | ✅ PASS |
| T5 | `recentAnomalies.length=5`, bounded ≤25 | `length=5` | ✅ PASS |
| T6 | Each entry has all required fields, no secrets/forbidden terms | `allRequired=true noForbidden=true` | ✅ PASS |
| T7 | `lastAnomalyAt` is valid ISO 8601 string | Valid ISO | ✅ PASS |
| T8 | Endpoint count still 59 | `59` | ✅ PASS |
| T9 | `identityKey` correctly set to `"id:<actorId>"` for keyed buckets | All 5 matched | ✅ PASS |
| T10 | `/api/healthz` hammer (10 requests) → no new anomalies | Count unchanged | ✅ PASS |
| T11 | 5 normal (under-limit) requests → no anomalies | Count unchanged | ✅ PASS |
| T12 | Fire 90 requests (60 allowed + 30 blocked) → `recentAnomalies.length ≤ 25`, `anomalyCount=35` | `length=25 anomalyCount=35` | ✅ PASS |

**Why no new endpoint:** The anomaly buffer is observability metadata, not a separate resource. It is surfaced through the existing aggregation point (`GET /api/diagnostics/snapshot`) to avoid increasing the endpoint count (which would break the frozen baseline). Adding a dedicated `GET /api/rate-limit/anomalies` endpoint would require a baseline amendment phase.

**Files changed:** `core/rateLimiter.ts` (new `RateLimitAnomaly` interface, `MAX_ANOMALY_ENTRIES`, `anomalyBuffer`, `anomalyCount`, `lastAnomalyAt`, `recordRateLimitAnomaly()`, extended `RateLimiterStatus`), `core/diagnostics.ts` (re-export `RateLimitAnomaly`, extended `DiagnosticsRateLimit` interface, 3 new fields in snapshot body), `server.ts` (import `recordRateLimitAnomaly`, call in `!rl.allowed` branch).

### Phase 60 — X-Forwarded-For Validation & Trusted Proxy Foundation

Infrastructure-only hardening phase — no new endpoints, no new health checks, no new registered subsystems. Three files changed in code: `core/hardening.ts`, `core/sessionContext.ts`, `server.ts`. Config files updated: `.env.example`, `DEPLOYMENT.md`.

**Problem:** Prior to Phase 60, `X-Forwarded-For` was forwarded from any TCP connection without validation. A client connecting directly to port 3000 (bypassing the reverse proxy) could inject arbitrary `X-Forwarded-For` and `X-Forwarded-Proto` headers. This allowed IP spoofing, XFF poisoning, and HTTPS enforcement bypass — even with `BULLDOZER_REQUIRE_HTTPS=true` set. The `x-forwarded-for` header was also never length- or content-validated, leaving the request pipeline open to control-character injection.

**Solution:** Two independent protections, both in `validateForwardedFor()`:

1. **XFF structural validation** (always runs when `x-forwarded-for` is present): rejects control characters, values exceeding 512 chars, and empty comma-separated segments — regardless of proxy configuration.
2. **Trusted proxy enforcement** (opt-in via `BULLDOZER_TRUSTED_PROXIES`): rejects any request whose TCP socket `remoteAddress` is not in the allowlist.

**`validateForwardedFor(req)` — logic:**

```
x-forwarded-for present:
  length > 512              → blocked: true, type=xff_too_long,           400
  contains control char     → blocked: true, type=invalid_forwarded_for,  400
  segment empty after trim  → blocked: true, type=malformed_forwarded_for, 400

TRUSTED_PROXIES.size > 0:
  normalizeRemoteAddress(remoteAddr) not in TRUSTED_PROXIES
                            → blocked: true, type=untrusted_proxy,        400

all checks pass             → { blocked: false, warned: false }
```

**`normalizeRemoteAddress(addr)` — IPv4-mapped IPv6 normalization:**

When a Node.js HTTP server listens on `0.0.0.0` in dual-stack mode, an incoming connection from `127.0.0.1` may have `remoteAddress = "::ffff:127.0.0.1"`. Without normalization, this would not match `"127.0.0.1"` in `TRUSTED_PROXIES`. The function strips the `::ffff:` prefix when the remainder matches an IPv4 dotted-quad pattern:

```
"::ffff:127.0.0.1" → "127.0.0.1"  (matched in TRUSTED_PROXIES)
"::1"              → "::1"         (unchanged — pure IPv6, not IPv4-mapped)
"127.0.0.1"        → "127.0.0.1"  (unchanged — already IPv4)
```

**New violation types:**

| Type | Trigger | HTTP status |
|---|---|---|
| `xff_too_long` | `x-forwarded-for` header length > 512 chars | 400 |
| `invalid_forwarded_for` | Control character detected in `x-forwarded-for` | 400 |
| `malformed_forwarded_for` | Empty comma-separated segment in `x-forwarded-for` | 400 |
| `untrusted_proxy` | `remoteAddress` not in `TRUSTED_PROXIES` (when configured) | 400 |

**New fields in `GET /api/hardening` response:**

| Field | Type | Description |
|---|---|---|
| `trustedProxiesConfigured` | `boolean` | Whether `BULLDOZER_TRUSTED_PROXIES` is set (non-empty) |
| `realIpHeader` | `string` | Always `"x-real-ip"` — the standard Nginx real-IP header name |
| `forwardedForHeader` | `string` | Always `"x-forwarded-for"` — the standard XFF header name |

**Session context enrichment (`SessionContext`):**

| Field | Type | Description |
|---|---|---|
| `remoteAddress?` | `string` | Raw `req.socket?.remoteAddress` — the proxy's TCP address, stored verbatim |
| `clientIp?` | `string` | First IP from `x-forwarded-for` — only set when `TRUSTED_PROXIES` is configured |

`clientIp` is never set without a trusted proxy configuration — untrusted XFF headers must not be used for IP attribution.

**Updated dispatch pipeline — proxy/XFF guard position:**
```
attachRequestId()          → x-request-id + 10 security headers
validateRequest()          → 400/405 early exit
validateRequestHardening() → URL + Host checks
  url_too_long             → 414
  path_traversal           → 400
  control_chars (path)     → 400
  double_slash             → warn only
  missing_host             → 400
  invalid_host             → 400
  host_not_allowed         → 400
validateHttpsTransport()   → X-Forwarded-Proto enforcement
  missing_forwarded_proto  → 400
  insecure_forwarded_proto → 400
validateForwardedFor()     → XFF structural + trusted proxy check  ← Phase 60: new
  xff_too_long             → 400
  invalid_forwarded_for    → 400
  malformed_forwarded_for  → 400
  untrusted_proxy          → 400  (TRUSTED_PROXIES configured only)
Content-Length guard       → 413/400
checkRateLimit()           → 429
createSessionContext()     → resolvedCtx assigned (records begin here)
```

**CIDR not supported:** The trusted proxy allowlist requires exact IP addresses. CIDR subnet matching is not implemented — it would require either an external library (forbidden) or a hand-rolled IPv6 bitwise implementation that is difficult to verify as correct. Exact IP matching covers all practical production cases (loopback, single VPS proxy, LAN proxy) and is documented.

**Why no new endpoint:** The three new hardening fields are surfaced through the existing `GET /api/hardening` endpoint via `getHardeningStatus()`. `remoteAddress` and `clientIp` are surfaced in `GET /api/session/recent`. No route, health check, or registered subsystem is added. The baseline (59 endpoints, 36 health checks, 26 subsystems) is unchanged.

**Phase 60 test results** (default mode port 8080; trusted proxy mode port 9997; untrusted proxy mode port 9996):

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| T1 | Default mode — normal request | 200 OK | ✅ PASS |
| T2 | Default mode — valid `X-Forwarded-For` | 200 OK | ✅ PASS |
| T3 | `X-Forwarded-For` with control char (`\x01`) | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T4 | `X-Forwarded-For` 807 chars (> 512 limit) | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T5 | `X-Forwarded-For: 1.2.3.4,,5.6.7.8` (empty segment) | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T6 | `TRUSTED_PROXIES=127.0.0.1,::1` + loopback connection | 200 OK (trusted) | ✅ PASS |
| T7 | Session context has `remoteAddress` + `clientIp=10.20.30.40` | Both fields present | ✅ PASS |
| T8 | `TRUSTED_PROXIES=10.0.0.1` + connection from 127.0.0.1 | 400 + x-request-id + 10 sec headers + no x-correlation-id | ✅ PASS |
| T9 | `GET /api/hardening` → proxy fields (default mode) | `trustedProxiesConfigured=false`, `realIpHeader=x-real-ip`, `forwardedForHeader=x-forwarded-for` | ✅ PASS |
| T10 | `GET /api/hardening` → `trustedProxiesConfigured=true` (proxy mode) | `true` | ✅ PASS |
| T_noCorr | Blocked XFF/proxy responses have no `x-correlation-id` | Absent (no session created) | ✅ PASS |

### Phase 59 — TLS/HTTPS Transport Hardening

Infrastructure-only hardening phase — no new endpoints, no new health checks, no new registered subsystems. Two files changed in code: `core/hardening.ts`, `server.ts`. Config files updated: `.env.example`, `DEPLOYMENT.md`.

**Problem:** The server always emitted `Strict-Transport-Security` but never verified whether requests actually arrived over HTTPS. In VPS/cloud deployments behind a reverse proxy (Nginx, Caddy), TLS is terminated at the proxy and traffic reaches the Node.js server over plain HTTP. If `BULLDOZER_REQUIRE_HTTPS` was not enforced, a misconfigured proxy — or a client that bypasses the proxy and hits port 3000 directly — could send plaintext HTTP requests that the server accepted as valid, despite the HSTS header.

**Solution:** Optional `X-Forwarded-Proto` enforcement. When `BULLDOZER_REQUIRE_HTTPS=true` is set, the server rejects any request that does not carry `X-Forwarded-Proto: https` (case-insensitive, whitespace-trimmed). When unset or `false`, behavior is identical to Phase 58.

**`validateHttpsTransport(req)` — logic:**

```
REQUIRE_HTTPS=false  → { blocked: false, warned: false }  (no-op, zero overhead)
REQUIRE_HTTPS=true:
  x-forwarded-proto absent or empty → blocked: true, type=missing_forwarded_proto, 400
  x-forwarded-proto != "https"      → blocked: true, type=insecure_forwarded_proto, 400
  x-forwarded-proto == "https"      → { blocked: false, warned: false }
```

**Case normalization:** `req.headers["x-forwarded-proto"].toLowerCase().trim()` — `"HTTPS"`, `" https "`, and `"Https"` all pass. Node.js HTTP header names are already lower-cased; only the value requires normalization.

**New violation types:**

| Type | Trigger | HTTP status |
|---|---|---|
| `missing_forwarded_proto` | `x-forwarded-proto` header absent or empty when `REQUIRE_HTTPS=true` | 400 |
| `insecure_forwarded_proto` | `x-forwarded-proto` value is not `"https"` when `REQUIRE_HTTPS=true` | 400 |

**New fields in `GET /api/hardening` response:**

| Field | Type | Description |
|---|---|---|
| `requireHttpsConfigured` | `boolean` | Whether `BULLDOZER_REQUIRE_HTTPS=true` was set at startup |
| `httpsHeaderName` | `string` | Always `"x-forwarded-proto"` |
| `hstsHeaderPresent` | `boolean` | Always `true` — `strict-transport-security` is in `SECURITY_HEADERS` |

**Updated dispatch pipeline — HTTPS transport guard position:**
```
attachRequestId()          → x-request-id + 10 security headers
validateRequest()          → 400/405 early exit
validateRequestHardening() → URL + Host checks
  url_too_long             → 414
  path_traversal           → 400
  control_chars (path)     → 400
  double_slash             → warn only
  missing_host             → 400
  invalid_host             → 400
  host_not_allowed         → 400
validateHttpsTransport()   → X-Forwarded-Proto enforcement   ← Phase 59: new
  missing_forwarded_proto  → 400  (REQUIRE_HTTPS=true only)
  insecure_forwarded_proto → 400  (REQUIRE_HTTPS=true only)
Content-Length guard       → 413/400
checkRateLimit()           → 429
createSessionContext()     → resolvedCtx assigned (records begin)
```

**Why enforcement is opt-in:** `BULLDOZER_REQUIRE_HTTPS=true` is correct only when the server is behind a proxy that always injects `X-Forwarded-Proto`. Setting it without a properly configured proxy causes all requests to be rejected. Local dev servers do not have `X-Forwarded-Proto` — enabling it in dev is a misconfiguration. The env var is parsed once at module load; changing it requires a restart.

**Why no new endpoint:** The three new fields (`requireHttpsConfigured`, `httpsHeaderName`, `hstsHeaderPresent`) are surfaced through the existing `GET /api/hardening` endpoint via `getHardeningStatus()`. No route, no health check, no registered subsystem is added. The baseline (59 endpoints, 36 health checks, 26 subsystems) is unchanged.

**Phase 59 test results** (raw TCP, port 8080 for default mode, port 9999 for REQUIRE_HTTPS=true mode):

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| T1 | No BULLDOZER_REQUIRE_HTTPS — normal request | 200 OK | ✅ PASS |
| T2 | No BULLDOZER_REQUIRE_HTTPS — request without X-Forwarded-Proto | 200 OK (enforcement off) | ✅ PASS |
| T3 | REQUIRE_HTTPS=true + `X-Forwarded-Proto: https` | 200 OK | ✅ PASS |
| T4 | REQUIRE_HTTPS=true + `X-Forwarded-Proto: http` | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T5 | REQUIRE_HTTPS=true + no X-Forwarded-Proto header | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T6 | REQUIRE_HTTPS=true + `X-Forwarded-Proto: HTTPS` (uppercase) | 200 OK (normalized) | ✅ PASS |
| T7 | REQUIRE_HTTPS=true + `X-Forwarded-Proto: ` (empty value) | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T8 | 400 responses have no x-correlation-id (no session) | Absent | ✅ PASS |
| T9 | `GET /api/hardening` → `requireHttpsConfigured: false` (default) | `false` | ✅ PASS |
| T10 | `GET /api/hardening` → `requireHttpsConfigured: true` (enabled) | `true` | ✅ PASS |
| T11 | `GET /api/hardening` → `hstsHeaderPresent: true` (always) | `true` | ✅ PASS |

### Phase 58 — Host Header Validation Hardening

Infrastructure-only hardening phase — no new endpoints, no new health checks, no new registered subsystems. One file changed in code: `core/hardening.ts`. Config files updated: `.env.example`, `DEPLOYMENT.md`.

**Changes to `validateRequestHardening()` — Host header block:**

| Change | Before Phase 58 | After Phase 58 |
|---|---|---|
| Missing or empty `Host` | `warned: true` (warn only) | `blocked: true, httpStatus: 400` |
| Control chars in `Host` value | Not checked | `blocked: true, httpStatus: 400` |
| `BULLDOZER_ALLOWED_HOSTS` allowlist | Not supported | Optional allowlist; skip if unset |

**New violation types:**

| Type | Trigger | HTTP status |
|---|---|---|
| `missing_host` | `Host` header absent or whitespace-only | 400 (promoted from warn) |
| `invalid_host` | Any char with code `< 0x20` or `== 0x7f` in `Host` value | 400 (new) |
| `host_not_allowed` | `BULLDOZER_ALLOWED_HOSTS` set and `Host` not in allowlist | 400 (new) |

**Allowlist — `BULLDOZER_ALLOWED_HOSTS`:**
- Parsed once at module load from `process.env["BULLDOZER_ALLOWED_HOSTS"]`
- Split on comma, each entry trimmed and lowercased, stored as `Set<string>`
- If unset or empty string → `ALLOWED_HOSTS.size === 0` → allowlist check skipped
- If set → incoming `Host` is lowercased and trimmed, checked against the Set
- Full `host:port` value is compared — proxies that rewrite `Host` must be accounted for
- Changing the env var while the server runs has no effect — restart required

**Updated dispatch pipeline — Host header guard position:**
```
attachRequestId()          → x-request-id + 10 security headers
validateRequest()          → 400/405 early exit (method/URL validation)
validateRequestHardening() → URL checks + Host header checks + allowlist
  url_too_long             → 414
  path_traversal           → 400
  control_chars (path)     → 400
  double_slash             → warn only (continues)
  missing_host             → 400  ← Phase 58: promoted from warn to block
  invalid_host             → 400  ← Phase 58: new
  host_not_allowed         → 400  ← Phase 58: new
Content-Length guard       → 413/400
checkRateLimit()           → 429
createSessionContext()     → resolvedCtx assigned (records begin)
```

**Why missing Host is now blocked (not warned):**
HTTP/1.1 (RFC 7230 §5.4) requires every HTTP/1.1 request to include a `Host` header. A request without `Host` is malformed. Host-header injection attacks use absent, empty, or overridden Host values to manipulate cache keys, password-reset links, and virtual-host routing. Demoting this from a warning to a block aligns the server with the RFC and closes the injection vector.

**Why host value is not reflected in the 400 body:**
`host_not_allowed` reason says `"Host is not in the allowed hosts list"` — it does not include the actual `Host` value received. Reflecting attacker-controlled input (even a header value) in error responses is an injection risk. The actual host value is logged server-side only.

**Phase 58 test results** (raw TCP, port 8080 for main server, port 9898 for allowlist tests):

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| T1 | Normal `Host: localhost:8080` | 200 OK | ✅ 200 + `{"status":"ok"}` |
| T2 | `Host:` empty value | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T3 | `Host: localhost\x01evil` (ctrl char 0x01) | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T4 | `Host: localhost\x7fevil` (DEL char 0x7f) | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T5 | No `Host` header at all (HTTP/1.1) | 400 returned | ✅ 400 — see note below |
| T6 | No `x-correlation-id` on blocked response | Absent | ✅ Absent (no session context) |
| T7 | Allowed host with `BULLDOZER_ALLOWED_HOSTS=localhost:9898` | 200 | ✅ 200 OK |
| T8 | Disallowed host with allowlist set (`evil.example.com`) | 400 + x-request-id + 10 sec headers | ✅ PASS |
| T9 | Case-insensitive allowlist (`LOCALHOST:9898`) | 200 | ✅ 200 OK |

**Note on T5 — Node.js v24 hard constraint:** When a HTTP/1.1 request contains NO `Host` header, Node.js v24's llhttp C++ parser rejects it before the JavaScript `request` event fires and emits no `clientError` event. The 400 response contains only `Connection`, `Date`, and `Transfer-Encoding` headers — no `x-request-id`, no security headers, no JSON body. This is an unoverridable runtime constraint (see GOTCHAS.md). All other Host violations — empty value, control chars, allowlist mismatch — go through `dispatch()` and receive the full header set. The security outcome for T5 is correct (400 returned); only the header enrichment is missing for that one case.

### Phase 57 — Input Body Size Enforcement Hardening

Infrastructure-only hardening phase — no new endpoints, no new health checks, no new registered subsystems. Two files changed: `lib/body.ts` (exported constant) and `server.ts` (dispatch guard).

**Problem:** `readJsonBody()` enforced the 64 KB limit on streamed bytes, but only for routes that called it (POST routes). All GET routes and any route that did not call `readJsonBody()` had no body protection — a client could stream an arbitrarily large body and Node.js would buffer it at the socket layer until memory pressure, `req.destroy()`, or connection close. Additionally, the per-route enforcement was post-routing, meaning the server had already parsed the path and begun authentication before the body was read.

**Solution:** Add a `Content-Length` header check at the top of the dispatch pipeline, before routing, before session context creation, and before any record-keeping.

**Single source of truth — `MAX_BODY_BYTES`:**
`DEFAULT_MAX_BYTES` in `lib/body.ts` was renamed to `export const MAX_BODY_BYTES = 65_536`. Both enforcement points now use the same exported constant:
- `server.ts` dispatch — `Content-Length` header check (applies to ALL routes, ALL methods)
- `readJsonBody()` default parameter — streaming accumulator check (applies to routes that read bodies)

**Dispatch guard — insertion point:**
Placed after `validateRequestHardening()` and before `checkRateLimit()` / `createSessionContext()`:
```
attachRequestId()          → requestId, x-request-id, security headers set
validateRequest()          → method + path extracted (400/405 early exit if invalid)
validateRequestHardening() → URL safety checks (400/414 early exit if blocked)
Content-Length guard       → 413 / 400 early exit ← Phase 57 insertion point
checkRateLimit()           → 429 early exit
createSessionContext()     → resolvedCtx assigned (audit/session/lifecycle records begin)
validateRouteAccess()      → appendAuditEntry()
router.resolve()           → handler (404 if not found)
```

**Guard behavior table:**

| `Content-Length` header | Behaviour |
|---|---|
| Absent | Skip guard entirely — no change to existing behaviour |
| Present, numeric, `<= 65536` | Pass — continue dispatch |
| Present, numeric, `> 65536` | **HTTP 413 Payload Too Large** |
| Present, non-numeric | **HTTP 400 Bad Request** (`Number("abc")` → `NaN`) |
| Present, negative | **HTTP 400 Bad Request** (`-1 < 0` guard) |

**Boundary:** `Content-Length: 65536` passes (`> MAX_BODY_BYTES`, not `>=`). `Content-Length: 65537` is rejected.

**413 response properties:**
- Carries `X-Request-Id` (set at line 153, before the guard)
- Carries all 10 security headers (set at line 154, before the guard)
- Does NOT create session context (`resolvedCtx` remains `null`)
- Does NOT append audit entry
- Does NOT append lifecycle record
- Does NOT consume a rate-limit slot

**Defence-in-depth:** Even if a client omits `Content-Length` or sends a smaller value than the actual body, `readJsonBody()` still enforces the limit on actual streamed bytes via the `size > maxBytes` accumulator check. The dispatch guard is the first line; `readJsonBody()` is the backstop.

**Phase 57 test results** (all run directly on server port 8080, bypassing the Replit proxy which buffers request bodies):

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| 1 | `GET /api/status` with `Content-Length: 100000` (header only, no body) | HTTP 413 | ✅ |
| 2 | `POST /api/tasks` with actual 65537-byte body | HTTP 413 (before body parser) | ✅ |
| 3 | `GET /api/healthz` (no Content-Length) | HTTP 200 | ✅ |
| 4 | `POST /api/tasks` with small body (correct Content-Length) | HTTP 201 (handler accepted) | ✅ |
| 5 | 413 carries `X-Request-Id` | 16-char hex `54d18ccf141f0d50` | ✅ |
| 6 | 413 carries all 10 security headers | 10/10 present | ✅ |
| 7 | Lifecycle record for 413 `requestId` | NOT FOUND (correct — no resolvedCtx) | ✅ |
| 8 | Audit entry for 413 `requestId` | NOT FOUND (correct — no resolvedCtx) | ✅ |
| 9 | `Content-Length: not-a-number` | HTTP 400 (invalid value) | ✅ |
| 10 | `Content-Length: 65536` (exact boundary, `>` not `>=`) | HTTP 200 (passes guard) | ✅ |
| 11 | `POST /api/commands` with actual 65537-byte body | HTTP 413 | ✅ |
| 12 | 413 carries no `X-Correlation-Id` | Absent (session context not created) | ✅ |

**Note on proxy vs direct:** The Replit proxy at `localhost:80` buffers request bodies before forwarding, so large-body tests that rely on declaring `Content-Length` without sending bytes time out at the proxy. Tests 1–12 were run directly on port 8080. The dispatch guard's behaviour is confirmed correct by both the direct test results and the server structured logs.

### Phase 56 — Response Security Header Audit

Infrastructure-only hardening phase — no new endpoints, no new health checks, no new registered subsystems. One file changed: `core/hardening.ts`.

**Goal:** Audit the security headers applied to every response, expand from 5 to 10 headers covering all modern browser protection categories, and surface the active header set in `GET /api/hardening` for machine-verifiable inspection.

**Previous header set (5 headers, pre-Phase 56):**
```
x-content-type-options: nosniff
x-frame-options: DENY
x-xss-protection: 0
referrer-policy: no-referrer
x-permitted-cross-domain-policies: none
```

**Expanded header set (10 headers, Phase 56):**

| Header | Value | Rationale |
|---|---|---|
| `content-security-policy` | `default-src 'none'` | JSON API — blocks all resource loads if body is ever rendered as a document; safe and maximally restrictive |
| `cross-origin-opener-policy` | `same-origin` | Prevents cross-origin window references; isolates the browsing context |
| `cross-origin-resource-policy` | `same-origin` | Prevents other origins from embedding responses as resources; JSON clients use fetch/XHR, governed by CORS |
| `permissions-policy` | `camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()` | Explicitly denies all browser capability grants |
| `referrer-policy` | `no-referrer` | (carried over) No referrer information leaked on outbound requests |
| `strict-transport-security` | `max-age=63072000; includeSubDomains` | Browsers enforce HTTPS for 2 years; harmless over plain HTTP, effective behind TLS proxy |
| `x-content-type-options` | `nosniff` | (carried over) Prevents MIME-type sniffing |
| `x-frame-options` | `DENY` | (carried over) Prevents framing in any context |
| `x-permitted-cross-domain-policies` | `none` | (carried over) Blocks Flash/PDF cross-domain policy files |
| `x-xss-protection` | `0` | (carried over) Disables legacy XSS auditor (which introduced more vulnerabilities than it solved) |

**Why `applySecurityHeaders()` covers all exit paths:**
`applySecurityHeaders()` is called at line 154 of `server.ts`, immediately after `res.setHeader("x-request-id", requestId)` and before any conditional branch. Because Node.js `setHeader()` queues headers and `writeHead()` merges them, the 10 headers are present on every response including 400 (validation), 403 (hardening block), 404 (not found), 405 (method not allowed), 414 (URL too long), 429 (rate limit), and all 2xx handler responses.

**`SECURITY_HEADERS` — single source of truth:**
The constant in `hardening.ts` is the only place security headers are defined. `applySecurityHeaders()` iterates `Object.entries(SECURITY_HEADERS)` — any addition or removal to the constant automatically propagates to every response. No other file sets security headers.

**`GET /api/hardening` — expanded response:**
`getHardeningStatus()` now returns two new fields:
- `activeHeaderCount: number` — `Object.keys(SECURITY_HEADERS).length` — currently `10`
- `securityHeaders: Record<string, string>` — a shallow copy of the `SECURITY_HEADERS` constant

These fields allow machine-verifiable inspection of the active header set without reading source code.

**Phase 56 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| 1 | `GET /api/healthz` (200 success) | All 10 headers present | ✅ ALL 10 |
| 2 | `GET /api/status` (200 authenticated) | All 10 headers present | ✅ ALL 10 |
| 3 | `DELETE /api/healthz` (405 — earliest exit) | All 10 headers present | ✅ ALL 10 |
| 4 | `GET /api/nonexistent` (404 route not found) | All 10 headers present | ✅ ALL 10 |
| 5 | Path traversal hardening block (400) | All 10 headers present | ✅ ALL 10 |
| 6 | `/api/hardening` reports `activeHeaderCount: 10` | `10` | ✅ |
| 7 | `/api/hardening` reports `securityHeaders` object | All 10 entries | ✅ |

### Phase 55 — Request ID Propagation Hardening

Verification and documentation phase — no code changes required. Zero files modified. The `X-Request-Id` response header and full `requestId` propagation were already implemented in the dispatch pipeline (line 153 of `server.ts`). Phase 55 formally verifies and documents this as a named, tested invariant.

**What was already in place before Phase 55:**

| Propagation point | Location | Status |
|---|---|---|
| `X-Request-Id` response header | `dispatch()` — `res.setHeader("x-request-id", requestId)` line 153 | ✅ Present on every response |
| Structured log child | `dispatch()` — `logger.child({ requestId })` line 149 | ✅ All log lines include requestId |
| Audit log entry | `appendAuditEntry({ requestId, ... })` | ✅ requestId in every audit record |
| Session context | `createSessionContext({ requestId, ... })` | ✅ requestId in every session record |
| Lifecycle ledger | `appendLifecycleRecord({ requestId, ... })` | ✅ requestId in every lifecycle record |

**Why Phase 55 verified this as a named invariant:**
The Phase 55 direction from Phase 54's report recommended surfacing `X-Request-Id` as a response header. On inspection, it was already implemented — set unconditionally at the top of `dispatch()` before any branching logic. Phase 55 runs the full exit-path coverage tests to lock in this behavior as a documented guarantee.

**Exit path coverage:**

| Response type | HTTP status | X-Request-Id | X-Correlation-Id | Audit entry | Lifecycle record |
|---|---|---|---|---|---|
| Validation failure (bad method/URL) | 400 / 405 | ✅ | ❌ | ❌ | ❌ |
| Hardening block | 400 / 403 | ✅ | ❌ | ❌ | ❌ |
| Rate limit exceeded | 429 | ✅ | ❌ | ❌ | ❌ |
| Route not found | 404 | ✅ | ✅ | ✅ | ✅ |
| Handler success | 2xx | ✅ | ✅ | ✅ | ✅ |
| Handler error (errorBoundary) | 500 | ✅ | ✅ | ✅ | ✅ |

Pre-session-context rejections (validation, hardening, rate limit) carry `X-Request-Id` but not `X-Correlation-Id`, because the correlation ID is generated inside `createSessionContext()`, which is called after those checks pass.

**`requestId` format:**
16-character lowercase hex string, generated by `randomBytes(8).toString("hex")` in `lib/requestId.ts` via `node:crypto`. Statistically unique per request. Never reused within a server process lifetime.

**Cross-system correlation chain:**
A client that receives an `X-Request-Id: 495121619101607c` header can look up the corresponding server-side records at:
- `GET /api/audit/log` → `entries[].requestId === "495121619101607c"` — access decision, role, route, authSource
- `GET /api/lifecycle/recent` → `records[].requestId === "495121619101607c"` — statusCode, latencyMs, startedAt, finishedAt
- `GET /api/session/recent` → `sessions[].requestId === "495121619101607c"` — actorType, role, permissions

**Phase 55 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| 1 | `GET /api/healthz` | `X-Request-Id` header present | ✅ `b96e7dd5d7dba601` |
| 2 | `GET /api/status` | `X-Request-Id` header present | ✅ |
| 3 | `GET` non-existent route (404) | `X-Request-Id` header present | ✅ |
| 4 | `DELETE /api/healthz` (405, validation failure — earliest exit) | `X-Request-Id` header present | ✅ |
| 5 | `GET /api/status` (regular request) | `X-Request-Id` header present | ✅ |
| 6 | requestId format | 16-char hex, length 16 | ✅ `3a1317654362d206` |
| 7 | requestId in response header matches audit entry | `match: YES` | ✅ |
| 8 | requestId in response header matches lifecycle record | `match: YES` | ✅ |

### Phase 54 — Timing-Safe Key Comparison

Infrastructure-only hardening phase — no new endpoints, no new health checks, no new registered subsystems. Two files changed: `apiKeyAuth.ts`, `diagnostics.ts`.

**Goal:** Replace the naive `rawKey === ownerKey` and `rawKey === serviceKey` string equality checks with constant-time comparison using Node.js `timingSafeEqual` from `node:crypto`. This eliminates a timing side-channel that could allow a patient attacker to reconstruct key material byte-by-byte.

**Why the prior `===` comparison was a vulnerability:**
JavaScript's `===` operator on strings short-circuits at the first non-matching character. This means a submitted key that shares a longer prefix with the configured key takes measurably longer to reject than one that differs on the first byte. Over many requests, an attacker can exploit this timing difference to discover the key one byte at a time.

**`timingSafeCompare()` — the replacement:**
```typescript
function timingSafeCompare(submitted: string, configured: string): boolean {
  if (submitted.length !== configured.length) return false;
  return timingSafeEqual(Buffer.from(submitted), Buffer.from(configured));
}
```

**Length-guard design reasoning:**
`timingSafeEqual` requires both `Buffer` arguments to have the same byte length — it throws a `RangeError` otherwise. The length check (`submitted.length !== configured.length → return false`) is safe because key length is not a secret: the minimum (16) and maximum (256) are documented. Knowing that a submitted key is the wrong length gives no useful information about key content. Within any given length, all comparisons are constant-time.

**`timingSafeComparison: true` — typed literal invariant:**
`ApiKeyAuthStatus` gains a `timingSafeComparison: true` field backed by `const TIMING_SAFE_COMPARISON: true = true`. This is a machine-verifiable guarantee in the diagnostics snapshot that constant-time comparison is active. It is typed as the literal `true`, not `boolean`, so it can never be `false` at compile time.

**`DiagnosticsAuth` — updated shape:**
```json
"auth": {
  "operational": true,
  "ownerKeyConfigured": false,
  "serviceKeyConfigured": false,
  "totalApiKeyRequests": 0,
  "totalValidApiKeyRequests": 0,
  "totalInvalidApiKeyRequests": 0,
  "lastInvalidAt": null,
  "timingSafeComparison": true
}
```

**Phase 54 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| A | Valid owner key resolves owner/owner/api_key | `valid: true, actorType: owner` | ✅ |
| B | Valid service key resolves service/operator/api_key | `valid: true, actorType: service` | ✅ |
| C | Wrong key same length falls back safely | `valid: false, identity: null` | ✅ |
| D | Short key (length mismatch) — no crash | `valid: false` | ✅ |
| E | Oversized key — no crash | `valid: false` | ✅ |
| F | Empty key hits early-return guard | `valid: false` | ✅ |
| G | `timingSafeComparison: true` in `getApiKeyAuthStatus()` | `timingSafeComparison: true` | ✅ |
| H | `timingSafeComparison: true` in live diagnostics snapshot | present and `true` | ✅ |
| I | Owner key value not in `getApiKeyAuthStatus()` JSON | `PASS` | ✅ |
| J | Service key value not in `getApiKeyAuthStatus()` JSON | `PASS` | ✅ |
| K | No key-pattern strings in live diagnostics `auth` field | `PASS` | ✅ |
| L | `timingSafeEqual` no throw on equal-length buffers | `PASS` | ✅ |

### Phase 53 — Vault / Secrets Foundation

Infrastructure-only phase — no new endpoints, no new health checks, no new registered subsystems. Three files changed: `secretVault.ts` (new), `runtime.ts`, `diagnostics.ts`. `.env.example` updated.

**Goal:** Add a metadata-only local secrets vault that tracks which known secrets are configured without storing, logging, or exposing actual values. The vault is observable through the `vault` field added to `GET /api/diagnostics/snapshot`.

**Why no new endpoint or health check:**
The baseline was frozen at Phase 43 with 59 endpoints and 36 health checks. Vault state is fully observable through `DiagnosticsSnapshot.vault` — no additional endpoint is necessary. The vault has no complex failure modes (pure in-memory metadata, trivially initializes) so a dedicated health check adds no diagnostic value.

**Why not a registered subsystem:**
`registerSubsystemState()` is never called from `secretVault.ts`. The subsystem count remains at 26 and graph node count at 26. The vault is an informational metadata layer, not a service component with its own lifecycle or dependency graph participation.

**Vault model — metadata-only, 5 known secrets:**

| Secret name | Category | Source | Configured |
|---|---|---|---|
| `BULLDOZER_OWNER_API_KEY` | auth | env | Checks env at runtime |
| `BULLDOZER_SERVICE_API_KEY` | auth | env | Checks env at runtime |
| `BULLDOZER_STRIPE_SECRET_KEY` | payment | vault_placeholder | Always false |
| `BULLDOZER_OPENAI_API_KEY` | ai | vault_placeholder | Always false |
| `BULLDOZER_WEBHOOK_SECRET` | webhook | vault_placeholder | Always false |

**Source semantics:**
- `"env"` — the secret is expected from the process environment; `configured` reflects `typeof process.env[name] === "string" && process.env[name].length > 0`
- `"vault_placeholder"` — documented future key not yet in use anywhere; `configured` is always `false` regardless of env

**`VaultEntry` interface — 5 metadata fields only:**
```
name         — secret identifier (env var name)
category     — VaultSecretCategory: "auth" | "payment" | "ai" | "webhook" | "internal"
configured   — boolean: true only if source="env" and env var is present and non-empty
source       — VaultSecretSource: "env" | "vault_placeholder"
lastCheckedAt — ISO timestamp of the last status check
```

No `value`, `hash`, `length`, `prefix`, or any derivative of secret content is ever stored.

**`getVaultStatus()` behavior:**
Re-checks `process.env` on every call rather than caching the init-time state. This ensures `lastCheckedAt` is always current and the response reflects real-time configuration state. The raw env value is never captured into a local variable — only `typeof val === "string" && val.length > 0` is computed and then discarded.

**`DiagnosticsSnapshot.vault` shape:**
```json
{
  "operational": true,
  "totalSecrets": 5,
  "configuredCount": 0,
  "unconfiguredCount": 2,
  "placeholderCount": 3,
  "lastCheckedAt": "2026-05-12T20:34:52.000Z",
  "entries": [
    { "name": "BULLDOZER_OWNER_API_KEY", "category": "auth", "configured": false, "source": "env", "lastCheckedAt": "..." },
    { "name": "BULLDOZER_SERVICE_API_KEY", "category": "auth", "configured": false, "source": "env", "lastCheckedAt": "..." },
    { "name": "BULLDOZER_STRIPE_SECRET_KEY", "category": "payment", "configured": false, "source": "vault_placeholder", "lastCheckedAt": "..." },
    { "name": "BULLDOZER_OPENAI_API_KEY", "category": "ai", "configured": false, "source": "vault_placeholder", "lastCheckedAt": "..." },
    { "name": "BULLDOZER_WEBHOOK_SECRET", "category": "webhook", "configured": false, "source": "vault_placeholder", "lastCheckedAt": "..." }
  ]
}
```

**Phase 53 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| A | No keys configured | `configuredCount: 0`, `unconfiguredCount: 2`, `placeholderCount: 3` | ✅ |
| B | Owner key injected into env | `ownerEntry.configured: true`, `configuredCount: 1` | ✅ |
| C | Both keys injected into env | `configuredCount: 2`, placeholder count unchanged at 3 | ✅ |
| D | Placeholder entry ignores env | `STRIPE.configured: false` even with `BULLDOZER_STRIPE_SECRET_KEY` set | ✅ |
| E | No secret values in VaultStatus JSON | No `sk_`, `sk-`, `whsec`, `password`, etc. in output | ✅ PASS |
| F | Entry field count exactly 5 | `Object.keys(entry).length === 5` for all entries | ✅ PASS |
| G | Baseline still intact after vault added | All 6 baseline fields match | ✅ |
| H | executionBlocked still true | `safetyFlags.executionBlocked: true` | ✅ |
| I | Live diagnostics — vault operational | `vault.operational: true` after restart | ✅ |
| J | Leakage check in live diagnostics response | `no-value-leak: PASS` | ✅ |

**`.env.example` additions:**
Three future provider key placeholders added (commented out) with their `vault_placeholder` purpose noted.

### Phase 52 — Real Authentication Foundation

Infrastructure-only phase — no new endpoints, no new health checks, no new registered subsystems. Six files changed: `apiKeyAuth.ts` (new), `identityAccess.ts`, `auditLog.ts`, `runtime.ts`, `server.ts`, `diagnostics.ts`. One new file added: `.env.example`.

**Goal:** Add minimal real authentication using static environment-variable API keys. No users database, no OAuth, no JWT, no external auth providers, no billing, no secrets vault. The foundation sets the pattern and invariants that Phase 53+ will build on.

**Why no new endpoint, health check, or registered subsystem:**
Same reasoning as Phase 51 — the baseline is frozen at 59/36/26/26. `apiKeyAuth.ts` is a dispatch-layer enforcement module, not a service component with an independent lifecycle. Its state is surfaced through the new `auth` field added to `GET /api/diagnostics/snapshot`.

**Authentication model — static environment API keys:**

| Header | Env var | Resolved identity |
|---|---|---|
| `X-API-Key: <owner-key>` | `BULLDOZER_OWNER_API_KEY` | actorType=`owner`, role=`owner`, actorId=`owner`, source=`api_key` |
| `X-API-Key: <service-key>` | `BULLDOZER_SERVICE_API_KEY` | actorType=`service`, role=`operator`, actorId=`service`, source=`api_key` |
| `X-API-Key: <invalid>` | — | falls back to `anonymous/guest`, authSource=`invalid_api_key` |
| No `X-API-Key` | — | dev fallback: `X-Actor-*` headers → `resolveRequestIdentity()` |

**Key validation rules:**
- Minimum length: 16 characters (keys shorter than this are silently ignored at init — `ownerKeyConfigured` stays `false`)
- Maximum length: 256 characters (longer keys silently ignored)
- Comparison: strict equality (`===`) — timing-safe comparison not yet implemented (scheduled for Phase 53)
- Keys read from `process.env` exactly once inside `initApiKeyAuth()`, stored in module-level private `let` variables, never re-read, never logged, never serialized

**Dispatch integration — priority order (after existing validation/hardening):**

```
validateRequest → validateRequestHardening → log
→ read correlationId header
→ if X-API-Key header present and non-empty:
    result = resolveApiKeyIdentity(rawApiKey)
    if result.valid:
      identity = result.identity     (source = "api_key")
      authSource = "api_key"
    else:
      identity = anonymous/guest     (source = "default")
      authSource = "invalid_api_key"
→ else (no X-API-Key):
    identity = resolveRequestIdentity(X-Actor-Id, X-Actor-Type, X-Role)
    authSource = identity.source     ("headers" or "default")
→ rate limit check (uses resolved identity)
→ createSessionContext()
→ validateRouteAccess()
→ appendAuditEntry({ ...authSource })
→ router.resolve() → withErrorBoundary(handler)
```

**Key precedence rule:** When `X-API-Key` is present (even invalid), `X-Actor-*` headers are completely ignored for that request. The `X-Actor-*` dev fallback only applies when `X-API-Key` is absent entirely.

**`core/apiKeyAuth.ts` — new module:**

```typescript
// Module-level private state — keys never exposed
let ownerKey: string | null = null;
let serviceKey: string | null = null;
let ownerKeyConfigured = false;
let serviceKeyConfigured = false;
let totalApiKeyRequests = 0;
let totalValidApiKeyRequests = 0;
let totalInvalidApiKeyRequests = 0;
let lastInvalidAt: string | null = null;

// Exports
initApiKeyAuth()              // called from runtime.ts — reads env once
resolveApiKeyIdentity(key)    // called per-request in dispatch
getApiKeyAuthStatus()         // called from diagnostics.ts
```

`resolveApiKeyIdentity(rawKey)` returns `ApiKeyCheckResult { valid: boolean, identity: ResolvedIdentity | null }`:
- `rawKey === undefined || length === 0` → `{ valid: false, identity: null }` — counts as no-key, NOT an invalid attempt
- Valid owner key match → `{ valid: true, identity: { actorType: "owner", role: "owner", actorId: "owner", source: "api_key" } }`
- Valid service key match → `{ valid: true, identity: { actorType: "service", role: "operator", actorId: "service", source: "api_key" } }`
- Non-empty, non-matching key → `{ valid: false, identity: null }` + increments `totalInvalidApiKeyRequests`, sets `lastInvalidAt`, emits `logger.warn` (no key value in log)

**`authSource` field — new on `AuditEntry` and `AuditEntryInput`:**

Every audit entry now carries an optional `authSource?: string` describing how the request identity was established:

| authSource value | Meaning |
|---|---|
| `"api_key"` | Valid `X-API-Key` matched a configured key |
| `"invalid_api_key"` | `X-API-Key` present but matched no configured key — fell back to anon |
| `"headers"` | No `X-API-Key`; identity resolved from `X-Actor-*` headers (dev mode) |
| `"default"` | No `X-API-Key`, no `X-Actor-*` headers; pure anonymous/guest |

`isValidAuditEntry()` type guard does NOT check `authSource` — it is optional and absent in pre-Phase-52 persisted entries.

**`ResolvedIdentity.source` — extended union:**

Before Phase 52: `"headers" | "default"`
After Phase 52: `"api_key" | "headers" | "default"`

The `"api_key"` value is set exclusively by `resolveApiKeyIdentity()` in `apiKeyAuth.ts`. The `resolveRequestIdentity()` function in `identityAccess.ts` still only produces `"headers"` or `"default"`.

**`DiagnosticsSnapshot.auth` — new field:**

```typescript
auth: {
  operational: boolean;              // true after initApiKeyAuth()
  ownerKeyConfigured: boolean;       // true if BULLDOZER_OWNER_API_KEY valid
  serviceKeyConfigured: boolean;     // true if BULLDOZER_SERVICE_API_KEY valid
  totalApiKeyRequests: number;       // all requests with non-empty X-API-Key
  totalValidApiKeyRequests: number;  // matched a configured key
  totalInvalidApiKeyRequests: number;// non-empty key that matched nothing
  lastInvalidAt: string | null;      // ISO timestamp of last invalid attempt
}
```

**Security invariants — enforced and documented:**
- Key values are NEVER logged at any log level (even `debug`) — `logger.warn` on invalid attempt logs only `executionBlocked: true`
- Key values are NEVER included in any response body, audit entry, session context, or diagnostics field
- Key values are NEVER re-read from `process.env` after `initApiKeyAuth()` completes
- `ownerKeyConfigured` / `serviceKeyConfigured` booleans are the only observable indicators that a key is set
- Invalid key attempts produce a `warn`-level log with no key material, an audit entry with `authSource: "invalid_api_key"`, and an incremented `totalInvalidApiKeyRequests` counter

**Import constraints for `apiKeyAuth.ts`:**
- Allowed: `logger`, `timeline`, `eventBus`, `runtimeEventBus`, `ResolvedIdentity` type from `identityAccess`
- Must never import from: `healthMonitor`, `accessEnforcement`, `auditLog`, `sessionContext`, `requestLifecycleLedger`, `rateLimiter`, `persistentStore`, `runtimeStateRegistry`
- Auth state is NOT persisted across restarts — counters reset to 0 on every startup

**`initApiKeyAuth()` placement in startup sequence:**
```
initRateLimiter() → initApiKeyAuth() → initRuntimeDependencyGraph() → ...
```
Auth has no upstream dependencies on other infrastructure modules. Placed after `initRateLimiter()` for logical grouping.

**Phase 52 test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| A | No API key, no identity headers | `anonymous/guest` | ✅ |
| B | Invalid `X-API-Key` header | HTTP 200, falls back to anon/guest | ✅ HTTP 200 |
| C | Invalid key audit entry has `authSource: "invalid_api_key"` | authSource present, no key value | ✅ |
| D | Diagnostics `auth.totalInvalidApiKeyRequests` increments | `totalInvalid: 1`, `lastInvalidAt: present` | ✅ |
| E | Execute blocked for all roles | All `execute.granted: false` | ✅ |
| F | Invalid key value never in response body | No leakage | ✅ PASS |
| G | Dev `X-Actor-*` fallback works when no `X-API-Key` | actorId propagated | ✅ |
| H | Valid owner key → owner/owner/api_key (unit) | `valid: true, actorType: owner` | ✅ |
| I | Valid service key → service/operator/api_key (unit) | `valid: true, actorType: service` | ✅ |
| J | Key status never in `getApiKeyAuthStatus()` JSON | `key-leaked-in-status: false` | ✅ |

**`.env.example` — new file:**
Documents `BULLDOZER_OWNER_API_KEY` and `BULLDOZER_SERVICE_API_KEY` as optional, with minimum-16-char note. Never committed alongside actual key values.

### Phase 51 — Rate Limiting Foundation

Infrastructure-only phase — no new endpoints, no new health checks, no new registered subsystems. Four files changed: `rateLimiter.ts` (new), `runtime.ts`, `server.ts`, `diagnostics.ts`.

**Goal:** Add lightweight in-memory rate limiting to protect all API endpoints from abuse and overload. Rate limiting is keyed by resolved actor identity (from Phase 50), uses a fixed 60-second window, and surfaces observability state through the existing `GET /api/diagnostics/snapshot` endpoint.

**Why no new endpoint or health check:**
The baseline was frozen at Phase 43 with 59 endpoints and 36 health checks. Adding either would change those live counts and break `baseline.baselineStatus: "intact"`. Rate limiter state is fully observable through the `rateLimit` field added to the diagnostics snapshot — no additional endpoint is necessary. The rate limiter has no complex failure modes (it is a pure in-memory state machine that initializes trivially) so a dedicated health check would add no diagnostic value.

**Why no registered subsystem:**
`registerSubsystemState()` is not called from `rateLimiter.ts`. This preserves the subsystem count at 26 and graph node count at 26. The rate limiter is an internal enforcement module — it is an aspect of the dispatch pipeline, not a service component with its own lifecycle. Its state is surfaced through `DiagnosticsSnapshot.rateLimit` instead.

**Rate limiting model — fixed window per identity key:**

| Dimension | Value |
|---|---|
| Window | 60 seconds (fixed, not sliding) |
| Max identity key slots | 500 (evict oldest on overflow) |
| Exempt paths | `GET /api/healthz` only |
| Error response | HTTP 429 + `Retry-After` header (seconds remaining in window) |
| Overflow eviction | FIFO — oldest key removed when `buckets.size >= MAX_IDENTITY_KEYS` |

**Per-identity bucket limits (requests per 60-second window):**

| Identity | Limit |
|---|---|
| `anonymous:guest` or any `anonymous:*` | 60 |
| `service:viewer` or any `*:viewer` | 120 |
| `service:operator` or any `*:operator` | 300 |
| `*:admin`, `owner:*`, `system:*` | 600 |

Limit selection: `resolveLimit(actorType, role)` — `owner` or `system` actorType → 600 immediately; otherwise role-driven: admin=600, operator=300, viewer=120, guest=60.

**Identity key formation:**
- When `X-Actor-Id` header was present and valid (non-empty, ≤128 chars): `id:<actorId>` — per-actor isolation.
- Otherwise: `<actorType>:<role>` (e.g., `anonymous:guest`) — class-level bucket. All unauthenticated callers sharing the same actorType/role share one bucket.

**Dispatch integration (placement in `server.ts`):**

```
validateRequest → validateRequestHardening → log
→ read correlationId header
→ read identity headers → resolveRequestIdentity()
→ if path !== "/api/healthz":
    checkRateLimit(actorType, role, actorId)
    if !allowed: set Retry-After, sendError(429), return   ← EARLY EXIT
→ createSessionContext()
→ validateRouteAccess()
→ appendAuditEntry()
→ router.resolve() → withErrorBoundary(handler)
```

Rate-limited requests exit before `createSessionContext()`. This means:
- `resolvedCtx` stays `null` → `res.on("finish")` skips `appendLifecycleRecord`, `completeSessionLifecycle`, `updateAuditEntryLifecycle`
- No session context entry is created for rate-limited requests (avoids buffer pollution under attack)
- No audit entry is created (same reason)
- `incrementRequests()` still fires (the request WAS received)
- Security headers and `x-request-id` are still set (applied before the rate check)
- Blocked event is logged at `warn` level with `identityKey`, `requestCount`, `windowLimit`, `retryAfterSec`

**`core/rateLimiter.ts` — new module:**

```typescript
// Module-level state
const buckets = new Map<string, Bucket>();
const keyInsertionOrder: string[] = [];
let totalRequestsChecked = 0;
let totalBlocked = 0;
let lastBlockedAt: string | null = null;
let lastBlockedKey: string | null = null;

// Exports
initRateLimiter()         // called from runtime.ts startup
checkRateLimit()          // called per-request in dispatch
getRateLimiterStatus()    // called from diagnostics.ts
```

`checkRateLimit()` is the hot path — it runs on every non-healthz request. It is O(1) in all cases: Map lookup, insertion-order array push/shift, no iteration. No async operations, no disk I/O, no external calls.

**`Bucket` structure:**
```typescript
interface Bucket {
  windowStart: number;   // epoch ms when current window started
  count: number;         // requests this window (includes blocked)
  blockedCount: number;  // requests blocked this window
  lastBlockedAt: string | null;
}
```

Window reset: `if (now - bucket.windowStart >= WINDOW_MS) { windowStart = now; count = 0; }` — `blockedCount` and `lastBlockedAt` are NOT reset on window expiry (they are per-bucket lifetime counters, not per-window).

**`DiagnosticsSnapshot.rateLimit` — new field:**
```typescript
rateLimit: {
  operational: boolean;
  windowMs: number;          // 60000
  maxIdentityKeys: number;   // 500
  activeKeys: number;        // current Map size
  totalRequestsChecked: number;
  totalBlocked: number;
  lastBlockedAt: string | null;
  lastBlockedKey: string | null;
}
```

**Import constraints for `rateLimiter.ts`:**
- Imports allowed: `logger`, `timeline` (`addTimelineEvent`), `eventBus` (`emit`), `runtimeEventBus` (`emitRuntimeEvent`)
- Must never import from: `healthMonitor`, `accessEnforcement`, `auditLog`, `sessionContext`, `requestLifecycleLedger`, `persistentStore`, `runtimeStateRegistry`
- Rate limiter state is NOT persisted across restarts — buckets reset on every startup. This is intentional: a restart resets rate limit windows, which is acceptable for this foundation layer.

**`initRateLimiter()` placement in startup sequence:**
```
initSessionContext() → initRequestLifecycleLedger() → initRateLimiter() → initRuntimeDependencyGraph() → ...
```
Rate limiter has no upstream dependencies. Its position after `initRequestLifecycleLedger()` is chosen for readability grouping — it could equally be placed anywhere after `initRuntimeEventBus()` (for emitRuntimeEvent).

**Rate limit test results:**

| Test | Scenario | Expected | Actual |
|---|---|---|---|
| A | 101 hits to `GET /api/healthz` (no headers) | All 200 (exempt) | ✅ HTTP 200 |
| B | 65 rapid hits to `/api/status` (anon/guest, limit=60) | ~60 allowed, ~5 blocked | ✅ 55 allowed, 10 blocked* |
| C | `service:operator` request after anon block | 200 (separate bucket) | ✅ HTTP 200 |
| D | `owner` with actorId after anon block | 200 (separate bucket) | ✅ HTTP 200 |
| E | 429 response includes `Retry-After` header | Header present with seconds | ✅ `Retry-After: 42` |
| F | Diagnostics snapshot shows rate limit state | `operational:true, totalBlocked>0` | ✅ `totalBlocked:13, lastBlockedKey:anonymous:guest` |
| G | Execute blocked for all roles | All `execute.granted:false` | ✅ Confirmed |
| H | Anon bucket still exhausted after block | 429 | ✅ HTTP 429 |
| I | `service:viewer` and `service:admin` in fresh buckets | 200 | ✅ HTTP 200 |

*Test B allowed=55, blocked=10 (not 60/5) because the verification sweep (parallel bash block) had already consumed 5 anon:guest bucket slots before the 65-request burst. Total correct: 55+5=60 allowed before blocking.

### Phase 50 — Actor Identity Enrichment

Infrastructure-only phase — no new endpoints, no new health checks, no new subsystems. Four files changed: `identityAccess.ts`, `sessionContext.ts`, `auditLog.ts`, `server.ts`.

**Goal:** Enrich every request with structured actor identity propagated from three optional HTTP request headers. Session context, audit log, and access enforcement checks now carry real actor identity instead of a constant `anonymous/guest` placeholder. Headers are untrusted convenience metadata — no authentication, no tokens, no secrets.

**Three new optional headers:**

| Header | Validated against | Fallback |
|---|---|---|
| `X-Actor-Id` | Non-empty string, max 128 chars | `undefined` (omitted from records) |
| `X-Actor-Type` | `"system"`, `"owner"`, `"service"`, `"anonymous"` | `"anonymous"` |
| `X-Role` | `"owner"`, `"admin"`, `"operator"`, `"viewer"`, `"guest"` | `"guest"` |

**What changed — four files:**

**1. `identityAccess.ts`** — two new exports:
- `ResolvedIdentity` interface: `{ actorId: string | undefined, actorType: ActorType, role: Role, source: "headers" | "default" }`. `source` is `"headers"` when at least one identity header was present in the request (even if some fell back), `"default"` when no identity headers were present at all.
- `resolveRequestIdentity(rawActorId, rawActorType, rawRole)` — pure function, no throws, no side effects, no logging. Validates `actorType` against `VALID_ACTOR_TYPE_SET` (a module-level `Set<string>`, O(1) lookup). Validates `role` against `VALID_ROLE_SET` (same pattern). Sanitizes `actorId`: must be non-empty string, max 128 chars — silently strips to `undefined` if invalid. Never rejects a request. Returns `ResolvedIdentity`.
- Two new module-level constants: `VALID_ACTOR_TYPE_SET = new Set(ACTOR_TYPES)`, `VALID_ROLE_SET = new Set([...])`. Built once at load time, reused per request.

**2. `sessionContext.ts`** — three changes:
- `SessionContext` interface: gains optional `actorId?: string` field. All other fields unchanged.
- `SessionContextInput` interface: gains three optional fields — `actorType?: ActorType`, `role?: Role`, `actorId?: string`. Callers that don't provide them continue to get the `anonymous/guest` defaults.
- `createSessionContext()` body: `actorType` is now `input.actorType ?? resolveActorType()`. `role` is now `input.role ?? resolveRole()`. `actorId` is spread into the context object only when `input.actorId !== undefined` (preserves optionality). `resolveActorType()` and `resolveRole()` still exist as the fallback path — only called when the input does not supply a value.
- `isValidSessionContext()` type guard: unchanged. The new `actorId?` field is optional and not required for restore validation.

**3. `auditLog.ts`** — two interface changes + one construction change:
- `AuditEntry` interface: gains optional `actorType?: string` and `actorId?: string` fields between `role` and `permission`.
- `AuditEntryInput` interface: same two optional fields added.
- `appendAuditEntry()` body: spreads `actorType` and `actorId` into the new entry object only when defined (uses `...(input.actorType !== undefined ? { actorType: input.actorType } : {})` pattern — keeps optional fields absent rather than `undefined`-present).
- `isValidAuditEntry()` type guard: unchanged. Optional fields are not checked — pre-Phase-50 audit entries restored from disk (which lack these fields) remain valid.

**4. `server.ts`** — three changes to the `dispatch()` function:
- New import: `import { resolveRequestIdentity } from "./core/identityAccess"`.
- Header reading (three lines after `correlationId` resolution): reads `req.headers["x-actor-id"]`, `req.headers["x-actor-type"]`, `req.headers["x-role"]`. Coerces each to `string | undefined` with a `typeof === "string"` guard (HTTP headers can be `string | string[]` per Node.js types — this guard safely handles the array case by treating it as absent).
- `createSessionContext()` call: now passes `actorType: identity.actorType`, `role: identity.role`, `actorId: identity.actorId` alongside the existing `requestId`, `method`, `route`, `correlationId` fields.
- `appendAuditEntry()` call: now passes `actorType: sessionCtx.actorType` and `actorId: sessionCtx.actorId` alongside the existing fields.

**Access enforcement propagation (implicit):**
`validateRouteAccess(method, path, sessionCtx.role)` already takes the role as a parameter — no change needed. Since `sessionCtx.role` now reflects the header-resolved role (or the `"guest"` fallback), the access enforcement check automatically uses the correct identity. The access validation result and its `reason` string now reference the actual role from the header.

**Identity invariants that remain unchanged:**
- `executionBlocked: true` — typed as literal `true` on all interfaces. The identity enrichment does not add, modify, or conditionally set this flag. All 5 roles have `execute.blocked: true` and `execute.granted: false` in the role definitions.
- `authEnabled: false` — unchanged on `IdentityAccessStatus` and `SessionContextStatus`. Headers are explicitly not authentication.
- Enforcement mode: `"observe"` — unchanged. No request is rejected based on role.
- `ACTOR_TYPES` constant, `ROLE_DEFINITIONS` constant — both unchanged. No new types or roles added.

**Circular dependency rules respected:**
- `server.ts` now imports from `identityAccess.ts` directly. This is safe: `identityAccess.ts` does not import from `server.ts` or any module that does. The call graph is: `server.ts` → `identityAccess.ts` → `runtimeStateRegistry`, `logger`, `timeline`, `eventBus`, `runtimeEventBus`.
- `sessionContext.ts` already imported from `identityAccess.ts` (for `ActorType`, `Role`, `PermissionEntry`, `listRoleDefinitions()`). No new import paths introduced.
- `auditLog.ts` does not import from `identityAccess.ts` — `actorType` and `actorId` are typed as `string` in `AuditEntry`/`AuditEntryInput`, not as `ActorType`/`Role` from `identityAccess.ts`. This preserves the existing import boundary: `auditLog.ts` must not import from `accessEnforcement.ts` or `healthMonitor.ts`, and does not need to import from `identityAccess.ts` for untyped string fields.

**Identity propagation verification tests:**

| Test | Headers sent | Expected | Actual |
|---|---|---|---|
| No headers | (none) | `anonymous/guest/undefined` | ✅ `anonymous/guest/undefined` |
| Valid owner | `X-Actor-Type: owner`, `X-Role: owner`, `X-Actor-Id: actor-001` | `owner/owner/actor-001` | ✅ `owner/owner/actor-001` |
| Invalid actorType | `X-Actor-Type: hacker`, `X-Role: owner` | `anonymous/owner/undefined` | ✅ `anonymous/owner/undefined` |
| Invalid role | `X-Actor-Type: service`, `X-Role: superuser` | `service/guest/undefined` | ✅ `service/guest/undefined` |
| Valid service/operator | `X-Actor-Type: service`, `X-Role: operator`, `X-Actor-Id: svc-monitoring` | `service/operator/svc-monitoring` | ✅ `service/operator/svc-monitoring` |
| Execute blocked (all roles) | — | all roles: `execute.granted: false, execute.blocked: true` | ✅ confirmed |
| actorId >128 chars | `X-Actor-Id: x*200`, `X-Actor-Type: owner`, `X-Role: admin` | `actorId: undefined (stripped)` | ✅ `actorId: undefined` |

Session context and audit log both carry the resolved identity. Access enforcement checks use the resolved role. Execute remains globally blocked regardless of identity.

### Phase 49 — Structured Shutdown Drain

Infrastructure-only phase — no new endpoints, no new health checks, no new subsystems. One file changed: `shutdown.ts`.

**Goal:** Ensure in-flight requests can complete their full lifecycle — including `res.on("finish")` and the resulting persistence flush — before the process exits on SIGTERM or SIGINT. Eliminate the possibility of truncated lifecycle ledger entries at shutdown.

**Root cause of the prior behavior:**
`server.close()` stops accepting new connections and waits for all existing connections to close. However, HTTP/1.1 keep-alive connections that are idle (no active request) are not immediately closed — they remain open until the client's keep-alive timeout expires. This means `server.close()` could block for seconds even when no in-flight work exists, and in pathological cases could hold up shutdown long enough for the hard-kill timer to fire and truncate any last in-flight lifecycle entry.

**What changed — three-layer drain sequence:**

1. **`server.closeIdleConnections()`** — called immediately at shutdown start, before `server.close()`. Drops all idle keep-alive connections right away. After this call, the only remaining connections are those with an active in-flight request. This is what caused the test process to exit in 100 ms: no active requests were in-flight, so all connections were idle and were closed instantly.

2. **5-second drain window (`DRAIN_TIMEOUT_MS = 5_000`)** — a `setTimeout` that fires `server.closeAllConnections()` after 5 seconds. This is the soft bound: any request that has not completed within the drain window is force-closed, allowing its connection to be torn down and `server.close()` to call its callback. The drain timer is `.unref()`-ed so it does not hold the event loop open if everything else has already finished. `clearTimeout(drainTimer)` is called inside the `server.close()` callback — if all connections close before 5 seconds (the normal path), the drain timer is cancelled and the process exits cleanly at `process.exit(0)`.

3. **10-second hard kill (`SHUTDOWN_TIMEOUT_MS = 10_000`, unchanged)** — `setTimeout` → `process.exit(1)`. Fires unconditionally after 10 seconds regardless of connection state. This is the absolute failsafe. Also `.unref()`-ed.

**Timer independence:** The two timers (`hardKillTimer` and `drainTimer`) are independent. In the normal path: `closeIdleConnections()` fires → all connections close → `server.close()` callback fires → `clearTimeout(drainTimer)` → `process.exit(0)`. The hard kill never fires. In the slow-request path: `closeIdleConnections()` fires → one request still in-flight → `server.close()` waits → `drainTimer` fires at 5 s → `closeAllConnections()` → connection closes → `res.on("finish")` fires → lifecycle record flushed → `server.close()` callback fires → `clearTimeout(drainTimer)` (no-op, already fired) → `process.exit(0)`.

**Why `res.on("finish")` and persistence are safe:**
`appendLifecycleRecord()` — called in the `res.on("finish")` handler — is synchronous. After the response bytes are sent, `res.on("finish")` fires, `appendLifecycleRecord()` runs, `flushLifecycleLedger()` calls `writeStore()` (synchronous atomic write), and the record is on disk. This all happens before the connection is closed and before `server.close()` calls its callback. The 5-second drain window gives in-flight requests enough time to complete and flush, even under high latency.

**Shutdown timeline event:**
A second `addTimelineEvent` call emits a `"Drain window started"` event immediately after `closeIdleConnections()`, with `drainTimeoutMs` in the metadata. If the drain window expires (rare), a `warn`-level timeline event is emitted before `closeAllConnections()`.

**New constants:**
- `DRAIN_TIMEOUT_MS = 5_000` — soft drain window before force-close of remaining connections.
- `SHUTDOWN_TIMEOUT_MS = 10_000` — unchanged from prior implementation.

**`shutdown.ts` still must never import from `healthMonitor.ts`** — no change to import rules. The new import graph is identical to the prior one.

**Verified test (SIGTERM drain test):**
- Pre-SIGTERM: 50 lifecycle records in buffer.
- `kill -SIGTERM <pid>` sent.
- Process exited after 1 × 100 ms interval (effectively immediate — all connections were idle).
- Post-exit storage file: **52 records, 0 incomplete**. All records have `statusCode`, `latencyMs`, `finishedAt`, `startedAt`, `executionBlocked: true`. `latencyMs` range: 2–600 ms.
- After workflow restart: 53 records restored correctly (52 from disk + 1 from first request).

### Phase 48 — GOTCHAS.md Extraction

Documentation-only phase — no source code changes, no new endpoints, no new health checks, no new subsystems.

**Goal:** Reduce `replit.md` from 266 lines to 189 lines by moving the 78-entry Gotchas section into a dedicated `GOTCHAS.md` file. Improve navigability and reduce scroll distance to the session checkpoint table.

**Files changed:**
- `GOTCHAS.md` — created (84 lines). Contains the full Gotchas section verbatim plus a header and intro sentence.
- `replit.md` — trimmed (266 → 189 lines). The `## Gotchas` heading remains as a navigational anchor; the body is replaced with a one-line pointer to `GOTCHAS.md`. The header reference block gains a fourth line pointing to `GOTCHAS.md`.
- `NUCLEUS_LOCK.md` — no changes (no reference to Gotchas section existed).
- `ARCHITECTURE.md` — no changes.

All 78 bullet points preserved verbatim. No rule was altered, reworded, or omitted.

### Phase 47 — Lifecycle Ledger Persistence

Infrastructure-only phase — no new endpoints, no new health checks, no new subsystems. One file changed: `requestLifecycleLedger.ts`.

**Goal:** Request lifecycle records survive process restarts. The 500-entry ring buffer is preserved across restart cycles by flushing to the persistent key-value store after every `appendLifecycleRecord()` call and restoring at init time. `slowRequestCount` is correctly reconstructed from restored data.

**New constants:**
- `PERSIST_LIMIT = 500` — matches `MAX_RECORDS`. All 500 entries are eligible for persistence. At ~400–500 bytes per record with 2-space JSON indentation, 500 entries ≈ 200–250 KB — safely under the 512 KB `writeStore` limit.
- `STORE_KEY = "lifecycle-ledger"` — key name in the persistent store.

**New private function `isValidLifecycleRecord(obj: unknown): obj is LifecycleRecord`:**
Type guard. Validates: `id`, `requestId`, `correlationId`, `method`, `route`, `startedAt`, `finishedAt` are all `string`; `statusCode` is a finite `number`; `latencyMs` is a finite `number >= 0`; `executionBlocked === true` (strict equality). Invalid objects — wrong shape, missing fields, wrong types, `executionBlocked !== true`, negative latency, non-finite numbers, non-objects — are silently skipped. Non-array stored values are silently skipped.

**Phase 47 type guard vs Phases 45–46 — extra numeric validations:**
Unlike `AuditEntry` and `SessionContext`, `LifecycleRecord` carries `statusCode` (integer) and `latencyMs` (non-negative float). The type guard adds `Number.isFinite()` and `>= 0` checks for both numeric fields. This prevents records with `NaN`, `Infinity`, or negative latency from being restored into a buffer that feeds live percentile calculations and `slowRequestCount`.

**New private function `flushLifecycleLedger(): void`:**
Calls `writeStore(STORE_KEY, ledger.slice(-PERSIST_LIMIT))`. Wrapped in try/catch — if `writeStore` throws (e.g., disk full), logs a warning and continues. Never rethrows. Never blocks `appendLifecycleRecord()`.

**Modified `initRequestLifecycleLedger()`:**
After `registerSubsystemState()` and before `isOperational = true`: reads `readStore<unknown>(STORE_KEY)`, validates each element with `isValidLifecycleRecord()`, pushes valid entries into `ledger` (up to `MAX_RECORDS = 500`). **Key difference from Phases 45–46:** for each restored record where `latencyMs >= SLOW_REQUEST_THRESHOLD_MS (500)`, `slowRequestCount` is incremented. This reconstructs the slow-request counter to match the state of the restored buffer, exactly mirroring the live `appendLifecycleRecord()` path. Sets `restoredCount`. All three event payloads include `restoredCount`. Logger line includes `persistLimit`. Init order in `runtime.ts` guarantees `initPersistentStore()` (line 98) runs before `initRequestLifecycleLedger()` (line 114).

**Modified `appendLifecycleRecord()`:**
`flushLifecycleLedger()` called at the end of the function — after `ledger.push(record)`, after the `slowRequestCount++` path, after the ring-buffer eviction path (`ledger.shift()` with `slowRequestCount` decrement). All counter state is fully updated before flush. Pre-operational calls are unaffected by the `if (!isOperational) return` guard.

**`slowRequestCount` eviction correctness:** When a restored record with `latencyMs >= 500ms` is eventually evicted by `ledger.shift()` as new records arrive, the eviction path checks `evicted.latencyMs >= SLOW_REQUEST_THRESHOLD_MS` and decrements `slowRequestCount`. Restored records carry their original numeric `latencyMs` values (validated by the type guard), so this path is correct.

**Import safety:** `requestLifecycleLedger.ts` must never import from `healthMonitor.ts`, `sessionContext.ts`, `accessEnforcement.ts`, or `auditLog.ts` (these rules predate Phase 47 and are unchanged). Adding `persistentStore` is safe — `persistentStore.ts` imports `eventBus`, `timeline`, `runtimeEventBus`, `config` — no path back to `requestLifecycleLedger.ts`.

**Malformed data handling (verified):**
1. Non-array JSON (`"this is not an array"`) → `Array.isArray()` false → 0 entries restored → server starts cleanly, `{"status":"ok"}`.
2. Mixed array (3 valid, 4 invalid: `id` not string, negative `latencyMs`, `executionBlocked: false`, bare string element) → type guard filters → exactly 3 valid entries restored. The 600 ms slow record was correctly included in `slowRequestCount = 1` post-restore — confirmed via live `GET /api/lifecycle/status` and the `request_lifecycle_ledger` health check (`warn: Slow requests detected — 1 record(s) exceed 500ms threshold, p95: 600ms`).
3. Both cases: all 36 health checks pass with 0 failures, baseline intact.

**Persistent store key inventory after Phase 47:**

| Key | Owner | Max entries | Est. size |
|---|---|---|---|
| `audit-log` | `auditLog.ts` | 500 | ~500 KB |
| `session-context` | `sessionContext.ts` | 200 | ~200 KB |
| `lifecycle-ledger` | `requestLifecycleLedger.ts` | 500 | ~250 KB |

### Phase 46 — Session Context Persistence

Infrastructure-only phase — no new endpoints, no new health checks, no new subsystems. One file changed: `sessionContext.ts`.

**Goal:** Session context entries survive process restarts. The 200-entry ring buffer is preserved across restart cycles by flushing to the persistent key-value store on every new session creation and restoring at init time.

**New constants:**
- `PERSIST_LIMIT = 200` — matches `MAX_SESSIONS`. All 200 entries are eligible for persistence. At ~1 KB per entry (with `permissions` array embedded), 200 entries ≈ 200 KB — safely under the 512 KB `writeStore` limit.
- `STORE_KEY = "session-context"` — key name in the persistent store.

**New private function `isValidSessionContext(obj: unknown): obj is SessionContext`:**
Type guard. Validates: `id`, `requestId`, `correlationId`, `actorType`, `role`, `route`, `method`, `timestamp` are all `string`; `permissions` is an `Array`; `executionBlocked === true` (strict equality). Invalid objects — wrong shape, missing fields, wrong types, `executionBlocked !== true`, non-objects — are silently skipped. Non-array stored values are silently skipped.

**New private function `flushSessionContext(): void`:**
Calls `writeStore(STORE_KEY, sessionBuffer.slice(-PERSIST_LIMIT))`. Wrapped in try/catch — if `writeStore` throws (e.g., disk full), logs a warning and continues. Never rethrows. Never blocks `createSessionContext()`.

**Modified `initSessionContext()`:**
After `registerSubsystemState()` and before `isOperational = true`: reads `readStore<unknown>(STORE_KEY)`, validates each element with `isValidSessionContext()`, pushes valid entries into `sessionBuffer` (up to `MAX_SESSIONS = 200`). Sets `restoredCount`. All three event payloads include `restoredCount`. Logger line includes `persistLimit`. Init order in `runtime.ts` guarantees `initPersistentStore()` (line 98) runs before `initSessionContext()` (line 113) — no changes to `runtime.ts` required.

**Modified `createSessionContext()`:**
`flushSessionContext()` called inside the existing `if (isOperational)` block, after `sessionBuffer.push(ctx)`. Ring-buffer capacity (`MAX_SESSIONS = 200`) is unchanged. `createSessionContext()` continues to always return a valid `SessionContext` regardless of persistence state. Pre-operational calls (before `initSessionContext()`) are unaffected — they return a context without buffering or flushing. `completeSessionLifecycle()` does not trigger a flush.

**Import safety:** `sessionContext.ts` must never import from `healthMonitor.ts`, `accessEnforcement.ts`, or `auditLog.ts`. Adding `persistentStore` is safe — `persistentStore.ts` imports `eventBus`, `timeline`, `runtimeEventBus`, `config` — no path back to `sessionContext.ts`.

**Malformed data handling (verified):**
1. Non-array JSON (`"not an array"`) → `Array.isArray()` false → 0 entries restored → server starts cleanly, `{"status":"ok"}`.
2. Mixed array (3 valid, 3 invalid: wrong `id` type, `executionBlocked: false`, non-object string) → type guard filters → exactly 3 valid entries restored.
3. Both cases: all 36 health checks pass, 0 failures, baseline intact.

### Phase 45 — Audit Log Persistence

Infrastructure-only phase — no new endpoints, no new health checks, no new subsystems. One file changed: `auditLog.ts`.

**Goal:** Audit entries survive process restarts. The 1000-entry ring buffer is preserved across restart cycles by flushing to the persistent key-value store on every append and restoring at init time.

**New constants:**
- `PERSIST_LIMIT = 500` — maximum entries written to disk per flush. Caps serialized payload safely under the 512 KB `writeStore` limit (500 × ~500 bytes ≈ 250 KB).
- `STORE_KEY = "audit-log"` — key name in the persistent store.

**New private function `isValidAuditEntry(obj: unknown): obj is AuditEntry`:**
Type guard. Validates that each restored object has all required string fields (`id`, `timestamp`, `requestId`, `correlationId`, `method`, `route`, `role`, `permission`, `minimumRole`, `reason`, `enforcementMode`), a valid `AuditDecision` enum value, and `executionBlocked === true` (strict equality). Invalid objects — wrong shape, missing fields, wrong types, `executionBlocked !== true` — are silently skipped. Non-array stored values are also silently skipped (guards against corrupted files).

**New private function `flushAuditLog(): void`:**
Calls `writeStore(STORE_KEY, buffer.slice(-PERSIST_LIMIT))`. Wrapped in try/catch — if `writeStore` throws (e.g., disk full, value too large), logs a warning and continues. Never rethrows. Never blocks the append path.

**Modified `initAuditLog()`:**
After `registerSubsystemState()` and before setting `isOperational = true`: reads `readStore<unknown>(STORE_KEY)`, validates the value with `isValidAuditEntry()` per element, pushes valid entries into `buffer` (up to `MAX_ENTRIES = 1000`). Sets `restoredCount`. All three event payloads (`addTimelineEvent`, `emit`, `emitRuntimeEvent`) include `restoredCount`. Logger line includes `persistLimit`. Init order in `runtime.ts` guarantees `initPersistentStore()` (line 98) runs before `initAuditLog()` (line 112) — no changes to `runtime.ts` required.

**Modified `appendAuditEntry()`:**
Calls `flushAuditLog()` after `buffer.push(entry)`. Ring-buffer capacity (`MAX_ENTRIES = 1000`) is unchanged. Every HTTP request that completes an access check triggers one synchronous atomic rename flush. `updateAuditEntryLifecycle()` does not trigger a flush — the lifecycle of the most recent entry is picked up on the next request's flush.

**Import safety:** `persistentStore.ts` → `eventBus`, `timeline`, `runtimeEventBus`, `config` — no path back to `auditLog.ts`. No circular dependency. `auditLog.ts` still has zero imports from `healthMonitor.ts` or `accessEnforcement.ts`.

**Malformed data handling (verified):**
1. Non-array JSON in store (`"this is not an array"`) → `Array.isArray()` returns false → 0 entries restored → server starts cleanly.
2. Array with mixed valid/invalid entries (3 valid, 3 invalid — wrong id type, `executionBlocked: false`, non-object element) → type guard filters → only 3 valid entries restored.
3. Both cases: `GET /api/healthz` returns `{"status":"ok"}`, 36 health checks pass, 0 failures.

### Phase 44 — Cloud Migration Preparation

Infrastructure-only phase — no new endpoints, no new health checks, no new subsystems, no new capability records. All changes are configuration portability and deployment artefacts.

**Code changes (6 files):**

`config.ts` — added `storageDir: string` field. Reads `process.env["STORAGE_DIR"]`; defaults to `join(process.cwd(), "storage")`. Added `import { join } from "node:path"`. `storageDir` is the single canonical base used by all storage modules.

`snapshotStorage.ts` — replaced `join(process.cwd(), "storage", "snapshots")` with `join(config.storageDir, "snapshots")`. Added `import { config } from "./config"`.

`runtimeState.ts` — replaced `join(process.cwd(), "storage", "runtime-state")` with `join(config.storageDir, "runtime-state")`. Added `import { config } from "./config"`.

`taskPersistence.ts` — removed `import { fileURLToPath } from "node:url"` and `const __dirname = path.dirname(fileURLToPath(import.meta.url))`. That pattern resolved incorrectly in production ESM bundles on non-Replit systems (`dist/../../storage/tasks` becomes `/storage/tasks` outside the workspace). Replaced with `path.join(config.storageDir, "tasks")`. Added `import { config } from "./config"`.

`runtimeSnapshot.ts` — replaced `join(process.cwd(), "storage", "runtime-snapshots")` with `join(config.storageDir, "runtime-snapshots")`. Added `import { config } from "./config"`.

`persistentStore.ts` — replaced `join(process.cwd(), "storage", "store")` with `join(config.storageDir, "store")`. Added `import { config } from "./config"`.

**New deployment files (5):**

`Dockerfile` — two-stage build (builder: node:24-alpine + pnpm, runner: node:24-alpine non-root user `bulldozer:1001`). Builder installs deps with `pnpm install --frozen-lockfile --filter @workspace/api-server...`, then runs `pnpm --filter @workspace/api-server run build` to produce `dist/index.mjs`. Runner copies only the bundle, creates `/app/storage`, runs as non-root. `HEALTHCHECK` uses `wget` to poll `/api/healthz`. `CMD ["node", "--enable-source-maps", "./dist/index.mjs"]`.

`docker-compose.yml` — single service `api-server`, named volume `storage` mounted at `/app/storage`, `env_file: .env`, `restart: unless-stopped`, `healthcheck` every 30 s. Log driver `json-file` with rotation (50 MB × 5 files).

`.env.example` — documents all env vars: `PORT` (required), `SESSION_SECRET` (required), `STORAGE_DIR` (optional, default `<cwd>/storage`), `NODE_ENV`, `LOG_LEVEL`, `HOST_PORT`. Includes generation command for `SESSION_SECRET`.

`.dockerignore` — excludes `node_modules`, `dist/`, `storage/`, `.env`, `.replit*`, `.git`, IDE files, temp files.

`DEPLOYMENT.md` — full deployment reference: Docker Compose quick start, manual Docker build, direct Node.js with systemd unit file, Nginx reverse proxy config, storage layout and sizing, health verification curl commands, 20-item cloud migration checklist, security notes.

TypeScript typecheck: clean. All 6 storage modules continue to resolve paths correctly. Default behaviour (no `STORAGE_DIR` set) is identical to pre-Phase-44 (`join(process.cwd(), "storage")`). Baseline: phase 43, intact, all 6 fields match.

### Phase 43 — Persistent Storage Foundation

New storage subsystem — atomic JSON key-value store backed by `storage/store/`. Created `src/core/persistentStore.ts`: key validation regex `/^[a-zA-Z0-9_-]+$/`, max 64-char key, max 100 keys, max 512 KB per value. Functions: `initPersistentStore()` — `mkdirSync(STORE_DIR, { recursive: true })`, sets `operational = true`, emits `persistent_store:initialized` to eventBus + timeline + runtimeEventBus (category: "persistence"). `readStore<T>(key): T | null` — `existsSync` + `readFileSync` + `JSON.parse`, null on miss or parse error. `writeStore<T>(key, value): void` — `JSON.stringify` → `.tmp` file → `renameSync` (atomic POSIX rename). `deleteStore(key): void` — `unlinkSync` if exists. `listStoreKeys(): string[]` — `readdirSync` filtered to `.json` non-tmp files, `basename` without extension. `getPersistentStoreStatus(): PersistentStoreStatus` — `{ operational, subsystemName: "persistent_store", storeDir, keyCount, keys, bytesUsed, maxKeys, executionBlocked: true, recoveryBlocked: true, initializedAt }`. No imports from healthMonitor, accessEnforcement, auditLog, sessionContext, requestLifecycleLedger. Created `src/routes/storage.ts`: `handleStorageStatus` → `GET /api/storage/status`. Boot: `initPersistentStore()` called in `runtime.ts` after `startWatchdog()`, before `initRuntimeStatePersistence()`. Registry: `persistent_store` added to `SEED_SUBSYSTEMS` (category: "infrastructure", dependencies: ["runtime"]). Capability matrix: `persistent_store` record added (read: ["node:fs"], write: ["node:fs", "storage:store", "event_bus", "timeline", "runtime_event_bus"]); `"storage:store"` added to `VALID_INFRASTRUCTURE_REFS`. Health check `persistent_store` (check 36): pass when operational and keyCount < 80% of maxKeys; warn when keyCount ≥ 80/100; fail when not initialized. Access policy: `GET /api/storage/status` (read/viewer). Counts updated: BASELINE_HEALTH_CHECK_COUNT / HEALTH_CHECK_COUNT / HEALTH_CHECKS_TOTAL all 35 → 36. `BASELINE_LOCK.json` sealed at phase 43: 59 endpoints, 36 checks, 26 subsystems, 26 nodes, 0 cycles, 0 invalid refs. TypeScript typecheck: clean. Verification: health/full 36 checks / 0 failures / 5 structural warns; persistent_store pass; baseline intact; graph 26 nodes / 0 cycles; caps 26 subsystems / 0 invalid refs; 59 = 59 policy parity; CLEAN forbidden patterns.

### Phase 42 — Runtime Diagnostics Snapshot

Pure read-only aggregation endpoint. No new subsystem, no new health check, no new graph node. Created `src/core/diagnostics.ts`: `getDiagnosticsSnapshot()` imports from 9 existing modules — `getFullHealth` (healthMonitor), `getBaselineStatus` (baseline), `getLifecycleLedgerStatus` (requestLifecycleLedger), `getAuditLogStatus` (auditLog), `getAccessEnforcementStatus` (accessEnforcement), `getSessionContextStatus` (sessionContext), `getRuntimeDependencyGraphStatus` (runtimeDependencyGraph), `getCapabilityMatrixStatus` (runtimeCapabilityMatrix), `router` (router for `router.list().length`). Returns `DiagnosticsSnapshot`: `{ timestamp, executionBlocked: true, recoveryBlocked: true, health: { status, checkCount, passCount, warnCount, failCount }, baseline: { status, phase, allFieldsMatch, endpointCount, healthCheckCount, subsystemCount, graphNodeCount, cycleCount, invalidReferenceCount }, lifecycle: { recordCount, capacity, percentiles, statusDistribution, slowRequestCount, slowThresholdMs }, audit: { entryCount, capacity, oldestEntryAt, newestEntryAt }, access: { routePolicyCount, enforcementMode, authEnabled, executionBlocked: true, recoveryBlocked: true }, session: { sessionCount, capacity, authEnabled, defaultRole, defaultActorType, executionBlocked: true, recoveryBlocked: true }, graph: { nodeCount, cycleCount, hasCycles, maxDepth }, capabilities: { subsystemCount, invalidReferenceCount, validationStatus }, safetyFlags: { executionBlocked: true, recoveryBlocked: true, executePermissionBlocked: true, enforcementMode: "observe", commandExecutionBlocked: true, executionStillBlocked: true }, counts: { endpoints, healthChecks, subsystems, graphNodes } }`. Endpoint count in `counts.endpoints` is live from `router.list().length` — always reflects the actual registered route count. Health check count is the typed constant `HEALTH_CHECKS_TOTAL = 35` in diagnostics.ts (matches BASELINE_HEALTH_CHECK_COUNT). Created `src/routes/diagnostics.ts`: `handleDiagnosticsSnapshot` → `GET /api/diagnostics/snapshot`. Added 1 access policy (`GET /api/diagnostics/snapshot`: read/viewer); updated description "57-route → 58-route". Updated `BASELINE_LOCK.json` phase 42 (58 endpoints, 35 checks, 25 subsystems, 25 nodes). TypeScript typecheck: clean. Verification: snapshot returned with all 14 top-level sections present, `baseline.status: "intact"`, `baseline.allFieldsMatch: true`, `counts: { endpoints: 58, healthChecks: 35, subsystems: 25, graphNodes: 25 }`, `safetyFlags.executionBlocked: true`, `safetyFlags.enforcementMode: "observe"`, `graph.hasCycles: false`, `capabilities.invalidReferenceCount: 0`, 0 failures, 5 structural warns (all expected), 58 = 58 policy parity.

### Phase 41 — Lifecycle Percentiles + Slow Request Alerting

Pure enhancement of `src/core/requestLifecycleLedger.ts` and its health check. No new endpoints, no new health checks, no new subsystems. Counts unchanged: 57 endpoints · 35 health checks · 25 subsystems · 25 graph nodes · baseline phase 40 intact. Added three new interfaces: `LatencyPercentiles { p50, p95, p99: number | null }`, `StatusDistribution { "2xx", "4xx", "5xx", other: number }`. Added `SLOW_REQUEST_THRESHOLD_MS = 500` as a typed constant — not a runtime flag, not configurable via any API call. Added module-level `slowRequestCount: number = 0` tracked incrementally in `appendLifecycleRecord`: increments when `record.latencyMs >= 500`, decrements (floored at 0) when a slow record is evicted from the ring buffer on overflow — ring-buffer lifecycle correctness maintained. Added `computePercentile(sorted, pct)` helper: sorts `latencyMs` ascending, returns `sorted[Math.min(Math.floor(len * pct), len - 1)]`; returns `null` when ledger is empty. Percentiles and status distribution are computed on demand in `getLifecycleLedgerStatus()` — O(n log n) sort on ≤ 500 records, negligible cost. `LifecycleLedgerStatus` extended with `percentiles: LatencyPercentiles | null`, `statusDistribution: StatusDistribution`, `slowRequestCount: number`, `slowThresholdMs: number`. Updated `request_lifecycle_ledger` health check in `healthMonitor.ts` — three branches: `fail` on internal error; `warn` when not operational; `warn` when `slowRequestCount > 0` (detail includes count, p95, threshold); `pass` when operational and no slow requests (detail includes p50, record count, threshold). TypeScript typecheck: clean. Verification: p50/p95/p99 populated after 10 requests (all 1–3 ms), `statusDistribution: {"2xx":10,"4xx":0,"5xx":0,"other":0}`, `slowRequestCount: 0`, health check pass detail includes `p50: 1ms, slow: 0/500ms`, baseline intact (phase 40, all 6 fields match), 0 cycles, 0 invalid refs.

### Phase 40 — Request Lifecycle Ledger

Full per-request lifecycle telemetry recorded on `res.on("finish")`. No execution, no autonomous behavior. Created `src/core/requestLifecycleLedger.ts`: `LifecycleRecord` captures `{ id (8-byte hex via node:crypto), requestId, correlationId, method, route, startedAt, finishedAt, statusCode, latencyMs, executionBlocked: true }`. Ring buffer: 500 entries max, `ledger.shift()` on overflow. `appendLifecycleRecord(input)` is a no-op when not yet operational — early requests before `initRequestLifecycleLedger()` runs are silently skipped. `getLifecycleLedgerStatus()`: `{ operational, subsystemName: "request_lifecycle_ledger", recordCount, capacity, oldestRecordAt, newestRecordAt, executionBlocked: true, recoveryBlocked: true, initializedAt }`. `getRecentLifecycleRecords(limit)`: returns last N records (default 50, clamped to [1, 500]). `initRequestLifecycleLedger()` registers subsystem (`category: "observability"`, `dependencies: ["session_context", "audit_log", "runtime_state_registry"]`). Must be called after `initSessionContext()` and before `initRuntimeDependencyGraph()`. Import rule: never imports `healthMonitor`, `sessionContext`, `accessEnforcement`, or `auditLog` — dispatch wires all four independently. Extended `SessionContext` in `sessionContext.ts` with optional `lifecycle?: SessionLifecycle` (`{ statusCode, latencyMs, finishedAt }`). Added `completeSessionLifecycle(requestId, lifecycle)` — iterates ring buffer in reverse, finds by requestId, updates via spread (single-threaded safe). Extended `AuditEntry` in `auditLog.ts` with optional `lifecycle?: AuditLifecycle` (`{ statusCode, latencyMs, finishedAt }`). Added `updateAuditEntryLifecycle(requestId, lifecycle)` — same reverse-scan + spread pattern. Updated dispatch in `server.ts`: added `const startedAt = new Date().toISOString()` at request start; added `let resolvedCtx: SessionContext | null = null` mutable closure variable; restructured `res.on("finish")` handler — when `resolvedCtx !== null`, builds `lifecycle` object and calls `appendLifecycleRecord`, `completeSessionLifecycle`, `updateAuditEntryLifecycle`; after `createSessionContext()` call, sets `resolvedCtx = sessionCtx`. Lifecycle fields are absent on the very last in-flight request in each ring buffer (the one currently writing its response) — this is correct and expected since `res.on("finish")` fires after bytes are sent. Created `src/routes/requestLifecycleLedger.ts`: `handleLifecycleStatus` → `GET /api/lifecycle/status`, `handleLifecycleRecent` → `GET /api/lifecycle/recent` (supports `?limit=N` query param, 1–500, default 50). Added 2 policies to `ROUTE_ACCESS_POLICIES` (`GET /api/lifecycle/status`: read/viewer, `GET /api/lifecycle/recent`: monitor/operator). Updated `initAccessEnforcement` metadata "55-route → 57-route". Added 35th health check `request_lifecycle_ledger` to `healthMonitor.ts`. Added `request_lifecycle_ledger` capability record to `SEED_CAPABILITIES` (`category: "observability"`, `read: ["session_context", "audit_log", "runtime_state_registry"]`, `write: ["event_bus", "timeline", "runtime_event_bus"]`, `emit: ["request_lifecycle_ledger:initialized", "request_lifecycle_ledger:record_appended"]`, `access: ["node:crypto"]`). Updated `HEALTH_CHECK_COUNT` 34 → 35 in `runtimeSnapshot.ts`, `BASELINE_HEALTH_CHECK_COUNT` 34 → 35 in `baseline.ts`. Added `initRequestLifecycleLedger()` to `runtime.ts` between `initSessionContext()` and `initRuntimeDependencyGraph()`. Updated `BASELINE_LOCK.json` to phase 40 (57 endpoints, 35 health checks, 25 subsystems, 25 graph nodes, 0 cycles, 0 invalid refs). TypeScript typecheck: clean. Verification: 57 endpoints, 35 health checks, 0 failures, `request_lifecycle_ledger: pass`, `baseline_lock: pass` (intact, phase 40, all 6 fields match), 25 graph nodes, maxDepth: 6, 0 cycles, 25 capability records, 0 invalid refs, lifecycle records contain requestId + correlationId + statusCode + latencyMs + startedAt + finishedAt, session context `lifecycle` field populated on finished requests, audit entry `lifecycle` field populated on finished requests.

### Phase 39 — Session Context Layer

Per-request identity tracking and policy context propagation. No auth, no execution. Created `src/core/sessionContext.ts`: `SessionContext` captures `{ id (16-char hex via node:crypto), requestId, correlationId, actorType, role, permissions, route, method, timestamp, executionBlocked: true }`. `actorType` is always `"anonymous"` (no auth yet); `role` is always `"guest"` (no auth yet); `permissions` are derived from `listRoleDefinitions()` in `identityAccess` for the resolved role. `correlationId` is read from the incoming `X-Correlation-ID` request header; if absent, a new 16-char hex ID is generated via `node:crypto`. Ring buffer: 200 entries max, `sessionBuffer.shift()` on overflow. `createSessionContext(input)` is side-effect-free — always returns a valid `SessionContext` even before `initSessionContext()` runs; sessions are only written to the buffer after init. `getSessionContextStatus()`: `{ operational, subsystemName: "session_context", sessionCount, capacity, oldestSessionAt, newestSessionAt, defaultActorType, defaultRole, authEnabled: false, executionBlocked: true, recoveryBlocked: true, initializedAt }`. `getRecentSessions(limit)`: returns last N sessions (default 50, clamped to [1, 200]). `initSessionContext()` registers subsystem (`category: "observability"`, `dependencies: ["identity_access", "runtime_state_registry"]`). Must be called after `initAuditLog()` and before `initRuntimeDependencyGraph()`. Import rule: never imports `healthMonitor`, `accessEnforcement`, or `auditLog`. Created `src/routes/sessionContext.ts`: `handleSessionStatus` → `GET /api/session/status`, `handleSessionRecent` → `GET /api/session/recent` (supports `?limit=N` query param, 1–200, default 50). Extended `AuditEntryInput` and `AuditEntry` in `auditLog.ts` with `correlationId: string`. Updated dispatch in `server.ts`: extracts `X-Correlation-ID` header → `createSessionContext({ requestId, method, route, correlationId })` → sets `x-correlation-id` response header → `validateRouteAccess(method, path, sessionCtx.role)` (role now from session context, not hardcoded "guest") → `appendAuditEntry({ ..., correlationId: sessionCtx.correlationId, role: sessionCtx.role })`. Added 2 policies to `ROUTE_ACCESS_POLICIES` (`GET /api/session/status`: read/viewer, `GET /api/session/recent`: monitor/operator). Updated `initAccessEnforcement` metadata "53-route → 55-route". Added 34th health check `session_context` to `healthMonitor.ts`. Added `session_context` capability record to `SEED_CAPABILITIES` (`category: "observability"`, `read: ["identity_access", "runtime_state_registry"]`, `write: ["event_bus", "timeline", "runtime_event_bus"]`, `emit: ["session_context:initialized", "session_context:created"]`, `access: ["node:crypto"]`). Updated `HEALTH_CHECK_COUNT` 33 → 34 in `runtimeSnapshot.ts`, `BASELINE_HEALTH_CHECK_COUNT` 33 → 34 in `baseline.ts`. Added `initSessionContext()` to `runtime.ts`. Updated `BASELINE_LOCK.json` to phase 39 (55 endpoints, 34 health checks, 24 subsystems, 24 graph nodes, 0 cycles, 0 invalid refs). TypeScript typecheck: clean. Verification: 55 endpoints, 34 health checks, 0 failures, `session_context: pass`, `baseline_lock: pass` (intact, phase 39, all 6 fields match), 24 graph nodes, maxDepth: 5, 0 cycles, 24 capability records, 0 invalid refs, `X-Correlation-ID` header propagation verified, session ring buffer recording verified, audit entries include `correlationId` and session-resolved `role`.

### Phase 38 — Audit Log Layer

Append-only in-memory audit log that records every access enforcement check on every validated request. No disk writes, no execution path. Created `src/core/auditLog.ts`: `AuditEntry` captures `{ id (16-char hex via node:crypto), timestamp, requestId, method, route, role, permission, minimumRole, decision ("allowed" | "denied" | "no_policy"), reason, enforcementMode, executionBlocked: true }`. Ring buffer: plain array, max 1000 entries, oldest dropped via `shift()` on overflow — synchronous and re-entrant-safe in Node.js. `appendAuditEntry(input)` is a no-op when not yet operational (server starts before inits run). `getAuditLogStatus()`: `{ operational, subsystemName: "audit_log", entryCount, capacity, oldestEntryAt, newestEntryAt, executionBlocked: true, recoveryBlocked: true, initializedAt }`. `getAuditLogEntries(limit)`: returns last N entries (default 100, clamped to [1, 1000]). `initAuditLog()` registers subsystem (`category: "observability"`, `dependencies: ["access_enforcement", "runtime_state_registry"]`). Must be called after `initAccessEnforcement()` and before `initRuntimeDependencyGraph()`. Import rule: never imports `healthMonitor`. Created `src/routes/auditLog.ts`: `handleAuditStatus` → `GET /api/audit/status`, `handleAuditLog` → `GET /api/audit/log` (supports `?limit=N` query param, 1–1000, default 100, using the same manual querystring parsing pattern as `runtimeEvents.ts`). Wired in `server.ts` dispatch: after hardening check, calls `validateRouteAccess(method, path)` from `accessEnforcement` + `appendAuditEntry(...)` from `auditLog` on every request that passes validation. Decision derived as: `reason.startsWith("No access policy") → "no_policy"`, `allowed → "allowed"`, else `"denied"`. Added 53rd and 54th policies to `ROUTE_ACCESS_POLICIES` in `accessEnforcement.ts` (`GET /api/audit/status` and `GET /api/audit/log`, both `read / viewer`) — bringing total policies from 51 → 53 (matching endpoint count). Updated `initAccessEnforcement` metadata description "51-route → 53-route". Added 33rd health check `audit_log` to `healthMonitor.ts`: pass when operational (reports entryCount/capacity + newest timestamp), warn when not yet initialized, fail on internal error. Added `audit_log` capability record to `SEED_CAPABILITIES` (`category: "observability"`, `read: ["access_enforcement", "runtime_state_registry"]`, `write: ["event_bus", "timeline", "runtime_event_bus"]`, `emit: ["audit_log:initialized", "audit_log:entry_appended"]`, `access: ["node:crypto"]`). Updated `HEALTH_CHECK_COUNT` 32 → 33 in `runtimeSnapshot.ts`, `BASELINE_HEALTH_CHECK_COUNT` 32 → 33 in `baseline.ts`. Registered 2 routes (53 total). Added `initAuditLog()` to `runtime.ts`. Updated `BASELINE_LOCK.json` to phase 38 (53 endpoints, 33 health checks, 23 subsystems, 23 graph nodes, 0 cycles, 0 invalid refs). TypeScript typecheck: clean. Verification: 53 endpoints, 33 health checks, 0 failures, `audit_log: pass` (entryCount live, ring buffer recording), baseline `intact` (lockPhase: 38, all 6 fields match), 23 graph nodes, maxDepth: 5, 0 cycles, 23 capability records, 0 invalid refs.

### Phase 37 — Access Enforcement Layer

Validation-only access enforcement layer — no execution paths, no auth gating, no blocking. Created `src/core/accessEnforcement.ts`: defines a 51-entry `ROUTE_ACCESS_POLICIES` map covering every registered route (49 existing + 2 new access routes) with `method`, `path`, `permission` (`RoutePermission = "read" | "write" | "monitor" | "configure" | "billing" | "deploy"` — `"execute"` is never a valid route permission), `minimumRole`, and `description`. Enforcement mode is `"observe"` because `authEnabled: false` — validation logic runs and produces `AccessValidationResult` but requests are never blocked. `matchPath(pattern, actual)` handles parameterized segments (`:param` matches any single path segment). `validateRouteAccess(method, path, role?)` finds the matching policy, checks `meetsMinimumRole` (using ordered `ROLE_ORDER = ["owner","admin","operator","viewer","guest"]`) and `roleHasPermission` (delegates to `listRoleDefinitions()` from `identityAccess`), returns `{ method, path, role, permission, minimumRole, allowed, reason, enforcementMode, executionBlocked }`. Default role is `"guest"` when none supplied. `getAccessEnforcementStatus()`: `{ operational, subsystemName: "access_enforcement", enforcementMode, authEnabled: false, routePolicyCount, executionBlocked: true, recoveryBlocked: true, initializedAt }`. `getAccessEnforcementPolicies()`: `{ executionBlocked, recoveryBlocked, enforcementMode, count, policies }`. `initAccessEnforcement()` registers subsystem (`category: "enforcement"`, `dependencies: ["identity_access", "runtime_state_registry"]`). Must be called after `initIdentityAccess()` and before `initRuntimeDependencyGraph()`. Import rule: never imports `healthMonitor`. Created `src/routes/accessEnforcement.ts`: `handleAccessStatus` → `GET /api/access/status`, `handleAccessPolicies` → `GET /api/access/policies`. Added 32nd health check `access_enforcement` to `healthMonitor.ts`: pass when operational (detail includes policy count and mode), warn when not yet initialized, fail on internal error. Added `access_enforcement` capability record to `SEED_CAPABILITIES` (`category: "enforcement"`, `read: ["identity_access", "runtime_state_registry"]`, `write: ["event_bus", "timeline", "runtime_event_bus"]`, `emit: ["access_enforcement:initialized"]`, `access: ["node:env"]`). Updated `HEALTH_CHECK_COUNT` in `runtimeSnapshot.ts` 31 → 32. Updated `BASELINE_HEALTH_CHECK_COUNT` in `baseline.ts` 31 → 32. Registered 2 new routes in `server.ts` (51 total). Added `initAccessEnforcement()` to `runtime.ts` between `initIdentityAccess()` and `initRuntimeDependencyGraph()`. Updated `BASELINE_LOCK.json` to phase 37 (51 endpoints, 32 health checks, 22 subsystems, 22 graph nodes, 0 cycles, 0 invalid refs). TypeScript typecheck: clean. Verification: 51 endpoints, 32 health checks, 0 failures, `access_enforcement: pass`, baseline `intact` (lockPhase: 37, all 6 fields match), 22 graph nodes, 0 cycles, 22 capability records, 0 invalid refs. Policy breakdown: `read`×9, `monitor`×37, `configure`×1, `write`×4 — no `execute` permission assigned to any route. Minimum role breakdown: `viewer`×31, `operator`×19, `admin`×1.

### Phase 36 — Identity & Access Foundation

Read-only identity and access metadata layer — no real login, no external auth, no execution path. Created `src/core/identityAccess.ts`: defines 4 actor types (`system`, `owner`, `service`, `anonymous`), 5 roles (`owner`, `admin`, `operator`, `viewer`, `guest`), and 7 permission categories (`read`, `write`, `monitor`, `configure`, `billing`, `deploy`, `execute`). `execute` is permanently blocked across all roles via typed literal constants (`EXECUTE_BLOCKED: true`). `executionBlocked: true` and `recoveryBlocked: true` are typed literals at module level. `initIdentityAccess()` calls `registerSubsystemState()` to self-register in the runtime state registry (`category: "identity"`, `dependencies: ["runtime_state_registry"]`). Must be called after `initRuntimeStateRegistry()` and before `initRuntimeDependencyGraph()` so the new node is picked up by the graph (21 nodes) and capability matrix (21 records). Import rule: `identityAccess.ts` imports `runtimeStateRegistry`, `logger`, `timeline`, `eventBus`, `runtimeEventBus` — never imports `healthMonitor`. Created `src/routes/identityAccess.ts`: `handleIdentityStatus` for `GET /api/identity/status` (operational status, authEnabled: false, actor types, roles count, permission categories, all execution/recovery/execute block flags), `handleIdentityRoles` for `GET /api/identity/roles` (full role definitions with per-role permission entries including blocked flag). Added 31st health check `identity_access` to `healthMonitor.ts`: pass when operational, warn when not yet initialized, fail on internal error. Added `identity_access` capability record to `SEED_CAPABILITIES` in `runtimeCapabilityMatrix.ts` (`category: "identity"`, `read: ["runtime_state_registry"]`, `write: ["event_bus", "timeline", "runtime_event_bus"]`, `access: ["node:env"]`). Updated `HEALTH_CHECK_COUNT` in `runtimeSnapshot.ts` from 30 → 31. Updated `BASELINE_HEALTH_CHECK_COUNT` in `baseline.ts` from 30 → 31. Registered 2 new routes in `server.ts` (49 total). Added `initIdentityAccess()` to `runtime.ts` init sequence between `initRuntimeStateRegistry()` and `initRuntimeDependencyGraph()`. Updated `BASELINE_LOCK.json` to phase 36 (49 endpoints, 31 health checks, 21 subsystems, 21 graph nodes, 0 cycles, 0 invalid refs). TypeScript typecheck: clean. Verification: `/api/healthz` → ok, `/api/identity/status` → operational, `authEnabled: false`, all execute permissions `blocked: true`, `executeBlocked: true`, `/api/identity/roles` → 5 roles all with `execute.granted: false, blocked: true`, `GET /api/baseline/status` → `baselineStatus: intact` (all 6 fields match), 21 graph nodes, 0 cycles, 21 capability records, 0 invalid refs, 31 health checks, 0 failures.

### Phase 35 — Foundation Freeze & Baseline Protection

Read-only baseline layer. Created `BASELINE_LOCK.json` (version 1, phase 35, sealed 2026-05-11) containing the six sealed nucleus counts: `endpointCount: 47`, `healthCheckCount: 30`, `subsystemCount: 20`, `graphNodeCount: 20`, `cycleCount: 0`, `invalidReferenceCount: 0`, plus `executionBlocked: true`, `recoveryBlocked: true`, `typecheckStatus: "clean"`. Created `src/core/baseline.ts`: loads the lock file via `process.cwd()` at startup (works in both dev/tsx and prod/esbuild), compares six live fields against the sealed counts on every call to `getBaselineStatus()`, returns `baselineStatus: "intact" | "changed"` with per-field `{ baseline, live, match }` breakdown plus typed-literal `executionBlocked: true`, `recoveryBlocked: true`. Import rule: `baseline.ts` imports `router`, `getRuntimeDependencyGraphStatus`, `getCapabilityMatrixStatus`, `listSubsystemStates`, `logger`, `addTimelineEvent`, `emit` (eventBus), `emitRuntimeEvent`. `baseline.ts` must never import from `healthMonitor.ts` — the direction is healthMonitor → baseline only. Created `src/routes/baselineStatus.ts`: thin handler for `GET /api/baseline/status`, delegates entirely to `getBaselineStatus()`. Added 30th health check `baseline_lock` to `healthMonitor.ts`: pass when operational + intact, warn when not operational or drift detected, fail on internal error. Updated `HEALTH_CHECK_COUNT` in `runtimeSnapshot.ts` from 29 to 30. Registered `router.get("/api/baseline/status", handleBaselineStatus)` in `server.ts` (endpoint count: 46 → 47). Added `initBaseline()` call to `runtime.ts` after `initCapabilityMatrix()`. TypeScript typecheck: clean. Verification: `/api/healthz` → `{"status":"ok"}`, `/api/baseline/status` → `baselineStatus: "intact"`, all six field pairs `match: true`, 47 endpoints, 30 health checks, 0 failures. Created `BASELINE.md` documenting the frozen state, lock file format, endpoint response schema, health check conditions, import rules, and all six source files changed in this phase.

### Phase 34 — Nucleus Final Lock / Core Completion Seal

Verification and sealing phase. No source files were modified. All nucleus invariants were confirmed by live query against the running server and static analysis of `src/`. Verification results: 46 endpoints (confirmed via `server.ts` router registration count), 29 health checks (confirmed via `GET /api/health/full`), 20 registered subsystems (confirmed via `GET /api/runtime/registry`), 20 dependency graph nodes with 0 cycles (confirmed via `GET /api/runtime/graph/status`), 0 invalid capability references with `validationStatus: "valid"` (confirmed via `GET /api/runtime/capabilities/status`). All execution block constants verified live: `executionBlocked: true` returned by all 14 queue and meta endpoints; `blockedExecution: true` from restart supervisor; `recoveryBlocked: true` from capability matrix. Forbidden pattern static scan: zero `child_process` imports, zero `.exec(` / `.spawn(` / `.fork(` / `eval(` calls, zero deploy/recovery execution patterns across all `src/` TypeScript files. The `shellExecution` string in `pluginSandbox.ts` is a permission category name permanently set to `"denied"` — it is not a shell invocation. TypeScript typecheck: clean. Health check failures at boot: 0 (five warnings are operational — empty queue, no tasks yet, SESSION_SECRET detected and masked; all are expected at fresh startup). Created `NUCLEUS_LOCK.md` as the permanent completion record containing: the full verification table, all 20 subsystem names, dependency graph topology, all 46 endpoints by group, all 29 health check names, all five permanent safety constants with scope, the zero-execution-path certification, and the future layers roadmap. Updated `replit.md` to mark nucleus status as SEALED and progress as 100%.

### Phase 33 — Endpoint Documentation Split Layer

Documentation organisation phase. No source files were modified. Created `ENDPOINTS.md` as the single authoritative reference for all 46 active endpoints and all 29 health checks. Slimmed `replit.md` by removing the flat endpoint table (90 lines) and the flat health-check table (33 lines), replacing both with a 9-line summary block that links to `ENDPOINTS.md`. The new file is structured by endpoint group (Core, Detection, Snapshots, Observability, Monitoring, Security, State, Task Queue, Runtime Snapshots, Runtime Events, Commands, Runtime Registry, Runtime Dependency Graph, Runtime Capability Matrix — 14 groups), with columns for Method, Route, Purpose, Subsystem, and Notes. A numbered health-check table adds Pass / Warn / Fail conditions per check. A Safety Flags section documents all four permanent execution-block constants and their scope. No `src/` files were touched. Server remained running throughout. Endpoint count unchanged at 46. Health check count unchanged at 29.

### Phase 32 — Runtime Capability Matrix Layer

Read-only capability matrix that defines what every subsystem is allowed to READ, WRITE, EMIT, SUBSCRIBE, and ACCESS. `runtimeCapabilityMatrix.ts` maintains a `Map<string, CapabilityRecord>` keyed by subsystem name. CapabilityRecord model: `subsystemName`, `category`, `capabilities` (object with five arrays: `read`, `write`, `emit`, `subscribe`, `access`), `executionBlocked: true` (typed literal), `recoveryBlocked: true` (typed literal), `version: 1` (typed literal). API surface: `initCapabilityMatrix()` — seeds 20 records and validates all references; `getCapabilityRecord(subsystemName)` — returns record or null; `listCapabilityRecords()` — sorted alphabetically; `getCapabilityMatrixStatus()` — operational flag, capability type totals, validationStatus (`valid | invalid | unchecked`), invalidReferenceCount, invalidReferences list, validationDetails per subsystem, all execution flags. Validation: for each record, every entry in `read` and `write` is checked against the union of (known subsystem names from `listSubsystemStates()` ∪ `VALID_INFRASTRUCTURE_REFS`). `VALID_INFRASTRUCTURE_REFS` = `event_bus`, `timeline`, `runtime_event_bus`, `storage:snapshots`, `storage:tasks`, `storage:runtime-state`, `node:fs`, `node:http`, `node:env`, `node:process`, `node:crypto`. Any entry not in this combined set is flagged. The matrix correctly identified that `runtime_state_registry`, `runtime_dependency_graph`, and `runtime_capability_matrix` were not in the registry — this caused the registry to be expanded from 17 → 20 subsystems (Phase 32 expansion adds three `meta` category entries). Capability records are immutable after init — no mutation API exists. Emits to eventBus and runtimeEventBus on init with `severity: "warning"` if invalid references detected, `"info"` otherwise. `initCapabilityMatrix()` runs after `initRuntimeDependencyGraph()` in runtime init order. Registry and dependency graph automatically grew to 20 nodes with the new meta subsystem seeds. 29th health check (`runtime_capability_matrix`): fail if not operational; warn if invalidReferenceCount > 0; pass otherwise. 3 endpoints: `GET /api/runtime/capabilities` (list + status), `GET /api/runtime/capabilities/status` (status only), `GET /api/runtime/capabilities/:subsystemName` (single record by name, 404 if not found). Total after Phase 32: 46 endpoints, 29 health checks, 20 registered subsystems.

### Phase 31 — Runtime Dependency Graph Layer

Read-only dependency graph built from the registry's declared `dependencies` fields. `runtimeDependencyGraph.ts` maintains a `Map<string, DependencyNode>` keyed by subsystem name. DependencyNode model: `subsystemName`, `category`, `upstream` (direct deps declared in registry), `downstream` (computed reverse — who depends on this node), `allUpstream` (transitive closure, DFS), `allDownstream` (transitive closure, DFS), `depth` (length of longest upstream path to any root; roots have depth 0; cycle nodes return 0 via stack guard), `hasCycle` (whether this node appears in any detected cycle), `executionBlocked: true` (typed literal), `recoveryBlocked: true` (typed literal). Graph topology (17 seeded subsystems): single root is `runtime` (depth 0, 8 direct downstream, 16 transitive downstream = all others); deepest node is `runtime_snapshot` at depth 4 (runtime → task_queue → task_lifecycle → runtime_snapshot, plus task_policy branch); 11 leaf nodes (no downstream); max depth 4; 0 cycles. Cycle detection: iterative DFS with `visiting` (in-stack) and `visited` (fully processed) sets — re-encountering a `visiting` node confirms a cycle, path sliced from `path.indexOf(node)` to capture the exact cycle. `allUpstream`/`allDownstream` computed via DFS with a per-call `visited` Set to prevent infinite recursion on cycles. Depth computed via memoized recursive descent with a `stack` Set as cycle guard. Graph is seeded from `listSubsystemStates()` at init time — reads `state.dependencies` as upstream edges; registry is the single source of truth. Graph data is immutable after `initRuntimeDependencyGraph()` returns — no mutation API exists. Emits to eventBus and runtimeEventBus on init with `severity: "warning"` if cycles detected, `"info"` otherwise. 28th health check (`runtime_dependency_graph`): fail if not operational; warn if any cycles; pass otherwise. 3 endpoints: `GET /api/runtime/graph` (list + status), `GET /api/runtime/graph/status` (status only), `GET /api/runtime/graph/:subsystemName` (single, 404 on miss). `runtimeDependencyGraph.ts` never imports `healthMonitor`.

### Phase 30 — Runtime State Registry Layer

Central in-memory registry that tracks every subsystem's state without controlling or executing anything. `runtimeStateRegistry.ts` maintains a `Map<string, SubsystemState>` keyed by subsystem name. SubsystemState model: `subsystemName`, `category`, `status` (initialized|ready|degraded|blocked|archived|unknown), `health` (healthy|degraded|unhealthy|unknown), `version` (monotonically incrementing integer), `lastUpdatedAt`, `dependencies` (string array), `warnings` (string array), `errors` (string array), `executionBlocked: true` (typed literal), `recoveryBlocked: true` (typed literal), `metadata` (Record). API surface: `registerSubsystemState(input)` — idempotent, returns existing record unchanged on re-register; `updateSubsystemState(subsystemName, patch)` — merges metadata (spread), replaces warnings/errors/status/health outright, always bumps version + lastUpdatedAt, returns null if subsystem not found; `getSubsystemState(subsystemName)` — returns state or null; `listSubsystemStates()` — sorted alphabetically; `getRuntimeStateRegistryStatus()` — aggregated counts, `coreSubsystemsPresent` flag (checks runtime, health_monitor, task_queue, task_policy, command_gateway), all three execution flags. 17 subsystems seeded at init across 9 categories: core (runtime, health_monitor), queue (task_queue, task_policy, task_evaluation, task_persistence, queue_orchestration, task_lifecycle), snapshot (runtime_snapshot), events (runtime_event_bus), commands (command_gateway), security (hardening, secure_config), monitoring (watchdog, restart_supervisor), plugins (plugin_sandbox), recovery (recovery_tracker). All seed with `status: "initialized"`, `health: "unknown"`. Emits to eventBus and runtimeEventBus on init. Adds timeline event. 27th health check (`runtime_state_registry`): fail if not operational or core subsystems missing; warn if any degraded/blocked/unhealthy; pass otherwise. 3 endpoints: `GET /api/runtime/registry` (list + status), `GET /api/runtime/registry/status` (status only), `GET /api/runtime/registry/:subsystemName` (single, 404 on miss). `runtimeStateRegistry.ts` never imports `healthMonitor`.

### Phase 29 — Controlled Command Gateway Foundation

Controlled intake layer for all inbound commands. `commandGateway.ts` accepts, classifies, and records commands — no execution path exists anywhere in the module. Command model: `commandId` (16-char hex), `commandType` (namespace:action string), `source`, `requestedBy` (default: "system"), `payload`, `status` (received|evaluated|blocked|approval_required|archived), `riskLevel` (low|medium|high|critical), `approvalRequired`, `blockedReason`, `createdAt`, `updatedAt`, `correlationId`. Bounded ring buffer: max 500 commands, FIFO eviction. `submitCommand(input)` → intake, evaluate, store, emit, return. `evaluateCommand(commandType)` → pure classification function (no side effects). Policy evaluation (4 policies): `block_invalid_format` (type doesn't match `/^[a-zA-Z][a-zA-Z0-9_-]*:[a-zA-Z][a-zA-Z0-9_:.-]*$/` — same regex as taskPolicy), `block_dangerous_namespace` (shell, exec, spawn, cmd, bash, sh, process, system, deploy, deployment, recovery, run, execute, start, stop, restart, kill, self, ai, auto, repair, fix, update, delete, remove, mutate, write, fs, file, disk, network, external, rm, format, socket, fetch, http, request, worker, thread, cluster, fork, child → critical risk, blocked), `allow_low_risk` (status, read, query, metrics, health, check, report, view, info, ping → low risk, evaluated), `allow_medium_risk` (monitor, inspect, list, config, audit, log, timeline, snapshot, watchdog, trace, describe, show, get → medium risk, evaluated), `require_approval_unknown_namespace` (any other valid format → high risk, approval_required). Integrations: emits to both `eventBus.ts` and `runtimeEventBus.ts` on every command submission; adds timeline event; structured logger output. All three execution flags always true: `commandExecutionBlocked: true`, `executionBlocked: true`, `recoveryBlocked: true`. 26th health check (`command_gateway`): pass if operational and no blocked/approval-required commands; warn if any exist; fail if not initialized. 3 endpoints: `GET /api/commands` (list + status), `GET /api/commands/status` (status only), `POST /api/commands` (submit, returns 201 regardless of evaluation outcome). `commandGateway.ts` imports `eventBus`, `timeline`, `logger`, `runtimeEventBus` — never imports `healthMonitor`.

### Phase 28 — Runtime Event Bus & Internal Signal Layer

Higher-level runtime event bus built on top of (but independent from) `eventBus.ts`. `runtimeEventBus.ts` bridges the existing event bus via `initRuntimeEventBus()` which calls `subscribe()` on `eventBus.ts` for 19 event types across all subsystems, translating each to a rich `RuntimeEvent` with: `eventId` (16-char hex), `eventType` (dotted name), `source`, `severity` (info|warning|critical), `category` (runtime|health|queue|lifecycle|persistence|snapshot|recovery|policy|orchestration), `timestamp`, `payload`, `correlationId`, `runtimeVersion: 1`. Bounded ring buffer retains last 1000 events (FIFO eviction). `emitRuntimeEvent()` is re-entrant-safe via `isDispatching` flag + `pendingDispatch` queue — eliminates recursive event loops. Per-handler try/catch isolates failures into `dispatchFailures` counter. `subscribeRuntimeEvent(eventType, handler, source)` → subscriptionId (12-char hex); supports exact type or `"*"` wildcard. `unsubscribeRuntimeEvent(subscriptionId)`. `listRuntimeSubscribers()`. `listRecentRuntimeEvents(limit)` → newest first, clamped to 200. `clearOldRuntimeEvents(maxAgeMs?)`. Bridge subscriptions are registered on `eventBus.ts` — they are NOT counted in `activeSubscriberCount` (which only tracks `subscribeRuntimeEvent()` callers). `runtime.ts` adds direct `emitRuntimeEvent("runtime.ready")` call after `initRuntimeEventBus()`. `shutdown.ts` adds direct `emitRuntimeEvent("runtime.stopping")` call. 25th health check (`runtime_event_bus`): pass if operational and no failures; warn if dispatchFailures > 0 or retentionNearLimit (>800); fail if not initialized. `HEALTH_CHECK_COUNT` updated from 24 → 25 in `runtimeSnapshot.ts`. 3 new endpoints: GET /api/runtime/events (full status), GET /api/runtime/events/recent (?limit=N, default 50, max 200), GET /api/runtime/subscribers. `runtimeEventBus.ts` imports `eventBus.ts` (one-way only) — never reverse this.

### Phase 27 — Snapshot & Recovery Foundation

Cross-system runtime snapshot infrastructure. `createRuntimeSnapshot(reason)` collects from 7 subsystems (runtime, task queue, lifecycle, policy, orchestrator, persistence, router) and writes atomically to `storage/runtime-snapshots/active/`. Retention: max 50 active — on write, oldest active files are renamed to `storage/runtime-snapshots/archived/` (never deleted). Archived snapshots are permanent and read-only. Active snapshots are also immutable once written — no overwrite path exists. Each snapshot captures: `id`, `version: 1`, `status` (active|archived), `reason`, `createdAt`, `endpointCount` (dynamic from `router.list().length`), `healthCheckCount: 24` (constant), `executionBlocked: true`, `runtime`, `healthSummary` (derived — not imported from `healthMonitor.ts` to avoid circular dep), `queueStats`, `lifecycleStats`, `policyStats`, `orchestratorStats`, `persistenceStats`. `getRuntimeSnapshot(id)` overrides the `status` field from directory location rather than the written JSON value. `listRuntimeSnapshots()` returns both active and archived summaries. `validateRuntimeSnapshot(id)` checks all 15 required fields — `recoveryBlocked: true` always. `compareSnapshots(a, b)` produces a full structural diff across all subsystem counters and timing. Recovery preparation layer (planning only, no execution): `validateRecoveryCandidate(id)` delegates to validation; `estimateRecoveryImpact(id)` computes age-based impact level (minimal <5m, moderate <1h, significant ≥1h) with per-system warnings; `dryRunRecovery(id)` produces an 8-phase restoration plan with 5 permanently blocked execution steps — `dryRun: true, recoveryBlocked: true, executionBlocked: true`. `POST /api/runtime/recovery/dry-run` is a multi-action endpoint: `action=dry-run` (default), `validate`, `impact`, `compare`. Router updated to support parameterized segment matching (`/:param`) — exact match wins, then param match; handler extracts ID from `req.url`. 24th health check (`runtime_snapshot`): pass if operational and activeCount < 40, warn if near limit (≥40/50), fail on storage failure. `runtimeSnapshot.ts` must never import from `healthMonitor.ts` — circular dep risk (healthMonitor imports runtimeSnapshot).

### Phase 20 — Task Lifecycle State Machine Foundation

Five-state lifecycle machine. States: `queued | ready | waiting_approval | blocked | archived`. Transition rules enforced by an immutable `ALLOWED_TARGETS` map: `queued → {ready, waiting_approval, blocked, archived}`; `ready → {waiting_approval, blocked, archived}`; `waiting_approval → {ready, blocked, archived}`; `blocked → {archived}` only; `archived → {}` (terminal). `evaluateTaskLifecycle(task)` derives initial state from task queue status and `peekTaskPolicy()`: `allow → ready`, `approval_required → waiting_approval`, `warn → queued`, `block → blocked`. `transitionTaskState(taskId, targetState, reason?)` validates the transition, updates the per-task record, emits `task_lifecycle:transitioned` or `task_lifecycle:transition_rejected`, returns `TransitionResult` with `executionBlocked: true`. The lifecycle layer maintains its own `Map<string, TaskLifecycleRecord>` — it never modifies `taskQueue.ts` state. On init: seeds lifecycle records for all tasks already loaded from persistence, then subscribes to `task_queue:task_created` (create record) and `task_queue:task_blocked` (auto-transition to `blocked`). Counters: `totalTransitions`, `allowedTransitions`, `rejectedTransitions`, `lastTransitionAt`, `lastRejectedReason`. `POST /api/tasks/lifecycle/transition` validates `taskId`, `targetState`, optional `reason`; returns 200 on success, 422 on rejected transition. 23rd health check (`task_lifecycle`): pass if operational and no rejected transitions, warn if rejectedTransitions > 0, fail on internal error.

### Phase 19 — Queue Orchestration Foundation

Planning-only orchestration layer. `evaluateQueueReadiness()` scans all tasks via `listTasks()`, calls `peekTaskPolicy()` for each — a pure, side-effect-free function that runs the same policy logic as `evaluateTaskPolicy()` but never touches counters or emits events. Returns one `OrchestrationPlanEntry` per task with: `taskId`, `taskType`, `currentStatus`, `policyDecision`, `evaluationCategory`, `readiness` (`ready | blocked | approval_required | warning`), `reason`, `priority` (`low | normal | high`). Priority rules: `block → low`, `allow/warn → normal`, `approval_required → high`. Counters: `totalQueued`, `readyCount`, `blockedCount`, `approvalRequiredCount`, `warningCount`, `lastEvaluationAt`. `orchestrationMode: "planning_only"` typed as literal. `executionBlocked: true` typed as literal. Three event bus subscriptions re-evaluate on `task_created`, `task_blocked`, `task_queued`. `peekTaskPolicy()` added to `taskPolicy.ts` — pure function, zero side effects, no counter increments, no event emission. 22nd health check (`queue_orchestration`): pass if operational and no blocked/approval-required tasks, warn if any blocked or approval-required tasks exist, fail on internal error. `GET /api/queue/orchestration` returns orchestration status, full plan, and `executionBlocked: true`.

### Phase 18 — Task Persistence Foundation

Atomic disk persistence for the task queue. `persistTasks()` reads `listTasks()`, prunes to 100, writes to `storage/tasks/task-state.json` via `.tmp → rename`. `loadPersistedTasks()` reads file on boot, calls `importTask()` for each record — no event emitted, no evaluation triggered. `importTask()` added to `taskQueue.ts`: silently inserts tasks into the map, updates `lastTaskCreatedAt` and `lastBlockedAt`, no event bus emission. Three event bus subscriptions in `initTaskPersistence()`: `task_queue:task_created`, `task_queue:task_blocked`, `task_queue:task_queued` — all trigger `persistTasks()`. `clearPersistedTasks()` atomic-writes an empty state file. `executionBlocked: true` typed as literal `true`. 21st health check (`task_persistence`): pass if operational and tasks saved, warn if no tasks saved yet, fail on internal error. Verified: loaded tasks have `totalEvaluations: 0` and `totalPolicyEvaluations: 0` — the load path never triggers evaluation.

---

## Current Completed Infrastructure Systems

| System | Module | Status |
|---|---|---|
| Runtime Core | `runtime.ts`, `config.ts`, `shutdown.ts`, `plugins.ts` | Active |
| Request Router | `router.ts`, `server.ts`, `errorBoundary.ts` | Active |
| Structured Logger | `lib/logger.ts`, `lib/requestContext.ts` | Active |
| Request Validation | `lib/validate.ts`, `lib/response.ts` | Active |
| Runtime Metrics | `core/metrics.ts` | Active |
| Health Monitor | `core/healthMonitor.ts` | Active — 28 checks |
| Freeze Detector | `core/freezeDetector.ts` | Active |
| Crash Detector | `core/crashDetector.ts` | Active |
| Snapshot Layer | `core/snapshots.ts` | Active — max 10 in-memory |
| Persistent Snapshot Storage | `core/snapshotStorage.ts` | Active — max 20 on disk |
| Runtime Timeline | `core/timeline.ts` | Active — max 200 events |
| Event Bus | `core/eventBus.ts` | Active — synchronous, in-memory |
| Watchdog Core | `core/watchdog.ts` | Active — 15 s interval |
| Restart Supervisor | `core/restartSupervisor.ts` | Active — blockedExecution always true |
| Plugin Sandbox Isolation | `core/pluginSandbox.ts` | Active — all permissions denied |
| Persistent Runtime State | `core/runtimeState.ts` | Active — atomic single-file |
| Recovery Tracking | `core/recoveryTracker.ts` | Active — observation only |
| Production Hardening | `core/hardening.ts` | Active — 5 blocks, 2 warnings |
| Secure Config Management | `core/secureConfig.ts` | Active — masking + validation |
| Task Queue | `core/taskQueue.ts` | Active — tracking only, executionBlocked always true |
| Task Evaluation | `core/taskEvaluation.ts` | Active — delegates to task policy, executionStillBlocked always true |
| Task Policy Engine | `core/taskPolicy.ts` | Active — 10 policies, source of truth, executionBlocked always true |
| Task Persistence | `core/taskPersistence.ts` | Active — atomic disk writes, max 100 tasks, load-on-boot, executionBlocked always true |
| Queue Orchestrator | `core/queueOrchestrator.ts` | Active — planning only, peekTaskPolicy, readiness scan, executionBlocked always true |
| Task Lifecycle | `core/taskLifecycle.ts` | Active — 5-state machine, transition validation, own record map, executionBlocked always true |
| Runtime Snapshot | `core/runtimeSnapshot.ts` | Active — cross-system snapshot, max 50 active + archive, dry-run recovery, executionBlocked always true |
| Runtime Event Bus | `core/runtimeEventBus.ts` | Active — 9-category model, 1000-event ring buffer, bridge subscriptions, handler failure isolation |
| Command Gateway | `core/commandGateway.ts` | Active — intake-only, 4-policy risk classification, max 500 commands, commandExecutionBlocked always true |
| Runtime State Registry | `core/runtimeStateRegistry.ts` | Active — 17 seeded subsystems, register/update/list/get, read-only surface, executionBlocked always true |
| Runtime Dependency Graph | `core/runtimeDependencyGraph.ts` | Active — 17 nodes, upstream/downstream/transitive closures, cycle detection, depth, read-only |

---

## Current Progress Estimate

Bulldozer Mother Core is approximately **97%–98% complete** toward full production-scale infrastructure maturity.

| Layer | Status |
|---|---|
| Foundation nucleus | Complete |
| Core architecture | Stabilized |
| Observability systems | Complete |
| Passive safety systems | Complete |
| Production hardening foundation | Complete |
| Config management foundation | Complete |
| Queue/task infrastructure | Complete — queue + evaluation + policy + persistence + orchestration + lifecycle |
| Snapshot & recovery infrastructure | Complete — cross-system snapshot, retention, archive, dry-run recovery |
| Runtime event bus | Complete — 9-category model, bridge, 1000-event ring buffer, handler isolation |
| Command gateway | Complete — intake-only, risk classification, policy enforcement, no execution path |
| Runtime state registry | Complete — 17 subsystems seeded, register/update/list/get, no control plane |
| Runtime dependency graph | Complete — 17 nodes, upstream/downstream/transitive/depth, DFS cycle detection |
| Rate limiting | Not started |
| Secrets vault | Not started |
| Auth layer | Not started |
| Deployment readiness | Not started |
| Cloud orchestration layer | Not started |
| Controlled self-repair layer | Not started |
| Controlled self-development layer | Not started |
| App production factory | Not started |

The foundation-heavy phase is complete. The core architecture is stabilized and will not require structural changes to accommodate future phases. Future phases add new systems on top of the existing nucleus without modifying the nucleus itself.

---

## Architecture Principles

### 1. Infrastructure-first

No intelligence layer, no autonomous system, and no financial layer may be built until the underlying infrastructure layer is stable, tested, and observable. The build always proceeds from the most foundational layer upward.

### 2. Stability-first

Every system is designed so that its failure cannot cascade into adjacent systems. Storage failures do not break in-memory state. Event bus handler errors are swallowed. Hardening violations do not crash the server. Health check failures are isolated per-check. Each module is its own fault domain.

### 3. Modular systems

Every system is a standalone module with a clearly bounded interface. No module reaches into the internals of another. Integration is always through exported functions or the event bus. Circular dependencies are explicitly forbidden by construction for high-risk modules.

### 4. Strict phase sequencing

No phase begins until the previous phase is stable and verified. No phase is added speculatively. Every phase is typechecked, endpoint-tested, and reviewed before the next begins.

### 5. Sandbox-first execution

All future execution systems — plugins, repair actions, code generation, self-development — must be isolated in sandboxes. No unsandboxed execution path may exist. Plugin sandbox isolation is built and enforced before any plugin system is activated.

### 6. No AI before infrastructure maturity

Intelligence layers, AI models, and autonomous decision systems are not added until the nucleus is complete, stable, and hardened. The nucleus must be able to operate, observe, and report on itself without any AI dependency.

### 7. Cloud-first design

The Mother Core is designed to run on cloud/VPS infrastructure, not locally. No localhost assumptions, no embedded databases, no local-only dependencies. All persistence uses atomic disk operations compatible with cloud volume mounts.

### 8. Rollback-safe future systems

All future repair, development, and orchestration systems must implement rollback before they implement execution. A change that cannot be undone must not be applied.

### 9. Command-driven future autonomy

No autonomous action may occur without an explicit command from the user or a pre-approved signed instruction. The system may recommend, observe, detect, and record — but never act without authorization.

---

## Security Roadmap (Future Phases)

Nothing below has been built. This is planning documentation only.

| Phase | System | Purpose |
|---|---|---|
| Next | Rate limiting | Cap request frequency per IP or API consumer; prevent resource exhaustion |
| Future | Secrets vault | Encrypted secrets at rest; environment-scoped; no secrets in logs or snapshots |
| Future | Auth layer | Identity verification; token validation; session management |
| Future | Permissions system | Role-based access control for API routes and internal actions |
| Future | Audit logs | Immutable record of all privileged operations with actor, timestamp, and payload |
| Future | Integrity checks | Detect tampering with persisted state, snapshots, and config at rest |
| Future | Backup / restore | Structured backup of all durable state; verified restore with before/after comparison |
| Future | Security monitor | Aggregated view of hardening violations, auth failures, and integrity alerts |

All security phases must be built in order. No auth layer before secrets vault. No permissions before auth. No audit log before permissions.

---

## Future Infrastructure Roadmap

Nothing below has been built. This is planning documentation only.

| Phase | System | Purpose |
|---|---|---|
| Next | Rate limiting | Cap request frequency per IP or API consumer; prevent resource exhaustion |
| Future | Deployment readiness | Readiness vs liveness endpoint separation; health gate before deploy acceptance; graceful drain |
| Future | Cloud / VPS orchestration layer | APIs for provisioning, monitoring, and teardown of cloud resources; all actions user-approved |
| Future | Execution layer | Bounded, sandboxed execution of pre-approved commands; full audit trail; rollback on failure |
| Future | Controlled self-repair layer | Supervised repair triggered by watchdog observations; predefined bounds; rollback mandatory |
| Future | Controlled self-development layer | Supervised code and config generation; review gate before apply; rollback mandatory |
| Future | App production factory | Generate, deploy, monitor, and manage applications; all operations sandboxed and supervised |

---

## Service Separation Architecture

The Mother Core is the lightweight, stable nucleus. All heavy or specialized systems run isolated from the Mother Core process. The Mother Core orchestrates — it does not embed.

### Mother Core (this process)

- Runtime lifecycle management
- Request routing and validation
- Observability and health reporting
- Event bus and timeline
- Watchdog and passive safety
- Config management

### Isolated services (future — separate processes or containers)

| Service | Isolation reason |
|---|---|
| Video generation | Resource-heavy; must not starve the nucleus |
| Image generation | Resource-heavy; GPU-dependent |
| Music / audio generation | Resource-heavy |
| AI model inference | Latency and memory unpredictable; must be bounded |
| Databases | Separate persistence layer; no embedded DB in nucleus |
| External API adapters | Network I/O isolation; failure must not block nucleus |
| App builders | Sandboxed execution; cannot share process space with nucleus |

The Mother Core communicates with isolated services through defined APIs and event contracts. No service may reach into Mother Core internals. The nucleus never imports a service — the service registers with the nucleus through approved channels.

---

## Financial Architecture Vision

Documentation only. Nothing below has been built. No wallets connected. No billing systems active.

### Future capabilities (only after infrastructure stabilization)

- Treasury management layer
- Subscription routing
- Payout routing
- Billing systems
- SaaS payment infrastructure
- App revenue management
- Crypto treasury compatibility
- Stripe / Paddle / App Store billing compatibility
- Binance treasury compatibility
- OKX treasury compatibility

### Future money flow architecture

```
Users
  → Subscription / Billing Providers (Stripe, Paddle, App Store)
  → Treasury Layer
  → Project Treasury Wallet
  → Main Personal Wallet
```

### Financial isolation rules (permanent)

- All treasury systems must remain isolated from the Mother Core runtime
- No private wallet keys stored in runtime systems — ever
- All billing systems must remain sandboxed and auditable
- Financial execution must remain permission-controlled
- All payout systems must support rollback-safe accounting
- Infrastructure stability and security remain higher priority than monetization
- No financial automation without explicit command and audit trail
- The Mother Core runtime must be able to operate with zero financial system connectivity

---

## Constitutional Rules for the Mother Core

These rules apply at every phase, forever, regardless of how the system evolves.

1. The Mother Core always remains the top-level controller of all systems that run on top of it
2. The nucleus must always remain stable, lightweight, isolated, observable, recoverable, and sandboxed
3. Infrastructure stability is always higher priority than intelligence, autonomy, or monetization
4. `blockedExecution: true` in the restart supervisor is a permanent hardcoded constant — not a flag, not a setting
5. All future self-development must remain supervised and command-driven
6. All future recovery systems must remain rollback-safe
7. All future autonomous behavior must require explicit user authorization
8. No private keys, wallet credentials, or financial secrets may exist in the runtime process
9. No AI system may be embedded in the nucleus runtime
10. Every new phase must be tested and stable before the next phase begins

---

## Architecture Decisions

- Config is loaded once at startup; fails fast if PORT is missing or invalid.
- Runtime tracks status: `starting → ready → stopping → stopped`.
- Plugin Manager is a plain class — no DI, no reflection, just register / loadAll / list.
- Logger writes newline-delimited JSON to `process.stderr` with level filtering via `LOG_LEVEL`.
- Shutdown handler gives connections 10 s to drain before forcing `process.exit(1)`.
- Error boundary wraps every route handler; increments error counter and logs on throws.
- Metrics read from `process.memoryUsage()` and `process.cpuUsage()` on demand — no polling.
- Health monitor runs synchronous checks on every request; no timers, no background work.
- Freeze detector uses a single `setInterval` with `.unref()` — no heavy loops.
- Crash detector registers listeners on `uncaughtException`, `unhandledRejection`, `warning`; detection only, no recovery.
- Snapshot ring buffer holds max 10 entries; oldest dropped silently when full.
- Snapshot storage writes atomically (`.tmp` → `rename`); max 20 files; prune-on-write; failure never breaks in-memory flow.
- Timeline ring buffer holds max 200 events; newest-first on read; zero imports from outside core.
- Event bus is synchronous and in-memory; handler errors are swallowed so the bus never throws.
- Watchdog runs every 15 s with `.unref()`; reads raw state only — never calls `getFullHealth()` to avoid circular deps.
- Restart supervisor is a pure on-demand decision engine; `blockedExecution: true` is a hardcoded constant, never a runtime flag.
- Plugin sandbox stores all-denied permissions by construction; no grant path exists in the codebase.
- Runtime state persistence uses a single atomic file; 5 save triggers via event bus; load-on-boot for observation only.
- Recovery tracker uses edge-triggered observations keyed by reason string; severity only escalates; max 50 history.
- Hardening checks raw `req.url` for path traversal before URL parser normalization; security headers applied before routing.
- Secure config reads `process.env` independently on demand; never imports `config.ts`; all sensitive key values masked.
- Task queue stores tasks in-memory (`Map<string, Task>`); `executionBlocked: true` is a hardcoded `true` literal, never a flag; `completedTasks` and `failedTasks` are always `0` until an execution layer exists.
- POST body is parsed via `lib/body.ts` using raw `IncomingMessage` stream; max 64 KB.
- Task persistence uses `importTask()` on boot — no event emitted, no evaluation triggered; loaded tasks are records only.
- `peekTaskPolicy()` in `taskPolicy.ts` is a pure evaluation function — same logic as `evaluateTaskPolicy()` but zero side effects: no counter increments, no event emissions. Used exclusively by the queue orchestrator for read-only inspection.
- Queue orchestrator re-evaluates on every `task_created`, `task_blocked`, and `task_queued` event. `evaluateQueueReadiness()` is also called on every `GET /api/queue/orchestration` request via `listOrchestrationPlan()`.
- Task lifecycle never modifies queue state — it maintains its own `Map<string, TaskLifecycleRecord>` keyed by task ID.
- `archived` is a terminal lifecycle state — the transition validator enforces this; `ALLOWED_TARGETS.get("archived")` returns an empty Set by construction.
- `blocked` tasks can only transition to `archived` — the transition map enforces this structurally, not conditionally.
- `POST /api/tasks/lifecycle/transition` returns HTTP 422 for rejected transitions so callers can distinguish validation errors (400) from policy rejections (422).
- `runtimeSnapshot.ts` derives `healthSummary` directly from subsystem status objects — never calls `getFullHealth()` from `healthMonitor.ts` to avoid circular import.
- Snapshot `status` field is set to `"active"` at write time. `getRuntimeSnapshot()` overrides it from `findSnapshotFile()` result (directory location) so archived snapshots correctly report `"archived"`.
- Retention archival is a `renameSync(active/file, archived/file)` operation — atomic, no data loss, no deletion.
- `POST /api/runtime/recovery/dry-run` is multi-action: `action=dry-run` (default), `validate`, `impact`, `compare`. All actions return `recoveryBlocked: true` and `executionBlocked: true`.
- Router param matching: exact match checked first across all routes, then segment-by-segment param match (`:param` segments). Handlers extract param values from `req.url` directly — no param injection into handler signature.
- `runtimeEventBus.ts` bridge subscriptions call `subscribe()` from `eventBus.ts` — they are internal plumbing and do not appear in `activeSubscriberCount` (which counts only callers of `subscribeRuntimeEvent()`).
- `emitRuntimeEvent()` is re-entrant-safe: `isDispatching` flag + `pendingDispatch[]` queue ensures nested emits (e.g. a handler calling `emitRuntimeEvent`) are processed sequentially after the current dispatch completes, not recursively.
- `dispatchFailures` is a monotonically increasing counter — it never decrements. A single handler throw moves the health check from pass to warn permanently for the process lifetime.
- `HEALTH_CHECK_COUNT` in `runtimeSnapshot.ts` is updated to 29 after Phase 32 — new snapshots will reflect this; older immutable snapshots retain their original value at time of creation.
- `commandGateway.ts` `evaluateCommand()` is a pure function (no side effects) — safe to call independently of `submitCommand()`. The route handler calls both for policy transparency in the response.
- `commandExecutionBlocked: true`, `executionBlocked: true`, and `recoveryBlocked: true` in `commandGateway.ts` are all typed literals — never runtime flags.
- `POST /api/commands` always returns 201 — the record is always created regardless of risk level or blocked status. The `status` field in the response reflects the evaluation outcome.
- `registerSubsystemState()` is idempotent — re-registering an existing subsystem returns the existing record unchanged. Only the first registration creates the record.
- `updateSubsystemState()` returns `null` if the subsystem does not exist — callers must register before updating. Version starts at 1 on registration, increments by 1 on each update call.
- `executionBlocked: true` and `recoveryBlocked: true` in every SubsystemState are typed literal `true` values embedded at write time — the update path always overwrites them to `true` regardless of patch input.
- Seeded subsystems all start with `status: "initialized"` and `health: "unknown"`. External callers (future phases) may call `updateSubsystemState()` to transition to `ready`, `degraded`, etc. as real health becomes known.
- `coreSubsystemsPresent` checks exactly: runtime, health_monitor, task_queue, task_policy, command_gateway — if any are missing the health check returns `fail`.
- `runtimeDependencyGraph.ts` graph is immutable after init — there is no public mutation function. The graph is a snapshot of the registry's declared dependencies at boot time.
- Cycle detection: DFS with `visiting` (in-stack) set. A node encountered while already in `visiting` means a cycle. The path to that node (sliced from `path.indexOf(node)`) is recorded as the cycle. Both `visiting` and `visited` are per-DFS-root call to correctly detect all cycles.
- `depth` computation uses a memoization map and a `stack` Set for cycle guarding — if a node is in `stack`, its contribution to depth is 0 rather than infinite recursion.
- `allUpstream`/`allDownstream` are full transitive closures. Each call passes a fresh `visited` Set to prevent double-counting in diamond-shaped dependency graphs (A→B, A→C, B→D, C→D — D appears only once in allUpstream).
- `runtime` is always the single root (depth 0). All other subsystems transitively depend on it. Graph grew from 17 → 20 nodes in Phase 32 (meta subsystems added to registry).
- Capability matrix records are immutable after `initCapabilityMatrix()` returns — no mutation, no grant, no revoke API exists anywhere in the codebase.
- `initCapabilityMatrix()` calls `listSubsystemStates()` at call time — must run after `initRuntimeStateRegistry()` and `initRuntimeDependencyGraph()`.
- `emitRuntimeEvent()` in capability matrix init uses `severity: "warning"` if any invalid references are detected, `"info"` if clean.
- No framework, no ORM, no codegen dependencies in the runtime package.

---

## Circular Dependency Rules

| Module | Rule |
|---|---|
| `timeline.ts` | Zero project imports — everything imports from it, never the reverse |
| `eventBus.ts` | Zero project imports — all modules emit into it, it never imports back |
| `snapshots.ts` | Must never import from `healthMonitor.ts` |
| `snapshotStorage.ts` | Imports only `node:fs`, `node:path`, and `logger` |
| `watchdog.ts` | Must never import from `healthMonitor.ts` — reads raw state directly |
| `restartSupervisor.ts` | Reads from `watchdog`, `freezeDetector`, `crashDetector`, `runtime`; never from `healthMonitor` |
| `pluginSandbox.ts` | Imports only `eventBus`, `timeline`, `logger` |
| `runtimeState.ts` | Must never import from `healthMonitor.ts` or `snapshots.ts`; gets snapshot ID via event bus |
| `recoveryTracker.ts` | Imports only `eventBus`, `timeline`, `logger`, `node:crypto`; never imports from any detector directly |
| `hardening.ts` | Imports only `eventBus`, `timeline`, `logger`, `node:http`; no circular risk |
| `secureConfig.ts` | Imports only `logger`; never imports `config.ts` |
| `taskQueue.ts` | Imports only `eventBus`, `timeline`, `logger`, `node:crypto`; no execution path |
| `taskPersistence.ts` | Imports `taskQueue` (for `listTasks`, `importTask`) but `taskQueue` never imports `taskPersistence` |
| `queueOrchestrator.ts` | Imports `taskQueue` (for `listTasks`) and `taskPolicy` (for `peekTaskPolicy`); neither imports it back |
| `taskLifecycle.ts` | Imports `taskQueue` (for `getTask`, `listTasks`) and `taskPolicy` (for `peekTaskPolicy`); maintains own record map; never modifies `taskQueue` state |
| `runtimeSnapshot.ts` | Imports `taskQueue`, `taskLifecycle`, `taskPolicy`, `queueOrchestrator`, `taskPersistence`, `runtime`, `router`; must never import `healthMonitor` (circular — healthMonitor imports runtimeSnapshot) |
| `runtimeEventBus.ts` | Imports `eventBus` (one-way bridge via `subscribe()`); must never be imported by `eventBus` (zero-import rule). `healthMonitor` imports `runtimeEventBus` for 25th check. `runtime` and `shutdown` import it for direct emits. |
| `commandGateway.ts` | Imports `eventBus`, `timeline`, `logger`, `runtimeEventBus`; must never import `healthMonitor` (healthMonitor imports commandGateway for 26th check, not vice versa). No circular deps. |
| `runtimeStateRegistry.ts` | Imports `eventBus`, `timeline`, `logger`, `runtimeEventBus`; must never import `healthMonitor` (healthMonitor imports runtimeStateRegistry for 27th check, not vice versa). No circular deps. |
| `runtimeDependencyGraph.ts` | Imports `runtimeStateRegistry` (read-only, `listSubsystemStates()` only), `eventBus`, `timeline`, `logger`, `runtimeEventBus`; must never import `healthMonitor` (healthMonitor imports runtimeDependencyGraph for 28th check). `initRuntimeDependencyGraph()` must run after `initRuntimeStateRegistry()`. |
| `runtimeCapabilityMatrix.ts` | Imports `runtimeStateRegistry` (read-only, `listSubsystemStates()` only), `eventBus`, `timeline`, `logger`, `runtimeEventBus`; must never import `healthMonitor` (healthMonitor imports runtimeCapabilityMatrix for 29th check). `initCapabilityMatrix()` must run after `initRuntimeDependencyGraph()`. |
| `workspaceShell.ts` | Imports only `./projectRegistry`; must never import `persistentStore`, `workspaceSnapshots`, `workspaceTimeline`, or any subsystem module. It is a pure aggregation facade — no state, no init, no persistence. |
| `workspaceSnapshots.ts` | Imports `./persistentStore` (read/write), `./workspaceShell` (all 5 panel builders + summary + navigation + health), `node:crypto`. Must never import from `workspaceTimeline` (timeline imports snapshots, not vice versa). `captureWorkspaceSnapshot()` calls `workspaceShell` functions — must only be called after all project registry init functions have run. |
| `workspaceTimeline.ts` | Imports `./projectRegistry` (`listProjects`, `getProjectActivity`) and `./workspaceSnapshots` (`listWorkspaceSnapshots`). Must never import `workspaceShell` directly (all needed data is available via projectRegistry + workspaceSnapshots). No persistence, no init, no subsystem registration. Pure re-aggregation on every call. |
| `workspaceDiff.ts` | Imports only `./workspaceSnapshots` (`listWorkspaceSnapshots`, `getWorkspaceSnapshotById`). Must never import `workspaceShell`, `projectRegistry`, or `workspaceTimeline`. `computeDiff()` is a private pure function — no logging, no throwing, no mutation. `getWorkspaceDiff()` returns a tagged union `{ result } | { error, status }` — never throws. No persistence, no init, no subsystem registration. |
| `workspaceAuditReport.ts` | Imports `./workspaceSnapshots`, `./workspaceDiff`, `./workspaceTimeline`, `./workspaceShell`, `./persistentStore`, `node:crypto`. Previously terminal node — now imported by `workspaceAuditDigest`. Has `initWorkspaceAuditReports()` — must run after `initWorkspaceSnapshots()` and `initPersistentStore()`. Ring buffer max 10, atomic persist on every create. `createAuditReport()` returns `{ report } | { error, status }` — never throws. `listAuditReports(filter?)` accepts `AuditReportFilter`. |
| `workspaceAuditDigest.ts` | Imports `./workspaceShell`, `./workspaceSnapshots`, `./workspaceAuditReport`, `node:crypto`. Terminal node — parallel to `workspaceGovernanceScorecard`. Must never be imported by any of its upstream modules. No init function, no persistence, no subsystem registration. `getWorkspaceAuditDigest()` is always fresh — every call generates a new `digestId`, calls `getWorkspaceSummary()`, `getWorkspaceHealth()`, `getLatestWorkspaceSnapshot()`, `listAuditReports({ limit: 10 })`, and returns a fully assembled `WorkspaceAuditDigest`. No state mutation of any kind. |
| `workspaceGovernanceScorecard.ts` | Imports `./workspaceShell`, `./workspaceSnapshots`, `./workspaceAuditReport`, `node:crypto`. **Terminal node** — parallel to `workspaceAuditDigest`. Must never be imported by any of its upstream modules. No init function, no persistence, no subsystem registration. `getWorkspaceGovernanceScorecard()` is always fresh — every call computes a deterministic score from `getWorkspaceSummary()`, `getWorkspaceHealth()`, `listWorkspaceSnapshots()`, `listAuditReports({ limit: 10 })`. `scorecardId` is `sha256(generatedAt).slice(0,16)` — deterministic per millisecond. No randomBytes. No state mutation of any kind. |
| `workspacePolicyComplianceLedger.ts` | Imports `./accessEnforcement` (`getAccessEnforcementPolicies`) and `./auditLog` (`getAuditLogEntries`), `node:crypto`. **Enforcement/observability layer leaf** — NOT part of the workspace DAG. Parallel to the workspace terminal nodes but drawing from different upstream layers. No init function, no persistence, no subsystem registration. `getPolicyComplianceLedger()` scans all ≤1000 audit entries against all 89 registered policies via local `matchPath()`. `ledgerId` is `sha256(generatedAt).slice(0,16)`. No state mutation of any kind. |

---

## Phase 112 — Governance Scorecard Validation Dimension

**Completed.** `validation_integrity` added as the 6th weighted governance dimension to `workspaceGovernanceScorecard.ts`. Sourced from `runWidgetRegistryValidation()` (pure static leaf, zero circular deps). Weight redistribution keeps sum exactly 100. No new endpoint, no new policy, no new health check, no new subsystem, no new persistence store.

### Change surface

**Modified**: `core/workspaceGovernanceScorecard.ts`

1. New import: `runWidgetRegistryValidation` from `./widgetRegistryHealth`
2. Weight constants redistributed: `WEIGHT_AUDIT` 25→22, `WEIGHT_SNAPSHOT` 25→22, `WEIGHT_RATIO` 15→13, `WEIGHT_QUOTA` 15→13, new `WEIGHT_VALIDATION=10`
3. New scoring function: `scoreValidationIntegrity(registryHealthy, violationCount, contractCount, passedContractCount)` — O(37) bounded, pure
4. `ScorecardSignals` interface extended: `validationIntegrityScore`, `validationIntegrityWeight`, `widgetContractViolations`, `widgetRegistryHealthy`
5. `getWorkspaceGovernanceScorecard()` extended: calls `runWidgetRegistryValidation()`, counts `passedContractCount`, populates 4 new signal fields, appends `validation_integrity` category to `categories[]`, passes `rawValidation` to `buildRecommendations()`
6. `buildRecommendations()` extended: 7th parameter `rawValidation`; fires advisory at `rawValidation < 100` (not < 50 — integrity is binary)

No other files modified. All other changes are documentation.

### Weight redistribution

| Dimension | Old weight | New weight | Delta |
|---|---|---|---|
| `capacity_utilization` | 20 | 20 | 0 |
| `audit_report_coverage` | 25 | 22 | −3 |
| `snapshot_availability` | 25 | 22 | −3 |
| `member_project_ratio` | 15 | 13 | −2 |
| `quota_adoption` | 15 | 13 | −2 |
| `validation_integrity` | — | 10 | +10 |
| **Total** | **100** | **100** | **0** |

### Scoring function

```typescript
scoreValidationIntegrity(registryHealthy, violationCount, contractCount, passedContractCount):
  if registryHealthy && violationCount === 0: return 100
  if contractCount === 0: return 0
  return clamp(Math.round(passedContractCount / contractCount * 100), 0, 100)
```

- **100**: all 37 contracts pass — `registryHealthy=true`, `violationCount=0`
- **0–99**: proportional to passing widget fraction — `passedContractCount / contractCount`
- **0**: empty registry (`contractCount=0`)

### Circular-dependency constraint

Must import `runWidgetRegistryValidation` (pure static leaf), NOT `runWidgetValidationProbe`. The latter triggers `getWorkspaceVisualShellComposed` → `getWorkspaceObservationLedger` → `getWorkspaceGovernanceScorecard` → circular. The import DAG is:

```
workspaceGovernanceScorecard → widgetRegistryHealth → workspaceWidgetContracts (terminal)
```

No new edge into `workspaceGovernanceScorecard` from any observer or composition module.

### Phase 112 baseline metrics

| Metric | Value |
|---|---|
| New endpoints | 0 |
| New policies | 0 |
| New subsystems | 0 |
| New health checks | 0 |
| New persistence stores | 0 |
| New init functions | 0 |
| New graph nodes | 0 |
| Breakdown entries | 6 (was 5) |
| Weight sum invariant | 100 |
| Tests passed | 30/30 |
| Restart survival | Verified |
| Typecheck | Clean |
| Governance grade (current) | B (score=77) |

---

## Phase 111 — Observation Ledger Analytics V2

**Completed.** Additive extension of `WorkspaceObservationLedgerAnalytics` with five validation integrity fields derived from the persisted ledger history ring. No new endpoint, no new policy, no new health check, no new subsystem, no new persistence store.

### Change surface

**Modified**: `core/workspaceObservationLedgerAnalytics.ts`

1. New import: `ValidationHealth` from `./workspaceObservationLedger`
2. New constant: `VALIDATION_HEALTH_ORDER: ValidationHealth[]` (`["healthy", "degraded", "failed"]`)
3. New helpers: `extractValidationSignals()`, `deriveBestValidationHealth()`, `deriveWorstValidationHealth()`
4. `AnalyticsSummary` extended: 4 new fields (`averageWidgetCoveragePercent`, `bestValidationHealth`, `worstValidationHealth`, `validationTrendDirection`)
5. `AnalyticsTransitions` extended: 1 new field (`validationHealthChanges`)
6. `getWorkspaceObservationLedgerAnalytics()` computes `validationSignals[]` from `extractValidationSignals()` per entry, derives all 5 new fields, and counts `validationHealthChanges` in the existing transition loop

No other files modified. All other changes are documentation.

### New field derivation rules

| Field | Location | Derivation |
|---|---|---|
| `averageWidgetCoveragePercent` | `summary` | `Math.round(sum(widgetCoveragePercent) / count)`, 0 if ring empty |
| `bestValidationHealth` | `summary` | Minimum `VALIDATION_HEALTH_ORDER` index seen; null if ring empty |
| `worstValidationHealth` | `summary` | Maximum `VALIDATION_HEALTH_ORDER` index seen; null if ring empty |
| `validationTrendDirection` | `summary` | `deriveTrendDirection(oldest.widgetCoveragePercent, newest.widgetCoveragePercent)`; null if < 2 entries |
| `validationHealthChanges` | `transitions` | Count of consecutive oldest-first pairs where `validationHealth` differs |

### Health ranking

```
healthy (index 0) > degraded (index 1) > failed (index 2)
```

`bestValidationHealth` = lowest index seen (best outcome). `worstValidationHealth` = highest index seen (worst outcome).

### Backward compatibility

`extractValidationSignals()` uses the same `!= null` guard pattern as Phase 110's `LedgerHistoryListItem` projection. Pre-Phase-109 entries without `validationProbe` fall back to `validationHealth="failed"` and `widgetCoveragePercent=0`. This is intentionally conservative — a ring with pre-Phase-109 entries will show:
- `worstValidationHealth="failed"` (correct: older entries genuinely unknown)
- `validationHealthChanges>=1` (correct: transition from "failed" fallback to "healthy" when Phase-109+ entries appear)
- `validationTrendDirection="improving"` if oldest=0 and newest=100 (correct: schema integrity improved once Phase 109 was deployed)

### Phase 111 baseline metrics

| Metric | Value |
|---|---|
| New endpoints | 0 |
| New policies | 0 |
| New subsystems | 0 |
| New health checks | 0 |
| New persistence stores | 0 |
| New init functions | 0 |
| New graph nodes | 0 |
| Tests passed | 34/34 |
| Restart survival | Verified |
| Typecheck | Clean |
| Backward compatibility | Verified — fallback to `"failed"` / `0` for pre-Phase-109 entries |

---

## Phase 110 — Ledger History Capture V2

**Completed.** Additive extension of `LedgerHistoryListItem` to expose validation integrity signals introduced in Phase 109, allowing operators to see `validationHealth` and `widgetCoveragePercent` directly in history list responses without requiring a detail fetch. No new endpoint, no new policy, no new health check, no new subsystem, no new persistence store.

### Change surface

**Modified**: `core/workspaceObservationLedgerHistory.ts`

1. New import: `ValidationHealth` from `./workspaceObservationLedger`
2. `LedgerHistoryListItem` extended: two new fields (`validationHealth: ValidationHealth`, `widgetCoveragePercent: number`)
3. `listWorkspaceObservationLedgerHistory()` projection updated: reads `e.snapshot.validationProbe` with runtime-safe type narrowing and backward-compatible fallbacks

No other files modified. All other changes are documentation.

### Backward compatibility

Older `LedgerHistoryEntry` snapshots (captured before Phase 109) will not have a `validationProbe` field. The projection handles this with a runtime guard:

```typescript
const vp = e.snapshot.validationProbe as
  | { validationHealth: ValidationHealth; widgetCoveragePercent: number }
  | undefined | null;

// Safe fallback — never crashes on missing field
const validationHealth: ValidationHealth =
  vp != null && typeof vp.validationHealth === "string"
    ? (vp.validationHealth as ValidationHealth)
    : "failed";
const widgetCoveragePercent: number =
  vp != null && typeof vp.widgetCoveragePercent === "number"
    ? vp.widgetCoveragePercent
    : 0;
```

Fallback contract: `validationHealth="failed"`, `widgetCoveragePercent=0` for any entry that predates Phase 109.

### `LedgerHistoryListItem` — complete interface (Phase 110)

| Field | Type | Source | Notes |
|---|---|---|---|
| `captureSeq` | `number` | `e.captureSeq` | Monotonic, ring-resume on boot |
| `createdAt` | `string` | `e.createdAt` | ISO timestamp |
| `ledgerId` | `string` | `e.ledgerId` | 16-char hex |
| `overallObservationHealth` | `ObservationHealth` | `summary.overallObservationHealth` | healthy/degraded/critical |
| `governanceReadiness` | `GovernanceGrade` | `summary.governanceReadiness` | A–F |
| `observationCoverage` | `number` | `summary.observationCoverage` | 0–100 |
| `exposureRiskLevel` | `ExposureRiskLevel` | `summary.exposureRiskLevel` | low/medium/high/none |
| `validationHealth` *(new)* | `ValidationHealth` | `snapshot.validationProbe.validationHealth` | healthy/degraded/failed; fallback "failed" |
| `widgetCoveragePercent` *(new)* | `number` | `snapshot.validationProbe.widgetCoveragePercent` | 0–100; fallback 0 |
| `executionBlocked` | `true` | constant | Always `true` |

### Phase 110 baseline metrics

| Metric | Value |
|---|---|
| New endpoints | 0 |
| New policies | 0 |
| New subsystems | 0 |
| New health checks | 0 |
| New persistence stores | 0 |
| New init functions | 0 |
| New graph nodes | 0 |
| Tests passed | 26/26 |
| Restart survival | Verified |
| Typecheck | Clean |
| Backward compatibility | Verified — fallback to `"failed"` / `0` for pre-Phase-109 entries |

---

## Phase 109 — Validation Probe Integration into Observation Ledger

**Completed.** Additive integration of widget contract registry validation signals directly into `WorkspaceObservationLedger`. No new endpoint, no new policy, no new health check, no new subsystem. Pure additive field addition.

### Change surface

**Modified**: `core/workspaceObservationLedger.ts`

1. New import: `runWidgetRegistryValidation` from `./widgetRegistryHealth`
2. New exported type: `ValidationHealth = "healthy" | "degraded" | "failed"`
3. New exported interface: `ValidationProbeHealth` (8 fields)
4. `ObservationLedgerSummary` extended: `validationProbeHealth: ValidationProbeHealth`
5. `WorkspaceObservationLedger` extended: `validationProbe: ValidationProbeHealth`
6. New helper: `deriveValidationHealth(allWidgetsValid, failedFieldCount, widgetCoveragePercent)`
7. `deriveObservationHealth()` gains a 5th parameter `validationHealth: ValidationHealth`
8. `getWorkspaceObservationLedger()` now calls 7 sources (was 6); `validationRegistryResult` computed from `runWidgetRegistryValidation()`

### Why `runWidgetRegistryValidation()` and not `runWidgetValidationProbe()`

`runWidgetValidationProbe()` creates a circular call chain:

```
getWorkspaceObservationLedger()
  → runWidgetValidationProbe()
    → getWorkspaceVisualShellComposed()
      → getWorkspaceObservationLedger()   ← CIRCULAR (infinite loop)
```

`runWidgetRegistryValidation()` is a pure static leaf with no circular risk:

```
getWorkspaceObservationLedger()
  → runWidgetRegistryValidation()
    → getAllWidgetContracts()             ← terminal leaf
```

### `ValidationProbeHealth` field mapping

| Field | Source | Formula |
|---|---|---|
| `allWidgetsValid` | `registryResult.registryHealthy` | direct |
| `passedWidgets` | `contractValidations.filter(c=>c.passed).length` | exact per-contract count |
| `failedWidgets` | `totalWidgets - passedWidgets` | derived |
| `widgetCoveragePercent` | `round(passedWidgets/totalWidgets*100)` | 0 if no contracts |
| `failedFieldCount` | `requiredFieldViolations.length + enumerationViolations.length + executionBlockedViolations.length + schemaVersionMismatches.length` | 4 violation arrays |
| `fieldCoveragePercent` | `round((totalWidgets×4 − failedFieldCount)/(totalWidgets×4)×100)` | 4 boolean checks per contract |
| `validationHealth` | `deriveValidationHealth(...)` | failed/healthy/degraded |
| `executionBlocked` | `true` | constant |

### `ValidationHealth` derivation

| Condition | Result |
|---|---|
| `widgetCoveragePercent === 0` | `"failed"` |
| `allWidgetsValid && failedFieldCount === 0` | `"healthy"` |
| otherwise | `"degraded"` |

### `overallObservationHealth` priority table (updated)

| Condition | Result |
|---|---|
| `probeHealth === "none_passed"` | `critical` |
| `observationCoverage < 25` | `critical` |
| `exposureRiskLevel === "high"` | `critical` |
| `validationHealth === "failed"` *(new)* | `critical` |
| `probeHealth === "partial"` | `degraded` |
| `observationCoverage < 50` | `degraded` |
| `exposureRiskLevel === "medium"` | `degraded` |
| `governanceReadiness === "D" or "F"` | `degraded` |
| `validationHealth === "degraded"` *(new)* | `degraded` |
| none of the above | `healthy` |

### Phase 109 baseline metrics

| Metric | Value |
|---|---|
| New endpoints | 0 |
| New policies | 0 |
| New subsystems | 0 |
| New health checks | 0 |
| New persistence stores | 0 |
| New init functions | 0 |
| New graph nodes | 0 |
| Tests passed | 28/28 |
| Restart survival | Verified |
| Typecheck | Clean |
| Circular dependency | Avoided — static registry path used |

---

## Phase 107 — Registry Coherence Diagnostic Endpoint

**Completed.** Exposes the full `WidgetRegistryHealthResult` from Phase 106 via `GET /api/workspace/visual-shell/widgets/registry/coherence`. Read-only, deterministic, zero-state wrapper. No new logic — pure pass-through from the existing `runWidgetRegistryValidation()` function.

### Change surface

**Modified**: `routes/workspace.ts`

New import:
```typescript
import { runWidgetRegistryValidation } from "../core/widgetRegistryHealth";
```

New handler (3 lines):
```typescript
export function handleWidgetRegistryCoherence(_req: IncomingMessage, res: ServerResponse): void {
  const result = runWidgetRegistryValidation();
  sendJson(res, 200, result);
}
```

**Modified**: `server.ts`

Route registered before `/widgets` (first in the group):
```typescript
router.get("/api/workspace/visual-shell/widgets/registry/coherence", handleWidgetRegistryCoherence);
router.get("/api/workspace/visual-shell/widgets", handleWidgetContractList);
```

**Modified**: `core/accessEnforcement.ts`

New policy #106: `GET /api/workspace/visual-shell/widgets/registry/coherence` — read/viewer.
Description updated to `106-route policy map`.

### Response shape

**`WidgetRegistryHealthResult`** (verbatim from Phase 106 type):

| Field | Type | Value (healthy) |
|---|---|---|
| `registryHealthy` | boolean | `true` |
| `summary` | `RegistryCoherenceSummary` | contractCount=37, compactTypeCount=15, uniqueWidgetIdCount=37, violationCount=0 |
| `compactTypeValidations` | `CompactTypeValidation[15]` | All canonical, all present, sorted alphabetically |
| `contractValidations` | `ContractRegistryValidation[37]` | All passed, all 4 booleans true |
| `missingCompactTypes` | `string[]` | `[]` |
| `invalidCompactTypes` | `string[]` | `[]` |
| `duplicateWidgetIds` | `string[]` | `[]` |
| `schemaVersionMismatches` | `string[]` | `[]` |
| `executionBlockedViolations` | `string[]` | `[]` |
| `enumerationViolations` | `string[]` | `[]` |
| `requiredFieldViolations` | `string[]` | `[]` |
| `executionBlocked` | `true` | `true` |

### Route depth and ordering

| Route | Depth (parts) | Registration order |
|---|---|---|
| `/widgets/registry/coherence` | 6 | 1st (exact) |
| `/widgets` | 4 | 2nd |
| `/widgets/validate` | 6 | 3rd |
| `/widgets/validate/capture` | 7 | 4th |
| `/widgets/validate/history` | 7 | 5th |
| `/widgets/validate/history/:captureSeq` | 8 | 6th |
| `/widgets/:widgetId` | 5 | 7th |

`/registry/coherence` cannot be captured by `/:widgetId` (depth 6 ≠ depth 5). The router's first-pass exact match (line 37) resolves it before the parameterized scan (line 39+) is even attempted.

### Determinism

`runWidgetRegistryValidation()` is a pure function — no timestamps, no IDs, no monotonic counters. The response is bit-for-bit identical across consecutive calls and across server restarts. This is intentional: the registry is static and the validation result is time-independent.

### Phase 107 baseline metrics

| Metric | Value |
|---|---|
| New endpoints | 1 (`GET /widgets/registry/coherence`) |
| New policies | 1 (105→106) |
| New subsystems | 0 |
| New health checks | 0 |
| New persistence stores | 0 |
| New init functions | 0 |
| New graph nodes | 0 |
| Tests passed | 30/30 |
| Restart survival | Verified |
| Typecheck | Clean |

---

## Phase 106 — Registry Coherence Health Check

**Completed.** Introduces `widget_contract_registry` as health check #38 — a governed, read-only coherence validation layer that continuously validates the Widget Contract Registry against the Phase 101 compact data type system. No new endpoints, no new policies, no new subsystems, no init function, no persistence.

### Change surface

**New file**: `core/widgetRegistryHealth.ts`

Pure static validation module. Exports:

| Export | Type | Purpose |
|---|---|---|
| `WidgetRegistryHealthResult` | interface | Full validation result (registryHealthy + 7 violation arrays + compactTypeValidations + contractValidations) |
| `RegistryCoherenceSummary` | interface | Aggregate counts and match flags |
| `CompactTypeValidation` | interface | Per-compact-type presence and canonical status |
| `ContractRegistryValidation` | interface | Per-contract validation result (4 boolean checks + passed) |
| `WidgetRegistryHealthStatus` | interface | Slim status type for `healthMonitor.ts` integration |
| `runWidgetRegistryValidation()` | function | Full validation — returns `WidgetRegistryHealthResult` |
| `getWidgetRegistryHealthStatus()` | function | Called by health monitor — returns `WidgetRegistryHealthStatus` |

**Modified**: `core/workspaceWidgetContracts.ts`

New export:
```typescript
export function getAllWidgetContracts(): ReadonlyArray<WidgetContract> {
  return CONTRACT_REGISTRY;
}
```

**Modified**: `core/healthMonitor.ts`

New import:
```typescript
import { getWidgetRegistryHealthStatus } from "./widgetRegistryHealth";
```

New check appended at end of `runChecks()`:
```typescript
let widgetContractRegistryCheck: Check;
try {
  const wch = getWidgetRegistryHealthStatus();
  widgetContractRegistryCheck = {
    name: "widget_contract_registry",
    status: wch.registryHealthy ? "pass" : "fail",
    detail: wch.detail,
  };
} catch {
  widgetContractRegistryCheck = {
    name: "widget_contract_registry",
    status: "fail",
    detail: "Widget contract registry health check internal error",
  };
}
checks.push(widgetContractRegistryCheck);
```

**Modified**: `core/diagnostics.ts`

```typescript
const HEALTH_CHECKS_TOTAL = 38;  // was 37
```

**Modified**: `core/baseline.ts`

```typescript
const BASELINE_HEALTH_CHECK_COUNT = 38;  // was 36 (nucleus seal) → updated to live count
```

### Validation rules (8 invariants)

| # | Rule | Violation array | Severity |
|---|---|---|---|
| 1 | `CONTRACT_INDEX.size === 37` | `contractCountMatch: false` in summary | fail |
| 2 | All widgetIds unique | `duplicateWidgetIds[]` | fail |
| 3 | All compactDataTypes in canonical set of 15 | `invalidCompactTypes[]` | fail |
| 4 | All 15 canonical compactDataTypes present in registry | `missingCompactTypes[]` | fail |
| 5 | All `schemaVersion === "1"` | `schemaVersionMismatches[]` | fail |
| 6 | All `examplePayload.executionBlocked === true` (strict) | `executionBlockedViolations[]` | fail |
| 7 | All enumerations have `values.length > 0` | `enumerationViolations[]` | fail |
| 8 | All `requiredFields[]` appear in `fields[].fieldName` | `requiredFieldViolations[]` | fail |

`registryHealthy = true` iff all 8 invariants hold and `violationCount === 0`.

### Canonical compact data types (Phase 101, sorted)

```
audit, crash, exposure, freeze, governance, heatmap, health,
ledger, members, metrics, observation_coverage, probe, projects,
static_reference, trend
```

These 15 values are the discriminant literals of the `CompactDataPayload` union in `workspaceVisualShellComposition.ts`. They are mirrored in `CANONICAL_COMPACT_TYPES` (frozen `readonly string[]`) in `widgetRegistryHealth.ts`. Any new compactDataType added to the composition layer must also be added to this array.

### Healthy detail string

```
Widget contract registry coherent — 37 contracts, 15 compact types, 0 violations
```

### Import graph position

`widgetRegistryHealth.ts` is a leaf node importing from `workspaceWidgetContracts.ts` (another leaf). It does NOT import from any live data source, any persistence layer, or any subsystem with init state. Its position in the import graph: `healthMonitor → widgetRegistryHealth → workspaceWidgetContracts`.

### Three-constant sync rule

When the health check count changes, three constants must be updated atomically:

| File | Constant | Value after Phase 106 |
|---|---|---|
| `core/diagnostics.ts` | `HEALTH_CHECKS_TOTAL` | 38 |
| `core/baseline.ts` | `BASELINE_HEALTH_CHECK_COUNT` | 38 |
| `NUCLEUS_LOCK.md` | Total health checks column | 38 |

`BASELINE_LOCK.json` retains the frozen nucleus-seal value of 36. The `baseline.healthCheckCount` field in `GET /api/diagnostics/snapshot` correctly shows `{ baseline: 36, live: 38, match: false }` — this is intentional documented drift, not a bug.

### Phase 106 baseline metrics

| Metric | Value |
|---|---|
| New endpoints | 0 |
| New policies | 0 |
| New subsystems | 0 |
| New health checks | 1 (`widget_contract_registry`, check #38) |
| New persistence stores | 0 |
| New init functions | 0 |
| New graph nodes | 0 |
| Tests passed | 30/30 |
| Restart survival | Verified |
| Typecheck | Clean |
| Forbidden patterns | None (no eval, Function, exec, spawn, setTimeout, setInterval) |
| Secrets exposure | None |

---

## Phase 105 — Validation History Detail Endpoint

**Completed.** Additive read-only extension to the Phase 104 validation history ring. Exposes the full stored `WidgetValidationProbeResult` for a single captureSeq via `GET /api/workspace/visual-shell/widgets/validate/history/:captureSeq`. No new persistence, no new init, no new subsystem, no new health check. Extends `workspaceWidgetValidationHistory.ts` only.

### Change surface

**Module extended**: `core/workspaceWidgetValidationHistory.ts`

New exported type:
```typescript
export interface ValidationHistoryDetailResult {
  captureSeq: number;
  createdAt: string;
  probeId: string;
  probeSnapshot: WidgetValidationProbeResult;  // full Phase 103 probe result
  executionBlocked: true;
}
```

New exported function:
```typescript
export function getWidgetValidationHistoryDetail(captureSeq: number): ValidationHistoryDetailResult | null {
  const entry = historyRing.find((e) => e.captureSeq === captureSeq);
  if (entry === undefined) return null;
  return {
    captureSeq: entry.captureSeq,
    createdAt: entry.createdAt,
    probeId: entry.probeId,
    probeSnapshot: entry.snapshot,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
```

**Route handler** (`routes/workspace.ts`):

```typescript
export function handleWidgetValidationHistoryDetail(req, res) {
  const rawSeq = req.url.split("?")[0].split("/").at(-1) ?? "";
  const captureSeq = parseInt(rawSeq, 10);
  // strict guard: non-integer, float, zero, negative → 404
  if (!rawSeq || isNaN(captureSeq) || captureSeq <= 0 || String(captureSeq) !== rawSeq) {
    return sendError(res, 404, ...);
  }
  const detail = getWidgetValidationHistoryDetail(captureSeq);
  if (detail === null) return sendError(res, 404, ...);
  sendJson(res, 200, detail);
}
```

**Route registration** (`server.ts`): registered after `GET /history` and before `GET /:widgetId` — no routing conflict (router enforces length-equality on parameterized matches; the new route is 2 segments deeper than `/:widgetId`).

### List vs detail asymmetry

| Endpoint | Returned type | Contains `results[]`? | Contains `fieldResults[]`? |
|---|---|---|---|
| `GET /history` | `ValidationHistoryListResult` (summary items) | No | No |
| `GET /history/:captureSeq` | `ValidationHistoryDetailResult` (full snapshot) | Yes (37 entries) | Yes (220 total) |

### Response shape

**`ValidationHistoryDetailResult`**:

| Field | Type | Notes |
|---|---|---|
| `captureSeq` | number | Matches URL param |
| `createdAt` | string | ISO timestamp from probe execution |
| `probeId` | string | 16-char hex (sha256-derived) — matches list entry |
| `probeSnapshot` | `WidgetValidationProbeResult` | Full Phase 103 probe result: summary + results[37] + fieldCoverage |
| `executionBlocked` | `true` | literal |

### Error handling

| Input | HTTP status | Reason |
|---|---|---|
| Non-integer (e.g. `"abc"`) | 404 | `isNaN(parseInt("abc", 10))` |
| Float (e.g. `"1.5"`) | 404 | `String(1) !== "1.5"` |
| Zero | 404 | `captureSeq <= 0` |
| Negative | 404 | `captureSeq <= 0` |
| Valid integer not in ring | 404 | `historyRing.find()` returns `undefined` |
| Valid integer in ring | 200 | `ValidationHistoryDetailResult` returned |

### Phase 105 baseline metrics

| Metric | Value |
|---|---|
| New endpoints | 1 (`GET /validate/history/:captureSeq`) |
| New policies | 1 (104→105) |
| New subsystems | 0 |
| New health checks | 0 |
| New persistence stores | 0 |
| New init functions | 0 |
| Tests passed | 30/30 |
| Restart survival | Verified |
| 404 edge cases | 4 (non-integer, float, zero, unknown seq) |
| Typecheck | Clean |

---

## Phase 104 — Validation Probe Snapshot Capture

**Completed.** Introduces a governed persistence ring for Widget Contract Validation Probe results. Each capture runs a fresh probe, stores a full `WidgetValidationProbeResult` snapshot in an append-only ring buffer (max 10), and exposes a summary-only history list. Two new endpoints: `POST /api/workspace/visual-shell/widgets/validate/capture` (write, operator) and `GET /api/workspace/visual-shell/widgets/validate/history` (read, viewer). No rendering, no autonomous execution, no mutation outside the ring.

### Module: `workspaceWidgetValidationHistory.ts`

```
initWorkspaceWidgetValidationHistory()
  ↓
  stored ← readStore("workspace-widget-validation-history")
  valid ← stored.filter(isValidEntry)       [skips malformed entries]
  historyRing ← valid.slice(-10)            [bounded to MAX_ENTRIES]
  nextCaptureSeq ← max(stored seqs) + 1     [monotonic across restarts]

captureWidgetValidationSnapshot()
  ↓
  probe ← runWidgetValidationProbe()        [one live call — reads all 37 widgets]
  captureSeq ← nextCaptureSeq++
  entry ← { captureSeq, createdAt, probeId, snapshot: probe, executionBlocked: true }
  historyRing.push(entry)
  while ring.length > 10: ring.shift()     [prune oldest]
  flush() → writeStore(ring)               [try/catch, never throws]
  → ValidationHistoryCaptureResult

listWidgetValidationHistory()
  ↓
  sorted ← [...historyRing].sort(desc captureSeq)  [newest-first]
  → ValidationHistoryListResult (summary projection only)
```

### Type system

**`ValidationHistoryEntry`** (internal, stored):

| Field | Type |
|---|---|
| `captureSeq` | number |
| `createdAt` | string (ISO) |
| `probeId` | string (16-char hex) |
| `snapshot` | `WidgetValidationProbeResult` (full) |
| `executionBlocked` | `true` |

**`ValidationHistoryCaptureResult`** (POST response, 201):

| Field | Type | Notes |
|---|---|---|
| `captureSeq` | number | Monotonic; resumes from max stored on restart |
| `createdAt` | string | ISO timestamp from probe |
| `probeId` | string | 16-char hex, sha256(generatedAt).slice(0,16) |
| `allWidgetsValid` | boolean | `probe.summary.allWidgetsValid` |
| `passedWidgets` | number | `probe.summary.passedWidgets` |
| `failedWidgets` | number | `probe.summary.failedWidgets` |
| `fieldCoveragePercent` | number | `probe.fieldCoverage.coveragePercent` |
| `failedFieldCount` | number | `probe.summary.failedFieldCount` |
| `widgetCoveragePercent` | number | `probe.summary.widgetCoveragePercent` |
| `ringSize` | number | Ring size after insertion (≤10) |
| `executionBlocked` | `true` | literal |

**`ValidationHistoryListItem`** (GET response entry — summary projection):

Same as `ValidationHistoryCaptureResult` minus `ringSize`. Does NOT expose `snapshot` or `fieldResults[]`. Summary-only: `captureSeq, createdAt, probeId, allWidgetsValid, passedWidgets, failedWidgets, fieldCoveragePercent, failedFieldCount, widgetCoveragePercent, executionBlocked`.

**`ValidationHistoryListResult`**:

| Field | Type |
|---|---|
| `entries` | `ValidationHistoryListItem[]` (newest-first) |
| `total` | number (≤10) |
| `maxRetained` | 10 |
| `storeKey` | `"workspace-widget-validation-history"` |
| `executionBlocked` | `true` |

### Persistence semantics

- Store key: `workspace-widget-validation-history`
- Max retained: 10 (ring buffer — oldest entry pruned when exceeded)
- Atomic write: `writeStore<ValidationHistoryEntry[]>(STORE_KEY, historyRing)`
- Load-on-boot: `readStore` → `filter(isValidEntry)` → `slice(-10)`
- Malformed entry skipping: `isValidEntry` guard on captureSeq/createdAt/probeId/snapshot/executionBlocked
- `flush()` wrapped in try/catch — persistence failure never crashes the runtime
- `captureSeq` resumes from `max(persisted seqs) + 1` — monotonic across restarts

### `isValidEntry` guard

```typescript
function isValidEntry(obj: unknown): obj is ValidationHistoryEntry {
  if (obj === null || typeof obj !== "object") return false;
  const e = obj as Record<string, unknown>;
  return (
    typeof e["captureSeq"] === "number" &&
    typeof e["createdAt"] === "string" &&
    typeof e["probeId"] === "string" &&
    e["snapshot"] !== null &&
    typeof e["snapshot"] === "object" &&
    e["executionBlocked"] === true
  );
}
```

### Import graph position

`workspaceWidgetValidationHistory.ts` imports from:
- `workspaceWidgetValidationProbe` (Phase 103 — `runWidgetValidationProbe`, `WidgetValidationProbeResult`)
- `persistentStore` (utilities — `readStore`, `writeStore`)
- `lib/logger` (structured logging)

This places the module as a leaf node one layer above the probe module in the visual-layer sub-graph:

```
workspaceWidgetContracts ──────────────────────────┐
                                                    ↓
workspaceVisualShellComposition ──→ workspaceWidgetValidationProbe ──→ workspaceWidgetValidationHistory
```

No new graph cycles. No cross-imports with the workspace DAG (snapshots, audit reports, observation ledger history).

### Runtime init order

```
initWorkspaceSnapshots()
initWorkspaceAuditReports()
initWorkspaceObservationLedgerHistory()
initWorkspaceWidgetValidationHistory()   ← Phase 104 (after ledger history)
initRuntimeDependencyGraph()
```

### Phase 104 baseline metrics

| Metric | Value |
|---|---|
| New endpoints | 2 (`POST /validate/capture`, `GET /validate/history`) |
| New policies | 2 (102→104) |
| New subsystems | 0 |
| New health checks | 0 |
| Tests passed | 30/30 |
| Ring max | 10 |
| Store key | `workspace-widget-validation-history` |
| captureSeq restart survival | Verified (monotonic across reboot) |
| Ring cap enforcement | Verified (10-entry ceiling) |
| Malformed entry safety | Verified (`isValidEntry` guard) |
| Summary-only list | Verified (no full probe results exposed) |
| Typecheck | Clean |

---

## Phase 103 — Widget Contract Validation Probe

**Completed.** Introduces a live cross-layer validation sweep that fetches the composed widget shell (Phase 101) and validates each of the 37 `ComposedWidget.compactData` payloads against their registered `WidgetContract` schemas (Phase 102). One new endpoint: `GET /api/workspace/visual-shell/widgets/validate` (read, viewer). No persistence, no init function, no subsystem, no health check, no rendering.

### Module design

`workspaceWidgetValidationProbe.ts` calls `getWorkspaceVisualShellComposed()` once, iterates all 37 widgets in `composedPanel` order, resolves their contract via `getWidgetContract(widgetId)`, and runs a structured validation sweep against each field defined in the contract. All validation logic is pure — no external calls after the initial bundle fetch.

```
runWidgetValidationProbe()
  ↓
  composed ← getWorkspaceVisualShellComposed()    [one live call]
  allWidgets ← composedPanels.flatMap(p => p.widgets)   [37, same order as shell]
  ↓
  for each widget:
    contract ← getWidgetContract(widgetId)          [O(1) — CONTRACT_INDEX Map]
    if contract === null  → ValidationFailure(no_contract)
    else:
      topLevel:  validate dataType consistency
                 validate executionBlocked === true
      per-field: for each field in contract.fields:
                   required field present?          → required_field_missing
                   field type matches?              → type_mismatch
                   enumeration value valid?         → enum_violation
    → WidgetValidationResult (contractFound, passed, fieldResults[], topLevelFailures[])
  ↓
  aggregate: WidgetValidationSummary, ValidationCoverage
  ↓
  WidgetValidationProbeResult
```

### Validation rules (ValidationRule union)

| Rule | Applied to | Condition |
|---|---|---|
| `no_contract` | Top-level | `getWidgetContract(widgetId)` returns `null` |
| `data_type_mismatch` | Top-level | `compactData.dataType !== contract.compactDataType` |
| `execution_blocked_missing` | Top-level | `compactData.executionBlocked !== true` |
| `required_field_missing` | Per-field | Field key absent from compactData payload |
| `type_mismatch` | Per-field | Value does not satisfy `WidgetFieldType` check |
| `enum_violation` | Per-field | Non-null string value not in `enumDef.values[]` |

### Field type validation

`validateFieldType(value, fieldType)` is a pure function:

| `WidgetFieldType` | Passes when |
|---|---|
| `"string"` | `typeof value === "string"` |
| `"number"` | `typeof value === "number"` |
| `"boolean"` | `typeof value === "boolean"` |
| `"string\|null"` | `typeof value === "string" \|\| value === null` |
| `"number\|null"` | `typeof value === "number" \|\| value === null` |
| `"string[]"` | `Array.isArray(value) && every element is string` |

### Enumeration validation

Enumeration checks are applied only when: (a) the contract has an enumeration for that field, and (b) the value is a non-null string. Null values on nullable fields skip the enum check — only the type check applies.

### Type hierarchy

**`ValidationFailure`**:

| Field | Type | Notes |
|---|---|---|
| `field` | string | Field name where the failure occurred |
| `rule` | `ValidationRule` | Which rule was violated |
| `expected` | string | Human-readable description of expected value |
| `actual` | string | String representation of the actual value |
| `executionBlocked` | `true` | literal |

**`FieldValidationResult`**:

| Field | Type | Notes |
|---|---|---|
| `fieldName` | string | Contract field name |
| `passed` | boolean | True only if `failures` is empty |
| `failures` | `ValidationFailure[]` | One entry per rule violated on this field |
| `executionBlocked` | `true` | literal |

**`WidgetValidationResult`**:

| Field | Type | Notes |
|---|---|---|
| `widgetId` | string | — |
| `widgetType` | string | From composed shell |
| `sectionId` | string | From contract registry |
| `compactDataType` | string | From contract registry (or `"unknown"` if no_contract) |
| `contractFound` | boolean | False only on no_contract |
| `passed` | boolean | `topLevelFailures.length === 0 && all fieldResults passed` |
| `fieldResults` | `FieldValidationResult[]` | One per field in contract.fields (empty if no_contract) |
| `topLevelFailures` | `ValidationFailure[]` | no_contract / data_type_mismatch / execution_blocked_missing |
| `executionBlocked` | `true` | literal |

**`ValidationCoverage`**:

| Field | Type | Notes |
|---|---|---|
| `totalFields` | number | Sum of `fieldResults.length` across all 37 widgets |
| `passedFields` | number | Fields with `passed === true` |
| `failedFields` | number | Fields with `passed === false` |
| `coveragePercent` | number | `round(passedFields/totalFields×100)`; 0 if totalFields=0 |
| `executionBlocked` | `true` | literal |

**`WidgetValidationSummary`**:

| Field | Type | Notes |
|---|---|---|
| `totalWidgetsValidated` | number | 37 (stable — all widgets from composedPanels) |
| `passedWidgets` | number | Widgets with `passed === true` |
| `failedWidgets` | number | `totalWidgetsValidated - passedWidgets` |
| `allWidgetsValid` | boolean | `failedWidgets === 0` |
| `widgetCoveragePercent` | number | `round(passedWidgets/total×100)` |
| `fieldValidationCount` | number | Same as `fieldCoverage.totalFields` (220 in current schema) |
| `failedFieldCount` | number | Same as `fieldCoverage.failedFields` |
| `contractsMissing` | number | Count of widgets where `contractFound === false` |
| `executionBlocked` | `true` | literal |

**`WidgetValidationProbeResult`**:

| Field | Type | Notes |
|---|---|---|
| `probeId` | string | `sha256(generatedAt).slice(0,16)` — unique per call |
| `generatedAt` | string | ISO timestamp |
| `summary` | `WidgetValidationSummary` | Aggregate across all 37 widgets |
| `results` | `WidgetValidationResult[]` | 37 entries, same order as `composedPanels.flatMap(p → p.widgets)` |
| `fieldCoverage` | `ValidationCoverage` | Field-level pass/fail aggregate |
| `executionBlocked` | `true` | literal |

### Route registration order (critical)

`/api/workspace/visual-shell/widgets/validate` is registered in `server.ts` BEFORE `/api/workspace/visual-shell/widgets/:widgetId`. The router uses first-match-wins (registration order). Without this ordering, `validate` would be captured by the `:widgetId` handler and return a 404 (no contract named "validate").

Registration order in `server.ts`:
```
router.get("/api/workspace/visual-shell/widgets",            handleWidgetContractList)
router.get("/api/workspace/visual-shell/widgets/validate",   handleWidgetValidationProbe)  ← BEFORE /:widgetId
router.get("/api/workspace/visual-shell/widgets/:widgetId",  handleWidgetContractById)
```

### Import graph position

`workspaceWidgetValidationProbe.ts` imports from:
- `workspaceWidgetContracts` (Phase 102 — `getWidgetContract`, `WidgetField`, `WidgetEnumeration`, `WidgetFieldType`)
- `workspaceVisualShellComposition` (Phase 101 — `getWorkspaceVisualShellComposed`)
- `node:crypto` (for `probeId` generation)

This places the probe module at the widest leaf position in the visual-layer sub-graph — it is the only module that imports from both Phase 101 (composition) and Phase 102 (contracts). No new graph cycles are introduced since both upstream modules are already in the graph.

### Baseline probe metrics (current live run)

| Metric | Value |
|---|---|
| Total widgets validated | 37 |
| Contracts found | 37 / 37 |
| Passed widgets | 37 (100%) |
| Failed widgets | 0 |
| Total field validations | 220 |
| Passed field validations | 220 (100%) |
| Failed field validations | 0 |
| Widget coverage percent | 100% |
| Field coverage percent | 100% |

220 total field validations = 37 widgets × average 5.94 fields/widget (range: 2 fields for `audit` to 7 fields for `ledger`; `executionBlocked` is always included as a declared contract field).

### Stability invariants

- `probeId` is unique per call (sha256 of `generatedAt`).
- Widget result order is guaranteed to match `composedPanels.flatMap(p → p.widgets)` — the same deterministic order as the composed shell.
- A widget with no contract (`contractFound: false`) produces `fieldResults: []` and `topLevelFailures: [ValidationFailure(no_contract)]`. Currently this cannot occur since all 37 widgets have contracts, but the path is safe.
- `fieldCoverage.passedFields + fieldCoverage.failedFields === fieldCoverage.totalFields` is always true.
- `summary.widgetCoveragePercent = round(passedWidgets / totalWidgetsValidated × 100)`. Never throws on division by zero — guarded by `totalWidgetsValidated === 0 ? 0 : ...`.
- No mutation of any kind: `getWidgetContract()` reads from a static `Map`, `getWorkspaceVisualShellComposed()` is read-only, and the probe accumulates into local arrays only.

---

## Phase 102 — Widget Data Contracts Registry

**Completed.** Introduces a governed, deterministic schema contract registry for all 37 Workspace Visual Shell widgets. Two new endpoints: `GET /api/workspace/visual-shell/widgets` (list all contracts) and `GET /api/workspace/visual-shell/widgets/:widgetId` (single contract by ID). No persistence, no init function, no subsystem, no health check, no live data calls. The module is a pure static leaf with zero imports from live data sources.

### Module design

`workspaceWidgetContracts.ts` declares all 37 contracts at module scope as a compile-time constant. The contracts are completely static — they describe the *schema* of the compact data payloads introduced in Phase 101, not the live values. A `CONTRACT_INDEX: Map<string, WidgetContract>` is pre-built at module load for O(1) widgetId lookup.

```
listWidgetContracts()
  → CONTRACT_REGISTRY.map → WidgetContractSummaryItem[]
  → REGISTRY_SUMMARY (pre-computed once at module load)
  → WidgetContractListResult

getWidgetContract(widgetId)
  → CONTRACT_INDEX.get(widgetId) → WidgetContract | null
  → null  →  404
  → found →  200 WidgetContract
```

### Type hierarchy

**`WidgetFieldType`** — union of valid field type strings:

| Value | Meaning |
|---|---|
| `"string"` | Non-null string |
| `"number"` | Non-null number |
| `"boolean"` | Non-null boolean |
| `"string\|null"` | Nullable string |
| `"number\|null"` | Nullable number |
| `"string[]"` | Non-null string array |

**`WidgetField`**:

| Field | Type | Notes |
|---|---|---|
| `fieldName` | string | Exact key name in the compact payload |
| `fieldType` | `WidgetFieldType` | Type of the field value |
| `description` | string | Human-readable contract description |
| `nullable` | boolean | True only for fields typed `string\|null` or `number\|null` |
| `executionBlocked` | `true` | literal |

**`WidgetEnumeration`**:

| Field | Type | Notes |
|---|---|---|
| `field` | string | Field name this enumeration applies to |
| `values` | `string[]` | All valid string values; stable ordered |
| `executionBlocked` | `true` | literal |

**`WidgetContract`** (full detail endpoint):

| Field | Type | Notes |
|---|---|---|
| `widgetId` | string | Stable widget identifier |
| `widgetType` | string | One of 10 widget type variants |
| `title` | string | Display title |
| `sectionId` | string | One of 5 section identifiers |
| `sourceEndpoint` | string | API path that provides full data |
| `recommendedSize` | string | small / medium / large / full |
| `refreshCategory` | string | realtime / periodic / on-demand / static |
| `compactDataType` | string | Which compact payload type this widget uses |
| `schemaVersion` | string | Always `"1"` |
| `fields` | `WidgetField[]` | Ordered field definitions for the compact payload |
| `requiredFields` | `string[]` | Non-nullable field names (excludes `executionBlocked`) |
| `enumerations` | `WidgetEnumeration[]` | Bounded value sets for string fields |
| `examplePayload` | `Record<string, unknown>` | Static example of compact payload (always includes `executionBlocked: true`) |
| `executionBlocked` | `true` | literal |

**`WidgetContractSummaryItem`** (list projection):

| Field | Type | Notes |
|---|---|---|
| `widgetId` | string | — |
| `widgetType` | string | — |
| `title` | string | — |
| `sectionId` | string | — |
| `sourceEndpoint` | string | — |
| `compactDataType` | string | — |
| `schemaVersion` | string | `"1"` |
| `fieldCount` | number | `fields.length` |
| `requiredFieldCount` | number | `requiredFields.length` |
| `executionBlocked` | `true` | literal |

**`WidgetContractSummary`**:

| Field | Type | Notes |
|---|---|---|
| `totalContracts` | number | 37 (stable) |
| `contractsByCompactDataType` | `Record<string, number>` | Count per compact data type |
| `contractsByWidgetType` | `Record<string, number>` | Count per widget type variant |
| `contractsBySectionId` | `Record<string, number>` | Count per section |
| `schemaVersion` | string | `"1"` |
| `executionBlocked` | `true` | literal |

**`WidgetContractListResult`**:

| Field | Type | Notes |
|---|---|---|
| `contracts` | `WidgetContractSummaryItem[]` | 37 items, deterministic order |
| `total` | number | 37 |
| `summary` | `WidgetContractSummary` | Pre-computed at module load |
| `executionBlocked` | `true` | literal |

### Compact data type → field coverage

| `compactDataType` | Key fields | Enumerations | Nullable fields |
|---|---|---|---|
| `governance` | governanceScore, governanceGrade, dimensionCount, recommendationCount | governanceGrade: A/B/C/D/F | — |
| `observation_coverage` | coveragePercent, observedPolicies, unobservedPolicies, totalPolicies | — | — |
| `exposure` | exposureScore, exposureGrade, totalWritePolicies, unobserved/rarely/wellObservedWritePolicies | exposureGrade: A/B/C/D/F | — |
| `probe` | allProbesPassed, passedProbeCount, failedProbeCount, totalProbes, totalProbeTimeMs | — | — |
| `heatmap` | coldCount, warmCount, hotCount, coveragePercent | — | — |
| `trend` | trendDirection, coverageDelta, currentCoveragePercent, comparedSnapshotCount | trendDirection: improving/stable/degrading/null | trendDirection, coverageDelta |
| `ledger` | overallObservationHealth, governanceReadiness, observationCoverage, exposureRiskLevel, probeHealth | overallObservationHealth: healthy/degraded/critical; governanceReadiness: A–F; exposureRiskLevel: none/low/medium/high; probeHealth: all_passed/partial/none_passed | — |
| `health` | status, totalChecks, passingChecks, failingChecks | status: healthy/degraded/unhealthy | — |
| `metrics` | totalRequests, totalErrors, memoryUsedMb | — | — |
| `freeze` | status, freezeCount, lastLagMs | status: normal/warning/frozen | — |
| `crash` | status, crashCount, warningCount | status: stable/warning/crashed | — |
| `projects` | total, active, archived, suspended, utilizationPercent | — | — |
| `members` | totalMemberRecords, projectsWithCustomQuotas, projectsUsingDefaults | — | — |
| `audit` | retainedReportCount | — | — |
| `static_reference` | sourceEndpoint, note | — | — |

### Registry distribution (by section)

| Section | Widgets | Compact types used |
|---|---|---|
| `governance` | 9 | governance (4), observation_coverage (2), exposure (3) |
| `observation` | 12 | heatmap (3), trend (3), probe (3), ledger (3) |
| `diagnostics` | 7 | health (2), metrics (3), freeze (1), crash (1) |
| `projects` | 5 | projects (3), members (2) |
| `activity` | 4 | static_reference (2), audit (2) |

### Import graph position

`workspaceWidgetContracts.ts` imports nothing from any other workspace module — it is a true static leaf. It does not import `workspaceVisualShell.ts` or `workspaceVisualShellComposition.ts`, which means widget metadata (types, sections, sources, sizes, refresh categories) is duplicated by declaration rather than derived at runtime. This is intentional: keeping the contract layer independent of the live shell ensures that the contract registry cannot crash due to upstream errors, and its ordering remains stable regardless of shell rearrangements.

### Stability invariants

- `CONTRACT_REGISTRY` order is fixed at compile time; `listWidgetContracts()` always returns the same 37 IDs in the same order (T23 verifies stability across calls).
- `CONTRACT_INDEX` is a `Map` pre-built at module load; `getWidgetContract()` never throws.
- `REGISTRY_SUMMARY` is pre-computed once at module load; it does not recompute per request.
- All 37 `WidgetContract` objects carry `executionBlocked: true` at the root level.
- All `WidgetField` objects carry `executionBlocked: true`.
- All `WidgetEnumeration` objects carry `executionBlocked: true`.
- All `examplePayload` objects contain `executionBlocked: true`.
- `requiredFields[]` excludes `executionBlocked` and all nullable fields — only non-nullable domain fields appear.
- Unknown `widgetId` → 404 with a message citing `GET /api/workspace/visual-shell/widgets`.
- `schemaVersion` is the string `"1"` throughout — bump required if field shape changes.

---

## Phase 101 — Workspace Visual Shell Composition

**Completed.** Introduces a live composition layer that merges the static visual shell metadata from Phase 100 with bounded compact data payloads derived from live governance and observation signals. One new endpoint: `GET /api/workspace/visual-shell/composed` (read, viewer). No persistence, no init function, no subsystem, no health check. No rendering, no HTML, no CSS, no JS runtime.

### Module design

`workspaceVisualShellComposition.ts` fetches the static shell from `getWorkspaceVisualShell()` and a live data bundle from 8 source functions (called once per request), then maps every `VisualWidget` to a `ComposedWidget` by looking up its `widgetId` in a `WIDGET_EXTRACTORS` record. Each extractor is a pure function `(LiveBundle) → CompactDataPayload`.

```
getWorkspaceVisualShellComposed()
  ↓
  shell   ← getWorkspaceVisualShell()   [static shell, Phase 100]
  bundle  ← fetchLiveBundle()           [8 live sources, once per call]
  ↓
  composedPanels[15] ← shell.panels.map(panel →
    panel.widgets.map(widget →
      WIDGET_EXTRACTORS[widget.widgetId](bundle)
      → ComposedWidget { ...widget, compactData }
    )
  )
  ↓
  compositionSummary ← buildCompositionSummary(composedPanels, bundle)
  ↓
  WorkspaceVisualShellComposed
```

### Live bundle sources

`fetchLiveBundle()` calls all sources at the top of the request, before any extraction:

| Source function | Provides compact data for |
|---|---|
| `getWorkspaceObservationLedger()` | governance, observation_coverage, exposure, probe, heatmap, trend, ledger widgets |
| `getWorkspaceGovernanceScorecard()` | dimension count, recommendation count in governance widgets |
| `getWorkspaceSummary()` | projects, members widgets |
| `getFullHealth()` | health widgets |
| `getMetrics()` | metrics widgets |
| `getFreezeStatus()` | freeze widget |
| `getCrashStatus()` | crash widget |
| `listAuditReports({ limit: 10 })` | audit widgets |

`getWorkspaceObservationLedger()` internally calls all 5 observation modules. The bundle call therefore performs a deep live read of the entire governance layer in one pass, and all 37 widget extractors draw from this single fetch result.

### Type hierarchy

**`CompactDataPayload`** — discriminated union of 15 compact types:

| `dataType` | Fields (all + `executionBlocked: true`) | Sourced from |
|---|---|---|
| `governance` | `governanceScore`, `governanceGrade`, `dimensionCount`, `recommendationCount` | ledger.governance + scorecard |
| `observation_coverage` | `coveragePercent`, `observedPolicies`, `unobservedPolicies`, `totalPolicies` | ledger.compliance |
| `exposure` | `exposureScore`, `exposureGrade`, `totalWritePolicies`, `unobservedWritePolicies`, `rarelyObservedWritePolicies`, `wellObservedWritePolicies` | ledger.exposure |
| `probe` | `allProbesPassed`, `passedProbeCount`, `failedProbeCount`, `totalProbes`, `totalProbeTimeMs` | ledger.probe |
| `heatmap` | `coldCount`, `warmCount`, `hotCount`, `coveragePercent` | ledger.heatmap |
| `trend` | `trendDirection`, `coverageDelta`, `currentCoveragePercent`, `comparedSnapshotCount` | ledger.trend |
| `ledger` | `overallObservationHealth`, `governanceReadiness`, `observationCoverage`, `exposureRiskLevel`, `probeHealth` | ledger.summary |
| `health` | `status`, `totalChecks`, `passingChecks`, `failingChecks` | health |
| `metrics` | `totalRequests`, `totalErrors`, `memoryUsedMb` | metrics |
| `freeze` | `status`, `freezeCount`, `lastLagMs` | freeze |
| `crash` | `status`, `crashCount`, `warningCount` | crash |
| `projects` | `total`, `active`, `archived`, `suspended`, `utilizationPercent` | summary.projects + summary.capacity |
| `members` | `totalMemberRecords`, `projectsWithCustomQuotas`, `projectsUsingDefaults` | summary.members + summary.quotas |
| `audit` | `retainedReportCount` | listAuditReports |
| `static_reference` | `sourceEndpoint`, `note` | (no live data available) |

**`ComposedWidget`**:

| Field | Type | Notes |
|---|---|---|
| `widgetId` | string | Preserved from shell |
| `widgetType` | `WidgetType` | Preserved from shell |
| `title` | string | Preserved from shell |
| `sourceEndpoint` | string | Preserved from shell |
| `recommendedSize` | `WidgetSize` | Preserved from shell |
| `refreshCategory` | `RefreshCategory` | Preserved from shell |
| `compactData` | `CompactDataPayload` | Live data payload (15 discriminated types) |
| `executionBlocked` | `true` | literal |

**`ComposedPanel`** — mirrors `VisualPanel` but with `widgets: ComposedWidget[]`.

**`CompositionSummary`**:

| Field | Type | Notes |
|---|---|---|
| `totalComposedWidgets` | number | 37 (stable) |
| `widgetsWithLiveData` | number | 35 (all except timeline-feed, diff-pairs-table) |
| `widgetsWithStaticReference` | number | 2 |
| `compactDataTypes` | `string[]` | Sorted unique list of `dataType` values in use |
| `governanceScore` | number | From ledger.governance |
| `governanceGrade` | string | From ledger.governance |
| `observationHealth` | string | From ledger.summary |
| `observationCoverage` | number | From ledger.summary |
| `executionBlocked` | `true` | literal |

**`WorkspaceVisualShellComposed`**:

| Field | Type | Notes |
|---|---|---|
| `composedId` | string | `sha256(generatedAt).slice(0,16)` — unique per call |
| `generatedAt` | string | ISO timestamp |
| `shellId` | string | From the static shell (also unique per call) |
| `sections` | `VisualSection[]` | 5 — identical to shell |
| `composedPanels` | `ComposedPanel[]` | 15 — widgets augmented with compactData |
| `navigationGroups` | `DashboardNavigationGroup[]` | 5 — identical to shell |
| `layout` | `WidgetLayout` | Identical to shell |
| `compositionSummary` | `CompositionSummary` | Live governance summary |
| `executionBlocked` | `true` | literal |

### Widget extractor map

`WIDGET_EXTRACTORS: Record<string, CompactExtractor>` is declared at module scope. It maps all 37 widget IDs to their compact extractor functions. Widgets not in the map fall back to `static_reference`. Currently 35 widgets are registered (2 intentionally use `static_reference`):

- `timeline-feed` → `static_reference` (full timeline data too large for compactData; fetch from sourceEndpoint)
- `diff-pairs-table` → `static_reference` (diff pairs require full snapshot pairs; fetch from sourceEndpoint)

### Import graph position

`workspaceVisualShellComposition.ts` imports from:
- `workspaceVisualShell` (Phase 100 — static shell)
- `workspaceObservationLedger` (Phase 97 — unified ledger)
- `workspaceGovernanceScorecard` (Phase 91)
- `workspaceShell` (Phase 83)
- `healthMonitor` (infrastructure)
- `metrics` (infrastructure)
- `freezeDetector` (infrastructure)
- `crashDetector` (infrastructure)
- `workspaceAuditReport` (Phase 88)

This is the widest import fan-in in the visual layer, but all imports are read-only and already present in the graph. No new graph nodes or cycles are introduced.

### Stability invariants

- `composedId` and `shellId` are both unique per call (different sha256 seeds — `composedId` from `generatedAt` at composition time, `shellId` from `getWorkspaceVisualShell()` which stamps its own `generatedAt`).
- All 37 widget IDs in `composedPanels` match exactly the 37 IDs in the static shell — verified by test T20.
- All `compactData` objects have `executionBlocked: true` — verified by test T05 (all 37 widgets).
- `compositionSummary.widgetsWithLiveData + compositionSummary.widgetsWithStaticReference === 37` always holds — verified by test T07.
- `compactDataTypes[]` is sorted alphabetically and contains only valid `dataType` strings.
- No full endpoint payloads are embedded — each compact type contains only summary-level fields (bounded 3–8 fields).
- `fetchLiveBundle()` is called once per request. All 37 extractor functions share the same bundle reference.

---

## Phase 100 — Workspace Visual Shell Foundation

**Completed.** Introduces the first governed visual/UI-facing layer: a pure static read-only metadata module that exposes dashboard-ready layout contracts for future frontend rendering. One new endpoint: `GET /api/workspace/visual-shell` (read, viewer). No persistence, no init function, no subsystem, no health check. No rendering, no HTML, no CSS, no JS runtime.

### Module design

`workspaceVisualShell.ts` builds a static tree of metadata objects at module scope. All panel and widget definitions are declared as module-level constants; `getWorkspaceVisualShell()` assembles them into the response, computes the `WidgetLayout` summary, derives `VisualSection` summaries by scanning the panel list, and stamps a unique `shellId` and `generatedAt` per call.

```
Module-level constants (stable, deterministic):
  PANELS_GOVERNANCE[]   3 panels  9 widgets
  PANELS_OBSERVATION[]  4 panels  12 widgets
  PANELS_DIAGNOSTICS[]  3 panels  7 widgets
  PANELS_PROJECTS[]     2 panels  5 widgets
  PANELS_ACTIVITY[]     3 panels  4 widgets
  ALL_PANELS            15 panels 37 widgets total
  NAVIGATION_GROUPS[]   5 groups  20 nav items total

getWorkspaceVisualShell()
  → shellId = sha256(generatedAt).slice(0,16)
  → sections[5]  ← derived from ALL_PANELS by sectionId
  → panels[15]   ← ALL_PANELS (static)
  → navigationGroups[5] ← NAVIGATION_GROUPS (static)
  → layout       ← computeLayout(ALL_PANELS)
```

### Type hierarchy

**`VisualWidget`** — atomic dashboard component contract:

| Field | Type | Values |
|---|---|---|
| `widgetId` | string | Stable kebab-case identifier (unique across all 37 widgets) |
| `widgetType` | `WidgetType` | `metric\|status\|table\|timeline\|gauge\|list\|heatmap\|scorecard\|badge\|chart` |
| `title` | string | Human-readable label |
| `sourceEndpoint` | string | API path — always starts with `/api/` |
| `recommendedSize` | `WidgetSize` | `small\|medium\|large\|full` |
| `refreshCategory` | `RefreshCategory` | `realtime\|periodic\|on-demand\|static` |
| `executionBlocked` | `true` | literal |

**`VisualPanel`** — logical grouping of widgets within a section:

| Field | Type | Notes |
|---|---|---|
| `panelId` | string | Stable kebab-case identifier (unique across all 15 panels) |
| `title` | string | Panel display name |
| `description` | string | Panel purpose summary |
| `sectionId` | `SectionId` | One of 5 section identifiers |
| `panelOrder` | number | 1-based ordering within the section |
| `widgets` | `VisualWidget[]` | Widgets belonging to this panel |
| `executionBlocked` | `true` | literal |

**`VisualSection`** — high-level grouping (derived, not persisted):

| Field | Type | Notes |
|---|---|---|
| `sectionId` | `SectionId` | `governance\|observation\|diagnostics\|projects\|activity` |
| `title` | string | Section display name |
| `description` | string | Section purpose summary |
| `sectionOrder` | number | 1–5, deterministic |
| `panelCount` | number | Count of panels with this sectionId |
| `widgetCount` | number | Sum of all widgets across panels in this section |
| `executionBlocked` | `true` | literal |

**`WidgetLayout`** — aggregate summary:

| Field | Type | Notes |
|---|---|---|
| `totalWidgets` | number | 37 (stable) |
| `totalPanels` | number | 15 (stable) |
| `totalSections` | number | 5 (stable) |
| `widgetsByType` | `Record<WidgetType, number>` | Count per widget type |
| `widgetsBySize` | `Record<WidgetSize, number>` | Count per recommended size |
| `widgetsByRefreshCategory` | `Record<RefreshCategory, number>` | Count per refresh category |
| `executionBlocked` | `true` | literal |

**`DashboardNavigationGroup`** — navigation menu structure:

| Field | Type | Notes |
|---|---|---|
| `groupId` | `NavigationGroupId` | `overview\|governance\|observation\|audit\|diagnostics` |
| `title` | string | Group display name |
| `groupOrder` | number | 1–5 |
| `items` | `DashboardNavigationItem[]` | Ordered navigation items |
| `executionBlocked` | `true` | literal |

**`DashboardNavigationItem`**:

| Field | Type | Notes |
|---|---|---|
| `itemId` | string | Stable kebab-case identifier |
| `title` | string | Item display label |
| `endpoint` | string | API path for the linked resource |
| `itemOrder` | number | 1-based ordering within the group |
| `executionBlocked` | `true` | literal |

**`WorkspaceVisualShell`** — root response:

| Field | Type | Notes |
|---|---|---|
| `shellId` | string | `sha256(generatedAt).slice(0,16)` — unique per call |
| `generatedAt` | string | ISO timestamp |
| `sections` | `VisualSection[]` | 5 sections, sectionOrder 1–5 |
| `panels` | `VisualPanel[]` | 15 panels, all sections |
| `navigationGroups` | `DashboardNavigationGroup[]` | 5 groups, groupOrder 1–5 |
| `layout` | `WidgetLayout` | Aggregate counts |
| `executionBlocked` | `true` | literal |

### Section and panel inventory

| Section | sectionOrder | Panels | Widgets | Panel names |
|---|---|---|---|---|
| governance | 1 | 3 | 9 | Governance Overview, Policy Compliance Ledger, Policy Exposure Risk |
| observation | 2 | 4 | 12 | Observation Heatmap, Coverage Trend, Observation Probe, Ledger Analytics |
| diagnostics | 3 | 3 | 7 | System Health, Runtime Metrics, Freeze & Crash Detection |
| projects | 4 | 2 | 5 | Project Registry, Workspace Membership |
| activity | 5 | 3 | 4 | Workspace Timeline, Change Detection, Audit Trail |

### Widget distribution

| Metric | Value |
|---|---|
| Total widgets | 37 |
| metric | 10 |
| badge | 7 |
| table | 7 |
| gauge | 5 |
| list | 2 |
| scorecard | 2 |
| chart | 2 |
| timeline | 1 |
| heatmap | 1 |
| status | 0 |
| small | 21 |
| medium | 8 |
| large | 6 |
| full | 2 |
| on-demand | 18 |
| periodic | 12 |
| realtime | 7 |
| static | 0 |

### Navigation groups

| Group | groupOrder | Items |
|---|---|---|
| overview | 1 | Workspace Summary, Workspace Health, Navigation Panels |
| governance | 2 | Governance Scorecard, Policy Compliance, Exposure Risk Index |
| observation | 3 | Policy Heatmap, Coverage Trend, Observation Probe, Observation Ledger, Ledger History, Ledger Analytics |
| audit | 4 | Audit Reports, Audit Digest, Workspace Snapshots |
| diagnostics | 5 | Health Checks, Runtime Metrics, Freeze Detector, Crash Detector, Diagnostics Snapshot |

### computeLayout()

`computeLayout(panels: VisualPanel[])` iterates all widgets across all panels and tallies `byType`, `bySize`, and `byRefresh` maps. All three maps sum to `totalWidgets`. The function has no I/O and no side effects — it is called once per `getWorkspaceVisualShell()` invocation.

### Stability invariants

- All panel IDs are unique across the full 15-panel set.
- All widget IDs are unique across the full 37-widget set.
- All source endpoints start with `/api/`.
- Section ordering (`sectionOrder` 1–5) is deterministic and matches `SECTION_DEFS` array order.
- Panel ordering (`panelOrder`) is 1-based within each section, assigned in `PANELS_*` constant order.
- Navigation group ordering (`groupOrder` 1–5) is deterministic and matches `NAVIGATION_GROUPS` array order.
- Navigation item ordering (`itemOrder`) is 1-based within each group.
- `layout.widgetsByType` covers all 10 `WidgetType` keys (including `status: 0`).
- `layout.widgetsByRefreshCategory` covers all 4 `RefreshCategory` keys (including `static: 0`).
- No HTML, CSS, JS, or rendering instructions appear anywhere in the response.
- `executionBlocked: true` in every nested type at every depth.

### Import graph position

`workspaceVisualShell.ts` imports only `node:crypto` (for `sha256`). It has no imports from any workspace core module. This makes it a true leaf node with zero runtime coupling to the rest of the system. Adding new widgets or panels requires no changes to any other module.

---

## Phase 99 — Workspace Observation Ledger Analytics

**Completed.** Introduces a pure read-only analytics layer that derives compact historical governance insights from the persisted Observation Ledger History ring buffer. One new endpoint: `GET /api/workspace/observation/ledger/analytics` (read, viewer). No persistence, no init function, no subsystem, no health check. Pure derivation from the in-memory history ring via `getRawHistoryEntries()`.

### Module design

`workspaceObservationLedgerAnalytics.ts` reads the in-memory ring and computes all analytics at request time:

```
getRawHistoryEntries()  ──►  oldestFirst[] (sorted ASC by captureSeq)
                                │
                         ┌──────┴──────────────────────────────────┐
                         │                                          │
                    summary derivations               transition counting
                    ─────────────────                 ──────────────────
                    averageObservationCoverage         governanceGradeChanges
                    bestGovernanceGrade                exposureRiskChanges
                    worstExposureRiskLevel             healthStateChanges
                    observationTrendDirection          improvingCoverageCount
                    averageProbeTimeMs                 degradingCoverageCount
                    latestCaptureSeq
                         │
                    series[] (newestFirst, max 20)
                    ──────────────────────────────
                    AnalyticsHistoryPoint per entry
```

All computation is pure — no I/O, no mutation, no side effects. The analytics endpoint is idempotent: calling it N times with the same ring state produces N identical results (modulo `analyticsId`/`generatedAt` which are generated per-call from `new Date()`).

### New export in `workspaceObservationLedgerHistory.ts`

```typescript
export function getRawHistoryEntries(): LedgerHistoryEntry[] {
  return [...historyRing];  // copy — caller cannot mutate the ring
}
```

A shallow copy of the ring is returned to prevent the analytics module from accidentally mutating the in-memory ring. This is the only export path that exposes full snapshot data outside the history module.

### Type hierarchy

**`AnalyticsSummary`**:

| Field | Type | Derivation |
|---|---|---|
| `totalSnapshotsAnalyzed` | number | `entries.length` |
| `averageObservationCoverage` | number | `round1(mean(coverages))` — 1-decimal precision |
| `bestGovernanceGrade` | `GovernanceGrade \| null` | Lowest-letter grade seen (A beats B beats C …); null if no entries |
| `worstExposureRiskLevel` | `ExposureRiskLevel \| null` | Highest-risk level seen (high > medium > low > none); null if no entries |
| `observationTrendDirection` | `AnalyticsTrendDirection` | Compare oldest vs newest coverage: improving/stable/degrading; null if < 2 entries |
| `averageProbeTimeMs` | `number \| null` | `round1(mean(probe.totalProbeTimeMs))`; null if no entries |
| `latestCaptureSeq` | `number \| null` | `max(captureSeq values)`; null if no entries |
| `executionBlocked` | `true` | literal |

**`AnalyticsTransitions`** — computed from consecutive oldest-first pairs `(i-1, i)`:

| Field | Type | Increment condition |
|---|---|---|
| `governanceGradeChanges` | number | `curr.governanceReadiness !== prev.governanceReadiness` |
| `exposureRiskChanges` | number | `curr.exposureRiskLevel !== prev.exposureRiskLevel` |
| `healthStateChanges` | number | `curr.overallObservationHealth !== prev.overallObservationHealth` |
| `improvingCoverageCount` | number | `curr.observationCoverage > prev.observationCoverage` |
| `degradingCoverageCount` | number | `curr.observationCoverage < prev.observationCoverage` |
| `executionBlocked` | `true` | literal |

For a ring of N entries, there are N−1 consecutive pairs. All counts are ≥ 0. `improvingCoverageCount + degradingCoverageCount ≤ N−1` (equal when no stable-coverage pairs exist).

**`AnalyticsHistoryPoint`** — one per ring entry, newest-first:

| Field | Type | Source |
|---|---|---|
| `captureSeq` | number | `entry.captureSeq` |
| `createdAt` | string | `entry.createdAt` |
| `observationCoverage` | number | `entry.snapshot.summary.observationCoverage` |
| `governanceReadiness` | `GovernanceGrade` | `entry.snapshot.summary.governanceReadiness` |
| `exposureRiskLevel` | `ExposureRiskLevel` | `entry.snapshot.summary.exposureRiskLevel` |
| `overallObservationHealth` | `ObservationHealth` | `entry.snapshot.summary.overallObservationHealth` |
| `probeTimeMs` | number | `entry.snapshot.probe.totalProbeTimeMs` |
| `executionBlocked` | `true` | literal |

**`WorkspaceObservationLedgerAnalytics`** — root response:

| Field | Type | Notes |
|---|---|---|
| `analyticsId` | string | `sha256(generatedAt).slice(0,16)` — unique per call |
| `generatedAt` | string | ISO timestamp |
| `summary` | `AnalyticsSummary` | — |
| `transitions` | `AnalyticsTransitions` | — |
| `series` | `AnalyticsHistoryPoint[]` | Newest-first, max 20 (bounded by ring) |
| `snapshotsInRing` | number | `entries.length` — equals `series.length` |
| `executionBlocked` | `true` | literal |

### Grade and risk ordering

```typescript
const GRADE_ORDER: GovernanceGrade[] = ["A", "B", "C", "D", "F"];
// "best" = lowest index → A is best, F is worst

const RISK_ORDER: ExposureRiskLevel[] = ["none", "low", "medium", "high"];
// "worst" = highest index → high is worst, none is safest
```

`deriveBestGrade()` uses `Array.reduce` over all grades picking the one with the lowest `GRADE_ORDER` index. `deriveWorstRisk()` picks the one with the highest `RISK_ORDER` index.

### Trend direction derivation

```
if (ring < 2 entries)  → null
elif newestCoverage > oldestCoverage  → "improving"
elif newestCoverage < oldestCoverage  → "degrading"
else                                  → "stable"
```

"Oldest" = entry with lowest `captureSeq`; "newest" = entry with highest `captureSeq`. The comparison uses only the two endpoints — it does not attempt to classify the curve shape. This gives a stable, deterministic result regardless of intermediate fluctuations.

### Rounding convention

All numeric averages are rounded to 1 decimal place via `round1(n) = Math.round(n * 10) / 10`. This applies to both `averageObservationCoverage` and `averageProbeTimeMs`. Integer inputs are preserved exactly (e.g., `round1(45) === 45`).

### Import hierarchy

```
workspaceObservationLedgerHistory  (exports getRawHistoryEntries)
         │
workspaceObservationLedgerAnalytics  (leaf — imports from history only)
```

The analytics module does not import `workspaceObservationLedger` or any of the 5 inner observation modules. It reads only the already-computed snapshots stored in the history ring. This avoids triggering a full probe run on every analytics request.

### Empty ring behaviour

When `getRawHistoryEntries()` returns an empty array:
- `totalSnapshotsAnalyzed = 0`
- `averageObservationCoverage = 0`
- `bestGovernanceGrade = null`
- `worstExposureRiskLevel = null`
- `observationTrendDirection = null`
- `averageProbeTimeMs = null`
- `latestCaptureSeq = null`
- `series = []`
- `snapshotsInRing = 0`
- All transition counts = 0

No errors are thrown for an empty ring — this is the expected initial state before any captures.

### Invariants

- `snapshotsInRing === series.length` always.
- `series` is always newest-first (descending captureSeq).
- `series.length ≤ 20` (bounded by the history ring max).
- All transition counts are non-negative integers.
- `improvingCoverageCount + degradingCoverageCount ≤ max(0, snapshotsInRing − 1)`.
- `executionBlocked: true` in root, `summary`, `transitions`, and every `AnalyticsHistoryPoint`.
- No persistence write of any kind — the analytics endpoint is unconditionally read-only.
- `analyticsId` is unique per call (derived from `new Date().toISOString()` which has ms precision).

---

## Phase 98 — Workspace Observation Ledger History

**Completed.** Introduces persistent Observation Ledger History with governed snapshot capture and historical replay. Two new endpoints: `POST /api/workspace/observation/ledger/capture` (write, operator) and `GET /api/workspace/observation/ledger/history` (read, viewer). Backed by an append-only ring buffer (max 20) persisted atomically to `workspace-observation-ledger-history` store key with load-on-boot and captureSeq resume.

### Module design

`workspaceObservationLedgerHistory.ts` wraps `getWorkspaceObservationLedger()` in a capture + persist lifecycle:

```
getWorkspaceObservationLedger()  ──►  LedgerHistoryEntry {
                                        captureSeq     ← auto-increment
                                        createdAt      ← ledger.generatedAt
                                        ledgerId       ← ledger.ledgerId
                                        snapshot       ← full ledger
                                        executionBlocked: true
                                      }
                                         │
                                   historyRing[] (max 20, oldest pruned)
                                         │
                                   writeStore(STORE_KEY)  ← atomic flush
```

The `initWorkspaceObservationLedgerHistory()` function:
- Idempotent (guarded by `isInitialized`)
- Reads `readStore<unknown[]>(STORE_KEY)` on boot
- Validates each entry via `isValidEntry()` — skips malformed silently, logs a warn
- Resumes `nextCaptureSeq` from `max(persisted captureSeq) + 1` — prevents post-restart collisions
- Called from `runtime.ts` after `initWorkspaceAuditReports()`

### Type hierarchy

**`LedgerHistoryEntry`** — full stored record:

| Field | Type | Notes |
|---|---|---|
| `captureSeq` | number | Auto-increment starting at 1; resumed from max on boot |
| `createdAt` | string | ISO — taken from `snapshot.generatedAt` |
| `ledgerId` | string | 16-char hex from `snapshot.ledgerId` |
| `snapshot` | `WorkspaceObservationLedger` | Full ledger at capture time |
| `executionBlocked` | `true` | literal |

**`LedgerHistoryCaptureResult`** — returned from `POST /capture` (201):

| Field | Type | Notes |
|---|---|---|
| `captureSeq` | number | The seq assigned to this capture |
| `createdAt` | string | ISO |
| `ledgerId` | string | 16-char hex |
| `ringSize` | number | Current ring length after this capture (≤ 20) |
| `executionBlocked` | `true` | literal |

**`LedgerHistoryListItem`** — summary-only (full snapshot not included):

| Field | Type | Notes |
|---|---|---|
| `captureSeq` | number | |
| `createdAt` | string | ISO |
| `ledgerId` | string | 16-char hex |
| `overallObservationHealth` | `ObservationHealth` | Extracted from `snapshot.summary` |
| `governanceReadiness` | `GovernanceGrade` | Extracted from `snapshot.summary` |
| `observationCoverage` | number | Extracted from `snapshot.summary` |
| `exposureRiskLevel` | `ExposureRiskLevel` | Extracted from `snapshot.summary` |
| `executionBlocked` | `true` | literal |

**`LedgerHistoryListResult`** — returned from `GET /history` (200):

| Field | Type | Notes |
|---|---|---|
| `entries` | `LedgerHistoryListItem[]` | Newest-first (descending captureSeq) |
| `total` | number | `entries.length` |
| `maxRetained` | number | Always 20 |
| `storeKey` | string | `"workspace-observation-ledger-history"` |
| `executionBlocked` | `true` | literal |

### Persistence semantics

- **Ring buffer**: `historyRing[]` in module scope. Entries pushed on each capture. Pruning removes from the front (`Array.shift()`) when length > 20. The oldest captured entry (lowest `captureSeq`) is always the first to be pruned.
- **Atomic flush**: `writeStore(STORE_KEY, historyRing)` called after every capture. Wrapped in try-catch — flush failure logs an error but never throws, so the ring is still available in memory for subsequent reads.
- **Load on boot**: `readStore<unknown[]>(STORE_KEY)` reads the persisted array. Each element is validated via `isValidEntry()`. Invalid elements are dropped and a `logger.warn` is emitted. The valid slice is taken as `[-MAX_ENTRIES:]` (newest 20).
- **captureSeq resume**: After loading valid entries, `nextCaptureSeq = max(captureSeq values) + 1`. On a fresh server with no persisted data, `nextCaptureSeq = 1`.
- **Ordering on list**: `listWorkspaceObservationLedgerHistory()` sorts a copy of `historyRing` by `captureSeq` descending before building the list items — newest-first regardless of insertion order on boot.

### Entry validation (`isValidEntry`)

An entry is valid iff:
- `typeof captureSeq === "number"`
- `typeof createdAt === "string"`
- `typeof ledgerId === "string"`
- `snapshot !== null && typeof snapshot === "object"`
- `executionBlocked === true`

Full snapshot schema is not re-validated on boot — structural type checking only. This bounds boot time for large rings (max 20 entries).

### Error handling

- **Capture side**: `getWorkspaceObservationLedger()` calls never throw (all 6 inner modules are try-catch wrapped via the probe). The capture path is effectively unconditionally safe.
- **Flush side**: `writeStore` is wrapped in try-catch. On failure, the in-memory ring is preserved and available for subsequent requests. The entry is still returned to the caller — capture "succeeds" from the caller's perspective; only the durable copy is lost.
- **Boot side**: Malformed entries are silently dropped. An empty or missing store produces an empty ring and `nextCaptureSeq = 1`.

### Runtime init placement

```typescript
// runtime.ts
initWorkspaceSnapshots();
initWorkspaceAuditReports();
initWorkspaceObservationLedgerHistory();  // ← Phase 98 addition
initRuntimeDependencyGraph();
```

Placed after `initWorkspaceAuditReports()` since the ledger history init has no dependency on the dependency graph or capability matrix, and the workspace audit reports init must complete before the observation layer is fully operational.

### Invariants

- `ringSize` in `LedgerHistoryCaptureResult === historyRing.length` at the time of response construction.
- `entries` in `LedgerHistoryListResult` are always sorted by `captureSeq` descending.
- `entries.length === total` always.
- `captureSeq` values are strictly monotone-increasing across all captures in a process lifetime (no reuse, no gaps from restart).
- After restart, the first new `captureSeq` is always `> max(persisted captureSeq)`.
- Ring never exceeds 20 entries — oldest (lowest seq) is pruned first.
- `executionBlocked: true` in all response types (capture result, list result, each list item).
- No mutation of any other store key — only `workspace-observation-ledger-history`.

---

## Phase 97 — Workspace Observation Ledger

**Completed.** Introduces `GET /api/workspace/observation/ledger` — a unified governance dashboard readout that aggregates the key summary signals from all 5 observation modules plus the replay probe into a single compact, deterministic response. No HTTP requests are made internally — all 6 source modules are called as TypeScript functions in sequence. No persistence, no init, no subsystem registration, no health check.

### Module design

`workspaceObservationLedger.ts` imports all 6 observation and probe modules:

```
workspacePolicyComplianceLedger ──► compliance signal
workspaceObservationHeatmap ──────► heatmap signal
workspaceCoverageTrend ───────────► trend signal       workspaceObservationLedger
workspacePolicyExposureIndex ─────► exposure signal
workspaceGovernanceScorecard ─────► governance signal
workspaceObservationProbe ────────► probe signal
```

All 6 sources are called sequentially — deterministic, read-only, no parallelism.

### WorkspaceObservationLedger fields

| Field | Type | Notes |
|---|---|---|
| `ledgerId` | string (16-char hex) | `sha256(generatedAt).slice(0,16)` |
| `generatedAt` | ISO string | Timestamp of ledger construction start |
| `summary` | `ObservationLedgerSummary` | Derived aggregate health signals |
| `compliance` | `ObservationLedgerComplianceSignal` | Coverage numbers from compliance ledger |
| `heatmap` | `ObservationLedgerHeatmapSignal` | Band counts from heatmap |
| `trend` | `ObservationLedgerTrendSignal` | Coverage delta + trend direction |
| `exposure` | `ObservationLedgerExposureSignal` | Write-surface risk score + grade |
| `governance` | `ObservationLedgerGovernanceSignal` | Governance score + grade |
| `probe` | `ObservationLedgerProbeSignal` | Probe pass/fail + timing baseline |
| `executionBlocked` | `true` | literal |

### ObservationLedgerSummary fields

| Field | Type | Notes |
|---|---|---|
| `overallObservationHealth` | `"healthy" \| "degraded" \| "critical"` | Derived — see rules below |
| `governanceReadiness` | `GovernanceGrade` (A–F) | Direct from scorecard |
| `observationCoverage` | number (int 0–100) | `compliance.summary.coveragePercent` |
| `exposureRiskLevel` | `"low" \| "medium" \| "high" \| "none"` | Derived from exposure grade + total write policies |
| `trendDirection` | `TrendDirection \| null` | Direct from trend summary |
| `probeHealth` | `"all_passed" \| "partial" \| "none_passed"` | Derived from probe summary |
| `executionBlocked` | `true` | literal |

### Signal interfaces (compact extractions)

**`ObservationLedgerComplianceSignal`**: `coveragePercent`, `observedPolicies`, `unobservedPolicies`, `totalPolicies`.

**`ObservationLedgerHeatmapSignal`**: `coldCount`, `warmCount`, `hotCount`, `totalPolicies`, `coveragePercent`.

**`ObservationLedgerTrendSignal`**: `currentCoveragePercent`, `previousCoveragePercent`, `coverageDelta`, `trendDirection`, `comparedSnapshotCount`.

**`ObservationLedgerExposureSignal`**: `exposureScore`, `exposureGrade`, `totalWritePolicies`, `unobservedWritePolicies`, `rarelyObservedWritePolicies`, `wellObservedWritePolicies`.

**`ObservationLedgerGovernanceSignal`**: `governanceScore`, `governanceGrade`.

**`ObservationLedgerProbeSignal`**: `allProbesPassed`, `passedProbeCount`, `failedProbeCount`, `totalProbes`, `totalProbeTimeMs`, `fastestProbeMs`, `slowestProbeMs`.

All signal interfaces include `executionBlocked: true`.

### Derivation rules

**`exposureRiskLevel`** (from `exposureGrade` + `totalWritePolicies`):

| Condition | Result |
|---|---|
| `totalWritePolicies === 0` | `"none"` |
| Grade `A` or `B` | `"low"` |
| Grade `C` or `D` | `"medium"` |
| Grade `F` | `"high"` |

**`probeHealth`** (from `probe.summary`):

| Condition | Result |
|---|---|
| `allProbesPassed === true` | `"all_passed"` |
| `passedProbeCount === 0` | `"none_passed"` |
| Otherwise | `"partial"` |

**`overallObservationHealth`** (evaluated in priority order):

| Condition | Result |
|---|---|
| `probeHealth === "none_passed"` OR `observationCoverage < 25` OR `exposureRiskLevel === "high"` | `"critical"` |
| `probeHealth === "partial"` OR `observationCoverage < 50` OR `exposureRiskLevel === "medium"` OR `governanceReadiness ∈ {"D","F"}` | `"degraded"` |
| Otherwise | `"healthy"` |

The three tiers form a strict priority ordering. Critical takes precedence over degraded, degraded over healthy. On a fresh server with no audit history (0% coverage), the ledger will correctly report `"critical"`.

### Invariants

- `ledger.compliance.coveragePercent === ledger.summary.observationCoverage` always.
- `ledger.heatmap.coldCount + ledger.heatmap.warmCount + ledger.heatmap.hotCount === ledger.heatmap.totalPolicies` always.
- `ledger.probe.passedProbeCount + ledger.probe.failedProbeCount === ledger.probe.totalProbes === 5` always.
- `ledger.exposure.unobservedWritePolicies + ledger.exposure.rarelyObservedWritePolicies + ledger.exposure.wellObservedWritePolicies === ledger.exposure.totalWritePolicies` always.
- `ledger.summary.probeHealth === "all_passed"` iff `ledger.probe.allProbesPassed === true`.
- `ledger.summary.exposureRiskLevel` is a deterministic function of `ledger.exposure.exposureGrade` and `ledger.exposure.totalWritePolicies`.
- `ledger.summary.overallObservationHealth` is a deterministic function of `probeHealth`, `observationCoverage`, `exposureRiskLevel`, and `governanceReadiness`.
- `executionBlocked: true` in root, summary, all 6 signal objects.
- No persistence mutation of any kind — pure sequential read-only aggregation.

### Import hierarchy

`workspaceObservationLedger` is a terminal aggregator one level above the probe. It imports both the 5 observation leaves and the probe itself:

```
Compliance Ledger ←─── [heatmap, trend, exposure] (all 3 import compliance)
                                                        │
Governance Scorecard ←──── [workspaceShell, auditReport]│
                                                        ↓
workspaceObservationProbe ←── [all 5 above]    workspaceObservationLedger ←── [all 6 above]
```

No cycles introduced. The ledger is the deepest leaf in the governance observation import graph.

---

## Phase 96 — Workspace Observation Replay Probe

**Completed.** Introduces `GET /api/workspace/observation/probe` — a deterministic, sequential health sweep of all 5 governance observation modules. Each module is called once, its response is timed with `Date.now()`, its top-level schema is validated against a required-field checklist, and its `executionBlocked: true` invariant is checked. Aggregate timing and pass/fail counts are surfaced in the summary. No persistence, no init, no subsystem registration, no health check.

### Module design

`workspaceObservationProbe.ts` fans out to all 5 observation leaf nodes in a fixed sequence:

```
workspacePolicyComplianceLedger ──► (probe 1)
workspaceObservationHeatmap ──────► (probe 2)
workspaceCoverageTrend ───────────► (probe 3)   workspaceObservationProbe
workspacePolicyExposureIndex ─────► (probe 4)
workspaceGovernanceScorecard ─────► (probe 5)
```

All 5 probes run sequentially — no parallelism. This ensures a deterministic, low-variance timing baseline and avoids any shared-state contention between observation modules.

### WorkspaceObservationProbeResult fields

| Field | Type | Notes |
|---|---|---|
| `probeId` | string (16-char hex) | `sha256(generatedAt).slice(0,16)` |
| `generatedAt` | ISO string | Timestamp of probe start |
| `summary` | `ObservationProbeSummary` | Aggregate pass/fail + timing |
| `probes` | `SubProbeResult[]` | Always exactly 5, stable order |
| `executionBlocked` | `true` | literal |

### ObservationProbeSummary fields

| Field | Type | Notes |
|---|---|---|
| `allProbesPassed` | boolean | `failedProbeCount === 0` |
| `passedProbeCount` | number | Count of probes where `passed === true` |
| `failedProbeCount` | number | `totalProbes - passedProbeCount` |
| `totalProbes` | number | Always 5 |
| `fastestProbeMs` | number \| null | `Math.min(...responseTimeMsValues)` |
| `slowestProbeMs` | number \| null | `Math.max(...responseTimeMsValues)` |
| `totalProbeTimeMs` | number | Sum of all `responseTimeMs` values |
| `executionBlocked` | `true` | literal |

### SubProbeResult fields

| Field | Type | Notes |
|---|---|---|
| `probeIndex` | number (1–5) | Stable, 1-based |
| `moduleName` | string | TypeScript module name |
| `endpoint` | string | Corresponding HTTP endpoint path |
| `responseTimeMs` | number | `Date.now()` delta around module call |
| `schemaValid` | boolean | All required top-level fields present |
| `executionBlockedValid` | boolean | Root `executionBlocked === true` |
| `missingFields` | string[] | Empty when `schemaValid === true` |
| `passed` | boolean | `schemaValid && executionBlockedValid` |
| `executionBlocked` | `true` | literal |

### Probe order and schema requirements

| probeIndex | moduleName | endpoint | Required fields |
|---|---|---|---|
| 1 | `workspacePolicyComplianceLedger` | `/api/workspace/policy/compliance` | `ledgerId`, `generatedAt`, `summary`, `entries`, `auditEntriesScanned`, `executionBlocked` |
| 2 | `workspaceObservationHeatmap` | `/api/workspace/observation/heatmap` | `heatmapId`, `generatedAt`, `summary`, `permissionMatrix`, `roleTierMatrix`, `policies`, `auditEntriesScanned`, `executionBlocked` |
| 3 | `workspaceCoverageTrend` | `/api/workspace/observation/trend` | `trendId`, `generatedAt`, `summary`, `snapshotHistory`, `auditEntriesScanned`, `executionBlocked` |
| 4 | `workspacePolicyExposureIndex` | `/api/workspace/observation/exposure` | `exposureId`, `generatedAt`, `summary`, `entries`, `totalPoliciesScanned`, `auditEntriesScanned`, `executionBlocked` |
| 5 | `workspaceGovernanceScorecard` | `/api/workspace/governance/scorecard` | `scorecardId`, `generatedAt`, `governanceScore`, `governanceGrade`, `breakdown`, `recommendations`, `signals`, `executionBlocked` |

### Exception handling

Each probe is wrapped in a try-catch. If a module throws (should never happen in normal operation, but is handled defensively):
- `responseTimeMs` = time elapsed until the throw
- `schemaValid = false`
- `executionBlockedValid = false`
- `missingFields = ["(module threw an exception)"]`
- `passed = false`

The remaining probes continue running regardless. A single failure does not abort the sweep.

### Timing semantics

- `responseTimeMs` is `Date.now()` before and after the module call — integer milliseconds. Sub-millisecond calls report `0`.
- `totalProbeTimeMs` is the **sum** of all individual `responseTimeMs` values, not wall-clock probe duration. Inter-probe overhead (loop iterations, object construction) is not included.
- `fastestProbeMs` and `slowestProbeMs` are the min/max of the 5 `responseTimeMs` values. Both are `null` only when `totalProbes === 0` — which cannot happen in the current implementation since the probe array is always 5 entries.

### Invariants

- `probes.length === 5 === summary.totalProbes` always.
- `probeIndex` values are `[1, 2, 3, 4, 5]` in order — never reordered.
- `passedProbeCount + failedProbeCount === totalProbes` always.
- `allProbesPassed === (failedProbeCount === 0)` always.
- `totalProbeTimeMs === sum(probes.map(p => p.responseTimeMs))` always.
- `fastestProbeMs <= slowestProbeMs` when both non-null.
- `passed === (schemaValid && executionBlockedValid)` for every sub-probe.
- `executionBlocked: true` in probe root, summary, every SubProbeResult.
- No persistence mutation of any kind — pure read-only aggregation calling read-only modules.

---

## Phase 95 — Workspace Policy Exposure Index

**Completed.** Introduces `GET /api/workspace/observation/exposure` — a deterministic, read-only write-surface risk classification. It filters the compliance ledger to write-permission policies only and classifies each by observation frequency into three risk tiers, producing a weighted inverse-risk `exposureScore` (0–100) and an `exposureGrade` (A–F). No persistence, no init, no subsystem registration, no health check.

### Module design

`workspacePolicyExposureIndex.ts` is a leaf node with a single upstream dependency:

```
workspacePolicyComplianceLedger ──► workspacePolicyExposureIndex (leaf)
```

It calls `getPolicyComplianceLedger()` once, filters to `isWritePolicy === true` entries, and classifies each by observationCount. The compliance ledger already has all observation data — no second audit scan is needed.

### WorkspacePolicyExposureIndex fields

| Field | Type | Notes |
|---|---|---|
| `exposureId` | string (16-char hex) | `sha256(generatedAt).slice(0,16)` |
| `generatedAt` | ISO string | Timestamp of computation |
| `summary` | `ExposureIndexSummary` | All risk metrics |
| `entries` | `ExposureIndexEntry[]` | Write policies only, ordered by risk tier |
| `totalPoliciesScanned` | number | All policies scanned (before write filter) |
| `auditEntriesScanned` | number | Passed through from compliance ledger |
| `executionBlocked` | `true` | literal |

### ExposureIndexSummary fields

| Field | Type | Notes |
|---|---|---|
| `totalWritePolicies` | number | Count of write-permission policies (entries.length) |
| `unobservedWritePolicies` | number | observationCount === 0 |
| `rarelyObservedWritePolicies` | number | observationCount 1–9 |
| `wellObservedWritePolicies` | number | observationCount ≥ 10 |
| `exposureScore` | integer 0–100 | Inverse-risk weighted score |
| `exposureGrade` | `"A" \| "B" \| "C" \| "D" \| "F"` | Derived from exposureScore |
| `highestRiskPolicy` | `ExposureWriteRef \| null` | Write policy with lowest observationCount |
| `lowestRiskPolicy` | `ExposureWriteRef \| null` | Write policy with highest observationCount |
| `executionBlocked` | `true` | literal |

### Risk level classification

| Risk level | Condition | Meaning |
|---|---|---|
| `unobserved_write` | observationCount === 0 | Write path never hit — unknown governance surface |
| `rarely_observed_write` | 1 ≤ observationCount < 10 | Write path hit rarely — limited signal |
| `well_observed_write` | observationCount ≥ 10 | Write path well-monitored — strong signal |

### Exposure score formula

```
exposureScore = round((wellCount × 1.0 + rarelyCount × 0.5) / totalWritePolicies × 100)
```

- `well_observed_write` → full credit (weight 1.0)
- `rarely_observed_write` → half credit (weight 0.5)
- `unobserved_write` → no credit (weight 0.0)
- If `totalWritePolicies === 0`: `exposureScore = 100` (vacuous compliance — no write surface)
- Clamped to `[0, 100]` via `Math.min(100, ...)`

### Exposure grade thresholds

| Grade | Minimum score |
|---|---|
| A | 90 |
| B | 75 |
| C | 60 |
| D | 45 |
| F | < 45 |

Identical thresholds to `workspaceGovernanceScorecard.ts` — deliberate consistency.

### Entry ordering

Entries are sorted highest-risk-first within each tier:

1. `unobserved_write` — alphabetical by `method:path` ASC (all equally risky)
2. `rarely_observed_write` — ascending `observationCount` ASC (least observed = highest risk first), tie-break `method:path` ASC
3. `well_observed_write` — ascending `observationCount` ASC (least observed = highest risk first), tie-break `method:path` ASC

### highestRiskPolicy and lowestRiskPolicy

- `highestRiskPolicy`: write entry with minimum `observationCount`, tie-break `method:path` ASC. Always an `unobserved_write` when any exist.
- `lowestRiskPolicy`: write entry with maximum `observationCount`, tie-break `method:path` ASC. Always a `well_observed_write` when any exist.
- Both are `null` only when `totalWritePolicies === 0`.

### ExposureWriteRef fields

| Field | Type | Notes |
|---|---|---|
| `method` | string | HTTP method |
| `path` | string | Route path pattern |
| `permission` | string | Always `"write"` |
| `minimumRole` | string | From policy registry |
| `observationCount` | number | From audit log scan |
| `riskLevel` | `WriteRiskLevel` | Tier classification |
| `executionBlocked` | `true` | literal |

### Invariants

- `unobservedWritePolicies + rarelyObservedWritePolicies + wellObservedWritePolicies === totalWritePolicies` always.
- `entries.length === totalWritePolicies` always.
- Every entry has `permission === "write"`.
- `0 ≤ exposureScore ≤ 100` always (integer).
- `exposureGrade ∈ {"A","B","C","D","F"}` always.
- `highestRiskPolicy` and `lowestRiskPolicy` are both null iff `totalWritePolicies === 0`.
- `highestRiskPolicy.observationCount ≤ lowestRiskPolicy.observationCount` when both non-null.
- `executionBlocked: true` in root, summary, every entry, every ExposureWriteRef.
- No persistence mutation of any kind — pure read-only aggregation.

---

## Phase 94 — Workspace Coverage Trend Layer

**Completed.** Introduces `GET /api/workspace/observation/trend` — a deterministic, read-only temporal coverage comparison. It uses workspace snapshot timestamps as historical anchors and counts how many compliance ledger entries had `firstObservedAt <= snapshot.createdAt` to compute a coverage curve over time. No persistence, no init, no subsystem registration, no health check.

### Module design

`workspaceCoverageTrend.ts` is a leaf node that draws from two independent upstream modules:

```
workspacePolicyComplianceLedger ──► workspaceCoverageTrend (leaf)
workspaceSnapshots ─────────────►
```

It calls `getPolicyComplianceLedger()` once for live entries (O(P×A) — done inside that module) and `listWorkspaceSnapshots()` once for snapshot timestamps. The O(P×S) historical scan (P=91 policies, S≤5 snapshots) is 455 iterations worst-case — negligible.

### WorkspaceCoverageTrend fields

| Field | Type | Notes |
|---|---|---|
| `trendId` | string (16-char hex) | `sha256(generatedAt).slice(0,16)` |
| `generatedAt` | ISO string | Timestamp of computation |
| `summary` | `CoverageTrendSummary` | All trend metrics |
| `snapshotHistory` | `SnapshotCoveragePoint[]` | Max 5, newest-first |
| `auditEntriesScanned` | number | Passed through from compliance ledger |
| `executionBlocked` | `true` | literal |

### CoverageTrendSummary fields

| Field | Type | Notes |
|---|---|---|
| `currentCoveragePercent` | integer 0–100 | (hot+warm)/total×100 from live state |
| `previousCoveragePercent` | integer 0–100 \| null | From most-recent snapshot point; null if no snapshots |
| `coverageDelta` | integer \| null | current − previous; null if no snapshots |
| `heatShift` | `HeatShift` | Current band counts + delta vs previous |
| `trendDirection` | `"improving" \| "stable" \| "degrading" \| null` | null if no snapshots; improving if delta>0 |
| `comparedSnapshotCount` | number | Length of snapshotHistory |
| `totalPolicies` | number | From compliance ledger |
| `currentObservedCount` | number | hot + warm count (live) |
| `executionBlocked` | `true` | literal |

### HeatShift fields

| Field | Type | Notes |
|---|---|---|
| `hotCountCurrent` | number | Live hot count (observationCount ≥ 10) |
| `warmCountCurrent` | number | Live warm count (1–9) |
| `coldCountCurrent` | number | Live cold count (0) |
| `observedDelta` | integer \| null | currentObservedCount − previousObservedCount; null if no snapshots |
| `unobservedDelta` | integer \| null | −observedDelta; null if no snapshots |
| `executionBlocked` | `true` | literal |

### SnapshotCoveragePoint fields

| Field | Type | Notes |
|---|---|---|
| `snapshotId` | string | From workspace snapshot ring |
| `snapshotCreatedAt` | ISO string | Snapshot timestamp used as historical anchor |
| `historicalObservedCount` | number | count(entries where firstObservedAt ≤ snapshotCreatedAt) |
| `historicalCoveragePercent` | integer 0–100 | historicalObservedCount/totalPolicies×100 |
| `executionBlocked` | `true` | literal |

### Key design constraint: firstObservedAt as historical proxy

The compliance ledger records `firstObservedAt` — the earliest audit log entry timestamp that matched each policy. By filtering `firstObservedAt <= snapshot.createdAt`, we answer "how many policies had been observed at least once by the time this snapshot was taken." This is not a full audit replay — it cannot compute historical hot/warm/cold band counts, only historical observed/unobserved. Band counts (`hotCountCurrent`, `warmCountCurrent`, `coldCountCurrent`) reflect the current live state only.

### Invariants

- `hotCountCurrent + warmCountCurrent + coldCountCurrent === totalPolicies` always.
- `currentObservedCount === hotCountCurrent + warmCountCurrent` always.
- `snapshotHistory.length === comparedSnapshotCount` always.
- `snapshotHistory.length <= 5` always.
- `snapshotHistory` ordered newest-first (snapshotCreatedAt DESC).
- `previousCoveragePercent === snapshotHistory[0].historicalCoveragePercent` when snapshotHistory non-empty.
- `trendDirection` is null if and only if `previousCoveragePercent` is null (no snapshots).
- `observedDelta` is null if and only if `unobservedDelta` is null; when non-null: `observedDelta + unobservedDelta === 0`.
- `0 <= historicalObservedCount <= totalPolicies` for every snapshot point.
- `executionBlocked: true` in trend root, summary, heatShift, every SnapshotCoveragePoint.

---

## Phase 93 — Workspace Observation Heatmap

**Completed.** Introduces `GET /api/workspace/observation/heatmap` — a deterministic, read-only activity-band matrix over all 90 registered policies, derived entirely from the compliance ledger's already-computed `entries[]`. No second audit scan, no persistence, no init, no subsystem registration, no health check.

### Module design

`workspaceObservationHeatmap.ts` is a leaf node that sits one level above the compliance ledger in the enforcement/observability layer:

```
accessEnforcement ──► workspacePolicyComplianceLedger ──► workspaceObservationHeatmap (leaf)
auditLog ───────────►
```

The heatmap calls `getPolicyComplianceLedger()` once per request and re-aggregates its `entries[]` — no direct dependency on `accessEnforcement`, `auditLog`, or any workspace-layer module.

### Band thresholds

| Band | Condition | Governance signal |
|---|---|---|
| `cold` | observationCount === 0 | Route never hit — audit coverage gap |
| `warm` | 1 ≤ observationCount ≤ 9 | Route observed, limited sample |
| `hot` | observationCount ≥ 10 | Route well-observed |

### WorkspaceObservationHeatmap fields

| Field | Type | Notes |
|---|---|---|
| `heatmapId` | string (16-char hex) | `sha256(generatedAt).slice(0,16)` — deterministic per millisecond |
| `generatedAt` | ISO string | Timestamp of computation |
| `summary` | `HeatmapSummary` | totalPolicies, coldCount, warmCount, hotCount, coveragePercent, hottestPolicy, coldestPolicy |
| `permissionMatrix` | `Record<string, BandCounts>` | 3 canonical keys: read / monitor / write |
| `roleTierMatrix` | `Record<string, BandCounts>` | 5 canonical keys: owner / admin / operator / viewer / guest |
| `policies` | `HeatmapPolicyRef[]` | All 90 refs — hot-desc → warm-desc → cold-alpha |
| `auditEntriesScanned` | number | Passed through from compliance ledger |
| `executionBlocked` | `true` | literal |

### BandCounts fields

| Field | Type | Notes |
|---|---|---|
| `cold` | number | Count in cold band |
| `warm` | number | Count in warm band |
| `hot` | number | Count in hot band |
| `total` | number | cold + warm + hot (always) |
| `executionBlocked` | `true` | literal |

### HeatmapPolicyRef fields

| Field | Type | Notes |
|---|---|---|
| `method` | string | GET / POST / PATCH / DELETE |
| `path` | string | Policy path pattern |
| `permission` | string | read / monitor / write |
| `minimumRole` | string | owner / admin / operator / viewer / guest |
| `observationCount` | number | From compliance ledger entry |
| `band` | `ActivityBand` | cold / warm / hot |
| `executionBlocked` | `true` | literal |

### HeatmapSummary fields

| Field | Type | Notes |
|---|---|---|
| `totalPolicies` | number | Always equals `policies.length` |
| `coldCount` | number | Count with band "cold" |
| `warmCount` | number | Count with band "warm" |
| `hotCount` | number | Count with band "hot" |
| `coveragePercent` | integer 0–100 | `Math.round((warm+hot)/total*100)` |
| `hottestPolicy` | `HeatmapPolicyRef \| null` | Max observationCount ref (null if no policies) |
| `coldestPolicy` | `HeatmapPolicyRef \| null` | Min observationCount ref (null if no policies) |
| `executionBlocked` | `true` | literal |

### Invariants

- `coldCount + warmCount + hotCount === totalPolicies` always.
- `sum(permissionMatrix[k].total for k in keys) === totalPolicies` always.
- `sum(roleTierMatrix[k].total for k in keys) === totalPolicies` always.
- `permissionMatrix[k].cold + permissionMatrix[k].warm + permissionMatrix[k].hot === permissionMatrix[k].total` for every key.
- `roleTierMatrix[k].cold + roleTierMatrix[k].warm + roleTierMatrix[k].hot === roleTierMatrix[k].total` for every key.
- All hot entries precede all warm entries; all warm precede all cold in `policies[]`.
- `coveragePercent` equals the compliance ledger's `coveragePercent` (both compute observed/total × 100).
- `executionBlocked: true` in heatmap root, summary, every `BandCounts` value, every `HeatmapPolicyRef`.

---

## Phase 92 — Workspace Policy Compliance Ledger

**Completed.** Introduces `GET /api/workspace/policy/compliance` — a deterministic, read-only per-policy observation coverage ledger derived from the audit log ring buffer. No persistence, no init, no subsystem registration, no health check.

### Module design

`workspacePolicyComplianceLedger.ts` sits in the **enforcement/observability layer**, not the workspace layer. It reads from two existing modules that have no import dependency on each other:

```
accessEnforcement ──► workspacePolicyComplianceLedger (leaf)
auditLog ───────────►
```

The workspace layer terminal nodes (`workspaceAuditDigest`, `workspaceGovernanceScorecard`) draw from workspace-layer modules. The compliance ledger draws from enforcement-layer modules. These are parallel, independent observation layers.

### PolicyComplianceLedger fields

| Field | Type | Source | Notes |
|---|---|---|---|
| `ledgerId` | string (16-char hex) | `sha256(generatedAt).slice(0,16)` | Deterministic per millisecond |
| `generatedAt` | ISO string | `new Date()` | Timestamp of ledger computation |
| `summary` | `ComplianceSummary` | aggregated from entries | totalPolicies, observedPolicies, unobservedPolicies, blockedPolicies, coveragePercent, latestObservedAt |
| `entries` | `ComplianceLedgerEntry[]` | one per registered policy | All 89 policies; observed-desc then unobserved-alpha |
| `auditEntriesScanned` | number | `getAuditLogEntries(1000).entries.length` | Actual audit entries scanned (0–1000) |
| `executionBlocked` | `true` | literal | Always present |

### ComplianceLedgerEntry fields

| Field | Type | Notes |
|---|---|---|
| `method` | string | GET / POST / PATCH / DELETE |
| `path` | string | Policy path pattern (may contain `:param` segments) |
| `permission` | string | read / monitor / write |
| `minimumRole` | string | owner / admin / operator / viewer / guest |
| `status` | `"observed" \| "unobserved"` | observed if observationCount > 0 |
| `isWritePolicy` | boolean | permission === "write" — marks mutation-capable routes |
| `observationCount` | number | Audit entries matching this policy (method + path pattern) |
| `allowedCount` | number | Subset with decision === "allowed" |
| `deniedCount` | number | Subset with decision === "denied" |
| `lastObservedAt` | string \| null | Most recent matching audit entry timestamp |
| `firstObservedAt` | string \| null | Oldest matching audit entry timestamp |
| `executionBlocked` | `true` | literal |

### ComplianceSummary fields

| Field | Type | Notes |
|---|---|---|
| `totalPolicies` | number | Always equals `entries.length` |
| `observedPolicies` | number | Count with status "observed" |
| `unobservedPolicies` | number | `totalPolicies - observedPolicies` |
| `blockedPolicies` | number | Count with `permission === "write"` (static — governance-blocked mutation routes) |
| `coveragePercent` | integer 0–100 | `Math.round(observedPolicies / totalPolicies * 100)` |
| `latestObservedAt` | string \| null | Max `lastObservedAt` across all observed entries |
| `executionBlocked` | `true` | literal |

### Invariants

- `summary.observedPolicies + summary.unobservedPolicies === summary.totalPolicies` always.
- `summary.coveragePercent === Math.min(100, Math.round(summary.observedPolicies / summary.totalPolicies * 100))` always.
- `summary.blockedPolicies === entries.filter(e => e.isWritePolicy).length` always.
- All observed entries precede all unobserved entries in `entries[]`.
- Within observed: sorted by `observationCount` DESC, tie-broken by `method:path` ASC.
- Within unobserved: sorted by `method:path` ASC.
- `entry.allowedCount + entry.deniedCount <= entry.observationCount` always.
- Calling `GET /api/workspace/policy/compliance` N times never mutates any persistent store key.

---

## Phase 91 — Workspace Governance Scorecard Layer

**Completed.** Introduces `GET /api/workspace/governance/scorecard` — a deterministic, read-only governance health scorecard with no persistence, no init, no subsystem registration, and no health check.

### Module design

`workspaceGovernanceScorecard.ts` is a pure computation module — a second terminal node in the workspace layer DAG, parallel to `workspaceAuditDigest`:

```
workspaceShell ──────────────────────────────────────┬──► workspaceAuditDigest (terminal)
workspaceSnapshots ───────── workspaceAuditReport ───┤
workspaceDiff ───────────────────────────────────────┤
workspaceTimeline ───────────────────────────────────┴──► workspaceGovernanceScorecard (terminal)
```

Neither terminal node imports the other. Both are parallel leaf nodes in the DAG.

### WorkspaceGovernanceScorecard fields

| Field | Type | Source | Notes |
|---|---|---|---|
| `scorecardId` | string (16-char hex) | `sha256(generatedAt).slice(0,16)` | Deterministic — same generatedAt → same ID; no randomBytes |
| `generatedAt` | ISO string | `new Date()` | Timestamp of scorecard computation |
| `governanceScore` | integer 0–100 | weighted formula | `Math.round(sum(rawScore_i * weight_i / 100))` |
| `governanceGrade` | "A"\|"B"\|"C"\|"D"\|"F" | `gradeFromScore()` | A≥90, B≥75, C≥60, D≥45, F<45 |
| `breakdown` | `ScorecardCategory[]` (5 items) | per-dimension scorers | Each item: category, rawScore (int 0–100), weight, weightedScore, signal |
| `recommendations` | `string[]` (max 5) | `buildRecommendations()` | Advisory only — deterministic from low-scoring dimensions (<50 threshold) |
| `signals` | `ScorecardSignals` | live workspace reads | 7 numeric + 1 boolean; raw inputs used for computation |
| `executionBlocked` | `true` | literal | Always present |

### Scoring formula

| Category | Weight | rawScore formula | Full score condition |
|---|---|---|---|
| `capacity_utilization` | 20 | `100 - round(utilizationPercent)`, clamped 0–100 | 0% capacity used |
| `audit_report_coverage` | 25 | `round(retainedReportCount / 10 * 100)`, clamped | 10 reports retained |
| `snapshot_availability` | 25 | `round(snapshotCount / 20 * 100)`, clamped | 20 snapshots retained |
| `member_project_ratio` | 15 | `min(100, round(memberRecords / totalProjects / 2 * 100))`; 100 if no projects | ≥2 members/project |
| `quota_adoption` | 15 | `round(projectsWithCustomQuotas / totalProjects * 100)`; 100 if no projects | All projects have custom quotas |

Weights sum to 100. `governanceScore = Math.round(sum(weightedScore_i))` where `weightedScore_i = rawScore_i * weight_i / 100`.

### Invariants

- `breakdown.length === 5` always.
- `breakdown.reduce((a,c) => a + c.weight, 0) === 100` always.
- `Math.abs(Math.round(breakdown.reduce((a,c) => a + c.weightedScore, 0)) - governanceScore) <= 1` (rounding invariant).
- All `rawScore` values are integers in [0, 100].
- `recommendations.length <= 5` always.
- All recommendation strings are advisory — no execution instructions, no mutation paths, no self-modification.
- Calling `GET /api/workspace/governance/scorecard` N times never mutates the audit report ring, snapshot ring, project registry, or any persistent store key.
- `scorecardId` is deterministic: `createHash('sha256').update(generatedAt).digest('hex').slice(0, 16)`. Given the same ISO timestamp (same millisecond), the same ID is produced. Two calls at different milliseconds always produce different IDs.

---

## Phase 90 — Workspace Audit Digest Layer

**Completed.** Introduces `GET /api/workspace/audit/digest` — a single-call, read-only governance overview with no persistence, no init, no subsystem registration, and no health check.

### Module design

`workspaceAuditDigest.ts` is a pure aggregation module — the new terminal node in the workspace layer DAG:

```
workspaceShell ──────────────────────────────────────┐
workspaceSnapshots ───────── workspaceAuditReport ───► workspaceAuditDigest
workspaceDiff ───────────────────────────────────────┘ (terminal)
workspaceTimeline ───────────────────────────────────┘
```

No module that `workspaceAuditDigest` imports may itself import `workspaceAuditDigest`.

### WorkspaceAuditDigest fields

| Field | Type | Source | Notes |
|---|---|---|---|
| `digestId` | string (16-char hex) | `randomBytes(8)` | Unique per call — ephemeral, never stored |
| `generatedAt` | ISO string | `new Date()` | Timestamp of digest generation |
| `workspaceSummary` | `WorkspaceSummary` | `getWorkspaceSummary()` | Live — reflects current state |
| `latestSnapshot` | `DigestSnapshotExcerpt \| null` | `getLatestWorkspaceSnapshot()` | Null if ring is empty |
| `recentReports` | `DigestReportExcerpt[]` (max 5) | `listAuditReports({ limit: 10 }).reports.slice(0, 5)` | Summary fields only, executionBlocked per item |
| `changeSignalSummary` | `DigestChangeSignalSummary` | All 10 retained reports | Counts by type and hasChanges — both sums equal retainedReportCount |
| `diagnosticsExcerpt` | `DigestDiagnosticsExcerpt` | `getWorkspaceHealth()` | 3 fields: status, registryOperational, storeKeyCount |
| `governanceExcerpt` | `DigestGovernanceExcerpt` | Same `WorkspaceSummary` call | 9 governance fields derived from `workspaceSummary` |
| `executionBlocked` | `true` | literal | Always present |

### Invariants

- `changeSignalSummary.snapshotComparisonCount + timelineSummaryCount + governanceReviewCount === retainedReportCount`
- `changeSignalSummary.hasChangesTrue + hasChangesFalse + hasChangesNull === retainedReportCount`
- Calling `GET /api/workspace/audit/digest` N times always leaves `totalBeforeFilter` on `GET /api/workspace/audit/reports` unchanged — no persistence mutation of any kind.

---

## Phase 89 — Workspace Audit Report Search & Filtering

**Completed.** Additive query-string filtering on `GET /api/workspace/audit/reports`. Zero new endpoints, zero new policies, zero new subsystems, zero new health checks.

### Filter parameters

| Parameter | Values | Invalid handling |
|---|---|---|
| `?reportType` | `snapshot_comparison` \| `timeline_summary` \| `governance_review` | Not in `VALID_REPORT_TYPES` → silently ignored, not added to `filtersApplied` |
| `?hasChanges` | `"true"` \| `"false"` only | Any other string → silently ignored, filter not applied |
| `?since` | ISO date string (floor) | `Date.parse()` returns `NaN` → silently ignored, filter not applied |
| `?limit` | Integer 1–10; default 10, max 10 | ≤0 or non-numeric → default; >10 → clamped to 10 |

### Response additions

`WorkspaceAuditReportListResult` gained two additive fields in Phase 89:

- `totalBeforeFilter: number` — ring size before any filter is applied (0–10)
- `filtersApplied: string[]` — active semantic filters as `"key=value"` strings; `limit` is never included (it is a pagination control, not a semantic filter)

### Ordering guarantee

Newest-first ordering is established by reversing the ring **before** any filter is applied. All three semantic filters (`reportType`, `hasChanges`, `since`) operate on the already-reversed pool, so ordering is always preserved.

### `?hasChanges` semantics

`hasChanges` on `WorkspaceAuditReportListItem` is `null` for `timeline_summary` and `governance_review` report types (their `diffSummary` is `null`). The `?hasChanges=true` and `?hasChanges=false` filters compare using strict equality (`=== filter.hasChanges`). Since `null !== true` and `null !== false`, non-comparison reports are always excluded by either value of this filter.

---

## Phase 88 — Workspace Audit Report Layer

**Completed.** Three new endpoints under `/api/workspace/audit/`.

### Design goals

1. **Immutable governance records** — once created, a report is never mutated. `createdAt` is fixed at creation time and is identical on every read.
2. **Bounded retention** — max 10 reports in the ring buffer. Oldest is pruned on overflow. Reports survive server restarts via the `workspace-audit-reports` persistent store key.
3. **Zero-execution contract** — `executionBlocked: true` is a typed literal constant on every report. No runtime flag, no config option.
4. **Three aggregation modes** — `snapshot_comparison` (requires two snapshot IDs, computes diff summary + both snapshot refs), `timeline_summary` (no snapshot IDs, full timeline excerpt), `governance_review` (no snapshot IDs, latest snapshot ref + governance summary).

### Report model

| Field | Type | Notes |
|---|---|---|
| `reportId` | `string` (16-char hex) | Generated by `randomBytes(8).toString("hex")` |
| `createdAt` | `string` (ISO) | Fixed at creation — immutable |
| `reportType` | `AuditReportType` | `snapshot_comparison` \| `timeline_summary` \| `governance_review` |
| `snapshotRefs` | `AuditSnapshotRef[]` | 0, 1, or 2 entries depending on report type |
| `diffSummary` | `AuditDiffSummary \| null` | Non-null only for `snapshot_comparison` |
| `timelineExcerpt` | `AuditTimelineExcerpt` | Always present — up to 20 recent events + type counts |
| `diagnosticsHealth` | `AuditDiagnosticsHealth` | Always present — captured at report creation time |
| `governanceSummary` | `AuditGovernanceSummary` | Always present — captured at report creation time |
| `note` | `string` | Human-readable description of the report |
| `executionBlocked` | `true` | Typed literal constant |

### Endpoints

| Method | Route | Purpose |
|---|---|---|
| `POST` | `/api/workspace/audit/report` | Create audit report |
| `GET` | `/api/workspace/audit/reports` | List all reports, newest-first |
| `GET` | `/api/workspace/audit/reports/:reportId` | Get full report by ID |

### Import constraints

- `workspaceAuditReport.ts` is the **terminal node** in the workspace-layer import graph. It imports from all four workspace modules but is never imported by them.
- Never import `diagnostics.ts` from `workspaceAuditReport.ts` — use `getWorkspaceHealth()` from `workspaceShell.ts` for workspace-scoped registry health.
- `initWorkspaceAuditReports()` must follow `initWorkspaceSnapshots()` in `runtime.ts` init order.

### Counters

- Endpoint count: 83 → 86
- Policy count: 83 → 86
- Health checks: 37 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

---

## Phase 114 — Governance Scorecard History Capture

**Completed.** Two new endpoints under `/api/workspace/governance/scorecard/`.

### Design goals

1. **Point-in-time governance tracking** — operators can capture a governance scorecard snapshot at any time and compare scores over time without enabling execution, workers, or any autonomous behavior.
2. **Validation integrity preserved** — all Phase 112 `validation_integrity` fields (`validationIntegrityScore`, `validationIntegrityWeight`, `widgetRegistryHealthy`, `widgetContractViolations`) are stored in the snapshot and surfaced in the summary list projection.
3. **Summary-only list projection** — the history list endpoint never exposes the full `breakdown[]`, `recommendations[]`, or `signals` internals. Only the 9 key signal fields are returned per list item.
4. **Bounded retention** — max 10 snapshots in the ring buffer. Oldest is pruned on overflow. Snapshots survive server restarts via the `workspace-governance-scorecard-history` persistent store key.
5. **Zero-execution contract** — `executionBlocked: true` is a typed literal constant on every response type.

### Persistence model

| Field | Value |
|---|---|
| Store key | `workspace-governance-scorecard-history` |
| Max retained | 10 |
| Ring overflow | Oldest (lowest captureSeq) pruned first |
| Atomic write | `writeStore` called after every capture |
| Load-on-boot | `readStore` in `initWorkspaceGovernanceScorecardHistory()` |
| CaptureSeq resume | `Math.max(...ring.map(e => e.captureSeq)) + 1` on boot |
| Malformed entry handling | `isValidEntry()` guard drops structurally invalid entries with `logger.warn` |
| Flush failure | `try/catch` — ring preserved in memory, error logged, no crash |

### Types

| Type | Fields |
|---|---|
| `ScorecardHistoryEntry` | captureSeq, createdAt, scorecardId, snapshot (full WorkspaceGovernanceScorecard), executionBlocked |
| `ScorecardHistoryCaptureResult` (201) | captureSeq, createdAt, scorecardId, governanceScore, governanceGrade, validationIntegrityScore, validationIntegrityWeight, widgetRegistryHealthy, widgetContractViolations, ringSize, executionBlocked |
| `ScorecardHistoryListItem` | captureSeq, createdAt, scorecardId, governanceScore, governanceGrade, validationIntegrityScore, validationIntegrityWeight, widgetRegistryHealthy, widgetContractViolations, executionBlocked |
| `ScorecardHistoryListResult` | entries[], total, maxRetained=10, storeKey, executionBlocked |

### Endpoints

| Method | Route | Purpose |
|---|---|---|
| `POST` | `/api/workspace/governance/scorecard/capture` | Capture governance scorecard snapshot |
| `GET` | `/api/workspace/governance/scorecard/history` | List all captured snapshots, newest-first |

### Import constraints

- `workspaceGovernanceScorecardHistory.ts` imports `getWorkspaceGovernanceScorecard` from `./workspaceGovernanceScorecard`. No reverse import permitted — `workspaceGovernanceScorecard.ts` must never import from `workspaceGovernanceScorecardHistory.ts`.
- `initWorkspaceGovernanceScorecardHistory()` is called from `runtime.ts` after `initWorkspaceWidgetValidationHistory()` and before `initRuntimeDependencyGraph()`.
- The subsystem name `workspace_governance_scorecard_history` appears in logger.info only — consistent with Phase 98/104 history module pattern. No `registerSubsystemState()` call; subsystem count stays at 27.

### Counters

- Endpoint count: 106 → 108
- Policy count: 106 → 108
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

---

## Phase 115 — Governance Scorecard History Analytics

**Completed.** One new endpoint: `GET /api/workspace/governance/scorecard/analytics`.

### Design goals

1. **Longitudinal governance visibility** — operators can observe how governance scores, grades, and validation integrity have evolved across all retained captures without triggering any execution, mutation, or recomputation.
2. **No live recomputation** — analytics reads exclusively from the in-memory history ring via `getRawScorecardHistoryEntries()`. `getWorkspaceGovernanceScorecard()` is never called from the analytics module.
3. **Consistent pattern with Phase 111** — mirrors the structure of `workspaceObservationLedgerAnalytics.ts`: same summary/transitions/series layout, same trend derivation rule (oldest vs newest comparison), same consecutive-pair transition counting.
4. **Zero-execution contract** — `executionBlocked: true` is a typed literal constant on every response type and every series point.
5. **Bounded complexity** — O(n) single pass over max-10 ring entries.

### Analytics derivation rules

| Field | Derivation |
|---|---|
| `averageGovernanceScore` | Mean of all scores, `round1()` (1 decimal place) |
| `highestGovernanceScore` | `Math.max(...scores)` — null if ring empty |
| `lowestGovernanceScore` | `Math.min(...scores)` — null if ring empty |
| `currentGovernanceGrade` | Newest entry's grade (highest captureSeq) — null if ring empty |
| `bestValidationIntegrityScore` | `Math.max(...viScores)` — null if ring empty |
| `worstValidationIntegrityScore` | `Math.min(...viScores)` — null if ring empty |
| `latestCaptureSeq` | `Math.max(...seqs)` — null if ring empty |
| `governanceTrendDirection` | Compare `scores[oldest]` vs `scores[newest]`; null if <2 entries |
| `validationTrendDirection` | Compare `viScores[oldest]` vs `viScores[newest]`; null if <2 entries |
| `governanceGradeChanges` | Count consecutive pairs where `grades[i] !== grades[i-1]` |
| `validationIntegrityChanges` | Count consecutive pairs where `viScores[i] !== viScores[i-1]` |
| `improvementCount` | Count consecutive pairs where `scores[i] > scores[i-1]` |
| `degradationCount` | Count consecutive pairs where `scores[i] < scores[i-1]` |

### Types

| Type | Fields |
|---|---|
| `ScorecardTrendDirection` | `"improving" \| "stable" \| "degrading" \| null` |
| `ScorecardAnalyticsSummary` | totalSnapshotsAnalyzed, averageGovernanceScore, highestGovernanceScore, lowestGovernanceScore, currentGovernanceGrade, bestValidationIntegrityScore, worstValidationIntegrityScore, governanceTrendDirection, validationTrendDirection, latestCaptureSeq, executionBlocked |
| `ScorecardAnalyticsTransitions` | governanceGradeChanges, validationIntegrityChanges, improvementCount, degradationCount, executionBlocked |
| `ScorecardAnalyticsHistoryPoint` | captureSeq, createdAt, governanceScore, governanceGrade, validationIntegrityScore, widgetRegistryHealthy, executionBlocked |
| `WorkspaceGovernanceScorecardAnalytics` | analyticsId, generatedAt, summary, transitions, series[], snapshotsInRing, executionBlocked |

### History module change

`getRawScorecardHistoryEntries(): ScorecardHistoryEntry[]` added to `workspaceGovernanceScorecardHistory.ts` — returns a shallow copy of the in-memory ring. Same pattern as `getRawHistoryEntries()` in `workspaceObservationLedgerHistory.ts`.

### Import chain

`workspaceGovernanceScorecardAnalytics` → `workspaceGovernanceScorecardHistory` → `workspaceGovernanceScorecard`

No circular imports. `workspaceGovernanceScorecardAnalytics` is a pure terminal analytics leaf — nothing imports it except the route handler.

### Counters

- Endpoint count: 108 → 109
- Policy count: 108 → 109
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

---

## Phase 116 — Scorecard Analytics Dimension Breakdown

**Completed.** Additive extension of `GET /api/workspace/governance/scorecard/analytics` — no new endpoint, no new policy, no new subsystem.

### Design goals

1. **Per-dimension longitudinal visibility** — operators can inspect how each of the 6 governance dimensions has performed across all retained scorecard captures, without enabling any execution, persistence mutation, or live recomputation.
2. **Consistent rounding invariant** — `averageWeightedScore`, `minimumWeightedScore`, and `maximumWeightedScore` all use `round1()` (1 decimal place), ensuring `max ≥ avg ≥ min` always holds even when raw floating-point values would violate this due to rounding asymmetry.
3. **Alphabetical determinism** — the 6 dimension keys are emitted in a fixed canonical order regardless of how `snapshot.breakdown[]` is ordered within each stored entry.
4. **Defensive backward compatibility** — if a stored entry's `breakdown[]` does not contain a given dimension key (e.g. pre-Phase-112 entries missing `validation_integrity`), that entry is silently skipped for that dimension. `snapshotsAnalyzed` reflects only the count of entries that actually contributed data.

### Canonical dimension keys (alphabetical)

```
audit_report_coverage
capacity_utilization
member_project_ratio
quota_adoption
snapshot_availability
validation_integrity
```

### DimensionBreakdownEntry fields

| Field | Type | Notes |
|---|---|---|
| `dimensionKey` | `DimensionKey` | One of the 6 canonical keys |
| `averageWeightedScore` | `number` | Mean of all contributed weighted scores, `round1()` |
| `minimumWeightedScore` | `number \| null` | `round1(Math.min(...))` — null if ring empty |
| `maximumWeightedScore` | `number \| null` | `round1(Math.max(...))` — null if ring empty |
| `currentWeightedScore` | `number \| null` | Raw value from newest entry's `breakdown[]` — null if ring empty or key missing |
| `trendDirection` | `ScorecardTrendDirection` | oldest vs newest `weightedScore`; null if <2 contributing entries |
| `snapshotsAnalyzed` | `number` | Count of ring entries that contained this dimension key |
| `executionBlocked` | `true` | Typed literal constant |

### Sourcing

Data flows: `snapshot.breakdown[]` on each `ScorecardHistoryEntry` → collected per dimension key → aggregated. No calls to `getWorkspaceGovernanceScorecard()` or any other live module. No I/O. Pure in-memory computation over max-10 ring entries.

### Files changed

- `core/workspaceGovernanceScorecardAnalytics.ts` — `DimensionBreakdownEntry` type added; `DIMENSION_KEYS` constant added; `dimensionBreakdown` derivation block added at end of `getWorkspaceGovernanceScorecardAnalytics()`; `WorkspaceGovernanceScorecardAnalytics` interface extended with `dimensionBreakdown: DimensionBreakdownEntry[]`

### Counters

- Endpoint count: 109 (unchanged)
- Policy count: 109 (unchanged)
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

---

## Phase 117 — Governance Scorecard History Detail Endpoint

**Completed.** Adds `GET /api/workspace/governance/scorecard/history/:captureSeq` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks.

### Design goals

1. **Full snapshot drill-down** — operators can retrieve the complete stored `WorkspaceGovernanceScorecard` for any captureSeq retained in the ring, including `breakdown[]`, `recommendations[]`, and all `signals` fields. The list endpoint provides a summary projection; this endpoint provides the full detail.
2. **Strict 404 semantics** — the endpoint returns 404 for (a) captureSeq not found in the ring (pruned or never captured) and (b) malformed captureSeq (non-integer, ≤0, float, non-numeric string). There is no 400 — all input errors yield 404 to match the existing parametric endpoint convention in this codebase.
3. **Zero live recomputation** — the handler calls `getGovernanceScorecardHistoryDetail()` which performs an O(10) `Array.find()` on the in-memory ring. No call to `getWorkspaceGovernanceScorecard()` or any other live computation module.
4. **No persistence mutation** — the ring is read-only from this handler's perspective. `flush()` is never called. `nextCaptureSeq` is never incremented.

### Response type

```
ScorecardHistoryDetailResult {
  captureSeq:       number                      // matches requested path param
  createdAt:        string                      // ISO timestamp from capture time
  scorecardId:      string                      // 16-char hex
  scorecardSnapshot: WorkspaceGovernanceScorecard {
    scorecardId:      string
    generatedAt:      string
    governanceScore:  number (0–100)
    governanceGrade:  GovernanceGrade (A/B/C/D/F)
    breakdown:        ScorecardCategory[]       // 6 dimensions incl. validation_integrity
    recommendations:  string[]                  // max 5 advisory strings
    signals:          ScorecardSignals          // 12 fields (8 original + 4 Phase-112)
    executionBlocked: true
  }
  executionBlocked: true
}
```

### 404 rejection rules

| Input | Rejection reason |
|---|---|
| `abc` | `isNaN(parseInt("abc"))` → true |
| `1.5` | `String(parseInt("1.5", 10)) !== "1.5"` → `"1" !== "1.5"` |
| `0` | `captureSeq <= 0` → true |
| `-1` | `captureSeq <= 0` → true |
| `9999999` | `historyRing.find()` returns `undefined` → null → 404 |

### Router dispatch

The router resolves exact paths before parametric paths (two-pass: exact first, then `:param` pattern). `GET /api/workspace/governance/scorecard/history` (exact) and `GET /api/workspace/governance/scorecard/history/:captureSeq` (parametric) are distinct routes and never conflict.

### Files changed

- `core/workspaceGovernanceScorecardHistory.ts` — `ScorecardHistoryDetailResult` interface added; `getGovernanceScorecardHistoryDetail(captureSeq: number): ScorecardHistoryDetailResult | null` added (O(10) `Array.find()` on in-memory ring, no I/O, no flush)
- `routes/workspace.ts` — `getGovernanceScorecardHistoryDetail` imported; `handleScorecardHistoryDetail` handler added (rawSeq parse + validation + 404 branches)
- `server.ts` — `handleScorecardHistoryDetail` imported; `router.get("/api/workspace/governance/scorecard/history/:captureSeq", handleScorecardHistoryDetail)` registered between list and analytics routes
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/governance/scorecard/history/:captureSeq`

### Counters

- Endpoint count: 109 → **110**
- Policy count: 109 → **110**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

---

## Phase 118 — Observation Ledger History Detail Endpoint

**Completed.** Adds `GET /api/workspace/observation/ledger/history/:captureSeq` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks.

### Design goals

1. **Full ledger drill-down** — operators can retrieve the complete stored `WorkspaceObservationLedger` for any captureSeq retained in the ring (max 20), including summary, governance, exposure, observationCoverage, probes, validationProbe, and trendDirection. The list endpoint provides a summary projection; this endpoint provides the full detail.
2. **Exact mirror of Phase 117 pattern** — same handler structure, same 404 rejection rules, same `Array.find()` lookup, applied to the ledger ring (max 20) instead of the scorecard ring (max 10).
3. **Zero live recomputation** — no call to `getWorkspaceObservationLedger()` or any other live module. The stored `entry.snapshot` is returned directly.
4. **No persistence mutation** — the ring is read-only from this handler's perspective.

### Response type

```
LedgerHistoryDetailResult {
  captureSeq:     number                       // matches requested path param
  createdAt:      string                       // ISO timestamp from capture time
  ledgerId:       string                       // 16-char hex
  ledgerSnapshot: WorkspaceObservationLedger {
    ledgerId:     string
    generatedAt:  string
    summary {
      overallObservationHealth  ObservationHealth
      governanceReadiness       GovernanceGrade
      observationCoverage       number
      exposureRiskLevel         ExposureRiskLevel
      trendDirection            string
      ...
    }
    governance     object
    exposure       object
    probes         object
    validationProbe {
      validationHealth      ValidationHealth
      widgetCoveragePercent number
      ...
    }
    executionBlocked: true
  }
  executionBlocked: true
}
```

### Files changed

- `core/workspaceObservationLedgerHistory.ts` — `LedgerHistoryDetailResult` interface added; `getObservationLedgerHistoryDetail(captureSeq: number): LedgerHistoryDetailResult | null` added (O(20) `Array.find()` on in-memory ring, no I/O, no flush)
- `routes/workspace.ts` — `getObservationLedgerHistoryDetail` imported; `handleLedgerHistoryDetail` handler added (rawSeq parse + validation + 404 branches)
- `server.ts` — `handleLedgerHistoryDetail` imported; `router.get("/api/workspace/observation/ledger/history/:captureSeq", handleLedgerHistoryDetail)` registered between list and analytics routes
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/observation/ledger/history/:captureSeq`

### Counters

- Endpoint count: 110 → **111**
- Policy count: 110 → **111**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

---

## Phase 119 — Phase Archive Compaction IV (Phases 110–118)

**COMPLETE.** Documentation-only. Phases 110–118 moved from `replit.md` session checkpoint into `PHASE_ARCHIVE.md`. 0 new endpoints / policies / health checks / subsystems / graph nodes. Archive footer updated to Phase 119. `replit.md` compacted to 5 active rows (Phases 119+).

---

## Phase 120 — Scorecard Comparison Endpoint

**Completed.** Adds `GET /api/workspace/governance/scorecard/history/compare?from=:captureSeq&to=:captureSeq` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks. New module `core/workspaceGovernanceScorecardComparison.ts`.

### Design goals

1. **Point-in-time governance diff** — operators can compare any two retained scorecard snapshots by captureSeq. Both must exist in the current ring (max 10). The response is deterministic and fully derived from stored data.
2. **Query-param routing, not path-param** — `?from=:captureSeq&to=:captureSeq` avoids ambiguity with the existing `/:captureSeq` detail route. The compare route is registered as an exact path (`/history/compare`) before the parametric route (`/history/:captureSeq`), so the router pass-1 exact match always wins.
3. **Same-entry comparison is valid** — `from=N&to=N` returns a stable identity result (all deltas = 0, all trendDirections = stable). No special-case needed.
4. **Consistent rounding** — all numeric deltas use `round1()` (one decimal place) matching the analytics module convention.
5. **400 vs 404 separation** — 400 for malformed query params (wrong type, missing, ≤0, float, string); 404 for structurally valid captureSeqs that are not in the ring.

### Response type

```
ScorecardComparisonResult {
  fromCaptureSeq:              number
  toCaptureSeq:                number
  fromCreatedAt:               string   // ISO from stored entry
  toCreatedAt:                 string   // ISO from stored entry
  fromGovernanceScore:         number
  toGovernanceScore:           number
  governanceScoreDelta:        number   // round1(to - from)
  fromGovernanceGrade:         GovernanceGrade
  toGovernanceGrade:           GovernanceGrade
  governanceGradeChange:       ImprovementDirection  // grade-index-based
  fromValidationIntegrityScore: number
  toValidationIntegrityScore:  number
  validationIntegrityDelta:    number   // round1(to - from)
  improvementDirection:        ImprovementDirection  // based on governanceScoreDelta
  dimensionDeltas:             DimensionDelta[6]     // alphabetically sorted
  executionBlocked:            true

  DimensionDelta {
    dimensionKey:       "audit_report_coverage" | "capacity_utilization" |
                        "member_project_ratio"  | "quota_adoption" |
                        "snapshot_availability" | "validation_integrity"
    fromWeightedScore:  number   // round1(breakdown[key].weightedScore in fromSnap)
    toWeightedScore:    number   // round1(breakdown[key].weightedScore in toSnap)
    weightedScoreDelta: number   // round1(to - from)
    trendDirection:     "improving" | "stable" | "degrading"
    executionBlocked:   true
  }
}

ImprovementDirection = "improved" | "unchanged" | "degraded"
  - For governanceGradeChange: lower grade index (A=0, F=4) = better grade
    so A→B = degraded, B→A = improved
  - For improvementDirection: based on governanceScoreDelta sign
```

### Files changed

- `core/workspaceGovernanceScorecardComparison.ts` — new module: `DimensionDelta`, `ScorecardComparisonResult`, `ScorecardComparisonNotFound`, `ComparisonTrendDirection`, `ImprovementDirection` types; `compareGovernanceScorecards(fromSeq, toSeq)` function; `round1()`, `gradeIndex()`, `trendFromDelta()`, `improvementFromDelta()`, `gradeChangeDelta()` internal helpers; imports only from `workspaceGovernanceScorecardHistory` and `workspaceGovernanceScorecard` (type-only)
- `routes/workspace.ts` — `compareGovernanceScorecards` imported; `handleScorecardHistoryCompare` handler added (URLSearchParams query parsing, `from`/`to` validation, 400/404 branches)
- `server.ts` — `handleScorecardHistoryCompare` imported; `router.get("/api/workspace/governance/scorecard/history/compare", ...)` registered between list and `:captureSeq` routes
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/governance/scorecard/history/compare`

### Counters

- Endpoint count: 111 → **112**
- Policy count: 111 → **112**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

---

## Phase 121 — Observation Ledger Comparison Endpoint

**Completed.** Adds `GET /api/workspace/observation/ledger/history/compare?from=:captureSeq&to=:captureSeq` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks. New module `core/workspaceObservationLedgerComparison.ts`.

### Design goals

1. **Point-in-time operational diff** — operators can compare any two retained ledger snapshots by captureSeq. Both must exist in the current ring (max 20). Response is fully deterministic and derived from stored data only.
2. **Four structured sub-deltas** — response is organized into `governanceDelta`, `validationDelta`, `exposureDelta`, and `trendDelta` sections, each carrying their from/to values, a change label, and `executionBlocked: true`.
3. **Query-param routing** — `?from=:captureSeq&to=:captureSeq` avoids ambiguity with the existing `/:captureSeq` detail route. The compare route is registered as an exact path before the parametric route.
4. **Ordered-index change labels** — all change fields use the same `changeFromOrderedIndex()` helper which maps an ordered quality ranking to `improved`/`unchanged`/`degraded`. Each domain has its own order: grades (A→F), validation health (healthy→failed), exposure risk (none→high), observation health (healthy→critical), trend direction (improving→null).
5. **`improvementDirection` based on coverage delta** — the top-level `improvementDirection` uses `observationCoverageDelta` sign as the primary driver, consistent with the ledger's primary metric.
6. **Backward-compat for pre-Phase-109 snapshots** — `extractValidationSignals()` degrades safely to `"failed"`/`0` when `validationProbe` is absent in older stored entries.

### Response type

```
LedgerComparisonResult {
  fromCaptureSeq:               number
  toCaptureSeq:                 number
  fromCreatedAt:                string     // ISO from stored entry
  toCreatedAt:                  string     // ISO from stored entry
  observationCoverageDelta:     number     // round1(to - from)
  governanceReadinessChange:    ComparisonChangeLabel
  validationHealthChange:       ComparisonChangeLabel
  widgetCoveragePercentDelta:   number     // round1(to - from)
  overallObservationHealthChange: ComparisonChangeLabel
  improvementDirection:         ImprovementDirection  // based on observationCoverageDelta
  governanceDelta:              GovernanceDelta
  validationDelta:              ValidationDelta
  exposureDelta:                ExposureDelta
  trendDelta:                   TrendDelta
  executionBlocked:             true

  GovernanceDelta {
    fromGovernanceReadiness:    GovernanceGrade
    toGovernanceReadiness:      GovernanceGrade
    governanceReadinessChange:  ComparisonChangeLabel  // grade-index-based: A=0 best, F=4 worst
    executionBlocked:           true
  }

  ValidationDelta {
    fromValidationHealth:       ValidationHealth
    toValidationHealth:         ValidationHealth
    validationHealthChange:     ComparisonChangeLabel  // health-index-based: healthy=0 best, failed=2 worst
    widgetCoveragePercentDelta: number                 // round1(to - from)
    executionBlocked:           true
  }

  ExposureDelta {
    fromExposureRisk:           ExposureRiskLevel
    toExposureRisk:             ExposureRiskLevel
    exposureRiskChange:         ComparisonChangeLabel  // risk-index-based: none=0 best, high=3 worst
    executionBlocked:           true
  }

  TrendDelta {
    fromTrendDirection:         TrendDirection | null
    toTrendDirection:           TrendDirection | null
    trendDirectionChange:       ComparisonChangeLabel  // trend-index-based: improving=0 best, null=3
    executionBlocked:           true
  }
}

ComparisonChangeLabel / ImprovementDirection = "improved" | "unchanged" | "degraded"
```

### Files changed

- `core/workspaceObservationLedgerComparison.ts` — new module: `ImprovementDirection`, `ComparisonChangeLabel`, `GovernanceDelta`, `ValidationDelta`, `ExposureDelta`, `TrendDelta`, `LedgerComparisonResult`, `LedgerComparisonNotFound` types; `compareObservationLedgerSnapshots(fromSeq, toSeq)` function; ordering tables (`GRADE_ORDER`, `RISK_ORDER`, `VALIDATION_HEALTH_ORDER`, `OBSERVATION_HEALTH_ORDER`, `TREND_DIRECTION_ORDER`); helpers `round1()`, `changeFromOrderedIndex()`, `gradeChange()`, `validationHealthChange()`, `exposureRiskChange()`, `observationHealthChange()`, `trendDirectionChange()`, `improvementFromCoverageDelta()`, `extractValidationSignals()`; imports from `workspaceObservationLedgerHistory` (runtime) and `workspaceObservationLedger`, `workspaceGovernanceScorecard`, `workspaceCoverageTrend` (type-only)
- `routes/workspace.ts` — `compareObservationLedgerSnapshots` imported; `handleLedgerHistoryCompare` handler added (URLSearchParams query parsing, from/to validation, 400/404 branches)
- `server.ts` — `handleLedgerHistoryCompare` imported; `router.get("/api/workspace/observation/ledger/history/compare", ...)` registered between history-list and history-detail routes
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/observation/ledger/history/compare`

### Counters

- Endpoint count: 112 → **113**
- Policy count: 112 → **113**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 123 — Dual Comparison Gateway

**Completed.** Adds `GET /api/workspace/comparison/dual?scorecardFrom=:s&scorecardTo=:s&ledgerFrom=:l&ledgerTo=:l` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceDualComparisonGateway.ts`.

### Design decisions

1. **Both comparisons always attempted before returning an error** — `getDualComparison()` calls `compareGovernanceScorecards()` and `compareObservationLedgerSnapshots()` sequentially before inspecting either result. This makes the error response maximally informative: when both fail the caller sees `both_not_found` with all four bad captureSeqs, rather than only the first failure.

2. **Three-way error discrimination** — `scorecard_not_found` (scorecard captureSeqs absent, ledger valid), `ledger_not_found` (ledger captureSeqs absent, scorecard valid), `both_not_found` (all captureSeqs absent). Each branch includes all relevant captureSeqs so the caller never has to guess which ring was missing which entry.

3. **Zero delta logic duplication** — `workspaceDualComparisonGateway.ts` contains no comparison arithmetic. All derivation is performed inside the existing comparison modules. The gateway is a pure delegation + shape-assembly layer.

4. **Bounded lookups: O(10)×2 + O(20)×2** — scorecard ring cap 10, ledger ring cap 20. Total ceiling: 60 Array.find() iterations per request.

5. **`generatedAt` stamped at assembly time** — only set after both sub-comparisons succeed, so the timestamp accurately reflects when the aggregated result was assembled.

6. **No new ring state, no new persistence** — the gateway module imports only from the two comparison modules. No new storage key, no new ring buffer, no init registration, no health check.

### Files changed

- `core/workspaceDualComparisonGateway.ts` — new module: `DualComparisonResult`, `DualComparisonError` (discriminated union: `scorecard_not_found` | `ledger_not_found` | `both_not_found`) types; `getDualComparison(scorecardFrom, scorecardTo, ledgerFrom, ledgerTo)` public function; imports from `workspaceGovernanceScorecardComparison` and `workspaceObservationLedgerComparison` only
- `routes/workspace.ts` — `getDualComparison` imported; `handleDualComparison` handler added (URLSearchParams query parsing; strict positive-integer validation for all 4 params; 400 with named-param error message; 404 with three-way discrimination; 200 on success)
- `server.ts` — `handleDualComparison` imported; `router.get("/api/workspace/comparison/dual", ...)` registered
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/comparison/dual` (inserted before scorecard history compare policy; policy 148 of 114)

### Counters

- Endpoint count: 113 → **114**
- Policy count: 113 → **114**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 124 — Comparison Registry Endpoint

**Completed.** Adds `GET /api/workspace/comparison/registry` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceComparisonRegistry.ts`.

### Design decisions

1. **Purely static module** — `getComparisonRegistry()` contains no runtime reads, no ring lookups, no persistence access. The entire `COMPARISON_ENDPOINTS` array is a compile-time constant. The only non-deterministic field is `generatedAt`, stamped at call time.

2. **Canonical alphabetical route ordering** — entries are ordered by route string: `/api/workspace/comparison/dual` → `/api/workspace/governance/scorecard/history/compare` → `/api/workspace/observation/ledger/history/compare`. This ordering is stable across restarts and never changes without a code edit.

3. **No runtime endpoint scanning** — the registry does not inspect `server.ts`, the router table, or any live data structure. It is a hand-authored, type-safe description of the three comparison endpoints. This avoids coupling to server internals and keeps the module rollback-safe.

4. **`ringCapacity` type is `number | string`** — scorecard (10) and ledger (20) use numbers matching their ring `MAX_ENTRIES` constants. The dual gateway spans two rings so its capacity is the composite string `"scorecard=10,ledger=20"`. Do not attempt to unify these into a single numeric type.

5. **`executionBlocked: true` at every level** — top-level result (1), each `ComparisonRegistryEntry` (3), and each `ComparisonQueryParam` (8 total: 4+2+2). Total: 12 occurrences per response. This mirrors the invariant held throughout all comparison modules.

6. **`registryVersion` is a fixed string literal `"1"`** — typed as `typeof REGISTRY_VERSION` (const assertion), not `string`. A future breaking schema change would increment this to `"2"`. Do not widen the type to `string`.

### Files changed

- `core/workspaceComparisonRegistry.ts` — new module: `ComparisonType`, `RingType`, `ComparisonQueryParam`, `ComparisonRegistryEntry`, `ComparisonRegistryResult` types; static `COMPARISON_ENDPOINTS` constant (3 entries); `getComparisonRegistry()` public function; no imports from other workspace modules
- `routes/workspace.ts` — `getComparisonRegistry` imported; `handleComparisonRegistry` handler added (no params needed — passes straight through to `getComparisonRegistry()`)
- `server.ts` — `handleComparisonRegistry` imported; `router.get("/api/workspace/comparison/registry", ...)` registered
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/comparison/registry` (inserted before dual comparison policy; policy 148 of 115)

### Counters

- Endpoint count: 114 → **115**
- Policy count: 114 → **115**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 126 — Governance Drift Detector

**Completed.** Adds `GET /api/workspace/governance/drift` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceGovernanceDriftDetector.ts`.

### Design decisions

1. **Consecutive-pair scan only** — drift is detected by comparing each adjacent (i, i+1) pair after sorting the ring ascending by captureSeq. This preserves chronological signal while keeping the scan O(N-1) bounded. Non-adjacent pairs are intentionally excluded — they would reflect compound change, not a single-step regression event.

2. **Worst-pair reporting** — `worstScoreDrop` / `worstCoverageDrop` is the maximum drop found across all scanned pairs. `fromCaptureSeq`/`toCaptureSeq` identifies the specific pair where the worst drop occurred. This gives the caller actionable targeting information without requiring a full scan result.

3. **Zero sentinel when no drift** — when `driftDetected: false`, `fromCaptureSeq` and `toCaptureSeq` are both 0, and `governanceGradeChange`/`observationHealthChange` are "unchanged". This prevents ambiguous null/undefined handling on the caller side while clearly signalling "no event to point at".

4. **Graceful < 2 entries handling** — when either ring has fewer than 2 captures, the corresponding drift sub-result returns the zero sentinel immediately, without attempting any scan. This means the endpoint is always safe to call from boot, even before any captures have been made.

5. **Risk level derivation** — `high` if both sub-scans trigger; `medium` if exactly one triggers with a severe magnitude (score drop ≥ 10 or coverage drop ≥ 20); `low` if exactly one triggers at the minimum threshold; `none` if neither triggers. Thresholds: scorecard drift ≥ 5, ledger drift ≥ 10.

6. **No query params, no 400/404 branches** — the handler is a zero-branch pass-through identical to the registry handler. Drift detection is always a snapshot of current ring state; callers never need to specify a window.

7. **`round1()` local to the module** — consistent with Phase 120–121 convention. Each module owns its own trivial rounding helper.

### Files changed

- `core/workspaceGovernanceDriftDetector.ts` — new module: `RiskLevel`, `ChangeLabel`, `ScorecardDriftResult`, `LedgerDriftResult`, `GovernanceDriftResult` types; `SCORECARD_DRIFT_THRESHOLD=5`, `LEDGER_DRIFT_THRESHOLD=10`, `SCORECARD_SEVERE_THRESHOLD=10`, `LEDGER_SEVERE_THRESHOLD=20`; `scanScorecardDrift()`, `scanLedgerDrift()`, `deriveRiskLevel()` internal functions; `getGovernanceDrift()` public API; imports from `workspaceGovernanceScorecardHistory` and `workspaceObservationLedgerHistory` (runtime) + `workspaceGovernanceScorecard` and `workspaceObservationLedger` (type-only)
- `routes/workspace.ts` — `getGovernanceDrift` imported; `handleGovernanceDrift` handler added (zero-branch pass-through)
- `server.ts` — `handleGovernanceDrift` imported; `router.get("/api/workspace/governance/drift", ...)` registered before `/api/workspace/governance/scorecard`
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/governance/drift` (inserted before scorecard policy, alphabetically correct)

### Counters

- Endpoint count: 115 → **116**
- Policy count: 115 → **116**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 128 — Governance Drift History

**Completed.** Adds `POST /api/workspace/governance/drift/capture` and `GET /api/workspace/governance/drift/history` — 2 new endpoints, 2 new policies, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceGovernanceDriftHistory.ts`. Runtime init: `initWorkspaceGovernanceDriftHistory()` registered in `runtime.ts` after `initWorkspaceGovernanceScorecardHistory()`, before `initRuntimeDependencyGraph()`.

### Design decisions

1. **Summary-only list projection** — `DriftHistoryListItem` exposes only the 9 top-level scalar signals from each captured `GovernanceDriftResult` (`driftDetected`, `riskLevel`, `scorecardDriftDetected`, `ledgerDriftDetected`, `worstScoreDrop`, `worstCoverageDrop`, `captureSeq`, `createdAt`, `driftId`). The full `scorecardDrift` and `ledgerDrift` sub-objects are intentionally excluded from the list endpoint — callers needing per-capture internals can trigger a fresh capture via POST.

2. **Full snapshot stored internally** — each `DriftHistoryEntry` stores the complete `GovernanceDriftResult` snapshot for future analytics phases. It is not exposed through the current list endpoint but is available to any future module that imports `workspaceGovernanceDriftHistory.ts`.

3. **captureSeq monotonic across restarts** — on boot, `initWorkspaceGovernanceDriftHistory()` reads the max stored `captureSeq` and resumes `nextCaptureSeq = maxSeq + 1`. This is identical to the pattern used by `workspaceGovernanceScorecardHistory.ts` and `workspaceObservationLedgerHistory.ts`.

4. **driftId = 8-byte hex** — generated fresh on every capture via `node:crypto` `randomBytes(8).toString('hex')`. Provides a stable identifier for each capture event without requiring any external ID source.

5. **Ring pruned oldest-first** — `historyRing.shift()` when length > 10, consistent with all other history rings in the project. The `isValidEntry` guard on boot skips any entries with missing or wrong-typed fields without aborting the load.

6. **createdAt from drift.generatedAt** — the capture timestamp is taken from the `GovernanceDriftResult.generatedAt` field (set by `getGovernanceDrift()`) rather than generating a second `new Date()` call. This keeps the stored timestamp consistent with the drift result it describes.

7. **No new subsystem, no new health check** — the drift history ring is a persistence-layer extension of the existing drift detector. It does not warrant its own health check or subsystem entry, consistent with Phase 114–115 (scorecard and ledger history) which also added no new subsystems.

### Files changed

- `core/workspaceGovernanceDriftHistory.ts` — new module: `DriftHistoryEntry`, `DriftHistoryListItem`, `DriftHistoryCaptureResult`, `DriftHistoryListResult` types; `initWorkspaceGovernanceDriftHistory()`, `captureDriftSnapshot()`, `listDriftHistory()` public API; `flush()`, `isValidEntry()`, `createDriftId()` internal helpers; `STORE_KEY='workspace-governance-drift-history'`, `MAX_ENTRIES=10`; imports from `workspaceGovernanceDriftDetector` (runtime: `getGovernanceDrift`, types: `GovernanceDriftResult`, `RiskLevel`) and `node:crypto`
- `routes/workspace.ts` — `captureDriftSnapshot`, `listDriftHistory` imported; `handleDriftHistoryCapture`, `handleDriftHistory` handlers added
- `server.ts` — `handleDriftHistoryCapture`, `handleDriftHistory` imported; `router.post(...)` and `router.get(...)` registered between drift GET and scorecard GET
- `core/runtime.ts` — `initWorkspaceGovernanceDriftHistory` imported; `initWorkspaceGovernanceDriftHistory()` call added after `initWorkspaceGovernanceScorecardHistory()`
- `core/accessEnforcement.ts` — 2 new policies: POST write/operator for `/api/workspace/governance/drift/capture`; GET read/viewer for `/api/workspace/governance/drift/history`

### Storage

- New store key: `workspace-governance-drift-history` → `artifacts/api-server/storage/store/workspace-governance-drift-history.json`

### Counters

- Endpoint count: 116 → **118**
- Policy count: 116 → **118**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 129 — UI Rendering Foundation

**Completed.** Adds `GET /api/workspace/ui/render-model` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIRenderModel.ts`. No `init()` required — pure derivation from existing layers. No persistence, no subsystem registration, no health check.

### Design decisions

1. **Pure derivation, no live data** — `getUIRenderModel()` derives everything from two existing pure functions: `getAllWidgetContracts()` (37 full `WidgetContract` objects with `recommendedSize`, `refreshCategory`, `compactDataType`) and `getWorkspaceVisualShell()` (15 panels with widget lists). Neither function triggers I/O or network calls. Response is bounded: O(37) + O(15) scans.

2. **`getAllWidgetContracts()` used instead of `listWidgetContracts()`** — `listWidgetContracts()` returns `WidgetContractSummaryItem` which lacks `recommendedSize` and `refreshCategory`. `getAllWidgetContracts()` returns the full `WidgetContract` including all fields needed to derive `size` and `refreshMode` on each `UIWidget`.

3. **renderHint token mapping** — each `widgetType` maps to an opaque layout hint token (e.g. `gauge → gauge_ring`, `badge → status_badge`, `table → data_table`). These are string constants, not HTML, not CSS classes, not React component names. A future renderer may interpret them however it chooses.

4. **dataBindings sorted alphabetically by sourceEndpoint** — 37 widgets produce 18 unique `sourceEndpoint` values. The deduplication set iterates in insertion order (registry order), then the result is `.sort()` -ed alphabetically for deterministic output independent of contract registry ordering changes.

5. **executionBlocked: true at every level** — the render model contains 100+ `executionBlocked: true` occurrences. Every nested object (UIWidget, UIPage, UINavigationItem, UINavigationGroup, UINavigation, UIPanelSummary, UIThemeTokens, UIDataBinding, UIGovernanceBadge, UILayout, root WorkspaceUIRenderModel) carries the flag. `mutationAllowed: false` and `requiresApproval: false` are literal `false as const` on every `UIDataBinding`.

6. **No init, no subsystem, no health check** — the render model is a pure read-only derivation layer. It adds no state to the runtime, requires no boot-time initialization, and is not an independently monitored subsystem. This is consistent with `workspaceWidgetContracts.ts` and `workspaceDiff.ts` (no init required for pure aggregation/derivation modules).

7. **Five static pages** — overview, governance, observation, diagnostics, comparison. These are opaque page descriptors (pageId, title, route, sectionIds[], description, pageOrder, executionBlocked). No routing logic, no rendering, no action handlers. Routes are prefixed `/ui/` to namespace them cleanly away from API routes.

8. **Five navigation groups** — overview, governance, observation, diagnostics, audit — matching the `NavigationGroupId` union from `workspaceVisualShell.ts`. Each group carries a static `items[]` of `UINavigationItem` (itemId, title, route, itemOrder, executionBlocked). No active links, no click handlers, no event emission.

9. **Five governance badges** — static signal descriptors referencing live governance/health endpoints. Not live data — just metadata: badgeId, label, signalType, sourceEndpoint, refreshMode. A future UI layer fetches the actual signal values.

10. **Static theme tokens** — colorMode='dark', density='compact', cardRadius='4px', gridGap='16px', typographyScale='sm'. These are opaque design-system tokens, not CSS variables, not inline styles. Frozen at Phase 129. A future theming phase may make these configurable.

### Files changed

- `core/workspaceUIRenderModel.ts` — **NEW** 305-line module: 10 exported interfaces (`UILayout`, `UIPage`, `UINavigationItem`, `UINavigationGroup`, `UINavigation`, `UIWidget`, `UIPanelSummary`, `UIThemeTokens`, `UIDataBinding`, `UIGovernanceBadge`, `WorkspaceUIRenderModel`); static constants (`STATIC_LAYOUT`, `STATIC_PAGES`, `STATIC_NAVIGATION`, `STATIC_THEME_TOKENS`, `STATIC_GOVERNANCE_BADGES`); `RENDER_HINT` mapping record; `deriveWidgets()`, `derivePanels()`, `deriveDataBindings()` internal helpers; `getUIRenderModel()` public API; imports `getAllWidgetContracts` from `workspaceWidgetContracts`, `getWorkspaceVisualShell`+types from `workspaceVisualShell`
- `routes/workspace.ts` — `getUIRenderModel` imported; `handleUIRenderModel` handler added
- `server.ts` — `handleUIRenderModel` imported; `router.get("/api/workspace/ui/render-model", ...)` registered before visual-shell block
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/render-model`

### Render model topology (at Phase 129)

| Field | Count/Value |
|---|---|
| `uiVersion` | `"1"` |
| `layout` | appName=Bulldozer, shellType=operator_dashboard, sidebarEnabled=true, topbarEnabled=true, contentGrid=responsive |
| `pages` | 5 — overview, governance, observation, diagnostics, comparison |
| `navigation.groups` | 5 — overview, governance, observation, diagnostics, audit |
| `panels` | 15 (from visual shell) |
| `widgets` | 37 (from widget contract registry) |
| `dataBindings` | 18 unique sourceEndpoints, sorted alphabetically |
| `governanceBadges` | 5 |
| `executionBlocked:true` occurrences | 100+ |

### Counters

- Endpoint count: 118 → **119**
- Policy count: 118 → **119**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 130 — Dashboard Skeleton Foundation

**Completed.** Adds `GET /api/workspace/ui/dashboard-skeleton` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceDashboardSkeleton.ts`. No `init()` required — pure derivation from `getWorkspaceVisualShell()`. No persistence, no subsystem registration, no health check.

### Design decisions

1. **Pure derivation from `getWorkspaceVisualShell()`** — the skeleton calls `getWorkspaceVisualShell()` once per request to obtain the static panel list and navigation groups. It does not cache the shell result. `getWorkspaceVisualShell()` is purely static (O(1) construction, no I/O), so per-request cost is O(15) panels + O(37) widget construction. Total response is bounded at all times.

2. **`PANEL_PRIMARY_PAGE` static map** — each of the 15 visual shell panels has one authoritative primary page assignment. This map is the single source of truth for `PanelLayout.pageId` and `WidgetLayoutEntry.pageId`. Panels not in the map fall back to `"overview"`. The map is frozen as a `Readonly<Record<string, string>>` — no runtime mutation.

3. **Width/height tokens derived from `recommendedSize`** — `SIZE_WIDTH` maps small→col-1, medium→col-2, large→col-3, full→col-4. `SIZE_HEIGHT` maps small/medium→row-1, large/full→row-2. These are opaque grid-system tokens, not CSS values. No inline styles, no HTML attributes, no `px` units. A future renderer may interpret them as CSS grid column/row spans.

4. **`cardStyle` and `layoutDirection` section-keyed** — governance and observation panels use `"elevated"` cards with `"column"` layout (stacked). Diagnostics uses `"outlined"` cards with `"row"` layout (horizontal metrics). Projects and activity use `"flat"` cards. These mappings are captured in `SECTION_CARD_STYLE` and `SECTION_LAYOUT_DIRECTION` frozen records.

5. **`priority` derived from `widgetType`** — the `WIDGET_TYPE_PRIORITY` record assigns 1–9 priority values by widget type. Badges and status widgets are priority 1 (shown first within a panel); timelines are priority 9 (shown last). This gives renderers a default sort order for overflow/responsive scenarios without any JS logic.

6. **`renderDensity` derived from `recommendedSize`** — small widgets use `"compact"` density (less padding, tighter typography); medium/large use `"standard"`; full-width widgets use `"expanded"`. These are opaque density tokens — not CSS, not breakpoints.

7. **Five `pageLayouts` with cross-section panel assignment** — the overview page references panels from governance, observation, diagnostics, projects, and activity sections. Comparison page references governance + observation panels plus change-detection and audit-trail. Each panel can be referenced by multiple pages even though it has only one `PANEL_PRIMARY_PAGE` assignment.

8. **Sidebar navigation groups derived from visual shell** — `deriveSidebar()` maps each `DashboardNavigationGroup` from `getWorkspaceVisualShell()` to a `SidebarNavigationGroup`. This preserves group ordering, item ordering, and itemIds/endpoints without duplicating the static data.

9. **No `init()`, no subsystem, no health check** — consistent with Phase 129 (`workspaceUIRenderModel.ts`) and Phase 112 (`workspaceDiff.ts`). Pure aggregation/derivation modules do not require subsystem registration or health monitoring.

10. **`ResponsiveRules` with three typed breakpoints** — desktop (≥1280px, 4 columns, sidebar visible), tablet (≥768px, 2 columns, sidebar hidden), mobile (≥320px, 1 column, sidebar hidden). `collapseBehavior: "stack"` is the only collapse mode defined at this phase. `maxColumns: 4` matches the desktop column count.

### Files changed

- `core/workspaceDashboardSkeleton.ts` — **NEW** module: 13 exported interfaces (`DashboardShell`, `DashboardTopbar`, `SidebarNavigationItem`, `SidebarNavigationGroup`, `DashboardSidebar`, `LayoutRegion`, `LayoutRegions`, `PageLayout`, `PanelLayout`, `WidgetLayoutEntry`, `ResponsiveBreakpoint`, `ResponsiveRules`, `WorkspaceDashboardSkeleton`); 8 static derivation records (`PANEL_PRIMARY_PAGE`, `SIZE_WIDTH`, `SIZE_HEIGHT`, `WIDGET_TYPE_PRIORITY`, `SIZE_DENSITY`, `SECTION_CARD_STYLE`, `SECTION_LAYOUT_DIRECTION`); 5 static constants (`STATIC_SHELL`, `STATIC_TOPBAR`, `STATIC_LAYOUT_REGIONS`, `STATIC_RESPONSIVE_RULES`, `PAGE_LAYOUT_DEFS`); `deriveSidebar()`, `derivePageLayouts()`, `derivePanelLayouts()`, `deriveWidgetLayouts()` internal helpers; `getDashboardSkeleton()` public API; imports `getWorkspaceVisualShell` + types from `workspaceVisualShell`
- `routes/workspace.ts` — `getDashboardSkeleton` imported; `handleDashboardSkeleton` handler added
- `server.ts` — `handleDashboardSkeleton` imported; `router.get("/api/workspace/ui/dashboard-skeleton", ...)` registered after render-model route
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/dashboard-skeleton`

### Dashboard skeleton topology (at Phase 130)

| Field | Count/Value |
|---|---|
| `dashboardVersion` | `"1"` |
| `shell.shellType` | `"operator_dashboard"` |
| `shell.shellMode` | `"full"` |
| `sidebar.navigationGroups` | 5 (overview, governance, observation, audit, diagnostics) |
| `sidebar.defaultPage` | `"overview"` |
| `layoutRegions.regions` | 4 (header, sidebar, main, statusbar) |
| `pageLayouts` | 5 — overview/governance/observation/diagnostics/comparison |
| `panelLayouts` | 15 (one per visual shell panel) |
| `widgetLayouts` | 37 (one per widget across all panels) |
| `responsiveRules.maxColumns` | 4 |
| `executionBlocked:true` occurrences | 95+ |

### Counters

- Endpoint count: 119 → **120**
- Policy count: 119 → **120**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 131 — UI Layer Coherence Probe

**Completed.** Adds `GET /api/workspace/ui/coherence` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUICoherence.ts`. No `init()` required — pure cross-layer derivation from `getUIRenderModel()` + `getDashboardSkeleton()`. No persistence, no subsystem registration, no health check.

### Design decisions

1. **Pure cross-layer probe** — `getUICoherence()` calls `getUIRenderModel()` and `getDashboardSkeleton()` once each per request, builds four index structures (Set/Map), then runs four independent validation passes. Total cost is O(37) widget scan + O(15) panel scan + O(5) page scan + O(18) binding scan. Bounded and deterministic.

2. **Seven validation rules in four passes**:
   - `validateWidgets()` — (a) each skeleton `widgetId` must exist in render model `widgets`; (b) no duplicate `widgetId` in skeleton `widgetLayouts`. Produces `WidgetViolation[]`.
   - `validatePanels()` — (c) each skeleton `panelId` must exist in render model `panels`; (d) no duplicate `panelId` in skeleton `panelLayouts`. Produces `PanelViolation[]`.
   - `validatePages()` — (e) each skeleton `pageId` must exist in render model `pages`; (f) no duplicate `pageId` in skeleton `pageLayouts`. Produces `PageViolation[]`.
   - `validateBindingCoverage()` — (g) each `renderModel.dataBindings[].sourceEndpoint` must be reachable from ≥1 skeleton `widgetId` via the `rmWidgetEndpointMap` (widgetId→sourceEndpoint from render model widgets). Produces `BindingViolation[]`.

3. **`rmWidgetEndpointMap` is the binding bridge** — instead of reading raw sourceEndpoint values from the visual shell (which would introduce a third dependency), the module cross-references via the render model widget map. A binding is "covered" if any skeleton widgetId maps to that binding's sourceEndpoint through the render model. This is the most conservative coverage check: if a widgetId is in the skeleton but absent from the render model (already caught by rule a), it contributes no coverage.

4. **Alphabetical violation ordering** — all four violation arrays are sorted alphabetically by their primary key (`widgetId`, `panelId`, `pageId`, `sourceEndpoint`). This ensures fully deterministic response shape across calls, even if the underlying derivation order changes.

5. **Duplicate detection uses a local `Set<string>` per pass** — the `seen` set is created fresh per validation function call (not shared across passes). This prevents cross-contamination between widget/panel/page duplicate checks.

6. **`bindingCoverage.coveragePercent` is rounded to 2 decimal places** — computed as `Math.round((covered / total) * 10000) / 100`. If `totalBindings === 0`, `coveragePercent` is 100 by convention (no bindings = no gaps).

7. **Normal operation produces the clean state** — since both the render model and skeleton derive from the same underlying `workspaceVisualShell` data (same 37 widget IDs, same 15 panel IDs, same 5 page IDs), all violation arrays are empty and all boolean flags are `true` in normal operation. The probe is designed to detect regressions if one layer is modified without updating the other.

8. **No `init()`, no subsystem, no health check** — consistent with Phase 129 (`workspaceUIRenderModel`), Phase 130 (`workspaceDashboardSkeleton`), and Phase 112 (`workspaceDiff`). Pure aggregation modules do not require subsystem registration.

### Files changed

- `core/workspaceUICoherence.ts` — **NEW** module: 4 violation type aliases (`WidgetViolationType`, `PanelViolationType`, `PageViolationType`, `BindingViolationType`); 7 exported interfaces (`WidgetViolation`, `PanelViolation`, `PageViolation`, `BindingViolation`, `BindingCoverage`, `UICoherenceResult`); 4 validation helpers (`validateWidgets`, `validatePanels`, `validatePages`, `validateBindingCoverage`); `getUICoherence()` public API; imports `getUIRenderModel` + `getDashboardSkeleton`
- `routes/workspace.ts` — `getUICoherence` imported; `handleUICoherence` handler added
- `server.ts` — `handleUICoherence` imported; `router.get("/api/workspace/ui/coherence", ...)` registered before render-model and dashboard-skeleton routes
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/coherence`

### Coherence probe topology (at Phase 131)

| Validation pass | Rule | Count checked |
|---|---|---|
| Widget presence | skeleton widgetId ∈ renderModel.widgets | 37 |
| Widget duplicates | no duplicate widgetId in skeleton | 37 |
| Panel presence | skeleton panelId ∈ renderModel.panels | 15 |
| Panel duplicates | no duplicate panelId in skeleton | 15 |
| Page presence | skeleton pageId ∈ renderModel.pages | 5 |
| Page duplicates | no duplicate pageId in skeleton | 5 |
| Binding coverage | renderModel binding sourceEndpoint reachable from skeleton widget | 18 |

### Normal operation result (at Phase 131)

| Field | Value |
|---|---|
| `uiVersion` | `"1"` |
| `dashboardVersion` | `"1"` |
| `allWidgetsCoherent` | `true` |
| `allPanelsCoherent` | `true` |
| `allPagesCoherent` | `true` |
| `bindingCoverage.totalBindings` | `18` |
| `bindingCoverage.coveragePercent` | `100` |
| All violation arrays | empty |

### Counters

- Endpoint count: 120 → **121**
- Policy count: 120 → **121**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 132 — UI Layer Version Manifest

**Completed.** Adds `GET /api/workspace/ui/version` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUILayerVersionManifest.ts`. No `init()` required. No calls to `getUIRenderModel()`, `getDashboardSkeleton()`, or `getUICoherence()` at runtime. Pure static manifest — only `generatedAt` varies per call.

### Design decisions

1. **Zero runtime dependencies on other UI modules** — unlike Phases 129–131 which call each other, the version manifest is self-contained. `getUILayerVersionManifest()` constructs the response entirely from module-level constants. No cross-layer reads at request time. This makes it safe to call even before the other UI modules are fully initialized.

2. **`schemaHash` pre-computed at module load** — `createHash("sha256")` is called once per layer during module initialization, not per request. The three static descriptor strings (`DESCRIPTOR_RENDER_MODEL`, `DESCRIPTOR_DASHBOARD_SKELETON`, `DESCRIPTOR_COHERENCE_PROBE`) are `JSON.stringify({type, fields[], version})` objects. The hash is truncated to 16 chars of lowercase hex.

3. **Descriptor format is `{type, fields[], version}`** — each descriptor captures the top-level response type name, the ordered list of top-level field names, and the schema version string. This is a structural fingerprint, not a full schema hash. Changing any top-level field name, adding a field, removing a field, or bumping the version string will produce a different `schemaHash`, signaling a breaking change.

4. **`STATIC_LAYERS` is a frozen `readonly` array** — the three `UILayerEntry` objects are defined at module scope and sorted alphabetically by `layerId` (dashboard\_skeleton < ui\_coherence\_probe < ui\_render\_model). The array reference is exposed as `STATIC_LAYERS as UILayerEntry[]` in the response — no per-request array construction.

5. **`layerType` enum** — three values: `"render_model"`, `"skeleton"`, `"coherence_probe"`. Typed as `UILayerType` — a TypeScript union. Adding a new layer requires adding a new `UILayerType` value.

6. **`layerCount` equals `STATIC_LAYERS.length`** — not hard-coded to `3`. If a layer is added to `STATIC_LAYERS`, `layerCount` automatically updates.

7. **Policy insertion: alphabetically after `ui/render-model`, before `visual-shell`** — `ui/version` sorts after `ui/render-model` (v > r) and before `visual-shell` (v... < v...) in the policy table, consistent with the insertion convention used across Phases 129–131.

8. **No `init()`, no subsystem, no health check** — consistent with all three prior UI layer modules (Phases 129–131). Pure static modules do not require subsystem registration.

### Schema hashes frozen at Phase 132

| layerId | schemaHash (16-char hex) |
|---|---|
| `dashboard_skeleton` | `979a6fe961ac2167` |
| `ui_coherence_probe` | `d51208e68baf16fa` |
| `ui_render_model` | `236afc67af00e482` |

These values are stable unless the corresponding layer's top-level field list or schema version string changes.

### Files changed

- `core/workspaceUILayerVersionManifest.ts` — **NEW** module: `UILayerType` union; `UILayerEntry` and `UILayerVersionManifest` interfaces; `computeSchemaHash()` helper; 3 static descriptor constants; 3 pre-computed hash constants; `STATIC_LAYERS` readonly array (3 entries, alphabetical); `getUILayerVersionManifest()` public API; imports `createHash` from `node:crypto` only
- `routes/workspace.ts` — `getUILayerVersionManifest` imported; `handleUILayerVersion` handler added
- `server.ts` — `handleUILayerVersion` imported; `router.get("/api/workspace/ui/version", ...)` registered
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/version`

### Counters

- Endpoint count: 121 → **122**
- Policy count: 121 → **122**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 133 — UI Layer Summary

**Completed.** Adds `GET /api/workspace/ui/summary` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUILayerSummary.ts`. No `init()`. No persistence. No subsystem registration. Pure aggregation from four existing UI modules.

### Design decisions

1. **Aggregation-only — no duplicated logic** — `getUILayerSummary()` calls `getUIRenderModel()`, `getDashboardSkeleton()`, `getUICoherence()`, and `getUILayerVersionManifest()` once each per request. All counting (`totalWidgets`, `totalPanels`, `totalPages`, `totalBindings`) is derived directly from the live return values of those calls — not re-implemented from scratch. This means the summary automatically stays in sync with any future change to those modules without needing its own update.

2. **`schemaHashes` extracted from version manifest via `Map<layerId, schemaHash>`** — the three hash keys (`renderModel`, `dashboardSkeleton`, `coherenceProbe`) are mapped from the manifest layer entries. Using `Map.get()` with a `?? ""` fallback preserves type safety while guarding against any future layer registry changes. The field names on `UILayerSchemaHashes` are deliberately shorter than the layerIds (`renderModel` not `ui_render_model`) to reduce response verbosity at the summary level.

3. **`layers[]` mirrors `manifest.layers` ordering** — canonical alphabetical order (dashboard_skeleton < ui_coherence_probe < ui_render_model) is inherited by mapping over `manifest.layers` directly. No secondary sort needed. Each `UILayerSummaryEntry` is a projection of the manifest entry: `{layerId, version, endpoint, healthy, executionBlocked}`.

4. **`healthy: true` is always true** — the four UI modules are pure in-memory derivations; they cannot throw or return null under normal operation. `healthy` reflects successful module load (static truth), not a live HTTP probe. Documenting this invariant explicitly in GOTCHAS prevents future maintainers from interpreting it as a live-probe result.

5. **`allLayersCoherent` is a three-way AND** — `coherence.allWidgetsCoherent && coherence.allPanelsCoherent && coherence.allPagesCoherent`. This is the same logical combination a human operator would check when asking "is the UI layer healthy?". `bindingCoveragePercent` is passed through directly — no re-computation.

6. **Policy insertion: after `ui/render-model`** — `ui/summary` (s) sorts between `ui/render-model` (r) and `ui/version` (v) alphabetically. Inserted before `ui/render-model` in the access policy table to keep the natural grouping of all `ui/` routes together.

7. **No `init()`, no subsystem, no health check** — consistent with Phases 129–132. Pure aggregation modules do not require subsystem registration or health check hooks.

8. **`UILayerSummaryEntry` is a deliberate slim projection of `UILayerEntry`** — the full `UILayerEntry` from Phase 132 includes `layerName`, `layerType`, and `schemaHash`. The summary entry drops these to keep the summary response compact. `schemaHashes` at the top level provides the hash values in a more operator-friendly key-value shape. Callers needing full layer metadata should use `GET /api/workspace/ui/version`.

### Files changed

- `core/workspaceUILayerSummary.ts` — **NEW**: `UILayerSummaryEntry`, `UILayerSchemaHashes`, `UILayerSummary` interfaces; `getUILayerSummary()` public API; imports from `workspaceUIRenderModel`, `workspaceDashboardSkeleton`, `workspaceUICoherence`, `workspaceUILayerVersionManifest`
- `routes/workspace.ts` — `getUILayerSummary` imported; `handleUILayerSummary` handler added
- `server.ts` — `handleUILayerSummary` imported; `router.get("/api/workspace/ui/summary", ...)` registered
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/summary`

### Counters

- Endpoint count: 122 → **123**
- Policy count: 122 → **123**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 134 — UI Preview Payload Foundation

**Completed.** Adds `GET /api/workspace/ui/preview` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIPreviewPayload.ts`. No `init()`. No persistence. No subsystem registration. Aggregates from five existing modules: `workspaceUIRenderModel`, `workspaceDashboardSkeleton`, `workspaceUICoherence`, `healthMonitor`, `runtimeDependencyGraph`.

### Design decisions

1. **Five module reads per request** — unlike Phase 133's summary layer (4 reads), this payload adds `getFullHealth()` and `getRuntimeDependencyGraphStatus()` to reach into the runtime health and graph subsystems for the `healthSummary` block. These are the only non-UI-layer reads in the entire UI stack.

2. **`diagnosticsHealthy = status !== "unhealthy"`, not `=== "healthy"`** — the system operates in a persistent `"degraded"` steady state: 7 subsystems emit `"warn"` checks (secure_config, task_queue, task_persistence, queue_orchestration, runtime_snapshot, baseline_lock, request_lifecycle_ledger) due to intentional design constraints (executionBlocked=true everywhere). Zero checks fail. `"degraded"` means warnings only — the system is functionally healthy. Using `!== "unhealthy"` correctly captures operational health versus perfection.

3. **`graphHealthy = !getRuntimeDependencyGraphStatus().hasCycles`** — the graph module exports `DependencyGraphStatus` with a `hasCycles: boolean` field. Negating it gives the boolean health signal. Under normal operation this is always `true` (27 nodes, 0 cycles).

4. **`widgetPriorityMap` — O(37) Map built once per request** — `skeleton.widgetLayouts` is iterated once to build `Map<widgetId, priority>`. Then `renderModel.widgets` (sorted alphabetically) uses `widgetPriorityMap.get(w.widgetId) ?? 0` for priority lookup. The `?? 0` fallback is a safety guard — under coherent system state all 37 widgetIds have a matching layout entry.

5. **`pageWidgetCountMap` — O(37) Map for page widget counts** — `skeleton.widgetLayouts` is iterated once more to build `Map<pageId, count>`. Pages reference widgets via their primary `pageId` assignment in `WidgetLayoutEntry`. This gives each `PagePreviewEntry` its `widgetCount` without a nested O(37) scan per page.

6. **Ordering:**
   - `pagePreview[]`: preserves `skeleton.pageLayouts` order (overview → governance → observation → diagnostics → comparison). Intentional page order established by the skeleton; not re-sorted.
   - `panelPreview[]`: alphabetical by `panelId` — consistent with coherence probe and other panel-keyed operations.
   - `widgetPreview[]`: alphabetical by `widgetId` — consistent with render model and widget contract registry.
   - `navigationPreview.groups[]`: sorted by `groupOrder` ascending then `groupId` as tiebreaker — matches the visual navigation order.

7. **`executionBlocked: true` on 12 nested locations** — root, shellPreview, navigationPreview, every navGroup entry (5), every pagePreview entry (5), every panelPreview entry (15), every widgetPreview entry (37), responsivePreview, desktop breakpoint, tablet breakpoint, mobile breakpoint, healthSummary. The test suite verifies all 12 collection-level positions.

8. **`PreviewResponsiveBreakpoint` is a minimal projection of `ResponsiveBreakpoint`** — drops the `executionBlocked` field from the source type and re-adds it explicitly via `projectBreakpoint()` helper. This ensures the type is self-contained and not accidentally dependent on the skeleton's private interface.

### Internal consistency invariant

`sum(panelPreview[].widgetCount) === 37` — each widget is assigned to exactly one panel in the skeleton. This is verified by T10.

### Files changed

- `core/workspaceUIPreviewPayload.ts` — **NEW**: 9 interfaces (`ShellPreview`, `NavigationPreviewGroup`, `NavigationPreview`, `PagePreviewEntry`, `PanelPreviewEntry`, `WidgetPreviewEntry`, `PreviewResponsiveBreakpoint`, `ResponsivePreview`, `PreviewHealthSummary`, `UIPreviewPayload`); `projectBreakpoint()` helper; `getUIPreviewPayload()` public API
- `routes/workspace.ts` — `getUIPreviewPayload` imported; `handleUIPreviewPayload` handler added
- `server.ts` — `handleUIPreviewPayload` imported; `router.get("/api/workspace/ui/preview", ...)` registered
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/preview`

### Counters

- Endpoint count: 123 → **124**
- Policy count: 123 → **124**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 135 — UI Index Foundation

**Completed.** Adds `GET /api/workspace/ui` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIIndex.ts`. No `init()`. No persistence. No subsystem registration. No reads from any other module at call time. Purely static derivation — only `generatedAt` changes per request call.

### Design decisions

1. **Fully static — no runtime module reads** — unlike Phase 133 (summary reads 4 modules) and Phase 134 (preview reads 5 modules), the UI Index reads from zero other modules. All version strings (`uiVersion`, `dashboardVersion`, `manifestVersion`, `previewVersion`) are static constants mirroring the frozen nucleus state. This makes the index effectively a zero-cost lookup and eliminates any transitive read overhead.

2. **Static constant versions vs. dynamic derivation** — an earlier alternative was to call `getUILayerVersionManifest()` to source `uiVersion`, `dashboardVersion`, and `manifestVersion`. This was rejected: the manifest itself is a static module (all fields are hardcoded `"1"`), so deriving from it adds a function call with no information benefit. Direct constants are cheaper, simpler, and avoid any import dependency on the version manifest module. `previewVersion` is likewise hardcoded `"1"` matching the preview payload module.

3. **Alphabetical ordering by path** — canonical stable ordering matching all other alphabetically-ordered collections in the UI layer (panelPreview, widgetPreview, manifest layers). The 6 paths sort as: coherence < dashboard-skeleton < preview < render-model < summary < version. This ordering is enforced by the static `STATIC_ENDPOINTS` array, not by a runtime sort — zero per-request overhead.

4. **`UIIndexCategory` type union** — 6 values matching the 6 endpoint categories: `render_model | skeleton | coherence | version | summary | preview`. One category per endpoint. Categories are distinct and non-overlapping. They classify the structural role of each endpoint in the UI layer stack.

5. **`stable: true` for all 6 entries** — all six UI-layer endpoints have frozen schemas as of Phase 135. `stable: false` is reserved for future experimental endpoints. No entry currently uses `false`.

6. **No hidden or internal routes** — the registry covers only the 6 publicly accessible endpoints under `/api/workspace/ui/*`. Internal routes (e.g., `/api/runtime/*`, `/api/diagnostics/*`) are not exposed in this index. The index is a UI-surface discovery manifest, not a full API catalog.

7. **Forbidden string pruning in descriptions** — descriptions must not contain `React.`, `JSX`, `<!DOCTYPE`, `<html`, `<div`, `useState`, `className=`, or `import React`. These patterns are checked by the T12 test to ensure the index payload is clean for operator consumption. Descriptions use neutral technical language: "templated markup" instead of "JSX", "frontend framework code" instead of "React code".

8. **`totalEndpoints === endpoints[].length` invariant** — `totalEndpoints` is set to `STATIC_ENDPOINTS.length` at module load, which equals the actual array length. This invariant is verified by T3 and T4 independently. If a new endpoint is added to the registry, both values update atomically.

### Files changed

- `core/workspaceUIIndex.ts` — **NEW**: 4 types (`UIIndexCategory`, `UIIndexEndpoint`, `UIIndexVersions`, `UIIndex`); `STATIC_ENDPOINTS` (6 entries, alphabetical); `STATIC_UI_VERSIONS` (all `"1"`, pre-built constant); `getUIIndex()` public API
- `routes/workspace.ts` — `getUIIndex` imported; `handleUIIndex` handler added
- `server.ts` — `handleUIIndex` imported; `router.get("/api/workspace/ui", ...)` registered (before all `/api/workspace/ui/*` sub-routes)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui` (before `/api/workspace/ui/coherence`)

### Counters

- Endpoint count: 124 → **125**
- Policy count: 124 → **125**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 136 — Phase Archive Compaction VIII

**Completed.** Documentation-only. 0 new endpoints, 0 new policies, 0 new health checks, 0 new subsystems, 0 new graph nodes. No source code modified.

### What changed

- `PHASE_ARCHIVE.md` — Phases 127–135 appended in compact format. Archive footer updated from Phase 127 to Phase 136.
- `replit.md` — Session checkpoint compacted to 4 active rows (Phases 136+). Phase Archive Compaction VII row removed. Safety rule row removed. Phase archive reference updated to "Phases 1–135".
- `NUCLEUS_LOCK.md` — Phase 136 row prepended.
- `ARCHITECTURE.md` — This section.
- `GOTCHAS.md` — Phase 136 compaction integrity warning appended.

### Runtime state at compaction seal

| Metric | Value |
|---|---|
| Endpoints | 125 |
| Policies | 125 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| `BASELINE_LOCK.json` frozen | ep=59, hc=36, sub=26, graph=26 |
| Intentional drift | ep=125, hc=38, sub=27, graph=27 |

### Invariant

Compaction phases never change endpoint counts, policy counts, health checks, subsystems, graph nodes, source code, or runtime behavior. If a counter in replit.md or NUCLEUS_LOCK.md changes during a compaction phase, that is an error — roll back the documentation change.

## Phase 137 — UI Navigation Manifest

**Completed.** Adds `GET /api/workspace/ui/navigation` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUINavigation.ts`. No `init()`. No persistence. No subsystem registration. Single module read: `getUIRenderModel().navigation`.

### Design decisions

1. **Single source: `getUIRenderModel().navigation` only** — the render model's `navigation` object is the canonical UI navigation definition. It already contains `groups[]`, each with `groupId`, `title`, `groupOrder`, `items[]`, and `executionBlocked`. No other module is read (not the dashboard skeleton sidebar, not any static table). This keeps the manifest a pure projection of the render model's declared navigation intent.

2. **`route` → `endpoint` field rename** — render model items carry `route` (frontend UI routes: `/ui/overview`, `/ui/governance`, etc.). The manifest exposes this as `endpoint` to match the spec's item shape. The values remain unchanged — they are UI navigation destinations, not API paths. This is documented explicitly in ENDPOINTS.md so no future reader mistakes them for API routes.

3. **`groupOrder`-sorted groups, `itemOrder`-sorted items** — both orderings are stable and derived from the integer fields already present on each group/item in the render model. No secondary sort key is needed: `groupOrder` values 1–5 are unique across groups; `itemOrder` values within each group are unique integers. Sorting is O(5) + O(N) where N ≤ 6 items per group — negligible.

4. **`itemCount === items[].length` invariant** — `itemCount` is set to `items.length` after the sort, not a separately maintained constant. If the render model adds or removes items from a group, both fields update atomically. Verified by T9.

5. **`defaultPage='overview'` const-asserted** — the default landing page is the `overview` group. This is a stable product-level decision (not derived from any runtime state) and is encoded as a TypeScript string literal type `"overview"` in the return type. It does not change unless the navigation structure is redesigned.

6. **`executionBlocked: true` at 3 levels** — on the root manifest, on every group (5), and on every item (11). Total: 17 `executionBlocked: true` occurrences per response. Verified by T6, T7, T8.

7. **11 items across 5 groups** — overview:1, governance:3, observation:3, diagnostics:2, audit:2. This reflects the render model's current navigation definition. Item counts are not hardcoded; they follow whatever the render model declares. The `totalGroups=5` count is `groups.length` (not a constant), so it automatically tracks if the render model's group count changes.

8. **No persistence, no health check, no subsystem** — the navigation manifest is a pure per-request derivation with no stateful components. Adding it to the health monitor or subsystem registry would add overhead with no benefit.

### Files changed

- `core/workspaceUINavigation.ts` — **NEW**: 3 types (`UINavigationItem`, `UINavigationGroup`, `UINavigationManifest`); `getUINavigationManifest()` public API
- `routes/workspace.ts` — `getUINavigationManifest` imported; `handleUINavigation` handler added
- `server.ts` — `handleUINavigation` imported; `router.get("/api/workspace/ui/navigation", ...)` registered (between `/api/workspace/ui` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/navigation`

### Counters

- Endpoint count: 125 → **126**
- Policy count: 125 → **126**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 138 — UI Page Manifest

**Completed.** Adds `GET /api/workspace/ui/pages` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIPages.ts`. No `init()`. No persistence. No subsystem registration. Two module reads per call: `getUIRenderModel().pages` + `getDashboardSkeleton().pageLayouts`.

### Design decisions

1. **Two-source derivation: render model pages + skeleton pageLayouts** — the render model owns the page identity fields (pageId, title, route, sectionIds[], description, pageOrder). The dashboard skeleton owns the structural layout (panelIds[] per page). The manifest merges these by building a `Map<pageId, panelCount>` from the skeleton and joining into each page entry. This is the minimal cross-module join required to satisfy `panelCount`.

2. **`panelCount = panelIds.length` from skeleton** — not a separately maintained constant, not counted from the visual shell. The skeleton's `pageLayouts[].panelIds` is the single source of truth for which panels belong to each page. If the skeleton adds or removes panels from a page, `panelCount` updates automatically on the next request.

3. **Defensive fallback `panelCount = 0`** — if a render model pageId has no matching entry in `skeleton.pageLayouts`, `panelCountMap.get(pageId) ?? 0` returns 0 instead of throwing. This prevents a hard crash if the two sources temporarily diverge. The normal steady-state is all 5 pageIds present in both sources.

4. **Sorted by `pageOrder` ascending (1→5)** — `pageOrder` values in the render model are 1–5 (unique integers). Sorting is O(5 log 5). The canonical order is: overview(1)→governance(2)→observation(3)→diagnostics(4)→comparison(5). This matches the logical product navigation hierarchy.

5. **`route` values are UI navigation destinations (`/ui/*`)** — same convention as Phase 137 (navigation manifest). Not API paths. Values: `/ui/overview`, `/ui/governance`, `/ui/observation`, `/ui/diagnostics`, `/ui/comparison`. These are sourced directly from the render model without transformation.

6. **`sectionIds[]` preserved as-is from the render model** — overview has 3 section IDs (governance, observation, diagnostics — it's a cross-cutting summary page); governance/observation/diagnostics each have 1; comparison has 2. No transformation or reordering applied.

7. **`totalPages === pages[].length` invariant** — derived from `pages.length` after the sort, not a hardcoded integer. If the render model adds a new page, both update atomically.

8. **No health check, no subsystem** — pure per-request derivation. The two source modules (render model, skeleton) are already tested by their own endpoints. Adding a health check for the page manifest would add overhead with no diagnostic benefit.

### Page data at Phase 138

| pageId | pageOrder | panelCount | sectionIds |
|---|---|---|---|
| overview | 1 | 5 | governance, observation, diagnostics |
| governance | 2 | 3 | governance |
| observation | 3 | 4 | observation |
| diagnostics | 4 | 3 | diagnostics |
| comparison | 5 | 4 | governance, observation |

### Files changed

- `core/workspaceUIPages.ts` — **NEW**: 2 types (`UIPageEntry`, `UIPageManifest`); `getUIPageManifest()` public API
- `routes/workspace.ts` — `getUIPageManifest` imported; `handleUIPages` handler added
- `server.ts` — `handleUIPages` imported; `router.get("/api/workspace/ui/pages", ...)` registered (between `/api/workspace/ui/navigation` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/pages`

### Counters

- Endpoint count: 126 → **127**
- Policy count: 126 → **127**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 139 — UI Panel Manifest

**Completed.** Adds `GET /api/workspace/ui/panels` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIPanels.ts`. No `init()`. No persistence. No subsystem registration. Two module reads per call: `getDashboardSkeleton().panelLayouts` + `getUIRenderModel().panels`.

### Design decisions

1. **Two-source join: skeleton panelLayouts + render model panels** — the skeleton owns the structural fields (pageId, widgetIds → widgetCount, cardStyle, layoutDirection); the render model owns the display fields (title). These are the minimal fields needed to satisfy the spec. No other module is read.

2. **`widgetCount = skeleton.widgetIds.length`** — not independently recounted from the render model's widgetIds (which agree in steady-state). The skeleton is the authoritative structural source; counting from it is consistent with how `panelCount` was derived in Phase 138 (skeleton as layout authority).

3. **`title` from render model via `Map<panelId, title>`** — built once per request from `renderModel.panels`. Fallback to `panelId` if a panel is present in the skeleton but missing from the render model. This prevents a hard crash on divergence without silently producing wrong data (the panelId is still a meaningful identifier).

4. **Sorted alphabetically by `panelId`** — localeCompare ascending. This is the canonical ordering for panel manifests (parallels how widget manifests and panel preview entries are ordered in Phase 131/134). The 15 alphabetical panelIds are stable; no runtime reordering is expected.

5. **`totalPanels === panels[].length` invariant** — derived from `panels.length` after the sort, never a separate constant. If the skeleton adds or removes panels, both update atomically.

6. **No health check, no subsystem** — same rationale as Phase 138 (pages). Pure per-request derivation from two source modules that are already covered by their own endpoints. No new failure mode is introduced.

### Panel data at Phase 139

| panelId | pageId | widgetCount | cardStyle | layoutDirection |
|---|---|---|---|---|
| audit-trail | comparison | 2 | flat | column |
| change-detection | comparison | 1 | flat | column |
| coverage-trend | observation | 3 | elevated | column |
| event-detection | diagnostics | 2 | outlined | row |
| exposure-risk | governance | 3 | elevated | column |
| governance-overview | governance | 4 | elevated | column |
| ledger-analytics | observation | 3 | elevated | column |
| observation-heatmap | observation | 3 | elevated | column |
| observation-probe | observation | 3 | elevated | column |
| policy-compliance | governance | 2 | elevated | column |
| project-registry | overview | 3 | flat | row |
| runtime-metrics | diagnostics | 3 | outlined | row |
| system-health | diagnostics | 2 | outlined | row |
| workspace-membership | overview | 2 | flat | row |
| workspace-timeline | overview | 1 | flat | column |

### Files changed

- `core/workspaceUIPanels.ts` — **NEW**: 2 types (`UIPanelEntry`, `UIPanelManifest`); `getUIPanelManifest()` public API
- `routes/workspace.ts` — `getUIPanelManifest` imported; `handleUIPanels` handler added
- `server.ts` — `handleUIPanels` imported; `router.get("/api/workspace/ui/panels", ...)` registered (between `/api/workspace/ui/pages` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/panels`

### Counters

- Endpoint count: 127 → **128**
- Policy count: 127 → **128**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 140 — UI Widget Manifest

**Completed.** Adds `GET /api/workspace/ui/widgets` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIWidgets.ts`. No `init()`. No persistence. No subsystem registration. Single module read per call: `getUIRenderModel().widgets`.

### Design decisions

1. **Single source: render model widgets only** — unlike Phase 138 (pages, two-source join) and Phase 139 (panels, two-source join), widgets require no cross-module lookup. The render model is the sole authority for all seven required widget fields. No skeleton read is needed.

2. **All 7 fields passed through directly** — `widgetId`, `title`, `widgetType`, `renderHint`, `size`, `sourceEndpoint`, `executionBlocked` are all present on every render model widget entry. No fallback logic is required; no field is absent in steady-state.

3. **Sorted alphabetically by `widgetId`** — localeCompare ascending. Consistent with Phase 139 (panels alphabetical) and Phase 131/134 (widget preview alphabetical). The 37 widgetIds form a stable set.

4. **`totalWidgets === widgets[].length` invariant** — derived from `widgets.length` after the sort, never a hardcoded 37.

5. **No health check, no subsystem** — pure per-request derivation from a single source already covered by its own endpoint (`/api/workspace/ui/render-model`).

### Files changed

- `core/workspaceUIWidgets.ts` — **NEW**: 2 types (`UIWidgetEntry`, `UIWidgetManifest`); `getUIWidgetManifest()` public API
- `routes/workspace.ts` — `getUIWidgetManifest` imported; `handleUIWidgets` handler added
- `server.ts` — `handleUIWidgets` imported; `router.get("/api/workspace/ui/widgets", ...)` registered (between `/api/workspace/ui/panels` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/widgets`

### Counters

- Endpoint count: 128 → **129**
- Policy count: 128 → **129**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 141 — Phase Archive Compaction IX

**Completed.** Documentation-only. Phases 136–140 appended to PHASE_ARCHIVE.md. `replit.md` compacted to 4 active rows. Archive footer updated Phase 136→Phase 141. 0 new endpoints / health checks / subsystems / graph nodes / policies. No source files modified. Runtime unchanged.

### Phases archived this compaction

| Phase | Type | Summary |
|---|---|---|
| 136 | Archive compaction | Phases 127–135 → PHASE_ARCHIVE.md; 0 runtime changes |
| 137 | UI Navigation Manifest | `GET /api/workspace/ui/navigation`; 1 endpoint+policy, 0 health checks |
| 138 | UI Page Manifest | `GET /api/workspace/ui/pages`; 1 endpoint+policy, 0 health checks |
| 139 | UI Panel Manifest | `GET /api/workspace/ui/panels`; 1 endpoint+policy, 0 health checks |
| 140 | UI Widget Manifest | `GET /api/workspace/ui/widgets`; 1 endpoint+policy, 0 health checks |

### Sealed counters at Phase 141 boundary

- Endpoint count: **129**
- Policy count: **129**
- Health checks: **38**
- Subsystems: **27**
- Graph nodes: **27** (0 cycles)
- BASELINE_LOCK.json: frozen at Phase 43 — ep=59, hc=36, sub=26, graph=26

### Compaction convention

1. All archived phases receive a concise `**COMPLETE** —` summary block in PHASE_ARCHIVE.md.
2. The archive footer line is updated to reflect the newest compaction phase.
3. `replit.md` retains exactly 4 active rows (Completed phases, Phase archive, Workspace state, Current progress).
4. NUCLEUS_LOCK.md receives a documentation-only row for the compaction phase itself.
5. No source files, no routes, no policies, no health checks are modified.

## Phase 142 — UI Data Bindings Manifest

**Completed.** Adds `GET /api/workspace/ui/bindings` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIBindings.ts`. No `init()`. No persistence. No subsystem registration. Single module read per call: `getUIRenderModel().dataBindings`.

### Design decisions

1. **Single source: render model dataBindings only** — same pattern as Phase 140 (widgets). No skeleton reads. All five required fields (sourceEndpoint, readOnly, mutationAllowed, requiresApproval, executionBlocked) are present on every render model dataBinding entry.

2. **`requiresApproval=false` on all 18 entries** — the render model designates all data bindings as read-only with no approval gate, consistent with the `executionBlocked=true` design philosophy. The phase spec assumed `requiresApproval=true` but the actual source data has `false`. The manifest faithfully passes through source values. This is the correct behaviour — do not override source values with assumed constants.

3. **Sorted alphabetically by `sourceEndpoint`** — localeCompare ascending. 18 unique sourceEndpoints, all starting with `/api/`.

4. **`totalBindings === bindings[].length` invariant** — derived from `bindings.length` after sort.

5. **No health check, no subsystem** — pure per-request derivation from a single source already covered by `/api/workspace/ui/render-model`.

### Binding data at Phase 142 (alphabetical by sourceEndpoint)

| sourceEndpoint | readOnly | mutationAllowed | requiresApproval |
|---|---|---|---|
| /api/crash | true | false | false |
| /api/freeze | true | false | false |
| /api/health/full | true | false | false |
| /api/healthz | true | false | false |
| /api/metrics | true | false | false |
| /api/projects | true | false | false |
| /api/workspace/audit/digest | true | false | false |
| /api/workspace/audit/reports | true | false | false |
| /api/workspace/diff | true | false | false |
| /api/workspace/governance/scorecard | true | false | false |
| /api/workspace/observation/exposure | true | false | false |
| /api/workspace/observation/heatmap | true | false | false |
| /api/workspace/observation/ledger/analytics | true | false | false |
| /api/workspace/observation/probe | true | false | false |
| /api/workspace/observation/trend | true | false | false |
| /api/workspace/policy/compliance | true | false | false |
| /api/workspace/summary | true | false | false |
| /api/workspace/timeline | true | false | false |

### Files changed

- `core/workspaceUIBindings.ts` — **NEW**: 2 types (`UIBindingEntry`, `UIBindingManifest`); `getUIBindingManifest()` public API
- `routes/workspace.ts` — `getUIBindingManifest` imported; `handleUIBindings` handler added
- `server.ts` — `handleUIBindings` imported; `router.get("/api/workspace/ui/bindings", ...)` registered (between `/api/workspace/ui/widgets` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/bindings`

### Counters

- Endpoint count: 129 → **130**
- Policy count: 129 → **130**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 143 — UI Governance Badges Manifest

**Completed.** Adds `GET /api/workspace/ui/badges` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIBadges.ts`. No `init()`. No persistence. No subsystem registration. Single module read per call: `getUIRenderModel().governanceBadges`.

### Design decisions

1. **Single source: render model governanceBadges only** — same pattern as Phases 140–142. No skeleton reads. All six required fields (badgeId, label, signalType, sourceEndpoint, refreshMode, executionBlocked) are present on every render model governanceBadge entry.

2. **Sorted alphabetically by `badgeId`** — localeCompare ascending. 5 unique badgeIds.

3. **`totalBadges === badges[].length` invariant** — derived from `badges.length` after sort.

4. **No health check, no subsystem** — pure per-request derivation from a single source already covered by `/api/workspace/ui/render-model`.

### Badge data at Phase 143 (alphabetical by badgeId)

| badgeId | label | signalType | sourceEndpoint | refreshMode |
|---|---|---|---|---|
| badge-drift-risk | Drift Risk Level | risk_level | /api/workspace/governance/drift | on-demand |
| badge-governance-grade | Governance Grade | grade | /api/workspace/governance/scorecard | on-demand |
| badge-governance-score | Governance Score | score | /api/workspace/governance/scorecard | on-demand |
| badge-observation-health | Observation Health | health | /api/workspace/observation/ledger | on-demand |
| badge-system-health | System Health | health_status | /api/healthz | realtime |

### Files changed

- `core/workspaceUIBadges.ts` — **NEW**: 2 types (`UIBadgeEntry`, `UIBadgeManifest`); `getUIBadgeManifest()` public API
- `routes/workspace.ts` — `getUIBadgeManifest` imported; `handleUIBadges` handler added
- `server.ts` — `handleUIBadges` imported; `router.get("/api/workspace/ui/badges", ...)` registered (between `/api/workspace/ui/bindings` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/badges`

### Counters

- Endpoint count: 130 → **131**
- Policy count: 130 → **131**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 144 — Phase Archive Compaction X

**Completed.** Documentation-only. 0 runtime source changes. 0 new endpoints. 0 new policies. 0 new health checks. 0 new subsystems. 0 new graph nodes.

Phases 141–143 appended to PHASE_ARCHIVE.md. `replit.md` active checkpoint compacted to 4 rows. Archive footer updated Phase 141→Phase 144.

### Compaction convention (established Phase 132, reaffirmed each compaction phase)

- Compaction phases archive the previous N completed phases into PHASE_ARCHIVE.md.
- The active checkpoint in replit.md always shows exactly 4 data rows (header excluded).
- No counter values change. No source files change. No endpoints are added or removed.
- Typecheck must pass. Runtime verification must pass.

### Counters sealed at Phase 144

| Metric | Value |
|---|---|
| Endpoints | 131 |
| Policies | 131 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| BASELINE_LOCK.json | ep=59, hc=36, sub=26, graph=26 (frozen Phase 43) |
| Intentional drift | endpointCount (59→131), healthCheckCount (36→38), subsystemCount (26→27), graphNodeCount (26→27) |

## Phase 145 — UI Theme Manifest

**Completed.** Adds `GET /api/workspace/ui/theme` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUITheme.ts`. No `init()`. No persistence. No subsystem registration. Single module read per call: `getUIRenderModel().themeTokens`.

### Design decisions

1. **Single source: render model themeTokens only** — same pattern as Phases 140–143. No skeleton reads. All 5 source fields (colorMode, density, cardRadius, gridGap, typographyScale) passed through directly without transformation.

2. **`executionBlocked: true` on both root and themeTokens object** — the themeTokens source already carries `executionBlocked: true`; the manifest root also sets it explicitly.

3. **No computed fields, no derived values** — pure pass-through. A future phase that changes theme values must update the render model.

4. **No health check, no subsystem** — pure per-request derivation from a single source already covered by `/api/workspace/ui/render-model`.

### Theme data at Phase 145

| Field | Value |
|---|---|
| colorMode | dark |
| density | compact |
| cardRadius | 4px |
| gridGap | 16px |
| typographyScale | sm |

### Files changed

- `core/workspaceUITheme.ts` — **NEW**: 2 types (`UIThemeTokens`, `UIThemeManifest`); `getUIThemeManifest()` public API
- `routes/workspace.ts` — `getUIThemeManifest` imported; `handleUITheme` handler added
- `server.ts` — `handleUITheme` imported; `router.get("/api/workspace/ui/theme", ...)` registered (between `/api/workspace/ui/badges` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/theme`

### Counters

- Endpoint count: 131 → **132**
- Policy count: 131 → **132**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 146 — UI Layout Manifest

**Completed.** Adds `GET /api/workspace/ui/layout` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUILayout.ts`. No `init()`. No persistence. No subsystem registration. Single module read per call: `getUIRenderModel().layout`.

### Design decisions

1. **Single source: render model layout only** — same pattern as Phase 145 (theme). No skeleton reads. All 5 source fields (appName, shellType, sidebarEnabled, topbarEnabled, contentGrid) passed through directly without transformation.

2. **`executionBlocked: true` on both root and layout object** — the source layout already carries `executionBlocked: true`; the manifest root also sets it explicitly.

3. **Boolean fields passed through as booleans** — `sidebarEnabled` and `topbarEnabled` are `boolean` in the source and typed as `boolean` in `UILayoutConfig`. Do not stringify them.

4. **No health check, no subsystem** — pure per-request derivation from a single source already covered by `/api/workspace/ui/render-model`.

### Layout data at Phase 146

| Field | Value |
|---|---|
| appName | Bulldozer |
| shellType | operator_dashboard |
| sidebarEnabled | true |
| topbarEnabled | true |
| contentGrid | responsive |

### Files changed

- `core/workspaceUILayout.ts` — **NEW**: 2 types (`UILayoutConfig`, `UILayoutManifest`); `getUILayoutManifest()` public API
- `routes/workspace.ts` — `getUILayoutManifest` imported; `handleUILayout` handler added
- `server.ts` — `handleUILayout` imported; `router.get("/api/workspace/ui/layout", ...)` registered (between `/api/workspace/ui/theme` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/layout`

### Counters

- Endpoint count: 132 → **133**
- Policy count: 132 → **133**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 147 — UI Layer Audit

**Completed.** Adds `GET /api/workspace/ui/audit` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUILayerAudit.ts`. No `init()`. No persistence. No subsystem registration. Calls all 8 manifest getters directly — no HTTP requests, no skeleton reads.

### Design decisions

1. **Getter composition, not HTTP** — the audit calls `getUINavigationManifest()`, `getUIPageManifest()`, `getUIPanelManifest()`, `getUIWidgetManifest()`, `getUIBindingManifest()`, `getUIBadgeManifest()`, `getUIThemeManifest()`, `getUILayoutManifest()` directly. No runtime endpoint scanning. No HTTP round-trips.

2. **Two classes of totalInvariantValid** — array-based layers (navigation, pages, panels, widgets, bindings, badges): `totalX === items.length`; scalar layers (theme, layout): `true` always — no array invariant exists.

3. **`healthy = totalInvariantValid && executionBlocked === true`** — the only two conditions that matter for a pure read-only manifest layer.

4. **`allHealthy = checks.every(c => c.healthy)`** — derived, never hardcoded.

5. **`layersChecked === checks.length` invariant** — set from `checks.length` after building, never hardcoded 8.

6. **No health check, no subsystem** — pure per-request derivation that adds observability without registering as a managed resource.

### Audit results at Phase 147

| layerId | endpoint | totalInvariantValid | healthy |
|---|---|---|---|
| navigation | /api/workspace/ui/navigation | true (5===5) | true |
| pages | /api/workspace/ui/pages | true (5===5) | true |
| panels | /api/workspace/ui/panels | true (15===15) | true |
| widgets | /api/workspace/ui/widgets | true (37===37) | true |
| bindings | /api/workspace/ui/bindings | true (18===18) | true |
| badges | /api/workspace/ui/badges | true (5===5) | true |
| theme | /api/workspace/ui/theme | true (scalar) | true |
| layout | /api/workspace/ui/layout | true (scalar) | true |

### Files changed

- `core/workspaceUILayerAudit.ts` — **NEW**: 2 types (`UIAuditCheck`, `UILayerAudit`); `getUILayerAudit()` public API
- `routes/workspace.ts` — `getUILayerAudit` imported; `handleUILayerAudit` handler added
- `server.ts` — `handleUILayerAudit` imported; `router.get("/api/workspace/ui/audit", ...)` registered (between `/api/workspace/ui/layout` and `/api/workspace/ui/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/audit`

### Counters

- Endpoint count: 133 → **134**
- Policy count: 133 → **134**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 148 — UI Foundation Seal & Compaction XI

**Completed.** Documentation-only. 0 runtime source changes. 0 new endpoints. 0 new policies. 0 new health checks. 0 new subsystems. 0 new graph nodes.

Phases 144–147 appended to PHASE_ARCHIVE.md. `replit.md` active checkpoint compacted to 4 rows. Archive footer updated Phase 144→Phase 148.

### UI Foundation Batch — Sealed

Phases 140–147 constitute the complete UI Foundation batch. All 9 UI manifest endpoints are now sealed at Phase 148:

| Phase | Endpoint | Module | Source |
|---|---|---|---|
| 140 | GET /api/workspace/ui/widgets | workspaceUIWidgets | renderModel.widgets (37) |
| 139 | GET /api/workspace/ui/panels | workspaceUIPanels | skeleton.panelLayouts + renderModel.panels (15) |
| 138 | GET /api/workspace/ui/pages | workspaceUIPages | renderModel.pages + skeleton.pageLayouts (5) |
| 137 | GET /api/workspace/ui/navigation | workspaceUINavigation | renderModel.navigation (5 groups, 11 items) |
| 142 | GET /api/workspace/ui/bindings | workspaceUIBindings | renderModel.dataBindings (18) |
| 143 | GET /api/workspace/ui/badges | workspaceUIBadges | renderModel.governanceBadges (5) |
| 145 | GET /api/workspace/ui/theme | workspaceUITheme | renderModel.themeTokens (5 fields) |
| 146 | GET /api/workspace/ui/layout | workspaceUILayout | renderModel.layout (5 fields) |
| 147 | GET /api/workspace/ui/audit | workspaceUILayerAudit | all 8 manifest getters (no HTTP) |

All 9 endpoints: `executionBlocked=true`, no persistence, no mutation, no HTML/CSS/frontend code, no subsystem, no health check. Pure per-request render-model derivations.

### Compaction convention (reaffirmed)

- Compaction phases archive the previous N completed phases into PHASE_ARCHIVE.md.
- The active checkpoint in replit.md always shows exactly 4 data rows (header excluded).
- No counter values change. No source files change. No endpoints are added or removed.
- Typecheck must pass. Runtime verification must pass.

### Counters sealed at Phase 148

| Metric | Value |
|---|---|
| Endpoints | 134 |
| Policies | 134 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| BASELINE_LOCK.json | ep=59, hc=36, sub=26, graph=26 (frozen Phase 43) |
| Intentional drift | endpointCount (59→134), healthCheckCount (36→38), subsystemCount (26→27), graphNodeCount (26→27) |

## Phase 149 — UI Manifest Catalogue

**Completed.** Adds `GET /api/workspace/ui/catalogue` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/workspaceUIManifestCatalogue.ts`. No `init()`. No persistence. No subsystem registration. No runtime scanning. Sources entirely from a static in-module constant.

### Design decisions

1. **Static constant, not runtime derivation** — `CATALOGUE_ENTRIES` is a `ReadonlyArray` defined once at module level. The getter maps it to add `executionBlocked: true` and stamps `generatedAt`. No module imports are called for content, no endpoints are scanned at runtime.

2. **Alphabetical by path** — entries are defined in alphabetical order in the constant. The output order is the constant's natural order (already alphabetical). No sort is applied at call time.

3. **`totalEntries === entries.length` invariant** — `totalEntries` is always derived from `entries.length` after mapping, never hardcoded.

4. **Two types: `UIManifestEntry` + `UIManifestCatalogue`** — each entry carries `path`, `layerId`, `description`, `dataShape`, `executionBlocked`. The catalogue adds `generatedAt`, `totalEntries`, `executionBlocked`.

5. **Adding a new UI manifest endpoint** — append one `Omit<UIManifestEntry, "executionBlocked">` object to `CATALOGUE_ENTRIES`. `totalEntries` and `entries.length` update automatically. No other files need to change inside this module.

### Coverage at Phase 149 (9 entries, alphabetical)

| path | layerId |
|---|---|
| /api/workspace/ui/audit | audit |
| /api/workspace/ui/badges | badges |
| /api/workspace/ui/bindings | bindings |
| /api/workspace/ui/layout | layout |
| /api/workspace/ui/navigation | navigation |
| /api/workspace/ui/pages | pages |
| /api/workspace/ui/panels | panels |
| /api/workspace/ui/theme | theme |
| /api/workspace/ui/widgets | widgets |

### Files changed

- `core/workspaceUIManifestCatalogue.ts` — **NEW**: 2 types (`UIManifestEntry`, `UIManifestCatalogue`); static `CATALOGUE_ENTRIES` (9 entries); `getUIManifestCatalogue()` public API
- `routes/workspace.ts` — `getUIManifestCatalogue` imported; `handleUIManifestCatalogue` handler added
- `server.ts` — `handleUIManifestCatalogue` imported; `router.get("/api/workspace/ui/catalogue", ...)` registered (between `/audit` and `/coherence`)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/api/workspace/ui/catalogue`

### Counters

- Endpoint count: 134 → **135**
- Policy count: 134 → **135**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 150 — Static UI Shell Foundation

**Completed.** Adds `GET /ui` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New modules `core/uiShell.ts` and `routes/ui.ts`. No `init()`. No persistence. No subsystem registration. Serves server-rendered HTML (text/html) assembled from existing UI manifest getters.

### Design decisions

1. **Server-rendered HTML, no client-side JS** — `buildUIShellHtml()` composes all data into a single HTML string at request time. The browser receives a complete static page. Zero `<script>` tags. Zero event handlers.

2. **All data from existing manifest getters** — calls `getUIThemeManifest()`, `getUILayoutManifest()`, `getUINavigationManifest()`, `getUIPageManifest()`, `getUIPanelManifest()`, `getUIWidgetManifest()`, `getUIBadgeManifest()`, `getUILayerAudit()` directly. No new data models.

3. **HTML-escape all dynamic strings** — `esc()` replaces `&`, `<`, `>`, `"` with named entities before interpolating into HTML. Defense against accidental injection from any data field.

4. **Separate route file** — `routes/ui.ts` is distinct from `routes/workspace.ts` since `/ui` is a different path family (HTML, not JSON API). Keeps workspace.ts focused on API handlers.

5. **Custom response headers** — `X-Execution-Blocked: true`, `X-Read-Only: true`, `Cache-Control: no-store`. These are set in `res.writeHead()` alongside `Content-Type: text/html; charset=utf-8`, which takes precedence over any previously `setHeader`-ed values.

6. **Visual READ ONLY / EXECUTION BLOCKED badges** — prominently rendered in the header using colored inline CSS. No external stylesheets, no external fonts.

7. **Content-Security-Policy: default-src 'none'** — inherited from `applySecurityHeaders()` (hardening layer). The shell serves no external resources — all CSS is inline, no images, no fonts, no scripts. Compliant with the existing CSP.

8. **No HEAD route** — the router uses exact method matching. HEAD `/ui` returns 404 (no_policy, observe mode). This is intentional — HEAD support for HTML routes is out of scope. Header validation uses GET.

### Output summary at Phase 150

- Size: 8449 bytes (stable, deterministic excl. `generatedAt`)
- Content-Type: `text/html; charset=utf-8`
- X-Execution-Blocked: `true`
- X-Read-Only: `true`
- Cache-Control: `no-store`
- Sections: Shell Config (9 KV tiles) · Navigation (5 groups) · Pages (5 rows) · Panels/Widgets/Badges (stats) · Governance Badges (5 rows) · UI Layer Audit (8 rows) · Footer

### Files changed

- `core/uiShell.ts` — **NEW**: `esc()` HTML entity encoder; `buildUIShellHtml()` — composes all 8 manifest getters, returns complete HTML string
- `routes/ui.ts` — **NEW**: `handleUIShell` — calls `buildUIShellHtml()`, sends 200 with `text/html; charset=utf-8` headers
- `server.ts` — `handleUIShell` imported from `./routes/ui`; `router.get("/ui", handleUIShell)` registered (after last visual-shell route)
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/ui`

### Counters

- Endpoint count: 135 → **136**
- Policy count: 135 → **136**
- Health checks: 38 (unchanged)
- Subsystems: 27 (unchanged)
- Graph nodes: 27 (unchanged)

## Phase 151 — Static UI Shell Seal & Compaction XII

**Completed.** Documentation-only. 0 runtime source changes. 0 new endpoints. 0 new policies. 0 new health checks. 0 new subsystems. 0 new graph nodes.

Phases 148–150 appended to PHASE_ARCHIVE.md. `replit.md` active checkpoint compacted to 4 rows. Archive footer updated Phase 148→Phase 151.

### Static UI Shell Batch — Sealed

Phases 149–150 constitute the Static UI Shell batch, sealed at Phase 151:

| Phase | Endpoint | Module | Type | Notes |
|---|---|---|---|---|
| 149 | GET /api/workspace/ui/catalogue | workspaceUIManifestCatalogue | JSON | 9-entry static registry, alphabetical by path |
| 150 | GET /ui | uiShell + routes/ui | HTML | Server-rendered, no JS, no forms, 8449 bytes |

Phase 148 was itself a compaction (Compaction XI), now archived here.

### First visible UI shell milestone

Phase 150 marks the first endpoint in the Bulldozer nucleus that serves `text/html` (all prior 135 endpoints served `application/json`). The shell is entirely server-rendered, stateless, read-only, and compliant with the existing `Content-Security-Policy: default-src 'none'` via inline-only CSS.

### Compaction convention (reaffirmed at Phase 151)

- Compaction phases archive the previous N completed phases into PHASE_ARCHIVE.md.
- The active checkpoint in replit.md always shows exactly 4 data rows.
- No counter values change. No source files change. No endpoints added or removed.
- Typecheck must pass. Runtime verification must pass.

### Counters sealed at Phase 151

| Metric | Value |
|---|---|
| Endpoints | 136 |
| Policies | 136 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| BASELINE_LOCK.json | ep=59, hc=36, sub=26, graph=26 (frozen Phase 43) |
| Intentional drift | endpointCount (59→136), healthCheckCount (36→38), subsystemCount (26→27), graphNodeCount (26→27) |

## Phase 152 — UI Overview Page

**Completed.** Adds `GET /ui/overview` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

New module `core/uiOverviewPage.ts`. `routes/ui.ts` extended with shared `sendHtml()` helper and `handleUIOverview`. No new route file. No `init()`. No persistence.

### Design decisions

1. **Overview-only data filtering** — `buildUIOverviewHtml()` filters `nav.groups` to `groupId === "overview"` and `panels.panels` to `pageId === "overview"`. The 3 overview panels (project-registry, workspace-membership, workspace-timeline) are the only panels shown. Non-overview panels (governance, observation, diagnostics, comparison) are never accessed.

2. **Shared `sendHtml()` helper in `routes/ui.ts`** — `handleUIShell` and `handleUIOverview` both need identical response headers. Extracted into a private `sendHtml(res, html)` helper to avoid duplicating the 5-header `writeHead` block. No interface change.

3. **Separate module `core/uiOverviewPage.ts`** — keeps `uiShell.ts` untouched (sealed at Phase 150). Each HTML page lives in its own module: `uiShell.ts` (full shell) and `uiOverviewPage.ts` (overview page). Pattern extends naturally for future pages.

4. **`esc()` re-declared locally** — each HTML-building module declares its own `esc()`. Not exported from a shared lib to avoid coupling modules to a shared internal util. Both are identical 4-replace functions.

5. **Breadcrumb navigation** — a plain-text `<p class="breadcrumb"><a href="/ui">/ui</a> › overview</p>` provides context. The anchor uses a plain `href` — no JS, no onclick.

6. **No HEAD route** — same convention as `/ui`. HEAD returns 404 (router exact-method matching). Header verification uses GET.

### Page sections at Phase 152

| Section | Data |
|---|---|
| Header | BULLDOZER · OVERVIEW (purple label) · READ ONLY badge · EXECUTION BLOCKED badge |
| System Summary | 6 KV tiles: shellType / contentGrid / themeMode / totalPages (5) / totalPanels (15) / totalWidgets (37) |
| Overview Navigation | Filtered nav items for groupId=overview, sorted by itemOrder |
| Overview Panels | 3 rows: project-registry / workspace-membership / workspace-timeline (panelId/title/widgetCount/cardStyle/layoutDirection) |
| Audit Snapshot | allHealthy / layersChecked / 8-row checks table |
| Footer | generatedAt · executionBlocked:true · readOnly:true · noMutation:true · noClientJS:true |

### Files changed

- `core/uiOverviewPage.ts` — **NEW**: `esc()` + `buildUIOverviewHtml()`
- `routes/ui.ts` — extracted `sendHtml()` helper; added `handleUIOverview`
- `server.ts` — import extended; `router.get("/ui/overview", handleUIOverview)` added
- `core/accessEnforcement.ts` — 1 new policy: GET read/viewer for `/ui/overview` (inserted before `/ui`)

### Counters

| Metric | Before | After |
|---|---|---|
| Endpoints | 136 | **137** |
| Policies | 136 | **137** |
| Health checks | 38 | 38 |
| Subsystems | 27 | 27 |
| Graph nodes | 27 (0 cycles) | 27 (0 cycles) |

## Phase 153 — UI Pages Batch (Governance / Observation / Diagnostics)

**Completed.** Adds `GET /ui/governance`, `GET /ui/observation`, `GET /ui/diagnostics` — 3 new endpoints, 3 new policies, 0 new subsystems, 0 new health checks, 0 new graph nodes.

Single new module `core/uiDashboardPages.ts` serving all three pages via a parameterised builder. `routes/ui.ts` extended with 3 handlers. No new route files.

### Design decisions

1. **Single parameterised module** — `buildDashboardPageHtml(pageId: DashboardPageId)` handles all three pages. `PAGE_META` holds the per-page title, label string, and accent color. `buildCss(labelColor)` injects the per-page accent into inline CSS. This avoids three near-identical modules while keeping the builder pure and side-effect-free.

2. **`DashboardPageId` union type** — `"governance" | "observation" | "diagnostics"` provides compile-time safety. TypeScript rejects any call with an unknown pageId. The `PAGE_META` record is keyed on this type, so missing entries are compile errors.

3. **Filter, never scan all** — nav items filtered by `g.groupId === pageId`; panels filtered by `p.pageId === pageId`. Only the page's own data is ever accessed. No other page's panels can appear even if the manifest changes, since filtering is by structural field equality.

4. **Per-page accent color** — governance: `#d8a878` (amber), observation: `#78b8d8` (steel blue), diagnostics: `#c878d8` (violet). The `.page-label` CSS rule sets `color: <labelColor>` via `buildCss(meta.labelColor)`. This is the only per-page CSS variation; all other rules are shared.

5. **`buildCss()` is a pure function** — takes `labelColor: string` and returns a CSS string literal. Called once per request. No module-level mutable state.

6. **Separate from `uiOverviewPage.ts`** — overview page is a Phase 152 sealed module. The three dashboard pages share `uiDashboardPages.ts`. Pattern for future pages: either extend `DashboardPageId` and add a `PAGE_META` entry, or create a new module for fundamentally different layouts.

### Panel scopes

| Page | Panels | Count |
|---|---|---|
| governance | governance-overview, exposure-risk, policy-compliance | 3 |
| observation | coverage-trend, ledger-analytics, observation-heatmap, observation-probe | 4 |
| diagnostics | event-detection, runtime-metrics, system-health | 3 |

### Page sizes at Phase 153

| Page | Size |
|---|---|
| `/ui/governance` | 5915 bytes |
| `/ui/observation` | 6042 bytes |
| `/ui/diagnostics` | 5801 bytes |

### Files changed

- `core/uiDashboardPages.ts` — **NEW**: `DashboardPageId`, `PAGE_META`, `buildCss()`, `buildDashboardPageHtml()`
- `routes/ui.ts` — import added; `handleUIGovernance`, `handleUIObservation`, `handleUIDiagnostics` added
- `server.ts` — import extended; 3 routes registered
- `core/accessEnforcement.ts` — 3 new policies: GET read/viewer for `/ui/governance`, `/ui/observation`, `/ui/diagnostics` (inserted before `/ui/overview`)

### Counters

| Metric | Before | After |
|---|---|---|
| Endpoints | 137 | **140** |
| Policies | 137 | **140** |
| Health checks | 38 | 38 |
| Subsystems | 27 | 27 |
| Graph nodes | 27 (0 cycles) | 27 (0 cycles) |

## Phase 154 — UI Pages Seal & Compaction XIII

**Completed.** Documentation-only. 0 runtime source changes. 0 new endpoints. 0 new policies. 0 new health checks. 0 new subsystems. 0 new graph nodes.

Phases 151–153 appended to PHASE_ARCHIVE.md. `replit.md` active checkpoint compacted to 4 rows. Archive footer updated Phase 151→Phase 154.

### Multi-Page Static UI Shell — Sealed

Phases 150–153 constitute the Multi-Page Static UI Shell batch, sealed at Phase 154:

| Phase | Endpoint(s) | Module | Type | Panels |
|---|---|---|---|---|
| 150 | GET /ui | uiShell | HTML | All (full shell) |
| 152 | GET /ui/overview | uiOverviewPage | HTML | project-registry, workspace-membership, workspace-timeline |
| 153 | GET /ui/governance | uiDashboardPages | HTML | governance-overview, exposure-risk, policy-compliance |
| 153 | GET /ui/observation | uiDashboardPages | HTML | coverage-trend, ledger-analytics, observation-heatmap, observation-probe |
| 153 | GET /ui/diagnostics | uiDashboardPages | HTML | event-detection, runtime-metrics, system-health |

Phase 151 was itself a compaction (Compaction XII), now archived here.

### Complete UI route map at Phase 154

```
GET /ui                — full shell index (all manifests, 8449 bytes)
GET /ui/overview       — overview page (3 panels, 5556 bytes)
GET /ui/governance     — governance page (3 panels, 5915 bytes)
GET /ui/observation    — observation page (4 panels, 6042 bytes)
GET /ui/diagnostics    — diagnostics page (3 panels, 5801 bytes)
```

5 HTML endpoints. All: `Content-Type: text/html; charset=utf-8`, `X-Execution-Blocked: true`, `X-Read-Only: true`, `Cache-Control: no-store`. Zero client-side JS. Zero forms. All CSS inline. All filtered by structural field equality (`groupId`, `pageId`).

### Counters sealed at Phase 154

| Metric | Value |
|---|---|
| Endpoints | 140 |
| Policies | 140 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| HTML endpoints | 5 (`/ui`, `/ui/overview`, `/ui/governance`, `/ui/observation`, `/ui/diagnostics`) |
| JSON endpoints | 135 |
| BASELINE_LOCK.json | ep=59, hc=36, sub=26, graph=26 (frozen Phase 43) |

## Phase 155 — UI Comparison Page

**Completed.** Adds `GET /ui/comparison` — 1 new endpoint, 1 new policy, 0 new subsystems, 0 new health checks, 0 new graph nodes.

No new module. `core/uiDashboardPages.ts` extended: `DashboardPageId` union widened, `PAGE_META` record extended. `routes/ui.ts` and `server.ts` updated. Zero new files.

### Design decisions

1. **Reuse existing parameterised builder** — `buildDashboardPageHtml("comparison")` is a direct call to the Phase 153 builder. Adding `"comparison"` to `DashboardPageId` and `PAGE_META` is the only module change needed. TypeScript enforces completeness of the `PAGE_META` record at compile time.

2. **Teal accent `#78d8c8`** — distinct from the four existing page accents (amber/steel-blue/violet for governance/observation/diagnostics). Maintains visual differentiation across all five pages.

3. **2 panels (audit-trail, change-detection)** — `pageId === "comparison"` filter yields exactly 2 panels. Both are confirmed in the panel manifest under `pageId="comparison"`.

4. **No new files** — extending `DashboardPageId` and `PAGE_META` is the minimal change. No new `core/uiXxxPage.ts` module needed.

### Complete UI route map at Phase 155

```
GET /ui                — full shell index    (8449 bytes, all manifests)
GET /ui/overview       — overview page       (5556 bytes, 3 panels)
GET /ui/governance     — governance page     (5915 bytes, 3 panels)
GET /ui/observation    — observation page    (6042 bytes, 4 panels)
GET /ui/diagnostics    — diagnostics page    (5801 bytes, 3 panels)
GET /ui/comparison     — comparison page     (5543 bytes, 2 panels)
```

All 5 render model pages now have dedicated HTML routes. Full UI Shell complete.

### Counters

| Metric | Before | After |
|---|---|---|
| Endpoints | 140 | **141** |
| Policies | 140 | **141** |
| Health checks | 38 | 38 |
| Subsystems | 27 | 27 |
| Graph nodes | 27 (0 cycles) | 27 (0 cycles) |
| HTML endpoints | 5 | **6** |

## Phase 156 — Full UI Shell Seal & Compaction XIV

**Completed.** Documentation-only. 0 runtime source changes. 0 new endpoints. 0 new policies. 0 new health checks. 0 new subsystems. 0 new graph nodes.

Phases 154–155 appended to PHASE_ARCHIVE.md. `replit.md` active checkpoint compacted to 4 rows. Archive footer updated Phase 154→Phase 156.

### Complete 6-Endpoint UI Shell — Sealed

All 5 render model pages now have dedicated HTML routes. The full UI shell is complete and sealed at Phase 156:

| Phase | Endpoint | Module | Panels | Accent | Size |
|---|---|---|---|---|---|
| 150 | GET /ui | uiShell | all (full index) | — | 8449 B |
| 152 | GET /ui/overview | uiOverviewPage | project-registry, workspace-membership, workspace-timeline | — | 5556 B |
| 153 | GET /ui/governance | uiDashboardPages | governance-overview, exposure-risk, policy-compliance | `#d8a878` amber | 5915 B |
| 153 | GET /ui/observation | uiDashboardPages | coverage-trend, ledger-analytics, observation-heatmap, observation-probe | `#78b8d8` steel blue | 6042 B |
| 153 | GET /ui/diagnostics | uiDashboardPages | event-detection, runtime-metrics, system-health | `#c878d8` violet | 5801 B |
| 155 | GET /ui/comparison | uiDashboardPages | audit-trail, change-detection | `#78d8c8` teal | 5543 B |

All 6 endpoints: `Content-Type: text/html; charset=utf-8` · `X-Execution-Blocked: true` · `X-Read-Only: true` · `Cache-Control: no-store` · zero client-side JS · zero forms · all CSS inline · filtered by structural field equality.

### Module summary

| Module | Pages served | Pattern |
|---|---|---|
| `core/uiShell.ts` | `/ui` | All 8 manifest getters, full composite |
| `core/uiOverviewPage.ts` | `/ui/overview` | Standalone builder, custom sections |
| `core/uiDashboardPages.ts` | `/ui/governance`, `/ui/observation`, `/ui/diagnostics`, `/ui/comparison` | Parameterised `DashboardPageId`, `PAGE_META` |
| `routes/ui.ts` | All 6 | Shared `sendHtml()` helper, 6 handlers |

### Counters sealed at Phase 156

| Metric | Value |
|---|---|
| Endpoints | 141 |
| Policies | 141 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| HTML endpoints | 6 |
| JSON endpoints | 135 |
| BASELINE_LOCK.json | ep=59, hc=36, sub=26, graph=26 (frozen Phase 43) |

## Phase 159 — UI Branding Header

**Completed.** Visual identity upgrade of all 6 HTML UI pages. CSS-only changes to 3 source modules. 0 new endpoints. 0 new policies.

### What changed

11 targeted edits across `core/uiShell.ts`, `core/uiOverviewPage.ts`, `core/uiDashboardPages.ts`:

| Edit type | Count | Description |
|---|---|---|
| CSS block replacements | 3 | `.topbar`/`.dot`/`.app-name`/`.spacer` → brand-header system (10 new classes each) |
| HTML topbar replacements | 3 | `<div class="topbar">` → `<div class="brand-header">` with full structure |
| Breadcrumb CSS cleanups | 2 | `margin-bottom:18px;padding:0 2px` removed from sub-page files |
| @media updates | 3 | `.topbar{...}` → `.brand-header{padding:12px 14px}` |

### Brand header CSS class inventory

| Class | Role |
|---|---|
| `.brand-header` | Outer card — `#111213` bg, `1px #1c1c1e` border, `3px ACCENT` left border |
| `.brand-top` | Flex row — identity left, badges right, `flex-wrap:wrap`, `margin-bottom:12px` |
| `.brand-identity` | Flex row — mark + text block, `gap:14px` |
| `.brand-mark` | ◈ `&#9672;` — 20px, accent colour, `text-shadow:0 0 12px ACCENT55` glow |
| `.brand-text` | Column flex — name + subtitle, `gap:4px` |
| `.brand-name` | BULLDOZER — 17px, 900 weight, 4px letter-spacing, `#f2f2f2` |
| `.brand-sub` | Subtitle — 10px, `#424242`, 1.5px letter-spacing, uppercase |
| `.brand-badges` | READ ONLY + EXECUTION BLOCKED — `flex-shrink:0`, `gap:8px` |
| `.brand-foot` | Below hairline (`1px #181818`) — flex row: page-tag + breadcrumb on sub-pages |
| `.page-tag` | Retained — per-page accent pill |
| `.breadcrumb` | Retained — now `<span>` inside `.brand-foot` flex row (was block `<p>`) |

### Shell vs sub-page brand-foot

| Page | brand-foot contents |
|---|---|
| `/ui` | `<span class="page-tag">UI Shell</span>` only |
| `/ui/overview` | `<span class="breadcrumb"><a href="/ui">/ui</a> › overview</span>` + `<span class="page-tag">Overview</span>` |
| `/ui/governance` | breadcrumb `/ui › governance` + GOVERNANCE tag |
| `/ui/observation` | breadcrumb `/ui › observation` + OBSERVATION tag |
| `/ui/diagnostics` | breadcrumb `/ui › diagnostics` + DIAGNOSTICS tag |
| `/ui/comparison` | breadcrumb `/ui › comparison` + COMPARISON tag |

### Per-page accent left border (unchanged from Phase 157)

| Page | Accent |
|---|---|
| `/ui` | `#7878d8` blue-purple |
| `/ui/overview` | `#7878d8` blue-purple |
| `/ui/governance` | `#d8a878` amber |
| `/ui/observation` | `#78b8d8` steel blue |
| `/ui/diagnostics` | `#c878d8` violet |
| `/ui/comparison` | `#78d8c8` teal |

---

## Phase 158 — Visual UI Seal & Compaction XV

**Completed.** Documentation-only. 0 runtime source changes. 0 new endpoints. 0 new policies.

Phases 156–157 appended to PHASE_ARCHIVE.md. `replit.md` active checkpoint compacted to 4 rows. Archive footer updated Phase 156→Phase 158 · Visual UI Seal.

### Styled Dashboard UI — Sealed at Phase 158

The complete 6-endpoint visual UI shell is sealed. All pages deliver a consistent dark-theme dashboard layout.

#### Design system classes

| Class | Role |
|---|---|
| `.layout` | Max-1100px centered wrapper, 20px padding |
| `.topbar` | Card header — accent dot, app name, page tag, badges |
| `.dot` | 9px glowing accent dot (box-shadow: 0 0 8px accent88) |
| `.page-tag` | Per-page label — accent color, accent border + bg tint |
| `.badge.ro` | READ ONLY — green on dark green |
| `.badge.eb` | EXECUTION BLOCKED — red on dark red |
| `.breadcrumb` | `/ui › page` trail on all sub-pages |
| `.stat-row` | Auto-fill grid of stat cards |
| `.sc` | Stat card — 22px accent number + 9px uppercase label |
| `.sh` | Section header — 9px uppercase, 2px letter-spacing, inline count |
| `.panel-grid` | Auto-fill grid of panel cards (min 210px) |
| `.pc` | Panel card — accent top bar, id (dim), title, chips, widget count |
| `.pc-bar` | 3px accent-color top bar on each panel card |
| `.chip` | Style/direction chip — dark bg, subtle border |
| `.wc` | Widget count in accent color, right-aligned |
| `.audit-bar` | Pill row — All Healthy status + executionBlocked chip |
| `.eb-chip` | executionBlocked badge — red on dark red |

#### Per-page accent colors

| Page | Accent | RGB role |
|---|---|---|
| `/ui` (shell index) | `#7878d8` | Blue-purple |
| `/ui/overview` | `#7878d8` | Blue-purple |
| `/ui/governance` | `#d8a878` | Amber |
| `/ui/observation` | `#78b8d8` | Steel blue |
| `/ui/diagnostics` | `#c878d8` | Violet |
| `/ui/comparison` | `#78d8c8` | Teal |

#### Shell index special features

- Pages section renders as `<a class="pgc" href="/ui/<page>">` anchor cards — each with its page-specific accent top bar. Clickable navigation without any JS.
- Nav groups displayed as card grid (`.nav-grid` / `.nc`).

#### Responsive breakpoint

`@media(max-width:620px)`: stat-row → 2-col; panel/nav/kv grids → 1-col; topbar compact.

#### Page sizes at seal

| Endpoint | Size |
|---|---|
| GET /ui | 11700 B |
| GET /ui/overview | 8150 B |
| GET /ui/governance | 8584 B |
| GET /ui/observation | 8977 B |
| GET /ui/diagnostics | 8454 B |
| GET /ui/comparison | 7900 B |

### Counters sealed at Phase 158

| Metric | Value |
|---|---|
| Endpoints | 141 |
| Policies | 141 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| HTML endpoints | 6 |
| BASELINE_LOCK.json | ep=59, hc=36, sub=26, graph=26 (frozen Phase 43) |

---

### Phase 165 — Operator UI Seal & Compaction

**Documentation-only.** Seals the Operator Dashboard visual refinement batch (Phases 162–164). Zero runtime source files changed. Zero endpoint, policy, health check, subsystem, or graph node changes.

**Sealed batch summary:**

Phase 162 built the operator dashboard layout on `/ui` — sticky topbar, 208px sidebar, two-panel flex body with independent scroll, metric card grid, KV config grid, pages nav grid, badges table, audit table.

Phase 163 extended the identical layout to all 5 sub-pages (`/ui/overview`, `/ui/governance`, `/ui/observation`, `/ui/diagnostics`, `/ui/comparison`) with per-page accent colours threaded through the full CSS via `buildCss(accent: string)` in each module. `PAGE_META` record in `uiDashboardPages.ts` holds `accent` + `dotClass` for the 4 parameterised pages; `uiOverviewPage.ts` uses `ACCENT = "#7878d8"` constant.

Phase 164 removed duplicated elements (badge row in title area → topbar only; sidebar "System" section → sidebar now Pages + Runtime only), redesigned sub-page metric cards to be page-scoped (This Page panels, Nav Items count), lifted all muted CSS text colours ~20% lightness across 20+ classes, and added `table-wrap{overflow-x:auto}` around every table for mobile horizontal scroll.

**CSS architecture at seal:**

Each of the 3 source modules (`core/uiShell.ts`, `core/uiOverviewPage.ts`, `core/uiDashboardPages.ts`) has its own `buildCss(accent)` function — intentionally not shared. Sharing would require a new lib package, violating the zero-dependency principle. The CSS is parameterised by accent only; all other values are constants.

The two-panel scroll contract: `html,body{height:100%;overflow:hidden}` + `body{display:flex;flex-direction:column}` + `.op-body{display:flex;flex:1;overflow:hidden}` + `.op-sidebar{overflow-y:auto}` + `.op-main{flex:1;overflow-y:auto}`. Topbar stays pinned via `flex-shrink:0`, not `position:fixed`. Mobile reverts all of this to normal block flow at ≤820px.

**Counters unchanged through Phases 162–165:**

| Metric | Value |
|---|---|
| Endpoints | 141 |
| Policies | 141 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| HTML UI routes | 6 |
| Workspace UI API endpoints | 17 |
| BASELINE_LOCK.json | ep=59, hc=36, sub=26, graph=26 (frozen Phase 43) |

---

### Phases 166–167 — UI Route Discovery APIs

**Phase 166** adds `GET /api/workspace/ui/pages/summary` — lightweight JSON summary for all 5 dashboard pages. Response: `generatedAt`, `totalPages=5`, `pages[]` (each: `pageId`, `title`, `apiRoute="/api/workspace/ui/pages"`, `htmlRoute` (/ui/…), `panelCount`, `panelIds[]`, `executionBlocked=true`). Derives from `getUIPageManifest()` + `getDashboardSkeleton().pageLayouts`. Core module: `core/workspaceUIPagesSummary.ts`.

**Phase 167** adds `GET /api/workspace/ui/html-routes` — JSON index of all 6 server-rendered HTML routes. Response: `generatedAt`, `totalRoutes=6`, `routes[]` (each: `path`, `pageId`, `title`, `type` ("shell"/"page"), `panelCount`, `executionBlocked=true`). Static shell entry for `/ui` + 5 sub-page entries from `getUIPageManifest()`. Core module: `core/workspaceUIHtmlRoutes.ts`.

Both follow the canonical lightweight UI manifest derivation pattern: one core getter → one handler in `routes/workspace.ts` → one registration in `server.ts` → one access policy. No init, no persistence, no subsystem, no health check.

**Phase 168** is a documentation-only seal of Phases 166–167. Zero runtime source files changed.

**Counters after Phase 168:**

| Metric | Value |
|---|---|
| Endpoints | 143 |
| Policies | 143 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 (0 cycles) |
| HTML UI routes | 6 |
| Workspace UI API endpoints | 19 |
| BASELINE_LOCK.json | ep=59, hc=36, sub=26, graph=26 (frozen Phase 43) |

---

### Phase 169 — Internal Operator Context Lock

**Documentation-only.** Establishes Bulldozer's identity as a private internal AI Production Factory. Zero runtime source files changed. Zero counter changes.

#### Identity

Bulldozer Mother Core is a **private internal AI Production Factory**. It is not a consumer app, not a public SaaS product, and not an externally accessible service. The nucleus exists to manufacture AI-generated products for the operator, not to be a product itself.

#### Access model

| Actor | Access level | Notes |
|---|---|---|
| Owner / operator | Full (all roles) | Only party with direct nucleus access |
| Approved employees | Permission-limited | Role-based, minimum-privilege; write/execution access denied by default |
| Customers | None | Customers interact only with generated apps — separate products |
| AI agents | Tool-only, operator-scoped | No autonomous access to runtime state, routes, policies, or nucleus invariants |

#### Boundary rules

**Mother Core ↔ Generated apps:**
Generated apps are separate products. They have their own branding, domains, deployment pipelines, and lifecycles. Mother Core is the factory; generated apps are the output. Mother Core does not serve generated apps, and generated apps do not share nucleus state.

**App Factory (future):**
When the App Factory subsystem is built, it must:
- Run in a dedicated sandbox isolated from core runtime state
- Require explicit operator approval before each generation (approval-gated, not autonomous)
- Have no autonomous execution path — generation cannot be triggered without an operator decision
- Log every generation request to the audit log before execution begins

**AI integration:**
Any AI integration (language models, code generation, inference engines) must:
- Be explicitly scoped and operator-approved before activation
- Be isolated from runtime state mutation paths — AI cannot modify routes, policies, health checks, subsystem registry, dependency graph, or capability matrix
- Operate as a tool invoked by the operator, never as an autonomous actor
- Be absent from the nucleus startup path — no AI init on boot
- Produce output that the operator reviews before it enters any persistent store

#### What this phase locks permanently

1. Mother Core is private and internal — never public-facing without an explicit product launch phase
2. Customer access to Mother Core is prohibited by design — customers get generated apps only
3. All future employee access must go through the role/permission system already in the nucleus (`identityAccess.ts`, `accessEnforcement.ts`)
4. The App Factory, when built, must be sandboxed and approval-gated — this is a hard architectural constraint, not a preference
5. No uncontrolled AI inside the nucleus — AI is always a scoped, operator-controlled tool

---

### Phase 170 — Operator Access Architecture Blueprint

**Documentation-only.** Defines and seals the 4-tier internal access architecture before implementing Auth/Vault systems. Zero runtime source files changed. Zero counter changes.

#### Tier 1 — Root Operator

The Root Operator is the owner of the Bulldozer instance. Exactly one Root Operator exists per nucleus deployment.

| Capability | Granted |
|---|---|
| Full nucleus visibility | Yes — all endpoints, subsystems, runtime state, vault metadata, audit log |
| Deployment authority | Yes — can trigger deploys, rollbacks, environment promotions |
| Approval authority | Yes — approves App Factory generations, employee access grants, AI tool activations |
| Rollback authority | Yes — can revert to any checkpoint |
| Nucleus structure mutation | Yes — only role that can add endpoints, policies, subsystems in future execution-enabled phases |
| Vault secret values | Yes — can read and rotate secret values |

The Root Operator role must never be delegated to an employee, AI agent, or generated app. All Root Operator actions are recorded to the audit log.

#### Tier 2 — Internal Operators

Internal Operators are trusted internal staff with operational (not structural) access to the nucleus.

| Capability | Granted |
|---|---|
| Operational dashboards | Yes — full read access to all `/api/workspace/*` endpoints and `/ui/*` HTML dashboard |
| Monitoring | Yes — health checks, metrics, watchdog, freeze/crash detectors |
| Diagnostics | Yes — snapshot, timeline, events, diagnostics endpoints |
| Nucleus mutation | **No** — cannot add/modify endpoints, policies, subsystems, graph nodes, or health checks |
| Vault access | **No** — no access to secret values |
| App Factory generation | **No** — cannot trigger generations without explicit Root Operator delegation |
| Deployment authority | **No** — cannot deploy or rollback |

Mutation capability may be delegated to a specific Internal Operator by the Root Operator in a future phase, but only via an explicit role permission entry in `accessEnforcement.ts`.

#### Tier 3 — Employees

Employees are workspace participants with access limited to their assigned project scope.

| Capability | Granted |
|---|---|
| Project-scoped workspace | Yes — access to projects they are members of in the Project Registry |
| Cross-project visibility | **No** — cannot see projects they are not assigned to |
| Deployment authority | **No** |
| Vault access | **No** |
| App Factory access | **No** — unless explicitly granted by Root Operator with a scoped, time-limited delegation |
| Nucleus visibility | **No** — cannot access `/api/runtime/*`, `/api/access/*`, `/api/audit/*`, or `/ui/*` |

Employee access is governed entirely by the Project Registry (`projectRegistry.ts`) and its membership/role system. Cross-project visibility requires an explicit Root Operator grant recorded in the audit log.

#### Tier 4 — Generated Product Customers

Customers of generated apps have no relationship with Mother Core.

| Capability | Granted |
|---|---|
| Generated app access | Yes — isolated to their specific generated product |
| Mother Core API access | **Never** — no `/api/*` or `/ui/*` routes of Mother Core are exposed to customers |
| Mother Core data visibility | **Never** — generated apps are separate products with separate data boundaries |
| Cross-product visibility | **Never** — customers of product A cannot see product B |

If a generated app needs data derived from nucleus state, it must go through a dedicated, explicitly scoped, approval-gated gateway introduced in a future phase — not a direct nucleus API call.

#### Future Auth Layer — 5 Mandatory Constraints

All 5 constraints must be fully implemented before any real user access is granted to Mother Core. Shipping with any constraint missing is a critical violation.

| Constraint | Requirement |
|---|---|
| **RBAC mandatory** | Every access check — including read-only endpoints — validated against role-permission matrix before serving response. No public endpoints inside Mother Core. Replaces current observe-mode in `accessEnforcement.ts` with enforce-mode. |
| **Audit trails mandatory** | Every access check recorded to audit log with: actor identity, role, path, HTTP method, result (allowed/denied), timestamp. Audit log is append-only and tamper-evident. |
| **Session logging mandatory** | Every authenticated session recorded with: identity, role, session start, session end, actions performed. Session records are persisted and purgeable only by Root Operator. |
| **Sandbox execution mandatory** | All App Factory generations run in an isolated sandbox with no direct access to nucleus runtime state, file system, or network beyond the approved generation API. |
| **Tenant isolation mandatory** | Generated products and their customers are isolated from each other and from Mother Core. Tenant isolation is enforced at the data, network, and auth boundary — not just at the API layer. |

#### Access model summary

```
Root Operator
├── Full nucleus visibility
├── Deployment + rollback + approval authority
└── Grants access to ──► Internal Operators (read-only ops)
                   └──► Employees (project-scoped)
                   └──► [never] Customers

Generated Product Customers
└── Access to generated app only (separate product, separate auth, separate boundary)
    └── Never sees Mother Core
```

---

### Phase 171 — Employee Workspace Boundary Blueprint

**Documentation-only.** Defines how future employees work inside Bulldozer without accessing Mother Core. Zero runtime source files changed. Zero counter changes.

#### 1. Employee Workspace

| Property | Value |
|---|---|
| Scope | Project-scoped only — limited to projects the employee is a member of in the Project Registry |
| Nucleus access | None — no access to any nucleus API (`/api/runtime/*`, `/api/access/*`, `/api/audit/*`, `/api/workspace/*`) |
| Global dashboard access | None — `/ui/*` operator dashboard routes are inaccessible to employees |
| Vault access | None — no secret values, no vault metadata |
| Deployment authority | None — employees cannot trigger deploys, rollbacks, or environment promotions |
| Cross-project visibility | None — employees cannot see projects they are not assigned to |

The employee workspace is strictly a sandboxed project-level environment. Its ceiling is the individual project; the floor is an isolated sandbox with no live system access.

#### 2. Employee Task Flow

```
Operator assigns task
       │
       ▼
Employee receives task in Project Workspace
       │
       ▼
Employee works inside sandbox (edits drafts, assets, code)
       │
       ▼
Employee submits result to Approval Queue
       │
       ▼
Operator reviews submission
       │
       ├─ Reject ──► rejection recorded in audit log; employee notified; work returned
       │
       └─ Approve ──► approval recorded in audit log
               │
               ▼
       Operator deploys (separate, explicit operator action)
               │
               ▼
       Deployment recorded in audit log
```

Key invariants:
- No step between employee submission and live deployment can be automated or bypassed
- Employee cannot self-approve or self-deploy
- Operator approval and operator deploy are separate explicit actions — approval does not trigger deploy
- Rejection does not delete the submission — it returns it to the employee for revision

#### 3. Employee Permissions

| Action | Permitted |
|---|---|
| Read own assigned project | Yes |
| Edit drafts / assets / code inside own sandbox | Yes |
| Submit work to Approval Queue | Yes |
| Modify routes (`server.ts`, `router.ts`) | **Never** |
| Modify access policies (`accessEnforcement.ts`) | **Never** |
| Modify core modules (`core/*.ts`) | **Never** |
| Modify health check configuration | **Never** |
| Add / modify subsystems | **Never** |
| Add / modify graph nodes | **Never** |
| Read other employees' project workspaces | **Never** |
| Read the Approval Queue | **Never** |
| Trigger deployments | **Never** |
| Access vault | **Never** |

All "Never" permissions are structural prohibitions enforced at the future Auth Layer RBAC matrix — not policy recommendations.

#### 4. Audit Requirements

| Event | Required fields |
|---|---|
| Task received | employeeId, projectId, taskId, timestamp |
| File read | employeeId, projectId, filePath, timestamp |
| File edit | employeeId, projectId, filePath, changeSummary, timestamp |
| Work submitted | employeeId, projectId, taskId, submissionId, timestamp |
| Submission approved | operatorId, submissionId, employeeId, projectId, timestamp |
| Submission rejected | operatorId, submissionId, employeeId, projectId, rejectionReason, timestamp |
| Deployment triggered | operatorId, submissionId, deploymentId, environment, timestamp |

Audit records are append-only, attributed to a specific identity, and purgeable only by the Root Operator. Employees cannot modify or delete their own audit trail.

#### 5. Future UI Implications

| Surface | Route namespace | Accessible to |
|---|---|---|
| Operator Dashboard | `/ui/*` (current) | Root Operator, Internal Operators |
| Employee Dashboard | Separate — not under `/ui/*` | Employees (own projects only) |
| Project Workspace | Sandboxed per project | Assigned employees |
| Approval Queue UI | Operator-only surface | Root Operator, delegated Internal Operators |
| Generated App UIs | Separate products, separate deployments | Customers of each app only |

Implementation rules:
- Employee Dashboard must use a separate route namespace — never under `/ui/*`
- Employee auth tokens must be rejected by Mother Core `/ui/*` routes at the RBAC layer
- Project Workspace is isolated per project — no cross-workspace navigation
- Approval Queue is never visible to employees — not even as an empty list

---

### Phase 172 — Generated Product Isolation Blueprint

**Documentation-only.** Defines how future generated apps/products remain isolated from Mother Core and from each other. Zero runtime source files changed. Zero counter changes.

#### 1. Product Isolation

Every generated app is a fully independent unit. No resource is shared with Mother Core or with any other generated app.

| Property | Requirement |
|---|---|
| Runtime | Separate process per product — no shared runtime, no shared memory |
| Domain | Separate domain or subdomain per product |
| Storage | Separate storage boundary — no access to nucleus storage paths (`/storage/snapshots`, `/storage/runtime-state`, `/storage/store/*`) |
| Auth | Separate auth system and credential namespace per product — Mother Core credentials are never valid inside a generated app |
| Deployment lifecycle | Separate deploy target, separate CI/CD pipeline, separate rollback scope |

There is no "lightweight" or "shared runtime" variant of a generated app. Partial isolation is not permitted.

#### 2. Mother Core Separation

| Boundary | Rule |
|---|---|
| Route exposure | Generated apps never expose Mother Core APIs — no `/api/runtime/*`, `/api/workspace/*`, `/api/access/*`, or any nucleus route in a generated app's route table |
| Route sharing | No direct route sharing — generated app routes and nucleus routes are separate namespaces with no overlap |
| Database sharing | No direct database sharing — generated apps cannot read or write nucleus storage |
| Auth token sharing | No shared tokens — Mother Core tokens are never issued to generated apps or customers; generated app tokens are never valid in Mother Core |
| Nucleus data access | Nucleus data reaches a generated app only through a future approval-gated fleet gateway — never via direct API call |

#### 3. Product Deployment Flow

```
Generation in sandbox (isolated, no live system access)
       │
       ▼
Operator reviews generated output
       │
       ├─ Reject ──► rejection recorded; generation returned; sandbox cleared
       │
       └─ Approve ──► deployment package assembled (audit logged)
               │
               ▼
       Package deployed to isolated target (audit logged)
               │
               ▼
       Post-deployment monitoring begins (fleet APIs only)
               │
               ▼
       Monitoring recorded in fleet audit log
```

Every step is gated. No step can be skipped or automated without an explicit future phase that introduces the capability and records it in ARCHITECTURE.md, NUCLEUS_LOCK.md, and the audit log. Generation sandbox is cleared after review regardless of outcome.

#### 4. Cross-Product Isolation

Tenant isolation is total. Product A cannot see any data, state, or identity belonging to Product B.

| Isolation boundary | Requirement |
|---|---|
| Logs | Separate log stream per product — no shared log aggregation endpoint that leaks cross-product data |
| Secrets | Separate secrets namespace per product — no shared vault, no shared secret identifiers |
| Quotas | Separate quota ledger per product — quota usage of product A is invisible to product B |
| API access | No inter-product API calls — product A cannot query product B's endpoints directly or indirectly |
| Monitoring | Monitoring endpoints must not leak cross-product counters, identifiers, or status |

Indirect isolation violations (e.g. a shared metrics endpoint that leaks product B's request count to product A) are treated the same as direct violations.

#### 5. Future Fleet Layer

The Fleet Layer is the only channel through which Mother Core observes running generated products.

| Concept | Definition |
|---|---|
| Fleet monitoring | Read state via fleet APIs — health, status, quota consumption, error rates |
| Fleet monitoring scope | Read-only observation only — no code execution, no state mutation, no customer data access |
| Fleet actions | Any fleet action beyond read-only observation requires explicit operator approval |
| Fleet audit | Every fleet action — read or write — is recorded in the fleet audit log with: operatorId, productId, action, timestamp, outcome |
| Fleet ≠ execution | The Fleet Layer observing a product is not the same as executing code inside it. These must remain permanently separate capabilities |

The Fleet Layer is a future phase. When implemented, it must not collapse the monitoring boundary into an execution boundary. Mother Core monitoring a product's health status is categorically different from Mother Core running code inside that product.

---

### Phase 173 — Theme Control Blueprint

**Documentation-only.** Defines the future theme/color control system for the Operator Dashboard and generated products. Zero runtime source files changed. Zero counter changes.

#### 1. Theme Ownership

| Actor | Authority |
|---|---|
| Root Operator | Controls Mother Core theme — full authority over all nucleus UI surfaces |
| Internal Operators | Can propose theme changes; production changes require Root Operator approval |
| Employees | Cannot change Mother Core theme; workspace-level preference scoped to Employee Workspace surface only |
| Generated product owners | Control their product's theme — entirely separate scope, no effect on Mother Core |

#### 2. Theme Scope

Five independent scopes with no shared inheritance chain and no cross-scope cascade:

| Scope | Surface |
|---|---|
| Mother Core theme | Nucleus API behavior, internal tooling, structural identity |
| Operator Dashboard theme | `/ui/*` HTML dashboard pages — current operator-facing UI |
| Employee Workspace theme | Future Employee Dashboard surface — separate route namespace |
| Generated Product theme | Customer-facing generated app — full branding freedom within safety rules |
| Client/brand theme | Per-client branding layer within a generated product |

Changing one scope must never affect another. There is no "inherit from parent scope" behavior. Each scope is defined and applied independently.

#### 3. Theme Controls

| Control | Options / Format |
|---|---|
| Base mode | `light` / `dark` / `system` |
| Primary color | Hex or HSL token — used for primary actions, active states, links |
| Secondary color | Hex or HSL token — used for secondary actions, accents |
| Success color | Semantic token — confirmation, healthy state indicators |
| Warning color | Semantic token — degraded state, caution indicators |
| Danger color | Semantic token — error state, destructive action indicators |
| Card style | `flat` / `bordered` / `elevated` |
| Density | `compact` / `comfortable` / `spacious` |
| Text direction | `LTR` / `RTL` |

All controls produce static, declarative token values. No control value may contain executable code, CSS `url()` references to external hosts, or dynamic expressions evaluated at render time.

#### 4. Safety Rules

| Rule | Requirement |
|---|---|
| No external assets by default | All theme tokens, fonts, and icons must be self-contained — no external CDN or remote host dependencies |
| No remote CSS | No `@import url(...)` to external hosts at runtime — all stylesheets must be bundled or inlined |
| No scriptable themes | No CSS-in-JS engines that execute arbitrary JavaScript to produce styles — theme definitions must be static and auditable |
| Audit on every change | Every theme change — including development and staging — must produce an audit record: actor, scope, tokens changed, timestamp |
| Production approval required | Production theme changes require explicit operator approval before the change is applied — unapproved production theme changes are policy violations |

#### 5. Future UI Direction

- **Visual Theme Settings page** — a dedicated operator-only page (future phase) for browsing and editing theme tokens across all scopes; accessible only to Root Operator and delegated Internal Operators
- **White/gray base with colored details** — canonical direction for the Operator Dashboard: neutral base (white or light gray in light mode; dark gray or near-black in dark mode) with color confined to accents, status indicators, and primary actions; high-saturation full-background themes are prohibited for Mother Core
- **Per-product branding** — generated products may use custom color palettes, logos, typefaces, and layout densities within their own theme scope and within safety rules; this freedom is for customer-facing surfaces, not Mother Core
- **Mother Core identity stays separate from generated apps** — the Operator Dashboard must always be visually distinguishable from any generated product; generated app branding must not bleed into the Operator Dashboard surface

---

### Phase 174 — Operator Dashboard Light Theme Preview

**Documentation-only.** Read-only visual preview plan for converting the Operator Dashboard to a white/gray base with colored details. Preview only — no HTML, CSS, or TypeScript files changed. Zero counter changes.

#### 1. Light Theme Palette

| Token | Value / Direction |
|---|---|
| Background | White or near-white (`#ffffff` / `#f8f9fa`) |
| Panels | Soft gray (`#f1f3f5` / `#e9ecef`) |
| Borders | Light gray (`#dee2e6` / `#ced4da`) |
| Text | Near-black (`#212529`) |
| Muted text | Slate gray (`#6c757d`) |
| Accents | Colored only for page identity and state indicators — not for structural elements |

Structural elements (topbar background, sidebar background, table rows, card backgrounds) use only the neutral palette above. Accent color appears exclusively in page-identity indicators (active nav link, card border stripe, section heading) and state badges.

#### 2. Accent Mapping

| Surface / State | Accent color |
|---|---|
| Overview page | Indigo |
| Governance page | Blue |
| Observation page | Pink / Magenta |
| Diagnostics page | Orange |
| Comparison page | Teal |
| Success state | Green |
| Warning state | Amber |
| Danger state | Red |

Page accents and semantic state colors are two distinct categories. A page accent identifies which dashboard surface the operator is on. A semantic color indicates the health or outcome of a system event. These must never be swapped or mixed.

#### 3. UI Areas to Convert

All 7 areas must be converted together in the implementation phase. Partial conversion is a visual consistency violation.

| UI area | What changes |
|---|---|
| Topbar | Background → white/near-white; text → near-black; active-page indicator uses page accent |
| Sidebar | Background → soft gray; nav link active state uses page accent stripe; hover state uses light border |
| Metric cards | Card background → white; border → light gray; value uses near-black; label uses muted text |
| Navigation cards | Card background → white; hover state adds soft shadow; page-accent border stripe or icon tint |
| Tables | Header background → soft gray; row background → white; border → light gray; hover row uses near-white tint |
| Audit blocks | Block background → soft gray; attribution text → muted; timestamp → muted |
| Status badges | Background and text color per semantic state: green/amber/red with appropriate contrast |

#### 4. Safety Rules

| Rule | Requirement |
|---|---|
| No external images | All icons and decorative assets must be inlined SVG or bundled — no external image URLs |
| No remote CSS | No `@import url(...)` to external hosts — all styles bundled or inline |
| No JS | Theme applied via static CSS custom properties only — no runtime computation |
| No runtime theme switch | Light theme is the new fixed default; a user-controlled light/dark toggle is a future phase |
| Preview only | This phase is a specification; implementation begins in a dedicated future phase |

---

### Phase 175 — Operator Dashboard Light Theme Implementation

**Runtime phase.** Converted all 6 Operator Dashboard HTML pages from dark theme to white/gray base with colored accents. Three source files changed: `uiShell.ts`, `uiOverviewPage.ts`, `uiDashboardPages.ts`. All 7 UI areas converted atomically. Zero counter changes.

#### Files Changed

| File | Change |
|---|---|
| `src/core/uiShell.ts` | `ACCENT` → `#6366f1`; `PAGE_ACCENTS` updated to light palette; `buildCss()` fully rewritten |
| `src/core/uiOverviewPage.ts` | `ACCENT` → `#6366f1`; `buildCss()` fully rewritten; fallback `style=` updated to `#6c757d` |
| `src/core/uiDashboardPages.ts` | `PAGE_META` accents updated; `buildCss()` fully rewritten; fallback `style=` updated to `#6c757d` |

#### Light Theme Palette Applied

| Token | Value |
|---|---|
| Body background | `#f8f9fa` |
| Topbar | `#ffffff` bg · `#dee2e6` border · `#212529` text |
| Sidebar | `#f1f3f5` bg · `#dee2e6` border · `#495057` links |
| Metric cards | `#ffffff` bg · `#dee2e6` border · 2 px accent top border |
| Navigation / panel cards | `#ffffff` bg · `#dee2e6` border · accent bar |
| Tables | `#f1f3f5` thead · `#dee2e6` th border · `#e9ecef` td border · `#495057` text |
| Audit blocks | `#ffffff` bg · `#dee2e6` border |
| Status badges | `.ro` green `#16a34a` · `.eb` / `.eb-chip` red `#dc2626` |
| Muted text | `#6c757d` throughout |

#### Accent Map Applied

| Page | Accent | Hex |
|---|---|---|
| UI Shell | Indigo | `#6366f1` |
| Overview | Indigo | `#6366f1` |
| Governance | Blue | `#3b82f6` |
| Observation | Pink / Magenta | `#d946ef` |
| Diagnostics | Orange | `#f97316` |
| Comparison | Teal | `#14b8a6` |

Semantic state colors are page-agnostic: Success = `#16a34a`, Danger / Exec-Blocked = `#dc2626`.

#### Design Rules Enforced

- `buildCss(accent)` is the single source of truth for all page CSS — no inline overrides in template strings
- Sidebar dot colors (`.sb-dot.gov/obs/diag/cmp`) are hardcoded per-class; they are independent of the `accent` parameter because all 6 sidebar links are always visible on every page
- Semantic colors do not vary by page accent — they are fixed on all 6 pages
- CSP unchanged: `default-src 'none'; style-src 'unsafe-inline'` — no external assets, no scripts
- 0 `<script>` tags, 0 `<form>` tags across all 6 pages

---

### Phase 176 — Light Theme Seal & Visual QA

**Documentation-only.** Officially seals the Phase 175 light theme after a full automated visual QA pass. Zero runtime source files changed. Zero counter changes.

#### Visual QA Results

| Check | Result |
|---|---|
| All 6 HTML routes | HTTP 200 |
| CSP header (all 6) | `default-src 'none'; style-src 'unsafe-inline'` |
| `<script>` tags | 0 on every page |
| `<form>` tags | 0 on every page |
| `<button>` tags | 0 on every page |
| White background (`#ffffff`) in CSS | 5–7 occurrences per page |
| Gray background (`#f8f9fa` / `#f1f3f5`) in CSS | 4–5 occurrences per page |
| Dark background token remnants | None — 0 dark hex values in rendered HTML |
| Typecheck | Clean — 0 errors |
| `allHealthy` | true |
| Graph cycles | 0 |

#### Accent Confirmation

| Page | Accent | Hex | Occurrences in rendered HTML |
|---|---|---|---|
| `/ui` (UI Shell) | Indigo | `#6366f1` | 9 |
| `/ui/overview` | Indigo | `#6366f1` | 9 |
| `/ui/governance` | Blue | `#3b82f6` | 10 |
| `/ui/observation` | Pink / Magenta | `#d946ef` | 10 |
| `/ui/diagnostics` | Orange | `#f97316` | 10 |
| `/ui/comparison` | Teal | `#14b8a6` | 10 |

The 9 vs 10 count difference is structural and expected: UI Shell and Overview use a `PAGE_ACCENTS` lookup for the page card bar, so their accent appears once fewer in the `buildCss(accent)` context than the four dashboard pages, which pass `meta.accent` directly.

#### Sealed State

- **Dark theme is retired as of Phase 175** — do not restore it.
- **Any future re-theme requires a new explicit phase + a new seal phase.**
- **The Phase 174 palette and Phase 175 accent map are the canonical token references** for all future Operator Dashboard theming work.
- **All 7 UI areas remain converted:** topbar · sidebar · metric cards · navigation/panel cards · tables · audit blocks · status badges.
- **Production readiness: 100%** — no open theming regressions, no dark token remnants, no JS, no forms, all routes healthy.

---

### Phase 177 — Auth Layer Blueprint

**Documentation-only.** Defines the future authentication layer before any implementation begins. Eight sections sealed. Zero runtime source files changed. Zero counter changes.

#### 1. Root Operator Login

| Property | Rule |
|---|---|
| Account type | Single root account |
| Credential grade | Hardware-key-grade (TOTP minimum; FIDO2/WebAuthn preferred) |
| Access scope | Full Mother Core — all nucleus APIs, all `/ui/*` routes, all admin operations |
| Delegation | Cannot delegate root-level access; Internal Operators receive explicit scoped grants only |
| Audit | Every login, logout, and failed attempt recorded with actor, timestamp, IP, outcome |

#### 2. Internal Operator Login

| Property | Rule |
|---|---|
| Account type | Named accounts, created and revoked by Root Operator |
| Credential grade | Strong password + TOTP second factor minimum |
| Access scope | Scoped to capabilities explicitly granted by Root — no implicit access |
| Session binding | Permissions evaluated at session start; privilege changes invalidate session immediately |
| Audit | Every action (not just login) recorded |

#### 3. Employee Login

| Property | Rule |
|---|---|
| Account type | Named accounts, created per-project by an Operator |
| Credential grade | Strong password + TOTP second factor minimum |
| Access scope | Project-scoped sandbox only — assigned projects' sandbox environment |
| Prohibited surfaces | Cannot access `/ui/*`; cannot access any `/api/*` nucleus endpoint |
| Audit | Every action, file change, submission, and approval event recorded |

#### 4. Customer / Product Login Separation

- Customer auth lives entirely in the generated product layer — Mother Core never handles customer credentials
- Mother Core does not receive, validate, store, or proxy customer passwords, tokens, or session cookies
- If a Mother Core route needs customer context it receives a bounded claim (e.g., project ID) — never raw credentials
- Customer session stores, password reset flows, and OAuth integrations are per-product concerns, fully isolated from Mother Core

#### 5. Session Rules

| Rule | Requirement |
|---|---|
| Token lifetime | Short-lived — no permanent session cookies on Mother Core |
| Invalidation triggers | Logout · privilege change · password reset · revocation |
| Concurrent sessions | Enforced limit per actor type (Root: 1 · Internal Operator: configurable · Employee: configurable) |
| Storage | Server-side session store — tokens are opaque references, not self-contained JWTs carrying permissions |
| Transmission | HTTPS only — no credential or session token over plaintext |

#### 6. Audit Logging Requirements

Every auth event must produce an append-only, tamper-evident audit record:

| Field | Content |
|---|---|
| Actor identity | Username / actor ID |
| Actor type | Root Operator / Internal Operator / Employee / Service |
| Event type | login · logout · failure · escalation · revocation · session-expire |
| Timestamp | ISO 8601 UTC |
| IP address | Request origin |
| Outcome | success / failure + reason |

Silent auth events — events that produce no audit record — are implementation violations.

#### 7. Access Prohibitions

| Prohibition | Rule |
|---|---|
| No anonymous Mother Core access | Every request to every `/api/*` and `/ui/*` must carry a verified credential after auth is live |
| No employee access to `/ui/*` | Employee sessions must never grant access to the Operator Dashboard or any nucleus endpoint |
| No customer access to Mother Core | No customer credential or session may reach any Mother Core route |
| No public read mode | No "read-only public" mode for Mother Core — internal probes use a service key, not anonymous access |

#### 8. Implementation Ordering

The auth layer must be **fully implemented and verified before any VPS or private server migration begins.** This is a hard ordering constraint. Moving Mother Core to a VPS without auth would expose all 143 endpoints publicly without any credential gate. This constraint may not be overridden by a convenience or timeline argument.

---

### Phase 178 — Vault & Secrets Blueprint

**Documentation-only.** Defines the future Vault/Secrets layer before any implementation begins. Five sections sealed. Zero runtime source files changed. Zero counter changes.

#### 1. Secret Types

| Secret Type | Description | Scope |
|---|---|---|
| API keys | Third-party service API credentials (payment, email, SMS providers, etc.) | Per-service, Root/Operator managed |
| Database URLs | Connection strings including credentials for all databases | Per-environment, Root managed |
| Signing keys | Keys for token signing, payload verification, HMAC | Per-subsystem, Root managed |
| Service tokens | Inter-service auth tokens for nucleus ↔ product communication | Per-service-pair, short TTL |
| Deployment credentials | Cloud provider keys, registry tokens, SSH keys used during deployment | Per-deployment, revoked after use |
| Employee/product scoped secrets | Project-scoped tokens for employee sandboxes and generated product runtimes | Per-project, Operator managed |

#### 2. Access Rules

| Actor | Vault Access |
|---|---|
| Root Operator | Full — create, read, rotate, revoke any secret |
| Internal Operator | Request-only — read access to specific named secrets with Root approval; no create, no revoke |
| Employee | None — no direct vault access at any scope |
| Generated product | Receives only scoped runtime secrets injected at boot — never queries the vault itself |
| Customer | None — no path to any Mother Core secret |

#### 3. Storage Rules

| Rule | Requirement |
|---|---|
| No secrets in source code | Unconditional — no secret value in any `.ts`, `.js`, `.json`, `.toml`, `.yaml`, or any committed file |
| No secrets in logs | Structured JSON logs must never include secret values, even partially or truncated |
| No secrets in documentation | No real secret values in any doc file — placeholder labels only (e.g., `sk-xxxx`) |
| Encrypted at rest | All stored values encrypted using a root key — plaintext storage is an implementation violation |
| Rotated regularly | Every secret type has a defined rotation policy; unrotated secrets past policy TTL treated as compromised |

#### 4. Usage Rules

| Rule | Requirement |
|---|---|
| Runtime injection only | Secrets injected at process start via env var or vault API call — never baked into build artifacts |
| Access audited | Every vault read, rotation, and revocation produces an audit record (actor, key name, event type, timestamp, outcome) |
| Expiration required | Every secret must have an explicit expiry — secrets without an expiry date are an implementation violation |
| Least privilege required | Each consumer receives only the specific secret(s) it needs — no broad vault access grants |
| Revocation required | Revocation must be immediate and complete — invalidated at source, cached copies expired; a revoked secret that still functions is a violation |

#### 5. Migration Ordering Constraints

| Constraint | Rule |
|---|---|
| Vault before VPS | Vault layer must be fully implemented and verified before any VPS or private server migration begins |
| Auth before Vault UI | Any Vault management UI must not be built until the Phase 177 Auth layer is fully implemented and enforced |

The Vault-before-VPS constraint exists because deploying Mother Core to a VPS without a functioning Vault would require embedding secrets in unaudited host-level environment files — creating an unrevocable secret surface outside the audit trail. The Auth-before-Vault-UI constraint exists because a Vault management UI without an auth gate would expose secret rotation and revocation controls to unauthenticated requests.

---

### Phase 179 — Rate Limiting & Abuse Guard Blueprint

**Documentation-only.** Defines the future rate limiting and abuse guard layer before any implementation begins. Five sections sealed. Zero runtime source files changed. Zero counter changes.

#### 1. Rate Limit Scopes

| Scope | Keyed By | Purpose |
|---|---|---|
| Per-IP | Request origin IP | Guards against unauthenticated flooding, scanning, and credential stuffing from a single source |
| Per-session | Authenticated session ID | Guards against a single authenticated session making bulk or automated requests |
| Per-operator | Internal Operator actor ID | Guards against operator-level bulk operations or misconfigured automation |
| Per-employee | Employee actor ID | Enforces strict project-scoped usage; employees have the tightest limits |
| Per-service-token | Service token identity | Guards against a compromised or misconfigured service token flooding nucleus APIs |
| Per-generated-product | Product / project identity | Guards against a generated product runtime making excessive calls to Mother Core service endpoints |

All scopes are **additive** — a request is counted against every applicable scope simultaneously. If any scope triggers, the request is rejected.

#### 2. Protected Surfaces

| Surface | Rate Limit Requirement |
|---|---|
| `/ui/*` | Per-IP + per-session; Operator-grade limits |
| `/api/*` (all nucleus APIs) | Per-IP + per-session + per-actor-class; surface-specific limits |
| Auth routes | Per-IP with aggressive burst limits; failed-login lockout separate |
| Vault routes | Per-IP + per-operator; lowest burst allowance of any surface |
| Future app factory routes | Per-operator + per-product; factory operations are heavyweight, strict limits |
| Fleet routes | Per-operator; fleet operations are privileged and high-risk, strict limits |

No surface may be left unmetered after the rate limiting layer is implemented.

#### 3. Abuse Controls

| Control | Rule |
|---|---|
| Request burst limits | Maximum requests per short window per scope; configurable per surface |
| Daily quotas | Maximum requests per 24-hour rolling window per actor |
| Failed login lockout | N failures → progressive exponential back-off → hard block after threshold; hard block emits audit event |
| Suspicious pattern detection | Repeated 404 scanning, sequential enumeration, rapid credential rotation — flagged and audit-logged |
| Temporary block | Automated blocks are time-bounded (configurable TTL); Root Operator applies permanent manual blocks |
| Audit event on limit hit | Every limit trigger: actor · scope · route · timestamp · limit value · current count · block duration |

#### 4. Actor Differences

| Actor | Rate Limit Treatment |
|---|---|
| Root Operator | Highest permitted rates — but every request counted and every limit hit audit-logged; not unlimited |
| Internal Operators | Normal operational limits — sufficient for interactive use and scripted ops; anomalies flagged |
| Employees | Strict project-scoped limits — tightest of all authenticated actors |
| Service tokens | Scoped per-token limits — a compromised token cannot exhaust global capacity |
| Customers | Rate limited only inside generated products — Mother Core meters service tokens, not customer identities |

#### 5. Migration Ordering Constraint

Rate limiting must be **fully implemented and verified before any VPS or private server exposure.** An unmetered public endpoint on a VPS is simultaneously a DoS surface, a credential-stuffing surface, and a vault-enumeration surface.

**Full pre-VPS ordering chain (cumulative):**

1. Auth layer implemented and verified (Phase 177 model)
2. Vault layer implemented and verified (Phase 178 model)
3. Rate limiting implemented and verified (Phase 179 model)
4. VPS / private server migration may begin

---

### Phase 180 — Auth Enforcement Skeleton

**Runtime phase.** Created `core/authModel.ts` — the observe-only auth classification skeleton. 1 source file created, 0 source files modified. No endpoints, no policies, no health checks, no subsystem registration. All counters unchanged.

#### File: `core/authModel.ts`

Pure module — no init function, no side effects at load, no subsystem registration, no health check registration, no event emission.

**Types:**

| Type | Definition |
|---|---|
| `AuthActorType` | `"root_operator" \| "internal_operator" \| "employee" \| "customer" \| "service_token" \| "anonymous"` |
| `AccessTier` | `1 \| 2 \| 3 \| 4` |
| `AuthRequest` | `{ method: string; path: string; actorType?: string }` |
| `AuthDecision` | `{ allowed: boolean; actorType: AuthActorType; tier: AccessTier \| null; reason: string; observeOnly: true; evaluatedAt: string }` |
| `AuthModelStatus` | Status snapshot — subsystemName, observeOnly, enforcing, actorTypeCount, actorTypes, accessTierCount, authEnabled, implementationPhase, note |

**Access tier map (Phase 170 blueprint):**

| Tier | Label | Nucleus | `/ui/*` | Vault |
|---|---|---|---|---|
| 1 | Root Operator (`root_operator`) | ✓ | ✓ | ✓ |
| 2 | Internal Operators (`internal_operator`) | ✓ | ✓ | ✗ |
| 3 | Employees (`employee`) | ✗ | ✗ | ✗ |
| 4 | Generated Product Customers (`customer`) | ✗ | ✗ | ✗ |
| — | `service_token`, `anonymous` — ungrouped, `tier: null` | — | — | — |

**Functions:**

- `resolveActorType(raw)` — normalises raw string → `AuthActorType`; unknown → `anonymous`
- `resolveAccessTier(actorType)` — maps actor type → `AccessTier | null`; `service_token` and `anonymous` → `null`
- `evaluateAuthObserveOnly(req)` — always `allowed: true`; `reason` records what enforcement would decide; `observeOnly: true` literal
- `listAuthActorTypes()` — returns sealed `readonly AuthActorType[]`
- `listAccessTiers()` — returns sealed `readonly AccessTierDefinition[]`
- `getAuthModelStatus()` — returns `AuthModelStatus` snapshot

**Design invariants:**
- `observeOnly: true` is a TypeScript literal type — impossible to construct an observe-mode `AuthDecision` with `observeOnly: false`
- `evaluateAuthObserveOnly` never blocks — the `allowed` field is unconditionally `true`
- `AuthActorType` coexists with the legacy `identityAccess.ts` `ActorType` — no migration in this phase
- Module is not wired into `runtime.ts` — no `initAuthModel()` call exists or is needed

---

### Phase 181 — Auth Route Classification Map

**Runtime phase.** Created `core/authRouteMap.ts` — pure observe-only route classification map. 1 source file created, 0 source files modified. No endpoints, no policies, no health checks, no subsystem registration. All counters unchanged.

#### File: `core/authRouteMap.ts`

Pure module — no init function, no side effects at load, no subsystem registration, no health check registration, no event emission.

**Route category map:**

| Category | Required Tier | Current Patterns | Status |
|---|---|---|---|
| `mother_core_ui` | `internal_operator_or_root` | `/ui` prefix (covers `/ui`, `/ui/*`) | Active |
| `mother_core_api` | `internal_operator_or_root` | `/api/` prefix (covers all `/api/*`) | Active |
| `employee_workspace` | `employee_project_scope` | *(none — future route namespace)* | Future |
| `generated_product` | `product_customer_scope` | *(none — future route namespace)* | Future |
| `public` | `none` | *(none — no public Mother Core routes exist)* | No routes |

**Functions:**

- `classifyAuthRoute(path)` — strips query/fragment, applies first-match-wins prefix matching, falls back to operator-grade default for unrecognised paths; always returns `observeOnly: true`
- `getAuthRouteMapSummary()` — returns `AuthRouteMapSummary` snapshot
- `listRouteCategories()` — returns sealed `readonly RouteCategory[]`
- `listCategoryDefinitions()` — returns sealed `readonly CategoryDefinition[]`

**Design invariants:**
- `CATEGORY_DEFINITIONS` order is significant — first match wins; `mother_core_ui` evaluated before `mother_core_api`
- Unrecognised paths default conservatively to `mother_core_api` / `internal_operator_or_root` — never to `public`
- `employee_workspace` and `generated_product` have empty pattern arrays; they cannot be matched until a future phase adds patterns
- `RouteClassification.observeOnly` is the literal type `true` — not a boolean
- No public Mother Core routes exist or are planned; `public` category is model-completeness only

---

### Phase 182 — Auth Decision Composer

**Runtime phase.** Created `core/authDecisionComposer.ts` — pure observe-only composition layer that joins actor classification (`authModel`) with route classification (`authRouteMap`) into a single `AuthCompositeDecision`. 1 source file created, 0 source files modified. No endpoints, no policies, no health checks, no subsystem registration. All counters unchanged.

#### File: `core/authDecisionComposer.ts`

Pure module — imports from `authModel` and `authRouteMap` only. No init, no subsystem registration, no health check registration, no event emission.

**`AuthCompositeDecision` fields:**

| Field | Type | Description |
|---|---|---|
| `allowed` | `boolean` | Always `true` in observe mode |
| `actorType` | `AuthActorType` | Resolved from raw input via `resolveActorType` |
| `tier` | `AccessTier \| null` | Phase 170 tier for actor; `null` for `service_token` / `anonymous` |
| `routeCategory` | `RouteCategory` | From `classifyAuthRoute` |
| `requiredTier` | `RequiredTier` | Required tier for the matched route category |
| `reason` | `string` | `"observe:"` or `"observe-warn:"` prefix + enforcement narrative |
| `observeOnly` | `true` | Literal type — not boolean |
| `evaluatedAt` | `string` | ISO 8601 timestamp |

**Reason classification:**

| Actor | Mother Core surface | Reason |
|---|---|---|
| `anonymous` | ✓ | `observe-warn:` — would be denied, no credentials |
| `customer` | ✓ | `observe-warn:` — customer boundary violation |
| `employee` | ✓ | `observe-warn:` — employee workspace only |
| `root_operator` | ✓ | `observe:` — full access, would be allowed |
| `internal_operator` | ✓ | `observe:` — would be evaluated against capability grant |
| `service_token` | ✓ | `observe:` — would be evaluated against token scope |
| Any | Non-MC surface | `observe:` — future surface, no enforcement model yet |

**Design invariants:**
- `allowed` is unconditionally `true` — `observe-warn` in `reason` is informational only
- `AuthCompositeDecision.observeOnly` is the literal type `true`
- Both dependencies (`evaluateAuthObserveOnly`, `classifyAuthRoute`) are called on every invocation — both are pure, no caching needed in this phase
- Not wired into `runtime.ts` — no `initAuthDecisionComposer()` call

---

### Phase 183 — Auth Observe Status API

**Runtime phase.** Created `routes/authObserveStatus.ts` and registered `GET /api/auth/observe-status`. Read-only diagnostic endpoint that surfaces the state of the three-file observe-only auth stack. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/auth/observe-status`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/auth/observe-status` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `observeOnly` | `true` | Literal — entire stack is observe-only |
| `authStackReady` | `true` | Literal — all 3 modules loaded |
| `executionBlocked` | `true` | Literal — no execution capability |
| `modules.authModel` | object | Status from `getAuthModelStatus()` |
| `modules.authRouteMap` | object | Status from `getAuthRouteMapSummary()` |
| `modules.authDecisionComposer` | object | Status from `getAuthComposerStatus()` |
| `sampleDecisions` | `AuthCompositeDecision[]` | 5 fresh decisions at request time |

**Sample decision actors/paths:**
- `anonymous` on `/ui` → `observe-warn:`
- `employee` on `/ui` → `observe-warn:`
- `customer` on `/api/workspace/ui/audit` → `observe-warn:`
- `internal_operator` on `/ui` → `observe:` allowed
- `root_operator` on `/api/workspace/ui/audit` → `observe:` allowed

**Design invariants:**
- Pure passive read — not wired into middleware, blocking paths, or session logic
- `composeAuthDecision` called fresh per request (timestamps are live)
- Access policy: `monitor` + `operator` — same tier as watchdog, hardening, restart-supervisor

---

### Phase 184 — Auth Observe Seal & Compaction

**Documentation-only.** Sealed the four-file observe-only auth stack built across Phases 180–183. Zero runtime source files changed. All counters unchanged.

#### Sealed stack summary

| Phase | File | Role |
|---|---|---|
| 180 | `core/authModel.ts` | Actor classifier — `AuthActorType`×6, `AccessTier`×4, `evaluateAuthObserveOnly` |
| 181 | `core/authRouteMap.ts` | Route classifier — `RouteCategory`×5, `RequiredTier`×4, `classifyAuthRoute` |
| 182 | `core/authDecisionComposer.ts` | Composition — `AuthCompositeDecision`, `composeAuthDecision` |
| 183 | `routes/authObserveStatus.ts` | Diagnostic endpoint — `GET /api/auth/observe-status` |

#### Sealed invariants

1. `observeOnly: true` is always a TypeScript literal — never a plain boolean, anywhere in the stack
2. `allowed` is always `true` — no decision in the observe stack blocks any request
3. No credentials, passwords, or session tokens are read, stored, or evaluated
4. No persistence writes anywhere in the four files
5. `authModel`, `authRouteMap`, `authDecisionComposer` have no init, no subsystem registration, no health check, no event emission
6. `routes/authObserveStatus.ts` is passive diagnostic only — must never be referenced from middleware or routing logic

#### Evolution rules

- Future auth enforcement must be implemented in **new files** — never by modifying the four sealed files
- A future enforcement layer may import `composeAuthDecision` as a read-only input — but must never feed results back into the observe stack
- Future session or audit phases may import from `authModel` and `authDecisionComposer` for type definitions — imports are one-directional

#### Counter snapshot at seal

| Metric | Value |
|---|---|
| Endpoints | 144 |
| Access policies | 144 |
| Health checks | 38 |
| Subsystems | 27 |
| Graph nodes | 27 |
| Graph cycles | 0 |

**Next layer:** session blueprint or auth audit events.

---

### Phase 185 — Session Layer Blueprint

**Documentation-only.** Defines the future session layer in full before any implementation. Zero runtime source files changed. All counters unchanged.

#### Session Types

| Session Type | Actor | Max Active | TTL | Scope |
|---|---|---|---|---|
| `root_operator` | `root_operator` | **1** (hard limit) | 30 min | Full Mother Core |
| `internal_operator` | `internal_operator` | Unlimited | 2 h | Capability-scoped |
| `employee` | `employee` | Unlimited | 2 h | Workspace-scoped |
| `service_token` | `service_token` | Unlimited | Sliding 24 h | Scope-pinned, no UI |
| `generated_product_customer` | `customer` | — | — | Outside Mother Core |

Generated-product customer sessions are explicitly out of scope for Mother Core — they belong in the future generated-product layer.

#### Session Rules

- No permanent sessions — all types have finite TTL, no "remember me"
- Server-side opaque session IDs — minimum 128 bits of entropy; all state stored server-side
- HTTPS-only — session identifiers never transmitted over plain HTTP
- Immediate invalidation on logout or role change — passive expiry is insufficient
- Root operator max-1 — new root_operator session atomically invalidates all existing root_operator sessions

#### Storage Rules

- No raw credentials in session store — permitted fields: actorType, actorId, tier, scopedCapabilities, issuedAt, expiresAt, lastSeenAt, auditId, sessionId
- No secrets in cookies — cookies carry opaque session ID only
- No self-contained JWT for Mother Core — JWT/PASETO/signed cookies are prohibited; opaque tokens only
- All session records audit-linked — every record carries an `auditId` referencing its creation event

#### Enforcement Ordering

```
Phases 180–183  Auth Observe Stack      (sealed)
Phase 185+      Session Layer           (this blueprint)
Future          Enforce-Mode Auth
Future          VPS / Private Server Migration
```

#### Implementation Boundaries

- New files only — `core/sessionLayer.ts`, `routes/session*.ts` (names TBD)
- May import `AuthActorType`, `AccessTier`, `composeAuthDecision` from sealed observe stack
- Must never modify `authModel.ts`, `authRouteMap.ts`, `authDecisionComposer.ts`, `authObserveStatus.ts`
- One-directional: session layer reads from observe stack; observe stack never imports from session layer

---

### Phase 186 — Auth Audit Events Blueprint

**Documentation-only.** Defines the future auth/session audit event model before any implementation. Zero runtime source files changed. All counters unchanged.

#### Audit Event Types

| Event Type | Trigger | Outcome |
|---|---|---|
| `login_success` | Successful authentication | `allowed` |
| `login_failure` | Failed authentication attempt | `denied` |
| `logout` | Explicit session termination | `completed` |
| `session_expired` | TTL elapsed, session invalidated | `expired` |
| `privilege_change` | Actor tier or capability modified | `granted` / `revoked` |
| `token_revoked` | Service token explicitly revoked | `revoked` |
| `auth_limit_hit` | Rate limit or session cap exceeded | `blocked` |
| `suspicious_activity` | Anomalous pattern detected | `flagged` |

#### Required Fields (per event)

| Field | Type | Notes |
|---|---|---|
| `eventId` | `string` | Random 128-bit opaque ID |
| `actorType` | `AuthActorType` | From sealed `authModel.ts` |
| `actorId` | `string` | Opaque — never a credential |
| `eventType` | `AuthAuditEventType` | One of the 8 types |
| `route` | `string` | Request path that triggered the event |
| `ip` | `string` | Client IP |
| `timestamp` | `string` | ISO 8601 |
| `outcome` | `string` | Per-type outcome value |
| `sessionId` | `string \| null` | Optional — null for pre-session events |
| `auditChainId` | `string` | Groups related events in a flow |

#### Storage Rules

- Append-only — no UPDATE or DELETE via any API path
- Tamper-evident — `auditChainId` for logical grouping; hash-chain strengthening is a future phase
- No deletion except root_operator archival process (which itself emits an audit event)
- No secrets — credentials and secret material are never stored in event records

#### Visibility Rules

| Actor | Visibility |
|---|---|
| `root_operator` | Full — all types, all actors, all time |
| `internal_operator` | Scoped — own type + capability-assigned scopes |
| `employee` | None |
| `customer` | None |
| `service_token` | None |

#### Future Integration Points

- **Session layer** — every session record links to an `auditId`; emits `login_success`, `logout`, `session_expired`
- **Rate limiter** — emits `auth_limit_hit` on cap breach
- **Enforce-mode auth** — emits `login_failure`, `privilege_change`, `suspicious_activity`
- **Fleet actions** — separate audit categories (out of scope for this blueprint)

#### Implementation Boundaries

- New file only — `core/authAuditLog.ts` (separate from existing `core/auditLog.ts`)
- May import `AuthActorType` from sealed `authModel.ts`
- Append-only store — no update or delete methods exported
- Visibility enforcement lives in the read path, not the write path

---

### Phase 187 — Auth Audit Log Core

**Runtime phase.** Created `core/authAuditLog.ts` — append-only in-memory auth audit log. Separate from `core/auditLog.ts` (access enforcement audit). 1 source file created, 0 modified. No endpoints, no policies, no health checks, no subsystem registration. All counters unchanged.

#### File: `core/authAuditLog.ts`

Pure module — no init, no subsystem registration, no health check, no event emission, no persistence.

**Types:**

| Export | Kind | Fields / Values |
|---|---|---|
| `AuthAuditEventType` | union (8) | `login_success`, `login_failure`, `logout`, `session_expired`, `privilege_change`, `token_revoked`, `auth_limit_hit`, `suspicious_activity` |
| `AuthAuditOutcome` | union (8) | `allowed`, `denied`, `completed`, `expired`, `granted`, `revoked`, `blocked`, `flagged` |
| `AuthAuditEvent` | interface | `eventId`, `actorType`, `actorId`, `eventType`, `route`, `ip`, `timestamp`, `outcome`, `sessionId: string \| null`, `auditChainId` |
| `AuthAuditSummary` | interface | `totalEvents`, `byEventType`, `byOutcome`, `oldestEventAt`, `newestEventAt`, `appendOnly: true`, `persistenceEnabled: false`, `implementationPhase: "skeleton"` |

**Functions:**

| Export | Description |
|---|---|
| `appendAuthAuditEvent(input)` | Drops prohibited field names; server-generates `eventId` + `timestamp`; ring buffer max 1000 |
| `listAuthAuditEvents()` | Newest-first full store copy — no actor scoping |
| `getAuthAuditSummary()` | Counts by event type and outcome; oldest/newest timestamps |

**Prohibited field names (key-name check, silently dropped):**
`password` · `secret` · `token` · `credential` · `credentials` · `passwd` · `pass` · `apiKey` · `api_key` · `privateKey` · `private_key`

**Design invariants:**
- `eventId` and `timestamp` always server-generated — caller values always discarded
- `sessionId` is `string | null` — null for pre-session events (`login_failure`, `token_revoked`, early `suspicious_activity`)
- Ring buffer max 1000 — oldest dropped on overflow, no error thrown
- No delete or update methods — append-only by construction
- Visibility scoping is the caller's responsibility — a future read-path layer enforces actor rules
- Not wired into `runtime.ts`

---

### Phase 188 — Auth Audit Log Observe API

**Runtime phase.** Created `routes/authAuditLog.ts` and registered `GET /api/auth/audit-log`. Read-only diagnostic endpoint exposing the in-memory auth audit log. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/auth/audit-log`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/auth/audit-log` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `appendOnly` | `true` | Literal |
| `persistenceEnabled` | `false` | Literal — in-memory only |
| `executionBlocked` | `true` | Literal |
| `totalEvents` | number | Count from summary |
| `summary` | `AuthAuditSummary` | Counts by type and outcome, oldest/newest timestamps |
| `events` | `AuthAuditEvent[]` | Newest-first full store; empty array when no events |

**Design invariants:**
- Serving this endpoint never writes to the audit log
- Visibility scoping deferred — future read-path layer enforces actor-level rules
- Access policy: `monitor` + `operator` — coarse gate consistent with Phase 186 visibility rules

---

### Phase 189 — Auth Diagnostic Layer Seal & Compaction

**Documentation-only.** Seals Phases 185–188. Auth diagnostic/audit layer officially closed. 0 runtime source files changed. All counters unchanged.

#### Sealed Layer Summary

| Phase | Title | Kind | Deliverable |
|---|---|---|---|
| 185 | Session Layer Blueprint | Documentation | Session types, TTL rules, storage rules |
| 186 | Auth Audit Events Blueprint | Documentation | 8 event types, 10 required fields, visibility model |
| 187 | Auth Audit Log Core | Runtime | `core/authAuditLog.ts` — append-only ring buffer max 1000 |
| 188 | Auth Audit Log Observe API | Runtime | `routes/authAuditLog.ts` — GET /api/auth/audit-log |

#### Sealed Source Files

| File | Sealed | Description |
|---|---|---|
| `core/authModel.ts` | Phase 180 | Actor classifier |
| `core/authRouteMap.ts` | Phase 181 | Route classifier |
| `core/authDecisionComposer.ts` | Phase 182 | Observe composer |
| `routes/authObserveStatus.ts` | Phase 183 | GET /api/auth/observe-status |
| `core/authAuditLog.ts` | Phase 187 | Auth audit ring buffer |
| `routes/authAuditLog.ts` | Phase 188 | GET /api/auth/audit-log |

#### Layer Boundary

- Phases 180–188: observe-only + read-only diagnostic surface
- `appendAuthAuditEvent` is not yet wired to any auth flows — store is empty at server start
- Enforce-mode auth (blocking, session creation, login/logout) belongs to a future layer

---

### Phase 190 — Session Core Skeleton

**Runtime phase.** Created `core/sessionCore.ts` — in-memory, non-enforcing session skeleton. Pure module, no init, no endpoints, no policies, no persistence, no cookies, no credentials, no JWT, not wired to request flow. 1 source file created, 0 modified. All counters unchanged.

#### File: `core/sessionCore.ts`

**Types:**

| Export | Kind | Description |
|---|---|---|
| `SessionActorType` | derived union (4) | `Extract<AuthActorType, "root_operator" \| "internal_operator" \| "employee" \| "service_token">` |
| `SessionStatus` | union (2) | `"active"` · `"expired"` |
| `SessionRecord` | interface | `sessionId`, `actorType`, `actorId`, `auditId`, `issuedAt`, `expiresAt`, `status`, `metadata` |
| `CreateSessionInput` | interface | Caller-supplied: `actorType`, `actorId`, `auditId`, `metadata?` |
| `CreateSessionResult` | discriminated union | `{ok:true,record}` · `{ok:false,reason}` |
| `SessionSummary` | interface | Counts, per-type breakdown, `persistenceEnabled: false`, `implementationPhase: "skeleton"` |

**TTLs:**

| Actor type | TTL |
|---|---|
| `root_operator` | 30 min |
| `internal_operator` | 2 h |
| `employee` | 2 h |
| `service_token` | 24 h (sliding — future layer) |

**Functions:**

| Export | Description |
|---|---|
| `createSessionRecord(input)` | Server-generates `sessionId`, `issuedAt`, `expiresAt`; enforces root_operator max 1 active; ring buffer max 500 |
| `listSessionRecords()` | Newest-first full store copy — no actor scoping |
| `expireSessionRecord(sessionId)` | Marks active record expired; returns record or null |
| `getSessionSummary()` | Active counts per actor type, root_operator active count |

**Design invariants:**
- `sessionId`, `issuedAt`, `expiresAt` always server-generated
- `auditId` required — must link to a prior auth audit event
- root_operator max-1 enforced via `{ok:false,reason}` result — never throws
- No visibility scoping in list or expire — caller responsibility
- Not wired into `runtime.ts`

---

### Phase 191 — Session Observe API

**Runtime phase.** Created `routes/sessionObserve.ts` and registered `GET /api/auth/sessions`. Read-only diagnostic endpoint exposing the in-memory session store. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/auth/sessions`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/auth/sessions` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `persistenceEnabled` | `false` | Literal — in-memory only |
| `enforcing` | `false` | Literal — skeleton mode; no blocking, no redirects |
| `executionBlocked` | `true` | Literal |
| `totalSessions` | number | Count from summary |
| `summary` | `SessionSummary` | Active/expired counts, per-type breakdown, root_operator active count |
| `sessions` | `SessionRecord[]` | Newest-first full store; empty array when no sessions |

**Design invariants:**
- Never calls `createSessionRecord` or `expireSessionRecord` — pure read
- Serving this endpoint never writes to the session store or the auth audit log
- `enforcing: false` is a literal — must never acquire enforcement behaviour
- Visibility scoping deferred to a future read-path layer
- Access policy: `monitor` + `operator` — consistent with audit-log and observe-status

---

### Phase 192 — Auth Session Diagnostic Seal

**Documentation-only.** Seals Phases 190–191. Auth/session diagnostic cluster officially closed. 0 runtime source files changed. All counters unchanged.

#### Complete Sealed Cluster

| Endpoint | Phase | Core module | Route module |
|---|---|---|---|
| `GET /api/auth/observe-status` | 183 | `authDecisionComposer.ts` | `routes/authObserveStatus.ts` |
| `GET /api/auth/audit-log` | 188 | `authAuditLog.ts` | `routes/authAuditLog.ts` |
| `GET /api/auth/sessions` | 191 | `sessionCore.ts` | `routes/sessionObserve.ts` |

#### All Sealed Source Files (8)

| File | Phase |
|---|---|
| `core/authModel.ts` | 180 |
| `core/authRouteMap.ts` | 181 |
| `core/authDecisionComposer.ts` | 182 |
| `routes/authObserveStatus.ts` | 183 |
| `core/authAuditLog.ts` | 187 |
| `routes/authAuditLog.ts` | 188 |
| `core/sessionCore.ts` | 190 |
| `routes/sessionObserve.ts` | 191 |

#### Cluster Invariants

- All three endpoints observe-only and read-only — permanently
- `createSessionRecord`, `expireSessionRecord`, `appendAuthAuditEvent` not yet wired — stores empty at server start
- Enforce-mode auth belongs to a future layer — new files only, no modifications to sealed files

---

### Phase 193 — Rate Limit Core Skeleton

**Runtime phase.** Created `core/rateLimitCore.ts` — in-memory, observe-only rate limit skeleton. Pure module, no init, no endpoints, no policies, no persistence, no blocking, not wired to request flow. 1 source file created, 0 modified. All counters unchanged.

#### File: `core/rateLimitCore.ts`

**Types:**

| Export | Kind | Description |
|---|---|---|
| `RateLimitScope` | union (6) | `ip` · `session` · `operator` · `employee` · `service_token` · `generated_product` |
| `RateLimitDecision` | interface | `scope`, `key`, `allowed: true`, `observeOnly: true`, `requestCount`, `windowStartedAt`, `observedAt` |
| `RateLimitSummary` | interface | `totalKeys`, `byScope` (distinct key count per scope), `totalObservations`, `enforcing: false`, `persistenceEnabled: false`, `implementationPhase: "skeleton"` |

**Functions:**

| Export | Description |
|---|---|
| `observeRateLimit(scope, key)` | Increments Map counter for `"${scope}:${key}"`; creates entry on first call; always `allowed: true` |
| `getRateLimitSummary()` | Counts by scope, total observations |
| `resetRateLimitMemory()` | Clears store; diagnostic/testing use only |

**Design invariants:**
- `allowed` always `true` — no rejection path in skeleton mode
- Not wired to request flow — explicit caller invocation only
- Store key: `"${scope}:${key}"` — caller controls key content
- `byScope` = distinct key count per scope (not total observations)
- Not wired into `runtime.ts`

---

### Phase 194 — Rate Limit Observe API

**Runtime phase.** Created `routes/rateLimitObserve.ts` and registered `GET /api/auth/rate-limit`. Read-only diagnostic endpoint exposing the in-memory rate limit observation store. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/auth/rate-limit`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/auth/rate-limit` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `observeOnly` | `true` | Literal |
| `enforcing` | `false` | Literal — skeleton mode |
| `persistenceEnabled` | `false` | Literal |
| `executionBlocked` | `true` | Literal |
| `summary` | `RateLimitSummary` | `totalKeys`, `byScope`, `totalObservations`, `enforcing`, `persistenceEnabled`, `implementationPhase` |

**Design invariants:**
- Calls only `getRateLimitSummary()` — never writes to the store
- No reset route — `resetRateLimitMemory()` not exposed as HTTP
- Access policy: `monitor` + `operator` — consistent with all `/api/auth/*` diagnostic endpoints

---

### Phase 195 — Rate Limit Diagnostic Seal

**Documentation-only phase.** Seals Phases 193–194 (Rate Limit Core Skeleton, Rate Limit Observe API). Full `/api/auth/*` diagnostic cluster officially sealed. 0 runtime source files changed. All counters unchanged.

#### Sealed /api/auth/* Diagnostic Cluster

| Endpoint | Core module | Phase | Status |
|---|---|---|---|
| `GET /api/auth/observe-status` | `authDecisionComposer.ts` | 183 | Sealed |
| `GET /api/auth/audit-log` | `authAuditLog.ts` | 188 | Sealed |
| `GET /api/auth/sessions` | `sessionCore.ts` | 191 | Sealed |
| `GET /api/auth/rate-limit` | `rateLimitCore.ts` | 194 | Sealed |

#### Sealed Source Files (10 total — never modify)

`authModel.ts` (180) · `authRouteMap.ts` (181) · `authDecisionComposer.ts` (182) · `routes/authObserveStatus.ts` (183) · `authAuditLog.ts` (187) · `routes/authAuditLog.ts` (188) · `sessionCore.ts` (190) · `routes/sessionObserve.ts` (191) · `rateLimitCore.ts` (193) · `routes/rateLimitObserve.ts` (194)

#### Cluster Invariants

- All four endpoints observe-only and read-only — permanently
- `observeRateLimit`, `createSessionRecord`, `expireSessionRecord`, `appendAuthAuditEvent` not yet wired — stores empty at server start
- Enforce-mode auth belongs to a future layer — new files only, no modifications to sealed files

---

### Phase 196 — Vault Core Skeleton

**Runtime phase.** Created `core/vaultCore.ts` — in-memory, metadata-only vault skeleton. Pure module, no init, no endpoints, no policies, no persistence, no encryption, no secret values accepted or stored. 1 source file created, 0 modified. All counters unchanged.

#### File: `core/vaultCore.ts`

**Types:**

| Export | Kind | Description |
|---|---|---|
| `VaultSecretType` | union (7) | `api_key` · `session_token` · `service_credential` · `signing_key` · `encryption_key` · `webhook_secret` · `oauth_token` |
| `VaultSecretScope` | union (5) | `global` · `project` · `operator` · `service` · `user` |
| `VaultSecretMetadata` | interface | `secretId`, `type`, `scope`, `ownerActorType`, `ownerActorId`, `expiresAt`, `rotationRequired`, `createdAt` |
| `VaultSummary` | interface | `totalSecrets`, `byType`, `byScope`, `rotationRequired`, `expiredCount`, `persistenceEnabled: false`, `encryptionEnabled: false`, `implementationPhase: "skeleton"` |

**Functions:**

| Export | Description |
|---|---|
| `registerVaultSecretMetadata(input)` | Generates `secretId` + `createdAt`; stores descriptor; returns `{ ok: true, metadata }` |
| `listVaultSecretMetadata()` | All records newest-first; no values |
| `getVaultSummary()` | Counts by type/scope; expiry check; summary flags |

**Design invariants:**
- Secret values structurally excluded from `RegisterVaultSecretInput` — no `value`, `secret`, `token`, `password`, `credential`, `apiKey`
- No retrieval function — no `getVaultSecretById`, `getVaultSecretValue`, `decryptVaultSecret`
- No deletion method — no `deleteVaultSecret` or `purgeVaultSecret`
- `byType`/`byScope` partial — absent keys mean zero for that type/scope
- Not wired into `runtime.ts`

---

### Phase 197 — Vault Observe API

**Runtime phase.** Created `routes/vaultObserve.ts` and registered `GET /api/auth/vault`. Read-only diagnostic endpoint exposing the in-memory vault metadata store. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/auth/vault`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/auth/vault` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `metadataOnly` | `true` | Literal |
| `encryptionEnabled` | `false` | Literal — skeleton mode |
| `persistenceEnabled` | `false` | Literal |
| `executionBlocked` | `true` | Literal |
| `totalSecrets` | number | Length of metadata array |
| `summary` | `VaultSummary` | Counts by type/scope, rotation/expiry summary |
| `metadata` | `VaultSecretMetadata[]` | All descriptors newest-first; no secret values |

**Design invariants:**
- Calls only `listVaultSecretMetadata()` and `getVaultSummary()` — never writes to the store
- Response structurally cannot contain prohibited fields — compile-time guarantee from `VaultSecretMetadata`
- No registration, retrieval, or deletion routes — future-phase concerns
- Access policy: `monitor` + `operator` — consistent with all `/api/auth/*` diagnostic endpoints

---

### Phase 198 — Vault Diagnostic Seal

**Documentation-only phase.** Seals Phases 196–197 (Vault Core Skeleton, Vault Observe API). Full `/api/auth/*` diagnostic cluster officially sealed — 5 endpoints, 12 source files. 0 runtime source files changed. All counters unchanged.

#### Sealed /api/auth/* Diagnostic Cluster (final)

| Endpoint | Core module | Phase | Status |
|---|---|---|---|
| `GET /api/auth/observe-status` | `authDecisionComposer.ts` | 183 | Sealed |
| `GET /api/auth/audit-log` | `authAuditLog.ts` | 188 | Sealed |
| `GET /api/auth/sessions` | `sessionCore.ts` | 191 | Sealed |
| `GET /api/auth/rate-limit` | `rateLimitCore.ts` | 194 | Sealed |
| `GET /api/auth/vault` | `vaultCore.ts` | 197 | Sealed |

#### Sealed Source Files (12 total — never modify)

`authModel.ts` (180) · `authRouteMap.ts` (181) · `authDecisionComposer.ts` (182) · `routes/authObserveStatus.ts` (183) · `authAuditLog.ts` (187) · `routes/authAuditLog.ts` (188) · `sessionCore.ts` (190) · `routes/sessionObserve.ts` (191) · `rateLimitCore.ts` (193) · `routes/rateLimitObserve.ts` (194) · `vaultCore.ts` (196) · `routes/vaultObserve.ts` (197)

#### Cluster Invariants

- All five endpoints observe-only and read-only — permanently
- `registerVaultSecretMetadata`, `observeRateLimit`, `createSessionRecord`, `expireSessionRecord`, `appendAuthAuditEvent` not yet wired — stores empty at server start
- Enforce-mode auth and vault encryption belong to future layers — new files only, no modifications to sealed files

---

### Phase 199 — Sandbox Security Blueprint

**Documentation-only phase.** Defines the architecture contract for the future Sandbox layer. 0 runtime source files changed. All counters unchanged.

#### Purpose

The Sandbox layer isolates all generated app builds, plugin execution, and test runs from Mother Core. The Mother Core process must never be exposed to generated code, plugin imports, or test commands directly.

| Goal | Description |
|---|---|
| Isolate generated app builds | Build tasks run in sandbox — never in Mother Core process |
| Isolate plugin execution | Plugin code runs in sandbox — Mother Core never exposed to plugin imports |
| Isolate test runs | Test commands run in sandbox — failures cannot affect Mother Core state |
| Prevent Mother Core mutation | Sandbox has no write access to Mother Core source, state, or storage |

#### Boundaries

| Boundary | Rule |
|---|---|
| Mother Core source files | No access — filesystem isolation, not permission-based |
| Vault secrets | No secret values — secretId references only; scoped token injection in future |
| Deployment credentials | No access — never passed into sandbox |
| Other projects | No cross-project access — each sandbox scoped to one project |
| Network | Blocked by default — explicit per-run operator grant required |

#### Allowed Inputs

| Input | Condition |
|---|---|
| Project spec | Always — declarative description of what to build |
| Template files | Always — read-only approved templates |
| Approved scoped secrets | Future phase — operator approval, metadata-reference only |
| Test commands | When operator-approved — no arbitrary shell access |

#### Outputs

| Output | Description |
|---|---|
| Build artifact | Compiled/bundled output of the generated app |
| Test report | Pass/fail with assertion details |
| Security report | Static analysis or dependency audit |
| Diff summary | Delta from previous approved state |
| Approval request | Structured operator gate before promotion |

#### Enforcement Rules

| Rule | Constraint |
|---|---|
| Sandbox before App Factory | App Factory must not run unless sandbox passes |
| Sandbox before Plugin Runtime | Plugin Runtime must not load unless sandbox passes |
| Sandbox before deployment | Generated app deployment must not proceed unless sandbox passes |
| Operator approval before promotion | No sandbox output may be promoted without explicit operator approval |

#### Design Invariants

- Sandbox isolation is categorical — no permission model can override the filesystem and network boundary
- Vault secret values are never passed into any sandbox, in any phase
- Operator approval is a hard gate — automatic promotion is not permitted
- All four enforcement rules are sequential gates, not advisory checks

---

### Phase 200 — Sandbox Core Skeleton

**Runtime phase.** Created `core/sandboxCore.ts` — in-memory, metadata-only sandbox run registry. Pure module, no init, no endpoints, no policies, no execution, no shell commands, no filesystem access, no network access, no vault access, not wired to request flow. 1 source file created, 0 modified. All counters unchanged.

#### File: `core/sandboxCore.ts`

**Types:**

| Export | Kind | Description |
|---|---|---|
| `SandboxRunType` | union (5) | `app_build` · `plugin_execution` · `test_run` · `security_scan` · `diff_summary` |
| `SandboxRunStatus` | union (5) | `pending_approval` · `approved` · `rejected` · `completed` · `failed` |
| `SandboxRunRecord` | interface | `sandboxRunId`, `projectId`, `runType`, `requestedByActorType`, `requestedByActorId`, `approvalRequired: true`, `status`, `createdAt` |
| `SandboxSummary` | interface | `totalRuns`, `byRunType`, `byStatus`, `pendingApprovalCount`, `executionEnabled: false`, `persistenceEnabled: false`, `implementationPhase: "skeleton"` |

**Functions:**

| Export | Description |
|---|---|
| `createSandboxRunRecord(input)` | Generates `sandboxRunId` + `createdAt`; `approvalRequired: true` always; `status: "pending_approval"` always; stores in Map; returns `{ ok: true, record }` |
| `listSandboxRuns()` | All records newest-first |
| `getSandboxSummary()` | Counts by run type/status; `executionEnabled: false` always |

**Design invariants:**
- Prohibited input fields structurally excluded — no `command`, `script`, `path`, `networkAccess`, `secretValue` in `CreateSandboxRunInput`
- `approvalRequired` always `true` — not caller-settable
- All records start at `status: "pending_approval"` — no status transition functions
- `executionEnabled` always `false` — no execution path
- `byRunType`/`byStatus` partial — absent keys mean zero
- Not wired into `runtime.ts`

---

### Phase 201 — Sandbox Observe API

**Runtime phase.** Created `routes/sandboxObserve.ts` and registered `GET /api/sandbox/runs`. Read-only diagnostic endpoint exposing the in-memory sandbox run registry. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/sandbox/runs`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/sandbox/runs` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `executionEnabled` | `false` | Literal |
| `persistenceEnabled` | `false` | Literal |
| `approvalRequired` | `true` | Literal |
| `executionBlocked` | `true` | Literal |
| `totalRuns` | number | Length of runs array |
| `summary` | `SandboxSummary` | Counts by run type/status; pending approval count |
| `runs` | `SandboxRunRecord[]` | All records newest-first |

**Design invariants:**
- Calls only `listSandboxRuns()` and `getSandboxSummary()` — never writes to the store
- No create-run, approval, or status-transition routes — future-phase concerns
- Path prefix `/api/sandbox/` — distinct from `/api/auth/*` cluster
- Access policy: `monitor` + `operator`

---

### Phase 202 — Sandbox Diagnostic Seal

**Documentation-only phase.** Seals Phases 200–201 (Sandbox Core Skeleton, Sandbox Observe API). Sandbox diagnostic cluster sealed — 1 endpoint, 2 source files. 0 runtime source files changed. All counters unchanged.

#### Sealed Sandbox Diagnostic Cluster

| Endpoint | Core module | Phase | Status |
|---|---|---|---|
| `GET /api/sandbox/runs` | `sandboxCore.ts` | 201 | Sealed |

#### Sealed Source Files (2 total — never modify)

`core/sandboxCore.ts` (200) · `routes/sandboxObserve.ts` (201)

#### Cluster Invariants

- `GET /api/sandbox/runs` observe-only and read-only — permanently
- `createSandboxRunRecord` not yet wired — store empty at server start
- Future enforcement/approval phases add new files only — no modifications to sealed files
- Sandbox cluster prefix `/api/sandbox/` — separate from `/api/auth/*` permanently

---

### Phase 203 — Plugin Runtime Blueprint

**Documentation-only phase.** Defines the future Plugin Runtime layer. 0 runtime source files changed. All counters unchanged.

---

#### Plugin Purpose

The Plugin Runtime layer extends Bulldozer Mother Core capabilities without mutating the Mother Core itself. Plugins support App Factory tools (generators, validators, exporters), template generation, schema validation, artifact export, and sandboxed test execution. Plugins are additive and operator-controlled — they do not modify routing, policies, or any sealed core module.

---

#### Plugin Boundaries

| Boundary | Rule |
|---|---|
| Mother Core mutation | Prohibited |
| Route/policy changes | Prohibited — plugins never register routes or policies directly |
| Vault access | Prohibited unless explicit named scope granted at registration |
| Network access | Prohibited by default — must be declared and approved |
| Filesystem access | Prohibited outside sandbox working directory |
| Cross-project access | Prohibited — plugins scoped to registration project |
| Inter-plugin access | Prohibited — no direct plugin-to-plugin calls |

---

#### Plugin Types (5)

| Type | Purpose |
|---|---|
| `generator` | Produces project files, scaffolding, or code artifacts |
| `validator` | Validates schemas, inputs, or generated artifact structure |
| `exporter` | Packages and prepares artifacts for delivery or deployment |
| `test-runner` | Executes sandboxed tests against a generated app build |
| `integration` | Bridges external systems (future phase — network scope required) |

---

#### Plugin Lifecycle (7 stages)

| Stage | Description |
|---|---|
| `register_metadata` | Operator submits plugin metadata — name, type, version, declared permissions, vault scope, network scope |
| `review` | Plugin recorded; not yet active; no execution permitted |
| `sandbox_test` | Plugin run inside sandbox against fixture input; result recorded, not promoted |
| `operator_approval` | Operator reviews sandbox result and explicitly approves or rejects |
| `enable` | Plugin active; may be invoked by authorized App Factory flows |
| `monitor` | All invocations audited; anomalies flag plugin for re-review |
| `disable_revoke` | Operator disables (temporary) or revokes (permanent); all future invocations blocked |

Lifecycle stages are sequential and non-skippable. Reactivation after `disable` returns to `review`. After `revoke`, the plugin record is sealed — no re-registration with the same identity.

---

#### Security Rules (4)

| Rule | Enforcement |
|---|---|
| All execution inside sandbox | No plugin invocation path may bypass the sandbox boundary — applies to all 5 plugin types |
| No run before sandbox approval | Plugins in `register_metadata`, `review`, or `sandbox_test` stage cannot be invoked |
| Every action audited | Every invocation, stage transition, and permission check is appended to the audit log |
| Permissions explicit and scoped | Every permission must be named at registration; blanket permissions are rejected |

---

### Phase 204 — Plugin Core Skeleton

**Runtime phase.** Created `core/pluginCore.ts` — in-memory, metadata-only plugin registry. Pure module, no init, no subsystem registration, no health checks, no event emission, no persistence, no execution. 1 runtime source file created, 0 source files modified. All counters unchanged.

#### Types

| Name | Kind | Members |
|---|---|---|
| `PluginType` | union | `generator`, `validator`, `exporter`, `test-runner`, `integration` |
| `PluginLifecycleStatus` | union | `registered_metadata`, `review`, `sandbox_test`, `operator_approval`, `enable`, `monitor`, `disabled`, `revoked` |
| `PluginPermissionScope` | union | `read_project`, `read_vault_named`, `write_artifact`, `network_declared`, `sandbox_only` |
| `PluginMetadataRecord` | interface | `pluginId`, `name`, `pluginType`, `requestedByActorType`, `requestedByActorId`, `permissionScopes`, `status`, `registeredAt` |
| `RegisterPluginInput` | interface | `name`, `pluginType`, `requestedByActorType`, `requestedByActorId`, `permissionScopes` — excludes `code`/`command`/`script`/`path`/`network`/`secretValue` |
| `PluginSummary` | interface | `totalPlugins`, `byType`, `byStatus`, `pendingReviewCount`, `executionEnabled: false`, `persistenceEnabled: false`, `implementationPhase: "skeleton"` |

#### Exports

| Export | Behaviour |
|---|---|
| `registerPluginMetadata(input)` | Generates `pluginId` + `registeredAt`; `status="registered_metadata"` always; stores in Map; returns `{ ok: true, record }` |
| `listPluginMetadata()` | All records newest-first |
| `getPluginSummary()` | Counts by type/status; `executionEnabled: false` always |

#### Design invariants

- Pure module — no init, not wired to `runtime.ts`
- `status` always `"registered_metadata"` at creation — not caller-settable
- `RegisterPluginInput` structurally excludes all execution-related fields at compile time
- `PluginPermissionScope` is the only permitted permission surface — no freeform strings, no blanket grants
- Stage transitions are a future-phase concern — new files only, never modifying `pluginCore.ts`

---

### Phase 205 — Plugin Observe API

**Runtime phase.** Created `routes/pluginObserve.ts` and registered `GET /api/plugins/registry`. Read-only diagnostic endpoint exposing the in-memory plugin metadata registry. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/plugins/registry`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/plugins/registry` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `executionEnabled` | `false` | Literal |
| `persistenceEnabled` | `false` | Literal |
| `executionBlocked` | `true` | Literal |
| `totalPlugins` | number | Length of plugins array |
| `summary` | `PluginSummary` | Counts by type/status; pending review count |
| `plugins` | `PluginMetadataRecord[]` | All records newest-first |

**Design invariants:**
- Calls only `listPluginMetadata()` and `getPluginSummary()` — never writes to the store
- No registration, enable, or disable routes — future-phase concerns
- Path prefix `/api/plugins/` — distinct from `/api/sandbox/` and `/api/auth/*` clusters
- Access policy: `monitor` + `operator`

---

### Phase 206 — Plugin Diagnostic Seal

**Documentation-only phase.** Seals Phases 203–205 (Plugin Runtime Blueprint, Plugin Core Skeleton, Plugin Observe API). Plugin diagnostic cluster sealed — 1 endpoint, 2 source files. 0 runtime source files changed. All counters unchanged.

#### Sealed Plugin Diagnostic Cluster

| Endpoint | Core module | Phase | Status |
|---|---|---|---|
| `GET /api/plugins/registry` | `pluginCore.ts` | 205 | Sealed |

#### Sealed Source Files (2 total — never modify)

`core/pluginCore.ts` (204) · `routes/pluginObserve.ts` (205)

#### Cluster Invariants

- `GET /api/plugins/registry` observe-only and read-only — permanently
- `registerPluginMetadata` not yet wired — store empty at server start
- Future registration/lifecycle phases add new files only — no modifications to sealed files
- Plugin cluster prefix `/api/plugins/` — separate from `/api/sandbox/` and `/api/auth/*` permanently
- Blueprint law (Phase 203): all plugin execution through sandbox, 7-stage lifecycle non-skippable, permissions explicit and scoped

---

### Phase 207 — App Factory Blueprint

**Documentation-only phase.** Defines the future App Factory layer. 0 runtime source files changed. All counters unchanged.

---

#### App Factory Purpose

The App Factory layer generates complete applications from operator-provided project specs, coordinating templates, plugins, and the sandbox to produce deployable artifacts — with explicit operator approval at every promotion gate.

---

#### App Types (6)

| Type | Description |
|---|---|
| `crud_app` | Standard create/read/update/delete data management application |
| `pos_invoice_app` | Point-of-sale and shop invoice application with transaction flow |
| `dashboard_app` | Data visualization and reporting dashboard |
| `api_service` | Standalone API service with defined endpoints and schema |
| `admin_panel` | Internal operator interface for managing a product domain |
| `content_production_module` | Content authoring, scheduling, and publishing module |

---

#### Factory Pipeline (10 stages)

| Stage | Description |
|---|---|
| `receive_project_spec` | Operator submits structured spec: app type, name, data model, plugin list, vault scope |
| `select_template` | Factory selects the matching generator plugin template for the app type |
| `generate_files` | Generator plugin produces project files inside the sandbox working directory |
| `sandbox_build` | Sandbox executes build; produces `SandboxRunRecord` (runType: `app_build`); `approvalRequired=true` |
| `sandbox_test` | Sandbox executes tests; produces `SandboxRunRecord` (runType: `test_run`); `approvalRequired=true` |
| `security_scan` | Sandbox executes security scan; produces `SandboxRunRecord` (runType: `security_scan`) |
| `artifact_package` | Factory packages build output, test report, and security report into a versioned artifact |
| `operator_review` | Operator inspects artifact summary, test report, security report, and diff summary |
| `approve_reject` | Operator explicitly approves or rejects; rejection archives with notes, returns to spec |
| `deployment_candidate` | Approved artifact marked as deployment candidate; actual deployment handled by separate layer |

Stages are sequential and non-skippable. Rejection at `approve_reject` archives the artifact record — no deletion.

---

#### Boundaries

| Boundary | Rule |
|---|---|
| Mother Core mutation | Prohibited |
| Direct deployment | Prohibited — pipeline ends at `deployment_candidate` |
| Vault value exposure | Prohibited — values never written into generated files, logs, or reports |
| Network access | Prohibited by default — must be declared and approved |
| Generated app → Mother Core APIs | Prohibited — generated apps are standalone; no shared session, vault, or auth |
| Customer access to factory | Prohibited — all factory routes are operator-only |

---

#### Output Records (6)

| Record | Contents |
|---|---|
| `artifact_summary` | Name, app type, template, plugin list, file count, build status, timestamps |
| `test_report` | Test result, pass/fail counts, coverage summary, sandbox run reference |
| `security_report` | Scan findings, severity counts, sandbox run reference |
| `diff_summary` | File-level delta vs previous artifact version |
| `approval_request` | Artifact + reports link, awaiting operator decision |
| `deployment_candidate` | Approved artifact reference, approval timestamp, approving operator ID |

---

### Phase 208 — App Factory Core Skeleton

**Runtime phase.** Created `core/appFactoryCore.ts` — in-memory, metadata-only App Factory request registry. Pure module, no init, no subsystem registration, no health checks, no event emission, no persistence, no file generation, no sandbox execution, no plugin execution, no deployment. 1 runtime source file created, 0 source files modified. All counters unchanged.

#### Types

| Name | Kind | Members |
|---|---|---|
| `AppFactoryAppType` | union | `crud_app`, `pos_invoice_app`, `dashboard_app`, `api_service`, `admin_panel`, `content_production_module` |
| `AppFactoryPipelineStatus` | union | `received_project_spec`, `select_template`, `generate_files`, `sandbox_build`, `sandbox_test`, `security_scan`, `artifact_package`, `operator_review`, `approved`, `rejected`, `deployment_candidate` |
| `AppFactoryRequestRecord` | interface | `factoryRequestId`, `appType`, `projectName`, `requestedByActorType`, `requestedByActorId`, `specSummary`, `status`, `createdAt` |
| `CreateAppFactoryRequestInput` | interface | `appType`, `projectName`, `requestedByActorType`, `requestedByActorId`, `specSummary` — excludes `code`/`files`/`command`/`script`/`deploy`/`secretValue` |
| `AppFactorySummary` | interface | `totalRequests`, `byAppType`, `byStatus`, `pendingReviewCount`, `generationEnabled: false`, `executionEnabled: false`, `persistenceEnabled: false`, `implementationPhase: "skeleton"` |

#### Exports

| Export | Behaviour |
|---|---|
| `createAppFactoryRequestRecord(input)` | Generates `factoryRequestId` + `createdAt`; `status="received_project_spec"` always; stores in Map; returns `{ ok: true, record }` |
| `listAppFactoryRequestRecords()` | All records newest-first |
| `getAppFactorySummary()` | Counts by app type/status; `pendingReviewCount` = `operator_review` count only; `generationEnabled/executionEnabled: false` always |

#### Design invariants

- Pure module — no init, not wired to `runtime.ts`
- `status` always `"received_project_spec"` at creation — not caller-settable
- `CreateAppFactoryRequestInput` structurally excludes all generation/execution/deployment fields at compile time
- `pendingReviewCount` counts `operator_review` status only — not earlier pipeline stages
- Pipeline stage transitions are a future-phase concern — new files only, never modifying `appFactoryCore.ts`

---

### Phase 209 — App Factory Observe API

**Runtime phase.** Created `routes/appFactoryObserve.ts` and registered `GET /api/factory/requests`. Read-only diagnostic endpoint exposing the in-memory App Factory request registry. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/factory/requests`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/factory/requests` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `generationEnabled` | `false` | Literal |
| `executionEnabled` | `false` | Literal |
| `persistenceEnabled` | `false` | Literal |
| `executionBlocked` | `true` | Literal |
| `totalRequests` | number | Length of requests array |
| `summary` | `AppFactorySummary` | Counts by app type/status; pending review count |
| `requests` | `AppFactoryRequestRecord[]` | All records newest-first |

**Design invariants:**
- Calls only `listAppFactoryRequestRecords()` and `getAppFactorySummary()` — never writes to the store
- No create-request, pipeline-advance, or approval routes — future-phase concerns
- Path prefix `/api/factory/` — distinct from `/api/plugins/`, `/api/sandbox/`, and `/api/auth/*` clusters
- Access policy: `monitor` + `operator`

---

### Phase 210 — App Factory Diagnostic Seal

**Documentation-only phase.** Seals Phases 207–209 (App Factory Blueprint, App Factory Core Skeleton, App Factory Observe API). Factory diagnostic cluster sealed — 1 endpoint, 2 source files. 0 runtime source files changed. All counters unchanged.

#### Sealed Factory Diagnostic Cluster

| Endpoint | Core module | Phase | Status |
|---|---|---|---|
| `GET /api/factory/requests` | `appFactoryCore.ts` | 209 | Sealed |

#### Sealed Source Files (2 total — never modify)

`core/appFactoryCore.ts` (208) · `routes/appFactoryObserve.ts` (209)

#### Cluster Invariants

- `GET /api/factory/requests` observe-only and read-only — permanently
- `createAppFactoryRequestRecord` not yet wired — store empty at server start
- Future spec-submission/pipeline phases add new files only — no modifications to sealed files
- Factory cluster prefix `/api/factory/` — four-way separation from `/api/plugins/`, `/api/sandbox/`, `/api/auth/*` permanently
- Blueprint law (Phase 207): no direct deployment, no vault values in generated files, no generated app access to Mother Core APIs, no customer access to factory, all builds through sandbox
- Next: Template Registry Core Skeleton

---

### Phase 211 — Template Registry Blueprint

**Documentation-only phase.** Defines the future Template Registry layer. 0 runtime source files changed. All counters unchanged.

#### Template Purpose

Provide approved app structures for the App Factory. Support all 6 App Factory application categories. Keep code generation predictable and safe by enforcing an explicit approval lifecycle before any template can be used in pipeline stages.

#### Template Types (6)

| Template Type | App Factory App Type |
|---|---|
| `crud_template` | `crud_app` |
| `pos_invoice_template` | `pos_invoice_app` |
| `dashboard_template` | `dashboard_app` |
| `api_service_template` | `api_service` |
| `admin_panel_template` | `admin_panel` |
| `content_module_template` | `content_production_module` |

#### Template Lifecycle (7 stages)

`register_metadata` → `review` → `sandbox_validate` → `operator_approval` → `enable` → `deprecate` → `revoke`

Strictly ordered. No skipping. `enable` requires `operator_approval`. Deprecated templates cycle back through `review` to re-enable.

#### Template Output Contract

| Field | Type | Note |
|---|---|---|
| `templateId` | string | Server-generated 16-byte hex |
| `templateType` | `TemplateType` | One of 6 template types |
| `name` | string | Human-readable name |
| `version` | string | Semantic version string |
| `supportedAppTypes` | `AppFactoryAppType[]` | Eligible app types |
| `requiredInputs` | `string[]` | Named inputs pipeline must supply |
| `generatedArtifactTypes` | `string[]` | Declared artifact types produced |
| `approvalRequired` | `true` | Literal — not configurable |

#### Template Boundaries (6)

| Boundary | Rule |
|---|---|
| No executable code during registration | Descriptors only — no code strings, script paths, shell commands, bytecode |
| No direct filesystem writes | File generation done by factory pipeline inside sandbox |
| No network access | Registration and lifecycle transitions are fully offline |
| No vault values | Templates must not reference, store, or emit any secret values |
| No deployment access | No path to any deployment layer |
| No Mother Core mutation | Must not modify any sealed core module |

#### Implementation Notes

- Core module: pure-module pattern — no init, not wired to `runtime.ts`
- Cluster prefix: `/api/templates/` — five-way separation from `/api/factory/`, `/api/plugins/`, `/api/sandbox/`, `/api/auth/*`
- Observe endpoint: same pattern as `GET /api/factory/requests`, `GET /api/plugins/registry`, `GET /api/sandbox/runs`
- `approvalRequired=true` literal in every output record — never caller-settable

---

### Phase 212 — Template Registry Core Skeleton

**Runtime phase.** Created `core/templateRegistryCore.ts` — in-memory, metadata-only Template Registry. Pure module, no init, no endpoints, no policies. 1 runtime source file created, 0 source files modified. All counters unchanged.

#### Types

| Type | Values |
|---|---|
| `TemplateType` | `crud_template`, `pos_invoice_template`, `dashboard_template`, `api_service_template`, `admin_panel_template`, `content_module_template` |
| `TemplateLifecycleStatus` | `register_metadata`, `review`, `sandbox_validate`, `operator_approval`, `enable`, `deprecate`, `revoke` |
| `SupportedAppType` | Mirrors `AppFactoryAppType` locally — no cross-module import from sealed `appFactoryCore.ts` |

#### `TemplateMetadataRecord` key fields

| Field | Value |
|---|---|
| `templateId` | Server-generated 16-byte hex |
| `approvalRequired` | `true` literal — compile-time enforced |
| `status` | `"register_metadata"` literal — always at creation |
| `registeredAt` | Server-generated ISO 8601 |

#### `RegisterTemplateMetadataInput` — accepted fields

`templateType` · `name` · `version` · `supportedAppTypes[]` · `requiredInputs[]` · `generatedArtifactTypes[]` · `requestedByActorType` · `requestedByActorId`

Structurally excludes: `code`, `files`, `command`, `script`, `path`, `networkFlag`, `secretValue`

#### Exports

| Export | Behaviour |
|---|---|
| `registerTemplateMetadata(input)` | Generates `templateId` + `registeredAt`; `approvalRequired=true` always; `status="register_metadata"` always; returns `{ok:true, record}` |
| `listTemplateMetadata()` | All records newest-first |
| `getTemplateSummary()` | `totalTemplates`, `byType`, `byStatus`, `pendingReviewCount`, `approvalRequired:true`, `executionEnabled:false`, `persistenceEnabled:false`, `implementationPhase:"skeleton"` |

#### Design Invariants

- Pure module — no init, not wired to `runtime.ts`
- `approvalRequired=true` is a `true` literal — compile-time enforced, never `boolean`
- `status="register_metadata"` always at creation — lifecycle transitions are future-phase, new files only
- `pendingReviewCount` counts `review` status only
- `SupportedAppType` is a local mirror — never import from sealed `appFactoryCore.ts`
- Next: Template Registry Diagnostic Seal

---

### Phase 213 — Template Registry Observe API

**Runtime phase.** Created `routes/templateRegistryObserve.ts` and registered `GET /api/templates/registry`. Read-only diagnostic endpoint exposing the in-memory Template Registry metadata store. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/templates/registry`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/templates/registry` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `generationEnabled` | `false` | Literal |
| `executionEnabled` | `false` | Literal |
| `persistenceEnabled` | `false` | Literal |
| `executionBlocked` | `true` | Literal |
| `totalTemplates` | number | Length of templates array |
| `summary` | `TemplateRegistrySummary` | Counts by type/status; pendingReviewCount; approvalRequired:true |
| `templates` | `TemplateMetadataRecord[]` | All records newest-first |

**Design invariants:**
- Calls only `listTemplateMetadata()` and `getTemplateSummary()` — never writes to the store
- No registration, enable, deprecate, or revoke routes — future-phase concerns
- Path prefix `/api/templates/` — five-way separation from `/api/factory/`, `/api/plugins/`, `/api/sandbox/`, `/api/auth/*`
- Access policy: `monitor` + `operator`

---

### Phase 214 — Template Registry Diagnostic Seal

**Documentation-only phase.** Seals Phases 211–213 (Template Registry Blueprint, Template Registry Core Skeleton, Template Registry Observe API). Template registry diagnostic cluster sealed — 1 endpoint, 2 source files. 0 runtime source files changed. All counters unchanged.

#### Sealed Template Registry Diagnostic Cluster

| Endpoint | Core module | Phase | Status |
|---|---|---|---|
| `GET /api/templates/registry` | `templateRegistryCore.ts` | 213 | Sealed |

#### Sealed Source Files (2 total — never modify)

`core/templateRegistryCore.ts` (212) · `routes/templateRegistryObserve.ts` (213)

#### Five Sealed Diagnostic Clusters — State After Phase 214

| Cluster | Prefix | Observe endpoint(s) | Core module(s) | Sealed |
|---|---|---|---|---|
| Auth diagnostics | `/api/auth/` | 5 endpoints (Phases 188–197) | `sessionCore`, `rateLimitCore`, `vaultCore` | Yes |
| Sandbox | `/api/sandbox/` | `GET /api/sandbox/runs` | `sandboxCore` | Yes |
| Plugin | `/api/plugins/` | `GET /api/plugins/registry` | `pluginCore` | Yes |
| App Factory | `/api/factory/` | `GET /api/factory/requests` | `appFactoryCore` | Yes |
| Template Registry | `/api/templates/` | `GET /api/templates/registry` | `templateRegistryCore` | Yes |

#### Cluster Invariants

- `GET /api/templates/registry` observe-only and read-only — permanently
- `registerTemplateMetadata` not yet wired — store empty at server start
- Future registration/lifecycle phases add new files only — no modifications to sealed files
- Five-way cluster separation is fully established and must be preserved in all future phases
- Blueprint law (Phase 211): no executable code during registration, no direct filesystem writes, no network access, no vault values, no deployment access, no Mother Core mutation
- Next: First Experimental Generation Core Skeleton

---

### Phase 215 — First Experimental Generation Blueprint

**Documentation-only phase.** Defines the first experimental generation flow. 0 runtime source files changed. All counters unchanged.

#### Experimental Goal

Prove end-to-end controlled generation flow. Generate a minimal CRUD app artifact structure only. No deployment, no execution, no sandbox runtime yet.

#### Experimental Scope

| Dimension | Value |
|---|---|
| App type | `crud_app` only |
| Template type | `crud_template` only |
| Output format | Artifact summary + virtual file map only |
| Initiation | Operator-only |

#### Experimental Pipeline (7 stages)

| Stage | Description |
|---|---|
| `receive_project_spec` | Intake — project name, appType, templateType, requiredInputs recorded |
| `select_template` | Resolve the `crud_template` from the Template Registry |
| `generate_virtual_structure` | Produce in-memory virtual file map; no disk writes |
| `validate_structure` | In-process structural checks only — no sandbox |
| `produce_artifact_summary` | Assemble virtual file tree, route list, schema summary, artifact summary |
| `operator_review` | Pipeline halts; operator inspects outputs |
| `approve_reject` | Terminal stage — explicit operator action only; no auto-approve |

#### Experimental Boundaries (7)

| Boundary | Rule |
|---|---|
| No real filesystem writes | In-memory descriptors only — no `fs.writeFile`, `fs.mkdir`, `fs.open` |
| No package installation | No `npm install`, `pnpm add`, or equivalent |
| No runtime execution | No `child_process`, no `eval`, no dynamic `import()` of generated code |
| No deployment candidate | Output records never passed to any deployment layer |
| No vault usage | No secret values accessed or emitted |
| No plugin execution yet | Plugin integration is future-phase |
| No customer access | Generation intake enforces `minimumRole: "operator"` |

#### Experimental Outputs (6)

Virtual file tree · Route list · Schema summary · Artifact summary · Validation report · Approval request

#### Implementation Notes

- Generation core module: pure-module pattern — no init, not wired to `runtime.ts`
- Generation cluster prefix: `/api/generation/` — sixth cluster, separate from all five sealed clusters
- Generation observe endpoint: same pattern as `/api/factory/requests`, `/api/templates/registry`
- `approve_reject` must never be made automatic or timeout-based in any implementation phase
- Intake route enforces `minimumRole: "operator"` — no viewer/guest access

---

### Phase 216 — First Experimental Generation Core Skeleton

**Runtime phase.** Created `core/experimentalGenerationCore.ts` — in-memory, virtual-output-only experimental generation registry. Pure module, no init, no endpoints, no policies. 1 runtime source file created, 0 source files modified. All counters unchanged.

#### Types

| Type | Constraint |
|---|---|
| `ExperimentalGenerationAppType` | `"crud_app"` literal only |
| `ExperimentalGenerationTemplateType` | `"crud_template"` literal only |
| `ExperimentalGenerationStatus` | 8 values — from `receive_project_spec` to `approved`/`rejected` |
| `VirtualFileRecord` | `virtualPath`, `fileType`, `contentDescriptor` — text only, no executable content |
| `VirtualRouteRecord` | `method`, `path`, `description` |
| `ArtifactSummary` | Structural metadata — no code |
| `ValidationReport` | `passed`, `checks[]` — 7 checks, all pass or skipped |

#### `ExperimentalGenerationRecord` key compile-time literals

| Field | Value | Type |
|---|---|---|
| `appType` | `"crud_app"` | Literal |
| `templateType` | `"crud_template"` | Literal |
| `status` | `"generate_virtual_structure"` | Literal |
| `executionBlocked` | `true` | Literal `true` |
| `deploymentBlocked` | `true` | Literal `true` |

#### `CreateExperimentalGenerationInput` — accepted fields

`projectName` · `requestedByActorType` · `requestedByActorId`

Structurally excludes: `code`, `files`, `command`, `script`, `shellCommand`, `installCommand`, `deployFlag`, `secretValue`

#### Exports

| Export | Behaviour |
|---|---|
| `createExperimentalGenerationRecord(input)` | Generates `generationId`+`createdAt`; builds virtual file tree (8 entries), route list (5 CRUD routes), validation report (7 checks); all literals hardcoded; returns `{ok:true, record}` |
| `listExperimentalGenerationRecords()` | All records newest-first |
| `getExperimentalGenerationSummary()` | `totalRuns`, `byStatus`, `pendingReviewCount`, `appType`, `templateType`, `executionEnabled:false`, `deploymentEnabled:false`, `persistenceEnabled:false`, `implementationPhase:"skeleton"` |

#### Design Invariants

- Pure module — no init, not wired to `runtime.ts`
- All type scope locked to `crud_app` + `crud_template` — new types require a new module
- `contentDescriptor` fields are text descriptions only — never executable code or disk-write targets
- `sandbox_execution` check always `skipped` — future integration adds new check, never modifies sealed entry
- `pendingReviewCount` counts `operator_review` only
- Lifecycle transitions are future-phase, new files only — never modify `experimentalGenerationCore.ts`
- Next: First Experimental Generation Diagnostic Seal

---

### Phase 217 — First Experimental Generation Observe API

**Runtime phase.** Created `routes/experimentalGenerationObserve.ts` and registered `GET /api/generation/experimental`. Read-only diagnostic endpoint exposing the in-memory experimental generation registry. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/generation/experimental`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/generation/experimental` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `generationEnabled` | `false` | Literal |
| `executionEnabled` | `false` | Literal |
| `deploymentEnabled` | `false` | Literal |
| `persistenceEnabled` | `false` | Literal |
| `executionBlocked` | `true` | Literal |
| `deploymentBlocked` | `true` | Literal |
| `totalGenerations` | number | Length of generations array |
| `summary` | `ExperimentalGenerationSummary` | Counts by status; pendingReviewCount; appType+templateType literals |
| `generations` | `ExperimentalGenerationRecord[]` | All records newest-first |

**Design invariants:**
- Calls only `listExperimentalGenerationRecords()` and `getExperimentalGenerationSummary()` — never writes to the store
- No generation trigger, approval, or lifecycle-transition routes — future-phase concerns
- Path prefix `/api/generation/` — sixth cluster, separate from all five sealed clusters
- Both `executionBlocked` and `deploymentBlocked` are `true` literals — two independent blocking fields
- Access policy: `monitor` + `operator`

---

### Phase 218 — First Experimental Generation Diagnostic Seal

**Documentation-only phase.** Seals Phases 215–217 (First Experimental Generation Blueprint, Core Skeleton, Observe API). Generation diagnostic cluster sealed — 1 endpoint, 2 source files. 0 runtime source files changed. All counters unchanged.

#### Sealed Generation Diagnostic Cluster

| Endpoint | Core module | Phase | Status |
|---|---|---|---|
| `GET /api/generation/experimental` | `experimentalGenerationCore.ts` | 217 | Sealed |

#### Sealed Source Files (2 total — never modify)

`core/experimentalGenerationCore.ts` (216) · `routes/experimentalGenerationObserve.ts` (217)

#### Six Sealed Diagnostic Clusters — State After Phase 218

| Cluster | Prefix | Observe endpoint(s) | Core module(s) | Sealed |
|---|---|---|---|---|
| Auth diagnostics | `/api/auth/` | 5 endpoints (Phases 188–197) | `sessionCore`, `rateLimitCore`, `vaultCore` | Yes |
| Sandbox | `/api/sandbox/` | `GET /api/sandbox/runs` | `sandboxCore` | Yes |
| Plugin | `/api/plugins/` | `GET /api/plugins/registry` | `pluginCore` | Yes |
| App Factory | `/api/factory/` | `GET /api/factory/requests` | `appFactoryCore` | Yes |
| Template Registry | `/api/templates/` | `GET /api/templates/registry` | `templateRegistryCore` | Yes |
| Experimental Generation | `/api/generation/` | `GET /api/generation/experimental` | `experimentalGenerationCore` | Yes |

#### Cluster Invariants

- `GET /api/generation/experimental` observe-only and read-only — permanently
- `createExperimentalGenerationRecord` not yet wired — store empty at server start
- Future generation-trigger/lifecycle phases add new files only — no modifications to sealed files
- Six-way cluster separation fully established — must be preserved in all future phases
- Blueprint law (Phase 215): no real filesystem writes, no package installation, no runtime execution, no deployment candidate, no vault usage, no plugin execution, no customer access
- Compile-time literals sealed: `appType="crud_app"`, `templateType="crud_template"`, `executionBlocked=true`, `deploymentBlocked=true`
- Next: First Real Template Artifact Core Skeleton

---

### Phase 219 — First Real Template Artifact Blueprint

**Documentation-only phase.** Defines the first real artifact structure model for experimental CRUD generation. 0 runtime source files changed. All counters unchanged.

#### 1. Artifact Purpose

| Purpose | Description |
|---|---|
| Virtual representation | Represent a deployable-style CRUD application virtually — no real disk writes |
| Deterministic structure | Provide deterministic structure generation from a fixed template contract |
| Sandbox compatibility | Prepare future sandbox build compatibility |
| Layout standardization | Standardize generated project layouts — every CRUD artifact follows the same directory shape |

#### 2. Virtual Artifact Structure (10 paths)

| Path | Role |
|---|---|
| `src/` | Root source directory |
| `src/routes/` | Route handler files |
| `src/components/` | Shared component descriptors |
| `src/services/` | Service layer stubs |
| `src/schemas/` | Zod or type schema files |
| `src/config/` | Configuration stubs |
| `src/types/` | TypeScript type declarations |
| `README.md` | Project readme descriptor |
| `package.json` | Virtual package descriptor (text only) |
| `tsconfig.json` | Virtual TypeScript config descriptor (text only) |

#### 3. Artifact Metadata (9 fields)

| Field | Type | Notes |
|---|---|---|
| `artifactId` | string | Server-generated 16-byte hex |
| `generationId` | string | Parent generation record ID |
| `appType` | `"crud_app"` | Compile-time literal |
| `templateType` | `"crud_template"` | Compile-time literal |
| `virtualFileCount` | number | Count of virtual file entries |
| `routeCount` | number | Count of virtual routes |
| `validationState` | string | `"passed"` \| `"failed"` \| `"pending"` |
| `approvalRequired` | `true` | Compile-time literal — never `false` |
| `createdAt` | string | ISO 8601 server-generated timestamp |

#### 4. Validation Rules

**Required (6):** health route · route registry · schema file · config stub · README.md · package.json virtual descriptor

**Prohibited (5):** duplicate route names · empty file trees · deployment metadata · embedded secrets · executable shell commands

#### 5. Future Boundaries (8 hard stops)

No real filesystem writes · no npm install · no runtime execution · no deployment packaging · no Docker generation · no environment variable injection · no vault secret injection · no plugin execution. Each, if introduced, requires a new separately named blueprint phase.

#### 6. Future Compatibility Targets

Sandbox build layer · package generation · deployment pipeline · fleet management · rollback orchestration

#### Invariants

- `package.json` and `tsconfig.json` entries are text descriptors only — never real installable/consumable file bodies
- `approvalRequired=true` is a compile-time literal in `CrudArtifactMetadata` — never `false`
- Validation rules are structural (checked at record-creation time) — not runtime test runners
- Five prohibited contents are absolute — no bypass permitted in any future phase
- Next: First Real Template Artifact Core Skeleton

---

### Phase 220 — First Real Template Artifact Core Skeleton

**Runtime phase.** Created `core/templateArtifactCore.ts` — deterministic, non-executing, in-memory virtual artifact registry. Pure module, no init, no endpoints, no policies. 1 runtime source file created. All counters unchanged.

#### Types

| Type | Description |
|---|---|
| `ArtifactValidationState` | `"structurally_valid"` \| `"failed"` \| `"pending"` |
| `ArtifactFileType` | 10 variants |
| `VirtualArtifactFile` | `virtualPath`, `fileType`, `contentDescriptor` |
| `VirtualArtifactRoute` | `method`, `path`, `description` |
| `ArtifactValidationCheck` | `name`, `status`, `detail` |
| `TemplateArtifactRecord` | Full artifact record (all fields readonly) |
| `CreateTemplateArtifactInput` | `generationId`, `projectName`, `requestedByActorType`, `requestedByActorId` |
| `TemplateArtifactSummary` | Aggregate summary |

#### Compile-time literals (3)

`appType="crud_app"` · `templateType="crud_template"` · `approvalRequired=true`

#### Deterministic Outputs per Record (Phase 219 Contract)

| Output | Count |
|---|---|
| `virtualFiles` | 10 (src/, src/routes/, src/components/, src/services/, src/schemas/, src/config/, src/types/, README.md, package.json descriptor, tsconfig.json descriptor) |
| `virtualRoutes` | 5 (GET list, POST create, GET by id, PATCH update, DELETE by id) |
| `validationChecks` | 7 (6 structural pass + 1 sandbox_execution skipped) |
| `schemaSummary` | 1 text string |
| `artifactSummary` | 1 text string |

#### Exports

`createTemplateArtifactRecord(input)` · `listTemplateArtifactRecords()` · `getTemplateArtifactSummary()`

#### Invariants

- Pure module — no init, not wired to runtime.ts or startRuntime()
- `validationState` fixed to `"structurally_valid"` at creation
- `package.json` and `tsconfig.json` entries are `contentDescriptor` text only
- `createTemplateArtifactRecord` not yet wired to any request flow — store empty at server start
- Future trigger/lifecycle phases add new files only — never modify `templateArtifactCore.ts`
- Next: First Real Template Artifact Diagnostic Seal

---

### Phase 221 — First Real Template Artifact Observe API

**Runtime phase.** Created `routes/templateArtifactObserve.ts` and registered `GET /api/artifacts/virtual`. Read-only diagnostic endpoint exposing the in-memory virtual artifact registry. 1 route file created, 2 source files modified (+1 endpoint, +1 policy). All other counters unchanged.

#### Endpoint: `GET /api/artifacts/virtual`

| Field | Value |
|---|---|
| Method | GET |
| Path | `/api/artifacts/virtual` |
| Permission | monitor |
| Minimum role | operator |
| Blocking | never |

**Response fields:**

| Field | Type | Description |
|---|---|---|
| `generatedAt` | string | ISO 8601 request timestamp |
| `generationEnabled` | `false` | Literal |
| `executionEnabled` | `false` | Literal |
| `deploymentEnabled` | `false` | Literal |
| `persistenceEnabled` | `false` | Literal |
| `executionBlocked` | `true` | Literal |
| `deploymentBlocked` | `true` | Literal |
| `totalArtifacts` | number | Length of artifacts array |
| `summary` | `TemplateArtifactSummary` | Counts by validationState; approvalRequired:true; appType+templateType literals |
| `artifacts` | `TemplateArtifactRecord[]` | All records newest-first |

**Design invariants:**
- Calls only `listTemplateArtifactRecords()` and `getTemplateArtifactSummary()` — never writes to the store
- No artifact creation, approval, or lifecycle-transition routes — future-phase concerns
- Path prefix `/api/artifacts/` — seventh cluster, separate from all six sealed clusters
- Both `executionBlocked` and `deploymentBlocked` are `true` literals — two independent blocking fields
- Access policy: `monitor` + `operator`

---

### Phase 222 — First Real Template Artifact Diagnostic Seal

**Documentation-only phase.** Seals Phases 219–221 (First Real Template Artifact Blueprint, Core Skeleton, Observe API). Virtual artifact diagnostic cluster sealed — 1 endpoint, 2 source files. 0 runtime source files changed. All counters unchanged.

#### Sealed Virtual Artifact Diagnostic Cluster

| Endpoint | Core module | Phase | Status |
|---|---|---|---|
| `GET /api/artifacts/virtual` | `templateArtifactCore.ts` | 221 | Sealed |

#### Sealed Source Files (2 total — never modify)

`core/templateArtifactCore.ts` (220) · `routes/templateArtifactObserve.ts` (221)

#### Seven Sealed Diagnostic Clusters — State After Phase 222

| Cluster | Prefix | Observe endpoint(s) | Core module(s) | Sealed |
|---|---|---|---|---|
| Auth diagnostics | `/api/auth/` | 5 endpoints (Phases 188–197) | `sessionCore`, `rateLimitCore`, `vaultCore` | Yes |
| Sandbox | `/api/sandbox/` | `GET /api/sandbox/runs` | `sandboxCore` | Yes |
| Plugin | `/api/plugins/` | `GET /api/plugins/registry` | `pluginCore` | Yes |
| App Factory | `/api/factory/` | `GET /api/factory/requests` | `appFactoryCore` | Yes |
| Template Registry | `/api/templates/` | `GET /api/templates/registry` | `templateRegistryCore` | Yes |
| Experimental Generation | `/api/generation/` | `GET /api/generation/experimental` | `experimentalGenerationCore` | Yes |
| Virtual Artifacts | `/api/artifacts/` | `GET /api/artifacts/virtual` | `templateArtifactCore` | Yes |

#### Cluster Invariants

- `GET /api/artifacts/virtual` observe-only and read-only — permanently
- `createTemplateArtifactRecord` not yet wired — store empty at server start
- Future artifact-creation/lifecycle phases add new files only — no modifications to sealed files
- Seven-way cluster separation fully established — must be preserved in all future phases
- Blueprint law (Phase 219): no real filesystem writes, no npm install, no runtime execution, no deployment packaging, no Docker generation, no environment variable injection, no vault secret injection, no plugin execution
- Compile-time literals sealed: `appType="crud_app"`, `templateType="crud_template"`, `approvalRequired=true`
- Deterministic contract sealed: 10 virtual files, 5 CRUD routes, 7 validation checks per record
- Next: First Virtual Package Core Skeleton

---

### Phase 223 — First Virtual Package Blueprint

**Documentation-only phase.** Defines the first virtual package architecture layer before any real package installation or build execution. 0 runtime source files changed. All counters unchanged.

#### 1. Package Purpose

| Purpose | Description |
|---|---|
| Virtual representation | Represent installable application dependencies virtually — no real package installation |
| Sandbox compatibility | Prepare future sandbox build compatibility |
| Dependency standardization | Standardize dependency declarations — every virtual package follows the same descriptor shape |
| Deterministic manifests | Support deterministic package manifests — fixed versions, no floating ranges |

#### 2. Virtual Package Structure (6 descriptors)

| Descriptor | Role |
|---|---|
| `package.json descriptor` | Virtual package manifest — text only, never real installable JSON |
| `dependency graph` | Flat list of declared dependencies with pinned versions |
| `script manifest` | Virtual script stubs — descriptors only, no executable bodies |
| `build manifest` | Virtual build configuration descriptor |
| `runtime manifest` | Runtime environment descriptor — Node.js version, environment type |
| `version manifest` | Package version lineage and semver descriptor |

#### 3. Package Metadata (9 fields)

| Field | Type | Notes |
|---|---|---|
| `packageId` | string | Server-generated 16-byte hex |
| `artifactId` | string | Parent artifact record ID |
| `generationId` | string | Parent generation record ID |
| `packageType` | string | e.g. `"crud_app_package"` |
| `dependencyCount` | number | Count of declared virtual dependencies |
| `scriptCount` | number | Count of declared virtual script stubs |
| `validationState` | string | `"structurally_valid"` \| `"failed"` \| `"pending"` |
| `approvalRequired` | `true` | Compile-time literal — never `false` |
| `createdAt` | string | ISO 8601 server-generated timestamp |

#### 4. Validation Rules

**Required (4):** dependency manifest · version manifest · build manifest · runtime manifest

**Prohibited (6):** install execution · shell execution · external downloads · dynamic dependency injection · embedded secrets · deployment scripts

#### 5. Dependency Rules

**Allowed (3):** deterministic dependency lists · fixed versions only · approved dependency categories only

**Prohibited (5):** latest tags · floating versions (`^`, `~`, `*`) · remote install scripts · postinstall execution · arbitrary shell hooks

#### 6. Future Boundaries (7 hard stops)

No npm install · no yarn/pnpm execution · no runtime execution · no Docker build · no external registry access · no deployment packaging · no plugin install execution. Each, if introduced, requires a new separately named blueprint phase.

#### 7. Future Compatibility Targets

Sandbox build layer · dependency resolver · package cache · deployment pipeline · rollback orchestration · fleet version tracking

#### Invariants

- All 6 virtual package descriptors are `contentDescriptor` text strings — never real installable/consumable file bodies
- `approvalRequired=true` is a compile-time literal — never `false`
- Fixed versions only — no `latest`, no `^`, no `~`, no `*` in any dependency entry
- Six prohibited validation items and five prohibited dependency items are absolute — no bypass permitted in any future phase
- Future boundaries are hard stops — each requires a new separately named blueprint phase
- Next: First Virtual Package Core Skeleton

---

### Phase 224 — First Virtual Package Core Skeleton

**Runtime phase.** Created `core/virtualPackageCore.ts` — deterministic, non-executing, in-memory virtual package registry. Pure module, no init, no endpoints, no policies. 1 runtime source file created. All counters unchanged.

#### Types

| Type | Description |
|---|---|
| `PackageValidationState` | `"structurally_valid"` \| `"failed"` \| `"pending"` |
| `PackageType` | `"crud_app_package"` |
| `VirtualDependency` | `name`, `version`, `category`, `descriptor` |
| `VirtualScriptDescriptor` | `name`, `descriptor` |
| `VirtualBuildDescriptor` | `tool`, `outputFormat`, `descriptor` |
| `VirtualRuntimeDescriptor` | `nodeVersion`, `environmentType`, `descriptor` |
| `VirtualVersionDescriptor` | `semver`, `releaseType`, `descriptor` |
| `PackageValidationCheck` | `name`, `status`, `detail` |
| `VirtualPackageRecord` | Full package record (all fields readonly) |
| `CreateVirtualPackageInput` | `artifactId`, `generationId`, `projectName`, `requestedByActorType`, `requestedByActorId` |
| `VirtualPackageSummary` | Aggregate summary |

#### Compile-time Literals

`approvalRequired=true` · `packageType="crud_app_package"` · `validationState="structurally_valid"`

#### Floating-Version Rejection

`isFixedVersion()` rejects: `latest` · `^` · `~` · `*` · `>` · `<` · `=` · `x.` prefix — enforced at record-creation time, structural not advisory.

#### Deterministic Outputs per Record

| Output | Count | Details |
|---|---|---|
| `dependencies` | 6 | node@24.0.0, typescript@5.9.0, zod@3.23.8, esbuild@0.25.0, tsx@4.19.0, @\<name>/types@0.1.0 — all fixed |
| `scriptManifest` | 4 | dev, build, typecheck, start — text descriptors only |
| `buildManifest` | 1 | esbuild / esm |
| `runtimeManifest` | 1 | node 24.0.0 / production |
| `versionManifest` | 1 | 0.1.0 / minor |
| `validationChecks` | 9 | 8 structural checks + 1 `install_execution` skipped |
| `packageJsonDescriptor` | 1 | text string only |

#### Exports

`createVirtualPackageRecord(input)` · `listVirtualPackageRecords()` · `getVirtualPackageSummary()`

#### Invariants

- Pure module — no init, not wired to runtime.ts or startRuntime()
- `validationState` fixed to `"structurally_valid"` at creation
- All descriptors are text-only — no real executable/installable/consumable content
- `createVirtualPackageRecord` not yet wired to any request flow — store empty at server start
- Future trigger/lifecycle phases add new files only — never modify `virtualPackageCore.ts`
- Next: First Virtual Package Observe API — sealed after Phase 225

---

### Phase 225 — First Virtual Package Observe API

**Runtime phase.** Created `routes/virtualPackageObserve.ts` — `GET /api/packages/virtual`. Read-only diagnostic view of the in-memory virtual package registry. +1 endpoint (154→155), +1 policy (154→155). 1 route file created.

#### Route

`GET /api/packages/virtual` → `handleVirtualPackageObserve`

#### Response Shape

| Field | Type | Notes |
|---|---|---|
| `generatedAt` | string | ISO 8601 server-generated timestamp |
| `generationEnabled` | `false` | Compile-time flag |
| `executionEnabled` | `false` | Compile-time flag |
| `deploymentEnabled` | `false` | Compile-time flag |
| `persistenceEnabled` | `false` | Compile-time flag |
| `executionBlocked` | `true` | Compile-time flag |
| `deploymentBlocked` | `true` | Compile-time flag |
| `totalPackages` | number | Count from store |
| `summary` | `VirtualPackageSummary` | Returned by `getVirtualPackageSummary()` |
| `packages` | `VirtualPackageRecord[]` | Newest-first, returned by `listVirtualPackageRecords()` |

#### Access Policy

`GET /api/packages/virtual` · `monitor` permission · `operator` minimum role

#### Invariants

- Pure read — no side effects, no store mutation, no filesystem access
- No creation route, no approval route, no status-transition route, no deletion route
- `virtualPackageCore.ts` and `virtualPackageObserve.ts` are both sealed — never modify
- Future write endpoints add new route files only

---

### Phase 226 — First Virtual Package Diagnostic Seal

**Documentation-only phase.** Seals the first virtual package diagnostic layer (Phases 223–225). 0 runtime source files changed. All counters unchanged.

#### Sealed Cluster: `/api/packages/virtual`

| Phase | Type | File | Status |
|---|---|---|---|
| 223 | Blueprint | documentation-only | Sealed |
| 224 | Core skeleton | `core/virtualPackageCore.ts` | Sealed — never modify |
| 225 | Observe API | `routes/virtualPackageObserve.ts` | Sealed — never modify |

#### Eight Sealed Diagnostic Clusters (after Phase 226)

| Cluster | Sealed observe endpoint | Sealed phase |
|---|---|---|
| `/api/packages/` | `GET /api/packages/virtual` | 226 |
| `/api/artifacts/` | `GET /api/artifacts/virtual` | 222 |
| `/api/generation/` | `GET /api/generation/experimental` | 218 |
| `/api/templates/` | `GET /api/templates/registry` | 214 |
| `/api/factory/` | `GET /api/factory/requests` | 210 |
| `/api/plugins/` | `GET /api/plugins/registry` | 206 |
| `/api/sandbox/` | `GET /api/sandbox/runs` | 202 |
| `/api/auth/` | 5 auth observe endpoints | 198 |

#### Invariants

- All 8 cluster observe routes are permanently sealed — no modification permitted
- `createVirtualPackageRecord` not yet wired to any request flow — store empty at server start
- Future creation/lifecycle phases add new files only — never modify sealed files
- Eight-way cluster separation must be preserved in all future phases
- Next: Dependency Resolution Core Skeleton

---

### Phase 227 — Dependency Resolution Blueprint

**Documentation-only phase.** Defines the deterministic dependency resolution architecture before any real installation or build execution. 0 runtime source files changed. All counters unchanged.

#### 1. Resolver Purpose

| Purpose | Description |
|---|---|
| Compatibility validation | Validate dependency compatibility deterministically |
| Conflict pre-detection | Detect conflicts before any install simulation |
| Sandbox preparation | Prepare future sandbox build orchestration |
| Reproducibility | Support reproducible package graphs |

#### 2. Resolver Inputs

| Input | Source |
|---|---|
| Virtual package descriptors | `VirtualPackageRecord.packageJsonDescriptor` |
| Dependency manifests | `VirtualPackageRecord.dependencies[]` |
| Runtime manifests | `VirtualPackageRecord.runtimeManifest` |
| Build manifests | `VirtualPackageRecord.buildManifest` |
| Version manifests | `VirtualPackageRecord.versionManifest` |

#### 3. Resolution Outputs

| Output | Description |
|---|---|
| Resolved dependency graph | Ordered, deduplicated, conflict-free dependency list |
| Compatibility report | Per-dependency compatibility status |
| Install ordering plan | Topological install order — no execution, descriptor only |
| Conflict report | All detected conflicts with reason codes |
| Deterministic resolution summary | Full audit-ready resolution record |

#### 4. Resolution Rules

**Allowed (4):** fixed versions only · deterministic ordering · approved dependency categories · explicit runtime compatibility

**Prohibited (6):** floating versions · external registry fetch · dynamic dependency injection · peer dependency auto-resolution · remote install hooks · runtime mutation during resolution

#### 5. Conflict Detection (6 types — all required)

| Conflict type | Description |
|---|---|
| Version conflicts | Two or more packages declare incompatible pinned versions of the same dependency |
| Runtime incompatibility | Dependency requires a Node.js version incompatible with the runtime manifest |
| Duplicate package identities | Two entries with same `name` + `version` — deduplication required |
| Circular dependency chains | Dependency A → B → A — must be detected and reported |
| Prohibited dependency categories | Any entry with a disallowed category rejected at input |
| Incompatible build/runtime targets | Build tool version incompatible with declared runtime target |

#### 6. Future Boundaries (7 hard stops)

No npm install · no package download · no filesystem writes · no runtime execution · no sandbox execution · no Docker builds · no deployment packaging. Each, if introduced, requires a new separately named blueprint phase.

#### 7. Future Compatibility Targets

Install simulation · sandbox build execution · package cache · artifact packaging · rollback orchestration · fleet dependency tracking

#### 8. Architectural Law (8 principles)

| Principle | Meaning |
|---|---|
| Deterministic | Same inputs always produce the same resolution output |
| Reproducible | Resolution can be replayed identically at any time |
| Auditable | Every resolution decision is logged and traceable |
| Approval-gated | No resolution output advances to install without approval |
| Sandbox-first | Resolution feeds sandbox simulation before any real install |
| Rollback-compatible | Every resolved graph can be reverted to a prior state |
| Observer-only | Resolver reads state — never mutates it |
| No mutation during resolution | Resolution is a pure read-compute operation |

#### Invariants

- Resolution is observer-only — no mutation of virtual package store, no filesystem writes, no side effects
- Fixed versions only — floating ranges rejected at input boundary, not silently coerced
- All 6 conflict detection types are required — omitting any is an incomplete implementation
- All 6 prohibited operations are absolute — no bypass in any future phase
- All 8 architectural laws bind every future resolver implementation
- Next: Dependency Resolution Observe API

---

### Phase 228 — Dependency Resolution Core Skeleton

**Runtime phase.** Created `core/dependencyResolutionCore.ts` — deterministic, non-executing, in-memory dependency resolution engine. Pure module, no init, no endpoints, no policies. 1 runtime source file created. All counters unchanged.

#### Types

| Type | Description |
|---|---|
| `DependencyConflictType` | 6 values: `version_conflict`, `circular_dependency`, `runtime_incompatibility`, `duplicate_identity`, `prohibited_category`, `incompatible_build_runtime_target` |
| `DependencyResolutionState` | `"structurally_resolved"` \| `"conflict_detected"` \| `"pending"` |
| `ResolvedDependencyNode` | `name`, `version`, `category`, `resolvedAt`, `compatibilityStatus`, `detail` |
| `ResolutionConflictRecord` | `conflictType`, `affectedPackages`, `detail`, `severity` |
| `ResolutionOrderingStep` | `step`, `name`, `version`, `category`, `descriptor` |
| `CompatibilitySummary` | Aggregate compatibility stats + build/runtime flags |
| `ConflictSummary` | `totalConflicts`, `blocking`, `warnings`, `byType` |
| `ResolutionValidationCheck` | `name`, `status`, `detail` |
| `DependencyResolutionRecord` | Full resolution record (all fields readonly) |
| `CreateDependencyResolutionInput` | `packageRecord: VirtualPackageRecord` |
| `DependencyResolutionSummary` | Aggregate summary |

#### Compile-time Literals

`approvalRequired=true` · `executionBlocked=true` · `installationBlocked=true` · `resolutionState="structurally_resolved"`

#### Conflict Detection (all 6 required)

| Function | Detects |
|---|---|
| `detectVersionConflicts` | Same name, differing pinned versions |
| `detectDuplicateIdentities` | Same name@version pair appearing more than once |
| `detectCircularDependencies` | Structural self-referential detection (full graph traversal in future phases) |
| `detectRuntimeIncompatibility` | Node dep version vs runtimeManifest.nodeVersion mismatch |
| `detectProhibitedCategories` | Category not in `{runtime, devDependency, peerDependency}` |
| `detectIncompatibleBuildRuntimeTargets` | esbuild ESM requires Node.js ≥12 |

#### Deterministic Ordering Contract

Graph and install plan: runtime → devDependency → peerDependency → alphabetical within category. Stable across runs with identical inputs.

#### Deterministic Outputs per Record

| Output | Description |
|---|---|
| `resolvedDependencyGraph[]` | Ordered, compatibility-annotated nodes |
| `installOrderingPlan[]` | Topological ordering steps — text descriptors only |
| `compatibilitySummary` | Per-category counts + build/runtime flags |
| `conflictSummary` | Conflict counts by type and severity |
| `validationChecks[]` | 8 structural + 1 `install_execution` skipped |

#### Exports

`createDependencyResolutionRecord(input)` · `listDependencyResolutionRecords()` · `getDependencyResolutionSummary()`

#### Invariants

- Pure module — no init, not wired to runtime.ts or startRuntime()
- `resolutionState` fixed to `"structurally_resolved"` at creation
- All 6 conflict-detection types always run — none may be removed
- Floating-version guard is structural — produces `incompatible` node, not silent coercion
- `createDependencyResolutionRecord` not yet wired to any request flow — store empty at server start
- Future trigger/lifecycle phases add new files only — never modify `dependencyResolutionCore.ts`
- Next: Dependency Resolution Observe API — sealed after Phase 229

---

### Phase 229 — Dependency Resolution Observe API

**Runtime phase.** Created `routes/dependencyResolutionObserve.ts` — `GET /api/resolution/dependencies`. Read-only diagnostic view of the in-memory dependency resolution registry. +1 endpoint (155→156), +1 policy (155→156). 1 route file created.

#### Route

`GET /api/resolution/dependencies` → `handleDependencyResolutionObserve`

#### Response Shape

| Field | Type | Notes |
|---|---|---|
| `generatedAt` | string | ISO 8601 server-generated timestamp |
| `resolutionEnabled` | `false` | Compile-time flag |
| `executionEnabled` | `false` | Compile-time flag |
| `installationEnabled` | `false` | Compile-time flag |
| `persistenceEnabled` | `false` | Compile-time flag |
| `executionBlocked` | `true` | Compile-time flag |
| `installationBlocked` | `true` | Compile-time flag |
| `totalResolutions` | number | Count from store |
| `summary` | `DependencyResolutionSummary` | Returned by `getDependencyResolutionSummary()` |
| `resolutions` | `DependencyResolutionRecord[]` | Newest-first, returned by `listDependencyResolutionRecords()` |

#### Access Policy

`GET /api/resolution/dependencies` · `monitor` permission · `operator` minimum role

#### Invariants

- Pure read — no side effects, no store mutation, no filesystem access
- No creation route, no approval route, no status-transition route, no deletion route
- `dependencyResolutionCore.ts` and `dependencyResolutionObserve.ts` are both sealed — never modify
- Future write endpoints add new route files only

---

### Phase 230 — Dependency Resolution Diagnostic Seal

**Documentation-only phase.** Seals the dependency resolution diagnostic layer (Phases 227–229). 0 runtime source files changed. All counters unchanged.

#### Sealed Cluster: `/api/resolution/dependencies`

| Phase | Type | File | Status |
|---|---|---|---|
| 227 | Blueprint | documentation-only | Sealed |
| 228 | Core skeleton | `core/dependencyResolutionCore.ts` | Sealed — never modify |
| 229 | Observe API | `routes/dependencyResolutionObserve.ts` | Sealed — never modify |

#### Nine Sealed Diagnostic Clusters (after Phase 230)

| Cluster | Sealed observe endpoint | Sealed phase |
|---|---|---|
| `/api/resolution/` | `GET /api/resolution/dependencies` | 230 |
| `/api/packages/` | `GET /api/packages/virtual` | 226 |
| `/api/artifacts/` | `GET /api/artifacts/virtual` | 222 |
| `/api/generation/` | `GET /api/generation/experimental` | 218 |
| `/api/templates/` | `GET /api/templates/registry` | 214 |
| `/api/factory/` | `GET /api/factory/requests` | 210 |
| `/api/plugins/` | `GET /api/plugins/registry` | 206 |
| `/api/sandbox/` | `GET /api/sandbox/runs` | 202 |
| `/api/auth/` | 5 auth observe endpoints | 198 |

#### Invariants

- All 9 cluster observe routes are permanently sealed — no modification permitted
- `createDependencyResolutionRecord` not yet wired to any request flow — store empty at server start
- Future creation/lifecycle phases add new files only — never modify sealed files
- Nine-way cluster separation must be preserved in all future phases
- Next: Install Simulation compact batch

---

### Phase 232 — Sandbox Build Core Skeleton

**Runtime phase.** Created `core/sandboxBuildCore.ts` — deterministic, non-executing, in-memory sandbox build planning engine. Pure module, no init, no runtime wiring.

**Imports:** `TemplateArtifactRecord` · `VirtualPackageRecord` · `DependencyResolutionRecord` · `SandboxRunRecord`

**Compile-time literals:** `approvalRequired=true` · `executionBlocked=true` · `deploymentBlocked=true` · `buildState="virtually_prepared"`

**Build steps (7 — descriptor-only):** `prepare_workspace` · `map_virtual_files` · `validate_package_manifest` · `apply_resolution_order` · `simulate_typecheck` · `simulate_bundle` · `produce_build_report`

**Expected outputs (4 — all virtual):** `virtual-workspace-map` · `virtual-typecheck-result` · `virtual-bundle` · `build-report` — all `isVirtual=true`, `realFileProduced=false`

**Validation checks (7 — all required):** `artifact_structure_exists` · `package_descriptor_exists` · `resolution_graph_exists` · `no_blocked_dependency_conflicts` · `sandbox_approval_present` · `build_steps_descriptor_only` · `output_remains_virtual`

**Exports:** `createSandboxBuildRecord(input)` · `listSandboxBuildRecords()` · `getSandboxBuildSummary()`

**Invariants:** No init · no subsystem registration · no filesystem writes · no execution · not wired to runtime.ts · sealed after Phase 234

---

### Phase 233 — Sandbox Build Observe API

**Runtime phase.** Created `routes/sandboxBuildObserve.ts` — `GET /api/sandbox/build/plans`. Read-only diagnostic view of the in-memory sandbox build plan registry. +1 endpoint (156→157), +1 policy (156→157).

**Response (10 fields):** `generatedAt` · `buildEnabled=false` · `executionEnabled=false` · `deploymentEnabled=false` · `persistenceEnabled=false` · `executionBlocked=true` · `deploymentBlocked=true` · `totalBuildPlans` · `summary` · `buildPlans[]` newest-first

**Access policy:** `GET /api/sandbox/build/plans` · `monitor` · `operator`

**Invariants:** Pure read · no side effects · no store mutation · future write endpoints add new files only · sealed after Phase 234

---

### Phase 234 — Sandbox Build Diagnostic Seal

**Documentation-only phase.** Seals the sandbox build diagnostic layer (Phases 231–233). 0 runtime source files changed. All counters unchanged.

#### Sealed Cluster: `/api/sandbox/build/`

| Phase | Type | File | Status |
|---|---|---|---|
| 231 | Blueprint | documentation-only | Sealed |
| 232 | Core skeleton | `core/sandboxBuildCore.ts` | Sealed — never modify |
| 233 | Observe API | `routes/sandboxBuildObserve.ts` | Sealed — never modify |

#### Ten Sealed Diagnostic Clusters (after Phase 234)

| Cluster | Sealed observe endpoint | Sealed phase |
|---|---|---|
| `/api/sandbox/build/` | `GET /api/sandbox/build/plans` | 234 |
| `/api/resolution/` | `GET /api/resolution/dependencies` | 230 |
| `/api/packages/` | `GET /api/packages/virtual` | 226 |
| `/api/artifacts/` | `GET /api/artifacts/virtual` | 222 |
| `/api/generation/` | `GET /api/generation/experimental` | 218 |
| `/api/templates/` | `GET /api/templates/registry` | 214 |
| `/api/factory/` | `GET /api/factory/requests` | 210 |
| `/api/plugins/` | `GET /api/plugins/registry` | 206 |
| `/api/sandbox/` | `GET /api/sandbox/runs` | 202 |
| `/api/auth/` | 5 auth observe endpoints | 198 |

#### Invariants

- All 10 cluster observe routes are permanently sealed — no modification permitted
- `createSandboxBuildRecord` not yet wired to any request flow — store empty at server start
- Future creation/lifecycle phases add new files only — never modify sealed files
- Ten-way cluster separation must be preserved in all future phases
- Next: Virtual Workspace compact batch

---

### Phase 235 — Install Simulation Blueprint

**Documentation-only phase.** Defines the future install simulation layer before any real package installation, filesystem writes, or execution. 0 runtime source files changed. All counters unchanged.

**Purpose (4):** simulate without executing · manifest validation · build preparation · risk detection

**Simulation inputs (4):** virtual package record · dependency resolution record · sandbox build plan record · operator approval reference

**Simulation outputs (8 fields):** `installSimulationId` · `packageId` · `resolutionId` · `buildPlanId` · `simulatedInstallSteps[]` · `riskReport[]` · `validationChecks[]` · `approvalRequired=true`

**Simulated steps (6 — descriptor-only):** `read_package_manifest` · `verify_fixed_versions` · `apply_resolution_order` · `check_install_risks` · `simulate_dependency_cache` · `produce_install_report`

**Hard boundaries (8 — all absolute):** no npm/yarn/pnpm execution · no package downloads · no filesystem writes · no postinstall scripts · no shell execution · no network access · no runtime execution · no deployment package

**Validation rules (7 — all required):** fixed versions only · resolution graph exists · no blocked conflicts · no remote hooks · no postinstall scripts · no floating versions · simulation descriptor-only

---

### Phase 236 — Install Simulation Core Skeleton

**Runtime phase.** Created `core/installSimulationCore.ts` — deterministic, non-executing, in-memory install simulation engine. Pure module, no init, no runtime wiring.

**Imports:** `VirtualPackageRecord` + `VirtualDependency` · `DependencyResolutionRecord` · `SandboxBuildRecord`

**Compile-time literals:** `approvalRequired=true` · `executionBlocked=true` · `installationBlocked=true` · `deploymentBlocked=true` · `simulationState="descriptor_simulated"`

**Simulated steps (6 — descriptor-only):** `read_package_manifest` · `verify_fixed_versions` · `apply_resolution_order` · `check_install_risks` · `simulate_dependency_cache` · `produce_install_report`

**Risk detectors (3 — structural only):** `detectFloatingVersionRisks` (blocking) · `detectBlockedConflictRisks` (blocking) · `detectMissingResolutionRisks` (high)

**Validation checks (7 — all required):** `fixed_versions_only` · `resolution_graph_exists` · `no_blocked_conflicts` · `no_remote_hooks` · `no_postinstall_scripts` · `no_floating_versions` · `simulation_descriptor_only`

**Exports:** `createInstallSimulationRecord(input)` · `listInstallSimulationRecords()` · `getInstallSimulationSummary()`

**Invariants:** No init · no subsystem registration · no filesystem writes · no execution · not wired to runtime.ts · sealed after Phase 238

---

### Phase 237 — Install Simulation Observe API

**Runtime phase.** Created `routes/installSimulationObserve.ts` — `GET /api/install/simulations`. Read-only diagnostic view of the in-memory install simulation registry. +1 endpoint (157→158), +1 policy (157→158).

**Response (12 fields):** `generatedAt` · `simulationEnabled=false` · `executionEnabled=false` · `installationEnabled=false` · `deploymentEnabled=false` · `persistenceEnabled=false` · `executionBlocked=true` · `installationBlocked=true` · `deploymentBlocked=true` · `totalSimulations` · `summary` · `simulations[]` newest-first

**Access policy:** `GET /api/install/simulations` · `monitor` · `operator`

**Invariants:** Pure read · no side effects · no store mutation · future write endpoints add new files only · sealed after Phase 238

---

### Phase 238 — Install Simulation Diagnostic Seal

**Documentation-only phase.** Seals the install simulation diagnostic layer (Phases 235–237). 0 runtime source files changed. All counters unchanged.

#### Sealed Cluster: `/api/install/`

| Phase | Type | File | Status |
|---|---|---|---|
| 235 | Blueprint | documentation-only | Sealed |
| 236 | Core skeleton | `core/installSimulationCore.ts` | Sealed — never modify |
| 237 | Observe API | `routes/installSimulationObserve.ts` | Sealed — never modify |

#### Eleven Sealed Diagnostic Clusters (after Phase 238)

| Cluster | Sealed observe endpoint | Sealed phase |
|---|---|---|
| `/api/install/` | `GET /api/install/simulations` | 238 |
| `/api/sandbox/build/` | `GET /api/sandbox/build/plans` | 234 |
| `/api/resolution/` | `GET /api/resolution/dependencies` | 230 |
| `/api/packages/` | `GET /api/packages/virtual` | 226 |
| `/api/artifacts/` | `GET /api/artifacts/virtual` | 222 |
| `/api/generation/` | `GET /api/generation/experimental` | 218 |
| `/api/templates/` | `GET /api/templates/registry` | 214 |
| `/api/factory/` | `GET /api/factory/requests` | 210 |
| `/api/plugins/` | `GET /api/plugins/registry` | 206 |
| `/api/sandbox/` | `GET /api/sandbox/runs` | 202 |
| `/api/auth/` | 5 auth observe endpoints | 198 |

#### Invariants

- All 11 cluster observe routes are permanently sealed — no modification permitted
- `createInstallSimulationRecord` not yet wired to any request flow — store empty at server start
- Future creation/lifecycle phases add new files only — never modify sealed files
- Eleven-way cluster separation must be preserved in all future phases
- Next: Preview Pipeline compact batch

---

### Phase 239 — Virtual Workspace Blueprint

**Documentation-only phase.** Defines the virtual workspace layer before any real filesystem workspace is created. 0 runtime source files changed. All counters unchanged.

**Purpose (4):** virtual representation · connect all upstream layer outputs · prepare for future real sandbox filesystem writes · Mother Core untouched

**Inputs (6):** virtual artifact record · virtual package record · dependency resolution record · sandbox build plan · install simulation record · operator approval reference

**Outputs (9 fields):** `workspaceId` · `artifactId` · `packageId` · `resolutionId` · `buildPlanId` · `installSimulationId` · `virtualWorkspaceTree[]` · `workspaceValidationChecks[]` · `approvalRequired=true`

**Virtual structure (8 descriptor-only paths):** `/workspace` · `/workspace/src` · `/workspace/src/routes` · `/workspace/src/services` · `/workspace/src/schemas` · `/workspace/config` · `/workspace/reports` · `/workspace/manifests`

**Hard boundaries (9 — all absolute):** no real directory creation · no filesystem writes · no package installation · no shell execution · no runtime execution · no network access · no vault access · no deployment package · no generated app launch

**Validation rules (8 — all required):** `artifact_exists` · `package_exists` · `resolution_exists` · `build_plan_exists` · `install_simulation_exists` · `workspace_tree_descriptor_only` · `no_real_paths_outside_virtual_root` · `output_remains_virtual`

---

### Phase 240 — Virtual Workspace Core Skeleton

**Runtime phase.** Created `core/virtualWorkspaceCore.ts` — deterministic, non-writing, in-memory virtual workspace descriptor engine. Pure module, no init, no runtime wiring.

**Imports (5):** `TemplateMetadataRecord` (templateRegistryCore) · `VirtualPackageRecord` (virtualPackageCore) · `DependencyResolutionRecord` (dependencyResolutionCore) · `SandboxBuildRecord` (sandboxBuildCore) · `InstallSimulationRecord` (installSimulationCore)

**Note:** `TemplateArtifactRecord` does not exist — correct type is `TemplateMetadataRecord`. All future phases must use `TemplateMetadataRecord`.

**Compile-time literals:** `approvalRequired=true` · `executionBlocked=true` · `deploymentBlocked=true` · `filesystemBlocked=true` · `workspaceState="virtually_mapped"`

**Virtual tree (8 paths — all carry `isVirtual=true` + `filesystemBlocked=true`):** `/workspace` · `/workspace/src` · `/workspace/src/routes` · `/workspace/src/services` · `/workspace/src/schemas` · `/workspace/config` · `/workspace/reports` · `/workspace/manifests`

**Validation checks (8 — all required):** `artifact_exists` · `package_exists` · `resolution_exists` · `build_plan_exists` · `install_simulation_exists` · `workspace_tree_descriptor_only` · `no_real_paths_outside_virtual_root` · `output_remains_virtual`

**Exports:** `createVirtualWorkspaceRecord(input)` · `listVirtualWorkspaceRecords()` · `getVirtualWorkspaceSummary()`

**Invariants:** No init · no subsystem registration · no filesystem writes · no execution · not wired to runtime.ts · sealed after Phase 242

---

### Phase 241 — Virtual Workspace Observe API

**Runtime phase.** Created `routes/virtualWorkspaceObserve.ts` — `GET /api/workspaces/virtual`. Read-only diagnostic view of the in-memory virtual workspace registry. +1 endpoint (158→159), +1 policy (158→159).

**Response (12 fields):** `generatedAt` · `workspaceEnabled=false` · `filesystemEnabled=false` · `executionEnabled=false` · `deploymentEnabled=false` · `persistenceEnabled=false` · `filesystemBlocked=true` · `executionBlocked=true` · `deploymentBlocked=true` · `totalWorkspaces` · `summary` · `workspaces[]` newest-first

**Access policy:** `GET /api/workspaces/virtual` · `monitor` · `operator`

**Invariants:** Pure read · no side effects · no store mutation · future write endpoints add new files only · sealed after Phase 242

---

### Phase 242 — Virtual Workspace Diagnostic Seal

**Documentation-only phase.** Seals the virtual workspace diagnostic layer (Phases 239–241). 0 runtime source files changed. All counters unchanged.

#### Sealed Cluster: `/api/workspaces/`

| Phase | Type | File | Status |
|---|---|---|---|
| 239 | Blueprint | documentation-only | Sealed |
| 240 | Core skeleton | `core/virtualWorkspaceCore.ts` | Sealed — never modify |
| 241 | Observe API | `routes/virtualWorkspaceObserve.ts` | Sealed — never modify |

#### Twelve Sealed Diagnostic Clusters (after Phase 242)

| Cluster | Sealed observe endpoint | Sealed phase |
|---|---|---|
| `/api/workspaces/` | `GET /api/workspaces/virtual` | 242 |
| `/api/install/` | `GET /api/install/simulations` | 238 |
| `/api/sandbox/build/` | `GET /api/sandbox/build/plans` | 234 |
| `/api/resolution/` | `GET /api/resolution/dependencies` | 230 |
| `/api/packages/` | `GET /api/packages/virtual` | 226 |
| `/api/artifacts/` | `GET /api/artifacts/virtual` | 222 |
| `/api/generation/` | `GET /api/generation/experimental` | 218 |
| `/api/templates/` | `GET /api/templates/registry` | 214 |
| `/api/factory/` | `GET /api/factory/requests` | 210 |
| `/api/plugins/` | `GET /api/plugins/registry` | 206 |
| `/api/sandbox/` | `GET /api/sandbox/runs` | 202 |
| `/api/auth/` | 5 auth observe endpoints | 198 |

#### Invariants

- All 12 cluster observe routes are permanently sealed — no modification permitted
- `createVirtualWorkspaceRecord` not yet wired to any request flow — store empty at server start
- Future creation/lifecycle phases add new files only — never modify sealed files
- Twelve-way cluster separation must be preserved in all future phases
- `TemplateArtifactRecord` does not exist — correct type is `TemplateMetadataRecord` from `templateRegistryCore.ts`
- Next: Experimental Production Flow compact batch

---

### Phase 243 — Preview Pipeline Blueprint

**Documentation-only phase.** Defines the preview pipeline layer before any real rendering, runtime execution, or generated app launch. 0 runtime source files changed. All counters unchanged.

**Purpose (4):** workspace/build/install → preview descriptors · prepare future visual/application preview · verify app structure before execution · operator review gate before controlled execution

**Inputs (5):** virtual workspace record · sandbox build record · install simulation record · virtual artifact record (`TemplateMetadataRecord`) · operator approval reference

**Outputs (9 fields):** `previewId` · `workspaceId` · `buildPlanId` · `installSimulationId` · `artifactId` · `previewScreens[]` · `previewRoutes[]` · `previewValidationChecks[]` · `approvalRequired=true`

**Preview screens (6 — descriptor-only):** `app_home` · `list_view` · `create_view` · `detail_view` · `edit_view` · `health_view`

**Hard boundaries (8 — all absolute):** no real rendering · no browser launch · no runtime execution · no generated app launch · no filesystem writes · no network access · no vault access · no deployment package

**Validation rules (7 — all required):** `workspace_exists` · `build_plan_exists` · `install_simulation_exists` · `artifact_exists` · `preview_screens_descriptor_only` · `preview_routes_mapped` · `output_remains_virtual`

---

### Phase 244 — Preview Pipeline Core Skeleton

**Runtime phase.** Created `core/previewPipelineCore.ts` — deterministic, non-rendering, in-memory preview descriptor engine. Pure module, no init, no runtime wiring.

**Imports (4):** `VirtualWorkspaceRecord` · `SandboxBuildRecord` · `InstallSimulationRecord` · `TemplateMetadataRecord`

**Compile-time literals:** `approvalRequired=true` · `renderingBlocked=true` · `browserLaunchBlocked=true` · `executionBlocked=true` · `deploymentBlocked=true` · `previewState="descriptor_preview"`

**Preview screens (6 — `renderingBlocked=true` + `browserLaunchBlocked=true` on all):** `app_home` · `list_view` · `create_view` · `detail_view` · `edit_view` · `health_view`

**Preview routes (6 — `executionBlocked=true` on all):** `/` · `/list` · `/create` · `/detail/:id` · `/edit/:id` · `/health` — one-to-one mapping to screens

**Validation checks (7 — all required):** `workspace_exists` · `build_plan_exists` · `install_simulation_exists` · `artifact_exists` · `preview_screens_descriptor_only` · `preview_routes_mapped` · `output_remains_virtual`

**Exports:** `createPreviewPipelineRecord(input)` · `listPreviewPipelineRecords()` · `getPreviewPipelineSummary()`

**Invariants:** No init · no subsystem registration · no rendering · no filesystem writes · not wired to runtime.ts · sealed after Phase 246

---

### Phase 245 — Preview Pipeline Observe API

**Runtime phase.** Created `routes/previewPipelineObserve.ts` — `GET /api/preview/pipelines`. Read-only diagnostic view of the in-memory preview pipeline registry. +1 endpoint (159→160), +1 policy (159→160).

**Response (14 fields):** `generatedAt` · `previewEnabled=false` · `renderingEnabled=false` · `browserLaunchEnabled=false` · `executionEnabled=false` · `deploymentEnabled=false` · `persistenceEnabled=false` · `renderingBlocked=true` · `browserLaunchBlocked=true` · `executionBlocked=true` · `deploymentBlocked=true` · `totalPreviews` · `summary` · `previews[]` newest-first

**Access policy:** `GET /api/preview/pipelines` · `monitor` · `operator`

**Invariants:** Pure read · no side effects · no store mutation · future write endpoints add new files only · sealed after Phase 246

---

### Phase 246 — Preview Pipeline Diagnostic Seal

**Documentation-only phase.** Seals the preview pipeline diagnostic layer (Phases 243–245). 0 runtime source files changed. All counters unchanged.

#### Sealed Cluster: `/api/preview/`

| Phase | Type | File | Status |
|---|---|---|---|
| 243 | Blueprint | documentation-only | Sealed |
| 244 | Core skeleton | `core/previewPipelineCore.ts` | Sealed — never modify |
| 245 | Observe API | `routes/previewPipelineObserve.ts` | Sealed — never modify |

#### Thirteen Sealed Diagnostic Clusters (after Phase 246)

| Cluster | Sealed observe endpoint | Sealed phase |
|---|---|---|
| `/api/preview/` | `GET /api/preview/pipelines` | 246 |
| `/api/workspaces/` | `GET /api/workspaces/virtual` | 242 |
| `/api/install/` | `GET /api/install/simulations` | 238 |
| `/api/sandbox/build/` | `GET /api/sandbox/build/plans` | 234 |
| `/api/resolution/` | `GET /api/resolution/dependencies` | 230 |
| `/api/packages/` | `GET /api/packages/virtual` | 226 |
| `/api/artifacts/` | `GET /api/artifacts/virtual` | 222 |
| `/api/generation/` | `GET /api/generation/experimental` | 218 |
| `/api/templates/` | `GET /api/templates/registry` | 214 |
| `/api/factory/` | `GET /api/factory/requests` | 210 |
| `/api/plugins/` | `GET /api/plugins/registry` | 206 |
| `/api/sandbox/` | `GET /api/sandbox/runs` | 202 |
| `/api/auth/` | 5 auth observe endpoints | 198 |

#### Invariants

- All 13 cluster observe routes are permanently sealed — no modification permitted
- `createPreviewPipelineRecord` not yet wired to any request flow — store empty at server start
- Future creation/lifecycle phases add new files only — never modify sealed files
- Thirteen-way cluster separation must be preserved in all future phases
- Next: Phase 251 resumes next session

---

### Phase 247 — Experimental Production Flow Blueprint

**Documentation-only phase.** Defines the first end-to-end experimental production flow before any real execution, filesystem writes, or deployment. 0 runtime source files changed. All counters unchanged.

**Purpose (4):** connect full virtual pipeline → one experimental production descriptor · prove end-to-end request-to-preview sequence · prepare future controlled execution · keep all outputs virtual and approval-gated

**Inputs (11):** factory request · template metadata · generation record · artifact record · package record · dependency resolution record · sandbox build record · install simulation record · virtual workspace record · preview pipeline record · operator approval reference

**Outputs (6):** `experimentalFlowId` · `linkedRecordIds` · `stageSequence[]` · `readinessReport` · `blockingReport` · `approvalRequired=true`

**Stage sequence (10 — descriptor-only):** `receive_request` → `select_template` → `generate_virtual_artifact` → `create_virtual_package` → `resolve_dependencies` → `prepare_sandbox_build` → `simulate_install` → `map_virtual_workspace` → `generate_preview` → `operator_review`

**Hard boundaries (8 — all absolute):** no real execution · no filesystem writes · no package install · no browser launch · no deployment package · no network access · no vault access · no generated app launch

**Validation rules (7 — all required):** `all_linked_records_exist` · `stage_order_deterministic` · `no_blocked_dependency_conflicts` · `install_simulation_passed_structurally` · `preview_descriptors_exist` · `approval_gate_present` · `output_remains_virtual`

---

### Phase 248 — Experimental Production Flow Core Skeleton

**Runtime phase.** Created `core/experimentalProductionFlowCore.ts` — deterministic, non-executing, in-memory end-to-end flow descriptor engine. Pure module, no init, no runtime wiring.

**Imports (10):** `AppFactoryRequestRecord` (appFactoryCore) · `TemplateMetadataRecord` (templateRegistryCore) · `ExperimentalGenerationRecord` (experimentalGenerationCore) · `TemplateArtifactRecord` (templateArtifactCore) · `VirtualPackageRecord` (virtualPackageCore) · `DependencyResolutionRecord` (dependencyResolutionCore) · `SandboxBuildRecord` (sandboxBuildCore) · `InstallSimulationRecord` (installSimulationCore) · `VirtualWorkspaceRecord` (virtualWorkspaceCore) · `PreviewPipelineRecord` (previewPipelineCore)

**Compile-time literals:** `flowState="descriptor_ready"` · `approvalRequired=true` · `executionBlocked=true` · `filesystemBlocked=true` · `deploymentBlocked=true` · `implementationPhase="blueprint_descriptor"` · `allStagesBlocked=true`

**Canonical stage sequence (10 — fixed):** `receive_request` → `select_template` → `generate_virtual_artifact` → `create_virtual_package` → `resolve_dependencies` → `prepare_sandbox_build` → `simulate_install` → `map_virtual_workspace` → `generate_preview` → `operator_review`

**Linked record fields:** `factoryRequest.factoryRequestId` · `templateMetadata.templateId` · `generationRecord.generationId` · `packageRecord.packageId` · `resolutionRecord.resolutionId` · `buildRecord.buildPlanId` · `installRecord.installSimulationId` · `workspaceRecord.workspaceId` · `previewRecord.previewId` · `operatorApprovalRef`

**Readiness checks (7):** `all_linked_records_exist` (always true) · `stage_order_deterministic` (always true) · `no_blocked_dependency_conflicts` (conflictSummary.totalConflicts===0) · `install_simulation_passed_structurally` (simulationState==="descriptor_simulated") · `preview_descriptors_exist` (previewScreens.length>0) · `approval_gate_present` (operatorApprovalRef.length>0) · `output_remains_virtual` (always true)

**Blocking checks (10):** one per stage, all `blocked: true`

**Exports:** `createExperimentalProductionFlowRecord` · `listExperimentalProductionFlowRecords` · `getExperimentalProductionFlowSummary`

**Invariants:** No init · no subsystem registration · no rendering · no filesystem writes · not wired to runtime.ts · sealed after Phase 250

---

### Phase 249 — Experimental Production Flow Observe API

**Runtime phase.** Created `routes/experimentalProductionFlowObserve.ts` — `GET /api/production/experimental-flows`. Read-only diagnostic view of the in-memory experimental production flow registry. +1 endpoint (160→161), +1 policy (160→161).

**Response (13 fields):** `generatedAt` · `flowEnabled=false` · `executionEnabled=false` · `filesystemEnabled=false` · `deploymentEnabled=false` · `persistenceEnabled=false` · `allStagesBlocked=true` · `executionBlocked=true` · `filesystemBlocked=true` · `deploymentBlocked=true` · `totalFlows` · `summary` · `flows[]` newest-first

**Access policy:** `GET /api/production/experimental-flows` · `monitor` · `operator`

**Invariants:** Pure read · no side effects · no store mutation · future write endpoints add new files only · sealed after Phase 250

---

### Phase 250 — Experimental Production Flow Diagnostic Seal & Session Pause

**Documentation-only phase.** Seals the experimental production flow diagnostic layer (Phases 247–249). 0 runtime source files changed. All counters unchanged. Session paused at Phase 250.

#### Sealed Cluster: `/api/production/`

| Phase | Type | File | Status |
|---|---|---|---|
| 247 | Blueprint | documentation-only | Sealed |
| 248 | Core skeleton | `core/experimentalProductionFlowCore.ts` | Sealed — never modify |
| 249 | Observe API | `routes/experimentalProductionFlowObserve.ts` | Sealed — never modify |

#### Fourteen Sealed Diagnostic Clusters (after Phase 250)

| Cluster | Sealed observe endpoint | Sealed phase |
|---|---|---|
| `/api/production/` | `GET /api/production/experimental-flows` | 250 |
| `/api/preview/` | `GET /api/preview/pipelines` | 246 |
| `/api/workspaces/` | `GET /api/workspaces/virtual` | 242 |
| `/api/install/` | `GET /api/install/simulations` | 238 |
| `/api/sandbox/build/` | `GET /api/sandbox/build/plans` | 234 |
| `/api/resolution/` | `GET /api/resolution/dependencies` | 230 |
| `/api/packages/` | `GET /api/packages/virtual` | 226 |
| `/api/artifacts/` | `GET /api/artifacts/virtual` | 222 |
| `/api/generation/` | `GET /api/generation/experimental` | 218 |
| `/api/templates/` | `GET /api/templates/registry` | 214 |
| `/api/factory/` | `GET /api/factory/requests` | 210 |
| `/api/plugins/` | `GET /api/plugins/registry` | 206 |
| `/api/sandbox/` | `GET /api/sandbox/runs` | 202 |
| `/api/auth/` | 5 auth observe endpoints | 198 |

#### Invariants

- All 14 cluster observe routes are permanently sealed — no modification permitted
- `createExperimentalProductionFlowRecord` not yet wired to any request flow — store empty at server start
- `TemplateArtifactRecord` lives in `templateArtifactCore.ts` — distinct from `TemplateMetadataRecord` in `templateRegistryCore.ts`
- Correct Phase 248 field names: `factoryRequestId` · `buildPlanId` · `installSimulationId` · `simulationState` — always grep the source interface before referencing a field
- Future creation/lifecycle phases add new files only — never modify sealed files
- Fourteen-way cluster separation must be preserved in all future phases
- Next: Controlled Execution compact batch (Phase 254)

---

### Phase 251 — Controlled Execution Sandbox Blueprint

**Documentation-only phase.** Defines the controlled execution sandbox layer before any real execution, filesystem mutation, or deployment. 0 runtime source files changed. All counters unchanged.

**Purpose (4):** prepare future real execution inside isolated sandbox boundaries · separate execution authority from Mother Core · enforce approval-gated runtime behavior · establish rollback-compatible execution contracts

**Inputs (6):** experimental production flow record · preview pipeline record · virtual workspace record · install simulation record · operator approval reference · execution policy reference

**Outputs (7):** `controlledExecutionId` · `executionPlan[]` · `executionStages[]` · `executionValidationChecks[]` · `executionBoundaryReport` · `rollbackPreparationReport` · `approvalRequired=true`

**Execution stages (7 — descriptor-only):** `validate_execution_context` → `allocate_sandbox_runtime` → `prepare_virtual_workspace_mount` → `validate_execution_policy` → `verify_install_simulation` → `prepare_runtime_guards` → `await_operator_execution_approval`

**Hard boundaries (8 — all absolute):** no real code execution · no unrestricted filesystem writes · no unrestricted shell access · no unrestricted network access · no Mother Core mutation · no vault mutation · no deployment execution · no background autonomous execution

**Validation rules (7):** `experimental_flow_exists` · `preview_exists` · `workspace_exists` · `install_simulation_passed` · `execution_policy_present` · `rollback_preparation_valid` · `output_remains_descriptor_only`

**Architectural laws (7 — permanent):** isolation · approval gate · rollback-first · sandbox-first · determinism · audit trail · separation of authority

---

### Phase 252 — Controlled Execution Core Skeleton

**Runtime phase.** Created `core/controlledExecutionCore.ts` — deterministic, non-executing, in-memory execution descriptor engine. Pure module, no init, no runtime wiring.

**Imports (4):** `ExperimentalProductionFlowRecord` · `PreviewPipelineRecord` · `VirtualWorkspaceRecord` · `InstallSimulationRecord`

**Compile-time literals:** `executionState="awaiting_operator_execution_approval"` · `approvalRequired=true` · `executionBlocked=true` · `filesystemBlocked=true` · `networkBlocked=true` · `deploymentBlocked=true` · `autonomousBlocked=true` · `implementationPhase="descriptor_only"` · `rollbackRequired=true` · `rollbackDescriptorOnly=true` · `motherCoreMutation=false` · `vaultMutation=false` · `shellAccess=false`

**`ExecutionBoundaryReport` (compile-time constant, 9 fields):** `executionBlocked=true` · `filesystemBlocked=true` · `networkBlocked=true` · `deploymentBlocked=true` · `autonomousBlocked=true` · `motherCoreMutation=false` · `vaultMutation=false` · `shellAccess=false` · `summary`

**`RollbackPreparationReport` (6 fields):** `rollbackRequired=true` · `rollbackDescriptorOnly=true` · `rollbackStagesCount=7` · `rollbackTargetStage="validate_execution_context"` · `rollbackReady` (driven by validation) · `summary`

**Canonical stages (7 — fixed):** `validate_execution_context` → `allocate_sandbox_runtime` → `prepare_virtual_workspace_mount` → `validate_execution_policy` → `verify_install_simulation` → `prepare_runtime_guards` → `await_operator_execution_approval`

**Execution plan (7 steps):** one per stage, all `blocked: true`

**Validation checks (7):** `experimental_flow_exists` (always true) · `preview_exists` (previewScreens.length>0) · `workspace_exists` (always true) · `install_simulation_passed` (simulationState==="descriptor_simulated") · `execution_policy_present` (executionPolicyRef.length>0) · `rollback_preparation_valid` (always true) · `output_remains_descriptor_only` (always true)

**Exports:** `createControlledExecutionRecord` · `listControlledExecutionRecords` · `getControlledExecutionSummary`

**Invariants:** No init · no subsystem registration · no real execution · not wired to runtime.ts · sealed after Phase 254

---

### Phase 253 — Controlled Execution Observe API

**Runtime phase.** Created `routes/controlledExecutionObserve.ts` — `GET /api/execution/controlled`. Read-only diagnostic view of the in-memory controlled execution descriptor registry. +1 endpoint (161→162), +1 policy (161→162).

**Response (15 fields):** `generatedAt` · `executionEnabled=false` · `filesystemEnabled=false` · `networkEnabled=false` · `deploymentEnabled=false` · `autonomousEnabled=false` · `persistenceEnabled=false` · `executionBlocked=true` · `filesystemBlocked=true` · `networkBlocked=true` · `deploymentBlocked=true` · `autonomousBlocked=true` · `totalExecutions` · `summary` · `executions[]` newest-first

**Access policy:** `GET /api/execution/controlled` · `monitor` · `operator`

**Invariants:** Pure read · no side effects · no store mutation · future write endpoints add new files only · sealed after Phase 254

---

### Phase 254 — Controlled Execution Diagnostic Seal

**Documentation-only phase.** Seals the controlled execution diagnostic layer (Phases 251–253). 0 runtime source files changed. All counters unchanged.

#### Sealed Cluster: `/api/execution/`

| Phase | Type | File | Status |
|---|---|---|---|
| 251 | Blueprint | documentation-only | Sealed |
| 252 | Core skeleton | `core/controlledExecutionCore.ts` | Sealed — never modify |
| 253 | Observe API | `routes/controlledExecutionObserve.ts` | Sealed — never modify |

#### Fifteen Sealed Diagnostic Clusters (after Phase 254)

| Cluster | Sealed observe endpoint | Sealed phase |
|---|---|---|
| `/api/execution/` | `GET /api/execution/controlled` | 254 |
| `/api/production/` | `GET /api/production/experimental-flows` | 250 |
| `/api/preview/` | `GET /api/preview/pipelines` | 246 |
| `/api/workspaces/` | `GET /api/workspaces/virtual` | 242 |
| `/api/install/` | `GET /api/install/simulations` | 238 |
| `/api/sandbox/build/` | `GET /api/sandbox/build/plans` | 234 |
| `/api/resolution/` | `GET /api/resolution/dependencies` | 230 |
| `/api/packages/` | `GET /api/packages/virtual` | 226 |
| `/api/artifacts/` | `GET /api/artifacts/virtual` | 222 |
| `/api/generation/` | `GET /api/generation/experimental` | 218 |
| `/api/templates/` | `GET /api/templates/registry` | 214 |
| `/api/factory/` | `GET /api/factory/requests` | 210 |
| `/api/plugins/` | `GET /api/plugins/registry` | 206 |
| `/api/sandbox/` | `GET /api/sandbox/runs` | 202 |
| `/api/auth/` | 5 auth observe endpoints | 198 |

#### Invariants

- All 15 cluster observe routes are permanently sealed — no modification permitted
- `createControlledExecutionRecord` not yet wired to any request flow — store empty at server start
- `networkBlocked` is a distinct compile-time literal introduced in Phase 252 — must accompany `executionBlocked`, `filesystemBlocked`, `deploymentBlocked`, `autonomousBlocked` in all controlled execution context
- Future creation/lifecycle phases add new files only — never modify sealed files
- Fifteen-way cluster separation must be preserved in all future phases
- Next: Execution-path write preparation stack (Phases 255–262) + Compression Seal (Phase 263)

---

### Phase 255 — Real Sandbox Filesystem Blueprint

**Documentation-only phase.** Defines the real sandbox filesystem layer before any unrestricted filesystem access or execution. 0 runtime source files changed.

**Purpose (4):** prepare isolated real filesystem environments · separate writable sandbox space from Mother Core · establish controlled mount boundaries · support future controlled artifact generation

**Inputs (5):** controlled execution record · virtual workspace record · sandbox execution policy · rollback preparation report · operator approval reference

**Outputs (7):** `sandboxFilesystemId` · `mountPlan[]` · `writableZones[]` · `protectedZones[]` · `filesystemValidationChecks[]` · `rollbackFilesystemPlan` · `approvalRequired=true`

**Writable zones (3):** `/sandbox/workspace` · `/sandbox/tmp` · `/sandbox/build-cache`

**Protected zones (5):** `/mother-core` · `/vault` · `/runtime-config` · `/system` · `/network-secrets`

**Hard boundaries (8):** no Mother Core writes · no unrestricted traversal · no vault access · no unrestricted shell · no unrestricted network · no deployment writes · no background autonomous mutation · rollback required before any writable access

**Architectural laws (6):** isolation · scoped writes · immutable protected zones · rollback-first · audit trail · deterministic mount ordering

---

### Phase 256 — Real Sandbox Filesystem Core Skeleton

**Runtime phase.** Created `core/sandboxFilesystemCore.ts` — deterministic non-writing in-memory filesystem boundary descriptor engine.

**Imports (2):** `ControlledExecutionRecord` · `VirtualWorkspaceRecord` (ID field: `workspaceId`, not `virtualWorkspaceId`)

**Compile-time literals:** `filesystemState="descriptor_mount_planned"` · `approvalRequired=true` · `filesystemWritesBlocked=true` · `motherCoreWritesBlocked=true` · `vaultAccessBlocked=true` · `shellAccessBlocked=true` · `networkAccessBlocked=true` · `deploymentWritesBlocked=true` · `rollbackRequired=true` · `rollbackDescriptorOnly=true` · `implementationPhase="descriptor_only"` · `scoped=true` · `overlapsProtected=false` · `immutable=true` · `sandboxAccess=false` · `writeBlocked=true`

**Mount plan:** deterministic 8-entry ordering — 3 writable (index 0–2) then 5 protected (index 3–7), all `writeBlocked:true`

**Validation (7):** `execution_record_exists` · `workspace_exists` · `writable_zones_isolated` · `protected_zones_enforced` · `rollback_plan_valid` · `approval_gate_present` · `output_remains_descriptor_only`

**Exports:** `createSandboxFilesystemRecord` · `listSandboxFilesystemRecords` · `getSandboxFilesystemSummary`

---

### Phase 257 — Controlled Write Guard Blueprint

**Documentation-only phase.** Defines the write guard layer: decides whether future writes would be allowed inside scoped sandbox zones after policy, approval, rollback, and zone validation.

**Inputs (2):** `SandboxFilesystemRecord` · `ControlledExecutionRecord`

**Allowed zones (3):** `/sandbox/workspace` · `/sandbox/tmp` · `/sandbox/build-cache`

**Blocked zones (5 — always):** `/mother-core` · `/vault` · `/runtime-config` · `/system` · `/network-secrets`

---

### Phase 258 — Controlled Write Guard Core Skeleton

**Runtime phase.** Created `core/controlledWriteGuardCore.ts` — in-memory write guard descriptor engine.

**Imports (2):** `SandboxFilesystemRecord` + zone path types · `ControlledExecutionRecord`

**Compile-time literals:** `guardState="descriptor_guard_ready"` · `approvalRequired=true` · `realWritesEnabled=false` · `motherCoreWritesBlocked=true` · `protectedZoneWritesBlocked=true` · `rollbackRequired=true` · `implementationPhase="descriptor_only"`

**Write policy checks (7):** `filesystem_record_exists` · `execution_record_exists` · `rollback_ready` · `approval_reference_present` · `allowed_zones_are_sandbox_scoped` · `protected_zones_fully_blocked` · `output_remains_descriptor_only`

**Allowed zones:** derived from `filesystemRecord.writableZones` — all `writeAllowed:false`, `realWritesEnabled:false`

**Exports:** `createWriteGuardRecord` · `listWriteGuardRecords` · `getWriteGuardSummary`

---

### Phase 259 — Real Write Enablement Gate Blueprint

**Documentation-only phase.** Defines the final pre-write gate: decides whether future real writes are eligible after filesystem boundary readiness, write guard approval, rollback confirmation, and zone validation.

**Inputs (3):** `SandboxFilesystemRecord` · `WriteGuardRecord` · `ControlledExecutionRecord`

**Compile-time literals:** `approvalRequired=true` · `realWritesEnabled=false` · `writeGateState="pre_write_ready"` · `motherCoreWritesBlocked=true` · `vaultWritesBlocked=true` · `shellAccessBlocked=true` · `networkAccessBlocked=true` · `deploymentWritesBlocked=true`

**Validation rules (8):** `filesystem_record_exists` · `write_guard_exists` · `execution_record_exists` · `rollback_ready` · `writable_zones_eligible` · `protected_zones_blocked` · `approval_gate_present` · `real_writes_still_disabled`

---

### Phase 260 — Real Write Enablement Gate Core Skeleton

**Runtime phase.** Created `core/realWriteEnablementGateCore.ts` — in-memory write enablement gate descriptor engine.

**Imports (3):** `SandboxFilesystemRecord` + zone path types · `WriteGuardRecord` · `ControlledExecutionRecord`

**Compile-time literals:** `writeGateState="pre_write_ready"` · `realWritesEnabled=false` · `approvalRequired=true` · `motherCoreWritesBlocked=true` · `vaultWritesBlocked=true` · `shellAccessBlocked=true` · `networkAccessBlocked=true` · `deploymentWritesBlocked=true` · `implementationPhase="descriptor_only"`

**Gate validation checks (8):** `filesystem_record_exists` · `write_guard_exists` · `execution_record_exists` · `rollback_ready` (combined: `filesystemRecord` AND `writeGuardRecord`) · `writable_zones_eligible` · `protected_zones_blocked` · `approval_gate_present` · `real_writes_still_disabled`

**`WriteReadinessReport`:** `realWritesEnabled=false` · `rollbackReady` (combined) · `writeGuardClearance` · `allChecksPass` · `summary`

**Exports:** `createWriteGateRecord` · `listWriteGateRecords` · `getWriteGateSummary`

---

### Phase 261 — Sandbox Write Plan Blueprint

**Documentation-only phase.** Defines the sandbox write plan layer: maps virtual workspace paths into allowed sandbox zones as write operation descriptors. All writes remain disabled.

**Inputs (4):** `SandboxFilesystemRecord` · `WriteGuardRecord` · `WriteGateRecord` · `ControlledExecutionRecord`

**Compile-time literals:** `approvalRequired=true` · `realWritesEnabled=false` · `writePlanState="descriptor_write_plan_ready"` · `motherCoreWritesBlocked=true` · `protectedZoneWritesBlocked=true` · `rollbackRequired=true` · `implementationPhase="descriptor_only"`

**Validation rules (9):** `filesystem_record_exists` · `write_guard_exists` · `write_gate_exists` · `execution_record_exists` · `real_writes_disabled` · `all_writes_target_allowed_zones` · `protected_zones_blocked` · `rollback_plan_ready` · `output_remains_descriptor_only`

---

### Phase 262 — Sandbox Write Plan Core Skeleton

**Runtime phase.** Created `core/sandboxWritePlanCore.ts` — in-memory sandbox write plan descriptor engine.

**Imports (4):** `SandboxFilesystemRecord` + zone path types · `WriteGuardRecord` · `WriteGateRecord` · `ControlledExecutionRecord`

**Compile-time literals:** `writePlanState="descriptor_write_plan_ready"` · `realWritesEnabled=false` · `approvalRequired=true` · `motherCoreWritesBlocked=true` · `protectedZoneWritesBlocked=true` · `rollbackRequired=true` · `implementationPhase="descriptor_only"`

**Planned writes (3):** one per writable zone, operation types cycle `create`/`overwrite`/`append`, all `writeBlocked:true`, `realWriteEnabled:false`

**Validation (9 checks):** cross-validates all 4 upstream records; `rollback_plan_ready` combines readiness from `filesystemRecord`, `writeGuardRecord`, and `writeGateRecord`

**`RollbackWritePlan`:** `rollbackRequired=true` · `rollbackDescriptorOnly=true` · `rollbackPlannedCount=3` · `rollbackSequenceReady` driven by all-checks-pass

**Exports:** `createWritePlanRecord` · `listWritePlanRecords` · `getWritePlanSummary`

---

### Phase 263 — Execution Path Compression Seal

**Documentation-only phase.** Seals the execution-path write preparation stack (Phases 255–262). 0 runtime source files changed. All counters unchanged.

#### Sealed Stack: Execution-Path Write Preparation

| Phase | Type | File | Status |
|---|---|---|---|
| 255 | Blueprint | documentation-only | Sealed |
| 256 | Core skeleton | `core/sandboxFilesystemCore.ts` | Sealed — never modify |
| 257 | Blueprint | documentation-only | Sealed |
| 258 | Core skeleton | `core/controlledWriteGuardCore.ts` | Sealed — never modify |
| 259 | Blueprint | documentation-only | Sealed |
| 260 | Core skeleton | `core/realWriteEnablementGateCore.ts` | Sealed — never modify |
| 261 | Blueprint | documentation-only | Sealed |
| 262 | Core skeleton | `core/sandboxWritePlanCore.ts` | Sealed — never modify |

#### Execution-Path Layer Stack (after Phase 263)

| Layer | Core file | State literal | Sealed phase |
|---|---|---|---|
| 1 — Controlled Execution | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 — Sandbox Filesystem | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 — Write Guard | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 — Write Enablement Gate | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 — Sandbox Write Plan | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |

#### Invariants

- All 4 sealed source files permanently sealed — no modification permitted
- `realWritesEnabled=false` compile-time literal at layers 3, 4, and 5 — a new activation layer must be added to enable real writes, not a modification of sealed files
- `VirtualWorkspaceRecord.workspaceId` is the correct ID field (not `virtualWorkspaceId`)
- Rollback readiness combined across all 3 upstream records in `sandboxWritePlanCore.ts`
- No observe API added in Phases 255–262 — all write-path cores are internal-only at this seal
- Future activation phases add new files only
- Next: Write-preparation execution stack (Phases 264–271) + Write Path Compression Seal (Phase 272)

---

### Phase 264 — First Real Sandbox Write Guarded Blueprint

**Documentation-only phase.** Defines the first guarded real-write operation model. All write operations remain disabled. 0 runtime source files changed.

**Purpose:** define first future real-write operation model · require write plan readiness · require write gate approval · require rollback readiness · restrict writes to approved sandbox zones · keep actual writes disabled

**Inputs (3):** `SandboxWritePlanRecord` · `WriteGateRecord` · `ControlledExecutionRecord`

**Outputs (6):** `guardedWriteId` · `writeOperations[]` · `blockedOperations[]` · `writeSafetyChecks[]` · `rollbackWriteReport` · `approvalRequired=true`

**Allowed future targets (3):** `/sandbox/workspace` · `/sandbox/tmp` · `/sandbox/build-cache`

**Blocked targets (5 — always):** `/mother-core` · `/vault` · `/runtime-config` · `/system` · `/network-secrets`

**Compile-time literals:** `approvalRequired=true` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `motherCoreWritesBlocked=true` · `protectedZoneWritesBlocked=true` · `vaultAccessBlocked=true` · `shellAccessBlocked=true` · `networkAccessBlocked=true` · `deploymentWritesBlocked=true` · `rollbackRequired=true` · `writeState="guarded_descriptor_ready"`

**Validation rules (9):** `write_plan_exists` · `write_gate_exists` · `execution_record_exists` · `write_gate_clear` · `rollback_ready` · `targets_limited_to_sandbox` · `protected_targets_blocked` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 265 — First Real Sandbox Write Guarded Core Skeleton

**Runtime phase.** Created `core/guardedSandboxWriteCore.ts` — in-memory guarded sandbox write descriptor engine.

**Import note:** `SandboxWritablePath` and `SandboxProtectedPath` are not re-exported by `sandboxWritePlanCore.ts` — both must be imported directly from `sandboxFilesystemCore.js`.

**Compile-time literals:** `writeState="guarded_descriptor_ready"` · `approvalRequired=true` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `motherCoreWritesBlocked=true` · `protectedZoneWritesBlocked=true` · `vaultAccessBlocked=true` · `shellAccessBlocked=true` · `networkAccessBlocked=true` · `deploymentWritesBlocked=true` · `rollbackRequired=true` · `implementationPhase="descriptor_only"`

**Write operations (3):** derived from `writePlanRecord.plannedWrites` — all `actualWritesEnabled:false`, `realWritesEnabled:false`, `writeBlocked:true`

**Blocked operations (5):** derived from `writePlanRecord.blockedWrites` — all `writeBlocked:true`

**Safety checks (9):** `write_plan_exists` · `write_gate_exists` · `execution_record_exists` · `write_gate_clear` (reads `writeGateRecord.writeReadinessReport.allChecksPass`) · `rollback_ready` (combined: `writePlanRecord.rollbackWritePlan.rollbackSequenceReady` AND `writeGateRecord.writeReadinessReport.rollbackReady`) · `targets_limited_to_sandbox` · `protected_targets_blocked` · `actual_writes_still_disabled` (always true) · `output_remains_descriptor_only` (always true)

**Exports:** `createGuardedSandboxWriteRecord` · `listGuardedSandboxWriteRecords` · `getGuardedSandboxWriteSummary`

---

### Phase 266 — Sandbox Write Audit Trail Blueprint

**Documentation-only phase.** Defines the write audit trail descriptor layer before any actual sandbox write is enabled. 0 runtime source files changed.

**Purpose:** define audit trail records for future sandbox write attempts · bind write attempt descriptors to rollback readiness · preserve traceability before enabling real writes

**Inputs (4):** `GuardedSandboxWriteRecord` · `SandboxWritePlanRecord` · `WriteGateRecord` · `ControlledExecutionRecord`

**Outputs (6):** `writeAuditId` · `attemptedOperations[]` · `blockedOperations[]` · `auditChecks[]` · `traceabilityReport` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `actualWritesEnabled=false` · `auditState="descriptor_audit_ready"` · `mutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `networkBlocked=true` · `shellBlocked=true` · `rollbackRequired=true`

**Validation rules (9):** `guarded_write_exists` · `write_plan_exists` · `write_gate_exists` · `execution_record_exists` · `attempted_operations_traced` · `blocked_operations_recorded` · `rollback_reference_present` · `mutation_still_blocked` · `output_remains_descriptor_only`

---

### Phase 267 — Sandbox Write Audit Trail Core Skeleton

**Runtime phase.** Created `core/sandboxWriteAuditCore.ts` — in-memory write audit trail descriptor engine.

**Compile-time literals:** `auditState="descriptor_audit_ready"` · `approvalRequired=true` · `actualWritesEnabled=false` · `mutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `networkBlocked=true` · `shellBlocked=true` · `rollbackRequired=true` · `implementationPhase="descriptor_only"`

**Attempted operations (3):** derived from `guardedWriteRecord.writeOperations` — all `actualWritesEnabled:false`, `mutationBlocked:true`

**Blocked operations (5):** derived from `guardedWriteRecord.blockedOperations` — all `mutationBlocked:true`

**Audit checks (9):** `guarded_write_exists` · `write_plan_exists` · `write_gate_exists` · `execution_record_exists` · `attempted_operations_traced` · `blocked_operations_recorded` · `rollback_reference_present` (combined: `guardedWriteRecord.rollbackWriteReport.rollbackReady` AND `writeGateRecord.writeReadinessReport.rollbackReady`) · `mutation_still_blocked` (always true) · `output_remains_descriptor_only` (always true)

**`TraceabilityReport`:** `rollbackRequired=true` · `rollbackDescriptorOnly=true` · `rollbackReferencePresent` · `rollbackReady` · `attemptedOperationCount` · `blockedOperationCount` · `allChecksPass` · `summary`

**Exports:** `createSandboxWriteAuditRecord` · `listSandboxWriteAuditRecords` · `getSandboxWriteAuditSummary`

---

### Phase 268 — Sandbox Write Rollback Snapshot Blueprint

**Documentation-only phase.** Defines the rollback snapshot descriptor layer before any actual sandbox write is enabled. 0 runtime source files changed.

**Purpose:** define rollback snapshot descriptors before future write attempts · bind snapshots to audited write operations · preserve pre-write recovery state

**Inputs (4):** `SandboxWriteAuditRecord` · `GuardedSandboxWriteRecord` · `SandboxFilesystemRecord` · `ControlledExecutionRecord`

**Outputs (6):** `rollbackSnapshotId` · `snapshotTargets[]` · `snapshotValidationChecks[]` · `recoveryPlan[]` · `snapshotReadinessReport` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `actualWritesEnabled=false` · `snapshotState="descriptor_snapshot_ready"` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `rollbackRequired=true`

**Validation rules (10):** `write_audit_exists` · `guarded_write_exists` · `filesystem_record_exists` · `execution_record_exists` · `audited_operations_traceable` · `snapshot_targets_within_writable_zones` · `protected_zones_excluded` · `recovery_plan_descriptor_only` · `mutation_still_blocked` · `output_remains_descriptor_only`

---

### Phase 269 — Sandbox Write Rollback Snapshot Core Skeleton

**Runtime phase.** Created `core/sandboxWriteRollbackSnapshotCore.ts` — in-memory rollback snapshot descriptor engine.

**Key import note:** `SandboxWritableZone.path` is the zone path field (not `zonePath`) — confirmed by grepping `sandboxFilesystemCore.ts` during this phase.

**Compile-time literals:** `snapshotState="descriptor_snapshot_ready"` · `approvalRequired=true` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `rollbackRequired=true` · `implementationPhase="descriptor_only"` · `snapshotDescriptorOnly=true` · `descriptorOnly=true`

**Snapshot targets (3):** derived from `auditRecord.attemptedOperations` — all `filesystemMutationBlocked:true`, `snapshotDescriptorOnly:true`

**Recovery plan (3 steps):** `recoveryAction:"restore_pre_write_state"` · `descriptorOnly:true` · `mutationBlocked:true`

**Validation checks (10):** includes `snapshot_targets_within_writable_zones` (cross-validates against `filesystemRecord.writableZones[].path`) · `protected_zones_excluded` (cross-validates against `filesystemRecord.protectedZones[].path`) · `output_remains_descriptor_only` (combined: `auditRecord` + `guardedWriteRecord` + `filesystemRecord` rollbackReady)

**Exports:** `createRollbackSnapshotRecord` · `listRollbackSnapshotRecords` · `getRollbackSnapshotSummary`

---

### Phase 270 — Sandbox Write Commit Gate Blueprint

**Documentation-only phase.** Defines the final write commit gate descriptor layer: decides whether a future write commit would be eligible. Commit remains disabled. 0 runtime source files changed.

**Purpose:** decide whether future write commit would be eligible · require rollback snapshot readiness · require audit traceability · require write gate readiness · require guarded write safety · keep actual commit disabled

**Inputs (5):** `SandboxWriteRollbackSnapshotRecord` · `SandboxWriteAuditRecord` · `GuardedSandboxWriteRecord` · `WriteGateRecord` · `ControlledExecutionRecord`

**Outputs (6):** `commitGateId` · `commitEligibilityChecks[]` · `commitBlockedReasons[]` · `commitReadinessReport` · `rollbackCommitPlan` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `actualWritesEnabled=false` · `commitEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `rollbackRequired=true` · `commitState="descriptor_commit_gate_ready"`

**Validation rules (11):** `rollback_snapshot_exists` · `write_audit_exists` · `guarded_write_exists` · `write_gate_exists` · `execution_record_exists` · `snapshot_ready` · `audit_traceable` · `write_gate_ready` · `guarded_write_safe` · `actual_commit_still_disabled` · `output_remains_descriptor_only`

---

### Phase 271 — Sandbox Write Commit Gate Core Skeleton

**Runtime phase.** Created `core/sandboxWriteCommitGateCore.ts` — in-memory commit gate descriptor engine. Final layer in the write-preparation stack: reads readiness across all four upstream write layers and produces a commit eligibility decision.

**Compile-time literals:** `commitState="descriptor_commit_gate_ready"` · `approvalRequired=true` · `actualWritesEnabled=false` · `commitEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `rollbackRequired=true` · `implementationPhase="descriptor_only"`

**Eligibility checks (11):** `rollback_snapshot_exists` · `write_audit_exists` · `guarded_write_exists` · `write_gate_exists` · `execution_record_exists` · `snapshot_ready` (reads `snapshotRecord.snapshotReadinessReport.allChecksPass`) · `audit_traceable` (reads `auditRecord.traceabilityReport.allChecksPass`) · `write_gate_ready` (reads `writeGateRecord.writeReadinessReport.allChecksPass`) · `guarded_write_safe` (reads `guardedWriteRecord.writeSafetyChecks.every(c => c.passed)`) · `actual_commit_still_disabled` (always true) · `output_remains_descriptor_only` (combined rollbackReady × 4 upstream records)

**Rollback readiness (combined across 4 upstream records):** `snapshotRecord.snapshotReadinessReport.rollbackReady` AND `auditRecord.traceabilityReport.rollbackReady` AND `guardedWriteRecord.rollbackWriteReport.rollbackReady` AND `writeGateRecord.writeReadinessReport.rollbackReady`

**`CommitBlockedReasons[]`:** 3 static entries always present (commitEnabled=false · approvalRequired · filesystemMutationBlocked) + dynamic entries per failed eligibility check

**`RollbackCommitPlan`:** bound to `snapshotRecord.rollbackSnapshotId` · `rollbackRequired=true` · `rollbackDescriptorOnly=true`

**Exports:** `createCommitGateRecord` · `listCommitGateRecords` · `getCommitGateSummary`

---

### Phase 272 — Write Path Compression Seal

**Documentation-only phase.** Seals the write-preparation execution stack (Phases 264–271). 0 runtime source files changed. All counters unchanged.

#### Sealed Stack: Write-Preparation Execution Path

| Phase | Type | File | Status |
|---|---|---|---|
| 264 | Blueprint | documentation-only | Sealed |
| 265 | Core skeleton | `core/guardedSandboxWriteCore.ts` | Sealed — never modify |
| 266 | Blueprint | documentation-only | Sealed |
| 267 | Core skeleton | `core/sandboxWriteAuditCore.ts` | Sealed — never modify |
| 268 | Blueprint | documentation-only | Sealed |
| 269 | Core skeleton | `core/sandboxWriteRollbackSnapshotCore.ts` | Sealed — never modify |
| 270 | Blueprint | documentation-only | Sealed |
| 271 | Core skeleton | `core/sandboxWriteCommitGateCore.ts` | Sealed — never modify |

#### Full Write-Preparation Layer Stack (after Phase 272)

| Layer | Core file | State literal | Sealed phase |
|---|---|---|---|
| 1 — Controlled Execution | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 — Sandbox Filesystem | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 — Write Guard | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 — Write Enablement Gate | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 — Sandbox Write Plan | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 — Guarded Write | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 — Write Audit Trail | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 — Rollback Snapshot | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 — Commit Gate | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |

#### Invariants

- All 4 sealed source files (Phases 265, 267, 269, 271) permanently sealed — no modification permitted
- `actualWritesEnabled=false` and `commitEnabled=false` compile-time literals at every write layer — new activation layers must be added, not modifications of sealed files
- `filesystemMutationBlocked=true` permanent compile-time literal in all write-path cores (265–271) — future real-write enablement requires a new file with explicit activation contract
- `SandboxWritablePath` and `SandboxProtectedPath` must always be imported from `sandboxFilesystemCore.js` — not re-exported by intermediate layers
- `SandboxWritableZone.path` is the zone field (not `zonePath`)
- `commitBlockedReasons[]` always has 3 static entries regardless of eligibility check results
- Rollback readiness combined across 4 upstream records in `sandboxWriteCommitGateCore.ts`
- No observe API added in Phases 264–271 — all 4 write-path cores are internal-only at this seal
- Next: First controlled actual sandbox write enablement blueprint

---

### Phase 231 — Sandbox Build Blueprint

**Documentation-only phase.** Defines the future sandbox build layer before any real filesystem writes, package installation, or execution. 0 runtime source files changed. All counters unchanged.

#### 1. Sandbox Build Purpose

| Purpose | Description |
|---|---|
| Virtual artifact preparation | Prepare virtual artifacts for future build simulation |
| Unified build plan | Connect artifact/package/resolution outputs into one controlled build plan |
| Isolation from Mother Core | Keep all build activity isolated from Mother Core runtime subsystems |
| Previewable outputs | Prepare future previewable application outputs |

#### 2. Build Inputs

| Input | Source |
|---|---|
| Virtual artifact record | `TemplateArtifactRecord` from `core/templateArtifactCore.ts` |
| Virtual package record | `VirtualPackageRecord` from `core/virtualPackageCore.ts` |
| Dependency resolution record | `DependencyResolutionRecord` from `core/dependencyResolutionCore.ts` |
| Sandbox run record | `SandboxRunRecord` from `core/sandboxCore.ts` |
| Operator approval reference | Approval actor ID + timestamp |

#### 3. Build Plan Outputs (9 fields)

| Field | Type | Notes |
|---|---|---|
| `buildPlanId` | string | Server-generated 16-byte hex |
| `artifactId` | string | Parent artifact record ID |
| `packageId` | string | Parent package record ID |
| `resolutionId` | string | Parent resolution record ID |
| `sandboxRunId` | string | Parent sandbox run record ID |
| `buildSteps[]` | descriptor array | 7 descriptor-only build steps |
| `expectedOutputs[]` | descriptor array | Text descriptors only — no real files |
| `validationChecks[]` | check array | 7 required validation checks |
| `approvalRequired` | `true` | Compile-time literal — never `false` |

#### 4. Build Steps (7 — descriptor-only, no executable bodies)

| Step | Descriptor name |
|---|---|
| 1 | `prepare_workspace` |
| 2 | `map_virtual_files` |
| 3 | `validate_package_manifest` |
| 4 | `apply_resolution_order` |
| 5 | `simulate_typecheck` |
| 6 | `simulate_bundle` |
| 7 | `produce_build_report` |

Adding an 8th step requires a new blueprint phase.

#### 5. Hard Boundaries (9 — all absolute)

No real filesystem writes · no npm/yarn/pnpm install · no shell execution · no runtime execution · no network access · no vault access · no Docker build · no deployment package · no generated app launch.

#### 6. Validation Rules (7 — all required)

| Rule | Description |
|---|---|
| Artifact structure exists | Virtual artifact record must be present |
| Package descriptor exists | Virtual package record must be present |
| Resolution graph exists | Dependency resolution record must be present |
| No blocked conflicts | Resolution record must have no blocking conflicts |
| Sandbox approval present | Operator approval reference must be present |
| Build steps descriptor-only | No step may carry executable content |
| Output remains virtual | No real file, bundle, or deployment package may be produced |

#### 7. Future Compatibility Targets

Install simulation · real sandbox filesystem · build executor · artifact preview · deployment candidate pipeline · rollback comparison

#### Invariants

- Sandbox build is isolated from Mother Core — no coupling to runtime subsystems
- Build steps are text descriptors only — 7 fixed, no additions without a new blueprint phase
- `approvalRequired=true` is a compile-time literal — never `false`
- All 9 hard boundaries are absolute — no bypass in any future phase
- All 7 validation rules are required — a plan that bypasses any is non-compliant

---

### Phase 273 — Controlled Actual Sandbox Write Enablement Blueprint

**Documentation-only phase.** Defines the first controlled actual write enablement layer: determines whether actual sandbox writes are eligible after all 9 sealed write-preparation layers pass. Actual writes remain disabled. 0 runtime source files changed.

**Purpose:** determine whether actual sandbox writes are eligible · require commit gate readiness · require rollback snapshot readiness · require audit traceability · require guarded write safety · restrict future writes to sandbox writable zones only · keep real writes disabled in this phase

**Inputs (7):** `SandboxWriteCommitGateRecord` · `SandboxWriteRollbackSnapshotRecord` · `SandboxWriteAuditRecord` · `GuardedSandboxWriteRecord` · `SandboxWritePlanRecord` · `WriteGateRecord` · `ControlledExecutionRecord`

**Outputs (7):** `actualWriteEnablementId` · `eligibilityChecks[]` · `eligibleOperations[]` · `blockedOperations[]` · `enablementReadinessReport` · `rollbackReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `commitRequired=true` · `rollbackRequired=true` · `motherCoreWritesBlocked=true` · `protectedZoneWritesBlocked=true` · `vaultAccessBlocked=true` · `shellAccessBlocked=true` · `networkAccessBlocked=true` · `deploymentWritesBlocked=true` · `enablementState="actual_write_pre_enablement_ready"` · `implementationPhase="descriptor_only"`

**Validation rules (15):** `commit_gate_exists` · `rollback_snapshot_exists` · `write_audit_exists` · `guarded_write_exists` · `write_plan_exists` · `write_gate_exists` · `execution_record_exists` · `commit_gate_ready` · `rollback_snapshot_ready` · `audit_traceable` · `guarded_write_safe` · `targets_limited_to_sandbox` · `protected_targets_blocked` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 274 — Controlled Actual Sandbox Write Enablement Core Skeleton

**Runtime phase.** Created `core/actualSandboxWriteEnablementCore.ts` — in-memory actual write enablement descriptor engine. First controlled actual write enablement layer: reads readiness across all 7 upstream records spanning the full 9-layer sealed write-preparation stack.

**Key design points:**

- `eligibleOperations[]` derives from `guardedWriteRecord.writeOperations` — consistent operation source across layers 6→10
- `rollbackReference` binds both `rollbackSnapshotId` and `commitGateId` into one reference object, making the rollback chain fully addressable by a single record
- Rollback readiness combined across **5 upstream records**: commit gate + snapshot + audit + guarded write + write gate

**Compile-time literals:** `enablementState="actual_write_pre_enablement_ready"` · `approvalRequired=true` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `commitRequired=true` · `rollbackRequired=true` · `motherCoreWritesBlocked=true` · `protectedZoneWritesBlocked=true` · `vaultAccessBlocked=true` · `shellAccessBlocked=true` · `networkAccessBlocked=true` · `deploymentWritesBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createActualWriteEnablementRecord` · `listActualWriteEnablementRecords` · `getActualWriteEnablementSummary`

---

### Phase 275 — Actual Sandbox Write Dry-Run Blueprint

**Documentation-only phase.** Defines the actual sandbox write dry-run layer: simulates exact future write execution path without writing files. 0 runtime source files changed.

**Purpose:** simulate the exact future write execution path · verify eligible operations ordering · verify rollback binding before any real write · keep mutation disabled in this phase

**Inputs (6):** `ActualSandboxWriteEnablementRecord` · `SandboxWriteCommitGateRecord` · `SandboxWriteRollbackSnapshotRecord` · `SandboxWriteAuditRecord` · `GuardedSandboxWriteRecord` · `ControlledExecutionRecord`

**Outputs (6):** `dryRunId` · `dryRunOperations[]` · `dryRunValidationChecks[]` · `dryRunReadinessReport` · `rollbackBindingReport` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `actualWritesEnabled=false` · `dryRunOnly=true` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `dryRunState="descriptor_dry_run_ready"`

**Validation rules (11):** `actual_enablement_exists` · `commit_gate_exists` · `rollback_snapshot_exists` · `write_audit_exists` · `guarded_write_exists` · `execution_record_exists` · `eligible_operations_present` · `operation_order_deterministic` · `rollback_binding_valid` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 276 — Actual Sandbox Write Dry-Run Core Skeleton

**Runtime phase.** Created `core/actualSandboxWriteDryRunCore.ts` — in-memory dry-run descriptor engine. Derives deterministically-ordered dry-run operations from the enablement layer; verifies rollback binding across 5 upstream records.

**Key design points:**

- `dryRunOperations[]` derives from `enablementRecord.eligibleOperations` sorted ascending by `operationIndex` — first layer to enforce deterministic execution order as a named check (`operation_order_deterministic`: `stepIndex === idx` for every op)
- `rollbackBindingReport` independently verifies both rollback anchors (`rollbackSnapshotId` + `commitGateId`) are non-empty before confirming binding — separating binding check from readiness check
- `simulatedOutcome: "would_write_if_enabled"` is a compile-time literal on every dry-run operation

**Compile-time literals:** `dryRunState="descriptor_dry_run_ready"` · `approvalRequired=true` · `actualWritesEnabled=false` · `dryRunOnly=true` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"` · `simulatedOutcome="would_write_if_enabled"`

**Exports:** `createActualSandboxWriteDryRunRecord` · `listActualSandboxWriteDryRunRecords` · `getActualSandboxWriteDryRunSummary`

---

### Phase 277 — Actual Sandbox Write Approval Token Blueprint

**Documentation-only phase.** Defines the approval token descriptor layer: represents explicit operator approval readiness for future actual writes; binds approval to a specific dry-run result, rollback reference, and commit gate. 0 runtime source files changed.

**Purpose:** represent explicit operator approval readiness for future actual writes · bind approval to a specific dry-run result · bind approval to rollback and commit gate references · keep approval descriptor-only in this phase

**Inputs (4):** `ActualSandboxWriteDryRunRecord` · `ActualSandboxWriteEnablementRecord` · `SandboxWriteCommitGateRecord` · `ControlledExecutionRecord`

**Outputs (6):** `approvalTokenId` · `approvalScope[]` · `approvalValidationChecks[]` · `approvalReadinessReport` · `linkedRollbackReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `approvalGranted=false` · `actualWritesEnabled=false` · `approvalState="descriptor_approval_pending"` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true`

**Validation rules (10):** `dry_run_exists` · `enablement_record_exists` · `commit_gate_exists` · `execution_record_exists` · `dry_run_ready` · `rollback_reference_bound` · `commit_gate_bound` · `approval_not_granted_yet` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 278 — Actual Sandbox Write Approval Token Core Skeleton

**Runtime phase.** Created `core/actualSandboxWriteApprovalTokenCore.ts` — in-memory approval token descriptor engine. Binds approval scope to a specific dry-run result, rollback reference, and commit gate. Approval remains un-granted.

**Key design points:**

- `approvalScope[]` derives from `dryRunRecord.dryRunOperations` sorted by `stepIndex` — preserves the deterministic order established in Phase 276
- `commit_gate_bound` cross-validates `dryRunRecord.rollbackBindingReport.commitGateId === commitGateRecord.commitGateId` — first cross-validation in the stack confirming commit gate ID propagated correctly through the dry-run layer
- `linkedRollbackReference` sources `rollbackSnapshotId` from `dryRunRecord.rollbackBindingReport` — anchored to dry-run's verified binding, not re-derived
- `approvalGranted=false` and `approvalRequired=true` appear on every `ApprovalScopeEntry` — un-granted state explicit at operation granularity

**Compile-time literals:** `approvalState="descriptor_approval_pending"` · `approvalGranted=false` · `approvalRequired=true` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createApprovalTokenRecord` · `listApprovalTokenRecords` · `getApprovalTokenSummary`

---

### Phase 279 — Actual Sandbox Write Final Preflight Blueprint

**Documentation-only phase.** Defines the final preflight descriptor layer before any actual sandbox write can be enabled. Requires approval token binding, dry-run readiness, enablement readiness, and commit gate readiness. 0 runtime source files changed.

**Purpose:** perform final preflight validation before future actual sandbox writes · require approval token binding · require dry-run readiness · require enablement readiness · require commit gate readiness · keep actual writes disabled in this phase

**Inputs (5):** `ActualSandboxWriteApprovalTokenRecord` · `ActualSandboxWriteDryRunRecord` · `ActualSandboxWriteEnablementRecord` · `SandboxWriteCommitGateRecord` · `ControlledExecutionRecord`

**Outputs (6):** `preflightId` · `preflightChecks[]` · `preflightBlockedReasons[]` · `preflightReadinessReport` · `linkedApprovalReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `preflightPassed=false` · `actualWritesEnabled=false` · `finalWriteAllowed=false` · `preflightState="descriptor_preflight_ready"` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true`

**Validation rules (12):** `approval_token_exists` · `dry_run_exists` · `enablement_record_exists` · `commit_gate_exists` · `execution_record_exists` · `approval_token_bound` · `dry_run_ready` · `enablement_ready` · `commit_gate_ready` · `approval_not_granted_yet` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 280 — Actual Sandbox Write Final Preflight Core Skeleton

**Runtime phase.** Created `core/actualSandboxWritePreflightCore.ts` — in-memory final preflight descriptor engine. Performs final preflight validation across 5 upstream layers.

**Key design points:**

- `approval_token_bound` strictly cross-validates `approvalTokenRecord.dryRunId === dryRunRecord.dryRunId` — an approval token constructed against a different dry-run than the one presented at preflight time fails this check
- `preflightBlockedReasons[]` always carries **3 static entries** (`preflightPassed=false` · `approvalRequired=true` · `actualWritesEnabled=false`) plus dynamic entries per failed check — same pattern as `commitBlockedReasons[]` in Phase 271, extended with `finalWriteAllowed=false` as third static reason
- `linkedApprovalReference` sources `rollbackSnapshotId` from `approvalTokenRecord.linkedRollbackReference` — preserving chain of custody through the approval layer
- `finalWriteAllowed=false` is a new compile-time literal first appearing in this layer — explicitly distinguishing the last gate before any future activation phase

**Compile-time literals:** `preflightState="descriptor_preflight_ready"` · `approvalRequired=true` · `preflightPassed=false` · `actualWritesEnabled=false` · `finalWriteAllowed=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createPreflightRecord` · `listPreflightRecords` · `getPreflightSummary`

---

### Phase 281 — Actual Sandbox Write Preflight Compression Seal

**Documentation-only phase.** Seals the actual sandbox write preflight stack (Phases 273–280). 0 runtime source files changed. All counters unchanged.

#### Sealed Stack: Actual Sandbox Write Preflight Stack (Phases 273–280)

| Phase | Type | File | Status |
|---|---|---|---|
| 273 | Blueprint | documentation-only | Sealed |
| 274 | Core skeleton | `core/actualSandboxWriteEnablementCore.ts` | Sealed — never modify |
| 275 | Blueprint | documentation-only | Sealed |
| 276 | Core skeleton | `core/actualSandboxWriteDryRunCore.ts` | Sealed — never modify |
| 277 | Blueprint | documentation-only | Sealed |
| 278 | Core skeleton | `core/actualSandboxWriteApprovalTokenCore.ts` | Sealed — never modify |
| 279 | Blueprint | documentation-only | Sealed |
| 280 | Core skeleton | `core/actualSandboxWritePreflightCore.ts` | Sealed — never modify |

#### Full Write-Preparation + Preflight Layer Stack (after Phase 281)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |

#### Invariants

- All 4 sealed source files (Phases 274, 276, 278, 280) permanently sealed — no modification permitted
- `actualWritesEnabled=false`, `finalWriteAllowed=false`, `preflightPassed=false`, `approvalGranted=false` compile-time literals across all preflight layers — new activation layers must be added, not modifications of sealed files
- `dryRunOperations[]` ordering is contract-enforced — sorted ascending by `operationIndex`; `operation_order_deterministic` validates `stepIndex === idx` for every operation
- `commit_gate_bound` cross-validates `approvalTokenRecord.dryRunId === dryRunRecord.dryRunId` at preflight time — a token constructed against a different dry-run will fail
- `preflightBlockedReasons[]` always has 3 static entries regardless of dynamic check results
- `linkedApprovalReference` sources `rollbackSnapshotId` from `approvalTokenRecord.linkedRollbackReference` — not from the snapshot record directly; chain of custody must be preserved
- Rollback readiness combined across 4–5 upstream records depending on layer — do not reduce without a dedicated seal phase
- No observe API added in Phases 273–280 — all 4 sealed cores are internal-only
- Next: First real sandbox write activation blueprint
- Output remains virtual — real file production requires a separately named execution phase

---

### Phase 282 — Execution Control Room UI Blueprint

**Documentation-only phase.** Defines the execution control room UI section for the `/ui/observation` page. 0 runtime source files changed.

**Purpose:** surface sealed write-preparation + preflight stack visually · show why writing is still blocked · show 8 display flags · list 14 stack layers (0–13) · provide operator next-action guidance · no new endpoints, no new policies, no new subsystems

**Output surface:** `/ui/observation` page — 4 new sections injected after existing panels section

**Sections (4):** Execution control room flags · Write-preparation + preflight layer stack · Why writing is still blocked · Next safe action

**Display flags (8):** `actualWritesEnabled=false` · `finalWriteAllowed=false` · `approvalGranted=false` · `preflightPassed=false` · `filesystemMutationBlocked=true` · `graphCycles=0` · `executionBlocked=true` · `readOnly=true`

---

### Phase 283 — Execution Control Room UI Core

**Runtime phase.** Created `core/executionControlRoomCore.ts` — pure HTML section builder. Injected into `/ui/observation` page via conditional in `buildDashboardPageHtml("observation")`.

**Key design points:**

- `WRITE_STACK` is a `readonly` array of 14 `StackLayer` entries (layers 0–13) — all compile-time constants; no reads from any runtime subsystem
- `FLAGS` object holds 8 compile-time booleans/numbers that mirror the sealed cores exactly
- `BLOCKED_REASONS` is a `readonly string[]` of 7 entries documenting exactly why writing is blocked at this stage
- `buildExecutionControlRoomSection(accent: string): string` is the single export — takes the page accent color from the parent builder for visual consistency
- Four HTML sections generated: flag cards grid · 14-layer stack table · blocked reasons table · next safe action guidance panel
- Injection is conditional: `pageId === "observation"` in `buildDashboardPageHtml` — zero impact on other pages

**Files changed:** `core/executionControlRoomCore.ts` (created) · `core/uiDashboardPages.ts` (import + conditional injection)

**Exports:** `buildExecutionControlRoomSection(accent: string): string`

#### Invariants

- `executionControlRoomCore.ts` is a pure HTML section builder — no init, no subsystem registration, no health checks, no event emission, no persistence, no real writes, no filesystem mutation, no client-side JS
- `WRITE_STACK` entries are compile-time only — never derived from runtime subsystem state; any update to sealed core file names must be a new phase
- Section injection is observation-page-only — do not add to other pages without a dedicated phase
- Accent color must always be passed from the parent builder — never hardcoded inside the section builder

---

### Phase 284 — First Real Sandbox Write Activation Blueprint

**Documentation-only phase.** Defines layer 14 of the write-preparation + preflight stack: the first real-write activation descriptor. 0 runtime source files changed.

**Purpose:** define the first real-write activation descriptor · bind activation to final preflight · bind activation to approval token · bind activation to dry-run ordering · bind activation to commit gate and rollback references · keep mutation disabled in this phase

**Inputs (6):** `ActualSandboxWritePreflightRecord` · `ActualSandboxWriteApprovalTokenRecord` · `ActualSandboxWriteDryRunRecord` · `ActualSandboxWriteEnablementRecord` · `SandboxWriteCommitGateRecord` · `ControlledExecutionRecord`

**Outputs (7):** `activationId` · `activationChecks[]` · `activationScope[]` · `activationBlockedReasons[]` · `rollbackActivationReference` · `activationReadinessReport` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `activationPrepared=true` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `finalWriteAllowed=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `activationState="descriptor_activation_ready"`

**Validation rules (13):** `preflight_exists` · `approval_token_exists` · `dry_run_exists` · `enablement_record_exists` · `commit_gate_exists` · `execution_record_exists` · `preflight_bound_to_approval` · `approval_bound_to_dry_run` · `dry_run_bound_to_commit_gate` · `rollback_reference_bound` · `activation_switch_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 285 — First Real Sandbox Write Activation Core Skeleton

**Runtime phase.** Created `core/firstRealSandboxWriteActivationCore.ts` — in-memory first real-write activation descriptor engine. Layer 14 of the write-preparation + preflight stack.

**Key design points:**

- `activationScope[]` derives from `approvalTokenRecord.approvalScope` — preserves the deterministic ordering chain established in Phase 276 (dry run) through Phase 278 (approval token); each entry gains `activationPrepared=true` and `activationSwitchEnabled=false` fields
- Three cross-validation checks form a full forward-binding chain: `preflight_bound_to_approval` (`preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId`) → `approval_bound_to_dry_run` (`approvalTokenRecord.dryRunId === dryRunRecord.dryRunId`) → `dry_run_bound_to_commit_gate` (`dryRunRecord.rollbackBindingReport.commitGateId === commitGateRecord.commitGateId`)
- `rollbackActivationReference` is the first binding reference in the stack to carry both `preflightId` and `approvalTokenId` as binding anchors, alongside `rollbackSnapshotId` and `commitGateId`
- `rollbackSnapshotId` sourced from `approvalTokenRecord.linkedRollbackReference.rollbackSnapshotId` — chain of custody preserved through the approval layer
- `activationBlockedReasons[]` carries 3 static entries (`activationSwitchEnabled=false` · `approvalRequired=true` · `actualWritesEnabled=false`) plus dynamic entries per failed check — consistent with sealed preflight layer pattern
- `activationSwitchEnabled=false` is a new compile-time literal first introduced in this layer — explicitly marks the gap between descriptor readiness and real execution enablement; a future activation-switch phase must flip this
- Rollback readiness combined across **4 upstream records**: preflight + approvalToken + dryRun + commitGate

**Compile-time literals:** `activationState="descriptor_activation_ready"` · `approvalRequired=true` · `activationPrepared=true` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `finalWriteAllowed=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createActivationRecord` · `listActivationRecords` · `getActivationSummary`

---

### Phase 286 — Activation Path Compression Seal

**Documentation-only phase.** Seals the control room UI + activation descriptor batch (Phases 282–285). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 282–285)

| Phase | Type | File | Status |
|---|---|---|---|
| 282 | Blueprint | documentation-only | Sealed |
| 283 | UI core + page injection | `core/executionControlRoomCore.ts` · `core/uiDashboardPages.ts` (modified) | Sealed — never modify executionControlRoomCore.ts |
| 284 | Blueprint | documentation-only | Sealed |
| 285 | Core skeleton | `core/firstRealSandboxWriteActivationCore.ts` | Sealed — never modify |

#### Full Write-Preparation + Preflight + Activation Layer Stack (after Phase 286)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |

#### Invariants

- `firstRealSandboxWriteActivationCore.ts` (Phase 285) permanently sealed — no modification permitted
- `executionControlRoomCore.ts` (Phase 283) permanently sealed — no modification permitted; visual updates require a new phase
- `activationSwitchEnabled=false` compile-time literal in layer 14 — a future activation-switch phase must introduce a new file to flip this, not modify the sealed core
- `activationScope[]` ordering chain must be preserved: dry-run (Ph 276) → approval token (Ph 278) → activation (Ph 285) → any future layer; do not re-derive from original sources
- Three-check forward-binding chain (`preflight_bound_to_approval` → `approval_bound_to_dry_run` → `dry_run_bound_to_commit_gate`) must be validated in every future layer that consumes these records
- `rollbackActivationReference` carries `preflightId` + `approvalTokenId` + `rollbackSnapshotId` + `commitGateId` — future layers sourcing rollback references must source from `rollbackActivationReference`, not from upstream sources directly
- `activationBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- `WRITE_STACK` in `executionControlRoomCore.ts` is compile-time only — layer 14 (`firstRealSandboxWriteActivationCore.ts`) is already reflected; any new layer must update this constant in a new phase
- No observe API added in Phases 282–285 — all new source files are internal-only
- Next: First activation-switch blueprint

---

### Phase 287 — First Activation Switch Blueprint

**Documentation-only phase.** Defines layer 15 of the write-preparation + preflight + activation stack: the first activation-switch descriptor. 0 runtime source files changed.

**Purpose:** define the first activation-switch descriptor · bind activation readiness to preflight validation · bind activation readiness to approval state · bind activation readiness to rollback chain · explicitly separate "prepared" from "enabled" · keep real writes disabled in this phase

**Inputs (6):** `FirstRealSandboxWriteActivationRecord` · `ActualSandboxWritePreflightRecord` · `ActualSandboxWriteApprovalTokenRecord` · `ActualSandboxWriteDryRunRecord` · `SandboxWriteCommitGateRecord` · `ControlledExecutionRecord`

**Outputs (6):** `activationSwitchId` · `switchChecks[]` · `switchBlockedReasons[]` · `switchReadinessReport` · `linkedActivationReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `activationPrepared=true` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `executionTransitionPending=true` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `switchState="descriptor_switch_pending"`

**Validation rules (13):** `activation_record_exists` · `preflight_record_exists` · `approval_token_exists` · `dry_run_exists` · `commit_gate_exists` · `execution_record_exists` · `activation_bound_to_preflight` · `preflight_bound_to_approval` · `approval_bound_to_dry_run` · `rollback_chain_valid` · `activation_switch_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 288 — First Activation Switch Core Skeleton

**Runtime phase.** Created `core/firstActivationSwitchCore.ts` — in-memory first activation-switch descriptor engine. Layer 15 of the write-preparation + preflight + activation stack.

**Key design points:**

- 3-check forward-binding chain: `activation_bound_to_preflight` (`activationRecord.preflightId === preflightRecord.preflightId`) → `preflight_bound_to_approval` (`preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId`) → `approval_bound_to_dry_run` (`approvalTokenRecord.dryRunId === dryRunRecord.dryRunId`) — extends the chain from Phase 285 by adding the new `activation_bound_to_preflight` head check; chain now spans 3 cross-validations and traverses all 4 binding layers at once
- `rollbackChainValid` combined across **5 upstream records**: activation + preflight + approvalToken + dryRun + commitGate — first layer to include `activationRecord.activationReadinessReport.rollbackReady` in the combined check
- `linkedActivationReference` carries **5 anchors**: `activationId` + `preflightId` + `approvalTokenId` + `rollbackSnapshotId` (from `activationRecord.rollbackActivationReference.rollbackSnapshotId`) + `commitGateId` — first reference object in the stack to carry all 5 binding anchors; future layers source from this, not from upstream records directly
- `executionTransitionPending=true` is a new compile-time literal first introduced in this layer — marks that the system is descriptor-ready for a future execution-transition phase without enabling any write or execution; distinct from `activationPrepared=true` (layer 14)
- `realWritesEnabled=false` is a new compile-time literal alongside `actualWritesEnabled=false` — explicitly distinguishes the real-write gate from the actual-write gate at the switch layer; two separate flags, both false, both compile-time
- `switchBlockedReasons[]` carries 3 static entries (`activationSwitchEnabled=false` · `approvalRequired=true` · `actualWritesEnabled=false`) + dynamic per failed check — consistent with layers 13–14 pattern

**Compile-time literals:** `switchState="descriptor_switch_pending"` · `approvalRequired=true` · `activationPrepared=true` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `executionTransitionPending=true` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createSwitchRecord` · `listSwitchRecords` · `getSwitchSummary`

---

### Phase 289 — Activation Switch Compression Seal

**Documentation-only phase.** Seals the activation-switch batch (Phases 287–288). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 287–288)

| Phase | Type | File | Status |
|---|---|---|---|
| 287 | Blueprint | documentation-only | Sealed |
| 288 | Core skeleton | `core/firstActivationSwitchCore.ts` | Sealed — never modify |

#### Full Write-Preparation + Preflight + Activation + Switch Layer Stack (after Phase 289)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |

#### Invariants

- `firstActivationSwitchCore.ts` (Phase 288) permanently sealed — no modification permitted
- `activationSwitchEnabled=false`, `actualWritesEnabled=false`, `realWritesEnabled=false`, `executionTransitionPending=true` compile-time literals in layer 15 — a future execution-transition phase must introduce a new file to change any of these
- `executionTransitionPending=true` is a forward signal only — it marks readiness, not permission; no real write is enabled by this flag
- `realWritesEnabled=false` and `actualWritesEnabled=false` are separate, independent flags — do not merge or alias them in any future layer
- 3-check forward-binding chain (`activation_bound_to_preflight` → `preflight_bound_to_approval` → `approval_bound_to_dry_run`) must be validated in every future layer that consumes activation + preflight + approval records; do not skip or merge
- `rollbackChainValid` across 5 upstream records is the new baseline — future layers must include at least these 5 records in the combined check
- `linkedActivationReference` with 5 anchors is the authoritative source for rollback and binding references in future layers — source from it, not from individual upstream records
- `switchBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 287–288 — `firstActivationSwitchCore.ts` is internal-only
- 16-layer stack (0–15) fully defined — new layers extend from layer 15 forward only
- Next: First execution-transition blueprint

---

### Phase 290 — First Execution Transition Blueprint

**Documentation-only phase.** Defines layer 16 of the write-preparation + preflight + activation + switch stack: the first execution-transition descriptor. 0 runtime source files changed.

**Purpose:** define the first bridge from activation readiness toward controlled execution transition · bind transition to activation switch · bind transition to activation descriptor · bind transition to preflight and approval chain · keep real writes and execution disabled in this phase

**Inputs (6):** `FirstActivationSwitchRecord` · `FirstRealSandboxWriteActivationRecord` · `ActualSandboxWritePreflightRecord` · `ActualSandboxWriteApprovalTokenRecord` · `ActualSandboxWriteDryRunRecord` · `ControlledExecutionRecord`

**Outputs (6):** `executionTransitionId` · `transitionChecks[]` · `transitionBlockedReasons[]` · `transitionReadinessReport` · `linkedTransitionReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `executionTransitionPrepared=true` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `executionEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `transitionState="descriptor_transition_pending"`

**Validation rules (13):** `activation_switch_exists` · `activation_record_exists` · `preflight_record_exists` · `approval_token_exists` · `dry_run_exists` · `execution_record_exists` · `switch_bound_to_activation` · `activation_bound_to_preflight` · `preflight_bound_to_approval` · `approval_bound_to_dry_run` · `execution_transition_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 291 — First Execution Transition Core Skeleton

**Runtime phase.** Created `core/firstExecutionTransitionCore.ts` — in-memory first execution-transition descriptor engine. Layer 16 of the write-preparation + preflight + activation + switch stack.

**Key design points:**

- 4-check forward-binding chain: `switch_bound_to_activation` (`switchRecord.activationId === activationRecord.activationId`) → `activation_bound_to_preflight` → `preflight_bound_to_approval` → `approval_bound_to_dry_run` — extends layer 15's 3-check chain by adding `switch_bound_to_activation` as new head; chain now traverses 5 binding layers end-to-end
- `rollbackChainValid` combined across `switchRecord.switchReadinessReport.rollbackChainValid` (which already covers 5 upstream layers) AND 4 individual `rollbackReady` fields (activation + preflight + approvalToken + dryRun) — most comprehensive rollback coverage in the stack
- `linkedTransitionReference` carries **5 anchors**: `activationSwitchId` (from `switchRecord.activationSwitchId`) + `activationId` + `preflightId` + `approvalTokenId` + `rollbackSnapshotId` (sourced from `switchRecord.linkedActivationReference.rollbackSnapshotId`) — rollback chain custody flows through the switch reference object, not re-derived from individual upstream records
- `executionEnabled=false` is a new compile-time literal — explicitly separates the execution gate from the transition gate; `executionTransitionEnabled=false` and `executionEnabled=false` are two independent flags
- `executionTransitionPrepared=true` is a new compile-time literal — a forward-readiness signal from layer 16 toward a future execution phase; marks readiness, not permission
- `transitionBlockedReasons[]` carries 3 static entries (`execution_transition_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–15 pattern

**Compile-time literals:** `transitionState="descriptor_transition_pending"` · `approvalRequired=true` · `executionTransitionPrepared=true` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `executionEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createTransitionRecord` · `listTransitionRecords` · `getTransitionSummary`

---

### Phase 292 — Execution Transition Compression Seal

**Documentation-only phase.** Seals the execution-transition batch (Phases 290–291). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 290–291)

| Phase | Type | File | Status |
|---|---|---|---|
| 290 | Blueprint | documentation-only | Sealed |
| 291 | Core skeleton | `core/firstExecutionTransitionCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 292)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |

#### Invariants

- `firstExecutionTransitionCore.ts` (Phase 291) permanently sealed — no modification permitted
- `executionTransitionEnabled=false`, `executionEnabled=false`, `activationSwitchEnabled=false`, `actualWritesEnabled=false`, `realWritesEnabled=false` compile-time literals in layer 16 — a future controlled-write-activation-bridge phase must introduce a new file to change any of these
- `executionEnabled=false` and `executionTransitionEnabled=false` are separate, independent flags — do not merge or alias in any future layer
- `executionTransitionPrepared=true` is a forward signal only — marks readiness, not permission; no write, execution, or filesystem mutation enabled by this flag
- 4-check forward-binding chain (`switch_bound_to_activation` → `activation_bound_to_preflight` → `preflight_bound_to_approval` → `approval_bound_to_dry_run`) must be validated in every future layer consuming switch + activation + preflight + approval records; do not skip or merge
- `rollbackChainValid` baseline now combines `switchRecord.switchReadinessReport.rollbackChainValid` + 4 individual rollbackReady fields — future layers must not reduce coverage
- `linkedTransitionReference` with 5 anchors is the authoritative source for rollback and binding references in future layers — source rollbackSnapshotId from it, not from individual upstream records
- `transitionBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 290–291 — `firstExecutionTransitionCore.ts` is internal-only
- 17-layer stack (0–16) fully defined — new layers extend from layer 16 forward only
- Next: First controlled write activation bridge

---

### Phase 293 — Controlled Write Activation Bridge Blueprint

**Documentation-only phase.** Defines layer 17 of the write-preparation + preflight + activation + switch + transition stack: the first controlled-write-activation-bridge descriptor. 0 runtime source files changed.

**Purpose:** bridge execution-transition readiness to future controlled write activation · bind bridge to transition layer · bind bridge to switch layer · bind bridge to activation/preflight/approval chain · keep mutation disabled in this phase

**Inputs (6):** `FirstExecutionTransitionRecord` · `FirstActivationSwitchRecord` · `FirstRealSandboxWriteActivationRecord` · `ActualSandboxWritePreflightRecord` · `ActualSandboxWriteApprovalTokenRecord` · `ControlledExecutionRecord`

**Outputs (6):** `writeActivationBridgeId` · `bridgeChecks[]` · `bridgeBlockedReasons[]` · `bridgeReadinessReport` · `linkedBridgeReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `bridgePrepared=true` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `bridgeState="descriptor_bridge_pending"`

**Validation rules (13):** `execution_transition_exists` · `activation_switch_exists` · `activation_record_exists` · `preflight_record_exists` · `approval_token_exists` · `execution_record_exists` · `transition_bound_to_switch` · `switch_bound_to_activation` · `activation_bound_to_preflight` · `preflight_bound_to_approval` · `bridge_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 294 — Controlled Write Activation Bridge Core Skeleton

**Runtime phase.** Created `core/controlledWriteActivationBridgeCore.ts` — in-memory first controlled-write-activation-bridge descriptor engine. Layer 17 of the write-preparation + preflight + activation + switch + transition stack.

**Key design points:**

- 4-check forward-binding chain: `transition_bound_to_switch` (`transitionRecord.activationSwitchId === switchRecord.activationSwitchId`) → `switch_bound_to_activation` → `activation_bound_to_preflight` → `preflight_bound_to_approval` — adds `transition_bound_to_switch` as new head, extending the chain from layer 16; now traverses 6 binding layers end-to-end (transition → switch → activation → preflight → approval)
- `rollbackChainValid` combined across `transitionRecord.transitionReadinessReport.rollbackChainValid` (aggregates full upstream stack) + `preflightRecord.preflightReadinessReport.rollbackReady` + `approvalTokenRecord.approvalReadinessReport.rollbackReady`
- `linkedBridgeReference` carries **5 anchors**: `executionTransitionId` (from transitionRecord) + `activationSwitchId` (from switchRecord) + `activationId` (from activationRecord) + `preflightId` (from preflightRecord) + `rollbackSnapshotId` (sourced from `transitionRecord.linkedTransitionReference.rollbackSnapshotId`) — rollback chain custody continues to flow through the transition reference
- `bridgePrepared=true` is a new compile-time literal — forward-readiness signal toward a future bridge-open phase; marks readiness, not permission
- `bridgeEnabled=false` alongside `executionTransitionEnabled=false` — two independent gate flags; bridge gate and transition gate remain separate; do not merge in future layers
- `bridgeBlockedReasons[]` carries 3 static entries (`bridge_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–16

**Compile-time literals:** `bridgeState="descriptor_bridge_pending"` · `approvalRequired=true` · `bridgePrepared=true` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createBridgeRecord` · `listBridgeRecords` · `getBridgeSummary`

---

### Phase 295 — Controlled Write Activation Bridge Compression Seal

**Documentation-only phase.** Seals the controlled-write-activation-bridge batch (Phases 293–294). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 293–294)

| Phase | Type | File | Status |
|---|---|---|---|
| 293 | Blueprint | documentation-only | Sealed |
| 294 | Core skeleton | `core/controlledWriteActivationBridgeCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 295)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |

#### Invariants

- `controlledWriteActivationBridgeCore.ts` (Phase 294) permanently sealed — no modification permitted
- `bridgeEnabled=false`, `executionTransitionEnabled=false`, `activationSwitchEnabled=false`, `actualWritesEnabled=false`, `realWritesEnabled=false` compile-time literals in layer 17 — a future bridge-open phase must introduce a new file to change any of these
- `bridgeEnabled=false` and `executionTransitionEnabled=false` are separate, independent flags — do not merge or alias in any future layer
- `bridgePrepared=true` is a forward signal only — marks readiness, not permission; no write, execution, or filesystem mutation enabled by this flag
- 4-check forward-binding chain (`transition_bound_to_switch` → `switch_bound_to_activation` → `activation_bound_to_preflight` → `preflight_bound_to_approval`) must be validated in every future layer consuming transition + switch + activation + preflight records; do not skip or merge
- `rollbackChainValid` sources from `transitionRecord.transitionReadinessReport.rollbackChainValid` — the authoritative aggregated upstream rollback signal; future layers must not reduce coverage below this baseline
- `linkedBridgeReference` with 5 anchors is the authoritative source for rollback and binding references in layer 17 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `bridgeBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 293–294 — `controlledWriteActivationBridgeCore.ts` is internal-only
- 18-layer stack (0–17) fully defined — new layers extend from layer 17 forward only
- Next: First bridge-open blueprint

---

### Phase 296 — First Bridge-Open Blueprint

**Documentation-only phase.** Defines layer 18 of the write-preparation + preflight + activation + switch + transition + bridge stack: the first bridge-open descriptor. 0 runtime source files changed.

**Purpose:** define the first bridge-open descriptor · bind bridge-open readiness to bridge layer · bind bridge-open readiness to transition/switch/activation chain · keep actual writes disabled in this phase · prepare future activation enablement

**Inputs (6):** `ControlledWriteActivationBridgeRecord` · `FirstExecutionTransitionRecord` · `FirstActivationSwitchRecord` · `FirstRealSandboxWriteActivationRecord` · `ActualSandboxWritePreflightRecord` · `ControlledExecutionRecord`

**Outputs (6):** `bridgeOpenId` · `bridgeOpenChecks[]` · `bridgeOpenBlockedReasons[]` · `bridgeOpenReadinessReport` · `linkedBridgeOpenReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `bridgeOpenPrepared=true` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `bridgeOpenState="descriptor_bridge_open_pending"`

**Validation rules (13):** `bridge_record_exists` · `execution_transition_exists` · `activation_switch_exists` · `activation_record_exists` · `preflight_record_exists` · `execution_record_exists` · `bridge_bound_to_transition` · `transition_bound_to_switch` · `switch_bound_to_activation` · `activation_bound_to_preflight` · `bridge_open_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 297 — First Bridge-Open Core Skeleton

**Runtime phase.** Created `core/firstBridgeOpenCore.ts` — in-memory first bridge-open descriptor engine. Layer 18 of the write-preparation + preflight + activation + switch + transition + bridge stack.

**Key design points:**

- 4-check forward-binding chain: `bridge_bound_to_transition` (`bridgeRecord.executionTransitionId === transitionRecord.executionTransitionId`) → `transition_bound_to_switch` → `switch_bound_to_activation` → `activation_bound_to_preflight` — adds `bridge_bound_to_transition` as new head; chain now traverses 7 binding layers end-to-end (bridge → transition → switch → activation → preflight)
- `rollbackChainValid` combined across `bridgeRecord.bridgeReadinessReport.rollbackChainValid` (aggregates full upstream stack through layer 17) + `preflightRecord.preflightReadinessReport.rollbackReady` — compact and authoritative
- `linkedBridgeOpenReference` carries **5 anchors**: `writeActivationBridgeId` (from bridgeRecord) + `executionTransitionId` (from transitionRecord) + `activationSwitchId` (from switchRecord) + `activationId` (from activationRecord) + `rollbackSnapshotId` (sourced from `bridgeRecord.linkedBridgeReference.rollbackSnapshotId`) — rollback chain custody flows through the bridge reference
- `bridgeOpenEnabled=false` and `bridgeEnabled=false` are two independent compile-time flags — bridge-open gate and bridge gate remain separate; do not merge in future layers
- `bridgeOpenPrepared=true` is a new compile-time literal — forward-readiness signal from layer 18 toward a future bridge-open execution phase; marks readiness, not permission
- `bridgeOpenBlockedReasons[]` carries 3 static entries (`bridge_open_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–17

**Compile-time literals:** `bridgeOpenState="descriptor_bridge_open_pending"` · `approvalRequired=true` · `bridgeOpenPrepared=true` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createBridgeOpenRecord` · `listBridgeOpenRecords` · `getBridgeOpenSummary`

---

### Phase 298 — Bridge-Open Compression Seal

**Documentation-only phase.** Seals the bridge-open batch (Phases 296–297). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 296–297)

| Phase | Type | File | Status |
|---|---|---|---|
| 296 | Blueprint | documentation-only | Sealed |
| 297 | Core skeleton | `core/firstBridgeOpenCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 298)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |

#### Invariants

- `firstBridgeOpenCore.ts` (Phase 297) permanently sealed — no modification permitted
- `bridgeOpenEnabled=false`, `bridgeEnabled=false`, `executionTransitionEnabled=false`, `activationSwitchEnabled=false`, `actualWritesEnabled=false`, `realWritesEnabled=false` compile-time literals in layer 18 — a future guarded-write-enable phase must introduce a new file to change any of these
- `bridgeOpenEnabled=false` and `bridgeEnabled=false` are separate, independent flags — do not merge or alias in any future layer
- `bridgeOpenPrepared=true` is a forward signal only — marks readiness, not permission; no write, execution, or filesystem mutation enabled by this flag
- 4-check forward-binding chain (`bridge_bound_to_transition` → `transition_bound_to_switch` → `switch_bound_to_activation` → `activation_bound_to_preflight`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` sources from `bridgeRecord.bridgeReadinessReport.rollbackChainValid` — the authoritative aggregated upstream signal through layer 17; future layers must not reduce coverage below this baseline
- `linkedBridgeOpenReference` with 5 anchors is the authoritative source for rollback and binding references in layer 18 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `bridgeOpenBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 296–297 — `firstBridgeOpenCore.ts` is internal-only
- 19-layer stack (0–18) fully defined — new layers extend from layer 18 forward only
- Next: First guarded write enable phase

---

### Phase 299 — First Guarded Write Enable Blueprint

**Documentation-only phase.** Defines layer 19 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open stack: the first guarded write enable descriptor. 0 runtime source files changed.

**Purpose:** prepare first guarded write enable state · bind enablement to bridge-open readiness · bind enablement to bridge, transition, switch, and activation chain · keep actual writes disabled in this phase · prepare future sandbox mutation phase

**Inputs (6):** `FirstBridgeOpenRecord` · `ControlledWriteActivationBridgeRecord` · `FirstExecutionTransitionRecord` · `FirstActivationSwitchRecord` · `FirstRealSandboxWriteActivationRecord` · `ControlledExecutionRecord`

**Outputs (6):** `guardedWriteEnableId` · `guardedEnableChecks[]` · `guardedEnableBlockedReasons[]` · `guardedEnableReadinessReport` · `linkedGuardedEnableReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `guardedWriteEnablePrepared=true` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `enableState="descriptor_guarded_write_enable_pending"`

**Validation rules (13):** `bridge_open_record_exists` · `bridge_record_exists` · `execution_transition_exists` · `activation_switch_exists` · `activation_record_exists` · `execution_record_exists` · `bridge_open_bound_to_bridge` · `bridge_bound_to_transition` · `transition_bound_to_switch` · `switch_bound_to_activation` · `guarded_write_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 300 — First Guarded Write Enable Core Skeleton

**Runtime phase.** Created `core/firstGuardedWriteEnableCore.ts` — in-memory first guarded write enable descriptor engine. Layer 19 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open stack.

**Key design points:**

- 4-check forward-binding chain: `bridge_open_bound_to_bridge` (`bridgeOpenRecord.writeActivationBridgeId === bridgeRecord.writeActivationBridgeId`) → `bridge_bound_to_transition` → `transition_bound_to_switch` → `switch_bound_to_activation` — adds `bridge_open_bound_to_bridge` as new head; chain now traverses 8 binding layers end-to-end (guarded-enable → bridge-open → bridge → transition → switch → activation)
- `rollbackChainValid` delegates entirely to `bridgeOpenRecord.bridgeOpenReadinessReport.rollbackChainValid` — that field aggregates the full upstream stack through layer 18; no additional sources needed at layer 19 (bridge-open already combines bridge + preflight); most compact valid aggregation yet
- `linkedGuardedEnableReference` carries **5 anchors**: `bridgeOpenId` (from bridgeOpenRecord) + `writeActivationBridgeId` (from bridgeRecord) + `executionTransitionId` (from transitionRecord) + `activationSwitchId` (from switchRecord) + `rollbackSnapshotId` (sourced from `bridgeOpenRecord.linkedBridgeOpenReference.rollbackSnapshotId`) — rollback chain custody flows through the bridge-open reference
- `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, `bridgeEnabled=false` are three independent compile-time flags at layer 19 — each gates a distinct operation; do not merge in future layers
- `guardedWriteEnablePrepared=true` is a new compile-time literal — forward-readiness signal from layer 19 toward a future sandbox mutation phase; marks readiness, not permission
- `guardedEnableBlockedReasons[]` carries 3 static entries (`guarded_write_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–18; static entry count holds at 3

**Compile-time literals:** `enableState="descriptor_guarded_write_enable_pending"` · `approvalRequired=true` · `guardedWriteEnablePrepared=true` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createGuardedWriteEnableRecord` · `listGuardedWriteEnableRecords` · `getGuardedWriteEnableSummary`

---

### Phase 301 — Guarded Write Enable Compression Seal

**Documentation-only phase.** Seals the guarded write enable batch (Phases 299–300). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 299–300)

| Phase | Type | File | Status |
|---|---|---|---|
| 299 | Blueprint | documentation-only | Sealed |
| 300 | Core skeleton | `core/firstGuardedWriteEnableCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 301)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |

#### Invariants

- `firstGuardedWriteEnableCore.ts` (Phase 300) permanently sealed — no modification permitted
- `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, `bridgeEnabled=false`, `executionTransitionEnabled=false`, `activationSwitchEnabled=false`, `actualWritesEnabled=false`, `realWritesEnabled=false` compile-time literals in layer 19 — a future sandbox mutation phase must introduce a new file to change any of these
- `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, and `bridgeEnabled=false` are three separate, independent flags — do not merge or alias in any future layer
- `guardedWriteEnablePrepared=true` is a forward signal only — marks readiness, not permission; no write, execution, or filesystem mutation enabled by this flag
- 4-check forward-binding chain (`bridge_open_bound_to_bridge` → `bridge_bound_to_transition` → `transition_bound_to_switch` → `switch_bound_to_activation`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` sources from `bridgeOpenRecord.bridgeOpenReadinessReport.rollbackChainValid` — the authoritative aggregated upstream signal through layer 18; future layers must not reduce coverage below this baseline
- `linkedGuardedEnableReference` with 5 anchors is the authoritative source for rollback and binding references in layer 19 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `guardedEnableBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 299–300 — `firstGuardedWriteEnableCore.ts` is internal-only
- 20-layer stack (0–19) fully defined — new layers extend from layer 19 forward only
- Next: First actual sandbox mutation switch

---

### Phase 302 — First Actual Sandbox Mutation Switch Blueprint

**Documentation-only phase.** Defines layer 20 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable stack: the first sandbox mutation-switch descriptor. 0 runtime source files changed.

**Purpose:** define the first sandbox mutation-switch descriptor · bind mutation-switch readiness to guarded-write readiness · bind mutation-switch readiness to bridge-open / bridge / transition / switch chain · prepare future actual sandbox mutation · keep mutation disabled in this phase

**Inputs (6):** `FirstGuardedWriteEnableRecord` · `FirstBridgeOpenRecord` · `ControlledWriteActivationBridgeRecord` · `FirstExecutionTransitionRecord` · `FirstActivationSwitchRecord` · `ControlledExecutionRecord`

**Outputs (6):** `mutationSwitchId` · `mutationSwitchChecks[]` · `mutationSwitchBlockedReasons[]` · `mutationSwitchReadinessReport` · `linkedMutationSwitchReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `mutationSwitchPrepared=true` · `mutationSwitchEnabled=false` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `mutationSwitchState="descriptor_mutation_switch_pending"`

**Validation rules (13):** `guarded_write_enable_exists` · `bridge_open_exists` · `bridge_record_exists` · `execution_transition_exists` · `activation_switch_exists` · `execution_record_exists` · `guarded_enable_bound_to_bridge_open` · `bridge_open_bound_to_bridge` · `bridge_bound_to_transition` · `transition_bound_to_switch` · `mutation_switch_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 303 — First Actual Sandbox Mutation Switch Core Skeleton

**Runtime phase.** Created `core/firstActualSandboxMutationSwitchCore.ts` — in-memory first sandbox mutation-switch descriptor engine. Layer 20 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable stack.

**Key design points:**

- 4-check forward-binding chain: `guarded_enable_bound_to_bridge_open` (`guardedWriteEnableRecord.bridgeOpenId === bridgeOpenRecord.bridgeOpenId`) → `bridge_open_bound_to_bridge` → `bridge_bound_to_transition` → `transition_bound_to_switch` — adds `guarded_enable_bound_to_bridge_open` as new head; chain now traverses 9 binding layers end-to-end (mutation-switch → guarded-enable → bridge-open → bridge → transition → switch)
- `rollbackChainValid` delegates entirely to `guardedWriteEnableRecord.guardedEnableReadinessReport.rollbackChainValid` — aggregates full upstream stack through layer 19; guarded-enable delegates to bridge-open which combines bridge + preflight; no additional sources needed at layer 20
- `linkedMutationSwitchReference` carries **5 anchors**: `guardedWriteEnableId` (from guardedWriteEnableRecord) + `bridgeOpenId` (from bridgeOpenRecord) + `writeActivationBridgeId` (from bridgeRecord) + `executionTransitionId` (from transitionRecord) + `rollbackSnapshotId` (sourced from `guardedWriteEnableRecord.linkedGuardedEnableReference.rollbackSnapshotId`) — rollback chain custody flows through the guarded-enable reference
- `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, `bridgeEnabled=false` — four independent compile-time gate flags at layer 20; each gates a distinct operation; do not merge in future layers
- `mutationSwitchPrepared=true` is a new compile-time literal — forward-readiness signal from layer 20 toward a future actual sandbox mutation phase; marks readiness, not permission
- `mutationSwitchBlockedReasons[]` carries 3 static entries (`mutation_switch_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–19; static entry count holds at 3

**Compile-time literals:** `mutationSwitchState="descriptor_mutation_switch_pending"` · `approvalRequired=true` · `mutationSwitchPrepared=true` · `mutationSwitchEnabled=false` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `activationSwitchEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createMutationSwitchRecord` · `listMutationSwitchRecords` · `getMutationSwitchSummary`

---

### Phase 304 — Sandbox Mutation Switch Compression Seal

**Documentation-only phase.** Seals the sandbox mutation-switch batch (Phases 302–303). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 302–303)

| Phase | Type | File | Status |
|---|---|---|---|
| 302 | Blueprint | documentation-only | Sealed |
| 303 | Core skeleton | `core/firstActualSandboxMutationSwitchCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 304)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |

#### Invariants

- `firstActualSandboxMutationSwitchCore.ts` (Phase 303) permanently sealed — no modification permitted
- `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, `bridgeEnabled=false`, `executionTransitionEnabled=false`, `activationSwitchEnabled=false`, `actualWritesEnabled=false`, `realWritesEnabled=false` compile-time literals in layer 20 — a future sandbox write permission gate must introduce a new file to change any of these
- `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, and `bridgeEnabled=false` are four separate, independent flags — do not merge or alias in any future layer
- `mutationSwitchPrepared=true` is a forward signal only — marks readiness, not permission; no write, execution, or filesystem mutation enabled by this flag
- 4-check forward-binding chain (`guarded_enable_bound_to_bridge_open` → `bridge_open_bound_to_bridge` → `bridge_bound_to_transition` → `transition_bound_to_switch`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` delegates to `guardedWriteEnableRecord.guardedEnableReadinessReport.rollbackChainValid` — authoritative aggregated signal through layer 19; do not reduce coverage
- `linkedMutationSwitchReference` with 5 anchors is the authoritative source for rollback and binding references in layer 20 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `mutationSwitchBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 302–303 — `firstActualSandboxMutationSwitchCore.ts` is internal-only
- 21-layer stack (0–20) fully defined — new layers extend from layer 20 forward only
- Next: First actual sandbox write permission gate

---

### Phase 305 — Actual Sandbox Write Permission Gate Blueprint

**Documentation-only phase.** Defines layer 21 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch stack: the first actual sandbox write permission gate descriptor. 0 runtime source files changed.

**Purpose:** define the first actual sandbox write permission gate · bind permission readiness to mutation switch · bind permission readiness to guarded enable / bridge-open / bridge / transition chain · keep actual writes disabled in this phase · prepare future scoped sandbox write permission activation

**Inputs (6):** `FirstActualSandboxMutationSwitchRecord` · `FirstGuardedWriteEnableRecord` · `FirstBridgeOpenRecord` · `ControlledWriteActivationBridgeRecord` · `FirstExecutionTransitionRecord` · `ControlledExecutionRecord`

**Outputs (6):** `writePermissionGateId` · `permissionChecks[]` · `permissionBlockedReasons[]` · `permissionReadinessReport` · `linkedPermissionReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `writePermissionPrepared=true` · `writePermissionEnabled=false` · `mutationSwitchEnabled=false` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `permissionState="descriptor_write_permission_pending"`

**Validation rules (13):** `mutation_switch_exists` · `guarded_write_enable_exists` · `bridge_open_exists` · `bridge_record_exists` · `execution_transition_exists` · `execution_record_exists` · `mutation_switch_bound_to_guarded_enable` · `guarded_enable_bound_to_bridge_open` · `bridge_open_bound_to_bridge` · `bridge_bound_to_transition` · `write_permission_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 306 — Actual Sandbox Write Permission Gate Core Skeleton

**Runtime phase.** Created `core/actualSandboxWritePermissionGateCore.ts` — in-memory first actual sandbox write permission gate descriptor engine. Layer 21 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch stack.

**Key design points:**

- 4-check forward-binding chain: `mutation_switch_bound_to_guarded_enable` (`mutationSwitchRecord.guardedWriteEnableId === guardedWriteEnableRecord.guardedWriteEnableId`) → `guarded_enable_bound_to_bridge_open` → `bridge_open_bound_to_bridge` → `bridge_bound_to_transition` — adds `mutation_switch_bound_to_guarded_enable` as new head; chain now traverses 10 binding layers end-to-end (permission-gate → mutation-switch → guarded-enable → bridge-open → bridge → transition)
- `rollbackChainValid` delegates entirely to `mutationSwitchRecord.mutationSwitchReadinessReport.rollbackChainValid` — aggregates full upstream stack through layer 20; mutation-switch delegates to guarded-enable → bridge-open → bridge + preflight; no additional sources needed at layer 21
- `linkedPermissionReference` carries **5 anchors**: `mutationSwitchId` (from mutationSwitchRecord) + `guardedWriteEnableId` (from guardedWriteEnableRecord) + `bridgeOpenId` (from bridgeOpenRecord) + `writeActivationBridgeId` (from bridgeRecord) + `rollbackSnapshotId` (sourced from `mutationSwitchRecord.linkedMutationSwitchReference.rollbackSnapshotId`) — rollback chain custody flows through the mutation-switch reference
- `writePermissionEnabled=false`, `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, `bridgeEnabled=false` — five independent compile-time gate flags at layer 21; each gates a distinct operation; do not merge in future layers
- `writePermissionPrepared=true` is a new compile-time literal — forward-readiness signal from layer 21 toward a future scoped sandbox write permission activation; marks readiness, not permission
- `permissionBlockedReasons[]` carries 3 static entries (`write_permission_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–20; static entry count holds at 3

**Compile-time literals:** `permissionState="descriptor_write_permission_pending"` · `approvalRequired=true` · `writePermissionPrepared=true` · `writePermissionEnabled=false` · `mutationSwitchEnabled=false` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `executionTransitionEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createWritePermissionGateRecord` · `listWritePermissionGateRecords` · `getWritePermissionGateSummary`

---

### Phase 307 — Write Permission Gate Compression Seal

**Documentation-only phase.** Seals the write permission gate batch (Phases 305–306). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 305–306)

| Phase | Type | File | Status |
|---|---|---|---|
| 305 | Blueprint | documentation-only | Sealed |
| 306 | Core skeleton | `core/actualSandboxWritePermissionGateCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 307)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |
| 21 | `actualSandboxWritePermissionGateCore.ts` | `"descriptor_write_permission_pending"` | 307 |

#### Invariants

- `actualSandboxWritePermissionGateCore.ts` (Phase 306) permanently sealed — no modification permitted
- `writePermissionEnabled=false`, `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, `bridgeEnabled=false`, `executionTransitionEnabled=false`, `activationSwitchEnabled=false`, `actualWritesEnabled=false`, `realWritesEnabled=false` compile-time literals in layer 21 — a future scoped sandbox write activation must introduce a new file to change any of these
- `writePermissionEnabled=false`, `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, and `bridgeEnabled=false` are five separate, independent flags — do not merge or alias in any future layer
- `writePermissionPrepared=true` is a forward signal only — marks readiness, not permission; no write, execution, or filesystem mutation enabled by this flag
- 4-check forward-binding chain (`mutation_switch_bound_to_guarded_enable` → `guarded_enable_bound_to_bridge_open` → `bridge_open_bound_to_bridge` → `bridge_bound_to_transition`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` delegates to `mutationSwitchRecord.mutationSwitchReadinessReport.rollbackChainValid` — authoritative aggregated signal through layer 20; do not reduce coverage
- `linkedPermissionReference` with 5 anchors is the authoritative source for rollback and binding references in layer 21 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `permissionBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 305–306 — `actualSandboxWritePermissionGateCore.ts` is internal-only
- 22-layer stack (0–21) fully defined — new layers extend from layer 21 forward only
- Next: First scoped sandbox write activation

---

### Phase 308 — First Scoped Sandbox Write Activation Blueprint

**Documentation-only phase.** Defines layer 22 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate stack: the first scoped sandbox write activation descriptor. 0 runtime source files changed.

**Purpose:** prepare scoped write activation for sandbox-only zones · bind activation to permission gate · bind activation to mutation switch / guarded enable / bridge-open chain · keep actual writes disabled in this phase · prepare future controlled sandbox mutation

**Inputs (6):** `ActualSandboxWritePermissionGateRecord` · `FirstActualSandboxMutationSwitchRecord` · `FirstGuardedWriteEnableRecord` · `FirstBridgeOpenRecord` · `ControlledWriteActivationBridgeRecord` · `ControlledExecutionRecord`

**Outputs (6):** `scopedWriteActivationId` · `scopedActivationChecks[]` · `scopedActivationBlockedReasons[]` · `scopedActivationReadinessReport` · `linkedScopedActivationReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `scopedActivationPrepared=true` · `scopedActivationEnabled=false` · `writePermissionEnabled=false` · `mutationSwitchEnabled=false` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `scopedActivationState="descriptor_scoped_write_activation_pending"`

**Validation rules (13):** `write_permission_gate_exists` · `mutation_switch_exists` · `guarded_write_enable_exists` · `bridge_open_exists` · `bridge_record_exists` · `execution_record_exists` · `permission_gate_bound_to_mutation_switch` · `mutation_switch_bound_to_guarded_enable` · `guarded_enable_bound_to_bridge_open` · `bridge_open_bound_to_bridge` · `scoped_activation_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 309 — First Scoped Sandbox Write Activation Core Skeleton

**Runtime phase.** Created `core/firstScopedSandboxWriteActivationCore.ts` — in-memory first scoped sandbox write activation descriptor engine. Layer 22 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate stack.

**Key design points:**

- 4-check forward-binding chain: `permission_gate_bound_to_mutation_switch` (`writePermissionGateRecord.mutationSwitchId === mutationSwitchRecord.mutationSwitchId`) → `mutation_switch_bound_to_guarded_enable` → `guarded_enable_bound_to_bridge_open` → `bridge_open_bound_to_bridge` — adds `permission_gate_bound_to_mutation_switch` as new head; chain now traverses 11 binding layers end-to-end (scoped-activation → permission-gate → mutation-switch → guarded-enable → bridge-open → bridge)
- `rollbackChainValid` delegates entirely to `writePermissionGateRecord.permissionReadinessReport.rollbackChainValid` — aggregates full upstream stack through layer 21; permission-gate delegates to mutation-switch → guarded-enable → bridge-open → bridge + preflight; no additional sources needed at layer 22
- `linkedScopedActivationReference` carries **5 anchors**: `writePermissionGateId` (from writePermissionGateRecord) + `mutationSwitchId` (from mutationSwitchRecord) + `guardedWriteEnableId` (from guardedWriteEnableRecord) + `bridgeOpenId` (from bridgeOpenRecord) + `rollbackSnapshotId` (sourced from `writePermissionGateRecord.linkedPermissionReference.rollbackSnapshotId`) — rollback chain custody flows through the permission reference
- `scopedActivationEnabled=false`, `writePermissionEnabled=false`, `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, `bridgeEnabled=false` — six independent compile-time gate flags at layer 22; each gates a distinct operation; do not merge in future layers
- `scopedActivationPrepared=true` is a new compile-time literal — forward-readiness signal from layer 22 toward a future controlled sandbox mutation phase; marks readiness, not permission
- `scopedActivationBlockedReasons[]` carries 3 static entries (`scoped_activation_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–21; static entry count holds at 3

**Compile-time literals:** `scopedActivationState="descriptor_scoped_write_activation_pending"` · `approvalRequired=true` · `scopedActivationPrepared=true` · `scopedActivationEnabled=false` · `writePermissionEnabled=false` · `mutationSwitchEnabled=false` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `bridgeEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createScopedActivationRecord` · `listScopedActivationRecords` · `getScopedActivationSummary`

---

### Phase 310 — Scoped Write Activation Compression Seal

**Documentation-only phase.** Seals the scoped write activation batch (Phases 308–309). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 308–309)

| Phase | Type | File | Status |
|---|---|---|---|
| 308 | Blueprint | documentation-only | Sealed |
| 309 | Core skeleton | `core/firstScopedSandboxWriteActivationCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 310)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |
| 21 | `actualSandboxWritePermissionGateCore.ts` | `"descriptor_write_permission_pending"` | 307 |
| 22 | `firstScopedSandboxWriteActivationCore.ts` | `"descriptor_scoped_write_activation_pending"` | 310 |

#### Invariants

- `firstScopedSandboxWriteActivationCore.ts` (Phase 309) permanently sealed — no modification permitted
- `scopedActivationEnabled=false`, `writePermissionEnabled=false`, `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false`, `bridgeEnabled=false`, `actualWritesEnabled=false`, `realWritesEnabled=false` compile-time literals in layer 22 — a future actual sandbox write execution gate must introduce a new file to change any of these
- All six gate flags are separate and independent — do not merge or alias in any future layer
- `scopedActivationPrepared=true` is a forward signal only — marks readiness, not permission; no write, execution, or filesystem mutation enabled by this flag
- 4-check forward-binding chain (`permission_gate_bound_to_mutation_switch` → `mutation_switch_bound_to_guarded_enable` → `guarded_enable_bound_to_bridge_open` → `bridge_open_bound_to_bridge`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` delegates to `writePermissionGateRecord.permissionReadinessReport.rollbackChainValid` — authoritative aggregated signal through layer 21; do not reduce coverage
- `linkedScopedActivationReference` with 5 anchors is the authoritative source for rollback and binding references in layer 22 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `scopedActivationBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 308–309 — `firstScopedSandboxWriteActivationCore.ts` is internal-only
- 23-layer stack (0–22) fully defined — new layers extend from layer 22 forward only
- Next: First actual sandbox write execution gate

---

### Phase 311 — Actual Sandbox Write Execution Gate Blueprint

**Documentation-only phase.** Defines layer 23 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation stack: the actual sandbox write execution gate descriptor. 0 runtime source files changed.

**Purpose:** define the final execution gate before first real sandbox write · bind execution gate to scoped activation · bind execution gate to permission/mutation/guarded chain · keep actual writes disabled in this phase · prepare future first real sandbox write operation

**Inputs (6):** `FirstScopedSandboxWriteActivationRecord` · `ActualSandboxWritePermissionGateRecord` · `FirstActualSandboxMutationSwitchRecord` · `FirstGuardedWriteEnableRecord` · `FirstBridgeOpenRecord` · `ControlledExecutionRecord`

**Outputs (6):** `writeExecutionGateId` · `executionGateChecks[]` · `executionGateBlockedReasons[]` · `executionGateReadinessReport` · `linkedExecutionGateReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `writeExecutionGatePrepared=true` · `writeExecutionGateEnabled=false` · `scopedActivationEnabled=false` · `writePermissionEnabled=false` · `mutationSwitchEnabled=false` · `guardedWriteEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `executionGateState="descriptor_write_execution_gate_pending"`

**Validation rules (13):** `scoped_activation_exists` · `write_permission_gate_exists` · `mutation_switch_exists` · `guarded_write_enable_exists` · `bridge_open_exists` · `execution_record_exists` · `scoped_activation_bound_to_permission_gate` · `permission_gate_bound_to_mutation_switch` · `mutation_switch_bound_to_guarded_enable` · `guarded_enable_bound_to_bridge_open` · `write_execution_gate_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 312 — Actual Sandbox Write Execution Gate Core Skeleton

**Runtime phase.** Created `core/actualSandboxWriteExecutionGateCore.ts` — in-memory actual sandbox write execution gate descriptor engine. Layer 23 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation stack.

**Key design points:**

- 4-check forward-binding chain: `scoped_activation_bound_to_permission_gate` (`scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId`) → `permission_gate_bound_to_mutation_switch` → `mutation_switch_bound_to_guarded_enable` → `guarded_enable_bound_to_bridge_open` — adds `scoped_activation_bound_to_permission_gate` as new head; chain now traverses 12 binding layers end-to-end (execution-gate → scoped-activation → permission-gate → mutation-switch → guarded-enable → bridge-open)
- `rollbackChainValid` delegates entirely to `scopedActivationRecord.scopedActivationReadinessReport.rollbackChainValid` — aggregates full upstream stack through layer 22; scoped-activation delegates to permission-gate → mutation-switch → guarded-enable → bridge-open → bridge + preflight; no additional sources needed at layer 23
- `linkedExecutionGateReference` carries **5 anchors**: `scopedWriteActivationId` (from scopedActivationRecord) + `writePermissionGateId` (from writePermissionGateRecord) + `mutationSwitchId` (from mutationSwitchRecord) + `guardedWriteEnableId` (from guardedWriteEnableRecord) + `rollbackSnapshotId` (sourced from `scopedActivationRecord.linkedScopedActivationReference.rollbackSnapshotId`) — rollback chain custody flows through the scoped-activation reference
- `writeExecutionGateEnabled=false`, `scopedActivationEnabled=false`, `writePermissionEnabled=false`, `mutationSwitchEnabled=false`, `guardedWriteEnabled=false`, `bridgeOpenEnabled=false` — six independent compile-time gate flags at layer 23; each gates a distinct operation; do not merge in future layers
- `writeExecutionGatePrepared=true` is a new compile-time literal — forward-readiness signal from layer 23 toward a future first real sandbox write operation; marks readiness, not permission
- `executionGateBlockedReasons[]` carries 3 static entries (`write_execution_gate_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–22; static entry count holds at 3

**Compile-time literals:** `executionGateState="descriptor_write_execution_gate_pending"` · `approvalRequired=true` · `writeExecutionGatePrepared=true` · `writeExecutionGateEnabled=false` · `scopedActivationEnabled=false` · `writePermissionEnabled=false` · `mutationSwitchEnabled=false` · `guardedWriteEnabled=false` · `bridgeOpenEnabled=false` · `actualWritesEnabled=false` · `realWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createWriteExecutionGateRecord` · `listWriteExecutionGateRecords` · `getWriteExecutionGateSummary`

---

### Phase 313 — Write Execution Gate Compression Seal

**Documentation-only phase.** Seals the write execution gate batch (Phases 311–312). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 311–312)

| Phase | Type | File | Status |
|---|---|---|---|
| 311 | Blueprint | documentation-only | Sealed |
| 312 | Core skeleton | `core/actualSandboxWriteExecutionGateCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 313)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |
| 21 | `actualSandboxWritePermissionGateCore.ts` | `"descriptor_write_permission_pending"` | 307 |
| 22 | `firstScopedSandboxWriteActivationCore.ts` | `"descriptor_scoped_write_activation_pending"` | 310 |
| 23 | `actualSandboxWriteExecutionGateCore.ts` | `"descriptor_write_execution_gate_pending"` | 313 |

#### Invariants

- `actualSandboxWriteExecutionGateCore.ts` (Phase 312) permanently sealed — no modification permitted
- All six gate flags (`writeExecutionGateEnabled`, `scopedActivationEnabled`, `writePermissionEnabled`, `mutationSwitchEnabled`, `guardedWriteEnabled`, `bridgeOpenEnabled`) are false, independent, and must not be merged or aliased in future layers
- `writeExecutionGatePrepared=true` is a forward signal only — marks readiness, not permission; no write, execution, or filesystem mutation enabled by this flag
- 4-check forward-binding chain (`scoped_activation_bound_to_permission_gate` → `permission_gate_bound_to_mutation_switch` → `mutation_switch_bound_to_guarded_enable` → `guarded_enable_bound_to_bridge_open`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` delegates to `scopedActivationRecord.scopedActivationReadinessReport.rollbackChainValid` — authoritative aggregated signal through layer 22; do not reduce coverage
- `linkedExecutionGateReference` with 5 anchors is the authoritative source for rollback and binding references in layer 23 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `executionGateBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 311–312 — `actualSandboxWriteExecutionGateCore.ts` is internal-only
- 24-layer stack (0–23) fully defined — new layers extend from layer 23 forward only
- Next: First actual sandbox write operation blueprint

---

### Phase 314 — First Actual Sandbox Write Operation Blueprint

**Documentation-only phase.** Defines layer 24 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate stack: the first actual sandbox write operation descriptor. 0 runtime source files changed.

**Purpose:** define first actual sandbox write operation model · bind operation to execution gate · bind operation to scoped activation / permission / mutation chain · restrict future writes to sandbox-approved targets only · keep runtime filesystem mutation disabled until executor phase

**Inputs (6):** `ActualSandboxWriteExecutionGateRecord` · `FirstScopedSandboxWriteActivationRecord` · `ActualSandboxWritePermissionGateRecord` · `FirstActualSandboxMutationSwitchRecord` · `FirstGuardedWriteEnableRecord` · `ControlledExecutionRecord`

**Outputs (6):** `actualWriteOperationId` · `writeOperationPlan[]` · `operationSafetyChecks[]` · `blockedOperationReasons[]` · `rollbackOperationReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `actualWriteOperationPrepared=true` · `runtimeWriteExecutorEnabled=false` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `operationState="descriptor_actual_write_operation_ready"`

**Validation rules (13):** `execution_gate_exists` · `scoped_activation_exists` · `permission_gate_exists` · `mutation_switch_exists` · `guarded_write_enable_exists` · `execution_record_exists` · `execution_gate_bound_to_scoped_activation` · `scoped_activation_bound_to_permission_gate` · `permission_gate_bound_to_mutation_switch` · `mutation_switch_bound_to_guarded_enable` · `runtime_executor_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 315 — First Actual Sandbox Write Operation Core Skeleton

**Runtime phase.** Created `core/firstActualSandboxWriteOperationCore.ts` — in-memory first actual sandbox write operation descriptor engine. Layer 24 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate stack.

**Key design points:**

- 4-check forward-binding chain: `execution_gate_bound_to_scoped_activation` (`writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId`) → `scoped_activation_bound_to_permission_gate` → `permission_gate_bound_to_mutation_switch` → `mutation_switch_bound_to_guarded_enable` — adds `execution_gate_bound_to_scoped_activation` as new head; chain now traverses 13 binding layers end-to-end (write-operation → execution-gate → scoped-activation → permission-gate → mutation-switch → guarded-enable)
- `rollbackChainValid` delegates entirely to `writeExecutionGateRecord.executionGateReadinessReport.rollbackChainValid` — aggregates full upstream stack through layer 23; execution-gate delegates to scoped-activation → permission-gate → mutation-switch → guarded-enable → bridge-open → bridge + preflight; no additional sources needed at layer 24
- `rollbackOperationReference` carries **5 anchors**: `writeExecutionGateId` (from writeExecutionGateRecord) + `scopedWriteActivationId` (from scopedActivationRecord) + `writePermissionGateId` (from writePermissionGateRecord) + `mutationSwitchId` (from mutationSwitchRecord) + `rollbackSnapshotId` (sourced from `writeExecutionGateRecord.linkedExecutionGateReference.rollbackSnapshotId`) — rollback chain custody flows through the execution-gate reference
- `writeOperationPlan[]` carries 1 descriptor entry with `targetScope="sandbox_approved_only"` and `mutationBlocked=true` — establishes the sandbox-approved-only write target constraint as a permanent compile-time invariant; future runtime write executor must honor this scope and cannot widen it without a new file
- `runtimeWriteExecutorEnabled=false` is a new compile-time literal — executor gate separate from all upstream gates; marks readiness toward a future runtime write executor phase
- `actualWriteOperationPrepared=true` is a new compile-time literal — confirms operation model is descriptor-captured; independent of `runtimeWriteExecutorEnabled`
- `blockedOperationReasons[]` carries 3 static entries (`runtime_executor_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–23; static entry count holds at 3

**Compile-time literals:** `operationState="descriptor_actual_write_operation_ready"` · `approvalRequired=true` · `actualWriteOperationPrepared=true` · `runtimeWriteExecutorEnabled=false` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createWriteOperationRecord` · `listWriteOperationRecords` · `getWriteOperationSummary`

---

### Phase 316 — First Actual Sandbox Write Operation Compression Seal

**Documentation-only phase.** Seals the first actual sandbox write operation batch (Phases 314–315). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 314–315)

| Phase | Type | File | Status |
|---|---|---|---|
| 314 | Blueprint | documentation-only | Sealed |
| 315 | Core skeleton | `core/firstActualSandboxWriteOperationCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 316)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |
| 21 | `actualSandboxWritePermissionGateCore.ts` | `"descriptor_write_permission_pending"` | 307 |
| 22 | `firstScopedSandboxWriteActivationCore.ts` | `"descriptor_scoped_write_activation_pending"` | 310 |
| 23 | `actualSandboxWriteExecutionGateCore.ts` | `"descriptor_write_execution_gate_pending"` | 313 |
| 24 | `firstActualSandboxWriteOperationCore.ts` | `"descriptor_actual_write_operation_ready"` | 316 |

#### Invariants

- `firstActualSandboxWriteOperationCore.ts` (Phase 315) permanently sealed — no modification permitted
- `targetScope=sandbox_approved_only` in `writeOperationPlan[]` is a permanent constraint — future runtime write executor must restrict all write targets to sandbox-approved paths; cannot be widened without a new file
- `runtimeWriteExecutorEnabled=false` and `actualWriteOperationPrepared=true` are two independent compile-time signals — do not conflate; each guards a distinct gate
- `runtimeWriteExecutorEnabled=false` must not be merged or aliased with any upstream gate flag in future layers
- 4-check forward-binding chain (`execution_gate_bound_to_scoped_activation` → `scoped_activation_bound_to_permission_gate` → `permission_gate_bound_to_mutation_switch` → `mutation_switch_bound_to_guarded_enable`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` delegates to `writeExecutionGateRecord.executionGateReadinessReport.rollbackChainValid` — authoritative aggregated signal through layer 23; do not reduce coverage
- `rollbackOperationReference` with 5 anchors is the authoritative source for rollback and binding references in layer 24 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `blockedOperationReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 314–315 — `firstActualSandboxWriteOperationCore.ts` is internal-only
- 25-layer stack (0–24) fully defined — new layers extend from layer 24 forward only
- Next: Runtime write executor blueprint

---

### Phase 317 — Runtime Write Executor Blueprint

**Documentation-only phase.** Defines layer 25 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate + write-operation stack: the runtime write executor descriptor. 0 runtime source files changed.

**Purpose:** define the first runtime write executor model · bind executor to actual write operation plan · bind executor to execution gate / scoped activation / permission / mutation chain · preserve sandbox-approved-only target scope · keep executor disabled in this phase

**Inputs (6):** `FirstActualSandboxWriteOperationRecord` · `ActualSandboxWriteExecutionGateRecord` · `FirstScopedSandboxWriteActivationRecord` · `ActualSandboxWritePermissionGateRecord` · `FirstActualSandboxMutationSwitchRecord` · `ControlledExecutionRecord`

**Outputs (6):** `runtimeWriteExecutorId` · `executorPlan[]` · `executorSafetyChecks[]` · `executorBlockedReasons[]` · `linkedExecutorReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `runtimeWriteExecutorPrepared=true` · `runtimeWriteExecutorEnabled=false` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `executorState="descriptor_runtime_write_executor_pending"`

**Validation rules (13):** `actual_write_operation_exists` · `execution_gate_exists` · `scoped_activation_exists` · `permission_gate_exists` · `mutation_switch_exists` · `execution_record_exists` · `write_operation_bound_to_execution_gate` · `execution_gate_bound_to_scoped_activation` · `scoped_activation_bound_to_permission_gate` · `permission_gate_bound_to_mutation_switch` · `executor_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 318 — Runtime Write Executor Core Skeleton

**Runtime phase.** Created `core/runtimeWriteExecutorCore.ts` — in-memory runtime write executor descriptor engine. Layer 25 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate + write-operation stack.

**Key design points:**

- 4-check forward-binding chain: `write_operation_bound_to_execution_gate` (`writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId`) → `execution_gate_bound_to_scoped_activation` → `scoped_activation_bound_to_permission_gate` → `permission_gate_bound_to_mutation_switch` — adds `write_operation_bound_to_execution_gate` as new head; chain now traverses 14 binding layers end-to-end (executor → write-operation → execution-gate → scoped-activation → permission-gate → mutation-switch)
- `rollbackChainValid` delegates entirely to `writeOperationRecord.writeOperationReadinessReport.rollbackChainValid` — aggregates full upstream stack through layer 24; write-operation delegates to execution-gate → scoped-activation → permission-gate → mutation-switch → guarded-enable → bridge-open → bridge + preflight; no additional sources needed at layer 25
- `linkedExecutorReference` carries **5 anchors**: `actualWriteOperationId` (from writeOperationRecord) + `writeExecutionGateId` (from writeExecutionGateRecord) + `scopedWriteActivationId` (from scopedActivationRecord) + `writePermissionGateId` (from writePermissionGateRecord) + `rollbackSnapshotId` (sourced from `writeOperationRecord.rollbackOperationReference.rollbackSnapshotId`) — rollback chain custody flows through the write-operation reference
- `executorPlan[]` carries 1 descriptor entry explicitly inheriting `targetScope="sandbox_approved_only"` and `executorEnabled=false` from layer 24 — sandbox-approved-only constraint now established at two consecutive layers (24 and 25); future sandbox write commit phase cannot widen without a new file
- `runtimeWriteExecutorPrepared=true` is a new compile-time literal — forward-readiness signal from layer 25 toward a future first sandbox write commit descriptor; marks readiness, not permission
- `executorBlockedReasons[]` carries 3 static entries (`executor_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–24; static entry count holds at 3

**Compile-time literals:** `executorState="descriptor_runtime_write_executor_pending"` · `approvalRequired=true` · `runtimeWriteExecutorPrepared=true` · `runtimeWriteExecutorEnabled=false` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createRuntimeWriteExecutorRecord` · `listRuntimeWriteExecutorRecords` · `getRuntimeWriteExecutorSummary`

---

### Phase 319 — Runtime Write Executor Compression Seal

**Documentation-only phase.** Seals the runtime write executor batch (Phases 317–318). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 317–318)

| Phase | Type | File | Status |
|---|---|---|---|
| 317 | Blueprint | documentation-only | Sealed |
| 318 | Core skeleton | `core/runtimeWriteExecutorCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 319)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |
| 21 | `actualSandboxWritePermissionGateCore.ts` | `"descriptor_write_permission_pending"` | 307 |
| 22 | `firstScopedSandboxWriteActivationCore.ts` | `"descriptor_scoped_write_activation_pending"` | 310 |
| 23 | `actualSandboxWriteExecutionGateCore.ts` | `"descriptor_write_execution_gate_pending"` | 313 |
| 24 | `firstActualSandboxWriteOperationCore.ts` | `"descriptor_actual_write_operation_ready"` | 316 |
| 25 | `runtimeWriteExecutorCore.ts` | `"descriptor_runtime_write_executor_pending"` | 319 |

#### Invariants

- `runtimeWriteExecutorCore.ts` (Phase 318) permanently sealed — no modification permitted
- `targetScope=sandbox_approved_only` now established at two consecutive layers (24 and 25) — future sandbox write commit phase must honor this scope at each layer; cannot widen without a new file per layer
- `runtimeWriteExecutorEnabled=false` at layer 25 is independent from the same literal at layer 24 — do not merge or treat as a single flag across files
- `runtimeWriteExecutorPrepared=true` is a forward signal only — marks readiness, not permission; no write or execution enabled by this flag
- 4-check forward-binding chain (`write_operation_bound_to_execution_gate` → `execution_gate_bound_to_scoped_activation` → `scoped_activation_bound_to_permission_gate` → `permission_gate_bound_to_mutation_switch`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` delegates to `writeOperationRecord.writeOperationReadinessReport.rollbackChainValid` — authoritative aggregated signal through layer 24; do not reduce coverage
- `linkedExecutorReference` with 5 anchors is the authoritative source for rollback and binding references in layer 25 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `executorBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 317–318 — `runtimeWriteExecutorCore.ts` is internal-only
- 26-layer stack (0–25) fully defined — new layers extend from layer 25 forward only
- Next: First sandbox write commit descriptor

---

### Phase 320 — First Sandbox Write Commit Descriptor Blueprint

**Documentation-only phase.** Defines layer 26 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate + write-operation + runtime-write-executor stack: the first sandbox write commit descriptor. 0 runtime source files changed.

**Purpose:** define first sandbox write commit descriptor · bind commit descriptor to runtime write executor · bind commit descriptor to actual write operation / execution gate / scoped activation chain · preserve targetScope=sandbox_approved_only · keep filesystem mutation disabled in this phase

**Inputs (6):** `RuntimeWriteExecutorRecord` · `FirstActualSandboxWriteOperationRecord` · `ActualSandboxWriteExecutionGateRecord` · `FirstScopedSandboxWriteActivationRecord` · `ActualSandboxWritePermissionGateRecord` · `ControlledExecutionRecord`

**Outputs (6):** `sandboxWriteCommitId` · `commitPlan[]` · `commitSafetyChecks[]` · `commitBlockedReasons[]` · `linkedCommitReference` · `approvalRequired=true`

**Compile-time literals:** `approvalRequired=true` · `sandboxWriteCommitPrepared=true` · `sandboxWriteCommitEnabled=false` · `runtimeWriteExecutorEnabled=false` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `commitState="descriptor_sandbox_write_commit_pending"`

**Validation rules (13):** `runtime_write_executor_exists` · `actual_write_operation_exists` · `execution_gate_exists` · `scoped_activation_exists` · `write_permission_gate_exists` · `execution_record_exists` · `executor_bound_to_write_operation` · `write_operation_bound_to_execution_gate` · `execution_gate_bound_to_scoped_activation` · `scoped_activation_bound_to_permission_gate` · `commit_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 321 — First Sandbox Write Commit Descriptor Core Skeleton

**Runtime phase.** Created `core/firstSandboxWriteCommitCore.ts` — in-memory first sandbox write commit descriptor engine. Layer 26 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate + write-operation + runtime-write-executor stack.

**Key design points:**

- 4-check forward-binding chain: `executor_bound_to_write_operation` (`executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId`) → `write_operation_bound_to_execution_gate` → `execution_gate_bound_to_scoped_activation` → `scoped_activation_bound_to_permission_gate` — adds `executor_bound_to_write_operation` as new head; chain now traverses 15 binding layers end-to-end (commit → executor → write-operation → execution-gate → scoped-activation → permission-gate → mutation-switch)
- `rollbackChainValid` delegates entirely to `executorRecord.executorReadinessReport.rollbackChainValid` — aggregates full upstream stack through layer 25; no additional sources needed at layer 26
- `linkedCommitReference` carries **5 anchors**: `runtimeWriteExecutorId` (from executorRecord) + `actualWriteOperationId` (from writeOperationRecord) + `writeExecutionGateId` (from writeExecutionGateRecord) + `scopedWriteActivationId` (from scopedActivationRecord) + `rollbackSnapshotId` (sourced from `executorRecord.linkedExecutorReference.rollbackSnapshotId`) — rollback chain custody flows through the executor reference
- `commitPlan[]` carries 1 descriptor entry inheriting `targetScope="sandbox_approved_only"` from layers 24–25 — sandbox-approved-only constraint now established at three consecutive layers (24, 25, 26); future sandbox write commit enable phase cannot widen without a new file per layer
- `sandboxWriteCommitPrepared=true` is a new compile-time literal — forward-readiness signal from layer 26; marks readiness, not permission
- `sandboxWriteCommitEnabled=false` and `runtimeWriteExecutorEnabled=false` are two independent compile-time literals — do not conflate; each guards a distinct gate
- `commitBlockedReasons[]` carries 3 static entries (`commit_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–25; static entry count holds at 3; `actual_writes_disabled` note references all 26 sealed layers

**Compile-time literals:** `commitState="descriptor_sandbox_write_commit_pending"` · `approvalRequired=true` · `sandboxWriteCommitPrepared=true` · `sandboxWriteCommitEnabled=false` · `runtimeWriteExecutorEnabled=false` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `implementationPhase="descriptor_only"`

**Exports:** `createFirstSandboxWriteCommitRecord` · `listFirstSandboxWriteCommitRecords` · `getFirstSandboxWriteCommitSummary`

---

### Phase 322 — First Sandbox Write Commit Descriptor Compression Seal

**Documentation-only phase.** Seals the first sandbox write commit descriptor batch (Phases 320–321). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 320–321)

| Phase | Type | File | Status |
|---|---|---|---|
| 320 | Blueprint | documentation-only | Sealed |
| 321 | Core skeleton | `core/firstSandboxWriteCommitCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 322)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |
| 21 | `actualSandboxWritePermissionGateCore.ts` | `"descriptor_write_permission_pending"` | 307 |
| 22 | `firstScopedSandboxWriteActivationCore.ts` | `"descriptor_scoped_write_activation_pending"` | 310 |
| 23 | `actualSandboxWriteExecutionGateCore.ts` | `"descriptor_write_execution_gate_pending"` | 313 |
| 24 | `firstActualSandboxWriteOperationCore.ts` | `"descriptor_actual_write_operation_ready"` | 316 |
| 25 | `runtimeWriteExecutorCore.ts` | `"descriptor_runtime_write_executor_pending"` | 319 |
| 26 | `firstSandboxWriteCommitCore.ts` | `"descriptor_sandbox_write_commit_pending"` | 322 |

#### Invariants

- `firstSandboxWriteCommitCore.ts` (Phase 321) permanently sealed — no modification permitted
- `targetScope=sandbox_approved_only` now established at three consecutive layers (24, 25, 26) — future sandbox write commit enable phase must honor this scope at each layer; cannot widen without a new file per layer
- `sandboxWriteCommitEnabled=false` and `runtimeWriteExecutorEnabled=false` are independent compile-time literals at layer 26 — do not merge or treat as a single flag across files
- `sandboxWriteCommitPrepared=true` is a forward signal only — marks readiness, not permission; no write or execution enabled by this flag
- 4-check forward-binding chain (`executor_bound_to_write_operation` → `write_operation_bound_to_execution_gate` → `execution_gate_bound_to_scoped_activation` → `scoped_activation_bound_to_permission_gate`) must be validated in every future layer; do not skip or merge
- `rollbackChainValid` delegates to `executorRecord.executorReadinessReport.rollbackChainValid` — authoritative aggregated signal through layer 25; do not reduce coverage
- `linkedCommitReference` with 5 anchors is the authoritative source for rollback and binding references in layer 26 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `commitBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 320–321 — `firstSandboxWriteCommitCore.ts` is internal-only
- 27-layer stack (0–26) fully defined — new layers extend from layer 26 forward only
- Next: Sandbox write commit enable blueprint

---

### Phase 323 — Sandbox Write Commit Enable Blueprint

**Documentation-only phase.** Defines layer 27 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate + write-operation + runtime-write-executor + sandbox-write-commit stack: the sandbox write commit enable descriptor. 0 runtime source files changed.

**Purpose:** prepare the sandbox write commit enable layer · bind commit enablement to sandbox write commit descriptor · bind commit enablement to executor / write operation / execution gate chain · preserve targetScope=sandbox_approved_only · keep actual filesystem mutation disabled in this phase

**Inputs (6):** `FirstSandboxWriteCommitRecord` · `RuntimeWriteExecutorRecord` · `FirstActualSandboxWriteOperationRecord` · `ActualSandboxWriteExecutionGateRecord` · `FirstScopedSandboxWriteActivationRecord` · `ControlledExecutionRecord`

**Outputs (6):** `sandboxWriteCommitEnableId` · `commitEnableChecks[]` · `commitEnableBlockedReasons[]` · `commitEnableReadinessReport` · `linkedCommitEnableReference` · `approvalRequired=true`

**Compile-time literals (12):** `approvalRequired=true` · `sandboxWriteCommitEnablePrepared=true` · `sandboxWriteCommitEnabled=false` · `runtimeWriteExecutorEnabled=false` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `targetScope="sandbox_approved_only"` · `commitEnableState="descriptor_sandbox_write_commit_enable_pending"`

**Validation rules (13):** `sandbox_write_commit_exists` · `runtime_write_executor_exists` · `actual_write_operation_exists` · `execution_gate_exists` · `scoped_activation_exists` · `execution_record_exists` · `commit_bound_to_executor` · `executor_bound_to_write_operation` · `write_operation_bound_to_execution_gate` · `execution_gate_bound_to_scoped_activation` · `commit_enable_still_disabled` · `actual_writes_still_disabled` · `output_remains_descriptor_only`

---

### Phase 324 — Sandbox Write Commit Enable Core Skeleton

**Runtime phase.** Created `core/sandboxWriteCommitEnableCore.ts` — in-memory sandbox write commit enable descriptor engine. Layer 27 of the write-preparation + preflight + activation + switch + transition + bridge + bridge-open + guarded-write-enable + mutation-switch + permission-gate + scoped-activation + execution-gate + write-operation + runtime-write-executor + sandbox-write-commit stack.

**Key design points:**

- 4-check forward-binding chain: `commit_bound_to_executor` (`commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId`) → `executor_bound_to_write_operation` → `write_operation_bound_to_execution_gate` → `execution_gate_bound_to_scoped_activation` — adds `commit_bound_to_executor` as new head; chain now traverses 16 binding layers end-to-end (commit-enable → commit → executor → write-operation → execution-gate → scoped-activation → permission-gate → mutation-switch)
- `rollbackChainValid` delegates entirely to `commitRecord.commitReadinessReport.rollbackChainValid` — aggregates full upstream stack through layer 26; no additional sources needed at layer 27
- `linkedCommitEnableReference` carries **5 anchors**: `sandboxWriteCommitId` (from commitRecord) + `runtimeWriteExecutorId` (from executorRecord) + `actualWriteOperationId` (from writeOperationRecord) + `writeExecutionGateId` (from writeExecutionGateRecord) + `rollbackSnapshotId` (sourced from `commitRecord.linkedCommitReference.rollbackSnapshotId`) — rollback chain custody flows through the commit reference
- `targetScope="sandbox_approved_only"` promoted to first-class record field — previously carried only inside `plan[]` entries at layers 24–26; at layer 27 it is a named field on `SandboxWriteCommitEnableRecord`, `CommitEnableReadinessReport`, and `SandboxWriteCommitEnableSummary`; future layers must carry it as a first-class field
- `sandboxWriteCommitEnablePrepared=true` is a new compile-time literal — forward-readiness signal from layer 27; marks readiness, not permission
- `sandboxWriteCommitEnabled=false` and `runtimeWriteExecutorEnabled=false` are two independent compile-time literals — do not conflate; each guards a distinct gate
- `commitEnableBlockedReasons[]` carries 3 static entries (`commit_enable_disabled` · `approval_required` · `actual_writes_disabled`) — consistent with layers 13–26; static entry count holds at 3; `actual_writes_disabled` note references all 27 sealed layers

**Compile-time literals:** `commitEnableState="descriptor_sandbox_write_commit_enable_pending"` · `approvalRequired=true` · `sandboxWriteCommitEnablePrepared=true` · `sandboxWriteCommitEnabled=false` · `runtimeWriteExecutorEnabled=false` · `actualWritesEnabled=false` · `filesystemMutationBlocked=true` · `motherCoreMutationBlocked=true` · `vaultMutationBlocked=true` · `shellBlocked=true` · `networkBlocked=true` · `targetScope="sandbox_approved_only"` · `implementationPhase="descriptor_only"`

**Exports:** `createSandboxWriteCommitEnableRecord` · `listSandboxWriteCommitEnableRecords` · `getSandboxWriteCommitEnableSummary`

---

### Phase 325 — Sandbox Write Commit Enable Compression Seal

**Documentation-only phase.** Seals the sandbox write commit enable batch (Phases 323–324). 0 runtime source files changed. All counters unchanged.

#### Sealed Files (Phases 323–324)

| Phase | Type | File | Status |
|---|---|---|---|
| 323 | Blueprint | documentation-only | Sealed |
| 324 | Core skeleton | `core/sandboxWriteCommitEnableCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 325)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |
| 21 | `actualSandboxWritePermissionGateCore.ts` | `"descriptor_write_permission_pending"` | 307 |
| 22 | `firstScopedSandboxWriteActivationCore.ts` | `"descriptor_scoped_write_activation_pending"` | 310 |
| 23 | `actualSandboxWriteExecutionGateCore.ts` | `"descriptor_write_execution_gate_pending"` | 313 |
| 24 | `firstActualSandboxWriteOperationCore.ts` | `"descriptor_actual_write_operation_ready"` | 316 |
| 25 | `runtimeWriteExecutorCore.ts` | `"descriptor_runtime_write_executor_pending"` | 319 |
| 26 | `firstSandboxWriteCommitCore.ts` | `"descriptor_sandbox_write_commit_pending"` | 322 |
| 27 | `sandboxWriteCommitEnableCore.ts` | `"descriptor_sandbox_write_commit_enable_pending"` | 325 |

#### Invariants

- `sandboxWriteCommitEnableCore.ts` (Phase 324) permanently sealed — no modification permitted
- `targetScope="sandbox_approved_only"` is now a first-class record field at layer 27 — future layers must carry it as a named field, not demote to plan-entry-only
- `targetScope=sandbox_approved_only` established at four consecutive layers (24, 25, 26, 27) — future layers must honor this scope; cannot widen without a new file per layer
- `sandboxWriteCommitEnabled=false` and `runtimeWriteExecutorEnabled=false` are independent compile-time literals at layer 27 — do not merge or treat as a single flag
- `sandboxWriteCommitEnablePrepared=true` is a forward signal only — marks readiness, not permission
- 4-check forward-binding chain (`commit_bound_to_executor` → `executor_bound_to_write_operation` → `write_operation_bound_to_execution_gate` → `execution_gate_bound_to_scoped_activation`) must be validated in every future layer; chain traverses 16 binding layers end-to-end
- `rollbackChainValid` delegates to `commitRecord.commitReadinessReport.rollbackChainValid` — authoritative aggregated signal through layer 26; do not reduce coverage
- `linkedCommitEnableReference` with 5 anchors is the authoritative source for rollback and binding references in layer 27 and above — source `rollbackSnapshotId` from it, not from individual upstream records
- `commitEnableBlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 323–324 — `sandboxWriteCommitEnableCore.ts` is internal-only
- 28-layer stack (0–27) fully defined — new layers extend from layer 27 forward only
- Next: First actual sandbox write commit execution gate

---

### Phase 336 — Actual Sandbox Mutation Path Compression Seal

**Documentation-only phase.** Seals Phases 326–335 (Actual Sandbox Write Commit Execution Gate + First Actual Sandbox Mutation Executor + Commit + Apply + Surface). 0 runtime source files changed. All counters unchanged. ep=162, pol=162, hc=38, sub=27, graph=27/0.

#### Sealed Files (Phases 326–335)

| Phase | Type | File | Status |
|---|---|---|---|
| 326 | Blueprint | documentation-only | Sealed |
| 327 | Core skeleton | `core/actualSandboxWriteCommitExecutionGateCore.ts` | Sealed — never modify |
| 328 | Blueprint | documentation-only | Sealed |
| 329 | Core skeleton | `core/firstActualSandboxMutationExecutorCore.ts` | Sealed — never modify |
| 330 | Blueprint | documentation-only | Sealed |
| 331 | Core skeleton | `core/firstActualSandboxMutationCommitCore.ts` | Sealed — never modify |
| 332 | Blueprint | documentation-only | Sealed |
| 333 | Core skeleton | `core/firstActualSandboxMutationApplyCore.ts` | Sealed — never modify |
| 334 | Blueprint | documentation-only | Sealed |
| 335 | Core skeleton | `core/firstActualSandboxMutationSurfaceCore.ts` | Sealed — never modify |

#### Full Layer Stack (after Phase 336)

| Layer | Core file | State | Sealed phase |
|---|---|---|---|
| 0 | `experimentalProductionFlowCore.ts` | `"observe_ready"` | 248 |
| 1 | `controlledExecutionCore.ts` | `"awaiting_operator_execution_approval"` | 254 |
| 2 | `sandboxFilesystemCore.ts` | `"descriptor_mount_planned"` | 263 |
| 3 | `controlledWriteGuardCore.ts` | `"descriptor_guard_ready"` | 263 |
| 4 | `realWriteEnablementGateCore.ts` | `"pre_write_ready"` | 263 |
| 5 | `sandboxWritePlanCore.ts` | `"descriptor_write_plan_ready"` | 263 |
| 6 | `guardedSandboxWriteCore.ts` | `"guarded_descriptor_ready"` | 272 |
| 7 | `sandboxWriteAuditCore.ts` | `"descriptor_audit_ready"` | 272 |
| 8 | `sandboxWriteRollbackSnapshotCore.ts` | `"descriptor_snapshot_ready"` | 272 |
| 9 | `sandboxWriteCommitGateCore.ts` | `"descriptor_commit_gate_ready"` | 272 |
| 10 | `actualSandboxWriteEnablementCore.ts` | `"actual_write_pre_enablement_ready"` | 281 |
| 11 | `actualSandboxWriteDryRunCore.ts` | `"descriptor_dry_run_ready"` | 281 |
| 12 | `actualSandboxWriteApprovalTokenCore.ts` | `"descriptor_approval_pending"` | 281 |
| 13 | `actualSandboxWritePreflightCore.ts` | `"descriptor_preflight_ready"` | 281 |
| 14 | `firstRealSandboxWriteActivationCore.ts` | `"descriptor_activation_ready"` | 286 |
| 15 | `firstActivationSwitchCore.ts` | `"descriptor_switch_pending"` | 289 |
| 16 | `firstExecutionTransitionCore.ts` | `"descriptor_transition_pending"` | 292 |
| 17 | `controlledWriteActivationBridgeCore.ts` | `"descriptor_bridge_pending"` | 295 |
| 18 | `firstBridgeOpenCore.ts` | `"descriptor_bridge_open_pending"` | 298 |
| 19 | `firstGuardedWriteEnableCore.ts` | `"descriptor_guarded_write_enable_pending"` | 301 |
| 20 | `firstActualSandboxMutationSwitchCore.ts` | `"descriptor_mutation_switch_pending"` | 304 |
| 21 | `actualSandboxWritePermissionGateCore.ts` | `"descriptor_write_permission_pending"` | 307 |
| 22 | `firstScopedSandboxWriteActivationCore.ts` | `"descriptor_scoped_write_activation_pending"` | 310 |
| 23 | `actualSandboxWriteExecutionGateCore.ts` | `"descriptor_write_execution_gate_pending"` | 313 |
| 24 | `firstActualSandboxWriteOperationCore.ts` | `"descriptor_actual_write_operation_ready"` | 316 |
| 25 | `runtimeWriteExecutorCore.ts` | `"descriptor_runtime_write_executor_pending"` | 319 |
| 26 | `firstSandboxWriteCommitCore.ts` | `"descriptor_sandbox_write_commit_pending"` | 322 |
| 27 | `sandboxWriteCommitEnableCore.ts` | `"descriptor_sandbox_write_commit_enable_pending"` | 325 |
| 28 | `actualSandboxWriteCommitExecutionGateCore.ts` | `"descriptor_commit_execution_gate_pending"` | 336 |
| 29 | `firstActualSandboxMutationExecutorCore.ts` | `"descriptor_mutation_executor_pending"` | 336 |
| 30 | `firstActualSandboxMutationCommitCore.ts` | `"descriptor_mutation_commit_pending"` | 336 |
| 31 | `firstActualSandboxMutationApplyCore.ts` | `"descriptor_mutation_apply_pending"` | 336 |
| 32 | `firstActualSandboxMutationSurfaceCore.ts` | `"descriptor_mutation_surface_pending"` | 336 |

#### Invariants

- All five core files (Phases 327, 329, 331, 333, 335) permanently sealed — no modification permitted
- `targetScope="sandbox_approved_only"` established at nine consecutive layers (24–32) as a first-class record field — future layers must carry it as a named field, not demote to plan-entry-only
- `*Prepared=true` signals at layers 28–32 are forward signals only — each marks readiness, not permission; do not interpret as activation authority in any future layer
- `*Enabled=false` flags at layers 28–32 are five independent compile-time literals — do not merge, alias, or derive any from the others
- 4-check forward-binding chain head at layer 32: `mutation_apply_bound_to_commit` → `mutation_commit_bound_to_executor` → `mutation_executor_bound_to_commit_execution_gate` → `commit_execution_gate_bound_to_commit_enable`; chain traverses 21 binding layers end-to-end
- `rollbackChainValid` single-step delegation: each layer delegates to immediately upstream record's readiness report — do not skip links or aggregate from multiple sources
- `rollbackSnapshotId` sourced from immediately upstream reference object at each layer — never re-derived from individual upstream records
- `*BlockedReasons[]` always has 3 static entries — do not reduce in future layers
- No observe API added in Phases 326–335 — all five new core files are internal-only
- 33-layer stack (0–32) fully defined — new layers extend from layer 32 forward only
- Next: First controlled filesystem mutation enablement blueprint (layer 33); must add `mutation_surface_bound_to_apply` as new chain head; must delegate `rollbackChainValid` to `mutationSurfaceRecord.mutationSurfaceReadinessReport.rollbackChainValid`; must source `rollbackSnapshotId` from `mutationSurfaceRecord.linkedMutationSurfaceReference.rollbackSnapshotId`
