// Widget Contract Validation Probe — Phase 103
// Validates live composed widget payloads against their registered Widget Data Contracts.
// Pure read-only: fetches composed shell once, validates all 37 widgets in one pass.
// No persistence, no init, no subsystem, no health check.

import { createHash } from "node:crypto";
import {
  getWidgetContract,
  WidgetField,
  WidgetEnumeration,
  type WidgetFieldType,
} from "./workspaceWidgetContracts";
import { getWorkspaceVisualShellComposed } from "./workspaceVisualShellComposition";

const EXECUTION_BLOCKED: true = true;

// --- Validation result types ---

export type ValidationRule =
  | "no_contract"
  | "data_type_mismatch"
  | "execution_blocked_missing"
  | "required_field_missing"
  | "type_mismatch"
  | "enum_violation";

export interface ValidationFailure {
  field: string;
  rule: ValidationRule;
  expected: string;
  actual: string;
  executionBlocked: true;
}

export interface FieldValidationResult {
  fieldName: string;
  passed: boolean;
  failures: ValidationFailure[];
  executionBlocked: true;
}

export interface WidgetValidationResult {
  widgetId: string;
  widgetType: string;
  sectionId: string;
  compactDataType: string;
  contractFound: boolean;
  passed: boolean;
  fieldResults: FieldValidationResult[];
  topLevelFailures: ValidationFailure[];
  executionBlocked: true;
}

export interface ValidationCoverage {
  totalFields: number;
  passedFields: number;
  failedFields: number;
  coveragePercent: number;
  executionBlocked: true;
}

export interface WidgetValidationSummary {
  totalWidgetsValidated: number;
  passedWidgets: number;
  failedWidgets: number;
  allWidgetsValid: boolean;
  widgetCoveragePercent: number;
  fieldValidationCount: number;
  failedFieldCount: number;
  contractsMissing: number;
  executionBlocked: true;
}

export interface WidgetValidationProbeResult {
  probeId: string;
  generatedAt: string;
  summary: WidgetValidationSummary;
  results: WidgetValidationResult[];
  fieldCoverage: ValidationCoverage;
  executionBlocked: true;
}

// --- Type checker ---

function validateFieldType(value: unknown, fieldType: WidgetFieldType): boolean {
  switch (fieldType) {
    case "string":      return typeof value === "string";
    case "number":      return typeof value === "number";
    case "boolean":     return typeof value === "boolean";
    case "string|null": return typeof value === "string" || value === null;
    case "number|null": return typeof value === "number" || value === null;
    case "string[]":    return Array.isArray(value) && (value as unknown[]).every((v) => typeof v === "string");
  }
}

function typeLabel(value: unknown): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}

// --- Per-field validator ---

function validateField(
  field: WidgetField,
  payload: Record<string, unknown>,
  enumerations: WidgetEnumeration[],
): FieldValidationResult {
  const failures: ValidationFailure[] = [];
  const value = payload[field.fieldName];
  const isPresent = field.fieldName in payload;

  // Presence check (required = non-nullable domain fields, tracked separately via contract.requiredFields)
  // Here we check all fields defined in the contract — nullable ones may be null but must be present
  if (!isPresent) {
    failures.push({
      field: field.fieldName,
      rule: "required_field_missing",
      expected: `key "${field.fieldName}" present in payload`,
      actual: "key absent",
      executionBlocked: EXECUTION_BLOCKED,
    });
    // No point type-checking a missing field
    return { fieldName: field.fieldName, passed: false, failures, executionBlocked: EXECUTION_BLOCKED };
  }

  // Type check
  if (!validateFieldType(value, field.fieldType)) {
    failures.push({
      field: field.fieldName,
      rule: "type_mismatch",
      expected: field.fieldType,
      actual: typeLabel(value),
      executionBlocked: EXECUTION_BLOCKED,
    });
  }

  // Enumeration check (only when value is non-null and a string — covers all enumerated fields)
  const enumDef = enumerations.find((e) => e.field === field.fieldName);
  if (enumDef !== undefined && value !== null && typeof value === "string") {
    if (!enumDef.values.includes(value)) {
      failures.push({
        field: field.fieldName,
        rule: "enum_violation",
        expected: `one of [${enumDef.values.join(", ")}]`,
        actual: String(value),
        executionBlocked: EXECUTION_BLOCKED,
      });
    }
  }

  return {
    fieldName: field.fieldName,
    passed: failures.length === 0,
    failures,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Per-widget validator ---

function validateWidget(
  widgetId: string,
  widgetType: string,
  sectionId: string,
  compactData: Record<string, unknown>,
): WidgetValidationResult {
  const topLevelFailures: ValidationFailure[] = [];
  const fieldResults: FieldValidationResult[] = [];

  // Resolve contract
  const contract = getWidgetContract(widgetId);
  if (contract === null) {
    topLevelFailures.push({
      field: "widgetId",
      rule: "no_contract",
      expected: `registered contract for widgetId "${widgetId}"`,
      actual: "no contract found",
      executionBlocked: EXECUTION_BLOCKED,
    });
    return {
      widgetId,
      widgetType,
      sectionId,
      compactDataType: String(compactData["dataType"] ?? "unknown"),
      contractFound: false,
      passed: false,
      fieldResults,
      topLevelFailures,
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  // Validate compactDataType consistency
  const liveDataType = compactData["dataType"];
  if (liveDataType !== contract.compactDataType) {
    topLevelFailures.push({
      field: "dataType",
      rule: "data_type_mismatch",
      expected: contract.compactDataType,
      actual: String(liveDataType ?? "absent"),
      executionBlocked: EXECUTION_BLOCKED,
    });
  }

  // Validate executionBlocked invariant at the compactData level
  if (compactData["executionBlocked"] !== true) {
    topLevelFailures.push({
      field: "executionBlocked",
      rule: "execution_blocked_missing",
      expected: "true",
      actual: String(compactData["executionBlocked"] ?? "absent"),
      executionBlocked: EXECUTION_BLOCKED,
    });
  }

  // Validate all declared fields in contract order (includes executionBlocked field itself)
  for (const field of contract.fields) {
    const result = validateField(field, compactData, contract.enumerations);
    fieldResults.push(result);
  }

  const allFieldsPassed = fieldResults.every((fr) => fr.passed);
  const passed = topLevelFailures.length === 0 && allFieldsPassed;

  return {
    widgetId,
    widgetType,
    sectionId: contract.sectionId,
    compactDataType: contract.compactDataType,
    contractFound: true,
    passed,
    fieldResults,
    topLevelFailures,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Public probe entry point ---

export function runWidgetValidationProbe(): WidgetValidationProbeResult {
  const generatedAt = new Date().toISOString();
  const probeId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  // Fetch live composed shell (one call covers all 37 widgets)
  const composed = getWorkspaceVisualShellComposed();
  const allWidgets = composed.composedPanels.flatMap((panel) => panel.widgets);

  // Map from panelId → sectionId using composed panels
  const panelSectionMap: Map<string, string> = new Map(
    composed.composedPanels.map((p) => [p.panelId, p.sectionId]),
  );

  // Validate each widget in composedPanel order
  const results: WidgetValidationResult[] = [];
  for (const widget of allWidgets) {
    // Resolve sectionId: look up via panel order in composedPanels
    const panelEntry = composed.composedPanels.find((p) =>
      p.widgets.some((w) => w.widgetId === widget.widgetId),
    );
    const sectionId = panelEntry ? (panelSectionMap.get(panelEntry.panelId) ?? "unknown") : "unknown";

    const compactData = widget.compactData as unknown as Record<string, unknown>;
    const result = validateWidget(widget.widgetId, widget.widgetType, sectionId, compactData);
    results.push(result);
  }

  // Aggregate summary
  const totalWidgetsValidated = results.length;
  const passedWidgets = results.filter((r) => r.passed).length;
  const failedWidgets = totalWidgetsValidated - passedWidgets;
  const allWidgetsValid = failedWidgets === 0;
  const contractsMissing = results.filter((r) => !r.contractFound).length;

  const widgetCoveragePercent =
    totalWidgetsValidated === 0
      ? 0
      : Math.round((passedWidgets / totalWidgetsValidated) * 100);

  // Field-level aggregation (only for widgets with contracts)
  let totalFieldValidations = 0;
  let failedFieldValidations = 0;
  for (const r of results) {
    totalFieldValidations += r.fieldResults.length;
    failedFieldValidations += r.fieldResults.filter((fr) => !fr.passed).length;
  }

  const summary: WidgetValidationSummary = {
    totalWidgetsValidated,
    passedWidgets,
    failedWidgets,
    allWidgetsValid,
    widgetCoveragePercent,
    fieldValidationCount: totalFieldValidations,
    failedFieldCount: failedFieldValidations,
    contractsMissing,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const passedFieldValidations = totalFieldValidations - failedFieldValidations;
  const fieldCoverage: ValidationCoverage = {
    totalFields: totalFieldValidations,
    passedFields: passedFieldValidations,
    failedFields: failedFieldValidations,
    coveragePercent:
      totalFieldValidations === 0
        ? 0
        : Math.round((passedFieldValidations / totalFieldValidations) * 100),
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    probeId,
    generatedAt,
    summary,
    results,
    fieldCoverage,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
