import { IncomingMessage, ServerResponse } from "node:http";
import { sendJson }                        from "../lib/response.js";
import {
  listControlledExecutionRecords,
  getControlledExecutionSummary,
} from "../core/controlledExecutionCore.js";

export function handleControlledExecutionObserve(
  req: IncomingMessage,
  res: ServerResponse,
): void {
  const executions = listControlledExecutionRecords();
  const summary    = getControlledExecutionSummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    executionEnabled:   false,
    filesystemEnabled:  false,
    networkEnabled:     false,
    deploymentEnabled:  false,
    autonomousEnabled:  false,
    persistenceEnabled: false,
    executionBlocked:   true,
    filesystemBlocked:  true,
    networkBlocked:     true,
    deploymentBlocked:  true,
    autonomousBlocked:  true,
    totalExecutions:    executions.length,
    summary,
    executions,
  });
}
