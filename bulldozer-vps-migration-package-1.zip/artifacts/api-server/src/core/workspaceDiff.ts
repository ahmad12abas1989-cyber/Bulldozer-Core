import {
  listWorkspaceSnapshots,
  getWorkspaceSnapshotById,
  type WorkspaceSnapshot,
} from "./workspaceSnapshots";

const EXECUTION_BLOCKED: true = true;
const MAX_DIFF_ROLE_KEYS = 10;

// --- Interfaces ---

export interface WorkspaceDiffCountDelta {
  from: number;
  to: number;
  delta: number;
  increased: boolean;
  decreased: boolean;
  unchanged: boolean;
}

export interface WorkspaceDiffSummaryDelta {
  totalProjects: WorkspaceDiffCountDelta;
  activeProjects: WorkspaceDiffCountDelta;
  archivedProjects: WorkspaceDiffCountDelta;
  suspendedProjects: WorkspaceDiffCountDelta;
  memberRecords: WorkspaceDiffCountDelta;
  activityRecords: WorkspaceDiffCountDelta;
  customQuotaProjects: WorkspaceDiffCountDelta;
  capacityUsed: WorkspaceDiffCountDelta;
  capacityAvailable: WorkspaceDiffCountDelta;
  utilizationPercent: WorkspaceDiffCountDelta;
}

export interface WorkspaceDiffProjectEntry {
  projectId: string;
  projectName: string;
  status: string;
  owner: string;
  createdAt: string;
}

export interface WorkspaceDiffProjectChanges {
  newlyObserved: WorkspaceDiffProjectEntry[];
  newlyObservedCount: number;
  fromRecentCount: number;
  toRecentCount: number;
  note: string;
}

export interface WorkspaceDiffRoleDelta {
  role: string;
  from: number;
  to: number;
  delta: number;
}

export interface WorkspaceDiffMembershipDelta {
  totalRecordsDelta: WorkspaceDiffCountDelta;
  projectsWithMembersDelta: WorkspaceDiffCountDelta;
  roleDeltas: WorkspaceDiffRoleDelta[];
}

export interface WorkspaceDiffQuotaDelta {
  customQuotaProjectsDelta: WorkspaceDiffCountDelta;
  defaultQuotaProjectsDelta: WorkspaceDiffCountDelta;
}

export interface WorkspaceDiffActivityDelta {
  totalRecordsDelta: WorkspaceDiffCountDelta;
  projectsWithActivityDelta: WorkspaceDiffCountDelta;
}

export interface WorkspaceDiffSnapshotMeta {
  snapshotId: string;
  createdAt: string;
  projectCount: number;
  memberCount: number;
  activityCount: number;
}

export interface WorkspaceDiffResult {
  diffId: string;
  computedAt: string;
  from: WorkspaceDiffSnapshotMeta;
  to: WorkspaceDiffSnapshotMeta;
  timeDeltaMs: number;
  timeDeltaSeconds: number;
  summaryDelta: WorkspaceDiffSummaryDelta;
  projectChanges: WorkspaceDiffProjectChanges;
  membershipDelta: WorkspaceDiffMembershipDelta;
  quotaDelta: WorkspaceDiffQuotaDelta;
  activityDelta: WorkspaceDiffActivityDelta;
  hasChanges: boolean;
  changeCount: number;
  executionBlocked: true;
}

export interface WorkspaceDiffPair {
  fromSnapshotId: string;
  toSnapshotId: string;
  fromCreatedAt: string;
  toCreatedAt: string;
  timeDeltaMs: number;
  executionBlocked: true;
}

export interface WorkspaceDiffListResult {
  checkedAt: string;
  availableSnapshots: number;
  availablePairs: number;
  pairs: WorkspaceDiffPair[];
  note: string;
  executionBlocked: true;
}

// --- Internal helpers ---

function makeDelta(from: number, to: number): WorkspaceDiffCountDelta {
  const delta = to - from;
  return {
    from,
    to,
    delta,
    increased: delta > 0,
    decreased: delta < 0,
    unchanged: delta === 0,
  };
}

function computeDiff(from: WorkspaceSnapshot, to: WorkspaceSnapshot): WorkspaceDiffResult {
  const computedAt = new Date().toISOString();
  const diffId = `${from.snapshotId}-${to.snapshotId}`;
  const fromTs = new Date(from.createdAt).getTime();
  const toTs = new Date(to.createdAt).getTime();
  const timeDeltaMs = toTs - fromTs;

  // --- Summary delta ---
  const fs = from.summary;
  const ts = to.summary;
  const summaryDelta: WorkspaceDiffSummaryDelta = {
    totalProjects:       makeDelta(fs.projects.total,                   ts.projects.total),
    activeProjects:      makeDelta(fs.projects.active,                  ts.projects.active),
    archivedProjects:    makeDelta(fs.projects.archived,                ts.projects.archived),
    suspendedProjects:   makeDelta(fs.projects.suspended,               ts.projects.suspended),
    memberRecords:       makeDelta(fs.members.totalRecords,             ts.members.totalRecords),
    activityRecords:     makeDelta(fs.activity.totalRecords,            ts.activity.totalRecords),
    customQuotaProjects: makeDelta(fs.quotas.projectsWithCustomQuotas,  ts.quotas.projectsWithCustomQuotas),
    capacityUsed:        makeDelta(fs.capacity.used,                    ts.capacity.used),
    capacityAvailable:   makeDelta(fs.capacity.available,               ts.capacity.available),
    utilizationPercent:  makeDelta(fs.capacity.utilizationPercent,      ts.capacity.utilizationPercent),
  };

  // --- Project changes (bounded: compare recentProjects arrays, max 5 each) ---
  const fromRecentIds = new Set(from.panels.projects.recentProjects.map((p) => p.projectId));
  const toRecentProjects = to.panels.projects.recentProjects;
  const newlyObserved: WorkspaceDiffProjectEntry[] = toRecentProjects
    .filter((p) => !fromRecentIds.has(p.projectId))
    .map((p) => ({
      projectId: p.projectId,
      projectName: p.projectName,
      status: p.status,
      owner: p.owner,
      createdAt: p.createdAt,
    }));

  const projectChanges: WorkspaceDiffProjectChanges = {
    newlyObserved,
    newlyObservedCount: newlyObserved.length,
    fromRecentCount: from.panels.projects.recentProjects.length,
    toRecentCount: toRecentProjects.length,
    note:
      "newlyObserved reflects projects appearing in the 'to' snapshot recent-5 list that were absent from the 'from' snapshot recent-5 list. Full registry comparison requires a live query against GET /api/projects.",
  };

  // --- Membership delta ---
  const fm = from.panels.membership;
  const tm = to.panels.membership;
  const allRoles = new Set([
    ...Object.keys(fm.roleDistribution),
    ...Object.keys(tm.roleDistribution),
  ]);
  const roleDeltas: WorkspaceDiffRoleDelta[] = Array.from(allRoles)
    .slice(0, MAX_DIFF_ROLE_KEYS)
    .map((role) => ({
      role,
      from: fm.roleDistribution[role] ?? 0,
      to:   tm.roleDistribution[role] ?? 0,
      delta: (tm.roleDistribution[role] ?? 0) - (fm.roleDistribution[role] ?? 0),
    }))
    .sort((a, b) => a.role.localeCompare(b.role));

  const membershipDelta: WorkspaceDiffMembershipDelta = {
    totalRecordsDelta:       makeDelta(fm.totalRecords,         tm.totalRecords),
    projectsWithMembersDelta: makeDelta(fm.projectsWithMembers, tm.projectsWithMembers),
    roleDeltas,
  };

  // --- Quota delta ---
  const fq = from.panels.quotas;
  const tq = to.panels.quotas;
  const quotaDelta: WorkspaceDiffQuotaDelta = {
    customQuotaProjectsDelta:  makeDelta(fq.projectsWithCustomQuotas, tq.projectsWithCustomQuotas),
    defaultQuotaProjectsDelta: makeDelta(fq.projectsUsingDefaults,    tq.projectsUsingDefaults),
  };

  // --- Activity delta ---
  const fa = from.panels.activity;
  const ta = to.panels.activity;
  const activityDelta: WorkspaceDiffActivityDelta = {
    totalRecordsDelta:        makeDelta(fa.totalRecords,        ta.totalRecords),
    projectsWithActivityDelta: makeDelta(fa.projectsWithActivity, ta.projectsWithActivity),
  };

  // --- hasChanges / changeCount ---
  const allDeltas: WorkspaceDiffCountDelta[] = [
    summaryDelta.totalProjects,
    summaryDelta.activeProjects,
    summaryDelta.archivedProjects,
    summaryDelta.suspendedProjects,
    summaryDelta.memberRecords,
    summaryDelta.activityRecords,
    summaryDelta.customQuotaProjects,
    membershipDelta.totalRecordsDelta,
    membershipDelta.projectsWithMembersDelta,
    quotaDelta.customQuotaProjectsDelta,
    quotaDelta.defaultQuotaProjectsDelta,
    activityDelta.totalRecordsDelta,
    activityDelta.projectsWithActivityDelta,
  ];
  const changeCount =
    allDeltas.filter((d) => !d.unchanged).length + newlyObserved.length;
  const hasChanges = changeCount > 0;

  return {
    diffId,
    computedAt,
    from: {
      snapshotId: from.snapshotId,
      createdAt: from.createdAt,
      projectCount: from.summary.projects.total,
      memberCount: from.summary.members.totalRecords,
      activityCount: from.summary.activity.totalRecords,
    },
    to: {
      snapshotId: to.snapshotId,
      createdAt: to.createdAt,
      projectCount: to.summary.projects.total,
      memberCount: to.summary.members.totalRecords,
      activityCount: to.summary.activity.totalRecords,
    },
    timeDeltaMs,
    timeDeltaSeconds: Math.round(timeDeltaMs / 1000),
    summaryDelta,
    projectChanges,
    membershipDelta,
    quotaDelta,
    activityDelta,
    hasChanges,
    changeCount,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Public API ---

export function getWorkspaceDiff(
  fromSnapshotId: string,
  toSnapshotId: string,
): { result: WorkspaceDiffResult } | { error: string; status: 400 | 404 } {
  if (!fromSnapshotId || !toSnapshotId) {
    return { error: "Both fromSnapshotId and toSnapshotId are required", status: 400 };
  }

  const fromSnapshot = getWorkspaceSnapshotById(fromSnapshotId);
  const toSnapshot = getWorkspaceSnapshotById(toSnapshotId);

  if (fromSnapshot === null) {
    return {
      error: `Snapshot not found: "${fromSnapshotId}". Check GET /api/workspace/snapshots for available IDs.`,
      status: 404,
    };
  }
  if (toSnapshot === null) {
    return {
      error: `Snapshot not found: "${toSnapshotId}". Check GET /api/workspace/snapshots for available IDs.`,
      status: 404,
    };
  }

  return { result: computeDiff(fromSnapshot, toSnapshot) };
}

export function listWorkspaceDiffPairs(): WorkspaceDiffListResult {
  const listing = listWorkspaceSnapshots();
  // listing.snapshots is newest-first; older → newer = from → to
  const snapshots = listing.snapshots;

  const pairs: WorkspaceDiffPair[] = [];
  for (let i = 0; i < snapshots.length - 1; i++) {
    const newer = snapshots[i]!;
    const older = snapshots[i + 1]!;
    const fromTs = new Date(older.createdAt).getTime();
    const toTs = new Date(newer.createdAt).getTime();
    pairs.push({
      fromSnapshotId: older.snapshotId,
      toSnapshotId: newer.snapshotId,
      fromCreatedAt: older.createdAt,
      toCreatedAt: newer.createdAt,
      timeDeltaMs: toTs - fromTs,
      executionBlocked: EXECUTION_BLOCKED,
    });
  }

  return {
    checkedAt: new Date().toISOString(),
    availableSnapshots: snapshots.length,
    availablePairs: pairs.length,
    pairs,
    note:
      "Each pair represents a consecutive snapshot interval. Use GET /api/workspace/diff/:fromSnapshotId/:toSnapshotId to compute a full diff between any two retained snapshots. Execution is blocked — diff results are immutable read-only audit records.",
    executionBlocked: EXECUTION_BLOCKED,
  };
}
