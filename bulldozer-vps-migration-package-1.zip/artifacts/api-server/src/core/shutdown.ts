import { createServer } from "node:http";
import { logger } from "../lib/logger";
import { setRuntimeStatus } from "./runtime";
import { stopFreezeDetector } from "./freezeDetector";
import { stopCrashDetector } from "./crashDetector";
import { stopWatchdog } from "./watchdog";
import { createSnapshot } from "./snapshots";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { saveRuntimeState } from "./runtimeState";
import { emitRuntimeEvent } from "./runtimeEventBus";

type HttpServer = ReturnType<typeof createServer>;

const SHUTDOWN_TIMEOUT_MS = 10_000;
const DRAIN_TIMEOUT_MS = 5_000;

export function registerShutdown(server: HttpServer): void {
  let shuttingDown = false;

  function shutdown(signal: string): void {
    if (shuttingDown) return;
    shuttingDown = true;

    addTimelineEvent({ level: "info", source: "shutdown", message: "Shutdown signal received", metadata: { signal } });
    emit("runtime:stopping", "shutdown", { signal });
    emitRuntimeEvent({
      eventType: "runtime.stopping",
      source: "shutdown",
      severity: "warning",
      category: "runtime",
      payload: { signal },
    });
    createSnapshot("shutdown");
    setRuntimeStatus("stopping");
    saveRuntimeState();
    stopFreezeDetector();
    stopWatchdog();
    stopCrashDetector();
    logger.info({ signal, drainTimeoutMs: DRAIN_TIMEOUT_MS }, "Shutdown signal received — draining connections");

    const hardKillTimer = setTimeout(() => {
      logger.error("Graceful shutdown timed out — forcing exit");
      process.exit(1);
    }, SHUTDOWN_TIMEOUT_MS);

    if (typeof hardKillTimer.unref === "function") hardKillTimer.unref();

    server.closeIdleConnections();

    addTimelineEvent({
      level: "info",
      source: "shutdown",
      message: "Drain window started — idle connections closed, in-flight requests completing",
      metadata: { drainTimeoutMs: DRAIN_TIMEOUT_MS },
    });

    const drainTimer = setTimeout(() => {
      logger.warn({ drainTimeoutMs: DRAIN_TIMEOUT_MS }, "Shutdown drain window expired — closing all remaining connections");
      addTimelineEvent({
        level: "warn",
        source: "shutdown",
        message: "Drain window expired — closing all remaining connections",
        metadata: { drainTimeoutMs: DRAIN_TIMEOUT_MS },
      });
      server.closeAllConnections();
    }, DRAIN_TIMEOUT_MS);

    if (typeof drainTimer.unref === "function") drainTimer.unref();

    server.close((err) => {
      clearTimeout(drainTimer);
      if (err) {
        logger.error({ err: String(err) }, "Error closing HTTP server");
        process.exit(1);
      }
      setRuntimeStatus("stopped");
      logger.info("Bulldozer Core stopped cleanly");
      process.exit(0);
    });
  }

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}
