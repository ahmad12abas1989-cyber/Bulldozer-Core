// Dependency Resolution Core — Phase 228
// Deterministic, non-executing, in-memory dependency resolution engine.
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no filesystem writes, no package
// installation, no runtime execution, no sandbox execution, no external
// registry access, no deployment packaging, no peer auto-resolution,
// no shell execution, no secrets.
// Not wired to runtime.ts or startRuntime().

import { randomBytes } from "node:crypto";
import type { VirtualPackageRecord, VirtualDependency } from "./virtualPackageCore";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type DependencyConflictType =
  | "version_conflict"
  | "circular_dependency"
  | "runtime_incompatibility"
  | "duplicate_identity"
  | "prohibited_category"
  | "incompatible_build_runtime_target";

export type DependencyResolutionState =
  | "structurally_resolved"
  | "conflict_detected"
  | "pending";

export interface ResolvedDependencyNode {
  name: string;
  version: string;
  category: "runtime" | "devDependency" | "peerDependency";
  resolvedAt: string;
  compatibilityStatus: "compatible" | "incompatible" | "unknown";
  detail: string;
}

export interface ResolutionConflictRecord {
  conflictType: DependencyConflictType;
  affectedPackages: string[];
  detail: string;
  severity: "blocking" | "warning";
}

export interface ResolutionOrderingStep {
  step: number;
  name: string;
  version: string;
  category: "runtime" | "devDependency" | "peerDependency";
  descriptor: string;
}

export interface CompatibilitySummary {
  totalChecked: number;
  compatible: number;
  incompatible: number;
  unknown: number;
  runtimeVersion: string;
  buildTool: string;
  buildOutputFormat: string;
  runtimeCompatible: boolean;
  buildCompatible: boolean;
}

export interface ConflictSummary {
  totalConflicts: number;
  blocking: number;
  warnings: number;
  byType: Record<DependencyConflictType, number>;
}

export interface ResolutionValidationCheck {
  name: string;
  status: "pass" | "fail" | "skipped";
  detail: string;
}

export interface DependencyResolutionRecord {
  readonly resolutionId: string;
  readonly packageId: string;
  readonly artifactId: string;
  readonly resolutionState: DependencyResolutionState;
  readonly approvalRequired: true;
  readonly executionBlocked: true;
  readonly installationBlocked: true;
  readonly resolvedDependencyGraph: ResolvedDependencyNode[];
  readonly installOrderingPlan: ResolutionOrderingStep[];
  readonly compatibilitySummary: CompatibilitySummary;
  readonly conflictSummary: ConflictSummary;
  readonly conflicts: ResolutionConflictRecord[];
  readonly validationChecks: ResolutionValidationCheck[];
  readonly resolvedCount: number;
  readonly conflictCount: number;
  readonly createdAt: string;
}

export interface CreateDependencyResolutionInput {
  packageRecord: VirtualPackageRecord;
}

export interface DependencyResolutionSummary {
  totalResolutions: number;
  byResolutionState: Record<DependencyResolutionState, number>;
  pendingApprovalCount: number;
  approvalRequired: true;
  executionBlocked: true;
  installationBlocked: true;
  implementationPhase: "skeleton";
}

// ---------------------------------------------------------------------------
// Floating-version guard — mirrors virtualPackageCore.isFixedVersion
// ---------------------------------------------------------------------------

const FORBIDDEN_VERSION_PATTERNS = [
  /^latest$/i,
  /^\*/,
  /^\^/,
  /^~/,
  /^>/,
  /^</,
  /^=/,
  /^x\./i,
];

function isFixedVersion(version: string): boolean {
  return !FORBIDDEN_VERSION_PATTERNS.some((re) => re.test(version.trim()));
}

// ---------------------------------------------------------------------------
// Conflict detection — 6 required types (Phase 227 blueprint)
// ---------------------------------------------------------------------------

function detectVersionConflicts(deps: VirtualDependency[]): ResolutionConflictRecord[] {
  const seen = new Map<string, string>();
  const conflicts: ResolutionConflictRecord[] = [];
  for (const dep of deps) {
    const existing = seen.get(dep.name);
    if (existing !== undefined && existing !== dep.version) {
      conflicts.push({
        conflictType: "version_conflict",
        affectedPackages: [dep.name],
        detail: `Package "${dep.name}" declared with conflicting versions: "${existing}" vs "${dep.version}"`,
        severity: "blocking",
      });
    } else {
      seen.set(dep.name, dep.version);
    }
  }
  return conflicts;
}

function detectDuplicateIdentities(deps: VirtualDependency[]): ResolutionConflictRecord[] {
  const seen = new Set<string>();
  const conflicts: ResolutionConflictRecord[] = [];
  for (const dep of deps) {
    const key = `${dep.name}@${dep.version}`;
    if (seen.has(key)) {
      conflicts.push({
        conflictType: "duplicate_identity",
        affectedPackages: [dep.name],
        detail: `Duplicate dependency identity detected: "${key}" — deduplication required`,
        severity: "warning",
      });
    } else {
      seen.add(key);
    }
  }
  return conflicts;
}

function detectCircularDependencies(deps: VirtualDependency[]): ResolutionConflictRecord[] {
  // In a virtual package, dependencies are a flat list with no sub-dependencies.
  // A circular dependency at this layer would require a dep referencing the
  // package itself by name. This check is structural: flag any dep whose name
  // matches the virtual package type prefix pattern.
  // Full graph-traversal cycle detection applies in future resolver phases.
  const selfReferential = deps.filter(
    (d) => d.name.includes("@") && d.name.startsWith("@") && d.category === "peerDependency" && d.name === d.name,
  );
  // Structural placeholder: no self-referential deps in Phase 228 virtual packages.
  void selfReferential;
  return [];
}

function detectRuntimeIncompatibility(
  deps: VirtualDependency[],
  runtimeVersion: string,
): ResolutionConflictRecord[] {
  const conflicts: ResolutionConflictRecord[] = [];
  const nodeDep = deps.find((d) => d.name === "node");
  if (nodeDep && nodeDep.version !== runtimeVersion) {
    conflicts.push({
      conflictType: "runtime_incompatibility",
      affectedPackages: ["node"],
      detail: `Node.js version mismatch: dependency declares "${nodeDep.version}" but runtime manifest specifies "${runtimeVersion}"`,
      severity: "blocking",
    });
  }
  return conflicts;
}

function detectProhibitedCategories(deps: VirtualDependency[]): ResolutionConflictRecord[] {
  const allowed = new Set(["runtime", "devDependency", "peerDependency"]);
  return deps
    .filter((d) => !allowed.has(d.category))
    .map((d) => ({
      conflictType: "prohibited_category" as DependencyConflictType,
      affectedPackages: [d.name],
      detail: `Dependency "${d.name}" has prohibited category "${d.category}" — only runtime, devDependency, peerDependency are permitted`,
      severity: "blocking" as const,
    }));
}

function detectIncompatibleBuildRuntimeTargets(
  buildTool: string,
  buildOutputFormat: string,
  nodeVersion: string,
): ResolutionConflictRecord[] {
  const conflicts: ResolutionConflictRecord[] = [];
  // Structural check: esbuild ESM output is compatible with Node.js 12+.
  // Future phases will add real version table lookups.
  if (buildTool === "esbuild" && buildOutputFormat === "esm") {
    const major = parseInt(nodeVersion.split(".")[0] ?? "0", 10);
    if (major < 12) {
      conflicts.push({
        conflictType: "incompatible_build_runtime_target",
        affectedPackages: ["esbuild"],
        detail: `Build target ESM (esbuild) requires Node.js ≥12, but runtime manifest declares "${nodeVersion}"`,
        severity: "blocking",
      });
    }
  }
  return conflicts;
}

function runAllConflictDetection(
  record: VirtualPackageRecord,
): ResolutionConflictRecord[] {
  return [
    ...detectVersionConflicts(record.dependencies),
    ...detectDuplicateIdentities(record.dependencies),
    ...detectCircularDependencies(record.dependencies),
    ...detectRuntimeIncompatibility(record.dependencies, record.runtimeManifest.nodeVersion),
    ...detectProhibitedCategories(record.dependencies),
    ...detectIncompatibleBuildRuntimeTargets(
      record.buildManifest.tool,
      record.buildManifest.outputFormat,
      record.runtimeManifest.nodeVersion,
    ),
  ];
}

// ---------------------------------------------------------------------------
// Resolved dependency graph — deterministic ordering (runtime first, then dev, then peer)
// ---------------------------------------------------------------------------

const CATEGORY_ORDER: Record<string, number> = {
  runtime: 0,
  devDependency: 1,
  peerDependency: 2,
};

function buildResolvedDependencyGraph(
  deps: VirtualDependency[],
  runtimeVersion: string,
): ResolvedDependencyNode[] {
  const resolvedAt = new Date().toISOString();
  const sorted = [...deps].sort((a, b) => {
    const ao = CATEGORY_ORDER[a.category] ?? 9;
    const bo = CATEGORY_ORDER[b.category] ?? 9;
    if (ao !== bo) return ao - bo;
    return a.name.localeCompare(b.name);
  });

  return sorted.map((dep) => {
    const floatingVersion = !isFixedVersion(dep.version);
    const isNodeDep = dep.name === "node";
    const versionMismatch = isNodeDep && dep.version !== runtimeVersion;
    let compatibilityStatus: "compatible" | "incompatible" | "unknown" = "compatible";
    let detail = `Resolved "${dep.name}@${dep.version}" (${dep.category}). Fixed version — deterministically resolved.`;

    if (floatingVersion) {
      compatibilityStatus = "incompatible";
      detail = `Rejected: "${dep.name}" version "${dep.version}" is a floating range — prohibited by resolution rules.`;
    } else if (versionMismatch) {
      compatibilityStatus = "incompatible";
      detail = `Runtime version mismatch: dependency "${dep.name}" declares "${dep.version}" but runtime manifest is "${runtimeVersion}".`;
    }

    return { name: dep.name, version: dep.version, category: dep.category, resolvedAt, compatibilityStatus, detail };
  });
}

// ---------------------------------------------------------------------------
// Install ordering plan — topological (no execution, descriptor only)
// ---------------------------------------------------------------------------

function buildInstallOrderingPlan(deps: VirtualDependency[]): ResolutionOrderingStep[] {
  const sorted = [...deps].sort((a, b) => {
    const ao = CATEGORY_ORDER[a.category] ?? 9;
    const bo = CATEGORY_ORDER[b.category] ?? 9;
    if (ao !== bo) return ao - bo;
    return a.name.localeCompare(b.name);
  });
  return sorted.map((dep, idx) => ({
    step: idx + 1,
    name: dep.name,
    version: dep.version,
    category: dep.category,
    descriptor: `Install step ${idx + 1}: "${dep.name}@${dep.version}" (${dep.category}). Text descriptor only — no execution permitted in this phase.`,
  }));
}

// ---------------------------------------------------------------------------
// Compatibility summary
// ---------------------------------------------------------------------------

function buildCompatibilitySummary(
  graph: ResolvedDependencyNode[],
  record: VirtualPackageRecord,
): CompatibilitySummary {
  const compatible   = graph.filter((n) => n.compatibilityStatus === "compatible").length;
  const incompatible = graph.filter((n) => n.compatibilityStatus === "incompatible").length;
  const unknown      = graph.filter((n) => n.compatibilityStatus === "unknown").length;
  const runtimeNodeVersion = record.runtimeManifest.nodeVersion;
  const major = parseInt(runtimeNodeVersion.split(".")[0] ?? "0", 10);
  return {
    totalChecked:        graph.length,
    compatible,
    incompatible,
    unknown,
    runtimeVersion:      runtimeNodeVersion,
    buildTool:           record.buildManifest.tool,
    buildOutputFormat:   record.buildManifest.outputFormat,
    runtimeCompatible:   incompatible === 0,
    buildCompatible:     major >= 12,
  };
}

// ---------------------------------------------------------------------------
// Conflict summary
// ---------------------------------------------------------------------------

function buildConflictSummary(conflicts: ResolutionConflictRecord[]): ConflictSummary {
  const byType: Record<DependencyConflictType, number> = {
    version_conflict:               0,
    circular_dependency:            0,
    runtime_incompatibility:        0,
    duplicate_identity:             0,
    prohibited_category:            0,
    incompatible_build_runtime_target: 0,
  };
  for (const c of conflicts) {
    byType[c.conflictType] = (byType[c.conflictType] ?? 0) + 1;
  }
  return {
    totalConflicts: conflicts.length,
    blocking:       conflicts.filter((c) => c.severity === "blocking").length,
    warnings:       conflicts.filter((c) => c.severity === "warning").length,
    byType,
  };
}

// ---------------------------------------------------------------------------
// Validation checks — 8 structural checks + 1 install skipped
// ---------------------------------------------------------------------------

function buildValidationChecks(
  deps: VirtualDependency[],
  graph: ResolvedDependencyNode[],
  conflicts: ResolutionConflictRecord[],
): ResolutionValidationCheck[] {
  const allFixed        = deps.every((d) => isFixedVersion(d.version));
  const noLatest        = deps.every((d) => !/latest/i.test(d.version));
  const hasGraph        = graph.length > 0;
  const hasOrdering     = deps.length > 0;
  const noFloating      = deps.every((d) => isFixedVersion(d.version));
  const noBlocking      = conflicts.filter((c) => c.severity === "blocking").length === 0;
  const allCompatible   = graph.every((n) => n.compatibilityStatus !== "incompatible");
  const noDynamic       = true; // structural: no dynamic injection in Phase 228 virtual packages

  return [
    {
      name: "resolved_graph_present",
      status: hasGraph ? "pass" : "fail",
      detail: hasGraph
        ? `${graph.length} resolved dependency nodes in graph`
        : "Resolved dependency graph is empty",
    },
    {
      name: "install_ordering_present",
      status: hasOrdering ? "pass" : "fail",
      detail: hasOrdering
        ? `${deps.length} install ordering steps generated`
        : "Install ordering plan is empty",
    },
    {
      name: "fixed_versions_only",
      status: allFixed ? "pass" : "fail",
      detail: allFixed
        ? "All dependency versions are fixed — no floating ranges detected"
        : "Floating version detected — latest/^/~/*/> are prohibited",
    },
    {
      name: "no_latest_tags",
      status: noLatest ? "pass" : "fail",
      detail: noLatest
        ? "No latest tags detected"
        : "latest tag detected — prohibited at resolution input boundary",
    },
    {
      name: "no_floating_ranges",
      status: noFloating ? "pass" : "fail",
      detail: noFloating
        ? "No floating ranges (^/~/*/>) detected"
        : "Floating range detected — prohibited",
    },
    {
      name: "no_blocking_conflicts",
      status: noBlocking ? "pass" : "fail",
      detail: noBlocking
        ? "No blocking conflicts detected"
        : `${conflicts.filter((c) => c.severity === "blocking").length} blocking conflict(s) detected`,
    },
    {
      name: "all_dependencies_compatible",
      status: allCompatible ? "pass" : "fail",
      detail: allCompatible
        ? "All resolved nodes are compatible"
        : "One or more resolved nodes are incompatible",
    },
    {
      name: "no_dynamic_injection",
      status: noDynamic ? "pass" : "fail",
      detail: "No dynamic dependency injection detected — structural check only in this phase",
    },
    {
      name: "install_execution",
      status: "skipped",
      detail: "Install execution check skipped — installationBlocked=true in this phase",
    },
  ];
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const store: DependencyResolutionRecord[] = [];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createDependencyResolutionRecord(
  input: CreateDependencyResolutionInput,
): DependencyResolutionRecord {
  const resolutionId = randomBytes(16).toString("hex");
  const createdAt    = new Date().toISOString();
  const { packageRecord } = input;

  const conflicts   = runAllConflictDetection(packageRecord);
  const graph       = buildResolvedDependencyGraph(packageRecord.dependencies, packageRecord.runtimeManifest.nodeVersion);
  const ordering    = buildInstallOrderingPlan(packageRecord.dependencies);
  const compat      = buildCompatibilitySummary(graph, packageRecord);
  const conflictSum = buildConflictSummary(conflicts);
  const checks      = buildValidationChecks(packageRecord.dependencies, graph, conflicts);

  const record: DependencyResolutionRecord = {
    resolutionId,
    packageId:              packageRecord.packageId,
    artifactId:             packageRecord.artifactId,
    resolutionState:        "structurally_resolved",
    approvalRequired:       true,
    executionBlocked:       true,
    installationBlocked:    true,
    resolvedDependencyGraph: graph,
    installOrderingPlan:    ordering,
    compatibilitySummary:   compat,
    conflictSummary:        conflictSum,
    conflicts,
    validationChecks:       checks,
    resolvedCount:          graph.length,
    conflictCount:          conflicts.length,
    createdAt,
  };

  store.push(record);
  return record;
}

export function listDependencyResolutionRecords(): DependencyResolutionRecord[] {
  return [...store].reverse();
}

export function getDependencyResolutionSummary(): DependencyResolutionSummary {
  const byResolutionState: Record<DependencyResolutionState, number> = {
    structurally_resolved: 0,
    conflict_detected:     0,
    pending:               0,
  };
  for (const r of store) {
    byResolutionState[r.resolutionState] =
      (byResolutionState[r.resolutionState] ?? 0) + 1;
  }
  return {
    totalResolutions:     store.length,
    byResolutionState,
    pendingApprovalCount: store.filter((r) => r.resolutionState === "pending").length,
    approvalRequired:     true,
    executionBlocked:     true,
    installationBlocked:  true,
    implementationPhase:  "skeleton",
  };
}
