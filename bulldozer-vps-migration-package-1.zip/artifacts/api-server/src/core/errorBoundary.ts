import type { IncomingMessage, ServerResponse } from "node:http";
import { logger } from "../lib/logger";
import { sendError } from "../lib/response";
import type { Handler } from "./router";
import "../lib/requestContext";
import { incrementErrors } from "./metrics";
import { addTimelineEvent } from "./timeline";

export function withErrorBoundary(handler: Handler): Handler {
  return (req: IncomingMessage, res: ServerResponse): void => {
    const base = req.requestId != null ? { requestId: req.requestId } : {};

    try {
      const result = handler(req, res);
      if (result instanceof Promise) {
        result.catch((err: unknown) => {
          incrementErrors();
          addTimelineEvent({ level: "error", source: "error-boundary", message: "Async route error", requestId: req.requestId ?? undefined, metadata: { err: String(err) } });
          logger.error({ ...base, err: String(err) }, "Async route error");
          sendError(res, 500, "Internal Server Error");
        });
      }
    } catch (err) {
      incrementErrors();
      addTimelineEvent({ level: "error", source: "error-boundary", message: "Sync route error", requestId: req.requestId ?? undefined, metadata: { err: String(err) } });
      logger.error({ ...base, err: String(err) }, "Sync route error");
      sendError(res, 500, "Internal Server Error");
    }
  };
}
