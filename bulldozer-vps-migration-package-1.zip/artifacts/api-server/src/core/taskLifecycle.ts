import { logger } from "../lib/logger";
import { emit, subscribe } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { getTask, listTasks } from "./taskQueue";
import { peekTaskPolicy } from "./taskPolicy";
import type { Task } from "./taskQueue";

export type LifecycleState = "queued" | "ready" | "waiting_approval" | "blocked" | "archived";

export interface TaskLifecycleRecord {
  taskId: string;
  taskType: string;
  currentState: LifecycleState;
  previousState: LifecycleState | null;
  lastTransitionAt: string;
  reason: string | null;
}

export interface LifecycleRule {
  from: LifecycleState;
  allowedTargets: LifecycleState[];
  description: string;
}

export interface TaskLifecycleStatus {
  operational: boolean;
  executionBlocked: true;
  totalTransitions: number;
  allowedTransitions: number;
  rejectedTransitions: number;
  lastTransitionAt: string | null;
  lastRejectedReason: string | null;
  trackedTaskCount: number;
}

export interface TransitionResult {
  success: boolean;
  taskId: string;
  previousState: LifecycleState | null;
  currentState: LifecycleState | null;
  reason: string | null;
  error: string | null;
  executionBlocked: true;
}

const EXECUTION_BLOCKED: true = true;

const LIFECYCLE_RULES: LifecycleRule[] = [
  {
    from: "queued",
    allowedTargets: ["ready", "waiting_approval", "blocked", "archived"],
    description: "Queued tasks can be promoted to ready, held for approval, blocked by policy, or archived",
  },
  {
    from: "ready",
    allowedTargets: ["waiting_approval", "blocked", "archived"],
    description: "Ready tasks can be held for approval, blocked by policy, or archived",
  },
  {
    from: "waiting_approval",
    allowedTargets: ["ready", "blocked", "archived"],
    description: "Tasks waiting approval can be approved to ready, blocked by policy, or archived",
  },
  {
    from: "blocked",
    allowedTargets: ["archived"],
    description: "Blocked tasks can only be archived — no other transitions permitted",
  },
  {
    from: "archived",
    allowedTargets: [],
    description: "Archived is a terminal state — no further transitions are permitted",
  },
];

const ALLOWED_TARGETS: ReadonlyMap<LifecycleState, ReadonlySet<LifecycleState>> = new Map([
  ["queued",           new Set<LifecycleState>(["ready", "waiting_approval", "blocked", "archived"])],
  ["ready",            new Set<LifecycleState>(["waiting_approval", "blocked", "archived"])],
  ["waiting_approval", new Set<LifecycleState>(["ready", "blocked", "archived"])],
  ["blocked",          new Set<LifecycleState>(["archived"])],
  ["archived",         new Set<LifecycleState>()],
]);

const lifecycleStates = new Map<string, TaskLifecycleRecord>();

let isOperational = false;
let totalTransitions = 0;
let allowedTransitions = 0;
let rejectedTransitions = 0;
let lastTransitionAt: string | null = null;
let lastRejectedReason: string | null = null;

export function evaluateTaskLifecycle(task: Task): LifecycleState {
  if (task.status === "blocked") return "blocked";

  const peek = peekTaskPolicy(task);
  switch (peek.decision) {
    case "allow":            return "ready";
    case "approval_required": return "waiting_approval";
    case "warn":             return "queued";
    case "block":            return "blocked";
  }
}

function createLifecycleRecord(task: Task): TaskLifecycleRecord {
  const initialState = evaluateTaskLifecycle(task);
  const record: TaskLifecycleRecord = {
    taskId: task.id,
    taskType: task.type,
    currentState: initialState,
    previousState: null,
    lastTransitionAt: new Date().toISOString(),
    reason: "initial evaluation",
  };
  lifecycleStates.set(task.id, record);
  return record;
}

export function transitionTaskState(
  taskId: string,
  targetState: LifecycleState,
  reason?: string,
): TransitionResult {
  const record = lifecycleStates.get(taskId);

  if (!record) {
    rejectedTransitions++;
    totalTransitions++;
    const error = `No lifecycle record found for task ${taskId}`;
    lastRejectedReason = error;
    emit("task_lifecycle:transition_rejected", "task-lifecycle", { taskId, targetState, error });
    logger.warn({ taskId, targetState }, error);
    return {
      success: false,
      taskId,
      previousState: null,
      currentState: null,
      reason: reason ?? null,
      error,
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const currentState = record.currentState;
  const allowed = ALLOWED_TARGETS.get(currentState);

  if (!allowed || !allowed.has(targetState)) {
    rejectedTransitions++;
    totalTransitions++;
    const error = `Transition from "${currentState}" to "${targetState}" is not permitted`;
    lastRejectedReason = error;
    emit("task_lifecycle:transition_rejected", "task-lifecycle", {
      taskId,
      from: currentState,
      to: targetState,
      error,
    });
    logger.warn({ taskId, currentState, targetState, taskType: record.taskType }, error);
    return {
      success: false,
      taskId,
      previousState: currentState,
      currentState,
      reason: reason ?? null,
      error,
      executionBlocked: EXECUTION_BLOCKED,
    };
  }

  const now = new Date().toISOString();
  const previousState = currentState;
  record.previousState = previousState;
  record.currentState = targetState;
  record.lastTransitionAt = now;
  record.reason = reason ?? null;

  totalTransitions++;
  allowedTransitions++;
  lastTransitionAt = now;

  emit("task_lifecycle:transitioned", "task-lifecycle", {
    taskId,
    taskType: record.taskType,
    from: previousState,
    to: targetState,
    reason: reason ?? null,
  });

  if (targetState === "archived") {
    addTimelineEvent({
      level: "info",
      source: "task-lifecycle",
      message: `Task archived: ${record.taskType}`,
      metadata: { taskId, from: previousState, reason: reason ?? null },
    });
  }

  logger.info(
    { taskId, taskType: record.taskType, from: previousState, to: targetState, executionBlocked: EXECUTION_BLOCKED },
    "Task lifecycle transition",
  );

  return {
    success: true,
    taskId,
    previousState,
    currentState: targetState,
    reason: reason ?? null,
    error: null,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

export function getTaskLifecycleStatus(): TaskLifecycleStatus & { timestamp: string } {
  return {
    operational: isOperational,
    executionBlocked: EXECUTION_BLOCKED,
    totalTransitions,
    allowedTransitions,
    rejectedTransitions,
    lastTransitionAt,
    lastRejectedReason,
    trackedTaskCount: lifecycleStates.size,
    timestamp: new Date().toISOString(),
  };
}

export function listLifecycleRules(): LifecycleRule[] {
  return [...LIFECYCLE_RULES];
}

export function listTaskLifecycles(): TaskLifecycleRecord[] {
  return Array.from(lifecycleStates.values());
}

export function getTaskLifecycleRecord(taskId: string): TaskLifecycleRecord | undefined {
  return lifecycleStates.get(taskId);
}

export function initTaskLifecycle(): void {
  for (const task of listTasks()) {
    if (!lifecycleStates.has(task.id)) {
      createLifecycleRecord(task);
    }
  }

  subscribe("task_queue:task_created", (event) => {
    const id = event.payload["id"] as string;
    const task = id ? getTask(id) : undefined;
    if (task && !lifecycleStates.has(task.id)) {
      createLifecycleRecord(task);
    }
  });

  subscribe("task_queue:task_blocked", (event) => {
    const id = event.payload["id"] as string;
    const record = id ? lifecycleStates.get(id) : undefined;
    if (record && record.currentState !== "blocked" && record.currentState !== "archived") {
      transitionTaskState(id, "blocked", "blocked by policy");
    }
  });

  isOperational = true;

  emit("task_lifecycle:initialized", "task-lifecycle", {
    trackedTaskCount: lifecycleStates.size,
    executionBlocked: EXECUTION_BLOCKED,
  });

  addTimelineEvent({
    level: "info",
    source: "task-lifecycle",
    message: `Task lifecycle state machine initialized — ${lifecycleStates.size} task(s) tracked`,
    metadata: { ruleCount: LIFECYCLE_RULES.length },
  });

  logger.info(
    { trackedTaskCount: lifecycleStates.size, ruleCount: LIFECYCLE_RULES.length, executionBlocked: EXECUTION_BLOCKED },
    "Task lifecycle state machine initialized",
  );
}
