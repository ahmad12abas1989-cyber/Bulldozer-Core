import { SandboxFilesystemRecord, SandboxWritablePath, SandboxProtectedPath } from "./sandboxFilesystemCore.js";
import { WriteGuardRecord }                                                      from "./controlledWriteGuardCore.js";
import { WriteGateRecord }                                                        from "./realWriteEnablementGateCore.js";
import { ControlledExecutionRecord }                                              from "./controlledExecutionCore.js";
import { randomBytes }                                                            from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type WritePlanState = "descriptor_write_plan_ready";

export type WritePlanValidationRule =
  | "filesystem_record_exists"
  | "write_guard_exists"
  | "write_gate_exists"
  | "execution_record_exists"
  | "real_writes_disabled"
  | "all_writes_target_allowed_zones"
  | "protected_zones_blocked"
  | "rollback_plan_ready"
  | "output_remains_descriptor_only";

export interface PlannedWrite {
  readonly planEntryIndex:    number;
  readonly targetPath:        SandboxWritablePath;
  readonly operationType:     "create" | "overwrite" | "append";
  readonly contentDescriptor: string;
  readonly realWriteEnabled:  false;
  readonly writeBlocked:      true;
  readonly reason:            string;
}

export interface BlockedWrite {
  readonly targetPath:   SandboxProtectedPath;
  readonly writeBlocked: true;
  readonly reason:       string;
}

export interface WritePlanValidationCheck {
  readonly rule:   WritePlanValidationRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface RollbackWritePlan {
  readonly rollbackRequired:        true;
  readonly rollbackDescriptorOnly:  true;
  readonly rollbackPlannedCount:    number;
  readonly rollbackTargetState:     "descriptor_write_plan_ready";
  readonly rollbackSequenceReady:   boolean;
  readonly summary:                 string;
}

export interface WritePlanRecord {
  readonly writePlanId:                string;
  readonly writePlanState:             WritePlanState;
  readonly approvalRequired:           true;
  readonly realWritesEnabled:          false;
  readonly motherCoreWritesBlocked:    true;
  readonly protectedZoneWritesBlocked: true;
  readonly rollbackRequired:           true;
  readonly implementationPhase:        "descriptor_only";
  readonly filesystemRecordId:         string;
  readonly writeGuardId:               string;
  readonly writeGateId:                string;
  readonly executionRecordId:          string;
  readonly approvalReference:          string;
  readonly plannedWrites:              readonly PlannedWrite[];
  readonly blockedWrites:              readonly BlockedWrite[];
  readonly writePlanValidationChecks:  readonly WritePlanValidationCheck[];
  readonly rollbackWritePlan:          RollbackWritePlan;
  readonly createdAt:                  string;
}

export interface CreateWritePlanInput {
  readonly filesystemRecord:  SandboxFilesystemRecord;
  readonly writeGuardRecord:  WriteGuardRecord;
  readonly writeGateRecord:   WriteGateRecord;
  readonly executionRecord:   ControlledExecutionRecord;
}

export interface WritePlanSummary {
  readonly total:                      number;
  readonly byState:                    Record<WritePlanState, number>;
  readonly realWritesEnabled:          false;
  readonly motherCoreWritesBlocked:    true;
  readonly protectedZoneWritesBlocked: true;
  readonly rollbackRequired:           true;
  readonly approvalRequired:           true;
  readonly plannedZonePaths:           readonly SandboxWritablePath[];
  readonly blockedZonePaths:           readonly SandboxProtectedPath[];
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildPlannedWrites(
  filesystemRecord: SandboxFilesystemRecord,
): readonly PlannedWrite[] {
  const operationTypes: Array<"create" | "overwrite" | "append"> = [
    "create",
    "overwrite",
    "append",
  ];
  return filesystemRecord.writableZones.map((z, idx) => ({
    planEntryIndex:    idx,
    targetPath:        z.path,
    operationType:     operationTypes[idx % operationTypes.length],
    contentDescriptor: `Descriptor-only planned write to ${z.path} — ${z.purpose}`,
    realWriteEnabled:  false,
    writeBlocked:      true,
    reason:            "Descriptor-only phase — planned write recorded but not executed; real activation requires operator approval + future execution phase",
  }));
}

function buildBlockedWrites(
  filesystemRecord: SandboxFilesystemRecord,
): readonly BlockedWrite[] {
  return filesystemRecord.protectedZones.map(z => ({
    targetPath:   z.path,
    writeBlocked: true,
    reason:       `Protected zone — write permanently blocked at all phases (${z.reason})`,
  }));
}

function buildValidationChecks(
  input: CreateWritePlanInput,
): readonly WritePlanValidationCheck[] {
  const { filesystemRecord, writeGuardRecord, writeGateRecord, executionRecord } = input;
  const rollbackReady =
    filesystemRecord.rollbackFilesystemPlan.rollbackReady &&
    writeGuardRecord.rollbackReadiness.rollbackReady &&
    writeGateRecord.writeReadinessReport.rollbackReady;
  const allTargetAllowed = filesystemRecord.writableZones.every(
    z => z.path.startsWith("/sandbox/"),
  );
  const allProtectedBlocked = filesystemRecord.protectedZones.every(
    z => z.sandboxAccess === false,
  );

  return [
    {
      rule:   "filesystem_record_exists",
      passed: filesystemRecord.sandboxFilesystemId.length > 0,
      detail: "Sandbox filesystem record is present and valid",
    },
    {
      rule:   "write_guard_exists",
      passed: writeGuardRecord.writeGuardId.length > 0,
      detail: "Write guard record is present and valid",
    },
    {
      rule:   "write_gate_exists",
      passed: writeGateRecord.writeGateId.length > 0,
      detail: "Write enablement gate record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "real_writes_disabled",
      passed: true,
      detail: "realWritesEnabled=false confirmed — no real filesystem mutation occurs at this phase",
    },
    {
      rule:   "all_writes_target_allowed_zones",
      passed: allTargetAllowed,
      detail: "All planned write targets are scoped under /sandbox/ — no host filesystem escape",
    },
    {
      rule:   "protected_zones_blocked",
      passed: allProtectedBlocked,
      detail: `All ${filesystemRecord.protectedZones.length} protected zones confirmed sandboxAccess=false`,
    },
    {
      rule:   "rollback_plan_ready",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback readiness confirmed across filesystem record, write guard, and write gate"
        : "Rollback not yet ready in one or more upstream records — write plan blocked",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: true,
      detail: "Write plan output is descriptor-only — no real filesystem mutation",
    },
  ] as const;
}

function buildRollbackWritePlan(
  checks: readonly WritePlanValidationCheck[],
  plannedWrites: readonly PlannedWrite[],
): RollbackWritePlan {
  const rollbackSequenceReady = checks.every(c => c.passed);
  return {
    rollbackRequired:       true,
    rollbackDescriptorOnly: true,
    rollbackPlannedCount:   plannedWrites.length,
    rollbackTargetState:    "descriptor_write_plan_ready",
    rollbackSequenceReady,
    summary: rollbackSequenceReady
      ? "Rollback write plan ready — all planned writes are descriptor-only and can be safely discarded without any real filesystem side-effects"
      : "Rollback write plan incomplete — one or more validation checks failed; planned writes must not proceed",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const writePlanStore = new Map<string, WritePlanRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createWritePlanRecord(
  input: CreateWritePlanInput,
): { ok: true; record: WritePlanRecord } {
  const writePlanId    = randomBytes(16).toString("hex");
  const plannedWrites  = buildPlannedWrites(input.filesystemRecord);
  const blockedWrites  = buildBlockedWrites(input.filesystemRecord);
  const checks         = buildValidationChecks(input);
  const rollbackPlan   = buildRollbackWritePlan(checks, plannedWrites);

  const record: WritePlanRecord = {
    writePlanId,
    writePlanState:              "descriptor_write_plan_ready",
    approvalRequired:            true,
    realWritesEnabled:           false,
    motherCoreWritesBlocked:     true,
    protectedZoneWritesBlocked:  true,
    rollbackRequired:            true,
    implementationPhase:         "descriptor_only",
    filesystemRecordId:          input.filesystemRecord.sandboxFilesystemId,
    writeGuardId:                input.writeGuardRecord.writeGuardId,
    writeGateId:                 input.writeGateRecord.writeGateId,
    executionRecordId:           input.executionRecord.controlledExecutionId,
    approvalReference:           input.filesystemRecord.approvalReference,
    plannedWrites,
    blockedWrites,
    writePlanValidationChecks:   checks,
    rollbackWritePlan:           rollbackPlan,
    createdAt:                   new Date().toISOString(),
  };

  writePlanStore.set(writePlanId, record);
  return { ok: true, record };
}

export function listWritePlanRecords(): readonly WritePlanRecord[] {
  return [...writePlanStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getWritePlanSummary(): WritePlanSummary {
  const records = listWritePlanRecords();
  const plannedPaths: SandboxWritablePath[] = [
    "/sandbox/workspace",
    "/sandbox/tmp",
    "/sandbox/build-cache",
  ];
  const blockedPaths: SandboxProtectedPath[] = [
    "/mother-core",
    "/vault",
    "/runtime-config",
    "/system",
    "/network-secrets",
  ];
  return {
    total:                      records.length,
    byState:                    { descriptor_write_plan_ready: records.length },
    realWritesEnabled:          false,
    motherCoreWritesBlocked:    true,
    protectedZoneWritesBlocked: true,
    rollbackRequired:           true,
    approvalRequired:           true,
    plannedZonePaths:           plannedPaths,
    blockedZonePaths:           blockedPaths,
  };
}
