import type { IncomingMessage } from "node:http";
import { logger } from "../lib/logger";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";

export type HardeningStatus = "clean" | "warning" | "hardened";

export interface HardeningState {
  status: HardeningStatus;
  totalViolations: number;
  blockedCount: number;
  warningCount: number;
  lastViolationAt: string | null;
  lastViolationType: string | null;
  lastViolationPath: string | null;
  activeHeaderCount: number;
  securityHeaders: Record<string, string>;
  requireHttpsConfigured: boolean;
  httpsHeaderName: string;
  hstsHeaderPresent: boolean;
  trustedProxiesConfigured: boolean;
  realIpHeader: string;
  forwardedForHeader: string;
}

export type HardeningCheckResult =
  | { blocked: false; warned: false }
  | { blocked: false; warned: true; type: string; reason: string }
  | { blocked: true; warned: false; type: string; reason: string; httpStatus: number };

const MAX_URL_LENGTH = 512;

const SECURITY_HEADERS: Record<string, string> = {
  "content-security-policy": "default-src 'none'",
  "cross-origin-opener-policy": "same-origin",
  "cross-origin-resource-policy": "same-origin",
  "permissions-policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()",
  "referrer-policy": "no-referrer",
  "strict-transport-security": "max-age=63072000; includeSubDomains",
  "x-content-type-options": "nosniff",
  "x-frame-options": "DENY",
  "x-permitted-cross-domain-policies": "none",
  "x-xss-protection": "0",
};

function parseAllowedHosts(): Set<string> {
  const raw = process.env["BULLDOZER_ALLOWED_HOSTS"];
  if (!raw || raw.trim() === "") return new Set();
  return new Set(
    raw
      .split(",")
      .map((h) => h.trim().toLowerCase())
      .filter((h) => h.length > 0),
  );
}

const ALLOWED_HOSTS: Set<string> = parseAllowedHosts();
const REQUIRE_HTTPS: boolean = process.env["BULLDOZER_REQUIRE_HTTPS"] === "true";
const HTTPS_HEADER = "x-forwarded-proto" as const;

function parseTrustedProxies(): Set<string> {
  const raw = process.env["BULLDOZER_TRUSTED_PROXIES"];
  if (!raw || raw.trim() === "") return new Set();
  return new Set(
    raw
      .split(",")
      .map((p) => p.trim().toLowerCase())
      .filter((p) => p.length > 0),
  );
}

const TRUSTED_PROXIES: Set<string> = parseTrustedProxies();
const MAX_XFF_LENGTH = 512;
const XFF_HEADER = "x-forwarded-for" as const;
const REAL_IP_HEADER = "x-real-ip" as const;

function normalizeRemoteAddress(addr: string): string {
  const lower = addr.toLowerCase().trim();
  if (lower.startsWith("::ffff:")) {
    const v4part = lower.slice(7);
    if (/^\d+\.\d+\.\d+\.\d+$/.test(v4part)) {
      return v4part;
    }
  }
  return lower;
}

let totalViolations = 0;
let blockedCount = 0;
let warningCount = 0;
let lastViolationAt: string | null = null;
let lastViolationType: string | null = null;
let lastViolationPath: string | null = null;

export function applySecurityHeaders(res: import("node:http").ServerResponse): void {
  for (const [name, value] of Object.entries(SECURITY_HEADERS)) {
    res.setHeader(name, value);
  }
}

export function recordHardeningViolation(
  type: string,
  path: string,
  reason: string,
  blocked: boolean,
): void {
  totalViolations++;
  const now = new Date().toISOString();
  lastViolationAt = now;
  lastViolationType = type;
  lastViolationPath = path;

  if (blocked) {
    blockedCount++;
  } else {
    warningCount++;
  }

  emit("hardening:violation", "hardening", { type, path, reason, blocked });
  logger.warn({ type, path, reason, blocked }, "Hardening violation recorded");

  if (totalViolations === 1) {
    addTimelineEvent({
      level: "warn",
      source: "hardening",
      message: `First hardening violation recorded: ${type}`,
      metadata: { type, path, reason, blocked },
    });
  }
}

export function validateRequestHardening(req: IncomingMessage): HardeningCheckResult {
  const rawUrl = req.url ?? "";

  if (rawUrl.length > MAX_URL_LENGTH) {
    return {
      blocked: true,
      warned: false,
      type: "url_too_long",
      reason: `URL length ${rawUrl.length} exceeds maximum ${MAX_URL_LENGTH}`,
      httpStatus: 414,
    };
  }

  if (rawUrl.includes("../") || rawUrl.includes("..\\") || rawUrl.includes("%2e%2e") || rawUrl.includes("%2E%2E")) {
    return {
      blocked: true,
      warned: false,
      type: "path_traversal",
      reason: "Path traversal sequence detected in raw URL",
      httpStatus: 400,
    };
  }

  const rawPath = rawUrl.split("?")[0];

  for (let i = 0; i < rawPath.length; i++) {
    const code = rawPath.charCodeAt(i);
    if (code < 0x20 && code !== 0x09) {
      return {
        blocked: true,
        warned: false,
        type: "control_chars",
        reason: "Control character detected in path",
        httpStatus: 400,
      };
    }
  }

  if (rawPath.includes("//")) {
    return {
      blocked: false,
      warned: true,
      type: "double_slash",
      reason: "Double slash detected in path",
    };
  }

  const host = req.headers["host"];

  if (!host || host.trim() === "") {
    return {
      blocked: true,
      warned: false,
      type: "missing_host",
      reason: "Request is missing the Host header",
      httpStatus: 400,
    };
  }

  for (let i = 0; i < host.length; i++) {
    const code = host.charCodeAt(i);
    if (code < 0x20 || code === 0x7f) {
      return {
        blocked: true,
        warned: false,
        type: "invalid_host",
        reason: "Control character detected in Host header",
        httpStatus: 400,
      };
    }
  }

  if (ALLOWED_HOSTS.size > 0) {
    const normalizedHost = host.toLowerCase().trim();
    if (!ALLOWED_HOSTS.has(normalizedHost)) {
      return {
        blocked: true,
        warned: false,
        type: "host_not_allowed",
        reason: `Host is not in the allowed hosts list`,
        httpStatus: 400,
      };
    }
  }

  return { blocked: false, warned: false };
}

export function validateHttpsTransport(req: IncomingMessage): HardeningCheckResult {
  if (!REQUIRE_HTTPS) return { blocked: false, warned: false };

  const rawProto = req.headers[HTTPS_HEADER];
  const proto = typeof rawProto === "string" ? rawProto.toLowerCase().trim() : null;

  if (proto === null || proto === "") {
    return {
      blocked: true,
      warned: false,
      type: "missing_forwarded_proto",
      reason: `${HTTPS_HEADER} header is required when HTTPS enforcement is enabled`,
      httpStatus: 400,
    };
  }

  if (proto !== "https") {
    return {
      blocked: true,
      warned: false,
      type: "insecure_forwarded_proto",
      reason: "Request was not forwarded over HTTPS",
      httpStatus: 400,
    };
  }

  return { blocked: false, warned: false };
}

export function validateForwardedFor(req: IncomingMessage): HardeningCheckResult {
  const rawXff = req.headers[XFF_HEADER];

  if (typeof rawXff === "string") {
    if (rawXff.length > MAX_XFF_LENGTH) {
      return {
        blocked: true,
        warned: false,
        type: "xff_too_long",
        reason: `x-forwarded-for header length ${rawXff.length} exceeds maximum ${MAX_XFF_LENGTH}`,
        httpStatus: 400,
      };
    }

    for (let i = 0; i < rawXff.length; i++) {
      const code = rawXff.charCodeAt(i);
      if (code < 0x20 || code === 0x7f) {
        return {
          blocked: true,
          warned: false,
          type: "invalid_forwarded_for",
          reason: "Control character detected in x-forwarded-for header",
          httpStatus: 400,
        };
      }
    }

    const segments = rawXff.split(",");
    for (const seg of segments) {
      if (seg.trim() === "") {
        return {
          blocked: true,
          warned: false,
          type: "malformed_forwarded_for",
          reason: "Malformed x-forwarded-for header: empty IP segment",
          httpStatus: 400,
        };
      }
    }
  }

  if (TRUSTED_PROXIES.size > 0) {
    const rawAddr = req.socket?.remoteAddress;
    if (rawAddr !== undefined && rawAddr !== "") {
      const normalized = normalizeRemoteAddress(rawAddr);
      if (!TRUSTED_PROXIES.has(normalized)) {
        return {
          blocked: true,
          warned: false,
          type: "untrusted_proxy",
          reason: "Request did not arrive from a trusted proxy",
          httpStatus: 400,
        };
      }
    }
  }

  return { blocked: false, warned: false };
}

export function resolveClientIp(req: IncomingMessage): string | undefined {
  if (TRUSTED_PROXIES.size === 0) return undefined;
  const rawXff = req.headers[XFF_HEADER];
  if (typeof rawXff !== "string") return undefined;
  const first = rawXff.split(",")[0];
  if (!first) return undefined;
  const trimmed = first.trim();
  return trimmed.length > 0 ? trimmed : undefined;
}

export function getSecurityHeaderLines(): string[] {
  return Object.entries(SECURITY_HEADERS).map(([k, v]) => `${k}: ${v}`);
}

export function getHardeningStatus(): HardeningState & { timestamp: string } {
  let status: HardeningStatus;
  if (blockedCount > 0) {
    status = "hardened";
  } else if (warningCount > 0) {
    status = "warning";
  } else {
    status = "clean";
  }

  return {
    status,
    totalViolations,
    blockedCount,
    warningCount,
    lastViolationAt,
    lastViolationType,
    lastViolationPath,
    activeHeaderCount: Object.keys(SECURITY_HEADERS).length,
    securityHeaders: { ...SECURITY_HEADERS },
    requireHttpsConfigured: REQUIRE_HTTPS,
    httpsHeaderName: HTTPS_HEADER,
    hstsHeaderPresent: "strict-transport-security" in SECURITY_HEADERS,
    trustedProxiesConfigured: TRUSTED_PROXIES.size > 0,
    realIpHeader: REAL_IP_HEADER,
    forwardedForHeader: XFF_HEADER,
    timestamp: new Date().toISOString(),
  };
}
