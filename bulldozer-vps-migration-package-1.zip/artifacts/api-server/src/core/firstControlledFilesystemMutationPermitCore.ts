// firstControlledFilesystemMutationPermitCore.ts
// Phase 342 — First Controlled Filesystem Mutation Permit Descriptor Core Skeleton
// In-memory first controlled filesystem mutation permit descriptor engine.
// Layer 35 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply + mutation-surface +
//   filesystem-mutation-enablement + filesystem-mutation-gate stack.
// Defines the first controlled filesystem mutation permit descriptor.
// Binds permit to filesystem mutation gate and to enablement/surface/apply/commit chain.
// Preserves sandbox-approved-only target scope from layers 24–34 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No unrestricted filesystem mutation. No shell execution. No network access.
// No vault access. No Mother Core mutation.
// filesystemMutationPermitEnabled=false — permit has not been activated.
// filesystemMutationPermitPrepared=true — descriptor-readiness established for a future
//   first controlled filesystem mutation permit activation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstControlledFilesystemMutationGateRecord }       from "./firstControlledFilesystemMutationGateCore.js";
import type { ControlledFilesystemMutationEnablementRecord }      from "./controlledFilesystemMutationEnablementCore.js";
import type { FirstActualSandboxMutationSurfaceRecord }           from "./firstActualSandboxMutationSurfaceCore.js";
import type { FirstActualSandboxMutationApplyRecord }             from "./firstActualSandboxMutationApplyCore.js";
import type { FirstActualSandboxMutationCommitRecord }            from "./firstActualSandboxMutationCommitCore.js";
import type { ControlledExecutionRecord }                         from "./controlledExecutionCore.js";
import { randomUUID }                                             from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type FilesystemMutationPermitState =
  "descriptor_filesystem_mutation_permit_pending";

export type FilesystemMutationPermitCheckRule =
  | "filesystem_mutation_gate_exists"
  | "filesystem_mutation_enablement_exists"
  | "mutation_surface_exists"
  | "mutation_apply_exists"
  | "mutation_commit_exists"
  | "execution_record_exists"
  | "filesystem_mutation_gate_bound_to_enablement"
  | "filesystem_mutation_enablement_bound_to_surface"
  | "mutation_surface_bound_to_apply"
  | "mutation_apply_bound_to_commit"
  | "filesystem_mutation_permit_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface FilesystemMutationPermitCheck {
  readonly rule: FilesystemMutationPermitCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface FilesystemMutationPermitBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface FilesystemMutationPermitPlanEntry {
  readonly entryId:                          string;
  readonly operationType:                    "descriptor_filesystem_mutation_permit_planned";
  readonly targetScope:                      "sandbox_approved_only";
  readonly filesystemMutationPermitEnabled:  false;
  readonly mutationBlocked:                  true;
  readonly note:                             string;
}

export interface LinkedFilesystemMutationPermitReference {
  readonly filesystemMutationGateId:         string;
  readonly filesystemMutationEnablementId:   string;
  readonly mutationSurfaceId:                string;
  readonly mutationApplyId:                  string;
  readonly rollbackSnapshotId:               string;
  readonly filesystemMutationPermitPrepared:       true;
  readonly filesystemMutationPermitEnabled:        false;
  readonly filesystemMutationGateEnabled:          false;
  readonly filesystemMutationEnablementEnabled:    false;
  readonly mutationSurfaceEnabled:                 false;
  readonly actualWritesEnabled:                    false;
  readonly rollbackChainValid:                     boolean;
  readonly referenceNote:                          string;
}

export interface FilesystemMutationPermitReadinessReport {
  readonly filesystemMutationPermitPrepared:       true;
  readonly filesystemMutationPermitEnabled:        false;
  readonly filesystemMutationGateEnabled:          false;
  readonly filesystemMutationEnablementEnabled:    false;
  readonly mutationSurfaceEnabled:                 false;
  readonly mutationApplyEnabled:                   false;
  readonly mutationCommitEnabled:                  false;
  readonly mutationExecutorEnabled:                false;
  readonly commitExecutionGateEnabled:             false;
  readonly sandboxWriteCommitEnabled:              false;
  readonly runtimeWriteExecutorEnabled:            false;
  readonly writeExecutionGateEnabled:              false;
  readonly scopedActivationEnabled:                false;
  readonly writePermissionEnabled:                 false;
  readonly mutationSwitchEnabled:                  false;
  readonly guardedWriteEnabled:                    false;
  readonly actualWritesEnabled:                    false;
  readonly realWritesEnabled:                      false;
  readonly approvalRequired:                       true;
  readonly allChecksPass:                          boolean;
  readonly blockedReasonCount:                     number;
  readonly rollbackChainValid:                     boolean;
  readonly targetScope:                            "sandbox_approved_only";
  readonly summary:                                string;
}

export interface FirstControlledFilesystemMutationPermitRecord {
  readonly filesystemMutationPermitId:             string;
  readonly filesystemMutationPermitState:          FilesystemMutationPermitState;
  readonly approvalRequired:                       true;
  readonly filesystemMutationPermitPrepared:       true;
  readonly filesystemMutationPermitEnabled:        false;
  readonly filesystemMutationGateEnabled:          false;
  readonly filesystemMutationEnablementEnabled:    false;
  readonly mutationSurfaceEnabled:                 false;
  readonly mutationApplyEnabled:                   false;
  readonly mutationCommitEnabled:                  false;
  readonly actualWritesEnabled:                    false;
  readonly filesystemMutationBlocked:              true;
  readonly motherCoreMutationBlocked:              true;
  readonly vaultMutationBlocked:                   true;
  readonly shellBlocked:                           true;
  readonly networkBlocked:                         true;
  readonly targetScope:                            "sandbox_approved_only";
  readonly implementationPhase:                    "descriptor_only";
  readonly filesystemMutationGateId:               string;
  readonly filesystemMutationEnablementId:         string;
  readonly mutationSurfaceId:                      string;
  readonly mutationApplyId:                        string;
  readonly mutationCommitId:                       string;
  readonly controlledExecutionId:                  string;
  readonly filesystemMutationPermitPlan:           readonly FilesystemMutationPermitPlanEntry[];
  readonly filesystemMutationPermitChecks:         readonly FilesystemMutationPermitCheck[];
  readonly filesystemMutationPermitBlockedReasons: readonly FilesystemMutationPermitBlockedReason[];
  readonly filesystemMutationPermitReadinessReport: FilesystemMutationPermitReadinessReport;
  readonly linkedFilesystemMutationPermitReference: LinkedFilesystemMutationPermitReference;
  readonly createdAt:                              string;
}

export interface CreateFirstControlledFilesystemMutationPermitInput {
  readonly gateRecord:          FirstControlledFilesystemMutationGateRecord;
  readonly enablementRecord:    ControlledFilesystemMutationEnablementRecord;
  readonly mutationSurfaceRecord: FirstActualSandboxMutationSurfaceRecord;
  readonly mutationApplyRecord:   FirstActualSandboxMutationApplyRecord;
  readonly mutationCommitRecord:  FirstActualSandboxMutationCommitRecord;
  readonly executionRecord:       ControlledExecutionRecord;
}

export interface FirstControlledFilesystemMutationPermitSummary {
  readonly total:                                  number;
  readonly byState:                                Record<FilesystemMutationPermitState, number>;
  readonly filesystemMutationPermitPrepared:       true;
  readonly filesystemMutationPermitEnabled:        false;
  readonly filesystemMutationGateEnabled:          false;
  readonly filesystemMutationEnablementEnabled:    false;
  readonly mutationSurfaceEnabled:                 false;
  readonly mutationApplyEnabled:                   false;
  readonly mutationCommitEnabled:                  false;
  readonly actualWritesEnabled:                    false;
  readonly approvalRequired:                       true;
  readonly filesystemMutationBlocked:              true;
  readonly motherCoreMutationBlocked:              true;
  readonly targetScope:                            "sandbox_approved_only";
  readonly filesystemMutationPermitState:          FilesystemMutationPermitState;
  readonly implementationPhase:                    "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstControlledFilesystemMutationPermitRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstControlledFilesystemMutationPermitInput,
): readonly FilesystemMutationPermitCheck[] {
  const { gateRecord, enablementRecord, mutationSurfaceRecord, mutationApplyRecord, mutationCommitRecord, executionRecord } = input;

  const gateExists        = gateRecord.filesystemMutationGateId.length > 0;
  const enablementExists  = enablementRecord.filesystemMutationEnablementId.length > 0;
  const surfaceExists      = mutationSurfaceRecord.mutationSurfaceId.length > 0;
  const applyExists        = mutationApplyRecord.mutationApplyId.length > 0;
  const commitExists       = mutationCommitRecord.mutationCommitId.length > 0;
  const ctrlExists         = executionRecord.controlledExecutionId.length > 0;

  const gateBound          = gateRecord.filesystemMutationEnablementId === enablementRecord.filesystemMutationEnablementId;
  const enablementBound    = enablementRecord.mutationSurfaceId === mutationSurfaceRecord.mutationSurfaceId;
  const surfaceBound       = mutationSurfaceRecord.mutationApplyId === mutationApplyRecord.mutationApplyId;
  const applyBound         = mutationApplyRecord.mutationCommitId === mutationCommitRecord.mutationCommitId;

  return [
    {
      rule: "filesystem_mutation_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `filesystemMutationGateId=${gateRecord.filesystemMutationGateId}`
        : "gateRecord.filesystemMutationGateId is empty",
    },
    {
      rule: "filesystem_mutation_enablement_exists",
      pass: enablementExists,
      note: enablementExists
        ? `filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`
        : "enablementRecord.filesystemMutationEnablementId is empty",
    },
    {
      rule: "mutation_surface_exists",
      pass: surfaceExists,
      note: surfaceExists
        ? `mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`
        : "mutationSurfaceRecord.mutationSurfaceId is empty",
    },
    {
      rule: "mutation_apply_exists",
      pass: applyExists,
      note: applyExists
        ? `mutationApplyId=${mutationApplyRecord.mutationApplyId}`
        : "mutationApplyRecord.mutationApplyId is empty",
    },
    {
      rule: "mutation_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `mutationCommitId=${mutationCommitRecord.mutationCommitId}`
        : "mutationCommitRecord.mutationCommitId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "filesystem_mutation_gate_bound_to_enablement",
      pass: gateBound,
      note: gateBound
        ? `gateRecord.filesystemMutationEnablementId === enablementRecord.filesystemMutationEnablementId (${enablementRecord.filesystemMutationEnablementId})`
        : `gate/enablement mismatch: gate.filesystemMutationEnablementId=${gateRecord.filesystemMutationEnablementId} vs enablement.filesystemMutationEnablementId=${enablementRecord.filesystemMutationEnablementId}`,
    },
    {
      rule: "filesystem_mutation_enablement_bound_to_surface",
      pass: enablementBound,
      note: enablementBound
        ? `enablementRecord.mutationSurfaceId === mutationSurfaceRecord.mutationSurfaceId (${mutationSurfaceRecord.mutationSurfaceId})`
        : `enablement/surface mismatch: enablement.mutationSurfaceId=${enablementRecord.mutationSurfaceId} vs surface.mutationSurfaceId=${mutationSurfaceRecord.mutationSurfaceId}`,
    },
    {
      rule: "mutation_surface_bound_to_apply",
      pass: surfaceBound,
      note: surfaceBound
        ? `mutationSurfaceRecord.mutationApplyId === mutationApplyRecord.mutationApplyId (${mutationApplyRecord.mutationApplyId})`
        : `surface/apply mismatch: surface.mutationApplyId=${mutationSurfaceRecord.mutationApplyId} vs apply.mutationApplyId=${mutationApplyRecord.mutationApplyId}`,
    },
    {
      rule: "mutation_apply_bound_to_commit",
      pass: applyBound,
      note: applyBound
        ? `mutationApplyRecord.mutationCommitId === mutationCommitRecord.mutationCommitId (${mutationCommitRecord.mutationCommitId})`
        : `apply/commit mismatch: apply.mutationCommitId=${mutationApplyRecord.mutationCommitId} vs commit.mutationCommitId=${mutationCommitRecord.mutationCommitId}`,
    },
    {
      rule: "filesystem_mutation_permit_still_disabled",
      pass: true,
      note: "filesystemMutationPermitEnabled=false — compile-time literal; no filesystem mutation permit activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "filesystemMutationPermitState=descriptor_filesystem_mutation_permit_pending — output is a descriptor only; filesystem mutation permit is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly FilesystemMutationPermitCheck[],
): readonly FilesystemMutationPermitBlockedReason[] {
  const staticReasons: FilesystemMutationPermitBlockedReason[] = [
    { code: "filesystem_mutation_permit_disabled", reason: "filesystemMutationPermitEnabled=false — compile-time literal; an explicit first controlled filesystem mutation permit activation phase must activate the permit before any sandbox target can receive filesystem writes",                                                                                                                                                                                                                                                                                                                                         static: true },
    { code: "approval_required",                   reason: "approvalRequired=true — explicit operator approval is required before the filesystem mutation permit can be activated",                                                                                                                                                                                                                                                                                                                                                                                                                                        static: true },
    { code: "actual_writes_disabled",              reason: "actualWritesEnabled=false — compile-time literal across all 35 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, mutation-apply, mutation-surface, filesystem-mutation-enablement, and filesystem-mutation-gate layers", static: true },
  ];
  const dynamicReasons: FilesystemMutationPermitBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedPermitReference(
  input: CreateFirstControlledFilesystemMutationPermitInput,
  rollbackChainValid: boolean,
): LinkedFilesystemMutationPermitReference {
  const { gateRecord, enablementRecord, mutationSurfaceRecord, mutationApplyRecord } = input;
  return {
    filesystemMutationGateId:           gateRecord.filesystemMutationGateId,
    filesystemMutationEnablementId:     enablementRecord.filesystemMutationEnablementId,
    mutationSurfaceId:                  mutationSurfaceRecord.mutationSurfaceId,
    mutationApplyId:                    mutationApplyRecord.mutationApplyId,
    rollbackSnapshotId:                 gateRecord.linkedFilesystemMutationGateReference.rollbackSnapshotId,
    filesystemMutationPermitPrepared:   true,
    filesystemMutationPermitEnabled:    false,
    filesystemMutationGateEnabled:      false,
    filesystemMutationEnablementEnabled: false,
    mutationSurfaceEnabled:             false,
    actualWritesEnabled:                false,
    rollbackChainValid,
    referenceNote: "linked filesystem mutation permit reference sources rollbackSnapshotId from gateRecord.linkedFilesystemMutationGateReference; filesystem mutation permit disabled; filesystem mutation gate disabled; filesystem mutation enablement disabled; mutation surface disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstControlledFilesystemMutationPermitRecord(
  input: CreateFirstControlledFilesystemMutationPermitInput,
): FirstControlledFilesystemMutationPermitRecord {
  const { gateRecord, enablementRecord, mutationSurfaceRecord, mutationApplyRecord, mutationCommitRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = gateRecord.filesystemMutationGateReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedPermitReference(input, rollbackChainValid);

  const filesystemMutationPermitPlan: FilesystemMutationPermitPlanEntry[] = [
    {
      entryId:                         randomUUID(),
      operationType:                   "descriptor_filesystem_mutation_permit_planned",
      targetScope:                     "sandbox_approved_only",
      filesystemMutationPermitEnabled: false,
      mutationBlocked:                 true,
      note:                            "filesystem mutation permit planned in descriptor-only mode; targetScope=sandbox_approved_only; filesystemMutationPermitEnabled=false; filesystemMutationBlocked=true; first controlled filesystem mutation permit activation phase required to activate",
    },
  ];

  const filesystemMutationPermitReadinessReport: FilesystemMutationPermitReadinessReport = {
    filesystemMutationPermitPrepared:       true,
    filesystemMutationPermitEnabled:        false,
    filesystemMutationGateEnabled:          false,
    filesystemMutationEnablementEnabled:    false,
    mutationSurfaceEnabled:                 false,
    mutationApplyEnabled:                   false,
    mutationCommitEnabled:                  false,
    mutationExecutorEnabled:                false,
    commitExecutionGateEnabled:             false,
    sandboxWriteCommitEnabled:              false,
    runtimeWriteExecutorEnabled:            false,
    writeExecutionGateEnabled:              false,
    scopedActivationEnabled:                false,
    writePermissionEnabled:                 false,
    mutationSwitchEnabled:                  false,
    guardedWriteEnabled:                    false,
    actualWritesEnabled:                    false,
    realWritesEnabled:                      false,
    approvalRequired:                       true,
    allChecksPass,
    blockedReasonCount:                     blockedReasons.length,
    rollbackChainValid,
    targetScope:                            "sandbox_approved_only",
    summary: `filesystemMutationPermitState=descriptor_filesystem_mutation_permit_pending; filesystemMutationPermitEnabled=false; filesystemMutationGateEnabled=false; filesystemMutationEnablementEnabled=false; mutationSurfaceEnabled=false; mutationApplyEnabled=false; mutationCommitEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstControlledFilesystemMutationPermitRecord = {
    filesystemMutationPermitId:              randomUUID(),
    filesystemMutationPermitState:           "descriptor_filesystem_mutation_permit_pending",
    approvalRequired:                        true,
    filesystemMutationPermitPrepared:        true,
    filesystemMutationPermitEnabled:         false,
    filesystemMutationGateEnabled:           false,
    filesystemMutationEnablementEnabled:     false,
    mutationSurfaceEnabled:                  false,
    mutationApplyEnabled:                    false,
    mutationCommitEnabled:                   false,
    actualWritesEnabled:                     false,
    filesystemMutationBlocked:               true,
    motherCoreMutationBlocked:               true,
    vaultMutationBlocked:                    true,
    shellBlocked:                            true,
    networkBlocked:                          true,
    targetScope:                             "sandbox_approved_only",
    implementationPhase:                     "descriptor_only",
    filesystemMutationGateId:                gateRecord.filesystemMutationGateId,
    filesystemMutationEnablementId:          enablementRecord.filesystemMutationEnablementId,
    mutationSurfaceId:                       mutationSurfaceRecord.mutationSurfaceId,
    mutationApplyId:                         mutationApplyRecord.mutationApplyId,
    mutationCommitId:                        mutationCommitRecord.mutationCommitId,
    controlledExecutionId:                   executionRecord.controlledExecutionId,
    filesystemMutationPermitPlan,
    filesystemMutationPermitChecks:          checks,
    filesystemMutationPermitBlockedReasons:  blockedReasons,
    filesystemMutationPermitReadinessReport,
    linkedFilesystemMutationPermitReference: linkedRef,
    createdAt:                               new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstControlledFilesystemMutationPermitRecords(): readonly FirstControlledFilesystemMutationPermitRecord[] {
  return _store.slice();
}

export function getFirstControlledFilesystemMutationPermitSummary(): FirstControlledFilesystemMutationPermitSummary {
  return {
    total:                                  _store.length,
    byState:                                { descriptor_filesystem_mutation_permit_pending: _store.length },
    filesystemMutationPermitPrepared:        true,
    filesystemMutationPermitEnabled:         false,
    filesystemMutationGateEnabled:           false,
    filesystemMutationEnablementEnabled:     false,
    mutationSurfaceEnabled:                  false,
    mutationApplyEnabled:                    false,
    mutationCommitEnabled:                   false,
    actualWritesEnabled:                     false,
    approvalRequired:                        true,
    filesystemMutationBlocked:               true,
    motherCoreMutationBlocked:               true,
    targetScope:                             "sandbox_approved_only",
    filesystemMutationPermitState:           "descriptor_filesystem_mutation_permit_pending",
    implementationPhase:                     "descriptor_only",
  };
}
