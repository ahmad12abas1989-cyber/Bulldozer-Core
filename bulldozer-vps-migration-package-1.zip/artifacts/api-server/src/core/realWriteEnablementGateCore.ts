import { SandboxFilesystemRecord, SandboxWritablePath, SandboxProtectedPath } from "./sandboxFilesystemCore.js";
import { WriteGuardRecord }                                                      from "./controlledWriteGuardCore.js";
import { ControlledExecutionRecord }                                              from "./controlledExecutionCore.js";
import { randomBytes }                                                            from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type WriteGateState = "pre_write_ready";

export type GateValidationCheckRule =
  | "filesystem_record_exists"
  | "write_guard_exists"
  | "execution_record_exists"
  | "rollback_ready"
  | "writable_zones_eligible"
  | "protected_zones_blocked"
  | "approval_gate_present"
  | "real_writes_still_disabled";

export interface EligibleWritableZone {
  readonly path:              SandboxWritablePath;
  readonly eligible:          boolean;
  readonly realWritesEnabled: false;
  readonly reason:            string;
}

export interface BlockedProtectedZone {
  readonly path:         SandboxProtectedPath;
  readonly writeBlocked: true;
  readonly reason:       string;
}

export interface GateValidationCheck {
  readonly rule:   GateValidationCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface WriteReadinessReport {
  readonly realWritesEnabled:    false;
  readonly approvalRequired:     true;
  readonly rollbackRequired:     true;
  readonly rollbackReady:        boolean;
  readonly writeGuardClearance:  boolean;
  readonly allChecksPass:        boolean;
  readonly summary:              string;
}

export interface WriteGateRecord {
  readonly writeGateId:               string;
  readonly writeGateState:            WriteGateState;
  readonly approvalRequired:          true;
  readonly realWritesEnabled:         false;
  readonly motherCoreWritesBlocked:   true;
  readonly vaultWritesBlocked:        true;
  readonly shellAccessBlocked:        true;
  readonly networkAccessBlocked:      true;
  readonly deploymentWritesBlocked:   true;
  readonly implementationPhase:       "descriptor_only";
  readonly filesystemRecordId:        string;
  readonly writeGuardId:              string;
  readonly executionRecordId:         string;
  readonly approvalReference:         string;
  readonly eligibleWritableZones:     readonly EligibleWritableZone[];
  readonly blockedProtectedZones:     readonly BlockedProtectedZone[];
  readonly gateValidationChecks:      readonly GateValidationCheck[];
  readonly writeReadinessReport:      WriteReadinessReport;
  readonly createdAt:                 string;
}

export interface CreateWriteGateInput {
  readonly filesystemRecord:  SandboxFilesystemRecord;
  readonly writeGuardRecord:  WriteGuardRecord;
  readonly executionRecord:   ControlledExecutionRecord;
}

export interface WriteGateSummary {
  readonly total:                   number;
  readonly byState:                 Record<WriteGateState, number>;
  readonly realWritesEnabled:       false;
  readonly motherCoreWritesBlocked: true;
  readonly vaultWritesBlocked:      true;
  readonly shellAccessBlocked:      true;
  readonly networkAccessBlocked:    true;
  readonly deploymentWritesBlocked: true;
  readonly approvalRequired:        true;
  readonly eligibleZonePaths:       readonly SandboxWritablePath[];
  readonly blockedZonePaths:        readonly SandboxProtectedPath[];
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildEligibleWritableZones(
  filesystemRecord: SandboxFilesystemRecord,
): readonly EligibleWritableZone[] {
  return filesystemRecord.writableZones.map(z => ({
    path:              z.path,
    eligible:          false,
    realWritesEnabled: false,
    reason:            "Pre-write gate phase — eligibility declared but real writes remain disabled until explicit future execution phase",
  }));
}

function buildBlockedProtectedZones(
  filesystemRecord: SandboxFilesystemRecord,
): readonly BlockedProtectedZone[] {
  return filesystemRecord.protectedZones.map(z => ({
    path:         z.path,
    writeBlocked: true,
    reason:       `Protected zone — permanently blocked at all phases (${z.reason})`,
  }));
}

function buildGateValidationChecks(
  input: CreateWriteGateInput,
): readonly GateValidationCheck[] {
  const { filesystemRecord, writeGuardRecord, executionRecord } = input;
  const rollbackReady       = filesystemRecord.rollbackFilesystemPlan.rollbackReady;
  const guardRollbackReady  = writeGuardRecord.rollbackReadiness.rollbackReady;
  const combinedRollback    = rollbackReady && guardRollbackReady;
  const allZonesEligible    = filesystemRecord.writableZones.every(
    z => z.path.startsWith("/sandbox/"),
  );
  const allProtectedBlocked = filesystemRecord.protectedZones.every(
    z => z.sandboxAccess === false,
  );

  return [
    {
      rule:   "filesystem_record_exists",
      passed: filesystemRecord.sandboxFilesystemId.length > 0,
      detail: "Sandbox filesystem record is present and valid",
    },
    {
      rule:   "write_guard_exists",
      passed: writeGuardRecord.writeGuardId.length > 0,
      detail: "Write guard record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "rollback_ready",
      passed: combinedRollback,
      detail: combinedRollback
        ? "Rollback readiness confirmed across filesystem record and write guard"
        : "Rollback not yet ready in one or more upstream records — gate blocked",
    },
    {
      rule:   "writable_zones_eligible",
      passed: allZonesEligible,
      detail: "All writable zones are scoped under /sandbox/ — no host filesystem escape",
    },
    {
      rule:   "protected_zones_blocked",
      passed: allProtectedBlocked,
      detail: `All ${filesystemRecord.protectedZones.length} protected zones confirmed sandboxAccess=false`,
    },
    {
      rule:   "approval_gate_present",
      passed: filesystemRecord.approvalReference.length > 0,
      detail: "Operator approval reference is present in filesystem record",
    },
    {
      rule:   "real_writes_still_disabled",
      passed: true,
      detail: "realWritesEnabled=false confirmed — no real filesystem mutation occurs at this phase",
    },
  ] as const;
}

function buildWriteReadinessReport(
  checks: readonly GateValidationCheck[],
  writeGuardRecord: WriteGuardRecord,
  filesystemRecord: SandboxFilesystemRecord,
): WriteReadinessReport {
  const allChecksPass      = checks.every(c => c.passed);
  const rollbackReady      = filesystemRecord.rollbackFilesystemPlan.rollbackReady &&
                             writeGuardRecord.rollbackReadiness.rollbackReady;
  const writeGuardClearance = writeGuardRecord.rollbackReadiness.rollbackReady;

  return {
    realWritesEnabled:   false,
    approvalRequired:    true,
    rollbackRequired:    true,
    rollbackReady,
    writeGuardClearance,
    allChecksPass,
    summary: allChecksPass
      ? "Pre-write gate ready — all checks pass; real writes remain disabled until explicit future execution phase with operator approval"
      : "Pre-write gate not ready — one or more checks failed; real writes remain disabled",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const gateStore = new Map<string, WriteGateRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createWriteGateRecord(
  input: CreateWriteGateInput,
): { ok: true; record: WriteGateRecord } {
  const writeGateId        = randomBytes(16).toString("hex");
  const eligibleZones      = buildEligibleWritableZones(input.filesystemRecord);
  const blockedZones       = buildBlockedProtectedZones(input.filesystemRecord);
  const checks             = buildGateValidationChecks(input);
  const readinessReport    = buildWriteReadinessReport(checks, input.writeGuardRecord, input.filesystemRecord);

  const record: WriteGateRecord = {
    writeGateId,
    writeGateState:           "pre_write_ready",
    approvalRequired:         true,
    realWritesEnabled:        false,
    motherCoreWritesBlocked:  true,
    vaultWritesBlocked:       true,
    shellAccessBlocked:       true,
    networkAccessBlocked:     true,
    deploymentWritesBlocked:  true,
    implementationPhase:      "descriptor_only",
    filesystemRecordId:       input.filesystemRecord.sandboxFilesystemId,
    writeGuardId:             input.writeGuardRecord.writeGuardId,
    executionRecordId:        input.executionRecord.controlledExecutionId,
    approvalReference:        input.filesystemRecord.approvalReference,
    eligibleWritableZones:    eligibleZones,
    blockedProtectedZones:    blockedZones,
    gateValidationChecks:     checks,
    writeReadinessReport:     readinessReport,
    createdAt:                new Date().toISOString(),
  };

  gateStore.set(writeGateId, record);
  return { ok: true, record };
}

export function listWriteGateRecords(): readonly WriteGateRecord[] {
  return [...gateStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getWriteGateSummary(): WriteGateSummary {
  const records = listWriteGateRecords();
  const eligiblePaths: SandboxWritablePath[] = [
    "/sandbox/workspace",
    "/sandbox/tmp",
    "/sandbox/build-cache",
  ];
  const blockedPaths: SandboxProtectedPath[] = [
    "/mother-core",
    "/vault",
    "/runtime-config",
    "/system",
    "/network-secrets",
  ];
  return {
    total:                   records.length,
    byState:                 { pre_write_ready: records.length },
    realWritesEnabled:       false,
    motherCoreWritesBlocked: true,
    vaultWritesBlocked:      true,
    shellAccessBlocked:      true,
    networkAccessBlocked:    true,
    deploymentWritesBlocked: true,
    approvalRequired:        true,
    eligibleZonePaths:       eligiblePaths,
    blockedZonePaths:        blockedPaths,
  };
}
