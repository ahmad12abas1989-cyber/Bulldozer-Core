// uiDashboardPages.ts
// Phase 153 — UI Pages Batch (Governance / Observation / Diagnostics)
// Phase 155 — UI Comparison Page
// Phase 163 — Operator Dashboard Visual Upgrade II
// Phase 164 — UI Deduplication & Mobile Readability Pass
// Phase 175 — Light Theme Implementation
// Phase 283 — Execution Control Room UI Core (observation page section)
// Pure per-request HTML derivation from existing manifest getters.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. executionBlocked always true.

import { getUIThemeManifest }       from "./workspaceUITheme";
import { getUILayoutManifest }      from "./workspaceUILayout";
import { getUINavigationManifest }  from "./workspaceUINavigation";
import { getUIPageManifest }        from "./workspaceUIPages";
import { getUIPanelManifest }       from "./workspaceUIPanels";
import { getUIWidgetManifest }      from "./workspaceUIWidgets";
import { getUILayerAudit }          from "./workspaceUILayerAudit";
import { buildExecutionControlRoomSection } from "./executionControlRoomCore";

function esc(s: string): string {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export type DashboardPageId = "governance" | "observation" | "diagnostics" | "comparison";

// Phase 175 — Light theme accent mapping (sealed Phase 174)
const PAGE_META: Record<DashboardPageId, { title: string; label: string; accent: string; dotClass: string }> = {
  governance:  { title: "Governance",  label: "GOVERNANCE",  accent: "#3b82f6", dotClass: "gov"  }, // blue
  observation: { title: "Observation", label: "OBSERVATION", accent: "#d946ef", dotClass: "obs"  }, // pink/magenta
  diagnostics: { title: "Diagnostics", label: "DIAGNOSTICS", accent: "#f97316", dotClass: "diag" }, // orange
  comparison:  { title: "Comparison",  label: "COMPARISON",  accent: "#14b8a6", dotClass: "cmp"  }, // teal
};

function buildCss(accent: string): string {
  return `
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden}
body{background:#f8f9fa;color:#212529;font-family:ui-monospace,SFMono-Regular,'Cascadia Code','Fira Code',monospace;font-size:13px;line-height:1.5;display:flex;flex-direction:column}
.op-root{display:flex;flex-direction:column;flex:1;overflow:hidden}
.op-topbar{display:flex;align-items:center;gap:10px;padding:0 16px;height:48px;background:#ffffff;border-bottom:1px solid #dee2e6;flex-shrink:0;z-index:10}
.op-brand{display:flex;align-items:center;gap:9px;flex-shrink:0}
.op-mark{font-size:17px;color:${accent};line-height:1}
.op-name{font-size:13px;font-weight:900;letter-spacing:3px;color:#212529}
.op-sub{font-size:9px;color:#6c757d;letter-spacing:1.5px;text-transform:uppercase}
.op-vdiv{width:1px;height:22px;background:#dee2e6;flex-shrink:0}
.op-search{flex:1;display:flex;align-items:center;gap:8px;padding:5px 12px;background:#f8f9fa;border:1px solid #dee2e6;border-radius:4px;max-width:440px;min-width:0}
.op-search-ic{color:#6c757d;font-size:14px;flex-shrink:0;line-height:1}
.op-search-txt{font-size:10px;color:#6c757d;letter-spacing:0.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}
.op-topbar-right{display:flex;align-items:center;gap:7px;margin-left:auto;flex-shrink:0}
.badge{padding:3px 9px;border-radius:3px;font-size:9px;font-weight:700;letter-spacing:1px;white-space:nowrap}
.ro{background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0}
.eb{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
.op-body{display:flex;flex:1;overflow:hidden}
.op-sidebar{width:208px;flex-shrink:0;background:#f1f3f5;border-right:1px solid #dee2e6;display:flex;flex-direction:column;overflow-y:auto;scrollbar-width:thin;scrollbar-color:#ced4da #f1f3f5}
.sb-sec{padding:14px 12px 10px}
.sb-lbl{font-size:8px;font-weight:700;letter-spacing:2px;color:#6c757d;text-transform:uppercase;margin-bottom:6px;padding-left:2px}
.sb-link{display:flex;align-items:center;gap:7px;text-decoration:none;font-size:11px;font-weight:600;letter-spacing:0.5px;color:#495057;padding:6px 8px;border-radius:4px;margin-bottom:1px;border:1px solid transparent;overflow:hidden}
.sb-link.on{color:${accent};background:${accent}14;border-color:${accent}30}
.sb-dot{width:5px;height:5px;border-radius:50%;background:currentColor;flex-shrink:0;opacity:0.85}
.sb-dot.gov{background:#3b82f6}
.sb-dot.obs{background:#d946ef}
.sb-dot.diag{background:#f97316}
.sb-dot.cmp{background:#14b8a6}
.sb-sep{height:1px;background:#dee2e6;margin:4px 12px 6px}
.sb-stat{display:flex;justify-content:space-between;align-items:baseline;padding:3px 12px;font-size:10px}
.sb-stat-k{color:#6c757d}
.sb-stat-v{color:${accent};font-weight:700}
.sb-status{margin:4px 12px 12px;padding:8px 10px;background:#ffffff;border:1px solid #dee2e6;border-radius:4px}
.sb-status-row{display:flex;justify-content:space-between;align-items:center;font-size:10px;padding:2px 0}
.sb-ok{color:#16a34a;font-weight:700}
.sb-blk{color:#dc2626;font-weight:700}
.op-main{flex:1;overflow-y:auto;padding:24px 28px;min-width:0;scrollbar-width:thin;scrollbar-color:#ced4da #f8f9fa}
.op-title-area{margin-bottom:20px;padding-bottom:14px;border-bottom:1px solid #dee2e6}
.op-page-tag{font-size:9px;font-weight:700;letter-spacing:2px;color:${accent};text-transform:uppercase;margin-bottom:6px;display:flex;align-items:center;gap:6px}
.op-page-tag::before{content:'';display:inline-block;width:5px;height:5px;background:${accent};border-radius:50%}
.op-title{font-size:20px;font-weight:900;letter-spacing:2px;color:#212529;line-height:1.1;margin-bottom:5px}
.op-subtitle{font-size:10px;color:#6c757d;letter-spacing:1px}
.op-section{margin-bottom:26px}
.op-sh{display:flex;align-items:baseline;gap:9px;font-size:9px;font-weight:700;letter-spacing:2px;color:#6c757d;text-transform:uppercase;padding:14px 0 8px;border-bottom:1px solid #dee2e6;margin-bottom:12px}
.op-sh .op-ct{color:#adb5bd;font-weight:400;letter-spacing:0;font-size:9px;text-transform:none}
.m-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(118px,1fr));gap:10px}
.mc{background:#ffffff;border:1px solid #dee2e6;border-top:2px solid ${accent};border-radius:5px;padding:14px 15px}
.mc-n{font-size:28px;font-weight:800;color:${accent};line-height:1;margin-bottom:6px}
.mc-n.sm{font-size:13px;color:#495057;font-weight:600}
.mc-l{font-size:8px;color:#6c757d;text-transform:uppercase;letter-spacing:1.5px}
.panel-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}
.pc{background:#ffffff;border:1px solid #dee2e6;border-radius:5px;overflow:hidden}
.pc-bar{height:3px;background:${accent}}
.pc-body{padding:12px 14px}
.pc-id{font-size:8px;color:#6c757d;letter-spacing:1px;margin-bottom:3px}
.pc-title{font-size:11px;font-weight:700;color:#212529;margin-bottom:8px}
.pc-chips{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.chip{font-size:9px;padding:2px 7px;border-radius:2px;background:#f1f3f5;border:1px solid #dee2e6;color:#495057;letter-spacing:0.5px}
.wc{font-size:11px;color:${accent};font-weight:700;margin-left:auto}
.page-desc{font-size:11px;color:#6c757d;margin-bottom:14px;line-height:1.6}
.table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}
table{width:100%;border-collapse:collapse;min-width:320px}
thead tr{background:#f1f3f5}
th{text-align:left;font-size:8px;color:#6c757d;text-transform:uppercase;letter-spacing:1.2px;padding:7px 11px;border-bottom:1px solid #dee2e6}
td{padding:7px 11px;border-bottom:1px solid #e9ecef;font-size:11px;color:#495057;vertical-align:middle}
tbody tr:last-child td{border-bottom:none}
.td-id{color:#6c757d;font-size:10px}
.td-r{color:#6c757d;font-size:11px}
.ok{color:#16a34a;font-weight:700}
.fail{color:#dc2626;font-weight:700}
.audit-bar{display:flex;align-items:center;gap:12px;padding:8px 13px;background:#ffffff;border:1px solid #dee2e6;border-radius:4px;margin-bottom:10px;flex-wrap:wrap}
.a-lbl{font-size:9px;color:#6c757d}
.eb-chip{padding:2px 9px;background:#fef2f2;color:#dc2626;border:1px solid #fecaca;border-radius:3px;font-size:9px;font-weight:700}
.op-footer{margin-top:22px;padding:10px 0;border-top:1px solid #dee2e6;color:#6c757d;font-size:9px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;letter-spacing:0.5px}
@media(max-width:820px){
  html,body{overflow:auto;height:auto}
  .op-root{overflow:visible}
  .op-body{flex-direction:column;overflow:visible}
  .op-sidebar{width:100%;height:auto;overflow:visible;border-right:none;border-bottom:1px solid #dee2e6;flex-direction:row;flex-wrap:wrap;padding:6px 4px}
  .op-main{overflow:visible;padding:14px 12px}
  .op-section{margin-bottom:18px}
  .sb-sec{flex:1;min-width:130px;padding:6px 8px 4px}
  .sb-sep{display:none}
  .m-grid{grid-template-columns:repeat(3,1fr)}
  .panel-grid{grid-template-columns:repeat(2,1fr)}
  .op-topbar{flex-wrap:wrap;height:auto;padding:8px 12px;gap:8px}
  .op-vdiv{display:none}
  .op-search{max-width:100%}
  .op-topbar-right{margin-left:0}
  .op-title-area{margin-bottom:14px;padding-bottom:10px}
  .op-sh{padding:10px 0 6px}
}
@media(max-width:480px){
  .m-grid{grid-template-columns:repeat(2,1fr)}
  .panel-grid{grid-template-columns:1fr}
}`.trim();
}

export function buildDashboardPageHtml(pageId: DashboardPageId): string {
  const meta       = PAGE_META[pageId];
  const theme      = getUIThemeManifest().themeTokens;
  const layout     = getUILayoutManifest().layout;
  const nav        = getUINavigationManifest();
  const pages      = getUIPageManifest();
  const panels     = getUIPanelManifest();
  const widgets    = getUIWidgetManifest();
  const audit      = getUILayerAudit();
  const generatedAt = new Date().toISOString();

  const navGroup   = nav.groups.find((g) => g.groupId === pageId);
  const navItems   = (navGroup?.items ?? []).slice().sort((a, b) => a.itemOrder - b.itemOrder);
  const pageEntry  = pages.pages.find((p) => p.pageId === pageId);
  const pagePanels = panels.panels.filter((p) => p.pageId === pageId);

  const on = (id: string) => pageId === id ? " on" : "";

  const navHtml = navItems.length === 0
    ? `<tr><td colspan="3" style="color:#6c757d">No navigation items found</td></tr>`
    : navItems.map((item) =>
        `<tr><td class="td-id">${esc(item.itemId)}</td><td>${esc(item.title)}</td><td class="td-r">${esc(item.endpoint)}</td></tr>`
      ).join("");

  const panelsHtml = pagePanels.length === 0
    ? `<p style="color:#6c757d;font-size:11px">No panels found for ${esc(pageId)}</p>`
    : pagePanels.map((p) => `
    <div class="pc">
      <div class="pc-bar"></div>
      <div class="pc-body">
        <div class="pc-id">${esc(p.panelId)}</div>
        <div class="pc-title">${esc(p.title)}</div>
        <div class="pc-chips">
          <span class="chip">${esc(p.cardStyle)}</span>
          <span class="chip">${esc(p.layoutDirection)}</span>
          <span class="wc">${p.widgetCount}w</span>
        </div>
      </div>
    </div>`).join("");

  const auditHtml = audit.checks.map((c) =>
    `<tr><td class="td-id">${esc(c.layerId)}</td><td class="${c.healthy ? "ok" : "fail"}">${c.healthy ? "&#10003;" : "&#10007;"}</td><td class="${c.totalInvariantValid ? "ok" : "fail"}">${c.totalInvariantValid ? "&#10003;" : "&#10007;"}</td><td class="ok">true</td></tr>`
  ).join("");

  const pageDescHtml = pageEntry
    ? `<p class="page-desc">${esc(pageEntry.description)}</p>`
    : "";

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(layout.appName)} &mdash; ${esc(meta.title)}</title>
<style>${buildCss(meta.accent)}
</style>
</head>
<body>
<div class="op-root">

<header class="op-topbar">
  <div class="op-brand">
    <span class="op-mark">&#9672;</span>
    <div>
      <div class="op-name">${esc(layout.appName)}</div>
      <div class="op-sub">Mother Core</div>
    </div>
  </div>
  <div class="op-vdiv"></div>
  <div class="op-search">
    <span class="op-search-ic">&#128269;</span>
    <span class="op-search-txt">Read-only control surface &middot; no execution &middot; no mutation</span>
  </div>
  <div class="op-topbar-right">
    <span class="badge ro">READ ONLY</span>
    <span class="badge eb">EXECUTION BLOCKED</span>
  </div>
</header>

<div class="op-body">

<aside class="op-sidebar">
  <div class="sb-sec">
    <div class="sb-lbl">Pages</div>
    <a class="sb-link" href="/ui"><span class="sb-dot"></span>UI Shell</a>
    <a class="sb-link" href="/ui/overview"><span class="sb-dot"></span>Overview</a>
    <a class="sb-link${on("governance")}" href="/ui/governance"><span class="sb-dot gov"></span>Governance</a>
    <a class="sb-link${on("observation")}" href="/ui/observation"><span class="sb-dot obs"></span>Observation</a>
    <a class="sb-link${on("diagnostics")}" href="/ui/diagnostics"><span class="sb-dot diag"></span>Diagnostics</a>
    <a class="sb-link${on("comparison")}" href="/ui/comparison"><span class="sb-dot cmp"></span>Comparison</a>
  </div>
  <div class="sb-sep"></div>
  <div class="sb-sec">
    <div class="sb-lbl">Runtime</div>
    <div class="sb-status">
      <div class="sb-status-row"><span>Read Only</span><span class="sb-ok">true</span></div>
      <div class="sb-status-row"><span>Exec Blocked</span><span class="sb-blk">true</span></div>
      <div class="sb-status-row"><span>No Mutation</span><span class="sb-ok">true</span></div>
      <div class="sb-status-row"><span>No Client JS</span><span class="sb-ok">true</span></div>
    </div>
    <div class="sb-stat"><span class="sb-stat-k">This page</span><span class="sb-stat-v">${pagePanels.length}p</span></div>
    <div class="sb-stat"><span class="sb-stat-k">Nav items</span><span class="sb-stat-v">${navItems.length}</span></div>
    <div class="sb-stat"><span class="sb-stat-k">Mode</span><span class="sb-stat-v">${esc(theme.colorMode)}</span></div>
    <div class="sb-stat"><span class="sb-stat-k">Audit</span><span class="sb-stat-v ${audit.allHealthy ? "sb-ok" : "sb-blk"}">${audit.allHealthy ? "&#10003;" : "&#10007;"}</span></div>
  </div>
</aside>

<main class="op-main">

  <div class="op-title-area">
    <div class="op-page-tag">${esc(meta.label)}</div>
    <div class="op-title">${pageEntry ? esc(pageEntry.title) : esc(meta.title)}</div>
    <div class="op-subtitle">Mother Core &middot; ${pagePanels.length} panel${pagePanels.length !== 1 ? "s" : ""} &middot; ${navItems.length} nav item${navItems.length !== 1 ? "s" : ""} &middot; read-only</div>
  </div>

  <div class="op-section">
    <div class="op-sh">Page metrics <span class="op-ct">${esc(pageId)}-scoped</span></div>
    <div class="m-grid">
      <div class="mc"><div class="mc-n">${pagePanels.length}</div><div class="mc-l">This Page</div></div>
      <div class="mc"><div class="mc-n">${navItems.length}</div><div class="mc-l">Nav Items</div></div>
      <div class="mc"><div class="mc-n">${panels.totalPanels}</div><div class="mc-l">Total Panels</div></div>
      <div class="mc"><div class="mc-n">${widgets.totalWidgets}</div><div class="mc-l">Widgets</div></div>
      <div class="mc"><div class="mc-n sm">${esc(theme.colorMode)}</div><div class="mc-l">Theme Mode</div></div>
      <div class="mc"><div class="mc-n sm">${esc(layout.contentGrid)}</div><div class="mc-l">Content Grid</div></div>
    </div>
  </div>

  <div class="op-section">
    <div class="op-sh">Navigation <span class="op-ct">${navItems.length} item${navItems.length !== 1 ? "s" : ""} &middot; group: ${esc(pageId)}</span></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Item ID</th><th>Title</th><th>Route</th></tr></thead>
      <tbody>${navHtml}</tbody>
    </table></div>
  </div>

  <div class="op-section">
    <div class="op-sh">Panels <span class="op-ct">${pagePanels.length} panel${pagePanels.length !== 1 ? "s" : ""}${pageEntry ? ` &middot; ${esc(pageEntry.title)}` : ""}</span></div>
    ${pageDescHtml}<div class="panel-grid">${panelsHtml}</div>
  </div>

  ${pageId === "observation" ? buildExecutionControlRoomSection(meta.accent) : ""}

  <div class="op-section">
    <div class="op-sh">UI layer audit <span class="op-ct">v${esc(audit.auditVersion)} &middot; ${audit.layersChecked} layers</span></div>
    <div class="audit-bar">
      <span class="a-lbl">All Healthy:</span>
      <span class="${audit.allHealthy ? "ok" : "fail"}">${audit.allHealthy ? "&#10003; true" : "&#10007; false"}</span>
      <span class="a-lbl">executionBlocked:</span>
      <span class="eb-chip">true</span>
    </div>
    <div class="table-wrap"><table>
      <thead><tr><th>Layer</th><th>Healthy</th><th>Invariant Valid</th><th>Execution Blocked</th></tr></thead>
      <tbody>${auditHtml}</tbody>
    </table></div>
  </div>

  <footer class="op-footer">
    <span>generatedAt: ${esc(generatedAt)}</span>
    <span>executionBlocked: true &middot; readOnly: true &middot; noMutation: true &middot; noClientJS: true</span>
  </footer>

</main>
</div>
</div>
</body>
</html>`;
}
