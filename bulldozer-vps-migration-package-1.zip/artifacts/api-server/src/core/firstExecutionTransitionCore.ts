// firstExecutionTransitionCore.ts
// Phase 291 — First Execution Transition Core Skeleton
// In-memory first execution-transition descriptor engine.
// Layer 16 of the write-preparation + preflight + activation + switch stack.
// Bridges activation-switch readiness toward future controlled sandbox mutation.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No real writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. executionBlocked always true. readOnly always true.
// executionTransitionEnabled=false — real execution has not been enabled.
// executionEnabled=false — no execution gate has been opened.

import type { FirstActivationSwitchRecord }              from "./firstActivationSwitchCore.js";
import type { FirstRealSandboxWriteActivationRecord }    from "./firstRealSandboxWriteActivationCore.js";
import type { ActualSandboxWritePreflightRecord }        from "./actualSandboxWritePreflightCore.js";
import type { ActualSandboxWriteApprovalTokenRecord }    from "./actualSandboxWriteApprovalTokenCore.js";
import type { ActualSandboxWriteDryRunRecord }           from "./actualSandboxWriteDryRunCore.js";
import type { ControlledExecutionRecord }                from "./controlledExecutionCore.js";
import { randomUUID }                                    from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type TransitionState = "descriptor_transition_pending";

export type TransitionCheckRule =
  | "activation_switch_exists"
  | "activation_record_exists"
  | "preflight_record_exists"
  | "approval_token_exists"
  | "dry_run_exists"
  | "execution_record_exists"
  | "switch_bound_to_activation"
  | "activation_bound_to_preflight"
  | "preflight_bound_to_approval"
  | "approval_bound_to_dry_run"
  | "execution_transition_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface TransitionCheck {
  readonly rule: TransitionCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface TransitionBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedTransitionReference {
  readonly activationSwitchId:          string;
  readonly activationId:                string;
  readonly preflightId:                 string;
  readonly approvalTokenId:             string;
  readonly rollbackSnapshotId:          string;
  readonly executionTransitionPrepared: true;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly rollbackChainValid:          boolean;
  readonly referenceNote:               string;
}

export interface TransitionReadinessReport {
  readonly executionTransitionPrepared: true;
  readonly executionTransitionEnabled:  false;
  readonly activationSwitchEnabled:     false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly executionEnabled:            false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly summary:                     string;
}

export interface FirstExecutionTransitionRecord {
  readonly executionTransitionId:        string;
  readonly transitionState:              TransitionState;
  readonly approvalRequired:             true;
  readonly executionTransitionPrepared:  true;
  readonly executionTransitionEnabled:   false;
  readonly activationSwitchEnabled:      false;
  readonly actualWritesEnabled:          false;
  readonly realWritesEnabled:            false;
  readonly executionEnabled:             false;
  readonly filesystemMutationBlocked:    true;
  readonly motherCoreMutationBlocked:    true;
  readonly vaultMutationBlocked:         true;
  readonly shellBlocked:                 true;
  readonly networkBlocked:               true;
  readonly implementationPhase:          "descriptor_only";
  readonly activationSwitchId:           string;
  readonly activationId:                 string;
  readonly preflightId:                  string;
  readonly approvalTokenId:              string;
  readonly dryRunId:                     string;
  readonly controlledExecutionId:        string;
  readonly transitionChecks:             readonly TransitionCheck[];
  readonly transitionBlockedReasons:     readonly TransitionBlockedReason[];
  readonly transitionReadinessReport:    TransitionReadinessReport;
  readonly linkedTransitionReference:    LinkedTransitionReference;
  readonly createdAt:                    string;
}

export interface CreateTransitionInput {
  readonly switchRecord:        FirstActivationSwitchRecord;
  readonly activationRecord:    FirstRealSandboxWriteActivationRecord;
  readonly preflightRecord:     ActualSandboxWritePreflightRecord;
  readonly approvalTokenRecord: ActualSandboxWriteApprovalTokenRecord;
  readonly dryRunRecord:        ActualSandboxWriteDryRunRecord;
  readonly executionRecord:     ControlledExecutionRecord;
}

export interface FirstExecutionTransitionSummary {
  readonly total:                        number;
  readonly byState:                      Record<TransitionState, number>;
  readonly executionTransitionPrepared:  true;
  readonly executionTransitionEnabled:   false;
  readonly activationSwitchEnabled:      false;
  readonly actualWritesEnabled:          false;
  readonly realWritesEnabled:            false;
  readonly executionEnabled:             false;
  readonly approvalRequired:             true;
  readonly filesystemMutationBlocked:    true;
  readonly motherCoreMutationBlocked:    true;
  readonly transitionState:              TransitionState;
  readonly implementationPhase:          "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstExecutionTransitionRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(input: CreateTransitionInput): readonly TransitionCheck[] {
  const { switchRecord, activationRecord, preflightRecord, approvalTokenRecord, dryRunRecord, executionRecord } = input;

  const switchExists    = switchRecord.activationSwitchId.length > 0;
  const activationExists= activationRecord.activationId.length > 0;
  const preflightExists = preflightRecord.preflightId.length > 0;
  const approvalExists  = approvalTokenRecord.approvalTokenId.length > 0;
  const dryRunExists    = dryRunRecord.dryRunId.length > 0;
  const executionExists = executionRecord.controlledExecutionId.length > 0;

  const switchBound     = switchRecord.activationId === activationRecord.activationId;
  const activationBound = activationRecord.preflightId === preflightRecord.preflightId;
  const preflightBound  = preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId;
  const approvalBound   = approvalTokenRecord.dryRunId === dryRunRecord.dryRunId;

  return [
    {
      rule: "activation_switch_exists",
      pass: switchExists,
      note: switchExists
        ? `activationSwitchId=${switchRecord.activationSwitchId}`
        : "switchRecord.activationSwitchId is empty",
    },
    {
      rule: "activation_record_exists",
      pass: activationExists,
      note: activationExists
        ? `activationId=${activationRecord.activationId}`
        : "activationRecord.activationId is empty",
    },
    {
      rule: "preflight_record_exists",
      pass: preflightExists,
      note: preflightExists
        ? `preflightId=${preflightRecord.preflightId}`
        : "preflightRecord.preflightId is empty",
    },
    {
      rule: "approval_token_exists",
      pass: approvalExists,
      note: approvalExists
        ? `approvalTokenId=${approvalTokenRecord.approvalTokenId}`
        : "approvalTokenRecord.approvalTokenId is empty",
    },
    {
      rule: "dry_run_exists",
      pass: dryRunExists,
      note: dryRunExists
        ? `dryRunId=${dryRunRecord.dryRunId}`
        : "dryRunRecord.dryRunId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: executionExists,
      note: executionExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "switch_bound_to_activation",
      pass: switchBound,
      note: switchBound
        ? `switchRecord.activationId === activationRecord.activationId (${activationRecord.activationId})`
        : `switch-activation mismatch: switch.activationId=${switchRecord.activationId} vs activation.activationId=${activationRecord.activationId}`,
    },
    {
      rule: "activation_bound_to_preflight",
      pass: activationBound,
      note: activationBound
        ? `activationRecord.preflightId === preflightRecord.preflightId (${preflightRecord.preflightId})`
        : `activation-preflight mismatch: activation.preflightId=${activationRecord.preflightId} vs preflight.preflightId=${preflightRecord.preflightId}`,
    },
    {
      rule: "preflight_bound_to_approval",
      pass: preflightBound,
      note: preflightBound
        ? `preflightRecord.approvalTokenId === approvalTokenRecord.approvalTokenId (${approvalTokenRecord.approvalTokenId})`
        : `preflight-approval mismatch: preflight.approvalTokenId=${preflightRecord.approvalTokenId} vs token.approvalTokenId=${approvalTokenRecord.approvalTokenId}`,
    },
    {
      rule: "approval_bound_to_dry_run",
      pass: approvalBound,
      note: approvalBound
        ? `approvalTokenRecord.dryRunId === dryRunRecord.dryRunId (${dryRunRecord.dryRunId})`
        : `approval-dryRun mismatch: token.dryRunId=${approvalTokenRecord.dryRunId} vs dryRun.dryRunId=${dryRunRecord.dryRunId}`,
    },
    {
      rule: "execution_transition_still_disabled",
      pass: true,
      note: "executionTransitionEnabled=false — compile-time literal; no execution-transition phase has enabled this",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "transitionState=descriptor_transition_pending — output is a descriptor only; execution bridge is not yet live",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly TransitionCheck[]): readonly TransitionBlockedReason[] {
  const staticReasons: TransitionBlockedReason[] = [
    { code: "execution_transition_disabled", reason: "executionTransitionEnabled=false — compile-time literal; an explicit execution-transition execution phase must set this to true", static: true },
    { code: "approval_required",             reason: "approvalRequired=true — explicit operator approval is required before the execution transition can be opened",                     static: true },
    { code: "actual_writes_disabled",        reason: "actualWritesEnabled=false — compile-time literal across all 16 sealed write-preparation, activation, and switch layers",           static: true },
  ];
  const dynamicReasons: TransitionBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedTransitionReference(
  input: CreateTransitionInput,
  rollbackChainValid: boolean,
): LinkedTransitionReference {
  const { switchRecord, activationRecord, preflightRecord, approvalTokenRecord } = input;
  return {
    activationSwitchId:          switchRecord.activationSwitchId,
    activationId:                activationRecord.activationId,
    preflightId:                 preflightRecord.preflightId,
    approvalTokenId:             approvalTokenRecord.approvalTokenId,
    rollbackSnapshotId:          switchRecord.linkedActivationReference.rollbackSnapshotId,
    executionTransitionPrepared: true,
    executionTransitionEnabled:  false,
    activationSwitchEnabled:     false,
    rollbackChainValid,
    referenceNote:               "linked transition reference sources rollbackSnapshotId from switchRecord.linkedActivationReference; transition disabled; descriptor-only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createTransitionRecord(input: CreateTransitionInput): FirstExecutionTransitionRecord {
  const { switchRecord, activationRecord, preflightRecord, approvalTokenRecord, dryRunRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid =
    switchRecord.switchReadinessReport.rollbackChainValid &&
    activationRecord.activationReadinessReport.rollbackReady &&
    preflightRecord.preflightReadinessReport.rollbackReady &&
    approvalTokenRecord.approvalReadinessReport.rollbackReady &&
    dryRunRecord.dryRunReadinessReport.rollbackReady;

  const allChecksPass    = checks.every((c) => c.pass);
  const blockedReasons   = buildBlockedReasons(checks);
  const linkedRef        = buildLinkedTransitionReference(input, rollbackChainValid);

  const transitionReadinessReport: TransitionReadinessReport = {
    executionTransitionPrepared: true,
    executionTransitionEnabled:  false,
    activationSwitchEnabled:     false,
    actualWritesEnabled:         false,
    realWritesEnabled:           false,
    executionEnabled:            false,
    approvalRequired:            true,
    allChecksPass,
    blockedReasonCount:          blockedReasons.length,
    rollbackChainValid,
    summary: `transitionState=descriptor_transition_pending; executionTransitionEnabled=false; activationSwitchEnabled=false; actualWritesEnabled=false; executionEnabled=false; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstExecutionTransitionRecord = {
    executionTransitionId:        randomUUID(),
    transitionState:              "descriptor_transition_pending",
    approvalRequired:             true,
    executionTransitionPrepared:  true,
    executionTransitionEnabled:   false,
    activationSwitchEnabled:      false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    executionEnabled:             false,
    filesystemMutationBlocked:    true,
    motherCoreMutationBlocked:    true,
    vaultMutationBlocked:         true,
    shellBlocked:                 true,
    networkBlocked:               true,
    implementationPhase:          "descriptor_only",
    activationSwitchId:           switchRecord.activationSwitchId,
    activationId:                 activationRecord.activationId,
    preflightId:                  preflightRecord.preflightId,
    approvalTokenId:              approvalTokenRecord.approvalTokenId,
    dryRunId:                     dryRunRecord.dryRunId,
    controlledExecutionId:        executionRecord.controlledExecutionId,
    transitionChecks:             checks,
    transitionBlockedReasons:     blockedReasons,
    transitionReadinessReport,
    linkedTransitionReference:    linkedRef,
    createdAt:                    new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listTransitionRecords(): readonly FirstExecutionTransitionRecord[] {
  return _store.slice();
}

export function getTransitionSummary(): FirstExecutionTransitionSummary {
  return {
    total:                        _store.length,
    byState:                      { descriptor_transition_pending: _store.length },
    executionTransitionPrepared:  true,
    executionTransitionEnabled:   false,
    activationSwitchEnabled:      false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    executionEnabled:             false,
    approvalRequired:             true,
    filesystemMutationBlocked:    true,
    motherCoreMutationBlocked:    true,
    transitionState:              "descriptor_transition_pending",
    implementationPhase:          "descriptor_only",
  };
}
