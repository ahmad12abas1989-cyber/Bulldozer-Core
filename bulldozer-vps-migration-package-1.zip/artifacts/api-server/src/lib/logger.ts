type Level = "debug" | "info" | "warn" | "error";

const LEVELS: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

const activeLevel: Level = (process.env["LOG_LEVEL"] as Level | undefined) ?? "info";
const activeValue = LEVELS[activeLevel] ?? LEVELS.info;

export interface Logger {
  debug(bindingsOrMsg: Record<string, unknown> | string, msg?: string): void;
  info(bindingsOrMsg: Record<string, unknown> | string, msg?: string): void;
  warn(bindingsOrMsg: Record<string, unknown> | string, msg?: string): void;
  error(bindingsOrMsg: Record<string, unknown> | string, msg?: string): void;
  child(bindings: Record<string, unknown>): Logger;
}

function write(level: Level, bindings: Record<string, unknown>, msg: string): void {
  if (LEVELS[level] < activeValue) return;
  const entry: Record<string, unknown> = {
    time: new Date().toISOString(),
    level,
    msg,
    ...bindings,
  };
  process.stderr.write(JSON.stringify(entry) + "\n");
}

function createLogger(base: Record<string, unknown> = {}): Logger {
  function mkLog(level: Level) {
    return (bindingsOrMsg: Record<string, unknown> | string, msg?: string): void => {
      if (typeof bindingsOrMsg === "string") {
        write(level, base, bindingsOrMsg);
      } else {
        write(level, { ...base, ...bindingsOrMsg }, msg ?? "");
      }
    };
  }

  return {
    debug: mkLog("debug"),
    info: mkLog("info"),
    warn: mkLog("warn"),
    error: mkLog("error"),
    child: (bindings: Record<string, unknown>) => createLogger({ ...base, ...bindings }),
  };
}

export const logger = createLogger();
