// Widget Registry Coherence Health Check — Phase 106
// Pure static validation module: no imports from live data sources, no persistence,
// no init, no subsystem registration. Validates CONTRACT_REGISTRY integrity against
// the 15 canonical compact data types defined in Phase 101.

import { getAllWidgetContracts, type WidgetContract } from "./workspaceWidgetContracts";

const EXECUTION_BLOCKED: true = true;
const EXPECTED_CONTRACT_COUNT = 37;
const EXPECTED_COMPACT_TYPE_COUNT = 15;

// Canonical compact data types as defined in Phase 101 workspaceVisualShellComposition.ts
// Must stay in sync with the CompactDataPayload discriminated union.
// Sorted alphabetically for deterministic comparison and output ordering.
const CANONICAL_COMPACT_TYPES: readonly string[] = [
  "audit",
  "crash",
  "exposure",
  "freeze",
  "governance",
  "heatmap",
  "health",
  "ledger",
  "members",
  "metrics",
  "observation_coverage",
  "probe",
  "projects",
  "static_reference",
  "trend",
];

const CANONICAL_COMPACT_TYPE_SET: ReadonlySet<string> = new Set(CANONICAL_COMPACT_TYPES);
const VALID_SCHEMA_VERSION = "1";

// --- Output types ---

export interface CompactTypeValidation {
  compactType: string;
  contractCount: number;
  presentInRegistry: boolean;
  isCanonical: boolean;
  executionBlocked: true;
}

export interface ContractRegistryValidation {
  widgetId: string;
  compactDataType: string;
  schemaVersion: string;
  enumerationCount: number;
  requiredFieldCount: number;
  fieldCount: number;
  schemaVersionValid: boolean;
  executionBlockedInExample: boolean;
  enumerationsNonEmpty: boolean;
  requiredFieldsExistInFields: boolean;
  passed: boolean;
  executionBlocked: true;
}

export interface RegistryCoherenceSummary {
  contractCount: number;
  expectedContractCount: number;
  contractCountMatch: boolean;
  compactTypeCount: number;
  expectedCompactTypeCount: number;
  compactTypeCountMatch: boolean;
  uniqueWidgetIdCount: number;
  violationCount: number;
  executionBlocked: true;
}

export interface WidgetRegistryHealthResult {
  registryHealthy: boolean;
  summary: RegistryCoherenceSummary;
  compactTypeValidations: CompactTypeValidation[];
  contractValidations: ContractRegistryValidation[];
  missingCompactTypes: string[];
  invalidCompactTypes: string[];
  duplicateWidgetIds: string[];
  schemaVersionMismatches: string[];
  executionBlockedViolations: string[];
  enumerationViolations: string[];
  requiredFieldViolations: string[];
  executionBlocked: true;
}

// --- Status type for healthMonitor integration ---

export interface WidgetRegistryHealthStatus {
  registryHealthy: boolean;
  contractCount: number;
  compactTypeCount: number;
  violationCount: number;
  detail: string;
  executionBlocked: true;
}

// --- Validation logic (pure, deterministic, bounded) ---

function validateContracts(contracts: ReadonlyArray<WidgetContract>): WidgetRegistryHealthResult {
  // --- 1. Duplicate widgetId detection ---
  const idSeen = new Map<string, number>();
  for (const c of contracts) {
    idSeen.set(c.widgetId, (idSeen.get(c.widgetId) ?? 0) + 1);
  }
  const duplicateWidgetIds: string[] = [];
  for (const [id, count] of idSeen) {
    if (count > 1) duplicateWidgetIds.push(id);
  }
  duplicateWidgetIds.sort();

  // --- 2. Compact type set from actual registry ---
  const registryCompactTypes = new Set<string>();
  for (const c of contracts) {
    registryCompactTypes.add(c.compactDataType);
  }

  // --- 3. Missing canonical types (in canonical set but not in registry) ---
  const missingCompactTypes: string[] = [];
  for (const ct of CANONICAL_COMPACT_TYPES) {
    if (!registryCompactTypes.has(ct)) missingCompactTypes.push(ct);
  }

  // --- 4. Invalid compact types (in registry but not in canonical set) ---
  const invalidCompactTypes: string[] = [];
  for (const ct of registryCompactTypes) {
    if (!CANONICAL_COMPACT_TYPE_SET.has(ct)) invalidCompactTypes.push(ct);
  }
  invalidCompactTypes.sort();

  // --- 5. Per-contract validations ---
  const schemaVersionMismatches: string[] = [];
  const executionBlockedViolations: string[] = [];
  const enumerationViolations: string[] = [];
  const requiredFieldViolations: string[] = [];
  const contractValidations: ContractRegistryValidation[] = [];

  for (const c of contracts) {
    // schemaVersion must equal "1"
    const schemaVersionValid = c.schemaVersion === VALID_SCHEMA_VERSION;
    if (!schemaVersionValid) schemaVersionMismatches.push(c.widgetId);

    // examplePayload.executionBlocked must be exactly true
    const executionBlockedInExample = c.examplePayload["executionBlocked"] === true;
    if (!executionBlockedInExample) executionBlockedViolations.push(c.widgetId);

    // All enumerations must have at least 1 value
    let enumerationsNonEmpty = true;
    for (const en of c.enumerations) {
      if (en.values.length === 0) {
        enumerationsNonEmpty = false;
        break;
      }
    }
    if (!enumerationsNonEmpty) enumerationViolations.push(c.widgetId);

    // All requiredFields must appear in fields[].fieldName
    const fieldNames = new Set(c.fields.map((f) => f.fieldName));
    let requiredFieldsExistInFields = true;
    for (const rf of c.requiredFields) {
      if (!fieldNames.has(rf)) {
        requiredFieldsExistInFields = false;
        break;
      }
    }
    if (!requiredFieldsExistInFields) requiredFieldViolations.push(c.widgetId);

    const passed =
      schemaVersionValid &&
      executionBlockedInExample &&
      enumerationsNonEmpty &&
      requiredFieldsExistInFields;

    contractValidations.push({
      widgetId: c.widgetId,
      compactDataType: c.compactDataType,
      schemaVersion: c.schemaVersion,
      enumerationCount: c.enumerations.length,
      requiredFieldCount: c.requiredFields.length,
      fieldCount: c.fields.length,
      schemaVersionValid,
      executionBlockedInExample,
      enumerationsNonEmpty,
      requiredFieldsExistInFields,
      passed,
      executionBlocked: EXECUTION_BLOCKED,
    });
  }

  // --- 6. Compact type validations (all canonical types + any extras) ---
  const allCompactTypes = new Set([...CANONICAL_COMPACT_TYPES, ...registryCompactTypes]);
  const compactTypeCountByType = new Map<string, number>();
  for (const c of contracts) {
    compactTypeCountByType.set(c.compactDataType, (compactTypeCountByType.get(c.compactDataType) ?? 0) + 1);
  }
  const compactTypeValidations: CompactTypeValidation[] = [];
  for (const ct of Array.from(allCompactTypes).sort()) {
    compactTypeValidations.push({
      compactType: ct,
      contractCount: compactTypeCountByType.get(ct) ?? 0,
      presentInRegistry: registryCompactTypes.has(ct),
      isCanonical: CANONICAL_COMPACT_TYPE_SET.has(ct),
      executionBlocked: EXECUTION_BLOCKED,
    });
  }

  // --- 7. Summary ---
  const contractCountMatch = contracts.length === EXPECTED_CONTRACT_COUNT;
  const compactTypeCountMatch = registryCompactTypes.size === EXPECTED_COMPACT_TYPE_COUNT;

  const totalViolationCount =
    (contractCountMatch ? 0 : 1) +
    duplicateWidgetIds.length +
    missingCompactTypes.length +
    invalidCompactTypes.length +
    schemaVersionMismatches.length +
    executionBlockedViolations.length +
    enumerationViolations.length +
    requiredFieldViolations.length;

  const registryHealthy =
    totalViolationCount === 0 && contractCountMatch && compactTypeCountMatch;

  const summary: RegistryCoherenceSummary = {
    contractCount: contracts.length,
    expectedContractCount: EXPECTED_CONTRACT_COUNT,
    contractCountMatch,
    compactTypeCount: registryCompactTypes.size,
    expectedCompactTypeCount: EXPECTED_COMPACT_TYPE_COUNT,
    compactTypeCountMatch,
    uniqueWidgetIdCount: idSeen.size,
    violationCount: totalViolationCount,
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    registryHealthy,
    summary,
    compactTypeValidations,
    contractValidations,
    missingCompactTypes,
    invalidCompactTypes,
    duplicateWidgetIds,
    schemaVersionMismatches,
    executionBlockedViolations,
    enumerationViolations,
    requiredFieldViolations,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- Public API ---

export function runWidgetRegistryValidation(): WidgetRegistryHealthResult {
  const contracts = getAllWidgetContracts();
  return validateContracts(contracts);
}

export function getWidgetRegistryHealthStatus(): WidgetRegistryHealthStatus {
  const result = runWidgetRegistryValidation();
  const violations: string[] = [];
  if (!result.summary.contractCountMatch) {
    violations.push(`contractCount=${result.summary.contractCount}/${result.summary.expectedContractCount}`);
  }
  if (result.duplicateWidgetIds.length > 0) {
    violations.push(`duplicateIds=[${result.duplicateWidgetIds.join(",")}]`);
  }
  if (result.missingCompactTypes.length > 0) {
    violations.push(`missingTypes=[${result.missingCompactTypes.join(",")}]`);
  }
  if (result.invalidCompactTypes.length > 0) {
    violations.push(`invalidTypes=[${result.invalidCompactTypes.join(",")}]`);
  }
  if (result.schemaVersionMismatches.length > 0) {
    violations.push(`schemaVersionMismatches=[${result.schemaVersionMismatches.join(",")}]`);
  }
  if (result.executionBlockedViolations.length > 0) {
    violations.push(`executionBlockedViolations=[${result.executionBlockedViolations.join(",")}]`);
  }
  if (result.enumerationViolations.length > 0) {
    violations.push(`enumerationViolations=[${result.enumerationViolations.join(",")}]`);
  }
  if (result.requiredFieldViolations.length > 0) {
    violations.push(`requiredFieldViolations=[${result.requiredFieldViolations.join(",")}]`);
  }

  const detail =
    result.registryHealthy
      ? `Widget contract registry coherent — ${result.summary.contractCount} contracts, ${result.summary.compactTypeCount} compact types, 0 violations`
      : `Widget contract registry incoherent — ${result.summary.violationCount} violation(s): ${violations.join("; ")}`;

  return {
    registryHealthy: result.registryHealthy,
    contractCount: result.summary.contractCount,
    compactTypeCount: result.summary.compactTypeCount,
    violationCount: result.summary.violationCount,
    detail,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
