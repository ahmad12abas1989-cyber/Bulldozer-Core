import type { IncomingMessage, ServerResponse } from "node:http";
import { getLatestSnapshot, createSnapshot } from "../core/snapshots";
import { sendJson } from "../lib/response";

export function handleSnapshot(_req: IncomingMessage, res: ServerResponse): void {
  const snap = getLatestSnapshot() ?? createSnapshot("manual");
  sendJson(res, 200, snap);
}
