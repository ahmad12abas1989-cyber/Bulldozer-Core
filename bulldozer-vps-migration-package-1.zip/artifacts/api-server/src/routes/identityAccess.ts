import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { getIdentityAccessStatus, listRoleDefinitions } from "../core/identityAccess";

export function handleIdentityStatus(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getIdentityAccessStatus());
}

export function handleIdentityRoles(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, listRoleDefinitions());
}
