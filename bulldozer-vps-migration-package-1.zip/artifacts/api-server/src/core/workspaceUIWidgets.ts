import { getUIRenderModel } from "./workspaceUIRenderModel.js";

export interface UIWidgetEntry {
  widgetId: string;
  title: string;
  widgetType: string;
  renderHint: string;
  size: string;
  sourceEndpoint: string;
  executionBlocked: true;
}

export interface UIWidgetManifest {
  generatedAt: string;
  totalWidgets: number;
  widgets: UIWidgetEntry[];
  executionBlocked: true;
}

export function getUIWidgetManifest(): UIWidgetManifest {
  const renderModel = getUIRenderModel();

  const widgets: UIWidgetEntry[] = renderModel.widgets
    .map((w) => ({
      widgetId: w.widgetId,
      title: w.title,
      widgetType: w.widgetType,
      renderHint: w.renderHint,
      size: w.size,
      sourceEndpoint: w.sourceEndpoint,
      executionBlocked: true as const,
    }))
    .sort((a, b) => a.widgetId.localeCompare(b.widgetId));

  return {
    generatedAt: new Date().toISOString(),
    totalWidgets: widgets.length,
    widgets,
    executionBlocked: true,
  };
}
