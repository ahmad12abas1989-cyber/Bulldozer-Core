import { createHash } from "node:crypto";
import { getPolicyComplianceLedger } from "./workspacePolicyComplianceLedger";
import { getWorkspaceObservationHeatmap } from "./workspaceObservationHeatmap";
import { getWorkspaceCoverageTrend } from "./workspaceCoverageTrend";
import { getWorkspacePolicyExposureIndex } from "./workspacePolicyExposureIndex";
import { getWorkspaceGovernanceScorecard } from "./workspaceGovernanceScorecard";
import { getWorkspaceObservationProbe } from "./workspaceObservationProbe";
import { runWidgetRegistryValidation } from "./widgetRegistryHealth";
import type { TrendDirection } from "./workspaceCoverageTrend";
import type { ExposureGrade } from "./workspacePolicyExposureIndex";
import type { GovernanceGrade } from "./workspaceGovernanceScorecard";

const EXECUTION_BLOCKED: true = true;

// --- Types ---

export type ObservationHealth = "healthy" | "degraded" | "critical";
export type ExposureRiskLevel = "low" | "medium" | "high" | "none";
export type ProbeHealth = "all_passed" | "partial" | "none_passed";
export type ValidationHealth = "healthy" | "degraded" | "failed";

export interface ValidationProbeHealth {
  allWidgetsValid: boolean;
  passedWidgets: number;
  failedWidgets: number;
  widgetCoveragePercent: number;
  fieldCoveragePercent: number;
  failedFieldCount: number;
  validationHealth: ValidationHealth;
  executionBlocked: true;
}

export interface ObservationLedgerSummary {
  overallObservationHealth: ObservationHealth;
  governanceReadiness: GovernanceGrade;
  observationCoverage: number;
  exposureRiskLevel: ExposureRiskLevel;
  trendDirection: TrendDirection | null;
  probeHealth: ProbeHealth;
  validationProbeHealth: ValidationProbeHealth;
  executionBlocked: true;
}

export interface ObservationLedgerComplianceSignal {
  coveragePercent: number;
  observedPolicies: number;
  unobservedPolicies: number;
  totalPolicies: number;
  executionBlocked: true;
}

export interface ObservationLedgerHeatmapSignal {
  coldCount: number;
  warmCount: number;
  hotCount: number;
  totalPolicies: number;
  coveragePercent: number;
  executionBlocked: true;
}

export interface ObservationLedgerTrendSignal {
  currentCoveragePercent: number;
  previousCoveragePercent: number | null;
  coverageDelta: number | null;
  trendDirection: TrendDirection | null;
  comparedSnapshotCount: number;
  executionBlocked: true;
}

export interface ObservationLedgerExposureSignal {
  exposureScore: number;
  exposureGrade: ExposureGrade;
  totalWritePolicies: number;
  unobservedWritePolicies: number;
  rarelyObservedWritePolicies: number;
  wellObservedWritePolicies: number;
  executionBlocked: true;
}

export interface ObservationLedgerGovernanceSignal {
  governanceScore: number;
  governanceGrade: GovernanceGrade;
  executionBlocked: true;
}

export interface ObservationLedgerProbeSignal {
  allProbesPassed: boolean;
  passedProbeCount: number;
  failedProbeCount: number;
  totalProbes: number;
  totalProbeTimeMs: number;
  fastestProbeMs: number | null;
  slowestProbeMs: number | null;
  executionBlocked: true;
}

export interface WorkspaceObservationLedger {
  ledgerId: string;
  generatedAt: string;
  summary: ObservationLedgerSummary;
  compliance: ObservationLedgerComplianceSignal;
  heatmap: ObservationLedgerHeatmapSignal;
  trend: ObservationLedgerTrendSignal;
  exposure: ObservationLedgerExposureSignal;
  governance: ObservationLedgerGovernanceSignal;
  probe: ObservationLedgerProbeSignal;
  validationProbe: ValidationProbeHealth;
  executionBlocked: true;
}

// --- Derivation helpers ---

function deriveExposureRiskLevel(
  grade: ExposureGrade,
  totalWritePolicies: number,
): ExposureRiskLevel {
  if (totalWritePolicies === 0) return "none";
  if (grade === "A" || grade === "B") return "low";
  if (grade === "C" || grade === "D") return "medium";
  return "high"; // F
}

function deriveProbeHealth(
  allProbesPassed: boolean,
  passedProbeCount: number,
): ProbeHealth {
  if (allProbesPassed) return "all_passed";
  if (passedProbeCount === 0) return "none_passed";
  return "partial";
}

function deriveValidationHealth(
  allWidgetsValid: boolean,
  failedFieldCount: number,
  widgetCoveragePercent: number,
): ValidationHealth {
  // Failed: zero widget coverage (probe produced no results)
  if (widgetCoveragePercent === 0) return "failed";
  // Healthy: every widget valid and no field failures
  if (allWidgetsValid && failedFieldCount === 0) return "healthy";
  // Degraded: partial widget or field failures
  return "degraded";
}

function deriveObservationHealth(
  observationCoverage: number,
  exposureRiskLevel: ExposureRiskLevel,
  probeHealth: ProbeHealth,
  governanceReadiness: GovernanceGrade,
  validationHealth: ValidationHealth,
): ObservationHealth {
  // Critical: any probe failure, very low coverage, extreme exposure risk, or validation failed
  if (
    probeHealth === "none_passed" ||
    observationCoverage < 25 ||
    exposureRiskLevel === "high" ||
    validationHealth === "failed"
  ) {
    return "critical";
  }
  // Degraded: partial probe failure, below-half coverage, medium exposure, poor governance, or degraded validation
  if (
    probeHealth === "partial" ||
    observationCoverage < 50 ||
    exposureRiskLevel === "medium" ||
    governanceReadiness === "D" ||
    governanceReadiness === "F" ||
    validationHealth === "degraded"
  ) {
    return "degraded";
  }
  return "healthy";
}

// --- Public API ---

export function getWorkspaceObservationLedger(): WorkspaceObservationLedger {
  const generatedAt = new Date().toISOString();
  const ledgerId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  // Aggregate from all 7 sources — sequential, deterministic, read-only
  const ledger = getPolicyComplianceLedger();
  const heatmap = getWorkspaceObservationHeatmap();
  const trend = getWorkspaceCoverageTrend();
  const exposure = getWorkspacePolicyExposureIndex();
  const scorecard = getWorkspaceGovernanceScorecard();
  const probe = getWorkspaceObservationProbe();
  const validationRegistryResult = runWidgetRegistryValidation();

  // Derive signal fields
  const probeHealth = deriveProbeHealth(
    probe.summary.allProbesPassed,
    probe.summary.passedProbeCount,
  );
  const exposureRiskLevel = deriveExposureRiskLevel(
    exposure.summary.exposureGrade,
    exposure.summary.totalWritePolicies,
  );
  const governanceReadiness = scorecard.governanceGrade;
  const observationCoverage = ledger.summary.coveragePercent;

  // Derive validation signals from static registry result (no circular deps)
  const passedWidgets = validationRegistryResult.contractValidations.filter((c) => c.passed).length;
  const totalWidgets = validationRegistryResult.summary.contractCount;
  const failedWidgets = totalWidgets - passedWidgets;
  const widgetCoveragePercent = totalWidgets === 0 ? 0 : Math.round((passedWidgets / totalWidgets) * 100);
  const failedFieldCount =
    validationRegistryResult.requiredFieldViolations.length +
    validationRegistryResult.enumerationViolations.length +
    validationRegistryResult.executionBlockedViolations.length +
    validationRegistryResult.schemaVersionMismatches.length;
  // 4 boolean field checks per contract: schemaVersionValid, executionBlockedInExample, enumerationsNonEmpty, requiredFieldsExistInFields
  const totalFieldChecks = Math.max(1, totalWidgets * 4);
  const fieldCoveragePercent = Math.round(((totalFieldChecks - failedFieldCount) / totalFieldChecks) * 100);
  const allWidgetsValid = validationRegistryResult.registryHealthy;

  const validationHealth = deriveValidationHealth(
    allWidgetsValid,
    failedFieldCount,
    widgetCoveragePercent,
  );

  const overallObservationHealth = deriveObservationHealth(
    observationCoverage,
    exposureRiskLevel,
    probeHealth,
    governanceReadiness,
    validationHealth,
  );

  const validationProbeSignal: ValidationProbeHealth = {
    allWidgetsValid,
    passedWidgets,
    failedWidgets,
    widgetCoveragePercent,
    fieldCoveragePercent,
    failedFieldCount,
    validationHealth,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const summary: ObservationLedgerSummary = {
    overallObservationHealth,
    governanceReadiness,
    observationCoverage,
    exposureRiskLevel,
    trendDirection: trend.summary.trendDirection,
    probeHealth,
    validationProbeHealth: validationProbeSignal,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const complianceSignal: ObservationLedgerComplianceSignal = {
    coveragePercent: ledger.summary.coveragePercent,
    observedPolicies: ledger.summary.observedPolicies,
    unobservedPolicies: ledger.summary.unobservedPolicies,
    totalPolicies: ledger.summary.totalPolicies,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const heatmapSignal: ObservationLedgerHeatmapSignal = {
    coldCount: heatmap.summary.coldCount,
    warmCount: heatmap.summary.warmCount,
    hotCount: heatmap.summary.hotCount,
    totalPolicies: heatmap.summary.totalPolicies,
    coveragePercent: heatmap.summary.coveragePercent,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const trendSignal: ObservationLedgerTrendSignal = {
    currentCoveragePercent: trend.summary.currentCoveragePercent,
    previousCoveragePercent: trend.summary.previousCoveragePercent,
    coverageDelta: trend.summary.coverageDelta,
    trendDirection: trend.summary.trendDirection,
    comparedSnapshotCount: trend.summary.comparedSnapshotCount,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const exposureSignal: ObservationLedgerExposureSignal = {
    exposureScore: exposure.summary.exposureScore,
    exposureGrade: exposure.summary.exposureGrade,
    totalWritePolicies: exposure.summary.totalWritePolicies,
    unobservedWritePolicies: exposure.summary.unobservedWritePolicies,
    rarelyObservedWritePolicies: exposure.summary.rarelyObservedWritePolicies,
    wellObservedWritePolicies: exposure.summary.wellObservedWritePolicies,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const governanceSignal: ObservationLedgerGovernanceSignal = {
    governanceScore: scorecard.governanceScore,
    governanceGrade: scorecard.governanceGrade,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const probeSignal: ObservationLedgerProbeSignal = {
    allProbesPassed: probe.summary.allProbesPassed,
    passedProbeCount: probe.summary.passedProbeCount,
    failedProbeCount: probe.summary.failedProbeCount,
    totalProbes: probe.summary.totalProbes,
    totalProbeTimeMs: probe.summary.totalProbeTimeMs,
    fastestProbeMs: probe.summary.fastestProbeMs,
    slowestProbeMs: probe.summary.slowestProbeMs,
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    ledgerId,
    generatedAt,
    summary,
    compliance: complianceSignal,
    heatmap: heatmapSignal,
    trend: trendSignal,
    exposure: exposureSignal,
    governance: governanceSignal,
    probe: probeSignal,
    validationProbe: validationProbeSignal,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
