// Workspace UI Index — Phase 135
// Deterministic navigation manifest for all active UI-layer API endpoints.
// Static endpoint registry only — no runtime scanning, no persistence reads,
// no mutation paths, no HTML/CSS/JSX/React, no rendering engines.
// No init(). No subsystem. No health check. No persistence.
// All versions are static constants matching the frozen nucleus state.
// executionBlocked: true on root and every UIIndexEndpoint entry.

const EXECUTION_BLOCKED: true = true;
const INDEX_VERSION = "1" as const;

// ---------------------------------------------------------------------------
// Type definitions
// ---------------------------------------------------------------------------

export type UIIndexCategory =
  | "render_model"
  | "skeleton"
  | "coherence"
  | "version"
  | "summary"
  | "preview";

export interface UIIndexEndpoint {
  path:             string;
  layerId:          string;
  title:            string;
  description:      string;
  category:         UIIndexCategory;
  stable:           boolean;
  executionBlocked: true;
}

export interface UIIndexVersions {
  uiVersion:        string;
  dashboardVersion: string;
  manifestVersion:  string;
  previewVersion:   string;
  executionBlocked: true;
}

export interface UIIndex {
  generatedAt:    string;
  indexVersion:   typeof INDEX_VERSION;
  totalEndpoints: number;
  uiVersions:     UIIndexVersions;
  endpoints:      UIIndexEndpoint[];
  executionBlocked: true;
}

// ---------------------------------------------------------------------------
// Static endpoint registry — alphabetical by path (canonical ordering).
// Do not add entries not actively served by the API server.
// Do not expose hidden, internal, or private routes.
// Do not expose secrets, auth tokens, or service credentials.
// ---------------------------------------------------------------------------

const STATIC_ENDPOINTS: readonly UIIndexEndpoint[] = [
  {
    path:        "/api/workspace/ui/coherence",
    layerId:     "ui_coherence_probe",
    title:       "UI Layer Coherence Probe",
    description: "Read-only cross-layer consistency validation between the UI Render Model and the Dashboard Skeleton. Returns violation arrays for widgets, panels, pages, and data bindings. No persistence. No mutation. executionBlocked always true.",
    category:    "coherence",
    stable:      true,
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    path:        "/api/workspace/ui/dashboard-skeleton",
    layerId:     "dashboard_skeleton",
    title:       "Dashboard Skeleton",
    description: "Structured composition blueprint derived from the Visual Shell. Defines shell shape, sidebar, topbar, layout regions, page layouts (5), panel layouts (15), widget layouts (37), and responsive rules. No persistence. No mutation. executionBlocked always true.",
    category:    "skeleton",
    stable:      true,
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    path:        "/api/workspace/ui/preview",
    layerId:     "ui_preview_payload",
    title:       "UI Preview Payload",
    description: "Renderer-safe aggregation of all UI-layer systems into a single preview payload. Includes shellPreview, navigationPreview, pagePreview (5), panelPreview (15), widgetPreview (37), responsivePreview, and healthSummary. No rendering engines. No templated markup. executionBlocked always true.",
    category:    "preview",
    stable:      true,
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    path:        "/api/workspace/ui/render-model",
    layerId:     "ui_render_model",
    title:       "UI Render Model",
    description: "Frontend-safe read-only render model derived from Widget Contracts (37 widgets) and Visual Shell (15 panels). Includes layout, navigation, pages, panels, widgets, themeTokens, dataBindings, and governanceBadges. No HTML generation. No frontend framework code. executionBlocked always true.",
    category:    "render_model",
    stable:      true,
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    path:        "/api/workspace/ui/summary",
    layerId:     "ui_layer_summary",
    title:       "UI Layer Summary",
    description: "Single lightweight aggregation of all UI-layer modules. Reports totalWidgets=37, totalPanels=15, totalPages=5, totalBindings=18, allLayersCoherent, bindingCoveragePercent, schemaHashes, and layer health entries. No persistence reads. executionBlocked always true.",
    category:    "summary",
    stable:      true,
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    path:        "/api/workspace/ui/version",
    layerId:     "ui_layer_version",
    title:       "UI Layer Version Manifest",
    description: "Static deterministic versioning metadata for all UI-layer systems. Pre-computes schemaHashes at module load via sha256 of field descriptors. layerCount=3 (dashboard_skeleton, ui_coherence_probe, ui_render_model). No runtime module reads. executionBlocked always true.",
    category:    "version",
    stable:      true,
    executionBlocked: EXECUTION_BLOCKED,
  },
];

// ---------------------------------------------------------------------------
// Static version constants — mirror frozen nucleus state.
// All versions are "1" and change only on incompatible schema changes.
// Do not derive from runtime modules — this avoids per-request reads.
// ---------------------------------------------------------------------------

const STATIC_UI_VERSIONS: UIIndexVersions = {
  uiVersion:        "1",
  dashboardVersion: "1",
  manifestVersion:  "1",
  previewVersion:   "1",
  executionBlocked: EXECUTION_BLOCKED,
};

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
// Pure static derivation — only generatedAt changes per call.
// No reads from any other module. No persistence. No mutation paths.
// No rendering engines. No HTML/CSS/JSX/React. No hidden routes exposed.
// No secrets exposure. executionBlocked: true on root and every endpoint entry.

export function getUIIndex(): UIIndex {
  return {
    generatedAt:    new Date().toISOString(),
    indexVersion:   INDEX_VERSION,
    totalEndpoints: STATIC_ENDPOINTS.length,
    uiVersions:     STATIC_UI_VERSIONS,
    endpoints:      STATIC_ENDPOINTS as UIIndexEndpoint[],
    executionBlocked: EXECUTION_BLOCKED,
  };
}
