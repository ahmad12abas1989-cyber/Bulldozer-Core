import { SandboxWriteRollbackSnapshotRecord } from "./sandboxWriteRollbackSnapshotCore.js";
import { SandboxWriteAuditRecord }             from "./sandboxWriteAuditCore.js";
import { GuardedSandboxWriteRecord }           from "./guardedSandboxWriteCore.js";
import { WriteGateRecord }                     from "./realWriteEnablementGateCore.js";
import { ControlledExecutionRecord }           from "./controlledExecutionCore.js";
import { randomBytes }                         from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type CommitGateState = "descriptor_commit_gate_ready";

export type CommitEligibilityCheckRule =
  | "rollback_snapshot_exists"
  | "write_audit_exists"
  | "guarded_write_exists"
  | "write_gate_exists"
  | "execution_record_exists"
  | "snapshot_ready"
  | "audit_traceable"
  | "write_gate_ready"
  | "guarded_write_safe"
  | "actual_commit_still_disabled"
  | "output_remains_descriptor_only";

export interface CommitEligibilityCheck {
  readonly rule:   CommitEligibilityCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface CommitBlockedReason {
  readonly reason:          string;
  readonly commitEnabled:   false;
  readonly blockedByPolicy: string;
}

export interface RollbackCommitPlan {
  readonly rollbackRequired:        true;
  readonly rollbackDescriptorOnly:  true;
  readonly rollbackSnapshotBound:   boolean;
  readonly rollbackReady:           boolean;
  readonly commitRollbackTargetState: "descriptor_commit_gate_ready";
  readonly summary:                 string;
}

export interface CommitReadinessReport {
  readonly commitEnabled:            false;
  readonly actualWritesEnabled:      false;
  readonly allEligibilityChecksPassed: boolean;
  readonly blockedReasonCount:       number;
  readonly approvalRequired:         true;
  readonly rollbackReady:            boolean;
  readonly summary:                  string;
}

export interface SandboxWriteCommitGateRecord {
  readonly commitGateId:               string;
  readonly commitState:                CommitGateState;
  readonly approvalRequired:           true;
  readonly actualWritesEnabled:        false;
  readonly commitEnabled:              false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly rollbackRequired:           true;
  readonly implementationPhase:        "descriptor_only";
  readonly rollbackSnapshotId:         string;
  readonly writeAuditId:               string;
  readonly guardedWriteId:             string;
  readonly writeGateId:                string;
  readonly executionRecordId:          string;
  readonly approvalReference:          string;
  readonly commitEligibilityChecks:    readonly CommitEligibilityCheck[];
  readonly commitBlockedReasons:       readonly CommitBlockedReason[];
  readonly commitReadinessReport:      CommitReadinessReport;
  readonly rollbackCommitPlan:         RollbackCommitPlan;
  readonly createdAt:                  string;
}

export interface CreateCommitGateInput {
  readonly snapshotRecord:     SandboxWriteRollbackSnapshotRecord;
  readonly auditRecord:        SandboxWriteAuditRecord;
  readonly guardedWriteRecord: GuardedSandboxWriteRecord;
  readonly writeGateRecord:    WriteGateRecord;
  readonly executionRecord:    ControlledExecutionRecord;
}

export interface SandboxWriteCommitGateSummary {
  readonly total:                      number;
  readonly byState:                    Record<CommitGateState, number>;
  readonly actualWritesEnabled:        false;
  readonly commitEnabled:              false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly approvalRequired:           true;
  readonly rollbackRequired:           true;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildEligibilityChecks(
  input: CreateCommitGateInput,
): readonly CommitEligibilityCheck[] {
  const { snapshotRecord, auditRecord, guardedWriteRecord, writeGateRecord, executionRecord } = input;

  const snapshotReady  = snapshotRecord.snapshotReadinessReport.allChecksPass;
  const auditTraceable = auditRecord.traceabilityReport.allChecksPass;
  const gateReady      = writeGateRecord.writeReadinessReport.allChecksPass;
  const guardedSafe    = guardedWriteRecord.writeSafetyChecks.every(c => c.passed);
  const rollbackReady  =
    snapshotRecord.snapshotReadinessReport.rollbackReady &&
    auditRecord.traceabilityReport.rollbackReady &&
    guardedWriteRecord.rollbackWriteReport.rollbackReady &&
    writeGateRecord.writeReadinessReport.rollbackReady;

  return [
    {
      rule:   "rollback_snapshot_exists",
      passed: snapshotRecord.rollbackSnapshotId.length > 0,
      detail: "Rollback snapshot record is present and valid",
    },
    {
      rule:   "write_audit_exists",
      passed: auditRecord.writeAuditId.length > 0,
      detail: "Sandbox write audit record is present and valid",
    },
    {
      rule:   "guarded_write_exists",
      passed: guardedWriteRecord.guardedWriteId.length > 0,
      detail: "Guarded sandbox write record is present and valid",
    },
    {
      rule:   "write_gate_exists",
      passed: writeGateRecord.writeGateId.length > 0,
      detail: "Write enablement gate record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "snapshot_ready",
      passed: snapshotReady,
      detail: snapshotReady
        ? "Rollback snapshot allChecksPass=true — snapshot layer is ready"
        : "Rollback snapshot checks have not all passed — commit gate blocked",
    },
    {
      rule:   "audit_traceable",
      passed: auditTraceable,
      detail: auditTraceable
        ? "Write audit traceabilityReport.allChecksPass=true — audit layer is traceable"
        : "Write audit traceability checks have not all passed — commit gate blocked",
    },
    {
      rule:   "write_gate_ready",
      passed: gateReady,
      detail: gateReady
        ? "Write gate writeReadinessReport.allChecksPass=true — gate layer is ready"
        : "Write gate readiness checks have not all passed — commit gate blocked",
    },
    {
      rule:   "guarded_write_safe",
      passed: guardedSafe,
      detail: guardedSafe
        ? "Guarded write safety checks all passed — guarded write layer is safe"
        : "One or more guarded write safety checks have not passed — commit gate blocked",
    },
    {
      rule:   "actual_commit_still_disabled",
      passed: true,
      detail: "commitEnabled=false confirmed — no actual write commit occurs at this phase",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback readiness confirmed across all four upstream records — commit gate descriptor is valid"
        : "Rollback readiness not fully confirmed across upstream records — commit gate descriptor blocked",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly CommitEligibilityCheck[],
): readonly CommitBlockedReason[] {
  const staticReasons: CommitBlockedReason[] = [
    {
      reason:          "Actual write commits are disabled at this phase — commitEnabled=false is a compile-time invariant",
      commitEnabled:   false,
      blockedByPolicy: "descriptor_commit_gate_ready phase policy",
    },
    {
      reason:          "Operator approval required before any commit can be enabled — approvalRequired=true",
      commitEnabled:   false,
      blockedByPolicy: "approval_required_policy",
    },
    {
      reason:          "Filesystem mutation blocked — filesystemMutationBlocked=true across all write layers",
      commitEnabled:   false,
      blockedByPolicy: "filesystem_mutation_blocked_policy",
    },
  ];
  const failedChecks = checks
    .filter(c => !c.passed)
    .map(c => ({
      reason:          `Eligibility check failed: ${c.rule} — ${c.detail}`,
      commitEnabled:   false as const,
      blockedByPolicy: `eligibility_check_policy:${c.rule}`,
    }));
  return [...staticReasons, ...failedChecks];
}

function buildReadinessReport(
  checks: readonly CommitEligibilityCheck[],
  blocked: readonly CommitBlockedReason[],
): CommitReadinessReport {
  const allPassed = checks.every(c => c.passed);
  const rollbackCheck = checks.find(c => c.rule === "output_remains_descriptor_only");
  const rollbackReady = rollbackCheck?.passed ?? false;
  return {
    commitEnabled:              false,
    actualWritesEnabled:        false,
    allEligibilityChecksPassed: allPassed,
    blockedReasonCount:         blocked.length,
    approvalRequired:           true,
    rollbackReady,
    summary: allPassed
      ? "Commit gate descriptor ready — all eligibility checks passed, rollback readiness confirmed across four upstream records; actual commit remains disabled pending operator approval and explicit future enablement"
      : "Commit gate descriptor blocked — one or more eligibility checks failed; all actual write commits remain disabled",
  };
}

function buildRollbackCommitPlan(
  checks: readonly CommitEligibilityCheck[],
  snapshotRecord: SandboxWriteRollbackSnapshotRecord,
): RollbackCommitPlan {
  const rollbackReady = checks.every(c => c.passed);
  return {
    rollbackRequired:           true,
    rollbackDescriptorOnly:     true,
    rollbackSnapshotBound:      snapshotRecord.rollbackSnapshotId.length > 0,
    rollbackReady,
    commitRollbackTargetState:  "descriptor_commit_gate_ready",
    summary: rollbackReady
      ? "Rollback commit plan ready — bound to rollback snapshot, all eligibility checks passed, descriptor-only; no filesystem mutation will occur if commit is rolled back"
      : "Rollback commit plan incomplete — eligibility checks must all pass before rollback plan is considered ready",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const commitGateStore = new Map<string, SandboxWriteCommitGateRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createCommitGateRecord(
  input: CreateCommitGateInput,
): { ok: true; record: SandboxWriteCommitGateRecord } {
  const commitGateId    = randomBytes(16).toString("hex");
  const checks          = buildEligibilityChecks(input);
  const blocked         = buildBlockedReasons(checks);
  const readiness       = buildReadinessReport(checks, blocked);
  const rollbackPlan    = buildRollbackCommitPlan(checks, input.snapshotRecord);

  const record: SandboxWriteCommitGateRecord = {
    commitGateId,
    commitState:               "descriptor_commit_gate_ready",
    approvalRequired:          true,
    actualWritesEnabled:       false,
    commitEnabled:             false,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
    rollbackRequired:          true,
    implementationPhase:       "descriptor_only",
    rollbackSnapshotId:        input.snapshotRecord.rollbackSnapshotId,
    writeAuditId:              input.auditRecord.writeAuditId,
    guardedWriteId:            input.guardedWriteRecord.guardedWriteId,
    writeGateId:               input.writeGateRecord.writeGateId,
    executionRecordId:         input.executionRecord.controlledExecutionId,
    approvalReference:         input.guardedWriteRecord.approvalReference,
    commitEligibilityChecks:   checks,
    commitBlockedReasons:      blocked,
    commitReadinessReport:     readiness,
    rollbackCommitPlan:        rollbackPlan,
    createdAt:                 new Date().toISOString(),
  };

  commitGateStore.set(commitGateId, record);
  return { ok: true, record };
}

export function listCommitGateRecords(): readonly SandboxWriteCommitGateRecord[] {
  return [...commitGateStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getCommitGateSummary(): SandboxWriteCommitGateSummary {
  const records = listCommitGateRecords();
  return {
    total:                     records.length,
    byState:                   { descriptor_commit_gate_ready: records.length },
    actualWritesEnabled:       false,
    commitEnabled:             false,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
    approvalRequired:          true,
    rollbackRequired:          true,
  };
}
