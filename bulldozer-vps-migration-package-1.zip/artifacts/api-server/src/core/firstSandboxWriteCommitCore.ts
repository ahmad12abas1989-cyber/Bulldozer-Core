// firstSandboxWriteCommitCore.ts
// Phase 321 — First Sandbox Write Commit Descriptor Core Skeleton
// In-memory first sandbox write commit descriptor engine.
// Layer 26 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor stack.
// Defines the first sandbox write commit descriptor.
// Preserves sandbox-approved-only target scope from layers 24–25.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. commitEnabled=false — commit has not been enabled.
// sandboxWriteCommitPrepared=true — descriptor-readiness established for a future sandbox write commit enable phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { RuntimeWriteExecutorRecord }               from "./runtimeWriteExecutorCore.js";
import type { FirstActualSandboxWriteOperationRecord }   from "./firstActualSandboxWriteOperationCore.js";
import type { ActualSandboxWriteExecutionGateRecord }    from "./actualSandboxWriteExecutionGateCore.js";
import type { FirstScopedSandboxWriteActivationRecord }  from "./firstScopedSandboxWriteActivationCore.js";
import type { ActualSandboxWritePermissionGateRecord }   from "./actualSandboxWritePermissionGateCore.js";
import type { ControlledExecutionRecord }                from "./controlledExecutionCore.js";
import { randomUUID }                                    from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type SandboxWriteCommitState = "descriptor_sandbox_write_commit_pending";

export type CommitSafetyCheckRule =
  | "runtime_write_executor_exists"
  | "actual_write_operation_exists"
  | "execution_gate_exists"
  | "scoped_activation_exists"
  | "write_permission_gate_exists"
  | "execution_record_exists"
  | "executor_bound_to_write_operation"
  | "write_operation_bound_to_execution_gate"
  | "execution_gate_bound_to_scoped_activation"
  | "scoped_activation_bound_to_permission_gate"
  | "commit_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface CommitSafetyCheck {
  readonly rule: CommitSafetyCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface CommitPlanEntry {
  readonly planEntryId:    string;
  readonly targetScope:    "sandbox_approved_only";
  readonly operationType:  "descriptor_commit_planned";
  readonly commitEnabled:  false;
  readonly mutationBlocked: true;
  readonly planNote:       string;
}

export interface CommitBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedCommitReference {
  readonly runtimeWriteExecutorId:       string;
  readonly actualWriteOperationId:       string;
  readonly writeExecutionGateId:         string;
  readonly scopedWriteActivationId:      string;
  readonly rollbackSnapshotId:           string;
  readonly sandboxWriteCommitPrepared:   true;
  readonly sandboxWriteCommitEnabled:    false;
  readonly runtimeWriteExecutorEnabled:  false;
  readonly actualWritesEnabled:          false;
  readonly rollbackChainValid:           boolean;
  readonly referenceNote:                string;
}

export interface CommitReadinessReport {
  readonly sandboxWriteCommitPrepared:   true;
  readonly sandboxWriteCommitEnabled:    false;
  readonly runtimeWriteExecutorEnabled:  false;
  readonly writeExecutionGateEnabled:    false;
  readonly scopedActivationEnabled:      false;
  readonly writePermissionEnabled:       false;
  readonly mutationSwitchEnabled:        false;
  readonly guardedWriteEnabled:          false;
  readonly actualWritesEnabled:          false;
  readonly realWritesEnabled:            false;
  readonly approvalRequired:             true;
  readonly allChecksPass:                boolean;
  readonly blockedReasonCount:           number;
  readonly rollbackChainValid:           boolean;
  readonly summary:                      string;
}

export interface FirstSandboxWriteCommitRecord {
  readonly sandboxWriteCommitId:         string;
  readonly commitState:                  SandboxWriteCommitState;
  readonly approvalRequired:             true;
  readonly sandboxWriteCommitPrepared:   true;
  readonly sandboxWriteCommitEnabled:    false;
  readonly runtimeWriteExecutorEnabled:  false;
  readonly actualWritesEnabled:          false;
  readonly filesystemMutationBlocked:    true;
  readonly motherCoreMutationBlocked:    true;
  readonly vaultMutationBlocked:         true;
  readonly shellBlocked:                 true;
  readonly networkBlocked:               true;
  readonly implementationPhase:          "descriptor_only";
  readonly runtimeWriteExecutorId:       string;
  readonly actualWriteOperationId:       string;
  readonly writeExecutionGateId:         string;
  readonly scopedWriteActivationId:      string;
  readonly writePermissionGateId:        string;
  readonly controlledExecutionId:        string;
  readonly commitPlan:                   readonly CommitPlanEntry[];
  readonly commitSafetyChecks:           readonly CommitSafetyCheck[];
  readonly commitBlockedReasons:         readonly CommitBlockedReason[];
  readonly linkedCommitReference:        LinkedCommitReference;
  readonly commitReadinessReport:        CommitReadinessReport;
  readonly createdAt:                    string;
}

export interface CreateFirstSandboxWriteCommitInput {
  readonly executorRecord:            RuntimeWriteExecutorRecord;
  readonly writeOperationRecord:      FirstActualSandboxWriteOperationRecord;
  readonly writeExecutionGateRecord:  ActualSandboxWriteExecutionGateRecord;
  readonly scopedActivationRecord:    FirstScopedSandboxWriteActivationRecord;
  readonly writePermissionGateRecord: ActualSandboxWritePermissionGateRecord;
  readonly executionRecord:           ControlledExecutionRecord;
}

export interface FirstSandboxWriteCommitSummary {
  readonly total:                      number;
  readonly byState:                    Record<SandboxWriteCommitState, number>;
  readonly sandboxWriteCommitPrepared: true;
  readonly sandboxWriteCommitEnabled:  false;
  readonly runtimeWriteExecutorEnabled: false;
  readonly actualWritesEnabled:        false;
  readonly approvalRequired:           true;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly commitState:                SandboxWriteCommitState;
  readonly implementationPhase:        "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstSandboxWriteCommitRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildSafetyChecks(input: CreateFirstSandboxWriteCommitInput): readonly CommitSafetyCheck[] {
  const { executorRecord, writeOperationRecord, writeExecutionGateRecord, scopedActivationRecord, writePermissionGateRecord, executionRecord } = input;

  const execExists   = executorRecord.runtimeWriteExecutorId.length > 0;
  const opExists     = writeOperationRecord.actualWriteOperationId.length > 0;
  const gateExists   = writeExecutionGateRecord.writeExecutionGateId.length > 0;
  const scopedExists = scopedActivationRecord.scopedWriteActivationId.length > 0;
  const permExists   = writePermissionGateRecord.writePermissionGateId.length > 0;
  const ctrlExists   = executionRecord.controlledExecutionId.length > 0;

  const executorBound = executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId;
  const opBound       = writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId;
  const gateBound     = writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId;
  const scopedBound   = scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId;

  return [
    {
      rule: "runtime_write_executor_exists",
      pass: execExists,
      note: execExists
        ? `runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`
        : "executorRecord.runtimeWriteExecutorId is empty",
    },
    {
      rule: "actual_write_operation_exists",
      pass: opExists,
      note: opExists
        ? `actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`
        : "writeOperationRecord.actualWriteOperationId is empty",
    },
    {
      rule: "execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`
        : "writeExecutionGateRecord.writeExecutionGateId is empty",
    },
    {
      rule: "scoped_activation_exists",
      pass: scopedExists,
      note: scopedExists
        ? `scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`
        : "scopedActivationRecord.scopedWriteActivationId is empty",
    },
    {
      rule: "write_permission_gate_exists",
      pass: permExists,
      note: permExists
        ? `writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`
        : "writePermissionGateRecord.writePermissionGateId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "executor_bound_to_write_operation",
      pass: executorBound,
      note: executorBound
        ? `executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId (${writeOperationRecord.actualWriteOperationId})`
        : `executor/write-operation mismatch: executor.actualWriteOperationId=${executorRecord.actualWriteOperationId} vs op.actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`,
    },
    {
      rule: "write_operation_bound_to_execution_gate",
      pass: opBound,
      note: opBound
        ? `writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId (${writeExecutionGateRecord.writeExecutionGateId})`
        : `write-operation/execution-gate mismatch: op.writeExecutionGateId=${writeOperationRecord.writeExecutionGateId} vs gate.writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`,
    },
    {
      rule: "execution_gate_bound_to_scoped_activation",
      pass: gateBound,
      note: gateBound
        ? `writeExecutionGateRecord.scopedWriteActivationId === scopedActivationRecord.scopedWriteActivationId (${scopedActivationRecord.scopedWriteActivationId})`
        : `execution-gate/scoped-activation mismatch: gate.scopedWriteActivationId=${writeExecutionGateRecord.scopedWriteActivationId} vs scoped.scopedWriteActivationId=${scopedActivationRecord.scopedWriteActivationId}`,
    },
    {
      rule: "scoped_activation_bound_to_permission_gate",
      pass: scopedBound,
      note: scopedBound
        ? `scopedActivationRecord.writePermissionGateId === writePermissionGateRecord.writePermissionGateId (${writePermissionGateRecord.writePermissionGateId})`
        : `scoped-activation/permission-gate mismatch: scoped.writePermissionGateId=${scopedActivationRecord.writePermissionGateId} vs gate.writePermissionGateId=${writePermissionGateRecord.writePermissionGateId}`,
    },
    {
      rule: "commit_still_disabled",
      pass: true,
      note: "sandboxWriteCommitEnabled=false — compile-time literal; no commit enable phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "commitState=descriptor_sandbox_write_commit_pending — output is a descriptor only; sandbox write commit is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(checks: readonly CommitSafetyCheck[]): readonly CommitBlockedReason[] {
  const staticReasons: CommitBlockedReason[] = [
    { code: "commit_disabled",        reason: "sandboxWriteCommitEnabled=false — compile-time literal; an explicit sandbox write commit enable phase must activate the commit before any sandbox write target can be touched",                                                                                                                                   static: true },
    { code: "approval_required",      reason: "approvalRequired=true — explicit operator approval is required before the sandbox write commit can be enabled",                                                                                                                                                                                                static: true },
    { code: "actual_writes_disabled", reason: "actualWritesEnabled=false — compile-time literal across all 26 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, and runtime-write-executor layers", static: true },
  ];
  const dynamicReasons: CommitBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedCommitReference(
  input: CreateFirstSandboxWriteCommitInput,
  rollbackChainValid: boolean,
): LinkedCommitReference {
  const { executorRecord, writeOperationRecord, writeExecutionGateRecord, scopedActivationRecord } = input;
  return {
    runtimeWriteExecutorId:       executorRecord.runtimeWriteExecutorId,
    actualWriteOperationId:       writeOperationRecord.actualWriteOperationId,
    writeExecutionGateId:         writeExecutionGateRecord.writeExecutionGateId,
    scopedWriteActivationId:      scopedActivationRecord.scopedWriteActivationId,
    rollbackSnapshotId:           executorRecord.linkedExecutorReference.rollbackSnapshotId,
    sandboxWriteCommitPrepared:   true,
    sandboxWriteCommitEnabled:    false,
    runtimeWriteExecutorEnabled:  false,
    actualWritesEnabled:          false,
    rollbackChainValid,
    referenceNote: "linked commit reference sources rollbackSnapshotId from executorRecord.linkedExecutorReference; sandbox write commit disabled; runtime write executor disabled; filesystem mutation blocked; descriptor-only",
  };
}

function buildCommitPlan(): readonly CommitPlanEntry[] {
  return [
    {
      planEntryId:   randomUUID(),
      targetScope:   "sandbox_approved_only",
      operationType: "descriptor_commit_planned",
      commitEnabled: false,
      mutationBlocked: true,
      planNote:      "Commit plan inherits sandbox_approved_only target scope from layers 24–25 write operation and executor plans. Commit disabled. No filesystem mutation until an explicit sandbox write commit enable phase activates the commit. descriptor_sandbox_write_commit_pending state — plan captured as descriptor only.",
    },
  ];
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstSandboxWriteCommitRecord(
  input: CreateFirstSandboxWriteCommitInput,
): FirstSandboxWriteCommitRecord {
  const { executorRecord, writeOperationRecord, writeExecutionGateRecord, scopedActivationRecord, writePermissionGateRecord, executionRecord } = input;

  const checks = buildSafetyChecks(input);

  const rollbackChainValid = executorRecord.executorReadinessReport.rollbackChainValid;

  const allChecksPass  = checks.every((c) => c.pass);
  const blockedReasons = buildBlockedReasons(checks);
  const linkedRef      = buildLinkedCommitReference(input, rollbackChainValid);
  const plan           = buildCommitPlan();

  const commitReadinessReport: CommitReadinessReport = {
    sandboxWriteCommitPrepared:   true,
    sandboxWriteCommitEnabled:    false,
    runtimeWriteExecutorEnabled:  false,
    writeExecutionGateEnabled:    false,
    scopedActivationEnabled:      false,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    summary: `commitState=descriptor_sandbox_write_commit_pending; sandboxWriteCommitEnabled=false; runtimeWriteExecutorEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstSandboxWriteCommitRecord = {
    sandboxWriteCommitId:          randomUUID(),
    commitState:                   "descriptor_sandbox_write_commit_pending",
    approvalRequired:              true,
    sandboxWriteCommitPrepared:    true,
    sandboxWriteCommitEnabled:     false,
    runtimeWriteExecutorEnabled:   false,
    actualWritesEnabled:           false,
    filesystemMutationBlocked:     true,
    motherCoreMutationBlocked:     true,
    vaultMutationBlocked:          true,
    shellBlocked:                  true,
    networkBlocked:                true,
    implementationPhase:           "descriptor_only",
    runtimeWriteExecutorId:        executorRecord.runtimeWriteExecutorId,
    actualWriteOperationId:        writeOperationRecord.actualWriteOperationId,
    writeExecutionGateId:          writeExecutionGateRecord.writeExecutionGateId,
    scopedWriteActivationId:       scopedActivationRecord.scopedWriteActivationId,
    writePermissionGateId:         writePermissionGateRecord.writePermissionGateId,
    controlledExecutionId:         executionRecord.controlledExecutionId,
    commitPlan:                    plan,
    commitSafetyChecks:            checks,
    commitBlockedReasons:          blockedReasons,
    linkedCommitReference:         linkedRef,
    commitReadinessReport,
    createdAt:                     new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstSandboxWriteCommitRecords(): readonly FirstSandboxWriteCommitRecord[] {
  return _store.slice();
}

export function getFirstSandboxWriteCommitSummary(): FirstSandboxWriteCommitSummary {
  return {
    total:                         _store.length,
    byState:                       { descriptor_sandbox_write_commit_pending: _store.length },
    sandboxWriteCommitPrepared:    true,
    sandboxWriteCommitEnabled:     false,
    runtimeWriteExecutorEnabled:   false,
    actualWritesEnabled:           false,
    approvalRequired:              true,
    filesystemMutationBlocked:     true,
    motherCoreMutationBlocked:     true,
    commitState:                   "descriptor_sandbox_write_commit_pending",
    implementationPhase:           "descriptor_only",
  };
}
