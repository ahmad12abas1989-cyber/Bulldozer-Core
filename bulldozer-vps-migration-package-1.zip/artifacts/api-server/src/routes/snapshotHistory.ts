import type { IncomingMessage, ServerResponse } from "node:http";
import { listPersistedSnapshots } from "../core/snapshotStorage";
import { sendJson } from "../lib/response";

export function handleSnapshotHistory(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, listPersistedSnapshots());
}
