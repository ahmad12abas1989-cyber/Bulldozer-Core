// Workspace UI Layer Coherence Probe — Phase 131
// Read-only validation: verifies internal consistency between the UI Render Model
// layer and the Dashboard Skeleton layer.
// No persistence, no mutation, no HTML/CSS/JSX, no rendering engines.
// Pure cross-layer derivation — deterministic shape, bounded output.

import { getUIRenderModel } from "./workspaceUIRenderModel";
import { getDashboardSkeleton } from "./workspaceDashboardSkeleton";

const EXECUTION_BLOCKED: true = true;

// ---------------------------------------------------------------------------
// Type definitions
// ---------------------------------------------------------------------------

export type WidgetViolationType = "missing_in_render_model" | "duplicate_in_skeleton";
export type PanelViolationType  = "missing_in_render_model" | "duplicate_in_skeleton";
export type PageViolationType   = "missing_in_render_model" | "duplicate_in_skeleton";
export type BindingViolationType = "no_widget_coverage";

export interface WidgetViolation {
  widgetId: string;
  violationType: WidgetViolationType;
  detail: string;
  executionBlocked: true;
}

export interface PanelViolation {
  panelId: string;
  violationType: PanelViolationType;
  detail: string;
  executionBlocked: true;
}

export interface PageViolation {
  pageId: string;
  violationType: PageViolationType;
  detail: string;
  executionBlocked: true;
}

export interface BindingViolation {
  sourceEndpoint: string;
  violationType: BindingViolationType;
  detail: string;
  executionBlocked: true;
}

export interface BindingCoverage {
  totalBindings: number;
  coveredBindings: number;
  uncoveredBindings: number;
  coveragePercent: number;
  executionBlocked: true;
}

export interface UICoherenceResult {
  generatedAt: string;
  uiVersion: string;
  dashboardVersion: string;
  allWidgetsCoherent: boolean;
  allPanelsCoherent: boolean;
  allPagesCoherent: boolean;
  bindingCoverage: BindingCoverage;
  widgetViolations: WidgetViolation[];
  panelViolations: PanelViolation[];
  pageViolations: PageViolation[];
  bindingViolations: BindingViolation[];
  executionBlocked: true;
}

// ---------------------------------------------------------------------------
// Validation helpers
// ---------------------------------------------------------------------------

function validateWidgets(
  skeletonWidgetIds: string[],
  renderModelWidgetIdSet: Set<string>,
): WidgetViolation[] {
  const violations: WidgetViolation[] = [];
  const seen = new Set<string>();

  for (const widgetId of skeletonWidgetIds) {
    if (seen.has(widgetId)) {
      violations.push({
        widgetId,
        violationType: "duplicate_in_skeleton",
        detail: `widgetId "${widgetId}" appears more than once in dashboard skeleton widgetLayouts`,
        executionBlocked: EXECUTION_BLOCKED,
      });
    } else {
      seen.add(widgetId);
      if (!renderModelWidgetIdSet.has(widgetId)) {
        violations.push({
          widgetId,
          violationType: "missing_in_render_model",
          detail: `widgetId "${widgetId}" is present in dashboard skeleton but not found in UI render model widgets`,
          executionBlocked: EXECUTION_BLOCKED,
        });
      }
    }
  }

  return violations.sort((a, b) => a.widgetId.localeCompare(b.widgetId));
}

function validatePanels(
  skeletonPanelIds: string[],
  renderModelPanelIdSet: Set<string>,
): PanelViolation[] {
  const violations: PanelViolation[] = [];
  const seen = new Set<string>();

  for (const panelId of skeletonPanelIds) {
    if (seen.has(panelId)) {
      violations.push({
        panelId,
        violationType: "duplicate_in_skeleton",
        detail: `panelId "${panelId}" appears more than once in dashboard skeleton panelLayouts`,
        executionBlocked: EXECUTION_BLOCKED,
      });
    } else {
      seen.add(panelId);
      if (!renderModelPanelIdSet.has(panelId)) {
        violations.push({
          panelId,
          violationType: "missing_in_render_model",
          detail: `panelId "${panelId}" is present in dashboard skeleton but not found in UI render model panels`,
          executionBlocked: EXECUTION_BLOCKED,
        });
      }
    }
  }

  return violations.sort((a, b) => a.panelId.localeCompare(b.panelId));
}

function validatePages(
  skeletonPageIds: string[],
  renderModelPageIdSet: Set<string>,
): PageViolation[] {
  const violations: PageViolation[] = [];
  const seen = new Set<string>();

  for (const pageId of skeletonPageIds) {
    if (seen.has(pageId)) {
      violations.push({
        pageId,
        violationType: "duplicate_in_skeleton",
        detail: `pageId "${pageId}" appears more than once in dashboard skeleton pageLayouts`,
        executionBlocked: EXECUTION_BLOCKED,
      });
    } else {
      seen.add(pageId);
      if (!renderModelPageIdSet.has(pageId)) {
        violations.push({
          pageId,
          violationType: "missing_in_render_model",
          detail: `pageId "${pageId}" is present in dashboard skeleton but not found in UI render model pages`,
          executionBlocked: EXECUTION_BLOCKED,
        });
      }
    }
  }

  return violations.sort((a, b) => a.pageId.localeCompare(b.pageId));
}

function validateBindingCoverage(
  bindingEndpoints: string[],
  widgetEndpointSet: Set<string>,
): BindingViolation[] {
  // Each data binding sourceEndpoint must be referenced by at least one widget
  // that appears in the dashboard skeleton (via the render model widget map).
  const violations: BindingViolation[] = [];

  for (const ep of bindingEndpoints) {
    if (!widgetEndpointSet.has(ep)) {
      violations.push({
        sourceEndpoint: ep,
        violationType: "no_widget_coverage",
        detail: `dataBinding sourceEndpoint "${ep}" has no corresponding widget in the dashboard skeleton widgetLayouts`,
        executionBlocked: EXECUTION_BLOCKED,
      });
    }
  }

  return violations.sort((a, b) => a.sourceEndpoint.localeCompare(b.sourceEndpoint));
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
// Pure read-only coherence probe. No HTML, no CSS, no JSX, no rendering engines.
// No persistence reads, no runtime mutation, no dynamic scanning outside
// render-model + dashboard-skeleton.
// Canonical alphabetical ordering for all violation arrays.
// executionBlocked: true at every level.

export function getUICoherence(): UICoherenceResult {
  const renderModel = getUIRenderModel();
  const skeleton    = getDashboardSkeleton();

  // --- Build render model index sets ---
  const rmWidgetIdSet = new Set(renderModel.widgets.map((w) => w.widgetId));
  const rmPanelIdSet  = new Set(renderModel.panels.map((p) => p.panelId));
  const rmPageIdSet   = new Set(renderModel.pages.map((p) => p.pageId));

  // widgetId → sourceEndpoint from render model widgets
  const rmWidgetEndpointMap = new Map<string, string>(
    renderModel.widgets.map((w) => [w.widgetId, w.sourceEndpoint]),
  );

  // --- Skeleton ID lists ---
  const skeletonWidgetIds = skeleton.widgetLayouts.map((w) => w.widgetId);
  const skeletonPanelIds  = skeleton.panelLayouts.map((p) => p.panelId);
  const skeletonPageIds   = skeleton.pageLayouts.map((p) => p.pageId);

  // --- Binding coverage: build set of sourceEndpoints reachable from skeleton widgets ---
  // A binding is "covered" if at least one skeleton widgetId maps (via the render model)
  // to that binding's sourceEndpoint.
  const skeletonReachableEndpoints = new Set<string>();
  for (const widgetId of skeletonWidgetIds) {
    const ep = rmWidgetEndpointMap.get(widgetId);
    if (ep !== undefined) {
      skeletonReachableEndpoints.add(ep);
    }
  }

  const bindingEndpoints = renderModel.dataBindings.map((b) => b.sourceEndpoint);

  // --- Run validations ---
  const widgetViolations  = validateWidgets(skeletonWidgetIds, rmWidgetIdSet);
  const panelViolations   = validatePanels(skeletonPanelIds, rmPanelIdSet);
  const pageViolations    = validatePages(skeletonPageIds, rmPageIdSet);
  const bindingViolations = validateBindingCoverage(bindingEndpoints, skeletonReachableEndpoints);

  // --- Binding coverage metrics ---
  const totalBindings    = bindingEndpoints.length;
  const uncoveredBindings = bindingViolations.length;
  const coveredBindings   = totalBindings - uncoveredBindings;
  const coveragePercent   = totalBindings === 0
    ? 100
    : Math.round((coveredBindings / totalBindings) * 10000) / 100;

  return {
    generatedAt:       new Date().toISOString(),
    uiVersion:         renderModel.uiVersion,
    dashboardVersion:  skeleton.dashboardVersion,
    allWidgetsCoherent: widgetViolations.length  === 0,
    allPanelsCoherent:  panelViolations.length   === 0,
    allPagesCoherent:   pageViolations.length    === 0,
    bindingCoverage: {
      totalBindings,
      coveredBindings,
      uncoveredBindings,
      coveragePercent,
      executionBlocked: EXECUTION_BLOCKED,
    },
    widgetViolations,
    panelViolations,
    pageViolations,
    bindingViolations,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
