import { randomBytes } from "node:crypto";
import { logger } from "../lib/logger";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";

export type TaskStatus = "queued" | "blocked";

export interface Task {
  id: string;
  type: string;
  status: TaskStatus;
  payload: unknown;
  metadata: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
  blockedReason?: string;
}

export interface TaskQueueState {
  totalTasks: number;
  queuedTasks: number;
  blockedTasks: number;
  completedTasks: 0;
  failedTasks: 0;
  executionBlocked: true;
  lastTaskCreatedAt: string | null;
  lastBlockedAt: string | null;
}

const EXECUTION_BLOCKED: true = true;

const tasks = new Map<string, Task>();
let totalTasks = 0;
let lastTaskCreatedAt: string | null = null;
let lastBlockedAt: string | null = null;

export function createTask(
  type: string,
  payload: unknown = {},
  metadata: Record<string, unknown> = {},
): Task {
  const now = new Date().toISOString();
  const id = randomBytes(8).toString("hex");

  const task: Task = {
    id,
    type,
    status: "queued",
    payload,
    metadata,
    createdAt: now,
    updatedAt: now,
  };

  tasks.set(id, task);
  totalTasks++;
  lastTaskCreatedAt = now;

  emit("task_queue:task_created", "task-queue", { id, type, status: "queued" });

  if (totalTasks === 1) {
    addTimelineEvent({
      level: "info",
      source: "task-queue",
      message: "First task created in queue",
      metadata: { id, type },
    });
  }

  logger.info({ id, type, status: "queued", executionBlocked: EXECUTION_BLOCKED }, "Task created (execution blocked)");
  return task;
}

export function markTaskQueued(taskId: string): Task | undefined {
  const task = tasks.get(taskId);
  if (!task) return undefined;

  const now = new Date().toISOString();
  task.status = "queued";
  task.updatedAt = now;
  delete task.blockedReason;

  emit("task_queue:task_queued", "task-queue", { id: taskId, type: task.type });
  logger.info({ id: taskId, type: task.type }, "Task marked queued");
  return task;
}

export function markTaskBlocked(taskId: string, reason: string): Task | undefined {
  const task = tasks.get(taskId);
  if (!task) return undefined;

  const now = new Date().toISOString();
  task.status = "blocked";
  task.blockedReason = reason;
  task.updatedAt = now;
  lastBlockedAt = now;

  emit("task_queue:task_blocked", "task-queue", { id: taskId, type: task.type, reason });
  logger.warn({ id: taskId, type: task.type, reason }, "Task marked blocked");
  return task;
}

export function importTask(task: Task): void {
  tasks.set(task.id, task);
  totalTasks++;
  if (!lastTaskCreatedAt || task.createdAt > lastTaskCreatedAt) {
    lastTaskCreatedAt = task.createdAt;
  }
  if (task.status === "blocked" && (!lastBlockedAt || task.updatedAt > lastBlockedAt)) {
    lastBlockedAt = task.updatedAt;
  }
  logger.info({ id: task.id, type: task.type, status: task.status }, "Task imported from persistence (execution blocked)");
}

export function getTask(taskId: string): Task | undefined {
  return tasks.get(taskId);
}

export function listTasks(): Task[] {
  return Array.from(tasks.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

export function getTaskQueueStatus(): TaskQueueState & { timestamp: string } {
  let queuedCount = 0;
  let blockedCount = 0;

  for (const t of tasks.values()) {
    if (t.status === "queued") queuedCount++;
    else if (t.status === "blocked") blockedCount++;
  }

  return {
    totalTasks,
    queuedTasks: queuedCount,
    blockedTasks: blockedCount,
    completedTasks: 0,
    failedTasks: 0,
    executionBlocked: EXECUTION_BLOCKED,
    lastTaskCreatedAt,
    lastBlockedAt,
    timestamp: new Date().toISOString(),
  };
}
