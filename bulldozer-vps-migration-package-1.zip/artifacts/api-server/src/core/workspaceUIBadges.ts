import { getUIRenderModel } from "./workspaceUIRenderModel.js";

export interface UIBadgeEntry {
  badgeId: string;
  label: string;
  signalType: string;
  sourceEndpoint: string;
  refreshMode: string;
  executionBlocked: true;
}

export interface UIBadgeManifest {
  generatedAt: string;
  totalBadges: number;
  badges: UIBadgeEntry[];
  executionBlocked: true;
}

export function getUIBadgeManifest(): UIBadgeManifest {
  const renderModel = getUIRenderModel();

  const badges: UIBadgeEntry[] = renderModel.governanceBadges
    .map((b) => ({
      badgeId: b.badgeId,
      label: b.label,
      signalType: b.signalType,
      sourceEndpoint: b.sourceEndpoint,
      refreshMode: b.refreshMode,
      executionBlocked: true as const,
    }))
    .sort((a, b) => a.badgeId.localeCompare(b.badgeId));

  return {
    generatedAt: new Date().toISOString(),
    totalBadges: badges.length,
    badges,
    executionBlocked: true,
  };
}
