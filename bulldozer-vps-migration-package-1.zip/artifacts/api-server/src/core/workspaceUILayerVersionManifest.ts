// Workspace UI Layer Version Manifest — Phase 132
// Static deterministic versioning metadata for all UI-layer systems.
// No reads from other runtime modules. No persistence. No mutation.
// No HTML/CSS/JSX. Pure static manifest — schemaHash pre-computed at module load.

import { createHash } from "node:crypto";

const EXECUTION_BLOCKED: true = true;
const MANIFEST_VERSION = "1" as const;

// ---------------------------------------------------------------------------
// Type definitions
// ---------------------------------------------------------------------------

export type UILayerType = "render_model" | "skeleton" | "coherence_probe";

export interface UILayerEntry {
  layerId: string;
  layerName: string;
  version: string;
  schemaHash: string;
  endpoint: string;
  layerType: UILayerType;
  executionBlocked: true;
}

export interface UILayerVersionManifest {
  generatedAt: string;
  manifestVersion: typeof MANIFEST_VERSION;
  uiVersion: string;
  dashboardVersion: string;
  renderModelSchemaVersion: string;
  skeletonSchemaVersion: string;
  coherenceProbeVersion: string;
  layerCount: number;
  layers: UILayerEntry[];
  executionBlocked: true;
}

// ---------------------------------------------------------------------------
// Schema hash derivation
// schemaHash = sha256(deterministic_JSON_shape_descriptor).slice(0, 16)
// Descriptors are frozen at phase boundary — change only on incompatible schema changes.
// Computed once at module load; zero per-request overhead.
// ---------------------------------------------------------------------------

function computeSchemaHash(descriptor: string): string {
  return createHash("sha256").update(descriptor).digest("hex").slice(0, 16);
}

// Static shape descriptors — ordered field list per layer type.
// Changing these strings changes the published schemaHash — a breaking change signal.
const DESCRIPTOR_RENDER_MODEL = JSON.stringify({
  type: "WorkspaceUIRenderModel",
  fields: [
    "generatedAt", "uiVersion", "layout", "navigation",
    "pages", "panels", "widgets", "themeTokens",
    "dataBindings", "governanceBadges", "executionBlocked",
  ],
  version: "1",
});

const DESCRIPTOR_DASHBOARD_SKELETON = JSON.stringify({
  type: "WorkspaceDashboardSkeleton",
  fields: [
    "generatedAt", "dashboardVersion", "shell", "sidebar",
    "topbar", "layoutRegions", "pageLayouts", "panelLayouts",
    "widgetLayouts", "responsiveRules", "executionBlocked",
  ],
  version: "1",
});

const DESCRIPTOR_COHERENCE_PROBE = JSON.stringify({
  type: "UICoherenceResult",
  fields: [
    "generatedAt", "uiVersion", "dashboardVersion",
    "allWidgetsCoherent", "allPanelsCoherent", "allPagesCoherent",
    "bindingCoverage", "widgetViolations", "panelViolations",
    "pageViolations", "bindingViolations", "executionBlocked",
  ],
  version: "1",
});

// Pre-computed hashes — immutable after module load
const HASH_RENDER_MODEL    = computeSchemaHash(DESCRIPTOR_RENDER_MODEL);
const HASH_DASHBOARD_SKELETON = computeSchemaHash(DESCRIPTOR_DASHBOARD_SKELETON);
const HASH_COHERENCE_PROBE = computeSchemaHash(DESCRIPTOR_COHERENCE_PROBE);

// ---------------------------------------------------------------------------
// Static layer registry — alphabetical by layerId (canonical ordering)
// ---------------------------------------------------------------------------

const STATIC_LAYERS: readonly UILayerEntry[] = [
  {
    layerId:    "dashboard_skeleton",
    layerName:  "Dashboard Skeleton",
    version:    "1",
    schemaHash: HASH_DASHBOARD_SKELETON,
    endpoint:   "/api/workspace/ui/dashboard-skeleton",
    layerType:  "skeleton",
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    layerId:    "ui_coherence_probe",
    layerName:  "UI Layer Coherence Probe",
    version:    "1",
    schemaHash: HASH_COHERENCE_PROBE,
    endpoint:   "/api/workspace/ui/coherence",
    layerType:  "coherence_probe",
    executionBlocked: EXECUTION_BLOCKED,
  },
  {
    layerId:    "ui_render_model",
    layerName:  "UI Render Model",
    version:    "1",
    schemaHash: HASH_RENDER_MODEL,
    endpoint:   "/api/workspace/ui/render-model",
    layerType:  "render_model",
    executionBlocked: EXECUTION_BLOCKED,
  },
];

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
// Static manifest — only generatedAt changes per call.
// All version strings, layer entries, and schemaHashes are pre-computed constants.
// No HTML, no CSS, no JSX, no rendering engines, no mutation paths, no persistence.
// No calls to getUIRenderModel / getDashboardSkeleton / getUICoherence.
// executionBlocked: true on root and on every UILayerEntry.

export function getUILayerVersionManifest(): UILayerVersionManifest {
  return {
    generatedAt:              new Date().toISOString(),
    manifestVersion:          MANIFEST_VERSION,
    uiVersion:                "1",
    dashboardVersion:         "1",
    renderModelSchemaVersion: "1",
    skeletonSchemaVersion:    "1",
    coherenceProbeVersion:    "1",
    layerCount:               STATIC_LAYERS.length,
    layers:                   STATIC_LAYERS as UILayerEntry[],
    executionBlocked:         EXECUTION_BLOCKED,
  };
}
