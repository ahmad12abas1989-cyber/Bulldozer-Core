import { listSubsystemStates } from "./runtimeStateRegistry";
import { logger } from "../lib/logger";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";
import { emitRuntimeEvent } from "./runtimeEventBus";

export interface DependencyNode {
  subsystemName: string;
  category: string;
  upstream: string[];
  downstream: string[];
  allUpstream: string[];
  allDownstream: string[];
  depth: number;
  hasCycle: boolean;
  executionBlocked: true;
  recoveryBlocked: true;
}

export interface DependencyGraphStatus {
  operational: boolean;
  totalNodes: number;
  rootCount: number;
  leafCount: number;
  maxDepth: number;
  cycleCount: number;
  hasCycles: boolean;
  cycles: string[][];
  executionBlocked: true;
  recoveryBlocked: true;
  timestamp: string;
}

const EXECUTION_BLOCKED: true = true;
const RECOVERY_BLOCKED: true = true;

const nodes = new Map<string, DependencyNode>();
let detectedCycles: string[][] = [];
let isOperational = false;

function findCycles(upstreamMap: Map<string, string[]>): string[][] {
  const visited = new Set<string>();
  const visiting = new Set<string>();
  const cycles: string[][] = [];

  function dfs(name: string, path: string[]): void {
    if (visiting.has(name)) {
      const idx = path.indexOf(name);
      if (idx >= 0) {
        cycles.push([...path.slice(idx), name]);
      }
      return;
    }
    if (visited.has(name)) return;
    visiting.add(name);
    for (const dep of upstreamMap.get(name) ?? []) {
      dfs(dep, [...path, name]);
    }
    visiting.delete(name);
    visited.add(name);
  }

  for (const name of upstreamMap.keys()) {
    dfs(name, []);
  }
  return cycles;
}

function computeDepth(
  name: string,
  upstreamMap: Map<string, string[]>,
  memo: Map<string, number>,
  stack: Set<string>,
): number {
  if (memo.has(name)) return memo.get(name)!;
  if (stack.has(name)) return 0;

  const upstream = upstreamMap.get(name) ?? [];
  if (upstream.length === 0) {
    memo.set(name, 0);
    return 0;
  }

  stack.add(name);
  let max = 0;
  for (const dep of upstream) {
    const d = computeDepth(dep, upstreamMap, memo, stack);
    if (d + 1 > max) max = d + 1;
  }
  stack.delete(name);
  memo.set(name, max);
  return max;
}

function collectAllUpstream(name: string, visited: Set<string>): string[] {
  const node = nodes.get(name);
  if (!node) return [];
  const result: string[] = [];
  for (const dep of node.upstream) {
    if (!visited.has(dep)) {
      visited.add(dep);
      result.push(dep);
      result.push(...collectAllUpstream(dep, visited));
    }
  }
  return result;
}

function collectAllDownstream(name: string, visited: Set<string>): string[] {
  const node = nodes.get(name);
  if (!node) return [];
  const result: string[] = [];
  for (const dep of node.downstream) {
    if (!visited.has(dep)) {
      visited.add(dep);
      result.push(dep);
      result.push(...collectAllDownstream(dep, visited));
    }
  }
  return result;
}

export function initRuntimeDependencyGraph(): void {
  const states = listSubsystemStates();

  const upstreamMap = new Map<string, string[]>();
  const downstreamMap = new Map<string, string[]>();
  const categoryMap = new Map<string, string>();

  for (const state of states) {
    upstreamMap.set(state.subsystemName, [...state.dependencies]);
    categoryMap.set(state.subsystemName, state.category);
    if (!downstreamMap.has(state.subsystemName)) {
      downstreamMap.set(state.subsystemName, []);
    }
  }

  for (const [name, upstream] of upstreamMap) {
    for (const dep of upstream) {
      if (!downstreamMap.has(dep)) {
        downstreamMap.set(dep, []);
      }
      const ds = downstreamMap.get(dep)!;
      if (!ds.includes(name)) {
        ds.push(name);
      }
    }
  }

  detectedCycles = findCycles(upstreamMap);
  const cycleNodeSet = new Set<string>(detectedCycles.flat());

  const depthMemo = new Map<string, number>();
  const depthStack = new Set<string>();

  for (const [name, upstream] of upstreamMap) {
    const node: DependencyNode = {
      subsystemName: name,
      category: categoryMap.get(name) ?? "unknown",
      upstream: [...upstream],
      downstream: [...(downstreamMap.get(name) ?? [])],
      allUpstream: [],
      allDownstream: [],
      depth: computeDepth(name, upstreamMap, depthMemo, depthStack),
      hasCycle: cycleNodeSet.has(name),
      executionBlocked: EXECUTION_BLOCKED,
      recoveryBlocked: RECOVERY_BLOCKED,
    };
    nodes.set(name, node);
  }

  for (const name of nodes.keys()) {
    const node = nodes.get(name)!;
    nodes.set(name, {
      ...node,
      allUpstream: collectAllUpstream(name, new Set()),
      allDownstream: collectAllDownstream(name, new Set()),
    });
  }

  isOperational = true;

  const totalNodes = nodes.size;
  const hasCycles = detectedCycles.length > 0;

  emit("runtime_dependency_graph:initialized", "runtime-dependency-graph", {
    totalNodes,
    hasCycles,
    cycleCount: detectedCycles.length,
    executionBlocked: EXECUTION_BLOCKED,
  });

  emitRuntimeEvent({
    eventType: "runtime_dependency_graph.initialized",
    source: "runtime-dependency-graph",
    severity: hasCycles ? "warning" : "info",
    category: "runtime",
    payload: {
      totalNodes,
      hasCycles,
      cycleCount: detectedCycles.length,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  addTimelineEvent({
    level: hasCycles ? "warn" : "info",
    source: "runtime-dependency-graph",
    message: `Runtime dependency graph initialized — ${totalNodes} nodes${hasCycles ? `, ${detectedCycles.length} cycle(s) detected` : ", no cycles"}`,
    metadata: {
      totalNodes,
      hasCycles,
      cycleCount: detectedCycles.length,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    {
      totalNodes,
      hasCycles,
      cycleCount: detectedCycles.length,
      executionBlocked: EXECUTION_BLOCKED,
    },
    "Runtime dependency graph initialized",
  );
}

export function getDependencyNode(subsystemName: string): DependencyNode | null {
  return nodes.get(subsystemName) ?? null;
}

export function listDependencyNodes(): DependencyNode[] {
  return Array.from(nodes.values()).sort((a, b) =>
    a.subsystemName.localeCompare(b.subsystemName),
  );
}

export function getRuntimeDependencyGraphStatus(): DependencyGraphStatus {
  const nodeList = Array.from(nodes.values());
  const rootCount = nodeList.filter((n) => n.upstream.length === 0).length;
  const leafCount = nodeList.filter((n) => n.downstream.length === 0).length;
  const maxDepth = nodeList.reduce((max, n) => Math.max(max, n.depth), 0);

  return {
    operational: isOperational,
    totalNodes: nodeList.length,
    rootCount,
    leafCount,
    maxDepth,
    cycleCount: detectedCycles.length,
    hasCycles: detectedCycles.length > 0,
    cycles: detectedCycles,
    executionBlocked: EXECUTION_BLOCKED,
    recoveryBlocked: RECOVERY_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}
