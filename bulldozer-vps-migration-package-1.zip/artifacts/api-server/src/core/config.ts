import { join } from "node:path";

export interface Config {
  port: number;
  nodeEnv: string;
  logLevel: string;
  storageDir: string;
}

function loadConfig(): Config {
  const rawPort = process.env["PORT"];

  if (!rawPort) {
    throw new Error("PORT environment variable is required but was not provided.");
  }

  const port = Number(rawPort);

  if (Number.isNaN(port) || port <= 0 || !Number.isInteger(port)) {
    throw new Error(`Invalid PORT value: "${rawPort}"`);
  }

  return {
    port,
    nodeEnv: process.env["NODE_ENV"] ?? "development",
    logLevel: process.env["LOG_LEVEL"] ?? "info",
    storageDir: process.env["STORAGE_DIR"] ?? join(process.cwd(), "storage"),
  };
}

export const config = loadConfig();
