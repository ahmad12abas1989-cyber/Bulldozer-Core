import { getDashboardSkeleton } from "./workspaceDashboardSkeleton.js";
import { getUIRenderModel } from "./workspaceUIRenderModel.js";

export interface UIPanelEntry {
  panelId: string;
  title: string;
  pageId: string;
  widgetCount: number;
  cardStyle: string;
  layoutDirection: string;
  executionBlocked: true;
}

export interface UIPanelManifest {
  generatedAt: string;
  totalPanels: number;
  panels: UIPanelEntry[];
  executionBlocked: true;
}

export function getUIPanelManifest(): UIPanelManifest {
  const skeleton = getDashboardSkeleton();
  const renderModel = getUIRenderModel();

  const titleMap = new Map<string, string>();
  for (const p of renderModel.panels) {
    titleMap.set(p.panelId, p.title);
  }

  const panels: UIPanelEntry[] = skeleton.panelLayouts
    .map((pl) => ({
      panelId: pl.panelId,
      title: titleMap.get(pl.panelId) ?? pl.panelId,
      pageId: pl.pageId,
      widgetCount: pl.widgetIds.length,
      cardStyle: pl.cardStyle,
      layoutDirection: pl.layoutDirection,
      executionBlocked: true as const,
    }))
    .sort((a, b) => a.panelId.localeCompare(b.panelId));

  return {
    generatedAt: new Date().toISOString(),
    totalPanels: panels.length,
    panels,
    executionBlocked: true,
  };
}
