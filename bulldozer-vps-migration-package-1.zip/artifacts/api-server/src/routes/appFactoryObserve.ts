// App Factory Observe Route — Phase 209
// GET /api/factory/requests
// Read-only diagnostic view of the in-memory App Factory request registry.
// No generation, no file creation, no sandbox execution, no plugin execution,
// no deployment, no vault access, no network access, no create-request route.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import { listAppFactoryRequestRecords, getAppFactorySummary } from "../core/appFactoryCore";

export function handleAppFactoryObserve(_req: IncomingMessage, res: ServerResponse): void {
  const requests = listAppFactoryRequestRecords();
  const summary  = getAppFactorySummary();

  sendJson(res, 200, {
    generatedAt:        new Date().toISOString(),
    generationEnabled:  false,
    executionEnabled:   false,
    persistenceEnabled: false,
    executionBlocked:   true,
    totalRequests:      requests.length,
    summary,
    requests,
  });
}
