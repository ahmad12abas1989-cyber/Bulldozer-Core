export type TimelineLevel = "info" | "warn" | "error";

export interface TimelineEvent {
  timestamp: string;
  level: TimelineLevel;
  source: string;
  message: string;
  requestId?: string;
  metadata?: Record<string, unknown>;
}

export interface AddEventInput {
  level: TimelineLevel;
  source: string;
  message: string;
  requestId?: string;
  metadata?: Record<string, unknown>;
}

const MAX_EVENTS = 200;
const events: TimelineEvent[] = [];

export function addTimelineEvent(input: AddEventInput): void {
  const event: TimelineEvent = {
    timestamp: new Date().toISOString(),
    level: input.level,
    source: input.source,
    message: input.message,
  };

  if (input.requestId != null) event.requestId = input.requestId;
  if (input.metadata != null) event.metadata = input.metadata;

  if (events.length >= MAX_EVENTS) {
    events.shift();
  }
  events.push(event);
}

export function getTimeline(limit?: number): TimelineEvent[] {
  const reversed = [...events].reverse();
  return limit != null && limit > 0 ? reversed.slice(0, limit) : reversed;
}

export function getTimelineSize(): number {
  return events.length;
}

export function clearTimeline(): void {
  events.length = 0;
}
