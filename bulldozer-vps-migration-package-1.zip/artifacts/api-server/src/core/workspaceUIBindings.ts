import { getUIRenderModel } from "./workspaceUIRenderModel.js";

export interface UIBindingEntry {
  sourceEndpoint: string;
  readOnly: boolean;
  mutationAllowed: boolean;
  requiresApproval: boolean;
  executionBlocked: true;
}

export interface UIBindingManifest {
  generatedAt: string;
  totalBindings: number;
  bindings: UIBindingEntry[];
  executionBlocked: true;
}

export function getUIBindingManifest(): UIBindingManifest {
  const renderModel = getUIRenderModel();

  const bindings: UIBindingEntry[] = renderModel.dataBindings
    .map((b) => ({
      sourceEndpoint: b.sourceEndpoint,
      readOnly: b.readOnly,
      mutationAllowed: b.mutationAllowed,
      requiresApproval: b.requiresApproval,
      executionBlocked: true as const,
    }))
    .sort((a, b) => a.sourceEndpoint.localeCompare(b.sourceEndpoint));

  return {
    generatedAt: new Date().toISOString(),
    totalBindings: bindings.length,
    bindings,
    executionBlocked: true,
  };
}
