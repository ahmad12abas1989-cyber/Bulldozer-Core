// Dependency Resolution Observe Route — Phase 229
// GET /api/resolution/dependencies
// Read-only diagnostic view of the in-memory dependency resolution registry.
// No resolution creation, no filesystem writes, no package installation,
// no runtime execution, no sandbox execution, no external registry access,
// no deployment packaging.

import type { IncomingMessage, ServerResponse } from "node:http";
import { sendJson } from "../lib/response";
import {
  listDependencyResolutionRecords,
  getDependencyResolutionSummary,
} from "../core/dependencyResolutionCore";

export function handleDependencyResolutionObserve(
  _req: IncomingMessage,
  res: ServerResponse,
): void {
  const resolutions = listDependencyResolutionRecords();
  const summary     = getDependencyResolutionSummary();

  sendJson(res, 200, {
    generatedAt:         new Date().toISOString(),
    resolutionEnabled:   false,
    executionEnabled:    false,
    installationEnabled: false,
    persistenceEnabled:  false,
    executionBlocked:    true,
    installationBlocked: true,
    totalResolutions:    resolutions.length,
    summary,
    resolutions,
  });
}
