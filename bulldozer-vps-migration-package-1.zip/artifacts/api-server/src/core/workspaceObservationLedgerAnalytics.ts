import { createHash } from "node:crypto";
import { getRawHistoryEntries } from "./workspaceObservationLedgerHistory";
import type { ObservationHealth, ExposureRiskLevel, ValidationHealth } from "./workspaceObservationLedger";
import type { GovernanceGrade } from "./workspaceGovernanceScorecard";

const EXECUTION_BLOCKED: true = true;

// --- Grade ordering (lower index = better) ---
const GRADE_ORDER: GovernanceGrade[] = ["A", "B", "C", "D", "F"];
const RISK_ORDER: ExposureRiskLevel[] = ["none", "low", "medium", "high"];
// Health ranking: healthy > degraded > failed (lower index = better)
const VALIDATION_HEALTH_ORDER: ValidationHealth[] = ["healthy", "degraded", "failed"];

export type AnalyticsTrendDirection = "improving" | "stable" | "degrading" | null;

// --- Types ---

export interface AnalyticsSummary {
  totalSnapshotsAnalyzed: number;
  averageObservationCoverage: number;
  bestGovernanceGrade: GovernanceGrade | null;
  worstExposureRiskLevel: ExposureRiskLevel | null;
  observationTrendDirection: AnalyticsTrendDirection;
  averageProbeTimeMs: number | null;
  latestCaptureSeq: number | null;
  // Phase 111 — validation integrity analytics
  averageWidgetCoveragePercent: number;
  bestValidationHealth: ValidationHealth | null;
  worstValidationHealth: ValidationHealth | null;
  validationTrendDirection: AnalyticsTrendDirection;
  executionBlocked: true;
}

export interface AnalyticsTransitions {
  governanceGradeChanges: number;
  exposureRiskChanges: number;
  healthStateChanges: number;
  improvingCoverageCount: number;
  degradingCoverageCount: number;
  // Phase 111 — validation integrity transition count
  validationHealthChanges: number;
  executionBlocked: true;
}

export interface AnalyticsHistoryPoint {
  captureSeq: number;
  createdAt: string;
  observationCoverage: number;
  governanceReadiness: GovernanceGrade;
  exposureRiskLevel: ExposureRiskLevel;
  overallObservationHealth: ObservationHealth;
  probeTimeMs: number;
  executionBlocked: true;
}

export interface WorkspaceObservationLedgerAnalytics {
  analyticsId: string;
  generatedAt: string;
  summary: AnalyticsSummary;
  transitions: AnalyticsTransitions;
  series: AnalyticsHistoryPoint[];
  snapshotsInRing: number;
  executionBlocked: true;
}

// --- Derivation helpers ---

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function deriveBestGrade(grades: GovernanceGrade[]): GovernanceGrade | null {
  if (grades.length === 0) return null;
  return grades.reduce((best, g) => {
    return GRADE_ORDER.indexOf(g) < GRADE_ORDER.indexOf(best) ? g : best;
  });
}

function deriveWorstRisk(levels: ExposureRiskLevel[]): ExposureRiskLevel | null {
  if (levels.length === 0) return null;
  return levels.reduce((worst, l) => {
    return RISK_ORDER.indexOf(l) > RISK_ORDER.indexOf(worst) ? l : worst;
  });
}

function deriveTrendDirection(
  oldestCoverage: number,
  newestCoverage: number,
): Exclude<AnalyticsTrendDirection, null> {
  if (newestCoverage > oldestCoverage) return "improving";
  if (newestCoverage < oldestCoverage) return "degrading";
  return "stable";
}

// Phase 111 — backward-compatible extraction of validation signals from a stored snapshot.
// Pre-Phase-109 entries do not have validationProbe; degrade safely to failed/0.
function extractValidationSignals(snapshot: Record<string, unknown>): {
  validationHealth: ValidationHealth;
  widgetCoveragePercent: number;
} {
  const vp = snapshot["validationProbe"] as
    | { validationHealth: ValidationHealth; widgetCoveragePercent: number }
    | undefined
    | null;
  return {
    validationHealth:
      vp != null && typeof vp.validationHealth === "string"
        ? (vp.validationHealth as ValidationHealth)
        : "failed",
    widgetCoveragePercent:
      vp != null && typeof vp.widgetCoveragePercent === "number"
        ? vp.widgetCoveragePercent
        : 0,
  };
}

function deriveBestValidationHealth(healths: ValidationHealth[]): ValidationHealth | null {
  if (healths.length === 0) return null;
  return healths.reduce((best, h) => {
    return VALIDATION_HEALTH_ORDER.indexOf(h) < VALIDATION_HEALTH_ORDER.indexOf(best) ? h : best;
  });
}

function deriveWorstValidationHealth(healths: ValidationHealth[]): ValidationHealth | null {
  if (healths.length === 0) return null;
  return healths.reduce((worst, h) => {
    return VALIDATION_HEALTH_ORDER.indexOf(h) > VALIDATION_HEALTH_ORDER.indexOf(worst) ? h : worst;
  });
}

// --- Public API ---

export function getWorkspaceObservationLedgerAnalytics(): WorkspaceObservationLedgerAnalytics {
  const generatedAt = new Date().toISOString();
  const analyticsId = createHash("sha256").update(generatedAt).digest("hex").slice(0, 16);

  // Read from the in-memory history ring — no I/O, no mutation
  const entries = getRawHistoryEntries();

  // Sort oldest-first for transition analysis
  const oldestFirst = [...entries].sort((a, b) => a.captureSeq - b.captureSeq);

  const snapshotsInRing = oldestFirst.length;

  // --- Summary derivations ---

  const grades = oldestFirst.map((e) => e.snapshot.summary.governanceReadiness);
  const risks = oldestFirst.map((e) => e.snapshot.summary.exposureRiskLevel);
  const coverages = oldestFirst.map((e) => e.snapshot.summary.observationCoverage);
  const probeTimes = oldestFirst.map((e) => e.snapshot.probe.totalProbeTimeMs);
  const seqs = oldestFirst.map((e) => e.captureSeq);

  const averageObservationCoverage =
    coverages.length > 0 ? round1(coverages.reduce((s, c) => s + c, 0) / coverages.length) : 0;

  const bestGovernanceGrade = deriveBestGrade(grades);
  const worstExposureRiskLevel = deriveWorstRisk(risks);

  const averageProbeTimeMs =
    probeTimes.length > 0 ? round1(probeTimes.reduce((s, t) => s + t, 0) / probeTimes.length) : null;

  const latestCaptureSeq = seqs.length > 0 ? Math.max(...seqs) : null;

  const observationTrendDirection: AnalyticsTrendDirection =
    oldestFirst.length >= 2
      ? deriveTrendDirection(
          oldestFirst[0].snapshot.summary.observationCoverage,
          oldestFirst[oldestFirst.length - 1].snapshot.summary.observationCoverage,
        )
      : null;

  // Phase 111 — validation integrity derivations
  const validationSignals = oldestFirst.map((e) =>
    extractValidationSignals(e.snapshot as unknown as Record<string, unknown>),
  );
  const validationHealths = validationSignals.map((v) => v.validationHealth);
  const widgetCoverages = validationSignals.map((v) => v.widgetCoveragePercent);

  const averageWidgetCoveragePercent =
    widgetCoverages.length > 0
      ? Math.round(widgetCoverages.reduce((s, c) => s + c, 0) / widgetCoverages.length)
      : 0;

  const bestValidationHealth = deriveBestValidationHealth(validationHealths);
  const worstValidationHealth = deriveWorstValidationHealth(validationHealths);

  const validationTrendDirection: AnalyticsTrendDirection =
    oldestFirst.length >= 2
      ? deriveTrendDirection(widgetCoverages[0], widgetCoverages[widgetCoverages.length - 1])
      : null;

  const summary: AnalyticsSummary = {
    totalSnapshotsAnalyzed: snapshotsInRing,
    averageObservationCoverage,
    bestGovernanceGrade,
    worstExposureRiskLevel,
    observationTrendDirection,
    averageProbeTimeMs,
    latestCaptureSeq,
    averageWidgetCoveragePercent,
    bestValidationHealth,
    worstValidationHealth,
    validationTrendDirection,
    executionBlocked: EXECUTION_BLOCKED,
  };

  // --- Transition metrics (consecutive oldest-first pairs) ---

  let governanceGradeChanges = 0;
  let exposureRiskChanges = 0;
  let healthStateChanges = 0;
  let improvingCoverageCount = 0;
  let degradingCoverageCount = 0;
  let validationHealthChanges = 0;

  for (let i = 1; i < oldestFirst.length; i++) {
    const prev = oldestFirst[i - 1].snapshot.summary;
    const curr = oldestFirst[i].snapshot.summary;

    if (curr.governanceReadiness !== prev.governanceReadiness) governanceGradeChanges++;
    if (curr.exposureRiskLevel !== prev.exposureRiskLevel) exposureRiskChanges++;
    if (curr.overallObservationHealth !== prev.overallObservationHealth) healthStateChanges++;
    if (curr.observationCoverage > prev.observationCoverage) improvingCoverageCount++;
    if (curr.observationCoverage < prev.observationCoverage) degradingCoverageCount++;

    // Phase 111 — validation health transition
    if (validationHealths[i] !== validationHealths[i - 1]) validationHealthChanges++;
  }

  const transitions: AnalyticsTransitions = {
    governanceGradeChanges,
    exposureRiskChanges,
    healthStateChanges,
    improvingCoverageCount,
    degradingCoverageCount,
    validationHealthChanges,
    executionBlocked: EXECUTION_BLOCKED,
  };

  // --- Series: newest-first, max 20 history points ---

  const newestFirst = [...oldestFirst].reverse();

  const series: AnalyticsHistoryPoint[] = newestFirst.map((e) => ({
    captureSeq: e.captureSeq,
    createdAt: e.createdAt,
    observationCoverage: e.snapshot.summary.observationCoverage,
    governanceReadiness: e.snapshot.summary.governanceReadiness,
    exposureRiskLevel: e.snapshot.summary.exposureRiskLevel,
    overallObservationHealth: e.snapshot.summary.overallObservationHealth,
    probeTimeMs: e.snapshot.probe.totalProbeTimeMs,
    executionBlocked: EXECUTION_BLOCKED,
  }));

  return {
    analyticsId,
    generatedAt,
    summary,
    transitions,
    series,
    snapshotsInRing,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
