import { randomBytes } from "node:crypto";
import { logger } from "../lib/logger";
import { subscribe } from "./eventBus";

export type EventSeverity = "info" | "warning" | "critical";

export type EventCategory =
  | "runtime"
  | "health"
  | "queue"
  | "lifecycle"
  | "persistence"
  | "snapshot"
  | "recovery"
  | "policy"
  | "orchestration";

export interface RuntimeEvent {
  eventId: string;
  eventType: string;
  source: string;
  severity: EventSeverity;
  category: EventCategory;
  timestamp: string;
  payload: Record<string, unknown>;
  correlationId: string | null;
  runtimeVersion: 1;
}

export type RuntimeEventHandler = (event: RuntimeEvent) => void;

interface Subscription {
  subscriptionId: string;
  eventType: string;
  handler: RuntimeEventHandler;
  source: string;
  subscribedAt: string;
}

export interface SubscriberInfo {
  subscriptionId: string;
  eventType: string;
  source: string;
  subscribedAt: string;
}

export interface RuntimeEventBusStatus {
  operational: boolean;
  totalEmitted: number;
  retainedEventCount: number;
  maxRetainedEvents: number;
  retentionNearLimit: boolean;
  dispatchFailures: number;
  activeSubscriberCount: number;
  eventCategoryCounts: Record<string, number>;
  eventTypeCounts: Record<string, number>;
  lastEventAt: string | null;
  lastEventType: string | null;
  executionBlocked: true;
  timestamp: string;
}

export interface RuntimeEventFilter {
  eventType?: string;
  source?: string;
  severity?: string;
  category?: string;
  correlationId?: string;
  limit?: number;
}

export interface RuntimeEventFilterResult {
  events: RuntimeEvent[];
  count: number;
  limit: number;
  filteredCount: number;
  filtersApplied: Record<string, string>;
  maxRetainedEvents: number;
  executionBlocked: true;
  timestamp: string;
}

const MAX_EVENTS = 1000;
const MAX_QUERY_LIMIT = 100;
const RETENTION_WARN_THRESHOLD = 800;
const RUNTIME_VERSION = 1 as const;
const EXECUTION_BLOCKED: true = true;

const events: RuntimeEvent[] = [];
const subscriptions = new Map<string, Subscription>();

let isOperational = false;
let totalEmitted = 0;
let dispatchFailures = 0;
let lastEventAt: string | null = null;
let lastEventType: string | null = null;
let isDispatching = false;
const pendingDispatch: RuntimeEvent[] = [];

const eventCategoryCounts: Record<string, number> = {};
const eventTypeCounts: Record<string, number> = {};

function storeEvent(event: RuntimeEvent): void {
  if (events.length >= MAX_EVENTS) {
    events.shift();
  }
  events.push(event);
}

function dispatchToSubscribers(event: RuntimeEvent): void {
  for (const sub of subscriptions.values()) {
    if (sub.eventType !== "*" && sub.eventType !== event.eventType) continue;
    try {
      sub.handler(event);
    } catch (err) {
      dispatchFailures++;
      logger.warn(
        { subscriptionId: sub.subscriptionId, eventType: event.eventType, err: String(err) },
        "Runtime event bus: handler failure isolated",
      );
    }
  }
}

export function emitRuntimeEvent(input: {
  eventType: string;
  source: string;
  severity: EventSeverity;
  category: EventCategory;
  payload?: Record<string, unknown>;
  correlationId?: string | null;
}): RuntimeEvent {
  const now = new Date().toISOString();

  const event: RuntimeEvent = {
    eventId: randomBytes(8).toString("hex"),
    eventType: input.eventType,
    source: input.source,
    severity: input.severity,
    category: input.category,
    timestamp: now,
    payload: input.payload ?? {},
    correlationId: input.correlationId ?? null,
    runtimeVersion: RUNTIME_VERSION,
  };

  storeEvent(event);
  totalEmitted++;
  lastEventAt = now;
  lastEventType = event.eventType;
  eventCategoryCounts[event.category] = (eventCategoryCounts[event.category] ?? 0) + 1;
  eventTypeCounts[event.eventType] = (eventTypeCounts[event.eventType] ?? 0) + 1;

  if (isDispatching) {
    pendingDispatch.push(event);
    return event;
  }

  isDispatching = true;
  try {
    dispatchToSubscribers(event);
    while (pendingDispatch.length > 0) {
      const next = pendingDispatch.shift()!;
      dispatchToSubscribers(next);
    }
  } finally {
    isDispatching = false;
  }

  return event;
}

export function subscribeRuntimeEvent(
  eventType: string,
  handler: RuntimeEventHandler,
  source: string,
): string {
  const subscriptionId = randomBytes(6).toString("hex");
  const now = new Date().toISOString();

  subscriptions.set(subscriptionId, {
    subscriptionId,
    eventType,
    handler,
    source,
    subscribedAt: now,
  });

  logger.info(
    { subscriptionId, eventType, source },
    "Runtime event bus: subscription registered",
  );

  return subscriptionId;
}

export function unsubscribeRuntimeEvent(subscriptionId: string): boolean {
  const existed = subscriptions.has(subscriptionId);
  if (existed) {
    subscriptions.delete(subscriptionId);
    logger.info({ subscriptionId }, "Runtime event bus: subscription removed");
  }
  return existed;
}

export function listRuntimeSubscribers(): SubscriberInfo[] {
  return Array.from(subscriptions.values()).map((s) => ({
    subscriptionId: s.subscriptionId,
    eventType: s.eventType,
    source: s.source,
    subscribedAt: s.subscribedAt,
  }));
}

export function listRecentRuntimeEvents(limit = 50): RuntimeEvent[] {
  const safeLimit = Math.min(Math.max(1, limit), MAX_EVENTS);
  return [...events].reverse().slice(0, safeLimit);
}

export function getFilteredRuntimeEvents(filter: RuntimeEventFilter): RuntimeEventFilterResult {
  const limit = Math.max(1, Math.min(filter.limit ?? MAX_QUERY_LIMIT, MAX_QUERY_LIMIT));
  const filtersApplied: Record<string, string> = {};

  let records = events.slice();

  if (filter.eventType !== undefined) {
    records = records.filter((e) => e.eventType === filter.eventType);
    filtersApplied["eventType"] = filter.eventType;
  }

  if (filter.source !== undefined) {
    records = records.filter((e) => e.source === filter.source);
    filtersApplied["source"] = filter.source;
  }

  if (filter.severity !== undefined) {
    records = records.filter((e) => e.severity === filter.severity);
    filtersApplied["severity"] = filter.severity;
  }

  if (filter.category !== undefined) {
    records = records.filter((e) => e.category === filter.category);
    filtersApplied["category"] = filter.category;
  }

  if (filter.correlationId !== undefined) {
    records = records.filter((e) => e.correlationId === filter.correlationId);
    filtersApplied["correlationId"] = filter.correlationId;
  }

  const filteredCount = records.length;
  const sliced = records.slice(-limit).reverse();

  return {
    events: sliced,
    count: sliced.length,
    limit,
    filteredCount,
    filtersApplied,
    maxRetainedEvents: MAX_EVENTS,
    executionBlocked: EXECUTION_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

export function clearOldRuntimeEvents(maxAgeMs?: number): number {
  if (maxAgeMs === undefined) {
    const cleared = events.length > MAX_EVENTS ? events.length - MAX_EVENTS : 0;
    events.splice(0, cleared);
    return cleared;
  }
  const cutoff = Date.now() - maxAgeMs;
  let cleared = 0;
  let i = 0;
  while (i < events.length) {
    if (new Date(events[i]!.timestamp).getTime() < cutoff) {
      events.splice(i, 1);
      cleared++;
    } else {
      i++;
    }
  }
  if (cleared > 0) {
    logger.info({ cleared, maxAgeMs }, "Runtime event bus: old events cleared");
  }
  return cleared;
}

export function getRuntimeEventBusStatus(): RuntimeEventBusStatus {
  return {
    operational: isOperational,
    totalEmitted,
    retainedEventCount: events.length,
    maxRetainedEvents: MAX_EVENTS,
    retentionNearLimit: events.length >= RETENTION_WARN_THRESHOLD,
    dispatchFailures,
    activeSubscriberCount: subscriptions.size,
    eventCategoryCounts: { ...eventCategoryCounts },
    eventTypeCounts: { ...eventTypeCounts },
    lastEventAt,
    lastEventType,
    executionBlocked: EXECUTION_BLOCKED,
    timestamp: new Date().toISOString(),
  };
}

function bridgeExistingBusEvents(): void {
  subscribe("runtime:starting", (e) => {
    emitRuntimeEvent({
      eventType: "runtime.starting",
      source: e.source,
      severity: "info",
      category: "runtime",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("runtime:ready", (e) => {
    emitRuntimeEvent({
      eventType: "runtime.ready",
      source: e.source,
      severity: "info",
      category: "runtime",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("runtime:stopping", (e) => {
    emitRuntimeEvent({
      eventType: "runtime.stopping",
      source: e.source,
      severity: "warning",
      category: "runtime",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("runtime:failed", (e) => {
    emitRuntimeEvent({
      eventType: "runtime.failed",
      source: e.source,
      severity: "critical",
      category: "runtime",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_queue:task_created", (e) => {
    emitRuntimeEvent({
      eventType: "queue.task_created",
      source: e.source,
      severity: "info",
      category: "queue",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_queue:task_blocked", (e) => {
    emitRuntimeEvent({
      eventType: "queue.task_blocked",
      source: e.source,
      severity: "warning",
      category: "queue",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_queue:task_queued", (e) => {
    emitRuntimeEvent({
      eventType: "queue.task_queued",
      source: e.source,
      severity: "info",
      category: "queue",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_lifecycle:transitioned", (e) => {
    emitRuntimeEvent({
      eventType: "lifecycle.transitioned",
      source: e.source,
      severity: "info",
      category: "lifecycle",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_lifecycle:transition_rejected", (e) => {
    emitRuntimeEvent({
      eventType: "lifecycle.transition_rejected",
      source: e.source,
      severity: "warning",
      category: "lifecycle",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_lifecycle:initialized", (e) => {
    emitRuntimeEvent({
      eventType: "lifecycle.initialized",
      source: e.source,
      severity: "info",
      category: "lifecycle",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("runtime_snapshot:created", (e) => {
    emitRuntimeEvent({
      eventType: "snapshot.created",
      source: e.source,
      severity: "info",
      category: "snapshot",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("runtime_snapshot:archived", (e) => {
    emitRuntimeEvent({
      eventType: "snapshot.archived",
      source: e.source,
      severity: "info",
      category: "snapshot",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("runtime_snapshot:dry_run_recovery", (e) => {
    emitRuntimeEvent({
      eventType: "recovery.dry_run_planned",
      source: e.source,
      severity: "info",
      category: "recovery",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("runtime_snapshot:impact_estimated", (e) => {
    emitRuntimeEvent({
      eventType: "recovery.impact_estimated",
      source: e.source,
      severity: "info",
      category: "recovery",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_policy:block", (e) => {
    emitRuntimeEvent({
      eventType: "policy.blocked",
      source: e.source,
      severity: "warning",
      category: "policy",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_policy:approval_required", (e) => {
    emitRuntimeEvent({
      eventType: "policy.approval_required",
      source: e.source,
      severity: "warning",
      category: "policy",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_policy:warn", (e) => {
    emitRuntimeEvent({
      eventType: "policy.warned",
      source: e.source,
      severity: "warning",
      category: "policy",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_policy:allow", (e) => {
    emitRuntimeEvent({
      eventType: "policy.allowed",
      source: e.source,
      severity: "info",
      category: "policy",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_persistence:saved", (e) => {
    emitRuntimeEvent({
      eventType: "persistence.tasks_saved",
      source: e.source,
      severity: "info",
      category: "persistence",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("task_persistence:loaded", (e) => {
    emitRuntimeEvent({
      eventType: "persistence.tasks_loaded",
      source: e.source,
      severity: "info",
      category: "persistence",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("queue_orchestrator:evaluated", (e) => {
    emitRuntimeEvent({
      eventType: "orchestration.evaluated",
      source: e.source,
      severity: "info",
      category: "orchestration",
      payload: e.payload,
      correlationId: e.id,
    });
  });

  subscribe("snapshot:created", (e) => {
    emitRuntimeEvent({
      eventType: "snapshot.in_memory_created",
      source: e.source,
      severity: "info",
      category: "snapshot",
      payload: e.payload,
      correlationId: e.id,
    });
  });
}

export function initRuntimeEventBus(): void {
  bridgeExistingBusEvents();

  isOperational = true;

  emitRuntimeEvent({
    eventType: "runtime_event_bus.initialized",
    source: "runtime-event-bus",
    severity: "info",
    category: "runtime",
    payload: {
      maxRetainedEvents: MAX_EVENTS,
      retentionWarnThreshold: RETENTION_WARN_THRESHOLD,
      executionBlocked: EXECUTION_BLOCKED,
    },
  });

  logger.info(
    { maxRetainedEvents: MAX_EVENTS, executionBlocked: EXECUTION_BLOCKED },
    "Runtime event bus initialized",
  );
}
