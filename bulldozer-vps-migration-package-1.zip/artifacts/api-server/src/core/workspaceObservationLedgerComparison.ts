import {
  getRawHistoryEntries,
} from "./workspaceObservationLedgerHistory";
import type {
  ObservationHealth,
  ExposureRiskLevel,
  ValidationHealth,
} from "./workspaceObservationLedger";
import type { GovernanceGrade } from "./workspaceGovernanceScorecard";
import type { TrendDirection } from "./workspaceCoverageTrend";

const EXECUTION_BLOCKED: true = true;

// --- Ordering tables (lower index = better) ---

const GRADE_ORDER: GovernanceGrade[] = ["A", "B", "C", "D", "F"];
const RISK_ORDER: ExposureRiskLevel[] = ["none", "low", "medium", "high"];
const VALIDATION_HEALTH_ORDER: ValidationHealth[] = ["healthy", "degraded", "failed"];
const OBSERVATION_HEALTH_ORDER: ObservationHealth[] = ["healthy", "degraded", "critical"];
const TREND_DIRECTION_ORDER: Array<TrendDirection | null> = ["improving", "stable", "degrading", null];

// --- Types ---

export type ImprovementDirection = "improved" | "unchanged" | "degraded";
export type ComparisonChangeLabel = "improved" | "unchanged" | "degraded";

export interface GovernanceDelta {
  fromGovernanceReadiness: GovernanceGrade;
  toGovernanceReadiness: GovernanceGrade;
  governanceReadinessChange: ComparisonChangeLabel;
  executionBlocked: true;
}

export interface ValidationDelta {
  fromValidationHealth: ValidationHealth;
  toValidationHealth: ValidationHealth;
  validationHealthChange: ComparisonChangeLabel;
  widgetCoveragePercentDelta: number;
  executionBlocked: true;
}

export interface ExposureDelta {
  fromExposureRisk: ExposureRiskLevel;
  toExposureRisk: ExposureRiskLevel;
  exposureRiskChange: ComparisonChangeLabel;
  executionBlocked: true;
}

export interface TrendDelta {
  fromTrendDirection: TrendDirection | null;
  toTrendDirection: TrendDirection | null;
  trendDirectionChange: ComparisonChangeLabel;
  executionBlocked: true;
}

export interface LedgerComparisonResult {
  fromCaptureSeq: number;
  toCaptureSeq: number;
  fromCreatedAt: string;
  toCreatedAt: string;
  observationCoverageDelta: number;
  governanceReadinessChange: ComparisonChangeLabel;
  validationHealthChange: ComparisonChangeLabel;
  widgetCoveragePercentDelta: number;
  overallObservationHealthChange: ComparisonChangeLabel;
  improvementDirection: ImprovementDirection;
  governanceDelta: GovernanceDelta;
  validationDelta: ValidationDelta;
  exposureDelta: ExposureDelta;
  trendDelta: TrendDelta;
  executionBlocked: true;
}

export interface LedgerComparisonNotFound {
  error: "not_found";
  which: "from" | "to" | "both";
  fromCaptureSeq: number;
  toCaptureSeq: number;
}

// --- Derivation helpers ---

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function changeFromOrderedIndex(fromIdx: number, toIdx: number): ComparisonChangeLabel {
  if (toIdx < fromIdx) return "improved";
  if (toIdx > fromIdx) return "degraded";
  return "unchanged";
}

function gradeChange(from: GovernanceGrade, to: GovernanceGrade): ComparisonChangeLabel {
  return changeFromOrderedIndex(GRADE_ORDER.indexOf(from), GRADE_ORDER.indexOf(to));
}

function validationHealthChange(from: ValidationHealth, to: ValidationHealth): ComparisonChangeLabel {
  return changeFromOrderedIndex(
    VALIDATION_HEALTH_ORDER.indexOf(from),
    VALIDATION_HEALTH_ORDER.indexOf(to),
  );
}

function exposureRiskChange(from: ExposureRiskLevel, to: ExposureRiskLevel): ComparisonChangeLabel {
  return changeFromOrderedIndex(RISK_ORDER.indexOf(from), RISK_ORDER.indexOf(to));
}

function observationHealthChange(from: ObservationHealth, to: ObservationHealth): ComparisonChangeLabel {
  return changeFromOrderedIndex(
    OBSERVATION_HEALTH_ORDER.indexOf(from),
    OBSERVATION_HEALTH_ORDER.indexOf(to),
  );
}

function trendDirectionChange(
  from: TrendDirection | null,
  to: TrendDirection | null,
): ComparisonChangeLabel {
  return changeFromOrderedIndex(
    TREND_DIRECTION_ORDER.indexOf(from),
    TREND_DIRECTION_ORDER.indexOf(to),
  );
}

function improvementFromCoverageDelta(delta: number): ImprovementDirection {
  if (delta > 0) return "improved";
  if (delta < 0) return "degraded";
  return "unchanged";
}

// Backward-compatible extraction of validation signals from a stored snapshot.
// Pre-Phase-109 entries may not have validationProbe; degrade safely to failed/0.
function extractValidationSignals(snapshot: Record<string, unknown>): {
  validationHealth: ValidationHealth;
  widgetCoveragePercent: number;
} {
  const vp = snapshot["validationProbe"] as
    | { validationHealth: ValidationHealth; widgetCoveragePercent: number }
    | undefined
    | null;
  return {
    validationHealth:
      vp != null && typeof vp.validationHealth === "string"
        ? (vp.validationHealth as ValidationHealth)
        : "failed",
    widgetCoveragePercent:
      vp != null && typeof vp.widgetCoveragePercent === "number"
        ? vp.widgetCoveragePercent
        : 0,
  };
}

// --- Public API ---

// O(20)×2 ring lookups — bounded, no I/O, no persistence mutation, no live ledger recomputation.
// Returns LedgerComparisonNotFound when either captureSeq is absent from the ring.
// Returns LedgerComparisonResult for all valid pairs including from===to (identity comparison).
export function compareObservationLedgerSnapshots(
  fromSeq: number,
  toSeq: number,
): LedgerComparisonResult | LedgerComparisonNotFound {
  const ring = getRawHistoryEntries();

  const fromEntry = ring.find((e) => e.captureSeq === fromSeq) ?? null;
  const toEntry   = ring.find((e) => e.captureSeq === toSeq)   ?? null;

  if (fromEntry === null || toEntry === null) {
    const which =
      fromEntry === null && toEntry === null ? "both"
      : fromEntry === null ? "from"
      : "to";
    return { error: "not_found", which, fromCaptureSeq: fromSeq, toCaptureSeq: toSeq };
  }

  const fromSnap = fromEntry.snapshot;
  const toSnap   = toEntry.snapshot;

  const fromSummary = fromSnap.summary;
  const toSummary   = toSnap.summary;

  // Validation signals (backward-compat)
  const fromVal = extractValidationSignals(fromSnap as unknown as Record<string, unknown>);
  const toVal   = extractValidationSignals(toSnap   as unknown as Record<string, unknown>);

  // Numeric deltas
  const observationCoverageDelta    = round1(toSummary.observationCoverage - fromSummary.observationCoverage);
  const widgetCoveragePercentDelta  = round1(toVal.widgetCoveragePercent   - fromVal.widgetCoveragePercent);

  // Change labels
  const govReadinessChange  = gradeChange(fromSummary.governanceReadiness, toSummary.governanceReadiness);
  const valHealthChange     = validationHealthChange(fromVal.validationHealth, toVal.validationHealth);
  const obsHealthChange     = observationHealthChange(fromSummary.overallObservationHealth, toSummary.overallObservationHealth);
  const expRiskChange       = exposureRiskChange(fromSummary.exposureRiskLevel, toSummary.exposureRiskLevel);
  const trendChange         = trendDirectionChange(fromSummary.trendDirection, toSummary.trendDirection);

  const improvement = improvementFromCoverageDelta(observationCoverageDelta);

  const governanceDelta: GovernanceDelta = {
    fromGovernanceReadiness: fromSummary.governanceReadiness,
    toGovernanceReadiness:   toSummary.governanceReadiness,
    governanceReadinessChange: govReadinessChange,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const validationDelta: ValidationDelta = {
    fromValidationHealth:    fromVal.validationHealth,
    toValidationHealth:      toVal.validationHealth,
    validationHealthChange:  valHealthChange,
    widgetCoveragePercentDelta,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const exposureDelta: ExposureDelta = {
    fromExposureRisk: fromSummary.exposureRiskLevel,
    toExposureRisk:   toSummary.exposureRiskLevel,
    exposureRiskChange: expRiskChange,
    executionBlocked: EXECUTION_BLOCKED,
  };

  const trendDelta: TrendDelta = {
    fromTrendDirection: fromSummary.trendDirection,
    toTrendDirection:   toSummary.trendDirection,
    trendDirectionChange: trendChange,
    executionBlocked: EXECUTION_BLOCKED,
  };

  return {
    fromCaptureSeq:              fromSeq,
    toCaptureSeq:                toSeq,
    fromCreatedAt:               fromEntry.createdAt,
    toCreatedAt:                 toEntry.createdAt,
    observationCoverageDelta,
    governanceReadinessChange:   govReadinessChange,
    validationHealthChange:      valHealthChange,
    widgetCoveragePercentDelta,
    overallObservationHealthChange: obsHealthChange,
    improvementDirection:        improvement,
    governanceDelta,
    validationDelta,
    exposureDelta,
    trendDelta,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
