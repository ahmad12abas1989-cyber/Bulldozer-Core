// firstActualSandboxMutationSurfaceCore.ts
// Phase 335 — First Actual Sandbox Mutation Surface Descriptor Core Skeleton
// In-memory first actual sandbox mutation surface descriptor engine.
// Layer 32 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable + commit-execution-gate + mutation-executor +
//   mutation-commit + mutation-apply stack.
// Prepares the first actual sandbox mutation surface descriptor.
// Preserves sandbox-approved-only target scope from layers 24–31 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. mutationSurfaceEnabled=false — surface has not been activated.
// mutationSurfacePrepared=true — descriptor-readiness established for a future first actual sandbox write mutation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { FirstActualSandboxMutationApplyRecord }         from "./firstActualSandboxMutationApplyCore.js";
import type { FirstActualSandboxMutationCommitRecord }        from "./firstActualSandboxMutationCommitCore.js";
import type { FirstActualSandboxMutationExecutorRecord }      from "./firstActualSandboxMutationExecutorCore.js";
import type { ActualSandboxWriteCommitExecutionGateRecord }   from "./actualSandboxWriteCommitExecutionGateCore.js";
import type { SandboxWriteCommitEnableRecord }                from "./sandboxWriteCommitEnableCore.js";
import type { ControlledExecutionRecord }                     from "./controlledExecutionCore.js";
import { randomUUID }                                         from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type MutationSurfaceState = "descriptor_mutation_surface_pending";

export type MutationSurfaceCheckRule =
  | "mutation_apply_exists"
  | "mutation_commit_exists"
  | "mutation_executor_exists"
  | "commit_execution_gate_exists"
  | "commit_enable_record_exists"
  | "execution_record_exists"
  | "mutation_apply_bound_to_commit"
  | "mutation_commit_bound_to_executor"
  | "mutation_executor_bound_to_commit_execution_gate"
  | "commit_execution_gate_bound_to_commit_enable"
  | "mutation_surface_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface MutationSurfaceCheck {
  readonly rule: MutationSurfaceCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface MutationSurfaceBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface MutationSurfacePlanEntry {
  readonly entryId:                 string;
  readonly operationType:           "descriptor_mutation_surface_planned";
  readonly targetScope:             "sandbox_approved_only";
  readonly mutationSurfaceEnabled:  false;
  readonly mutationBlocked:         true;
  readonly note:                    string;
}

export interface LinkedMutationSurfaceReference {
  readonly mutationApplyId:             string;
  readonly mutationCommitId:            string;
  readonly mutationExecutorId:          string;
  readonly commitExecutionGateId:       string;
  readonly rollbackSnapshotId:          string;
  readonly mutationSurfacePrepared:     true;
  readonly mutationSurfaceEnabled:      false;
  readonly mutationApplyEnabled:        false;
  readonly mutationCommitEnabled:       false;
  readonly actualWritesEnabled:         false;
  readonly rollbackChainValid:          boolean;
  readonly referenceNote:               string;
}

export interface MutationSurfaceReadinessReport {
  readonly mutationSurfacePrepared:     true;
  readonly mutationSurfaceEnabled:      false;
  readonly mutationApplyEnabled:        false;
  readonly mutationCommitEnabled:       false;
  readonly mutationExecutorEnabled:     false;
  readonly commitExecutionGateEnabled:  false;
  readonly sandboxWriteCommitEnabled:   false;
  readonly runtimeWriteExecutorEnabled: false;
  readonly writeExecutionGateEnabled:   false;
  readonly scopedActivationEnabled:     false;
  readonly writePermissionEnabled:      false;
  readonly mutationSwitchEnabled:       false;
  readonly guardedWriteEnabled:         false;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly approvalRequired:            true;
  readonly allChecksPass:               boolean;
  readonly blockedReasonCount:          number;
  readonly rollbackChainValid:          boolean;
  readonly targetScope:                 "sandbox_approved_only";
  readonly summary:                     string;
}

export interface FirstActualSandboxMutationSurfaceRecord {
  readonly mutationSurfaceId:             string;
  readonly mutationSurfaceState:          MutationSurfaceState;
  readonly approvalRequired:              true;
  readonly mutationSurfacePrepared:       true;
  readonly mutationSurfaceEnabled:        false;
  readonly mutationApplyEnabled:          false;
  readonly mutationCommitEnabled:         false;
  readonly mutationExecutorEnabled:       false;
  readonly commitExecutionGateEnabled:    false;
  readonly actualWritesEnabled:           false;
  readonly filesystemMutationBlocked:     true;
  readonly motherCoreMutationBlocked:     true;
  readonly vaultMutationBlocked:          true;
  readonly shellBlocked:                  true;
  readonly networkBlocked:                true;
  readonly targetScope:                   "sandbox_approved_only";
  readonly implementationPhase:           "descriptor_only";
  readonly mutationApplyId:               string;
  readonly mutationCommitId:              string;
  readonly mutationExecutorId:            string;
  readonly commitExecutionGateId:         string;
  readonly sandboxWriteCommitEnableId:    string;
  readonly controlledExecutionId:         string;
  readonly mutationSurfacePlan:           readonly MutationSurfacePlanEntry[];
  readonly mutationSurfaceChecks:         readonly MutationSurfaceCheck[];
  readonly mutationSurfaceBlockedReasons: readonly MutationSurfaceBlockedReason[];
  readonly mutationSurfaceReadinessReport: MutationSurfaceReadinessReport;
  readonly linkedMutationSurfaceReference: LinkedMutationSurfaceReference;
  readonly createdAt:                     string;
}

export interface CreateFirstActualSandboxMutationSurfaceInput {
  readonly mutationApplyRecord:         FirstActualSandboxMutationApplyRecord;
  readonly mutationCommitRecord:        FirstActualSandboxMutationCommitRecord;
  readonly mutationExecutorRecord:      FirstActualSandboxMutationExecutorRecord;
  readonly commitExecutionGateRecord:   ActualSandboxWriteCommitExecutionGateRecord;
  readonly commitEnableRecord:          SandboxWriteCommitEnableRecord;
  readonly executionRecord:             ControlledExecutionRecord;
}

export interface FirstActualSandboxMutationSurfaceSummary {
  readonly total:                         number;
  readonly byState:                       Record<MutationSurfaceState, number>;
  readonly mutationSurfacePrepared:       true;
  readonly mutationSurfaceEnabled:        false;
  readonly mutationApplyEnabled:          false;
  readonly mutationCommitEnabled:         false;
  readonly mutationExecutorEnabled:       false;
  readonly commitExecutionGateEnabled:    false;
  readonly actualWritesEnabled:           false;
  readonly approvalRequired:              true;
  readonly filesystemMutationBlocked:     true;
  readonly motherCoreMutationBlocked:     true;
  readonly targetScope:                   "sandbox_approved_only";
  readonly mutationSurfaceState:          MutationSurfaceState;
  readonly implementationPhase:           "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: FirstActualSandboxMutationSurfaceRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateFirstActualSandboxMutationSurfaceInput,
): readonly MutationSurfaceCheck[] {
  const { mutationApplyRecord, mutationCommitRecord, mutationExecutorRecord, commitExecutionGateRecord, commitEnableRecord, executionRecord } = input;

  const applyExists   = mutationApplyRecord.mutationApplyId.length > 0;
  const commitExists  = mutationCommitRecord.mutationCommitId.length > 0;
  const execExists    = mutationExecutorRecord.mutationExecutorId.length > 0;
  const gateExists    = commitExecutionGateRecord.commitExecutionGateId.length > 0;
  const enableExists  = commitEnableRecord.sandboxWriteCommitEnableId.length > 0;
  const ctrlExists    = executionRecord.controlledExecutionId.length > 0;

  const applyBound    = mutationApplyRecord.mutationCommitId === mutationCommitRecord.mutationCommitId;
  const commitBound   = mutationCommitRecord.mutationExecutorId === mutationExecutorRecord.mutationExecutorId;
  const execBound     = mutationExecutorRecord.commitExecutionGateId === commitExecutionGateRecord.commitExecutionGateId;
  const gateBound     = commitExecutionGateRecord.sandboxWriteCommitEnableId === commitEnableRecord.sandboxWriteCommitEnableId;

  return [
    {
      rule: "mutation_apply_exists",
      pass: applyExists,
      note: applyExists
        ? `mutationApplyId=${mutationApplyRecord.mutationApplyId}`
        : "mutationApplyRecord.mutationApplyId is empty",
    },
    {
      rule: "mutation_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `mutationCommitId=${mutationCommitRecord.mutationCommitId}`
        : "mutationCommitRecord.mutationCommitId is empty",
    },
    {
      rule: "mutation_executor_exists",
      pass: execExists,
      note: execExists
        ? `mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`
        : "mutationExecutorRecord.mutationExecutorId is empty",
    },
    {
      rule: "commit_execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`
        : "commitExecutionGateRecord.commitExecutionGateId is empty",
    },
    {
      rule: "commit_enable_record_exists",
      pass: enableExists,
      note: enableExists
        ? `sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`
        : "commitEnableRecord.sandboxWriteCommitEnableId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "mutation_apply_bound_to_commit",
      pass: applyBound,
      note: applyBound
        ? `mutationApplyRecord.mutationCommitId === mutationCommitRecord.mutationCommitId (${mutationCommitRecord.mutationCommitId})`
        : `apply/commit mismatch: apply.mutationCommitId=${mutationApplyRecord.mutationCommitId} vs commit.mutationCommitId=${mutationCommitRecord.mutationCommitId}`,
    },
    {
      rule: "mutation_commit_bound_to_executor",
      pass: commitBound,
      note: commitBound
        ? `mutationCommitRecord.mutationExecutorId === mutationExecutorRecord.mutationExecutorId (${mutationExecutorRecord.mutationExecutorId})`
        : `commit/executor mismatch: commit.mutationExecutorId=${mutationCommitRecord.mutationExecutorId} vs executor.mutationExecutorId=${mutationExecutorRecord.mutationExecutorId}`,
    },
    {
      rule: "mutation_executor_bound_to_commit_execution_gate",
      pass: execBound,
      note: execBound
        ? `mutationExecutorRecord.commitExecutionGateId === commitExecutionGateRecord.commitExecutionGateId (${commitExecutionGateRecord.commitExecutionGateId})`
        : `executor/gate mismatch: executor.commitExecutionGateId=${mutationExecutorRecord.commitExecutionGateId} vs gate.commitExecutionGateId=${commitExecutionGateRecord.commitExecutionGateId}`,
    },
    {
      rule: "commit_execution_gate_bound_to_commit_enable",
      pass: gateBound,
      note: gateBound
        ? `commitExecutionGateRecord.sandboxWriteCommitEnableId === commitEnableRecord.sandboxWriteCommitEnableId (${commitEnableRecord.sandboxWriteCommitEnableId})`
        : `gate/commit-enable mismatch: gate.sandboxWriteCommitEnableId=${commitExecutionGateRecord.sandboxWriteCommitEnableId} vs enable.sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`,
    },
    {
      rule: "mutation_surface_still_disabled",
      pass: true,
      note: "mutationSurfaceEnabled=false — compile-time literal; no mutation surface activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "mutationSurfaceState=descriptor_mutation_surface_pending — output is a descriptor only; mutation surface is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly MutationSurfaceCheck[],
): readonly MutationSurfaceBlockedReason[] {
  const staticReasons: MutationSurfaceBlockedReason[] = [
    { code: "mutation_surface_disabled", reason: "mutationSurfaceEnabled=false — compile-time literal; an explicit first actual sandbox write mutation phase must activate the surface before any sandbox target can be mutated",                                                                                                                                                                                                                                                                                                          static: true },
    { code: "approval_required",         reason: "approvalRequired=true — explicit operator approval is required before the mutation surface can be activated",                                                                                                                                                                                                                                                                                                                                                                             static: true },
    { code: "actual_writes_disabled",    reason: "actualWritesEnabled=false — compile-time literal across all 32 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, sandbox-write-commit-enable, commit-execution-gate, mutation-executor, mutation-commit, and mutation-apply layers", static: true },
  ];
  const dynamicReasons: MutationSurfaceBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedMutationSurfaceReference(
  input: CreateFirstActualSandboxMutationSurfaceInput,
  rollbackChainValid: boolean,
): LinkedMutationSurfaceReference {
  const { mutationApplyRecord, mutationCommitRecord, mutationExecutorRecord, commitExecutionGateRecord } = input;
  return {
    mutationApplyId:        mutationApplyRecord.mutationApplyId,
    mutationCommitId:       mutationCommitRecord.mutationCommitId,
    mutationExecutorId:     mutationExecutorRecord.mutationExecutorId,
    commitExecutionGateId:  commitExecutionGateRecord.commitExecutionGateId,
    rollbackSnapshotId:     mutationApplyRecord.linkedMutationApplyReference.rollbackSnapshotId,
    mutationSurfacePrepared: true,
    mutationSurfaceEnabled:  false,
    mutationApplyEnabled:    false,
    mutationCommitEnabled:   false,
    actualWritesEnabled:     false,
    rollbackChainValid,
    referenceNote: "linked mutation surface reference sources rollbackSnapshotId from mutationApplyRecord.linkedMutationApplyReference; mutation surface disabled; mutation apply disabled; mutation commit disabled; mutation executor disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createFirstActualSandboxMutationSurfaceRecord(
  input: CreateFirstActualSandboxMutationSurfaceInput,
): FirstActualSandboxMutationSurfaceRecord {
  const { mutationApplyRecord, mutationCommitRecord, mutationExecutorRecord, commitExecutionGateRecord, commitEnableRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = mutationApplyRecord.mutationApplyReadinessReport.rollbackChainValid;

  const allChecksPass   = checks.every((c) => c.pass);
  const blockedReasons  = buildBlockedReasons(checks);
  const linkedRef       = buildLinkedMutationSurfaceReference(input, rollbackChainValid);

  const mutationSurfacePlan: MutationSurfacePlanEntry[] = [
    {
      entryId:               randomUUID(),
      operationType:         "descriptor_mutation_surface_planned",
      targetScope:           "sandbox_approved_only",
      mutationSurfaceEnabled: false,
      mutationBlocked:       true,
      note:                  "mutation surface planned in descriptor-only mode; targetScope=sandbox_approved_only; mutationSurfaceEnabled=false; filesystemMutationBlocked=true; first actual sandbox write mutation phase required to activate",
    },
  ];

  const mutationSurfaceReadinessReport: MutationSurfaceReadinessReport = {
    mutationSurfacePrepared:      true,
    mutationSurfaceEnabled:       false,
    mutationApplyEnabled:         false,
    mutationCommitEnabled:        false,
    mutationExecutorEnabled:      false,
    commitExecutionGateEnabled:   false,
    sandboxWriteCommitEnabled:    false,
    runtimeWriteExecutorEnabled:  false,
    writeExecutionGateEnabled:    false,
    scopedActivationEnabled:      false,
    writePermissionEnabled:       false,
    mutationSwitchEnabled:        false,
    guardedWriteEnabled:          false,
    actualWritesEnabled:          false,
    realWritesEnabled:            false,
    approvalRequired:             true,
    allChecksPass,
    blockedReasonCount:           blockedReasons.length,
    rollbackChainValid,
    targetScope:                  "sandbox_approved_only",
    summary: `mutationSurfaceState=descriptor_mutation_surface_pending; mutationSurfaceEnabled=false; mutationApplyEnabled=false; mutationCommitEnabled=false; mutationExecutorEnabled=false; commitExecutionGateEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: FirstActualSandboxMutationSurfaceRecord = {
    mutationSurfaceId:              randomUUID(),
    mutationSurfaceState:           "descriptor_mutation_surface_pending",
    approvalRequired:               true,
    mutationSurfacePrepared:        true,
    mutationSurfaceEnabled:         false,
    mutationApplyEnabled:           false,
    mutationCommitEnabled:          false,
    mutationExecutorEnabled:        false,
    commitExecutionGateEnabled:     false,
    actualWritesEnabled:            false,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    vaultMutationBlocked:           true,
    shellBlocked:                   true,
    networkBlocked:                 true,
    targetScope:                    "sandbox_approved_only",
    implementationPhase:            "descriptor_only",
    mutationApplyId:                mutationApplyRecord.mutationApplyId,
    mutationCommitId:               mutationCommitRecord.mutationCommitId,
    mutationExecutorId:             mutationExecutorRecord.mutationExecutorId,
    commitExecutionGateId:          commitExecutionGateRecord.commitExecutionGateId,
    sandboxWriteCommitEnableId:     commitEnableRecord.sandboxWriteCommitEnableId,
    controlledExecutionId:          executionRecord.controlledExecutionId,
    mutationSurfacePlan,
    mutationSurfaceChecks:          checks,
    mutationSurfaceBlockedReasons:  blockedReasons,
    mutationSurfaceReadinessReport,
    linkedMutationSurfaceReference: linkedRef,
    createdAt:                      new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listFirstActualSandboxMutationSurfaceRecords(): readonly FirstActualSandboxMutationSurfaceRecord[] {
  return _store.slice();
}

export function getFirstActualSandboxMutationSurfaceSummary(): FirstActualSandboxMutationSurfaceSummary {
  return {
    total:                          _store.length,
    byState:                        { descriptor_mutation_surface_pending: _store.length },
    mutationSurfacePrepared:        true,
    mutationSurfaceEnabled:         false,
    mutationApplyEnabled:           false,
    mutationCommitEnabled:          false,
    mutationExecutorEnabled:        false,
    commitExecutionGateEnabled:     false,
    actualWritesEnabled:            false,
    approvalRequired:               true,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    targetScope:                    "sandbox_approved_only",
    mutationSurfaceState:           "descriptor_mutation_surface_pending",
    implementationPhase:            "descriptor_only",
  };
}
