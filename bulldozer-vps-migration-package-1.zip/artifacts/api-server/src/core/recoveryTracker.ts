import { randomBytes } from "node:crypto";
import { logger } from "../lib/logger";
import { emit, subscribe } from "./eventBus";
import { addTimelineEvent } from "./timeline";

export type RecoverySeverity = "low" | "medium" | "high" | "critical";

export interface RecoveryObservation {
  id: string;
  reason: string;
  affectedSubsystem: string;
  severity: RecoverySeverity;
  firstDetectedAt: string;
  lastDetectedAt: string;
  occurrenceCount: number;
  active: boolean;
}

export interface RecoveryTrackingStatus {
  status: "operational";
  activeObservationCount: number;
  historicalObservationCount: number;
  totalTrackedConditions: number;
  severitySummary: Record<RecoverySeverity, number>;
  activeObservations: RecoveryObservation[];
  historicalObservations: RecoveryObservation[];
  timestamp: string;
}

const MAX_HISTORY = 50;

const activeObservations = new Map<string, RecoveryObservation>();
const historicalObservations: RecoveryObservation[] = [];
let totalTrackedConditions = 0;

export function trackRecoveryCondition(
  reason: string,
  affectedSubsystem: string,
  severity: RecoverySeverity,
): void {
  totalTrackedConditions++;
  const now = new Date().toISOString();
  const existing = activeObservations.get(reason);

  if (existing) {
    existing.lastDetectedAt = now;
    existing.occurrenceCount++;
    if (severityRank(severity) > severityRank(existing.severity)) {
      existing.severity = severity;
    }
  } else {
    const obs: RecoveryObservation = {
      id: randomBytes(4).toString("hex"),
      reason,
      affectedSubsystem,
      severity,
      firstDetectedAt: now,
      lastDetectedAt: now,
      occurrenceCount: 1,
      active: true,
    };
    activeObservations.set(reason, obs);
    addTimelineEvent({
      level: "warn",
      source: "recovery-tracker",
      message: `Recovery condition tracked: ${reason}`,
      metadata: { reason, affectedSubsystem, severity },
    });
    emit("recovery_tracker:condition_tracked", "recovery-tracker", {
      reason,
      affectedSubsystem,
      severity,
    });
    logger.warn({ reason, affectedSubsystem, severity }, "Recovery condition tracked (observation only)");
  }
}

export function clearRecoveryTrackingHistory(): void {
  const now = new Date().toISOString();

  for (const obs of activeObservations.values()) {
    historicalObservations.push({ ...obs, active: false });
  }
  activeObservations.clear();

  while (historicalObservations.length > MAX_HISTORY) {
    historicalObservations.shift();
  }

  addTimelineEvent({
    level: "info",
    source: "recovery-tracker",
    message: "Recovery tracking history cleared",
    metadata: { clearedAt: now },
  });
  emit("recovery_tracker:history_cleared", "recovery-tracker", { clearedAt: now });
  logger.info({ clearedAt: now }, "Recovery tracking history cleared");
}

export function getRecoveryTrackingStatus(): RecoveryTrackingStatus {
  const active = Array.from(activeObservations.values());
  const severitySummary: Record<RecoverySeverity, number> = {
    low: 0,
    medium: 0,
    high: 0,
    critical: 0,
  };
  for (const obs of active) {
    severitySummary[obs.severity]++;
  }

  return {
    status: "operational",
    activeObservationCount: active.length,
    historicalObservationCount: historicalObservations.length,
    totalTrackedConditions,
    severitySummary,
    activeObservations: active,
    historicalObservations: [...historicalObservations].reverse(),
    timestamp: new Date().toISOString(),
  };
}

export function initRecoveryTracking(): void {
  subscribe("freeze:warning", () => {
    trackRecoveryCondition("repeated_freeze_warnings", "freeze_detector", "low");
  });

  subscribe("freeze:detected", () => {
    trackRecoveryCondition("event_loop_freeze", "freeze_detector", "medium");
  });

  subscribe("crash:exception", () => {
    trackRecoveryCondition("uncaught_exception", "crash_detector", "critical");
  });

  subscribe("crash:rejection", () => {
    trackRecoveryCondition("unhandled_rejection", "crash_detector", "high");
  });

  subscribe("crash:warning", () => {
    trackRecoveryCondition("process_warning", "crash_detector", "low");
  });

  subscribe("watchdog:degraded", () => {
    trackRecoveryCondition("watchdog_degraded", "watchdog", "medium");
  });

  subscribe("watchdog:runtime_not_ready", () => {
    trackRecoveryCondition("runtime_not_ready", "runtime", "high");
  });

  subscribe("watchdog:freeze_detected", () => {
    trackRecoveryCondition("freeze_detected_by_watchdog", "watchdog", "medium");
  });

  subscribe("watchdog:crash_detected", () => {
    trackRecoveryCondition("crash_detected_by_watchdog", "watchdog", "critical");
  });

  subscribe("restart_supervisor:recommended", () => {
    trackRecoveryCondition("restart_recommended", "restart_supervisor", "high");
  });

  emit("recovery_tracker:initialized", "recovery-tracker", {});
  addTimelineEvent({
    level: "info",
    source: "recovery-tracker",
    message: "Recovery tracker initialized",
  });
  logger.info("Recovery tracker initialized (observation only)");
}

function severityRank(s: RecoverySeverity): number {
  return { low: 0, medium: 1, high: 2, critical: 3 }[s];
}
