import { randomBytes } from "node:crypto";
import {
  getWorkspaceSummary,
  getWorkspaceHealth,
  type WorkspaceSummary,
} from "./workspaceShell";
import { getLatestWorkspaceSnapshot } from "./workspaceSnapshots";
import {
  listAuditReports,
  type AuditReportType,
  type WorkspaceAuditReportListItem,
} from "./workspaceAuditReport";

const EXECUTION_BLOCKED: true = true;
const DIGEST_RECENT_REPORT_COUNT = 5;
const DIGEST_ALL_REPORTS_LIMIT = 10;

// --- Types ---

export interface DigestSnapshotExcerpt {
  snapshotId: string;
  schemaVersion: string;
  createdAt: string;
  projectCount: number;
  memberCount: number;
  activityCount: number;
}

export interface DigestReportExcerpt {
  reportId: string;
  createdAt: string;
  reportType: AuditReportType;
  hasChanges: boolean | null;
  changeCount: number | null;
  snapshotRefCount: number;
  timelineEventCount: number;
  executionBlocked: true;
}

export interface DigestChangeSignalSummary {
  retainedReportCount: number;
  snapshotComparisonCount: number;
  timelineSummaryCount: number;
  governanceReviewCount: number;
  hasChangesTrue: number;
  hasChangesFalse: number;
  hasChangesNull: number;
  latestReportType: AuditReportType | null;
  latestReportAt: string | null;
}

export interface DigestGovernanceExcerpt {
  totalProjects: number;
  activeProjects: number;
  archivedProjects: number;
  suspendedProjects: number;
  capacityUtilizationPercent: number;
  atCapacity: boolean;
  memberRecords: number;
  activityRecords: number;
  projectsWithCustomQuotas: number;
}

export interface DigestDiagnosticsExcerpt {
  status: string;
  registryOperational: boolean;
  storeKeyCount: number;
}

export interface WorkspaceAuditDigest {
  digestId: string;
  generatedAt: string;
  workspaceSummary: WorkspaceSummary;
  latestSnapshot: DigestSnapshotExcerpt | null;
  recentReports: DigestReportExcerpt[];
  changeSignalSummary: DigestChangeSignalSummary;
  diagnosticsExcerpt: DigestDiagnosticsExcerpt;
  governanceExcerpt: DigestGovernanceExcerpt;
  executionBlocked: true;
}

// --- Internal helpers ---

function buildSnapshotExcerpt(): DigestSnapshotExcerpt | null {
  const snap = getLatestWorkspaceSnapshot();
  if (!snap) return null;
  return {
    snapshotId: snap.snapshotId,
    schemaVersion: snap.schemaVersion,
    createdAt: snap.createdAt,
    projectCount: snap.summary.projects.total,
    memberCount: snap.summary.members.totalRecords,
    activityCount: snap.summary.activity.totalRecords,
  };
}

function buildChangeSignalSummary(
  allReports: WorkspaceAuditReportListItem[],
): DigestChangeSignalSummary {
  let snapshotComparisonCount = 0;
  let timelineSummaryCount = 0;
  let governanceReviewCount = 0;
  let hasChangesTrue = 0;
  let hasChangesFalse = 0;
  let hasChangesNull = 0;

  for (const r of allReports) {
    if (r.reportType === "snapshot_comparison") snapshotComparisonCount++;
    else if (r.reportType === "timeline_summary") timelineSummaryCount++;
    else governanceReviewCount++;

    if (r.hasChanges === true) hasChangesTrue++;
    else if (r.hasChanges === false) hasChangesFalse++;
    else hasChangesNull++;
  }

  const latest = allReports[0] ?? null;
  return {
    retainedReportCount: allReports.length,
    snapshotComparisonCount,
    timelineSummaryCount,
    governanceReviewCount,
    hasChangesTrue,
    hasChangesFalse,
    hasChangesNull,
    latestReportType: latest?.reportType ?? null,
    latestReportAt: latest?.createdAt ?? null,
  };
}

function buildGovernanceExcerpt(summary: WorkspaceSummary): DigestGovernanceExcerpt {
  return {
    totalProjects: summary.projects.total,
    activeProjects: summary.projects.active,
    archivedProjects: summary.projects.archived,
    suspendedProjects: summary.projects.suspended,
    capacityUtilizationPercent: summary.capacity.utilizationPercent,
    atCapacity: summary.capacity.atCapacity,
    memberRecords: summary.members.totalRecords,
    activityRecords: summary.activity.totalRecords,
    projectsWithCustomQuotas: summary.quotas.projectsWithCustomQuotas,
  };
}

// --- Public API ---

export function getWorkspaceAuditDigest(): WorkspaceAuditDigest {
  const digestId = randomBytes(8).toString("hex");
  const generatedAt = new Date().toISOString();

  const workspaceSummary = getWorkspaceSummary();
  const health = getWorkspaceHealth();

  const allReportsResult = listAuditReports({ limit: DIGEST_ALL_REPORTS_LIMIT });
  const allReports = allReportsResult.reports;

  const recentReports: DigestReportExcerpt[] = allReports
    .slice(0, DIGEST_RECENT_REPORT_COUNT)
    .map((r) => ({
      reportId: r.reportId,
      createdAt: r.createdAt,
      reportType: r.reportType,
      hasChanges: r.hasChanges,
      changeCount: r.changeCount,
      snapshotRefCount: r.snapshotRefCount,
      timelineEventCount: r.timelineEventCount,
      executionBlocked: EXECUTION_BLOCKED,
    }));

  return {
    digestId,
    generatedAt,
    workspaceSummary,
    latestSnapshot: buildSnapshotExcerpt(),
    recentReports,
    changeSignalSummary: buildChangeSignalSummary(allReports),
    diagnosticsExcerpt: {
      status: health.status,
      registryOperational: health.registryOperational,
      storeKeyCount: health.storeKeyCount,
    },
    governanceExcerpt: buildGovernanceExcerpt(workspaceSummary),
    executionBlocked: EXECUTION_BLOCKED,
  };
}
