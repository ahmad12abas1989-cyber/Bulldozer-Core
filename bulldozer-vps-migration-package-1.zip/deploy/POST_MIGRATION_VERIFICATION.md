# Bulldozer Mother Core — Post-Migration Verification Checklist

> Run this checklist immediately after completing a VPS migration or major update.
> Every item must pass before the migration is declared successful.
> Record results with timestamps.

---

## Section 1 — Server startup

| # | Check | Command | Expected |
|---|---|---|---|
| 1.1 | Container is running | `docker ps --filter name=bulldozer-core` | STATUS: Up |
| 1.2 | No recent restarts | `docker inspect bulldozer-core --format '{{.RestartCount}}'` | `0` |
| 1.3 | Container log has no ERROR on startup | `docker logs bulldozer-core 2>&1 \| grep -i error \| head -5` | No errors |
| 1.4 | Server bound to expected port | `ss -tlnp \| grep <HOST_PORT>` | Port listening |

---

## Section 2 — Core endpoint health

Run: `./deploy/scripts/health-check.sh`

All items must show `PASS`:

- [ ] `GET /api/healthz` → 200
- [ ] `GET /api/status` → 200
- [ ] `GET /api/metrics` → 200
- [ ] `GET /api/health/full` → 200
- [ ] `GET /api/diagnostics/snapshot` → 200
- [ ] `GET /api/runtime/graph/status` → 200
- [ ] `GET /api/runtime/capabilities` → 200
- [ ] `GET /api/runtime/registry` → 200
- [ ] `GET /api/access/status` → 200
- [ ] `GET /api/audit/status` → 200

---

## Section 3 — UI routes

- [ ] `GET /ui` → 200
- [ ] `GET /ui/overview` → 200
- [ ] `GET /ui/governance` → 200
- [ ] `GET /ui/observation` → 200 (Architecture Era Banner: **Production Extraction**)
- [ ] `GET /ui/diagnostics` → 200
- [ ] `GET /ui/comparison` → 200

---

## Section 4 — Runtime invariants

Verify each JSON field by running the commands below:

```bash
BASE=http://localhost:<HOST_PORT>

# 4.1 allHealthy=true
curl -s $BASE/api/workspace/ui/audit | grep '"allHealthy":true'

# 4.2 cycleCount=0 (no dependency graph cycles)
curl -s $BASE/api/runtime/graph/status | grep '"cycleCount":0'

# 4.3 routePolicyCount=162
curl -s $BASE/api/access/status | grep '"routePolicyCount":162'

# 4.4 subsystemCount=27
curl -s $BASE/api/runtime/registry/status | grep '"registeredCount":27'

# 4.5 graphNodeCount=27
curl -s $BASE/api/runtime/graph/status | grep '"nodeCount":27'
```

- [ ] 4.1 `allHealthy=true`
- [ ] 4.2 `cycleCount=0`
- [ ] 4.3 `routePolicyCount=162`
- [ ] 4.4 Subsystems registered: 27
- [ ] 4.5 Graph nodes: 27

---

## Section 5 — Mother Core write-lock verification

These invariants must be confirmed after every migration. They confirm the sealed architecture is intact.

```bash
BASE=http://localhost:<HOST_PORT>

# 5.1 Controlled execution endpoint — must carry executionBlocked=true
curl -s $BASE/api/execution/controlled | python3 -m json.tool | grep executionBlocked

# 5.2 Filesystem mutation path is blocked
curl -s $BASE/api/sandbox/build/plans | python3 -m json.tool
```

- [ ] 5.1 `executionBlocked=true` present in `/api/execution/controlled`
- [ ] 5.2 No filesystem mutation has been activated
- [ ] 5.3 `actualWritesEnabled=false` — confirmed in observation UI at `/ui/observation` (Actual Writes = **BLOCKED**)
- [ ] 5.4 `filesystemMutationApprovalGranted=false` — sealed in 40 core layers, not overridden
- [ ] 5.5 Architecture Era Banner at `/ui/observation` shows:
  - Era: **Production Extraction**
  - Badge: **INFRA LOCKED**
  - Badge: **WRITES BLOCKED**

---

## Section 6 — Storage integrity

- [ ] Storage directory is mounted and writable by the container:
  ```bash
  docker exec bulldozer-core ls /app/storage
  ```
  Expected directories: `snapshots`, `runtime-snapshots`, `runtime-state`, `tasks`, `store`

- [ ] Store files are present and valid JSON:
  ```bash
  docker exec bulldozer-core sh -c \
    'for f in /app/storage/store/*.json; do
       node -e "JSON.parse(require(\"fs\").readFileSync(\"$f\",\"utf8\"))" 2>/dev/null \
       && echo "OK: $f" || echo "INVALID: $f"
     done'
  ```
  All files: `OK`

- [ ] Audit log has entries (confirms the server has been writing):
  ```bash
  curl -s http://localhost:<HOST_PORT>/api/audit/log | python3 -m json.tool | grep '"total"'
  ```

---

## Section 7 — Persistence across restart

- [ ] Stop and restart the container, then re-verify Section 2:
  ```bash
  ./deploy/scripts/stop.sh
  ./deploy/scripts/start.sh
  ./deploy/scripts/health-check.sh
  ```
- [ ] Confirm storage survives restart — audit log entry count should be >= pre-restart count

---

## Section 8 — Backup verification

- [ ] Run a manual backup: `./deploy/scripts/backup.sh`
- [ ] Confirm archive was created in `BACKUP_DIR`
- [ ] Confirm `.sha256` sidecar was created
- [ ] Confirm checksum passes: `sha256sum --check <archive>.sha256`

---

## Section 9 — TLS / reverse proxy (if configured)

- [ ] `https://your-domain.com/api/healthz` → 200 over HTTPS
- [ ] HTTP redirects to HTTPS (no mixed-content)
- [ ] TLS certificate is valid and not expiring within 30 days:
  ```bash
  echo | openssl s_client -connect your-domain.com:443 2>/dev/null \
    | openssl x509 -noout -dates
  ```

---

## Sign-off

| Field | Value |
|---|---|
| Migration date (UTC) | |
| Operator | |
| Git commit SHA | |
| Docker image ID | `docker inspect bulldozer-core:latest --format '{{.Id}}'` |
| All sections passed | ☐ Yes ☐ No — see notes |
| Notes | |

Migration is declared **complete** only when all sections are checked and sign-off is recorded.
