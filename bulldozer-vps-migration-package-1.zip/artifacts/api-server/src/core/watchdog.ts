import { logger } from "../lib/logger";
import { getRuntimeInfo } from "./runtime";
import { getFreezeStatus } from "./freezeDetector";
import { getCrashStatus } from "./crashDetector";
import { emit } from "./eventBus";
import { addTimelineEvent } from "./timeline";

export type WatchdogStatus = "healthy" | "degraded" | "failed";

export interface WatchdogState {
  status: WatchdogStatus;
  active: boolean;
  lastHeartbeatAt: string | null;
  lastHealthyAt: string | null;
  missedHealthChecks: number;
  degradedCount: number;
  lastDegradedAt: string | null;
  monitoredSystems: string[];
  timestamp: string;
}

const WATCHDOG_INTERVAL_MS = 15_000;
const MONITORED_SYSTEMS = ["runtime", "freeze_detector", "crash_detector"];

let timer: ReturnType<typeof setInterval> | null = null;
let active = false;

let status: WatchdogStatus = "healthy";
let lastHeartbeatAt: string | null = null;
let lastHealthyAt: string | null = null;
let missedHealthChecks = 0;
let degradedCount = 0;
let lastDegradedAt: string | null = null;

function tick(): void {
  const now = new Date().toISOString();
  lastHeartbeatAt = now;

  let thisDegraded = false;

  const runtimeInfo = getRuntimeInfo();
  if (runtimeInfo.state !== "ready") {
    missedHealthChecks++;
    thisDegraded = true;
    emit("watchdog:runtime_not_ready", "watchdog", { runtimeState: runtimeInfo.state });
    addTimelineEvent({
      level: "warn",
      source: "watchdog",
      message: "Watchdog: runtime not ready",
      metadata: { runtimeState: runtimeInfo.state },
    });
  }

  const freezeState = getFreezeStatus();
  if (freezeState.status === "frozen") {
    thisDegraded = true;
    emit("watchdog:freeze_detected", "watchdog", { lagMs: freezeState.lastLagMs });
    addTimelineEvent({
      level: "warn",
      source: "watchdog",
      message: "Watchdog: event loop freeze detected",
      metadata: { lagMs: freezeState.lastLagMs },
    });
  } else if (freezeState.status === "warning") {
    thisDegraded = true;
    emit("watchdog:freeze_warning", "watchdog", { lagMs: freezeState.lastLagMs });
  }

  const crashState = getCrashStatus();
  if (crashState.status === "crashed") {
    thisDegraded = true;
    emit("watchdog:crash_detected", "watchdog", {
      lastCrashType: crashState.lastCrashType,
      lastCrashMessage: crashState.lastCrashMessage,
    });
    addTimelineEvent({
      level: "error",
      source: "watchdog",
      message: "Watchdog: crash state detected",
      metadata: {
        lastCrashType: crashState.lastCrashType,
        lastCrashMessage: crashState.lastCrashMessage,
      },
    });
  }

  if (thisDegraded) {
    degradedCount++;
    lastDegradedAt = now;
    status = "degraded";
    emit("watchdog:degraded", "watchdog", { degradedCount, missedHealthChecks });
    logger.warn({ degradedCount, missedHealthChecks }, "Watchdog: degraded state observed");
  } else {
    lastHealthyAt = now;
    status = "healthy";
    emit("watchdog:heartbeat", "watchdog", { degradedCount });
  }
}

export function startWatchdog(): void {
  if (active) return;
  active = true;
  timer = setInterval(tick, WATCHDOG_INTERVAL_MS);
  if (typeof timer.unref === "function") timer.unref();
  addTimelineEvent({ level: "info", source: "watchdog", message: "Watchdog started" });
  emit("watchdog:started", "watchdog", { intervalMs: WATCHDOG_INTERVAL_MS });
  logger.info({ intervalMs: WATCHDOG_INTERVAL_MS }, "Watchdog started");
}

export function stopWatchdog(): void {
  if (!active) return;
  active = false;
  if (timer !== null) {
    clearInterval(timer);
    timer = null;
  }
  addTimelineEvent({ level: "info", source: "watchdog", message: "Watchdog stopped" });
  emit("watchdog:stopped", "watchdog", { degradedCount });
  logger.info("Watchdog stopped");
}

export function getWatchdogStatus(): WatchdogState {
  return {
    status,
    active,
    lastHeartbeatAt,
    lastHealthyAt,
    missedHealthChecks,
    degradedCount,
    lastDegradedAt,
    monitoredSystems: MONITORED_SYSTEMS,
    timestamp: new Date().toISOString(),
  };
}
