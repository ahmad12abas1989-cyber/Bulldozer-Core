// Auth Audit Log — Phase 187
// Append-only in-memory store for auth/session audit events.
// Separate from core/auditLog.ts (access enforcement audit).
// Pure module — no init, no subsystem registration, no health checks,
// no event emission, no persistence, no deletion methods.

import { randomBytes } from "node:crypto";

// ─── Types ───────────────────────────────────────────────────────────────────

export type AuthAuditEventType =
  | "login_success"
  | "login_failure"
  | "logout"
  | "session_expired"
  | "privilege_change"
  | "token_revoked"
  | "auth_limit_hit"
  | "suspicious_activity";

export type AuthAuditOutcome =
  | "allowed"    // login_success
  | "denied"     // login_failure
  | "completed"  // logout
  | "expired"    // session_expired
  | "granted"    // privilege_change (positive direction)
  | "revoked"    // privilege_change (negative direction) | token_revoked
  | "blocked"    // auth_limit_hit
  | "flagged";   // suspicious_activity

export interface AuthAuditEvent {
  eventId: string;
  actorType: string;
  actorId: string;
  eventType: AuthAuditEventType;
  route: string;
  ip: string;
  timestamp: string;
  outcome: AuthAuditOutcome;
  sessionId: string | null;
  auditChainId: string;
}

export interface AppendAuthAuditEventInput {
  actorType: string;
  actorId: string;
  eventType: AuthAuditEventType;
  route: string;
  ip: string;
  outcome: AuthAuditOutcome;
  sessionId?: string | null;
  auditChainId: string;
  // Any additional fields are accepted but prohibited names are dropped silently.
  [key: string]: unknown;
}

export interface AuthAuditSummary {
  totalEvents: number;
  byEventType: Record<AuthAuditEventType, number>;
  byOutcome: Record<AuthAuditOutcome, number>;
  oldestEventAt: string | null;
  newestEventAt: string | null;
  appendOnly: true;
  persistenceEnabled: false;
  implementationPhase: "skeleton";
}

// ─── Constants ───────────────────────────────────────────────────────────────

// Field names that are never allowed in audit event records.
const PROHIBITED_FIELD_NAMES = new Set([
  "password",
  "secret",
  "token",
  "credential",
  "credentials",
  "passwd",
  "pass",
  "apiKey",
  "api_key",
  "privateKey",
  "private_key",
]);

const ALL_EVENT_TYPES: AuthAuditEventType[] = [
  "login_success",
  "login_failure",
  "logout",
  "session_expired",
  "privilege_change",
  "token_revoked",
  "auth_limit_hit",
  "suspicious_activity",
];

const ALL_OUTCOMES: AuthAuditOutcome[] = [
  "allowed",
  "denied",
  "completed",
  "expired",
  "granted",
  "revoked",
  "blocked",
  "flagged",
];

// ─── In-memory append-only store ─────────────────────────────────────────────

// Ring buffer capped at 1000 events. Oldest events drop when cap is exceeded.
const MAX_EVENTS = 1000;
const EVENT_STORE: AuthAuditEvent[] = [];

function generateEventId(): string {
  return randomBytes(16).toString("hex");
}

function zeroByEventType(): Record<AuthAuditEventType, number> {
  return Object.fromEntries(ALL_EVENT_TYPES.map((t) => [t, 0])) as Record<AuthAuditEventType, number>;
}

function zeroByOutcome(): Record<AuthAuditOutcome, number> {
  return Object.fromEntries(ALL_OUTCOMES.map((o) => [o, 0])) as Record<AuthAuditOutcome, number>;
}

// ─── Public API ──────────────────────────────────────────────────────────────

// Append a new auth audit event to the in-memory store.
// Fields named password, secret, token, credential (and variants) are silently dropped.
// eventId and timestamp are always generated server-side — any supplied values are ignored.
export function appendAuthAuditEvent(input: AppendAuthAuditEventInput): AuthAuditEvent {
  // Sanitise: drop any prohibited fields from caller-supplied extras
  for (const key of Object.keys(input)) {
    if (PROHIBITED_FIELD_NAMES.has(key)) {
      delete input[key];
    }
  }

  const event: AuthAuditEvent = {
    eventId:      generateEventId(),
    actorType:    input.actorType,
    actorId:      input.actorId,
    eventType:    input.eventType,
    route:        input.route,
    ip:           input.ip,
    timestamp:    new Date().toISOString(),
    outcome:      input.outcome,
    sessionId:    input.sessionId ?? null,
    auditChainId: input.auditChainId,
  };

  if (EVENT_STORE.length >= MAX_EVENTS) {
    EVENT_STORE.shift(); // drop oldest
  }
  EVENT_STORE.push(event);

  return event;
}

// Return a shallow copy of all stored events, newest-first.
// Visibility enforcement is the caller's responsibility — this function
// returns the full store; a future read-path layer will apply actor scoping.
export function listAuthAuditEvents(): AuthAuditEvent[] {
  return EVENT_STORE.slice().reverse();
}

// Return a summary of stored events.
export function getAuthAuditSummary(): AuthAuditSummary {
  const byEventType = zeroByEventType();
  const byOutcome   = zeroByOutcome();

  for (const ev of EVENT_STORE) {
    byEventType[ev.eventType] = (byEventType[ev.eventType] ?? 0) + 1;
    byOutcome[ev.outcome]     = (byOutcome[ev.outcome]     ?? 0) + 1;
  }

  const oldest = EVENT_STORE.length > 0 ? EVENT_STORE[0].timestamp : null;
  const newest = EVENT_STORE.length > 0 ? EVENT_STORE[EVENT_STORE.length - 1].timestamp : null;

  return {
    totalEvents:          EVENT_STORE.length,
    byEventType,
    byOutcome,
    oldestEventAt:        oldest,
    newestEventAt:        newest,
    appendOnly:           true,
    persistenceEnabled:   false,
    implementationPhase:  "skeleton",
  };
}
