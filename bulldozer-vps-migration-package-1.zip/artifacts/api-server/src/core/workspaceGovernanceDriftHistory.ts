// Governance Drift History — Phase 128
// Persistent ring buffer for point-in-time Governance Drift Detector snapshots.
// Max 10 entries, atomic write semantics, load-on-boot, bounded ring pruning.
// No rendering, no autonomous execution, no mutation outside the ring.

import { randomBytes } from "node:crypto";
import { readStore, writeStore } from "./persistentStore";
import { logger } from "../lib/logger";
import { getGovernanceDrift, type GovernanceDriftResult, type RiskLevel } from "./workspaceGovernanceDriftDetector";

const EXECUTION_BLOCKED: true = true;
const MAX_ENTRIES = 10;
const STORE_KEY = "workspace-governance-drift-history";

// --- Types ---

export interface DriftHistoryEntry {
  captureSeq: number;
  createdAt: string;
  driftId: string;
  snapshot: GovernanceDriftResult;
  executionBlocked: true;
}

// Summary projection — excludes the full snapshot internals.
// Exposes only the top-level scalar signals from each captured drift result.
export interface DriftHistoryListItem {
  captureSeq: number;
  createdAt: string;
  driftId: string;
  driftDetected: boolean;
  riskLevel: RiskLevel;
  scorecardDriftDetected: boolean;
  ledgerDriftDetected: boolean;
  worstScoreDrop: number;
  worstCoverageDrop: number;
  executionBlocked: true;
}

export interface DriftHistoryCaptureResult {
  captureSeq: number;
  createdAt: string;
  driftId: string;
  driftDetected: boolean;
  riskLevel: RiskLevel;
  scorecardDriftDetected: boolean;
  ledgerDriftDetected: boolean;
  worstScoreDrop: number;
  worstCoverageDrop: number;
  ringSize: number;
  executionBlocked: true;
}

export interface DriftHistoryListResult {
  entries: DriftHistoryListItem[];
  total: number;
  maxRetained: number;
  storeKey: string;
  executionBlocked: true;
}

// --- Module state ---

let historyRing: DriftHistoryEntry[] = [];
let nextCaptureSeq = 1;
let loadedOnBoot = 0;
let isInitialized = false;

// --- Persistence helpers ---

function flush(): void {
  try {
    writeStore<DriftHistoryEntry[]>(STORE_KEY, historyRing);
  } catch (err) {
    logger.error(
      { err, storeKey: STORE_KEY },
      "Drift history: flush failed — ring preserved in memory",
    );
  }
}

function isValidEntry(obj: unknown): obj is DriftHistoryEntry {
  if (obj === null || typeof obj !== "object") return false;
  const e = obj as Record<string, unknown>;
  return (
    typeof e["captureSeq"] === "number" &&
    typeof e["createdAt"] === "string" &&
    typeof e["driftId"] === "string" &&
    e["snapshot"] !== null &&
    typeof e["snapshot"] === "object" &&
    e["executionBlocked"] === true
  );
}

function createDriftId(): string {
  return randomBytes(8).toString("hex");
}

// --- Init ---

export function initWorkspaceGovernanceDriftHistory(): void {
  if (isInitialized) return;

  const stored = readStore<unknown[]>(STORE_KEY);
  if (Array.isArray(stored)) {
    const valid = stored.filter(isValidEntry);
    historyRing = valid.slice(-MAX_ENTRIES);
    loadedOnBoot = historyRing.length;
    if (valid.length !== stored.length) {
      logger.warn(
        { total: stored.length, valid: valid.length, key: STORE_KEY },
        "Drift history load: skipped invalid entries on boot",
      );
    }
    // Resume captureSeq from the highest persisted seq to avoid collisions after restart.
    if (historyRing.length > 0) {
      const maxSeq = Math.max(...historyRing.map((e) => e.captureSeq));
      nextCaptureSeq = maxSeq + 1;
    }
  }

  isInitialized = true;
  logger.info(
    {
      subsystem: "workspace_governance_drift_history",
      loadedOnBoot,
      maxRetained: MAX_ENTRIES,
      storeKey: STORE_KEY,
      nextCaptureSeq,
    },
    "Workspace governance drift history initialized",
  );
}

// --- Capture ---

// Calls getGovernanceDrift() fresh, stores the result in the ring, flushes to disk.
// Returns a summary-only capture result — no full snapshot internals exposed.
// executionBlocked: true at every level; no autonomous execution path.
export function captureDriftSnapshot(): DriftHistoryCaptureResult {
  const drift = getGovernanceDrift();
  const captureSeq = nextCaptureSeq++;
  const createdAt = drift.generatedAt;
  const driftId = createDriftId();

  const entry: DriftHistoryEntry = {
    captureSeq,
    createdAt,
    driftId,
    snapshot: drift,
    executionBlocked: EXECUTION_BLOCKED,
  };

  historyRing.push(entry);

  // Prune to ring cap — oldest (lowest captureSeq) removed first.
  while (historyRing.length > MAX_ENTRIES) {
    historyRing.shift();
  }

  flush();

  return {
    captureSeq,
    createdAt,
    driftId,
    driftDetected: drift.driftDetected,
    riskLevel: drift.riskLevel,
    scorecardDriftDetected: drift.scorecardDrift.driftDetected,
    ledgerDriftDetected: drift.ledgerDrift.driftDetected,
    worstScoreDrop: drift.scorecardDrift.worstScoreDrop,
    worstCoverageDrop: drift.ledgerDrift.worstCoverageDrop,
    ringSize: historyRing.length,
    executionBlocked: EXECUTION_BLOCKED,
  };
}

// --- List ---

// Returns newest-first summary projection of all retained history entries.
// Full snapshot internals (scorecardDrift/ledgerDrift sub-objects) are intentionally
// excluded from list items — callers needing detail should capture fresh via POST.
export function listDriftHistory(): DriftHistoryListResult {
  const items: DriftHistoryListItem[] = [...historyRing]
    .sort((a, b) => b.captureSeq - a.captureSeq)
    .map((e) => ({
      captureSeq:             e.captureSeq,
      createdAt:              e.createdAt,
      driftId:                e.driftId,
      driftDetected:          e.snapshot.driftDetected,
      riskLevel:              e.snapshot.riskLevel,
      scorecardDriftDetected: e.snapshot.scorecardDrift.driftDetected,
      ledgerDriftDetected:    e.snapshot.ledgerDrift.driftDetected,
      worstScoreDrop:         e.snapshot.scorecardDrift.worstScoreDrop,
      worstCoverageDrop:      e.snapshot.ledgerDrift.worstCoverageDrop,
      executionBlocked:       EXECUTION_BLOCKED,
    }));

  return {
    entries:     items,
    total:       items.length,
    maxRetained: MAX_ENTRIES,
    storeKey:    STORE_KEY,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
