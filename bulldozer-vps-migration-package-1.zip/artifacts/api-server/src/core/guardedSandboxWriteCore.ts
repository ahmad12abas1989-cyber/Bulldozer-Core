import { WritePlanRecord }                                      from "./sandboxWritePlanCore.js";
import { SandboxWritablePath, SandboxProtectedPath }           from "./sandboxFilesystemCore.js";
import { WriteGateRecord }                                     from "./realWriteEnablementGateCore.js";
import { ControlledExecutionRecord }                           from "./controlledExecutionCore.js";
import { randomBytes }                                         from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type GuardedWriteState = "guarded_descriptor_ready";

export type WriteSafetyCheckRule =
  | "write_plan_exists"
  | "write_gate_exists"
  | "execution_record_exists"
  | "write_gate_clear"
  | "rollback_ready"
  | "targets_limited_to_sandbox"
  | "protected_targets_blocked"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface WriteOperation {
  readonly operationIndex:    number;
  readonly targetPath:        SandboxWritablePath;
  readonly operationType:     "create" | "overwrite" | "append";
  readonly contentDescriptor: string;
  readonly actualWritesEnabled: false;
  readonly realWritesEnabled:   false;
  readonly writeBlocked:        true;
  readonly reason:              string;
}

export interface BlockedOperation {
  readonly targetPath:   SandboxProtectedPath;
  readonly writeBlocked: true;
  readonly reason:       string;
}

export interface WriteSafetyCheck {
  readonly rule:   WriteSafetyCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface RollbackWriteReport {
  readonly rollbackRequired:        true;
  readonly rollbackDescriptorOnly:  true;
  readonly rollbackOperationsCount: number;
  readonly rollbackTargetState:     "guarded_descriptor_ready";
  readonly rollbackReady:           boolean;
  readonly summary:                 string;
}

export interface GuardedSandboxWriteRecord {
  readonly guardedWriteId:              string;
  readonly writeState:                  GuardedWriteState;
  readonly approvalRequired:            true;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly motherCoreWritesBlocked:     true;
  readonly protectedZoneWritesBlocked:  true;
  readonly vaultAccessBlocked:          true;
  readonly shellAccessBlocked:          true;
  readonly networkAccessBlocked:        true;
  readonly deploymentWritesBlocked:     true;
  readonly rollbackRequired:            true;
  readonly implementationPhase:         "descriptor_only";
  readonly writePlanId:                 string;
  readonly writeGateId:                 string;
  readonly executionRecordId:           string;
  readonly approvalReference:           string;
  readonly writeOperations:             readonly WriteOperation[];
  readonly blockedOperations:           readonly BlockedOperation[];
  readonly writeSafetyChecks:           readonly WriteSafetyCheck[];
  readonly rollbackWriteReport:         RollbackWriteReport;
  readonly createdAt:                   string;
}

export interface CreateGuardedSandboxWriteInput {
  readonly writePlanRecord:    WritePlanRecord;
  readonly writeGateRecord:    WriteGateRecord;
  readonly executionRecord:    ControlledExecutionRecord;
}

export interface GuardedSandboxWriteSummary {
  readonly total:                       number;
  readonly byState:                     Record<GuardedWriteState, number>;
  readonly actualWritesEnabled:         false;
  readonly realWritesEnabled:           false;
  readonly motherCoreWritesBlocked:     true;
  readonly protectedZoneWritesBlocked:  true;
  readonly vaultAccessBlocked:          true;
  readonly shellAccessBlocked:          true;
  readonly networkAccessBlocked:        true;
  readonly deploymentWritesBlocked:     true;
  readonly approvalRequired:            true;
  readonly allowedTargetPaths:          readonly SandboxWritablePath[];
  readonly blockedTargetPaths:          readonly SandboxProtectedPath[];
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildWriteOperations(
  writePlanRecord: WritePlanRecord,
): readonly WriteOperation[] {
  return writePlanRecord.plannedWrites.map((pw, idx) => ({
    operationIndex:    idx,
    targetPath:        pw.targetPath,
    operationType:     pw.operationType,
    contentDescriptor: `Guarded write descriptor for ${pw.targetPath} (${pw.operationType}) — ${pw.contentDescriptor}`,
    actualWritesEnabled: false,
    realWritesEnabled:   false,
    writeBlocked:        true,
    reason:              "Guarded descriptor phase — write operations defined but not executed; actual writes require explicit future enablement + operator approval",
  }));
}

function buildBlockedOperations(
  writePlanRecord: WritePlanRecord,
): readonly BlockedOperation[] {
  return writePlanRecord.blockedWrites.map(bw => ({
    targetPath:   bw.targetPath,
    writeBlocked: true,
    reason:       `Protected zone — permanently blocked at all phases (${bw.reason})`,
  }));
}

function buildSafetyChecks(
  input: CreateGuardedSandboxWriteInput,
): readonly WriteSafetyCheck[] {
  const { writePlanRecord, writeGateRecord, executionRecord } = input;
  const gateClear   = writeGateRecord.writeReadinessReport.allChecksPass;
  const rollbackReady =
    writePlanRecord.rollbackWritePlan.rollbackSequenceReady &&
    writeGateRecord.writeReadinessReport.rollbackReady;
  const allTargetsSandbox = writePlanRecord.plannedWrites.every(
    pw => pw.targetPath.startsWith("/sandbox/"),
  );
  const allProtectedBlocked = writePlanRecord.blockedWrites.length > 0 &&
    writePlanRecord.blockedWrites.every(bw => bw.writeBlocked === true);

  return [
    {
      rule:   "write_plan_exists",
      passed: writePlanRecord.writePlanId.length > 0,
      detail: "Sandbox write plan record is present and valid",
    },
    {
      rule:   "write_gate_exists",
      passed: writeGateRecord.writeGateId.length > 0,
      detail: "Write enablement gate record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "write_gate_clear",
      passed: gateClear,
      detail: gateClear
        ? "Write gate allChecksPass=true — gate is clear for guarded write descriptor"
        : "Write gate checks have not all passed — guarded write descriptor is blocked",
    },
    {
      rule:   "rollback_ready",
      passed: rollbackReady,
      detail: rollbackReady
        ? "Rollback readiness confirmed across write plan and write gate"
        : "Rollback not yet ready in one or more upstream records — guarded write blocked",
    },
    {
      rule:   "targets_limited_to_sandbox",
      passed: allTargetsSandbox,
      detail: "All write operation targets are scoped under /sandbox/ — no host filesystem escape",
    },
    {
      rule:   "protected_targets_blocked",
      passed: allProtectedBlocked,
      detail: `All ${writePlanRecord.blockedWrites.length} protected targets confirmed writeBlocked=true`,
    },
    {
      rule:   "actual_writes_still_disabled",
      passed: true,
      detail: "actualWritesEnabled=false confirmed — no real filesystem mutation occurs at this phase",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: true,
      detail: "Guarded write output is descriptor-only — no real filesystem mutation",
    },
  ] as const;
}

function buildRollbackWriteReport(
  checks: readonly WriteSafetyCheck[],
  operations: readonly WriteOperation[],
): RollbackWriteReport {
  const rollbackReady = checks.every(c => c.passed);
  return {
    rollbackRequired:        true,
    rollbackDescriptorOnly:  true,
    rollbackOperationsCount: operations.length,
    rollbackTargetState:     "guarded_descriptor_ready",
    rollbackReady,
    summary: rollbackReady
      ? "Rollback write report ready — all guarded write operations are descriptor-only and can be safely discarded without any real filesystem side-effects"
      : "Rollback write report incomplete — one or more safety checks failed; guarded write operations must not proceed to activation",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const guardedWriteStore = new Map<string, GuardedSandboxWriteRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createGuardedSandboxWriteRecord(
  input: CreateGuardedSandboxWriteInput,
): { ok: true; record: GuardedSandboxWriteRecord } {
  const guardedWriteId    = randomBytes(16).toString("hex");
  const writeOperations   = buildWriteOperations(input.writePlanRecord);
  const blockedOperations = buildBlockedOperations(input.writePlanRecord);
  const checks            = buildSafetyChecks(input);
  const rollbackReport    = buildRollbackWriteReport(checks, writeOperations);

  const record: GuardedSandboxWriteRecord = {
    guardedWriteId,
    writeState:                "guarded_descriptor_ready",
    approvalRequired:          true,
    actualWritesEnabled:       false,
    realWritesEnabled:         false,
    motherCoreWritesBlocked:   true,
    protectedZoneWritesBlocked: true,
    vaultAccessBlocked:        true,
    shellAccessBlocked:        true,
    networkAccessBlocked:      true,
    deploymentWritesBlocked:   true,
    rollbackRequired:          true,
    implementationPhase:       "descriptor_only",
    writePlanId:               input.writePlanRecord.writePlanId,
    writeGateId:               input.writeGateRecord.writeGateId,
    executionRecordId:         input.executionRecord.controlledExecutionId,
    approvalReference:         input.writePlanRecord.approvalReference,
    writeOperations,
    blockedOperations,
    writeSafetyChecks:         checks,
    rollbackWriteReport:       rollbackReport,
    createdAt:                 new Date().toISOString(),
  };

  guardedWriteStore.set(guardedWriteId, record);
  return { ok: true, record };
}

export function listGuardedSandboxWriteRecords(): readonly GuardedSandboxWriteRecord[] {
  return [...guardedWriteStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getGuardedSandboxWriteSummary(): GuardedSandboxWriteSummary {
  const records = listGuardedSandboxWriteRecords();
  const allowedPaths: SandboxWritablePath[] = [
    "/sandbox/workspace",
    "/sandbox/tmp",
    "/sandbox/build-cache",
  ];
  const blockedPaths: SandboxProtectedPath[] = [
    "/mother-core",
    "/vault",
    "/runtime-config",
    "/system",
    "/network-secrets",
  ];
  return {
    total:                      records.length,
    byState:                    { guarded_descriptor_ready: records.length },
    actualWritesEnabled:        false,
    realWritesEnabled:          false,
    motherCoreWritesBlocked:    true,
    protectedZoneWritesBlocked: true,
    vaultAccessBlocked:         true,
    shellAccessBlocked:         true,
    networkAccessBlocked:       true,
    deploymentWritesBlocked:    true,
    approvalRequired:           true,
    allowedTargetPaths:         allowedPaths,
    blockedTargetPaths:         blockedPaths,
  };
}
