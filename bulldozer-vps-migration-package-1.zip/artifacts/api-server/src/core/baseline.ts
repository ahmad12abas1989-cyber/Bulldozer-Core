import { readFileSync } from "node:fs";
import { join } from "node:path";
import { router } from "./router";
import { getRuntimeDependencyGraphStatus } from "./runtimeDependencyGraph";
import { getCapabilityMatrixStatus } from "./runtimeCapabilityMatrix";
import { listSubsystemStates } from "./runtimeStateRegistry";
import { logger } from "../lib/logger";
import { addTimelineEvent } from "./timeline";
import { emit } from "./eventBus";
import { emitRuntimeEvent } from "./runtimeEventBus";

const BASELINE_HEALTH_CHECK_COUNT = 38;
const BASELINE_TYPECHECK_STATUS = "clean";

export interface BaselineLock {
  version: number;
  phase: number;
  sealedAt: string;
  description: string;
  endpointCount: number;
  healthCheckCount: number;
  subsystemCount: number;
  graphNodeCount: number;
  cycleCount: number;
  invalidReferenceCount: number;
  executionBlocked: true;
  recoveryBlocked: true;
  typecheckStatus: string;
}

export interface BaselineField {
  baseline: number;
  live: number;
  match: boolean;
}

export interface BaselineHealthField {
  baseline: number;
  live: number;
  match: boolean;
}

export interface BaselineStatusResult {
  baselineStatus: "intact" | "changed";
  operational: boolean;
  lockVersion: number;
  lockPhase: number;
  lockSealedAt: string;
  endpointCount: BaselineField;
  healthCheckCount: BaselineHealthField;
  subsystemCount: BaselineField;
  graphNodeCount: BaselineField;
  cycleCount: BaselineField;
  invalidReferenceCount: BaselineField;
  executionBlocked: true;
  recoveryBlocked: true;
  typecheckStatus: string;
  checkedAt: string;
}

let lockData: BaselineLock | null = null;
let lockLoadError: string | null = null;
let initialized = false;

function loadLock(): void {
  try {
    const lockPath = join(process.cwd(), "BASELINE_LOCK.json");
    const raw = readFileSync(lockPath, "utf-8");
    lockData = JSON.parse(raw) as BaselineLock;
    addTimelineEvent({
      level: "info",
      source: "baseline",
      message: "Baseline lock loaded",
      metadata: { phase: lockData.phase, sealedAt: lockData.sealedAt },
    });
    emit("baseline:loaded", "baseline", { phase: lockData.phase, sealedAt: lockData.sealedAt });
    emitRuntimeEvent({
      eventType: "baseline.loaded",
      source: "baseline",
      severity: "info",
      category: "runtime",
      payload: { phase: lockData.phase, sealedAt: lockData.sealedAt },
    });
  } catch (err) {
    lockLoadError = String(err);
    logger.warn({ err: lockLoadError }, "baseline: failed to load BASELINE_LOCK.json");
    addTimelineEvent({
      level: "warn",
      source: "baseline",
      message: "Baseline lock load failed",
      metadata: { err: lockLoadError },
    });
  }
  initialized = true;
}

export function initBaseline(): void {
  if (initialized) return;
  loadLock();
}

export function getBaselineLock(): BaselineLock | null {
  if (!initialized) loadLock();
  return lockData;
}

export function getBaselineStatus(): BaselineStatusResult {
  if (!initialized) loadLock();

  const liveEndpoints = router.list().length;
  const liveSubsystems = listSubsystemStates().length;

  let liveGraphNodes = 0;
  let liveCycles = 0;
  let liveInvalidRefs = 0;

  try {
    const gs = getRuntimeDependencyGraphStatus();
    liveGraphNodes = gs.totalNodes;
    liveCycles = gs.cycleCount;
  } catch {
    // graph not yet initialized — values remain 0
  }

  try {
    const cs = getCapabilityMatrixStatus();
    liveInvalidRefs = cs.invalidReferenceCount;
  } catch {
    // capability matrix not yet initialized — value remains 0
  }

  if (!lockData) {
    return {
      baselineStatus: "changed",
      operational: false,
      lockVersion: 0,
      lockPhase: 0,
      lockSealedAt: "",
      endpointCount: { baseline: 0, live: liveEndpoints, match: false },
      healthCheckCount: { baseline: 0, live: BASELINE_HEALTH_CHECK_COUNT, match: false },
      subsystemCount: { baseline: 0, live: liveSubsystems, match: false },
      graphNodeCount: { baseline: 0, live: liveGraphNodes, match: false },
      cycleCount: { baseline: 0, live: liveCycles, match: false },
      invalidReferenceCount: { baseline: 0, live: liveInvalidRefs, match: false },
      executionBlocked: true,
      recoveryBlocked: true,
      typecheckStatus: BASELINE_TYPECHECK_STATUS,
      checkedAt: new Date().toISOString(),
    };
  }

  const endpointMatch = liveEndpoints === lockData.endpointCount;
  const healthMatch = BASELINE_HEALTH_CHECK_COUNT === lockData.healthCheckCount;
  const subsystemMatch = liveSubsystems === lockData.subsystemCount;
  const graphMatch = liveGraphNodes === lockData.graphNodeCount;
  const cycleMatch = liveCycles === lockData.cycleCount;
  const invalidMatch = liveInvalidRefs === lockData.invalidReferenceCount;

  const intact =
    endpointMatch &&
    healthMatch &&
    subsystemMatch &&
    graphMatch &&
    cycleMatch &&
    invalidMatch;

  return {
    baselineStatus: intact ? "intact" : "changed",
    operational: true,
    lockVersion: lockData.version,
    lockPhase: lockData.phase,
    lockSealedAt: lockData.sealedAt,
    endpointCount: { baseline: lockData.endpointCount, live: liveEndpoints, match: endpointMatch },
    healthCheckCount: { baseline: lockData.healthCheckCount, live: BASELINE_HEALTH_CHECK_COUNT, match: healthMatch },
    subsystemCount: { baseline: lockData.subsystemCount, live: liveSubsystems, match: subsystemMatch },
    graphNodeCount: { baseline: lockData.graphNodeCount, live: liveGraphNodes, match: graphMatch },
    cycleCount: { baseline: lockData.cycleCount, live: liveCycles, match: cycleMatch },
    invalidReferenceCount: { baseline: lockData.invalidReferenceCount, live: liveInvalidRefs, match: invalidMatch },
    executionBlocked: true,
    recoveryBlocked: true,
    typecheckStatus: BASELINE_TYPECHECK_STATUS,
    checkedAt: new Date().toISOString(),
  };
}
