// Governance Scorecard Comparison — Phase 120
// Pure read-only derivation comparing two stored Governance Scorecard snapshots.
// No persistence mutation, no live scorecard recomputation, no rendering,
// no autonomous execution, no AI orchestration.

import { getRawScorecardHistoryEntries } from "./workspaceGovernanceScorecardHistory";
import type { GovernanceGrade } from "./workspaceGovernanceScorecard";

const EXECUTION_BLOCKED: true = true;

// Canonical 6 dimension keys — alphabetically sorted, mirrors Phase 116 analytics.
// Sourced from breakdown[].category on the stored WorkspaceGovernanceScorecard.
const DIMENSION_KEYS = [
  "audit_report_coverage",
  "capacity_utilization",
  "member_project_ratio",
  "quota_adoption",
  "snapshot_availability",
  "validation_integrity",
] as const;

type DimensionKey = (typeof DIMENSION_KEYS)[number];

// Grade ordering: lower index = better grade.
// A=0, B=1, C=2, D=3, F=4
const GRADE_ORDER: GovernanceGrade[] = ["A", "B", "C", "D", "F"];

// --- Types ---

export type ComparisonTrendDirection = "improving" | "stable" | "degrading";
export type ImprovementDirection = "improved" | "unchanged" | "degraded";

export interface DimensionDelta {
  dimensionKey: DimensionKey;
  fromWeightedScore: number;
  toWeightedScore: number;
  weightedScoreDelta: number;
  trendDirection: ComparisonTrendDirection;
  executionBlocked: true;
}

export interface ScorecardComparisonResult {
  fromCaptureSeq: number;
  toCaptureSeq: number;
  fromCreatedAt: string;
  toCreatedAt: string;
  fromGovernanceScore: number;
  toGovernanceScore: number;
  governanceScoreDelta: number;
  fromGovernanceGrade: GovernanceGrade;
  toGovernanceGrade: GovernanceGrade;
  governanceGradeChange: ImprovementDirection;
  fromValidationIntegrityScore: number;
  toValidationIntegrityScore: number;
  validationIntegrityDelta: number;
  improvementDirection: ImprovementDirection;
  dimensionDeltas: DimensionDelta[];
  executionBlocked: true;
}

// Discriminated error return — not thrown, returned as a value.
export interface ScorecardComparisonNotFound {
  error: "not_found";
  which: "from" | "to" | "both";
}

// --- Internal helpers ---

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function gradeIndex(g: GovernanceGrade): number {
  return GRADE_ORDER.indexOf(g);
}

function trendFromDelta(delta: number): ComparisonTrendDirection {
  if (delta > 0) return "improving";
  if (delta < 0) return "degrading";
  return "stable";
}

function improvementFromDelta(delta: number): ImprovementDirection {
  if (delta > 0) return "improved";
  if (delta < 0) return "degraded";
  return "unchanged";
}

function gradeChangeDelta(fromGrade: GovernanceGrade, toGrade: GovernanceGrade): ImprovementDirection {
  // Lower grade index = better grade; a drop in index = improvement.
  const diff = gradeIndex(fromGrade) - gradeIndex(toGrade);
  return improvementFromDelta(diff);
}

// --- Public API ---

// O(10) × 2 bounded ring lookups + O(6) dimension comparisons.
// Returns ScorecardComparisonResult on success, ScorecardComparisonNotFound when
// one or both captureSeqs are absent from the current ring.
// No persistence mutation, no live scorecard recomputation.
export function compareGovernanceScorecards(
  fromCaptureSeq: number,
  toCaptureSeq: number,
): ScorecardComparisonResult | ScorecardComparisonNotFound {
  const entries = getRawScorecardHistoryEntries();

  const fromEntry = entries.find((e) => e.captureSeq === fromCaptureSeq) ?? null;
  const toEntry   = entries.find((e) => e.captureSeq === toCaptureSeq)   ?? null;

  if (fromEntry === null || toEntry === null) {
    const which =
      fromEntry === null && toEntry === null ? "both" :
      fromEntry === null                     ? "from" : "to";
    return { error: "not_found", which };
  }

  const fromSnap = fromEntry.snapshot;
  const toSnap   = toEntry.snapshot;

  const governanceScoreDelta     = round1(toSnap.governanceScore - fromSnap.governanceScore);
  const validationIntegrityDelta = round1(
    toSnap.signals.validationIntegrityScore - fromSnap.signals.validationIntegrityScore,
  );

  const governanceGradeChange = gradeChangeDelta(fromSnap.governanceGrade, toSnap.governanceGrade);

  // Dimension deltas — O(6) alphabetically sorted, matching canonical DIMENSION_KEYS order.
  const dimensionDeltas: DimensionDelta[] = DIMENSION_KEYS.map((key) => {
    const fromCat = fromSnap.breakdown.find((c) => c.category === key);
    const toCat   = toSnap.breakdown.find((c) => c.category === key);
    const fromWS  = round1(fromCat?.weightedScore ?? 0);
    const toWS    = round1(toCat?.weightedScore   ?? 0);
    const delta   = round1(toWS - fromWS);
    return {
      dimensionKey: key,
      fromWeightedScore: fromWS,
      toWeightedScore: toWS,
      weightedScoreDelta: delta,
      trendDirection: trendFromDelta(delta),
      executionBlocked: EXECUTION_BLOCKED,
    };
  });

  return {
    fromCaptureSeq,
    toCaptureSeq,
    fromCreatedAt: fromEntry.createdAt,
    toCreatedAt:   toEntry.createdAt,
    fromGovernanceScore:        fromSnap.governanceScore,
    toGovernanceScore:          toSnap.governanceScore,
    governanceScoreDelta,
    fromGovernanceGrade:        fromSnap.governanceGrade,
    toGovernanceGrade:          toSnap.governanceGrade,
    governanceGradeChange,
    fromValidationIntegrityScore: fromSnap.signals.validationIntegrityScore,
    toValidationIntegrityScore:   toSnap.signals.validationIntegrityScore,
    validationIntegrityDelta,
    improvementDirection: improvementFromDelta(governanceScoreDelta),
    dimensionDeltas,
    executionBlocked: EXECUTION_BLOCKED,
  };
}
