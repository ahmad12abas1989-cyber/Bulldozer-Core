// Rate Limit Core — Phase 193
// In-memory, observe-only rate limit skeleton. No blocking. No persistence.
// No automatic request wiring. No enforcement. Always allowed=true.
// Pure module — no init, no subsystem registration, no health checks, no event emission.

// ─── Scopes ──────────────────────────────────────────────────────────────────

export type RateLimitScope =
  | "ip"
  | "session"
  | "operator"
  | "employee"
  | "service_token"
  | "generated_product";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface RateLimitDecision {
  readonly scope:            RateLimitScope;
  readonly key:              string;   // caller-supplied identity key within the scope
  readonly allowed:          true;     // always true — no blocking in skeleton mode
  readonly observeOnly:      true;     // always true — signals non-enforcing mode
  readonly requestCount:     number;   // total observations for this scope+key since last reset
  readonly windowStartedAt:  string;   // ISO 8601 — when the first observation for this key was recorded
  readonly observedAt:       string;   // ISO 8601 — timestamp of this specific observation
}

export interface RateLimitEntry {
  readonly scope:           RateLimitScope;
  readonly key:             string;
  count:                    number;    // mutable only via observeRateLimit()
  readonly windowStartedAt: string;
}

export interface RateLimitSummary {
  readonly totalKeys:           number;   // distinct scope+key pairs currently tracked
  readonly byScope:             Readonly<Record<RateLimitScope, number>>;  // distinct key count per scope
  readonly totalObservations:   number;   // sum of all counts across all entries
  readonly enforcing:           false;
  readonly persistenceEnabled:  false;
  readonly implementationPhase: "skeleton";
}

// ─── In-memory store ─────────────────────────────────────────────────────────
// Keyed by `${scope}:${key}`. Mutable only through the exported functions below.

const STORE = new Map<string, RateLimitEntry>();

// ─── Helpers ─────────────────────────────────────────────────────────────────

function storeKey(scope: RateLimitScope, key: string): string {
  return `${scope}:${key}`;
}

// ─── Exports ─────────────────────────────────────────────────────────────────

/**
 * Observe a request for a given scope and key.
 * Increments the in-memory counter for this scope+key pair.
 * Always returns allowed=true — no blocking in skeleton mode.
 * Not wired to the request flow; callers must invoke this explicitly.
 */
export function observeRateLimit(scope: RateLimitScope, key: string): RateLimitDecision {
  const sk  = storeKey(scope, key);
  const now = new Date().toISOString();

  let entry = STORE.get(sk);
  if (!entry) {
    entry = { scope, key, count: 0, windowStartedAt: now };
    STORE.set(sk, entry);
  }
  entry.count++;

  return {
    scope,
    key,
    allowed:         true,
    observeOnly:     true,
    requestCount:    entry.count,
    windowStartedAt: entry.windowStartedAt,
    observedAt:      now,
  };
}

/**
 * Return a summary of the current rate limit observation store.
 */
export function getRateLimitSummary(): RateLimitSummary {
  const byScope: Record<RateLimitScope, number> = {
    ip:                0,
    session:           0,
    operator:          0,
    employee:          0,
    service_token:     0,
    generated_product: 0,
  };

  let totalObservations = 0;

  for (const entry of STORE.values()) {
    byScope[entry.scope]++;
    totalObservations += entry.count;
  }

  return {
    totalKeys:           STORE.size,
    byScope,
    totalObservations,
    enforcing:           false,
    persistenceEnabled:  false,
    implementationPhase: "skeleton",
  };
}

/**
 * Clear all tracked rate limit counters.
 * Diagnostic/testing use only — not wired to any request flow.
 * No-op if the store is already empty.
 */
export function resetRateLimitMemory(): void {
  STORE.clear();
}
