import { logger } from "../lib/logger";

export interface Plugin {
  name: string;
  version?: string;
  register(): void | Promise<void>;
}

class PluginManager {
  private readonly plugins: Plugin[] = [];

  register(plugin: Plugin): void {
    this.plugins.push(plugin);
    logger.info({ plugin: plugin.name }, "Plugin registered");
  }

  async loadAll(): Promise<void> {
    for (const plugin of this.plugins) {
      await plugin.register();
      logger.info({ plugin: plugin.name }, "Plugin loaded");
    }
  }

  list(): string[] {
    return this.plugins.map((p) => p.name);
  }
}

export const pluginManager = new PluginManager();
