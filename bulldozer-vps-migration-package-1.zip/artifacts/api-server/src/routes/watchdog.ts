import type { IncomingMessage, ServerResponse } from "node:http";
import { getWatchdogStatus } from "../core/watchdog";
import { sendJson } from "../lib/response";

export function handleWatchdog(_req: IncomingMessage, res: ServerResponse): void {
  sendJson(res, 200, getWatchdogStatus());
}
