import { ActualSandboxWriteDryRunRecord }      from "./actualSandboxWriteDryRunCore.js";
import { ActualSandboxWriteEnablementRecord }   from "./actualSandboxWriteEnablementCore.js";
import { SandboxWriteCommitGateRecord }          from "./sandboxWriteCommitGateCore.js";
import { ControlledExecutionRecord }             from "./controlledExecutionCore.js";
import { randomBytes }                           from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ApprovalState = "descriptor_approval_pending";

export type ApprovalCheckRule =
  | "dry_run_exists"
  | "enablement_record_exists"
  | "commit_gate_exists"
  | "execution_record_exists"
  | "dry_run_ready"
  | "rollback_reference_bound"
  | "commit_gate_bound"
  | "approval_not_granted_yet"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface ApprovalScopeEntry {
  readonly scopeIndex:             number;
  readonly targetPath:             string;
  readonly operationType:          string;
  readonly approvalGranted:        false;
  readonly approvalRequired:       true;
  readonly actualWritesEnabled:    false;
  readonly scopeNote:              string;
}

export interface ApprovalValidationCheck {
  readonly rule:   ApprovalCheckRule;
  readonly passed: boolean;
  readonly detail: string;
}

export interface LinkedRollbackReference {
  readonly rollbackSnapshotId:     string;
  readonly commitGateId:           string;
  readonly rollbackRequired:       true;
  readonly rollbackDescriptorOnly: true;
  readonly rollbackBound:          boolean;
  readonly rollbackReady:          boolean;
  readonly linkNote:               string;
}

export interface ApprovalReadinessReport {
  readonly approvalGranted:        false;
  readonly approvalRequired:       true;
  readonly actualWritesEnabled:    false;
  readonly allChecksPass:          boolean;
  readonly approvalScopeCount:     number;
  readonly rollbackReady:          boolean;
  readonly summary:                string;
}

export interface ActualSandboxWriteApprovalTokenRecord {
  readonly approvalTokenId:            string;
  readonly approvalState:              ApprovalState;
  readonly approvalRequired:           true;
  readonly approvalGranted:            false;
  readonly actualWritesEnabled:        false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
  readonly implementationPhase:        "descriptor_only";
  readonly dryRunId:                   string;
  readonly actualWriteEnablementId:    string;
  readonly commitGateId:               string;
  readonly executionRecordId:          string;
  readonly approvalScope:              readonly ApprovalScopeEntry[];
  readonly approvalValidationChecks:   readonly ApprovalValidationCheck[];
  readonly approvalReadinessReport:    ApprovalReadinessReport;
  readonly linkedRollbackReference:    LinkedRollbackReference;
  readonly createdAt:                  string;
}

export interface CreateApprovalTokenInput {
  readonly dryRunRecord:      ActualSandboxWriteDryRunRecord;
  readonly enablementRecord:  ActualSandboxWriteEnablementRecord;
  readonly commitGateRecord:  SandboxWriteCommitGateRecord;
  readonly executionRecord:   ControlledExecutionRecord;
}

export interface ActualSandboxWriteApprovalTokenSummary {
  readonly total:                      number;
  readonly byState:                    Record<ApprovalState, number>;
  readonly approvalGranted:            false;
  readonly approvalRequired:           true;
  readonly actualWritesEnabled:        false;
  readonly filesystemMutationBlocked:  true;
  readonly motherCoreMutationBlocked:  true;
  readonly vaultMutationBlocked:       true;
  readonly shellBlocked:               true;
  readonly networkBlocked:             true;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildApprovalScope(
  dryRunRecord: ActualSandboxWriteDryRunRecord,
): readonly ApprovalScopeEntry[] {
  return dryRunRecord.dryRunOperations
    .slice()
    .sort((a, b) => a.stepIndex - b.stepIndex)
    .map((op, idx) => ({
      scopeIndex:           idx,
      targetPath:           op.targetPath,
      operationType:        op.operationType,
      approvalGranted:      false,
      approvalRequired:     true,
      actualWritesEnabled:  false,
      scopeNote:            `Approval scope entry ${idx}: ${op.operationType} → ${op.targetPath} — approval descriptor-only; approvalGranted=false in this phase; requires explicit operator action in a future execution phase`,
    }));
}

function buildValidationChecks(
  input: CreateApprovalTokenInput,
  scope: readonly ApprovalScopeEntry[],
): readonly ApprovalValidationCheck[] {
  const { dryRunRecord, enablementRecord, commitGateRecord, executionRecord } = input;

  const dryRunReady = dryRunRecord.dryRunReadinessReport.allChecksPass;
  const rollbackBound = dryRunRecord.rollbackBindingReport.rollbackBound;
  const commitGateBound = commitGateRecord.commitGateId.length > 0 &&
    dryRunRecord.rollbackBindingReport.commitGateId === commitGateRecord.commitGateId;

  const rollbackReady =
    dryRunRecord.dryRunReadinessReport.rollbackReady &&
    dryRunRecord.rollbackBindingReport.rollbackReady &&
    enablementRecord.enablementReadinessReport.rollbackReady &&
    commitGateRecord.commitReadinessReport.rollbackReady;

  return [
    {
      rule:   "dry_run_exists",
      passed: dryRunRecord.dryRunId.length > 0,
      detail: "Dry-run record is present and valid",
    },
    {
      rule:   "enablement_record_exists",
      passed: enablementRecord.actualWriteEnablementId.length > 0,
      detail: "Actual write enablement record is present and valid",
    },
    {
      rule:   "commit_gate_exists",
      passed: commitGateRecord.commitGateId.length > 0,
      detail: "Commit gate record is present and valid",
    },
    {
      rule:   "execution_record_exists",
      passed: executionRecord.controlledExecutionId.length > 0,
      detail: "Controlled execution record is present and valid",
    },
    {
      rule:   "dry_run_ready",
      passed: dryRunReady,
      detail: dryRunReady
        ? "Dry-run allChecksPass=true — dry-run layer is complete and ready for approval scoping"
        : "Dry-run checks have not all passed — approval token blocked until dry run is ready",
    },
    {
      rule:   "rollback_reference_bound",
      passed: rollbackBound,
      detail: rollbackBound
        ? `Rollback reference bound — snapshotId=${dryRunRecord.rollbackBindingReport.rollbackSnapshotId.slice(0, 8)}… bound=true`
        : "Rollback reference not fully bound — approval token blocked until rollback binding is valid",
    },
    {
      rule:   "commit_gate_bound",
      passed: commitGateBound,
      detail: commitGateBound
        ? `Commit gate bound — commitGateId=${commitGateRecord.commitGateId.slice(0, 8)}… matches dry-run rollbackBindingReport`
        : "Commit gate ID mismatch or missing — approval token blocked until commit gate binding is confirmed",
    },
    {
      rule:   "approval_not_granted_yet",
      passed: true,
      detail: "approvalGranted=false confirmed — approval token is in descriptor-pending state; no actual approval issued in this phase",
    },
    {
      rule:   "actual_writes_still_disabled",
      passed: true,
      detail: "actualWritesEnabled=false confirmed — no real filesystem writes occur at approval token creation",
    },
    {
      rule:   "output_remains_descriptor_only",
      passed: rollbackReady,
      detail: rollbackReady
        ? `Rollback readiness confirmed across 4 upstream records — approval token is a valid descriptor; scope covers ${scope.length} operation(s)`
        : "Rollback readiness not fully confirmed across upstream records — approval token descriptor blocked",
    },
  ] as const;
}

function buildLinkedRollbackReference(
  input: CreateApprovalTokenInput,
  checks: readonly ApprovalValidationCheck[],
): LinkedRollbackReference {
  const rollbackReady = checks.every(c => c.passed);
  return {
    rollbackSnapshotId:     input.dryRunRecord.rollbackBindingReport.rollbackSnapshotId,
    commitGateId:           input.commitGateRecord.commitGateId,
    rollbackRequired:       true,
    rollbackDescriptorOnly: true,
    rollbackBound:          input.dryRunRecord.rollbackBindingReport.rollbackBound,
    rollbackReady,
    linkNote: rollbackReady
      ? "Approval token is linked to a valid rollback snapshot and commit gate — any future real write approved by this token can be rolled back to the pre-write state"
      : "Approval token rollback link incomplete — all checks must pass before approval token is rollback-ready",
  };
}

function buildReadinessReport(
  checks: readonly ApprovalValidationCheck[],
  scope: readonly ApprovalScopeEntry[],
): ApprovalReadinessReport {
  const allChecksPass = checks.every(c => c.passed);
  const rollbackCheck = checks.find(c => c.rule === "output_remains_descriptor_only");
  const rollbackReady = rollbackCheck?.passed ?? false;
  return {
    approvalGranted:      false,
    approvalRequired:     true,
    actualWritesEnabled:  false,
    allChecksPass,
    approvalScopeCount:   scope.length,
    rollbackReady,
    summary: allChecksPass
      ? `Approval token descriptor ready — ${scope.length} operation(s) in scope, rollback binding valid, all 10 checks passed; approvalGranted=false in this phase; actual approval requires explicit operator action in a future execution phase`
      : "Approval token descriptor blocked — one or more validation checks failed; approvalGranted remains false",
  };
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const tokenStore = new Map<string, ActualSandboxWriteApprovalTokenRecord>();

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createApprovalTokenRecord(
  input: CreateApprovalTokenInput,
): { ok: true; record: ActualSandboxWriteApprovalTokenRecord } {
  const approvalTokenId = randomBytes(16).toString("hex");
  const scope    = buildApprovalScope(input.dryRunRecord);
  const checks   = buildValidationChecks(input, scope);
  const rollback = buildLinkedRollbackReference(input, checks);
  const report   = buildReadinessReport(checks, scope);

  const record: ActualSandboxWriteApprovalTokenRecord = {
    approvalTokenId,
    approvalState:             "descriptor_approval_pending",
    approvalRequired:          true,
    approvalGranted:           false,
    actualWritesEnabled:       false,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
    implementationPhase:       "descriptor_only",
    dryRunId:                  input.dryRunRecord.dryRunId,
    actualWriteEnablementId:   input.enablementRecord.actualWriteEnablementId,
    commitGateId:              input.commitGateRecord.commitGateId,
    executionRecordId:         input.executionRecord.controlledExecutionId,
    approvalScope:             scope,
    approvalValidationChecks:  checks,
    approvalReadinessReport:   report,
    linkedRollbackReference:   rollback,
    createdAt:                 new Date().toISOString(),
  };

  tokenStore.set(approvalTokenId, record);
  return { ok: true, record };
}

export function listApprovalTokenRecords(): readonly ActualSandboxWriteApprovalTokenRecord[] {
  return [...tokenStore.values()].sort(
    (a, b) => b.createdAt.localeCompare(a.createdAt),
  );
}

export function getApprovalTokenSummary(): ActualSandboxWriteApprovalTokenSummary {
  const records = listApprovalTokenRecords();
  return {
    total:                     records.length,
    byState:                   { descriptor_approval_pending: records.length },
    approvalGranted:           false,
    approvalRequired:          true,
    actualWritesEnabled:       false,
    filesystemMutationBlocked: true,
    motherCoreMutationBlocked: true,
    vaultMutationBlocked:      true,
    shellBlocked:              true,
    networkBlocked:            true,
  };
}
