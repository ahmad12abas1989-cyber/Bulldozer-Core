// actualSandboxWriteCommitExecutionGateCore.ts
// Phase 327 — Actual Sandbox Write Commit Execution Gate Descriptor Core Skeleton
// In-memory actual sandbox write commit execution gate descriptor engine.
// Layer 28 of the write-preparation + preflight + activation + switch +
//   transition + bridge + bridge-open + guarded-write-enable +
//   mutation-switch + permission-gate + scoped-activation + execution-gate +
//   write-operation + runtime-write-executor + sandbox-write-commit +
//   sandbox-write-commit-enable stack.
// Defines the final commit execution gate before actual sandbox write mutation.
// Preserves sandbox-approved-only target scope from layers 24–27 as a first-class field.
// No init. No persistence. No subsystem. No health check.
// No client-side JavaScript. No forms. No actual writes.
// No filesystem mutation. No shell execution. No network access. No vault access.
// No Mother Core mutation. commitExecutionGateEnabled=false — gate has not been opened.
// commitExecutionGatePrepared=true — descriptor-readiness established for a future first actual sandbox write mutation phase.
// filesystemMutationBlocked=true — no filesystem mutation occurs in this phase.

import type { SandboxWriteCommitEnableRecord }          from "./sandboxWriteCommitEnableCore.js";
import type { FirstSandboxWriteCommitRecord }            from "./firstSandboxWriteCommitCore.js";
import type { RuntimeWriteExecutorRecord }               from "./runtimeWriteExecutorCore.js";
import type { FirstActualSandboxWriteOperationRecord }   from "./firstActualSandboxWriteOperationCore.js";
import type { ActualSandboxWriteExecutionGateRecord }    from "./actualSandboxWriteExecutionGateCore.js";
import type { ControlledExecutionRecord }                from "./controlledExecutionCore.js";
import { randomUUID }                                    from "node:crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type CommitExecutionState = "descriptor_commit_execution_gate_pending";

export type CommitExecutionGateCheckRule =
  | "commit_enable_record_exists"
  | "sandbox_write_commit_exists"
  | "runtime_write_executor_exists"
  | "actual_write_operation_exists"
  | "write_execution_gate_exists"
  | "execution_record_exists"
  | "commit_enable_bound_to_commit"
  | "commit_bound_to_executor"
  | "executor_bound_to_write_operation"
  | "write_operation_bound_to_execution_gate"
  | "commit_execution_still_disabled"
  | "actual_writes_still_disabled"
  | "output_remains_descriptor_only";

export interface CommitExecutionGateCheck {
  readonly rule: CommitExecutionGateCheckRule;
  readonly pass: boolean;
  readonly note: string;
}

export interface CommitExecutionBlockedReason {
  readonly code:   string;
  readonly reason: string;
  readonly static: boolean;
}

export interface LinkedCommitExecutionReference {
  readonly sandboxWriteCommitEnableId:        string;
  readonly sandboxWriteCommitId:              string;
  readonly runtimeWriteExecutorId:            string;
  readonly actualWriteOperationId:            string;
  readonly rollbackSnapshotId:                string;
  readonly commitExecutionGatePrepared:       true;
  readonly commitExecutionGateEnabled:        false;
  readonly sandboxWriteCommitEnabled:         false;
  readonly runtimeWriteExecutorEnabled:       false;
  readonly actualWritesEnabled:               false;
  readonly rollbackChainValid:                boolean;
  readonly referenceNote:                     string;
}

export interface CommitExecutionReadinessReport {
  readonly commitExecutionGatePrepared:       true;
  readonly commitExecutionGateEnabled:        false;
  readonly sandboxWriteCommitEnabled:         false;
  readonly runtimeWriteExecutorEnabled:       false;
  readonly writeExecutionGateEnabled:         false;
  readonly scopedActivationEnabled:           false;
  readonly writePermissionEnabled:            false;
  readonly mutationSwitchEnabled:             false;
  readonly guardedWriteEnabled:               false;
  readonly actualWritesEnabled:               false;
  readonly realWritesEnabled:                 false;
  readonly approvalRequired:                  true;
  readonly allChecksPass:                     boolean;
  readonly blockedReasonCount:                number;
  readonly rollbackChainValid:                boolean;
  readonly targetScope:                       "sandbox_approved_only";
  readonly summary:                           string;
}

export interface ActualSandboxWriteCommitExecutionGateRecord {
  readonly commitExecutionGateId:             string;
  readonly commitExecutionState:              CommitExecutionState;
  readonly approvalRequired:                  true;
  readonly commitExecutionGatePrepared:       true;
  readonly commitExecutionGateEnabled:        false;
  readonly sandboxWriteCommitEnabled:         false;
  readonly runtimeWriteExecutorEnabled:       false;
  readonly actualWritesEnabled:               false;
  readonly filesystemMutationBlocked:         true;
  readonly motherCoreMutationBlocked:         true;
  readonly vaultMutationBlocked:              true;
  readonly shellBlocked:                      true;
  readonly networkBlocked:                    true;
  readonly targetScope:                       "sandbox_approved_only";
  readonly implementationPhase:               "descriptor_only";
  readonly sandboxWriteCommitEnableId:        string;
  readonly sandboxWriteCommitId:              string;
  readonly runtimeWriteExecutorId:            string;
  readonly actualWriteOperationId:            string;
  readonly writeExecutionGateId:              string;
  readonly controlledExecutionId:             string;
  readonly commitExecutionChecks:             readonly CommitExecutionGateCheck[];
  readonly commitExecutionBlockedReasons:     readonly CommitExecutionBlockedReason[];
  readonly commitExecutionReadinessReport:    CommitExecutionReadinessReport;
  readonly linkedCommitExecutionReference:    LinkedCommitExecutionReference;
  readonly createdAt:                         string;
}

export interface CreateActualSandboxWriteCommitExecutionGateInput {
  readonly commitEnableRecord:       SandboxWriteCommitEnableRecord;
  readonly commitRecord:             FirstSandboxWriteCommitRecord;
  readonly executorRecord:           RuntimeWriteExecutorRecord;
  readonly writeOperationRecord:     FirstActualSandboxWriteOperationRecord;
  readonly writeExecutionGateRecord: ActualSandboxWriteExecutionGateRecord;
  readonly executionRecord:          ControlledExecutionRecord;
}

export interface ActualSandboxWriteCommitExecutionGateSummary {
  readonly total:                             number;
  readonly byState:                           Record<CommitExecutionState, number>;
  readonly commitExecutionGatePrepared:       true;
  readonly commitExecutionGateEnabled:        false;
  readonly sandboxWriteCommitEnabled:         false;
  readonly runtimeWriteExecutorEnabled:       false;
  readonly actualWritesEnabled:               false;
  readonly approvalRequired:                  true;
  readonly filesystemMutationBlocked:         true;
  readonly motherCoreMutationBlocked:         true;
  readonly targetScope:                       "sandbox_approved_only";
  readonly commitExecutionState:              CommitExecutionState;
  readonly implementationPhase:               "descriptor_only";
}

// ---------------------------------------------------------------------------
// In-memory store
// ---------------------------------------------------------------------------

const _store: ActualSandboxWriteCommitExecutionGateRecord[] = [];

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

function buildChecks(
  input: CreateActualSandboxWriteCommitExecutionGateInput,
): readonly CommitExecutionGateCheck[] {
  const { commitEnableRecord, commitRecord, executorRecord, writeOperationRecord, writeExecutionGateRecord, executionRecord } = input;

  const enableExists  = commitEnableRecord.sandboxWriteCommitEnableId.length > 0;
  const commitExists  = commitRecord.sandboxWriteCommitId.length > 0;
  const execExists    = executorRecord.runtimeWriteExecutorId.length > 0;
  const opExists      = writeOperationRecord.actualWriteOperationId.length > 0;
  const gateExists    = writeExecutionGateRecord.writeExecutionGateId.length > 0;
  const ctrlExists    = executionRecord.controlledExecutionId.length > 0;

  const enableBound   = commitEnableRecord.sandboxWriteCommitId === commitRecord.sandboxWriteCommitId;
  const commitBound   = commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId;
  const execBound     = executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId;
  const opBound       = writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId;

  return [
    {
      rule: "commit_enable_record_exists",
      pass: enableExists,
      note: enableExists
        ? `sandboxWriteCommitEnableId=${commitEnableRecord.sandboxWriteCommitEnableId}`
        : "commitEnableRecord.sandboxWriteCommitEnableId is empty",
    },
    {
      rule: "sandbox_write_commit_exists",
      pass: commitExists,
      note: commitExists
        ? `sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`
        : "commitRecord.sandboxWriteCommitId is empty",
    },
    {
      rule: "runtime_write_executor_exists",
      pass: execExists,
      note: execExists
        ? `runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`
        : "executorRecord.runtimeWriteExecutorId is empty",
    },
    {
      rule: "actual_write_operation_exists",
      pass: opExists,
      note: opExists
        ? `actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`
        : "writeOperationRecord.actualWriteOperationId is empty",
    },
    {
      rule: "write_execution_gate_exists",
      pass: gateExists,
      note: gateExists
        ? `writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`
        : "writeExecutionGateRecord.writeExecutionGateId is empty",
    },
    {
      rule: "execution_record_exists",
      pass: ctrlExists,
      note: ctrlExists
        ? `controlledExecutionId=${executionRecord.controlledExecutionId}`
        : "executionRecord.controlledExecutionId is empty",
    },
    {
      rule: "commit_enable_bound_to_commit",
      pass: enableBound,
      note: enableBound
        ? `commitEnableRecord.sandboxWriteCommitId === commitRecord.sandboxWriteCommitId (${commitRecord.sandboxWriteCommitId})`
        : `commit-enable/commit mismatch: enable.sandboxWriteCommitId=${commitEnableRecord.sandboxWriteCommitId} vs commit.sandboxWriteCommitId=${commitRecord.sandboxWriteCommitId}`,
    },
    {
      rule: "commit_bound_to_executor",
      pass: commitBound,
      note: commitBound
        ? `commitRecord.runtimeWriteExecutorId === executorRecord.runtimeWriteExecutorId (${executorRecord.runtimeWriteExecutorId})`
        : `commit/executor mismatch: commit.runtimeWriteExecutorId=${commitRecord.runtimeWriteExecutorId} vs executor.runtimeWriteExecutorId=${executorRecord.runtimeWriteExecutorId}`,
    },
    {
      rule: "executor_bound_to_write_operation",
      pass: execBound,
      note: execBound
        ? `executorRecord.actualWriteOperationId === writeOperationRecord.actualWriteOperationId (${writeOperationRecord.actualWriteOperationId})`
        : `executor/write-operation mismatch: executor.actualWriteOperationId=${executorRecord.actualWriteOperationId} vs op.actualWriteOperationId=${writeOperationRecord.actualWriteOperationId}`,
    },
    {
      rule: "write_operation_bound_to_execution_gate",
      pass: opBound,
      note: opBound
        ? `writeOperationRecord.writeExecutionGateId === writeExecutionGateRecord.writeExecutionGateId (${writeExecutionGateRecord.writeExecutionGateId})`
        : `write-operation/execution-gate mismatch: op.writeExecutionGateId=${writeOperationRecord.writeExecutionGateId} vs gate.writeExecutionGateId=${writeExecutionGateRecord.writeExecutionGateId}`,
    },
    {
      rule: "commit_execution_still_disabled",
      pass: true,
      note: "commitExecutionGateEnabled=false — compile-time literal; no commit execution activation phase has been started",
    },
    {
      rule: "actual_writes_still_disabled",
      pass: true,
      note: "actualWritesEnabled=false — compile-time literal; no execution phase has enabled actual filesystem writes",
    },
    {
      rule: "output_remains_descriptor_only",
      pass: true,
      note: "commitExecutionState=descriptor_commit_execution_gate_pending — output is a descriptor only; commit execution gate is not yet active",
    },
  ] as const;
}

function buildBlockedReasons(
  checks: readonly CommitExecutionGateCheck[],
): readonly CommitExecutionBlockedReason[] {
  const staticReasons: CommitExecutionBlockedReason[] = [
    { code: "commit_execution_gate_disabled", reason: "commitExecutionGateEnabled=false — compile-time literal; an explicit first actual sandbox write mutation phase must open this gate before any sandbox write target can be touched",                                                                                                                                                                                                     static: true },
    { code: "approval_required",              reason: "approvalRequired=true — explicit operator approval is required before the commit execution gate can be opened",                                                                                                                                                                                                                                                                         static: true },
    { code: "actual_writes_disabled",         reason: "actualWritesEnabled=false — compile-time literal across all 28 sealed write-preparation, activation, switch, transition, bridge, bridge-open, guarded-write-enable, mutation-switch, permission-gate, scoped-activation, execution-gate, write-operation, runtime-write-executor, sandbox-write-commit, and sandbox-write-commit-enable layers", static: true },
  ];
  const dynamicReasons: CommitExecutionBlockedReason[] = checks
    .filter((c) => !c.pass)
    .map((c) => ({ code: c.rule, reason: c.note, static: false }));
  return [...staticReasons, ...dynamicReasons];
}

function buildLinkedCommitExecutionReference(
  input: CreateActualSandboxWriteCommitExecutionGateInput,
  rollbackChainValid: boolean,
): LinkedCommitExecutionReference {
  const { commitEnableRecord, commitRecord, executorRecord, writeOperationRecord } = input;
  return {
    sandboxWriteCommitEnableId:   commitEnableRecord.sandboxWriteCommitEnableId,
    sandboxWriteCommitId:         commitRecord.sandboxWriteCommitId,
    runtimeWriteExecutorId:       executorRecord.runtimeWriteExecutorId,
    actualWriteOperationId:       writeOperationRecord.actualWriteOperationId,
    rollbackSnapshotId:           commitEnableRecord.linkedCommitEnableReference.rollbackSnapshotId,
    commitExecutionGatePrepared:  true,
    commitExecutionGateEnabled:   false,
    sandboxWriteCommitEnabled:    false,
    runtimeWriteExecutorEnabled:  false,
    actualWritesEnabled:          false,
    rollbackChainValid,
    referenceNote: "linked commit execution reference sources rollbackSnapshotId from commitEnableRecord.linkedCommitEnableReference; commit execution gate disabled; sandbox write commit enable disabled; sandbox write commit disabled; runtime write executor disabled; filesystem mutation blocked; descriptor-only; targetScope=sandbox_approved_only",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createActualSandboxWriteCommitExecutionGateRecord(
  input: CreateActualSandboxWriteCommitExecutionGateInput,
): ActualSandboxWriteCommitExecutionGateRecord {
  const { commitEnableRecord, commitRecord, executorRecord, writeOperationRecord, writeExecutionGateRecord, executionRecord } = input;

  const checks = buildChecks(input);

  const rollbackChainValid = commitEnableRecord.commitEnableReadinessReport.rollbackChainValid;

  const allChecksPass   = checks.every((c) => c.pass);
  const blockedReasons  = buildBlockedReasons(checks);
  const linkedRef       = buildLinkedCommitExecutionReference(input, rollbackChainValid);

  const commitExecutionReadinessReport: CommitExecutionReadinessReport = {
    commitExecutionGatePrepared:      true,
    commitExecutionGateEnabled:       false,
    sandboxWriteCommitEnabled:        false,
    runtimeWriteExecutorEnabled:      false,
    writeExecutionGateEnabled:        false,
    scopedActivationEnabled:          false,
    writePermissionEnabled:           false,
    mutationSwitchEnabled:            false,
    guardedWriteEnabled:              false,
    actualWritesEnabled:              false,
    realWritesEnabled:                false,
    approvalRequired:                 true,
    allChecksPass,
    blockedReasonCount:               blockedReasons.length,
    rollbackChainValid,
    targetScope:                      "sandbox_approved_only",
    summary: `commitExecutionState=descriptor_commit_execution_gate_pending; commitExecutionGateEnabled=false; sandboxWriteCommitEnabled=false; runtimeWriteExecutorEnabled=false; actualWritesEnabled=false; filesystemMutationBlocked=true; targetScope=sandbox_approved_only; allChecksPass=${allChecksPass}; rollbackChainValid=${rollbackChainValid}; blockedReasonCount=${blockedReasons.length}`,
  };

  const record: ActualSandboxWriteCommitExecutionGateRecord = {
    commitExecutionGateId:            randomUUID(),
    commitExecutionState:             "descriptor_commit_execution_gate_pending",
    approvalRequired:                 true,
    commitExecutionGatePrepared:      true,
    commitExecutionGateEnabled:       false,
    sandboxWriteCommitEnabled:        false,
    runtimeWriteExecutorEnabled:      false,
    actualWritesEnabled:              false,
    filesystemMutationBlocked:        true,
    motherCoreMutationBlocked:        true,
    vaultMutationBlocked:             true,
    shellBlocked:                     true,
    networkBlocked:                   true,
    targetScope:                      "sandbox_approved_only",
    implementationPhase:              "descriptor_only",
    sandboxWriteCommitEnableId:       commitEnableRecord.sandboxWriteCommitEnableId,
    sandboxWriteCommitId:             commitRecord.sandboxWriteCommitId,
    runtimeWriteExecutorId:           executorRecord.runtimeWriteExecutorId,
    actualWriteOperationId:           writeOperationRecord.actualWriteOperationId,
    writeExecutionGateId:             writeExecutionGateRecord.writeExecutionGateId,
    controlledExecutionId:            executionRecord.controlledExecutionId,
    commitExecutionChecks:            checks,
    commitExecutionBlockedReasons:    blockedReasons,
    commitExecutionReadinessReport,
    linkedCommitExecutionReference:   linkedRef,
    createdAt:                        new Date().toISOString(),
  };

  _store.push(record);
  return record;
}

export function listActualSandboxWriteCommitExecutionGateRecords(): readonly ActualSandboxWriteCommitExecutionGateRecord[] {
  return _store.slice();
}

export function getActualSandboxWriteCommitExecutionGateSummary(): ActualSandboxWriteCommitExecutionGateSummary {
  return {
    total:                          _store.length,
    byState:                        { descriptor_commit_execution_gate_pending: _store.length },
    commitExecutionGatePrepared:    true,
    commitExecutionGateEnabled:     false,
    sandboxWriteCommitEnabled:      false,
    runtimeWriteExecutorEnabled:    false,
    actualWritesEnabled:            false,
    approvalRequired:               true,
    filesystemMutationBlocked:      true,
    motherCoreMutationBlocked:      true,
    targetScope:                    "sandbox_approved_only",
    commitExecutionState:           "descriptor_commit_execution_gate_pending",
    implementationPhase:            "descriptor_only",
  };
}
