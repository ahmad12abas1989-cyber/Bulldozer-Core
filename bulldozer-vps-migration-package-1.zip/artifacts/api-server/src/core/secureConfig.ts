import { logger } from "../lib/logger";

export type SecureConfigStatus = "safe" | "degraded" | "unsafe";

export interface SecureConfigReport {
  status: SecureConfigStatus;
  env: string;
  safeConfigSummary: Record<string, string>;
  missingCount: number;
  warnings: string[];
  timestamp: string;
}

const REQUIRED_KEYS: string[] = ["PORT"];
const OPTIONAL_KEYS: string[] = ["NODE_ENV", "LOG_LEVEL"];
const VALID_NODE_ENV = new Set(["development", "production", "test"]);
const VALID_LOG_LEVEL = new Set(["debug", "info", "warn", "error"]);

const SENSITIVE_PATTERN = /SECRET|KEY|TOKEN|PASSWORD|PASSWD|PRIVATE|CREDENTIAL|AUTH|API_KEY|SIGNING/i;

function maskIfSensitive(envKey: string, value: string): string {
  return SENSITIVE_PATTERN.test(envKey) ? "***MASKED***" : value;
}

function detectSensitiveEnvVars(): string[] {
  return Object.keys(process.env).filter((k) => SENSITIVE_PATTERN.test(k));
}

export function getSecureConfigStatus(): SecureConfigReport {
  const warnings: string[] = [];
  let missingCount = 0;
  let hasUnsafe = false;

  const safeConfigSummary: Record<string, string> = {};

  for (const key of REQUIRED_KEYS) {
    const val = process.env[key];
    if (!val) {
      missingCount++;
      hasUnsafe = true;
      safeConfigSummary[key] = "MISSING";
      warnings.push(`Required config key missing: ${key}`);
    } else {
      safeConfigSummary[key] = maskIfSensitive(key, val);
    }
  }

  for (const key of OPTIONAL_KEYS) {
    const val = process.env[key];
    if (!val) {
      missingCount++;
      safeConfigSummary[key] = "NOT_SET (using default)";
      warnings.push(`Optional config key not set: ${key}`);
    } else {
      safeConfigSummary[key] = maskIfSensitive(key, val);
    }
  }

  const nodeEnv = process.env["NODE_ENV"] ?? "development";
  if (!VALID_NODE_ENV.has(nodeEnv)) {
    warnings.push(`NODE_ENV "${nodeEnv}" is not a recognised environment`);
  }

  const logLevel = process.env["LOG_LEVEL"] ?? "info";
  if (!VALID_LOG_LEVEL.has(logLevel)) {
    warnings.push(`LOG_LEVEL "${logLevel}" is not a recognised log level`);
  }

  const sensitiveKeys = detectSensitiveEnvVars();
  if (sensitiveKeys.length > 0) {
    warnings.push(
      `${sensitiveKeys.length} sensitive env var(s) detected in environment: ${sensitiveKeys.join(", ")} — values masked`,
    );
    for (const key of sensitiveKeys) {
      safeConfigSummary[key] = "***MASKED***";
    }
  }

  let status: SecureConfigStatus;
  if (hasUnsafe) {
    status = "unsafe";
  } else if (warnings.length > 0) {
    status = "degraded";
  } else {
    status = "safe";
  }

  logger.debug({ status, missingCount, warningCount: warnings.length }, "Secure config status computed");

  return {
    status,
    env: nodeEnv,
    safeConfigSummary,
    missingCount,
    warnings,
    timestamp: new Date().toISOString(),
  };
}
