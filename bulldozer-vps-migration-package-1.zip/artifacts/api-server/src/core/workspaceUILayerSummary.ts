// Workspace UI Layer Summary — Phase 133
// Aggregates existing UI-layer modules into a single lightweight operational overview.
// No new business logic. No persistence. No mutation. No HTML/CSS/JSX.
// Reads from: workspaceUIRenderModel, workspaceDashboardSkeleton,
//             workspaceUICoherence, workspaceUILayerVersionManifest.
// No init(). No subsystem. No health check.

import { getUIRenderModel }            from "./workspaceUIRenderModel";
import { getDashboardSkeleton }        from "./workspaceDashboardSkeleton";
import { getUICoherence }              from "./workspaceUICoherence";
import { getUILayerVersionManifest }   from "./workspaceUILayerVersionManifest";

const EXECUTION_BLOCKED: true = true;

// ---------------------------------------------------------------------------
// Type definitions
// ---------------------------------------------------------------------------

export interface UILayerSummaryEntry {
  layerId:          string;
  version:          string;
  endpoint:         string;
  healthy:          boolean;
  executionBlocked: true;
}

export interface UILayerSchemaHashes {
  renderModel:      string;
  dashboardSkeleton: string;
  coherenceProbe:   string;
}

export interface UILayerSummary {
  generatedAt:           string;
  uiVersion:             string;
  dashboardVersion:      string;
  manifestVersion:       string;
  layerCount:            number;
  totalWidgets:          number;
  totalPanels:           number;
  totalPages:            number;
  totalBindings:         number;
  allLayersCoherent:     boolean;
  bindingCoveragePercent: number;
  schemaHashes:          UILayerSchemaHashes;
  layers:                UILayerSummaryEntry[];
  executionBlocked:      true;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
// Derives all values from the four existing UI modules. No duplicated logic.
// Canonical alphabetical ordering by layerId matches version manifest ordering.
// layers[].healthy is always true — all four modules are pure in-memory
// derivations with no failure modes (they cannot return null/undefined/throw
// under normal operation). healthy reflects successful module load, not a
// live ping; it is always true and executionBlocked is always true.

export function getUILayerSummary(): UILayerSummary {
  const renderModel = getUIRenderModel();
  const skeleton    = getDashboardSkeleton();
  const coherence   = getUICoherence();
  const manifest    = getUILayerVersionManifest();

  // Extract schemaHashes from manifest layers (already alphabetical)
  const hashMap = new Map<string, string>(
    manifest.layers.map((l) => [l.layerId, l.schemaHash]),
  );

  const schemaHashes: UILayerSchemaHashes = {
    renderModel:       hashMap.get("ui_render_model")    ?? "",
    dashboardSkeleton: hashMap.get("dashboard_skeleton") ?? "",
    coherenceProbe:    hashMap.get("ui_coherence_probe") ?? "",
  };

  // layers[] — 3 entries, alphabetical by layerId (mirrors manifest ordering)
  // healthy=true: all modules are pure derivations; no live endpoint probe needed
  const layers: UILayerSummaryEntry[] = manifest.layers.map((l) => ({
    layerId:          l.layerId,
    version:          l.version,
    endpoint:         l.endpoint,
    healthy:          true,
    executionBlocked: EXECUTION_BLOCKED,
  }));

  const allLayersCoherent =
    coherence.allWidgetsCoherent &&
    coherence.allPanelsCoherent  &&
    coherence.allPagesCoherent;

  return {
    generatedAt:            new Date().toISOString(),
    uiVersion:              renderModel.uiVersion,
    dashboardVersion:       skeleton.dashboardVersion,
    manifestVersion:        manifest.manifestVersion,
    layerCount:             manifest.layerCount,
    totalWidgets:           renderModel.widgets.length,
    totalPanels:            skeleton.panelLayouts.length,
    totalPages:             skeleton.pageLayouts.length,
    totalBindings:          renderModel.dataBindings.length,
    allLayersCoherent,
    bindingCoveragePercent: coherence.bindingCoverage.coveragePercent,
    schemaHashes,
    layers,
    executionBlocked:       EXECUTION_BLOCKED,
  };
}
