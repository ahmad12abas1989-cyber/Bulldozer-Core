import { randomBytes } from "node:crypto";
import { getRuntimeInfo, type RuntimeInfo } from "./runtime";
import { getMetrics, type MetricsSnapshot } from "./metrics";
import { getFreezeStatus, type FreezeState } from "./freezeDetector";
import { getCrashStatus, type CrashState } from "./crashDetector";
import { persistSnapshot } from "./snapshotStorage";
import { emit } from "./eventBus";

export type SnapshotHealth = "healthy" | "degraded" | "unhealthy";

export interface Snapshot {
  id: string;
  reason: string;
  createdAt: string;
  runtime: RuntimeInfo;
  metrics: MetricsSnapshot;
  freeze: FreezeState;
  crash: CrashState;
  healthSummary: SnapshotHealth;
}

export interface SnapshotHistory {
  count: number;
  latest: Snapshot | null;
  snapshots: Snapshot[];
}

const MAX_HISTORY = 10;
const history: Snapshot[] = [];

function computeHealthSummary(
  runtime: RuntimeInfo,
  freeze: FreezeState,
  crash: CrashState,
): SnapshotHealth {
  if (
    runtime.state !== "ready" ||
    freeze.status === "frozen" ||
    crash.status === "crashed"
  ) {
    return "unhealthy";
  }
  if (freeze.status === "warning" || crash.status === "warning") {
    return "degraded";
  }
  return "healthy";
}

export function createSnapshot(reason = "manual"): Snapshot {
  const runtime = getRuntimeInfo();
  const metrics = getMetrics();
  const freeze = getFreezeStatus();
  const crash = getCrashStatus();
  const healthSummary = computeHealthSummary(runtime, freeze, crash);

  const snapshot: Snapshot = {
    id: randomBytes(8).toString("hex"),
    reason,
    createdAt: new Date().toISOString(),
    runtime,
    metrics,
    freeze,
    crash,
    healthSummary,
  };

  if (history.length >= MAX_HISTORY) {
    history.shift();
  }
  history.push(snapshot);

  try {
    persistSnapshot(snapshot);
  } catch (err) {
    // storage failure never affects in-memory operation
  }

  emit("snapshot:created", "snapshots", {
    id: snapshot.id,
    reason: snapshot.reason,
    healthSummary: snapshot.healthSummary,
  });

  return snapshot;
}

export function getLatestSnapshot(): Snapshot | null {
  return history.length > 0 ? history[history.length - 1]! : null;
}

export function getSnapshotHistory(): SnapshotHistory {
  return {
    count: history.length,
    latest: getLatestSnapshot(),
    snapshots: [...history],
  };
}

export function clearSnapshots(): void {
  history.length = 0;
}
